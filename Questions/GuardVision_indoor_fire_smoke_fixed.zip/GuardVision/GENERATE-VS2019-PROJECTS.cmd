@echo off
setlocal
echo Generating Visual Studio 2019 projects for GuardVision...
call "%~dp0scripts\prepare-vs.cmd" %*
if errorlevel 1 (
    echo.
    echo Failed. Install Visual Studio 2019 with C++ desktop development and CMake, then retry.
    exit /b 1
)
echo.
echo Done. Open GuardVision.sln in Visual Studio 2019.
exit /b 0
