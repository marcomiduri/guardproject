#include <iostream>

#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <core/StreamConfig.h>

int main() {
    guardvision::GuardVision guardVision;

    guardvision::GuardVisionConfig runtimeConfig;
    runtimeConfig.maxStreams = 4;

    const guardvision::Result initialized = guardVision.initialize(runtimeConfig);
    if (!initialized.ok) {
        std::cerr << "GuardVision initialization failed: " << initialized.error.message << '\n';
        return 1;
    }

    guardvision::StreamConfig streamConfig;
    streamConfig.streamId = "example-camera";
    streamConfig.displayName = "Example Camera";

    const guardvision::Result registered = guardVision.registerStream(streamConfig);
    if (!registered.ok) {
        std::cerr << "Stream registration failed: " << registered.error.message << '\n';
        guardVision.shutdown();
        return 1;
    }

    std::cout << "GuardVision " << guardvision::GuardVision::version()
              << " initialized. Submit decoded VideoFrame objects from the host application.\n";

    guardVision.unregisterStream(streamConfig.streamId);
    guardVision.shutdown();
    return 0;
}
