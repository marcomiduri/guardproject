[CmdletBinding()]
param(
    [string]$Generator = 'Visual Studio 16 2019',
    [string]$Architecture = 'x64',
    [string]$Toolset = '',
    [switch]$Clean
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

$guardVisionRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path

& (Join-Path $PSScriptRoot 'build.ps1') `
    -Configuration Debug `
    -BuildDir $guardVisionRoot `
    -Generator $Generator `
    -Architecture $Architecture `
    -Toolset $Toolset `
    -SkipTests `
    -ConfigureOnly `
    -Clean:$Clean

Write-Host "Open $(Join-Path $guardVisionRoot 'GuardVision.sln') in Visual Studio 2019."
