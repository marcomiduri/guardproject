<#
.SYNOPSIS
    Build, test, and optionally install GuardVision without requiring Qt.

.DESCRIPTION
    GuardVision is a Qt-independent static C++ library. This script validates
    the offline proprietary SDK layout, configures CMake, builds the requested
    configuration, runs CTest, and leaves the published library in bin/<Config>.
#>
[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release', 'RelWithDebInfo', 'MinSizeRel')]
    [string]$Configuration = 'Release',
    [string]$BuildDir = '',
    [string]$Generator = 'Visual Studio 16 2019',
    [string]$Architecture = 'x64',
    [string]$Toolset = '',
    [string]$IdentifyRoot = '',
    [string]$HazardDetectRoot = '',
    [bool]$EnableFace = $true,
    [bool]$EnableHazard = $true,
    [string]$IdentifyRuntimeDir = '',
    [string]$IdentifyRuntimeDirDebug = '',
    [string]$IdentifyRuntimeDirRelease = '',
    [string]$HazardDetectRuntimeDir = '',
    [string]$HazardDetectRuntimeDirDebug = '',
    [string]$HazardDetectRuntimeDirRelease = '',
    [string]$OpenCvRoot = '',
    [string]$OpenCvRuntimeDir = '',
    [string]$OpenCvRuntimeDirDebug = '',
    [string]$OpenCvRuntimeDirRelease = '',
    [switch]$SkipTests,
    [switch]$BuildExamples,
    [switch]$WarningsAsErrors,
    [switch]$Clean,
    [switch]$ConfigureOnly,
    [string]$InstallPrefix = ''
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

function Resolve-ExistingDirectory {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Label
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "$Label was not found: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

function Resolve-OptionalDirectory {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        return ''
    }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "Runtime directory was not found: $Path"
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

function Find-FirstRuntimeDirectory {
    param([string[]]$Candidates)

    foreach ($candidate in $Candidates) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and
            (Test-Path -LiteralPath $candidate -PathType Container)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }
    return ''
}

function Resolve-CMakeExecutable {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('cmake', 'ctest')]
        [string]$Name
    )

    $command = Get-Command $Name -ErrorAction SilentlyContinue
    if ($command -and -not [string]::IsNullOrWhiteSpace($command.Source)) {
        return $command.Source
    }

    $binCandidates = New-Object System.Collections.Generic.List[string]

    foreach ($scope in @('Process', 'User', 'Machine')) {
        $cmakePath = [Environment]::GetEnvironmentVariable('CMAKE', $scope)
        if (-not [string]::IsNullOrWhiteSpace($cmakePath)) {
            $binCandidates.Add((Split-Path -Parent $cmakePath))
            $binCandidates.Add($cmakePath)
        }
    }

    try {
        $kitwareInstallDir = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Kitware\CMake' -Name InstallDir -ErrorAction Stop).InstallDir
        if (-not [string]::IsNullOrWhiteSpace($kitwareInstallDir)) {
            $binCandidates.Add((Join-Path $kitwareInstallDir 'bin'))
        }
    } catch {
        # Kitware CMake registry key is optional.
    }

    $binCandidates.Add((Join-Path $env:ProgramFiles 'CMake\bin'))
    if (-not [string]::IsNullOrWhiteSpace(${env:ProgramFiles(x86)})) {
        $binCandidates.Add((Join-Path ${env:ProgramFiles(x86)} 'CMake\bin'))
    }
    $binCandidates.Add((Join-Path $env:LOCALAPPDATA 'Programs\CMake\bin'))

    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path -LiteralPath $vswhere) {
        $vsCMakeBins = @(
            & $vswhere -version '[16.0,17.0)' -products * -requires Microsoft.VisualStudio.Component.VC.CMake.Project `
                -find 'CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe' 2>$null
            & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.CMake.Project `
                -find 'CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe' 2>$null
        ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

        foreach ($vsCMake in $vsCMakeBins) {
            $binCandidates.Add((Split-Path -Parent $vsCMake))
        }

        $vsInstalls = @(
            & $vswhere -version '[16.0,17.0)' -products * -property installationPath 2>$null
            & $vswhere -latest -products * -property installationPath 2>$null
        ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

        foreach ($install in $vsInstalls) {
            $binCandidates.Add((Join-Path $install 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin'))
        }
    }

    $exeName = "$Name.exe"
    foreach ($binDir in ($binCandidates | Select-Object -Unique)) {
        if ([string]::IsNullOrWhiteSpace($binDir)) {
            continue
        }

        $candidate = if ((Split-Path -Leaf $binDir) -ieq $exeName) {
            $binDir
        } else {
            Join-Path $binDir $exeName
        }

        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    throw @"
'$Name' was not found on PATH or in common install locations.
Install CMake (https://cmake.org/download/) and ensure it is on PATH, or install the
'C++ CMake tools for Windows' component with Visual Studio 2019.
"@
}

function Stop-StaleGuardVisionTestProcesses {
    param([Parameter(Mandatory = $true)][string]$Root)

    $normalizedRoot = [System.IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    Get-Process -Name guardvision_tests -ErrorAction SilentlyContinue | ForEach-Object {
        $processPath = ''
        try {
            $processPath = $_.Path
        } catch {
            $processPath = ''
        }

        if (-not [string]::IsNullOrWhiteSpace($processPath)) {
            $normalizedProcessPath = [System.IO.Path]::GetFullPath($processPath)
            if ($normalizedProcessPath.StartsWith($normalizedRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
                Write-Host "[GuardVision] Stopping stale test process $($_.Id): $normalizedProcessPath"
                Stop-Process -Id $_.Id -Force
            }
        }
    }
}

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\win-path-utils.ps1')

$GuardVisionRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$DesktopRoot = (Resolve-Path (Join-Path $GuardVisionRoot '..')).Path
$skipTestsExplicit = $PSBoundParameters.ContainsKey('SkipTests')
$installRoot = Split-Path $DesktopRoot -Parent
$isInstalledDaboardPackage = (Test-Path (Join-Path $installRoot 'SourceBuildGuide.md')) -or
    (Test-Path (Join-Path $installRoot 'build-tool\DABoardBuildTool.exe'))
if (-not $skipTestsExplicit -and $isInstalledDaboardPackage) {
    $SkipTests = $true
    Write-Host '[GuardVision] Installed DABoard source package detected; building guardvision.lib only (skipping CTest).'
    Write-Host '[GuardVision] To run tests anyway: add -SkipTests:`$false to the build script.'
}
if (-not $SkipTests) {
    Stop-StaleGuardVisionTestProcesses -Root $GuardVisionRoot
}
if ([string]::IsNullOrWhiteSpace($BuildDir)) {
    $BuildDir = $GuardVisionRoot
}
if ($EnableFace) {
    if ([string]::IsNullOrWhiteSpace($IdentifyRoot)) {
        $IdentifyRoot = Join-Path $DesktopRoot 'sdk\Identify'
    }
    $IdentifyRoot = Resolve-ExistingDirectory -Path $IdentifyRoot -Label 'Identify SDK root'
} else {
    $IdentifyRoot = ''
}
if ($EnableHazard) {
    if ([string]::IsNullOrWhiteSpace($HazardDetectRoot)) {
        $HazardDetectRoot = Join-Path $DesktopRoot 'sdk\HazardDetect'
    }
    $HazardDetectRoot = Resolve-ExistingDirectory -Path $HazardDetectRoot -Label 'HazardDetect SDK root'
} else {
    $HazardDetectRoot = ''
}

if ($EnableFace -and [string]::IsNullOrWhiteSpace($IdentifyRuntimeDir)) {
    $IdentifyRuntimeDir = Find-FirstRuntimeDirectory @(
        (Join-Path $IdentifyRoot 'bin')
    )
}
if ($EnableFace -and [string]::IsNullOrWhiteSpace($IdentifyRuntimeDirDebug)) {
    $IdentifyRuntimeDirDebug = Find-FirstRuntimeDirectory @(
        (Join-Path $IdentifyRoot 'runtime\Debug'),
        (Join-Path $IdentifyRoot 'bin\Debug'),
        (Join-Path $IdentifyRoot 'debug'),
        (Join-Path $IdentifyRoot 'Debug')
    )
}
if ($EnableFace -and [string]::IsNullOrWhiteSpace($IdentifyRuntimeDirRelease)) {
    $IdentifyRuntimeDirRelease = Find-FirstRuntimeDirectory @(
        (Join-Path $IdentifyRoot 'runtime\Release'),
        (Join-Path $IdentifyRoot 'bin\Release'),
        (Join-Path $IdentifyRoot 'release'),
        (Join-Path $IdentifyRoot 'Release')
    )
}
if ($EnableHazard -and [string]::IsNullOrWhiteSpace($HazardDetectRuntimeDir)) {
    $HazardDetectRuntimeDir = Find-FirstRuntimeDirectory @(
        (Join-Path $HazardDetectRoot 'bin')
    )
}
if ($EnableHazard -and [string]::IsNullOrWhiteSpace($HazardDetectRuntimeDirDebug)) {
    $HazardDetectRuntimeDirDebug = Find-FirstRuntimeDirectory @(
        (Join-Path $HazardDetectRoot 'runtime\Debug'),
        (Join-Path $HazardDetectRoot 'bin\Debug'),
        (Join-Path $HazardDetectRoot 'lib-debug'),
        (Join-Path $HazardDetectRoot 'debug'),
        (Join-Path $HazardDetectRoot 'Debug')
    )
}
if ($EnableHazard -and [string]::IsNullOrWhiteSpace($HazardDetectRuntimeDirRelease)) {
    $HazardDetectRuntimeDirRelease = Find-FirstRuntimeDirectory @(
        (Join-Path $HazardDetectRoot 'runtime\Release'),
        (Join-Path $HazardDetectRoot 'bin\Release'),
        (Join-Path $HazardDetectRoot 'release'),
        (Join-Path $HazardDetectRoot 'Release')
    )
}
if ($EnableHazard) {
    if ([string]::IsNullOrWhiteSpace($OpenCvRoot)) {
        $OpenCvRoot = Join-Path $DesktopRoot 'sdk\OpenCV'
    }
    if ([string]::IsNullOrWhiteSpace($OpenCvRuntimeDir)) {
        $OpenCvRuntimeDir = Find-FirstRuntimeDirectory @(
            (Join-Path $OpenCvRoot 'bin')
        )
    }
    if ([string]::IsNullOrWhiteSpace($OpenCvRuntimeDirDebug)) {
        $OpenCvRuntimeDirDebug = Find-FirstRuntimeDirectory @(
            (Join-Path $OpenCvRoot 'runtime\Debug'),
            (Join-Path $OpenCvRoot 'bin\Debug'),
            (Join-Path $OpenCvRoot 'debug'),
            (Join-Path $OpenCvRoot 'Debug')
        )
    }
    if ([string]::IsNullOrWhiteSpace($OpenCvRuntimeDirRelease)) {
        $OpenCvRuntimeDirRelease = Find-FirstRuntimeDirectory @(
            (Join-Path $OpenCvRoot 'runtime\Release'),
            (Join-Path $OpenCvRoot 'bin\Release'),
            (Join-Path $OpenCvRoot 'release'),
            (Join-Path $OpenCvRoot 'Release')
        )
    }
}

if ($EnableFace) {
    $IdentifyRuntimeDir = Resolve-OptionalDirectory $IdentifyRuntimeDir
    $IdentifyRuntimeDirDebug = Resolve-OptionalDirectory $IdentifyRuntimeDirDebug
    $IdentifyRuntimeDirRelease = Resolve-OptionalDirectory $IdentifyRuntimeDirRelease
} else {
    $IdentifyRuntimeDir = ''
    $IdentifyRuntimeDirDebug = ''
    $IdentifyRuntimeDirRelease = ''
}
if ($EnableHazard) {
    $HazardDetectRuntimeDir = Resolve-OptionalDirectory $HazardDetectRuntimeDir
    $HazardDetectRuntimeDirDebug = Resolve-OptionalDirectory $HazardDetectRuntimeDirDebug
    $HazardDetectRuntimeDirRelease = Resolve-OptionalDirectory $HazardDetectRuntimeDirRelease
    $OpenCvRuntimeDir = Resolve-OptionalDirectory $OpenCvRuntimeDir
    $OpenCvRuntimeDirDebug = Resolve-OptionalDirectory $OpenCvRuntimeDirDebug
    $OpenCvRuntimeDirRelease = Resolve-OptionalDirectory $OpenCvRuntimeDirRelease
} else {
    $HazardDetectRuntimeDir = ''
    $HazardDetectRuntimeDirDebug = ''
    $HazardDetectRuntimeDirRelease = ''
    $OpenCvRuntimeDir = ''
    $OpenCvRuntimeDirDebug = ''
    $OpenCvRuntimeDirRelease = ''
}

if ($Clean) {
    if ($BuildDir -eq $GuardVisionRoot) {
        $cmakeArtifactNames = @(
            'CMakeCache.txt',
            'cmake_install.cmake',
            'CTestTestfile.cmake',
            'GuardVision.sln',
            'ALL_BUILD.vcxproj',
            'ALL_BUILD.vcxproj.filters',
            'INSTALL.vcxproj',
            'INSTALL.vcxproj.filters',
            'RUN_TESTS.vcxproj',
            'RUN_TESTS.vcxproj.filters',
            'ZERO_CHECK.vcxproj',
            'ZERO_CHECK.vcxproj.filters',
            'guardvision.vcxproj',
            'guardvision.vcxproj.filters'
        )
        foreach ($name in $cmakeArtifactNames) {
            $artifactPath = Join-Path $GuardVisionRoot $name
            if (Test-Path -LiteralPath $artifactPath) {
                Remove-Item -LiteralPath $artifactPath -Recurse -Force
            }
        }
        $cmakeFilesDir = Join-Path $GuardVisionRoot 'CMakeFiles'
        if (Test-Path -LiteralPath $cmakeFilesDir) {
            Remove-Item -LiteralPath $cmakeFilesDir -Recurse -Force
        }
        $testsDir = Join-Path $GuardVisionRoot 'tests'
        if (Test-Path -LiteralPath $testsDir) {
            Get-ChildItem -LiteralPath $testsDir -File -Filter '*.vcxproj*' -ErrorAction SilentlyContinue |
                Remove-Item -Force
        }
    } elseif (Test-Path -LiteralPath $BuildDir) {
        Remove-Item -LiteralPath $BuildDir -Recurse -Force
    }
}

$cmakeArgs = @(
    '-S', $GuardVisionRoot,
    '-B', $BuildDir,
    '-G', $Generator,
    "-DGUARDVISION_ENABLE_FACE=$EnableFace",
    "-DGUARDVISION_ENABLE_HAZARD=$EnableHazard",
    "-DGUARDVISION_BUILD_TESTS=$([bool](-not $SkipTests))",
    "-DGUARDVISION_BUILD_EXAMPLES=$([bool]$BuildExamples)",
    "-DGUARDVISION_WARNINGS_AS_ERRORS=$([bool]$WarningsAsErrors)",
    '-DGUARDVISION_PUBLISH_TO_SOURCE_BIN=ON'
)


if ($EnableFace) {
    $cmakeArgs += (Format-CMakeCacheArg -Name 'GUARDVISION_IDENTIFY_ROOT' -Value $IdentifyRoot)
}
if ($EnableHazard) {
    $cmakeArgs += (Format-CMakeCacheArg -Name 'GUARDVISION_HAZARDDETECT_ROOT' -Value $HazardDetectRoot)
}

$runtimeVariables = @{
    'GUARDVISION_IDENTIFY_RUNTIME_DIR' = $IdentifyRuntimeDir
    'GUARDVISION_IDENTIFY_RUNTIME_DIR_DEBUG' = $IdentifyRuntimeDirDebug
    'GUARDVISION_IDENTIFY_RUNTIME_DIR_RELEASE' = $IdentifyRuntimeDirRelease
    'GUARDVISION_HAZARDDETECT_RUNTIME_DIR' = $HazardDetectRuntimeDir
    'GUARDVISION_HAZARDDETECT_RUNTIME_DIR_DEBUG' = $HazardDetectRuntimeDirDebug
    'GUARDVISION_HAZARDDETECT_RUNTIME_DIR_RELEASE' = $HazardDetectRuntimeDirRelease
    'GUARDVISION_OPENCV_RUNTIME_DIR' = $OpenCvRuntimeDir
    'GUARDVISION_OPENCV_RUNTIME_DIR_DEBUG' = $OpenCvRuntimeDirDebug
    'GUARDVISION_OPENCV_RUNTIME_DIR_RELEASE' = $OpenCvRuntimeDirRelease
}
foreach ($entry in $runtimeVariables.GetEnumerator()) {
    $cacheArg = Format-CMakeCacheArg -Name $entry.Key -Value $entry.Value
    if ($cacheArg) {
        $cmakeArgs += $cacheArg
    }
}

$cmakeInstallPrefix = if ([string]::IsNullOrWhiteSpace($InstallPrefix)) {
    Join-Path $GuardVisionRoot 'install'
} else {
    $InstallPrefix
}
$cmakeArgs += (Format-CMakeCacheArg -Name 'CMAKE_INSTALL_PREFIX' -Value $cmakeInstallPrefix)

if (-not [string]::IsNullOrWhiteSpace($Architecture)) {
    $cmakeArgs += @('-A', $Architecture)
}
if (-not [string]::IsNullOrWhiteSpace($Toolset)) {
    $cmakeArgs += @('-T', $Toolset)
}

$cmakeExe = Resolve-CMakeExecutable -Name 'cmake'
$ctestExe = $null
if (-not $SkipTests) {
    $ctestExe = Resolve-CMakeExecutable -Name 'ctest'
}

Write-Host "[GuardVision] Using CMake: $cmakeExe"
Write-Host "[GuardVision] Configuring $Configuration..."
& $cmakeExe @cmakeArgs
if ($LASTEXITCODE -ne 0) {
    throw 'GuardVision CMake configure failed.'
}

$solutionPath = Join-Path $BuildDir 'GuardVision.sln'
if ($ConfigureOnly) {
    if (-not (Test-Path -LiteralPath $solutionPath)) {
        throw "GuardVision Visual Studio solution was not created: $solutionPath"
    }
    Write-Host "[GuardVision] Visual Studio solution ready: $solutionPath"
    Write-Host '[GuardVision] Open GuardVision.sln in Visual Studio 2019 (Debug|x64 or Release|x64).'
    return
}

$targets = @('guardvision')
if (-not $SkipTests) {
    $targets += 'guardvision_tests'
}
if ($BuildExamples) {
    $targets += 'guardvision_basic_frame_submit'
}

Write-Host "[GuardVision] Building targets: $($targets -join ', ')"
& $cmakeExe --build $BuildDir --config $Configuration --parallel --target @targets
if ($LASTEXITCODE -ne 0) {
    throw "GuardVision build failed for $Configuration."
}

$publishedLib = Join-Path $GuardVisionRoot "bin\$Configuration\guardvision.lib"
if (-not (Test-Path -LiteralPath $publishedLib)) {
    throw "GuardVision publish output missing: $publishedLib"
}

if (-not $SkipTests) {
    Write-Host '[GuardVision] Running CTest...'
    & $ctestExe --test-dir $BuildDir -C $Configuration --output-on-failure --timeout 180
    if ($LASTEXITCODE -ne 0) {
        throw "GuardVision tests failed for $Configuration."
    }
}

if (-not [string]::IsNullOrWhiteSpace($InstallPrefix)) {
    Write-Host "[GuardVision] Installing to $InstallPrefix..."
    & $cmakeExe --install $BuildDir --config $Configuration --prefix $InstallPrefix
    if ($LASTEXITCODE -ne 0) {
        throw "GuardVision install failed for $Configuration."
    }
}

Write-Host "[GuardVision] Published $publishedLib"
