@echo off
setlocal
echo Building GuardVision Debug (library only, tests skipped)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-debug.ps1" -SkipTests %*
exit /b %ERRORLEVEL%
