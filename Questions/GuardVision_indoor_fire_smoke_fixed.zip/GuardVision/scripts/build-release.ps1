[CmdletBinding()]
param(
    [string]$Generator = 'Visual Studio 16 2019',
    [string]$Architecture = 'x64',
    [string]$Toolset = '',
    [string]$IdentifyRoot = '',
    [string]$HazardDetectRoot = '',
    [bool]$EnableFace = $true,
    [bool]$EnableHazard = $true,
    [switch]$SkipTests,
    [switch]$WarningsAsErrors,
    [switch]$Clean
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

& (Join-Path $PSScriptRoot 'build.ps1') `
    -Configuration Release `
    -Generator $Generator `
    -Architecture $Architecture `
    -Toolset $Toolset `
    -IdentifyRoot $IdentifyRoot `
    -HazardDetectRoot $HazardDetectRoot `
    -EnableFace:$EnableFace `
    -EnableHazard:$EnableHazard `
    -SkipTests:$SkipTests `
    -WarningsAsErrors:$WarningsAsErrors `
    -Clean:$Clean
