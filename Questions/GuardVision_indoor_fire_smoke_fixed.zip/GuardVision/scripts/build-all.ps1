<#
.SYNOPSIS
    Build GuardVision Debug and Release.

.DESCRIPTION
    GuardVision itself does not link Qt. Build it once per configuration with
    scripts/build.ps1. Qt 5.7, 5.12, and 5.14 compatibility belongs to the host
    application's consumer smoke tests, not to the standalone library build.
#>
[CmdletBinding()]
param(
    [string]$Generator = 'Visual Studio 16 2019',
    [string]$Architecture = 'x64',
    [string]$Toolset = '',
    [string]$IdentifyRoot = '',
    [string]$HazardDetectRoot = '',
    [bool]$EnableFace = $true,
    [bool]$EnableHazard = $true,
    [switch]$SkipTests,
    [switch]$WarningsAsErrors,
    [switch]$Clean
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

Write-Host '[GuardVision] Building Debug and Release (Qt-independent library).'
& (Join-Path $PSScriptRoot 'build-debug.ps1') `
    -Generator $Generator -Architecture $Architecture -Toolset $Toolset `
    -IdentifyRoot $IdentifyRoot -HazardDetectRoot $HazardDetectRoot `
    -EnableFace:$EnableFace -EnableHazard:$EnableHazard `
    -SkipTests:$SkipTests -WarningsAsErrors:$WarningsAsErrors -Clean:$Clean
& (Join-Path $PSScriptRoot 'build-release.ps1') `
    -Generator $Generator -Architecture $Architecture -Toolset $Toolset `
    -IdentifyRoot $IdentifyRoot -HazardDetectRoot $HazardDetectRoot `
    -EnableFace:$EnableFace -EnableHazard:$EnableHazard `
    -SkipTests:$SkipTests -WarningsAsErrors:$WarningsAsErrors

