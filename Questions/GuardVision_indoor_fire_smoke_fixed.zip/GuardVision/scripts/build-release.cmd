@echo off
setlocal
echo Building GuardVision Release (library only, tests skipped)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-release.ps1" -SkipTests %*
exit /b %ERRORLEVEL%
