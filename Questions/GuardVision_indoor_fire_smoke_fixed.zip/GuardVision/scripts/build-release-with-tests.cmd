@echo off
setlocal
echo Building GuardVision Release and running CTest...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-release.ps1" -SkipTests:$false %*
exit /b %ERRORLEVEL%
