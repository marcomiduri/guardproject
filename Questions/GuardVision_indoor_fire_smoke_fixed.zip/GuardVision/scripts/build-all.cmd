@echo off
setlocal
echo Building GuardVision Debug and Release (library only, tests skipped)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-all.ps1" -SkipTests %*
exit /b %ERRORLEVEL%
