
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was GuardVisionConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(GuardVision_FACE_ENABLED True)
set(GuardVision_HAZARD_ENABLED True)

# Recreate only the proprietary dependency targets required by the installed
# GuardVision build. A motion-only package has no proprietary SDK requirement.
set(GUARDVISION_PACKAGE_ROOT "${PACKAGE_PREFIX_DIR}")
include("${CMAKE_CURRENT_LIST_DIR}/GuardVisionDependencies.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/GuardVisionRuntimeDeploy.cmake")
guardvision_define_dependency_targets(${GuardVision_FACE_ENABLED} ${GuardVision_HAZARD_ENABLED})

include("${CMAKE_CURRENT_LIST_DIR}/GuardVisionTargets.cmake")
check_required_components(GuardVision)
