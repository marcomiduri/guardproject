#pragma once

namespace guardvision {

struct Size {
    int width = 0;
    int height = 0;

    bool isValid() const noexcept;
};

struct Rect {
    int x = 0;
    int y = 0;
    int width = 0;
    int height = 0;

    bool isValid() const noexcept;
    int right() const noexcept;
    int bottom() const noexcept;
};

struct NormalizedRect {
    double x = 0.0;
    double y = 0.0;
    double width = 0.0;
    double height = 0.0;

    bool isValid() const noexcept;
};

Rect clampRect(const Rect& rect, Size frameSize);
Rect normalizedRectToPixels(const NormalizedRect& rect, Size frameSize);
Rect mapRectBetweenResolutions(const Rect& rect, Size sourceSize, Size targetSize);
Rect expandRectAroundCenter(const Rect& rect, double scale, Size frameSize);
Rect mapRoiRectToFullFrame(const Rect& roi, const Rect& roiRelativeRect);
double intersectOverUnion(const Rect& a, const Rect& b) noexcept;

}  // namespace guardvision
