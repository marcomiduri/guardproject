#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

namespace guardvision {

class FrameBuffer {
public:
    static std::shared_ptr<FrameBuffer> allocate(std::size_t sizeBytes);
    static std::shared_ptr<FrameBuffer> copyFrom(const std::uint8_t* source, std::size_t sizeBytes);

    const std::uint8_t* data() const noexcept;
    std::size_t sizeBytes() const noexcept;
    bool empty() const noexcept;

private:
    explicit FrameBuffer(std::size_t sizeBytes);

    std::vector<std::uint8_t> data_;
};

}  // namespace guardvision
