#pragma once

#include <cstdint>
#include <memory>
#include <string>

#include <frame/FrameBuffer.h>
#include <geometry/Geometry.h>

namespace guardvision {

enum class PixelFormat { BGR24, RGB24, BGRA32, Gray8, NV12, I420, YV12 };

bool isSupportedPixelFormat(PixelFormat format) noexcept;
bool isPlanarPixelFormat(PixelFormat format) noexcept;
std::size_t minimumBufferSize(int width, int height, int stride, PixelFormat format);

struct VideoFrame {
    std::string streamId;
    std::uint64_t sequence = 0;
    std::int64_t timestampMs = 0;

    int width = 0;
    int height = 0;
    int stride = 0;

    PixelFormat pixelFormat = PixelFormat::BGR24;
    std::shared_ptr<const FrameBuffer> buffer;

    bool isValid() const noexcept;
    Size size() const noexcept;
};

}  // namespace guardvision
