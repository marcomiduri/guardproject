#pragma once

#include <cstdint>

namespace guardvision {

struct OnboardMetrics {
    std::uint64_t candidatesReceived = 0;
    std::uint64_t candidatesAccepted = 0;
    std::uint64_t candidatesRejected = 0;
    std::uint64_t invalidCandidates = 0;
    std::uint64_t staleGenerationCandidates = 0;
    std::uint64_t staleTimestampCandidates = 0;
    std::uint64_t candidatesWithoutMatchingFrames = 0;
    std::uint64_t candidatesExpired = 0;
    std::uint64_t coordinateConversions = 0;
    std::uint64_t mainStreamToSubstreamMappings = 0;
    std::uint64_t expandedRegions = 0;
    std::uint64_t regionalConfirmationsRequested = 0;
    std::uint64_t confirmationsPassed = 0;
    std::uint64_t confirmationsFailed = 0;
    std::uint64_t alarmsStarted = 0;
    std::uint64_t alarmsUpdated = 0;
    std::uint64_t alarmsEnded = 0;
    std::uint64_t hybridAlarms = 0;
    std::uint64_t duplicatesSuppressed = 0;
    std::uint64_t activeCorrelationEntries = 0;
    std::uint64_t capabilityQueryFailures = 0;
    std::uint64_t alarmSubscriptionFailures = 0;
    std::uint64_t processingErrors = 0;
};

}  // namespace guardvision
