#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <geometry/Geometry.h>

namespace guardvision {

enum class CandidateType { Motion, Face, Fire, Smoke };

enum class CandidateCoordinateSpace { Unknown, Normalized, ReferencePixels };

struct OnboardCandidateRegion {
    CandidateCoordinateSpace coordinateSpace = CandidateCoordinateSpace::Unknown;

    NormalizedRect normalizedBounds;
    Rect pixelBounds;

    int referenceWidth = 0;
    int referenceHeight = 0;
};

struct OnboardCandidate {
    std::string streamId;
    std::uint64_t generation = 0;

    CandidateType type = CandidateType::Motion;
    std::int64_t timestampMs = 0;

    std::vector<OnboardCandidateRegion> regions;

    double confidence = 0.0;
    std::string targetId;
};

const char* toString(CandidateType type) noexcept;
const char* toString(CandidateCoordinateSpace space) noexcept;

}  // namespace guardvision
