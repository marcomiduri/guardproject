#pragma once

namespace guardvision {

struct OnboardConfig {
    double motionExpansionFactor = 1.5;
    double faceExpansionFactor = 1.5;
    double hazardExpansionFactor = 2.0;

    int maximumTimestampDifferenceMs = 2000;
    int maximumStoredFrames = 8;
    int maximumPendingCandidates = 32;
    int maximumActiveIncidents = 64;

    int alarmUpdateIntervalMs = 500;
    int incidentTimeoutMs = 5000;

    double hybridSpatialOverlapThreshold = 0.25;
};

bool isValidOnboardConfig(const OnboardConfig& config) noexcept;

}  // namespace guardvision
