#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <geometry/Geometry.h>

namespace guardvision {

enum class AlarmType { Motion, Face, Fire, Smoke };

enum class AlarmState { Started, Updated, Ended };

enum class AlarmSource { Software, Onboard, Hybrid };

struct AlarmEvent {
    std::uint64_t alarmId = 0;

    std::string streamId;
    // GuardVision-managed stream-registration generation. This is not a
    // camera, decoder, media-source, or application generation counter.
    std::uint64_t generation = 0;

    AlarmType type = AlarmType::Motion;
    AlarmState state = AlarmState::Started;
    AlarmSource source = AlarmSource::Software;

    std::int64_t timestampMs = 0;
    double confidence = 0.0;

    std::vector<Rect> regions;

    std::string onboardTargetId;
    std::uint64_t softwareTrackId = 0;
};

const char* toString(AlarmType type) noexcept;
const char* toString(AlarmState state) noexcept;
const char* toString(AlarmSource source) noexcept;

}  // namespace guardvision
