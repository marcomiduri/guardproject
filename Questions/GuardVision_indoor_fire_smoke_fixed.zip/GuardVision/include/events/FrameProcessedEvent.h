#pragma once

#include <cstdint>
#include <string>

namespace guardvision {

struct FrameProcessedEvent {
    std::string streamId;

    // GuardVision-managed stream-registration generation. This is not a
    // camera, decoder, media-source, or application generation counter.
    std::uint64_t generation = 0;
    std::uint64_t sequence = 0;
    std::int64_t timestampMs = 0;

    std::int64_t submittedAtMs = 0;
    std::int64_t processedAtMs = 0;
    std::int64_t queueDelayMs = 0;
};

}  // namespace guardvision
