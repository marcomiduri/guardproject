#pragma once

#include <events/AlarmEvent.h>
#include <core/Error.h>
#include <face/FaceEvent.h>
#include <events/FrameProcessedEvent.h>
#include <hazard/HazardEvent.h>
#include <motion/MotionEvent.h>
#include <core/StreamStatus.h>
namespace guardvision {

class IGuardVisionEventListener {
public:
    virtual ~IGuardVisionEventListener() = default;

    virtual void onStreamStatus(const StreamStatus& /*status*/) {}
    virtual void onFrameProcessed(const FrameProcessedEvent& /*event*/) {}
    virtual void onMotion(const MotionEvent& /*event*/) {}
    virtual void onFace(const FaceEvent& /*event*/) {}
    virtual void onHazard(const HazardEvent& /*event*/) {}
    virtual void onAlarm(const AlarmEvent& /*event*/) {}
    virtual void onError(const GuardVisionError& /*error*/) {}
};

}  // namespace guardvision
