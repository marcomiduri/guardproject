#pragma once

#include <core/Error.h>

namespace guardvision {

struct Result {
    bool ok = false;
    GuardVisionError error;

    static Result success();
    static Result failure(GuardVisionErrorCode code, const std::string& message, const std::string& component = std::string(),
                          const std::string& streamId = std::string());
};

}  // namespace guardvision
