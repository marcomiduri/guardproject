#pragma once

#include <string>

#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>

namespace guardvision {

struct StreamConfig {
    std::string streamId;
    std::string displayName;
    MotionConfig motion;
    FaceConfig face;
    HazardConfig hazard;
};

constexpr std::size_t kMaxStreamIdLength = 128;

bool isValidStreamId(const std::string& streamId) noexcept;

}  // namespace guardvision
