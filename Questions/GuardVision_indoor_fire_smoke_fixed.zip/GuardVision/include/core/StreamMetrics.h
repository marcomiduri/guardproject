#pragma once

#include <cstdint>
#include <string>

namespace guardvision {

struct StreamMetrics {
    std::string streamId;

    std::uint64_t submittedFrames = 0;
    std::uint64_t acceptedFrames = 0;
    std::uint64_t rejectedFrames = 0;
    std::uint64_t replacedFrames = 0;
    std::uint64_t processedFrames = 0;
    std::uint64_t staleJobsDiscarded = 0;

    std::uint64_t queueOverflowCount = 0;

    std::int64_t lastQueueDelayMs = 0;
    std::int64_t maximumQueueDelayMs = 0;

    bool hasPendingFrame = false;
    bool processingFrame = false;
};

struct RuntimeMetrics {
    std::uint64_t activeStreams = 0;

    std::uint64_t submittedFrames = 0;
    std::uint64_t acceptedFrames = 0;
    std::uint64_t rejectedFrames = 0;
    std::uint64_t replacedFrames = 0;
    std::uint64_t processedFrames = 0;

    std::uint64_t staleJobsDiscarded = 0;
    std::uint64_t queueOverflowCount = 0;
    std::uint64_t dispatchedEvents = 0;
    std::uint64_t droppedEvents = 0;
};

}  // namespace guardvision
