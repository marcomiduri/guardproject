#pragma once

namespace guardvision {

enum class StreamState { Registered, Active, Stopping, Stopped, Error };

const char* toString(StreamState state) noexcept;

}  // namespace guardvision
