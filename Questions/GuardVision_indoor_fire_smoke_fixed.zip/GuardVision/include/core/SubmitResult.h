#pragma once

#include <core/Error.h>

namespace guardvision {

enum class SubmitStatus {
    Accepted,
    ReplacedOlderPendingFrame,
    StreamNotRegistered,
    InvalidFrame,
    InvalidSequence,
    InvalidTimestamp,
    StreamStopping,
    NotInitialized,
    QueueUnavailable,
    InternalError
};

struct SubmitResult {
    SubmitStatus status = SubmitStatus::InternalError;
    bool accepted = false;
    GuardVisionError error;
};

const char* toString(SubmitStatus status) noexcept;

}  // namespace guardvision
