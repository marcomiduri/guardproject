#pragma once

#include <string>

namespace guardvision {

struct GuardVisionConfig {
    int maxStreams = 16;
    int frameWorkerCount = 1;
    int motionWorkerCount = 1;
    int faceWorkerCount = 2;
    int hazardWorkerCount = 2;
    int eventQueueCapacity = 1024;
    int readyStreamQueueCapacity = 256;
    std::string identifyResourcePath;
    std::string hazardResourcePath;
};

constexpr int kGuardVisionMaxStreamsUpperBound = 64;
constexpr int kGuardVisionMaxFrameWorkers = 8;
constexpr int kGuardVisionMaxMotionWorkers = 8;
constexpr int kGuardVisionMaxFaceWorkers = 4;
constexpr int kGuardVisionMaxHazardWorkers = 4;
constexpr int kGuardVisionMinEventQueueCapacity = 64;
constexpr int kGuardVisionMaxEventQueueCapacity = 8192;
constexpr int kGuardVisionMinReadyStreamQueueCapacity = 16;
constexpr int kGuardVisionMaxReadyStreamQueueCapacity = 4096;

bool isValidGuardVisionConfig(const GuardVisionConfig& config) noexcept;

}  // namespace guardvision
