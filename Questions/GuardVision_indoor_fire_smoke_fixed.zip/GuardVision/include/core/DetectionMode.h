#pragma once

namespace guardvision {

enum class DetectionMode { Disabled, Software, OnboardTriggered, Hybrid };

bool runsContinuousSoftware(DetectionMode mode) noexcept;
bool acceptsOnboardCandidates(DetectionMode mode) noexcept;
const char* toString(DetectionMode mode) noexcept;

}  // namespace guardvision
