#pragma once

namespace guardvision {

// Graceful releases all GuardVision and vendor resources. ProcessExit stops
// every GuardVision-owned thread and callback but intentionally leaves the
// process-global vendor engines/sessions for the operating system to reclaim.
// ProcessExit is terminal and must only be used immediately before process exit.
enum class ShutdownMode { Graceful, ProcessExit };

}  // namespace guardvision
