#pragma once

#include <string>

namespace guardvision {

enum class GuardVisionErrorCode {
    None,
    InvalidConfiguration,
    AlreadyInitialized,
    NotInitialized,
    StreamAlreadyExists,
    StreamNotFound,
    MaximumStreamCountReached,
    InvalidStreamConfiguration,
    InvalidFrame,
    UnsupportedPixelFormat,
    InvalidFrameSequence,
    InvalidFrameTimestamp,
    InvalidMotionConfiguration,
    MotionProcessingFailed,
    UnsupportedMotionPixelFormat,
    MotionQueueUnavailable,
    InvalidFaceConfiguration,
    UnsupportedFaceTriggerMode,
    FaceModelMissing,
    FaceEngineInitializationFailed,
    FaceSessionCreationFailed,
    FaceProcessingFailed,
    UnsupportedFacePixelFormat,
    FaceFeatureExtractionFailed,
    FaceIdentitySearchFailed,
    FaceQueueUnavailable,
    InvalidHazardConfiguration,
    HazardModelMissing,
    HazardEngineInitializationFailed,
    HazardSessionCreationFailed,
    HazardProcessingFailed,
    UnsupportedHazardPixelFormat,
    HazardQueueUnavailable,
    InvalidCandidate,
    UnsupportedCandidateType,
    UnknownCandidateCoordinateSpace,
    InvalidNormalizedCandidateRect,
    InvalidPixelCandidateRect,
    MissingCandidateReferenceResolution,
    IncompatibleCandidateGeometry,
    StaleCandidateGeneration,
    FrameCorrelationFailure,
    InvalidExpansionFactor,
    ConfirmationFailure,
    AlarmSubscriptionFailure,
    CapabilityQueryFailure,
    InternalError
};

struct GuardVisionError {
    GuardVisionErrorCode code = GuardVisionErrorCode::None;
    std::string streamId;
    std::string component;
    std::string message;
    bool recoverable = false;
    int vendorErrorCode = 0;
};

const char* toString(GuardVisionErrorCode code) noexcept;

}  // namespace guardvision
