#pragma once

#include <cstdint>
#include <string>

#include <core/StreamState.h>

namespace guardvision {

struct StreamStatus {
    std::string streamId;
    StreamState state = StreamState::Registered;

    bool acceptingFrames = false;
    bool hasPendingFrame = false;
    bool processingFrame = false;

    // GuardVision-managed stream-registration generation. This is not a
    // camera, decoder, media-source, or application generation counter.
    std::uint64_t generation = 0;

    std::uint64_t lastAcceptedSequence = 0;
    std::int64_t lastAcceptedTimestampMs = 0;
};

}  // namespace guardvision
