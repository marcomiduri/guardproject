#pragma once

#include <core/DetectionMode.h>
#include <face/FaceTypes.h>
#include <geometry/Geometry.h>

namespace guardvision {

struct FaceConfig {
    FaceProcessingLevel processingLevel = FaceProcessingLevel::Disabled;
    FaceTriggerMode triggerMode = FaceTriggerMode::ContinuousSoftware;
    DetectionMode detectionMode = DetectionMode::Software;

    int analysisIntervalMs = 100;

    int minimumFaceWidth = 32;
    int minimumFaceHeight = 32;

    double minimumDetectionConfidence = 0.5;
    double minimumQualityScore = 0.3;
    double minimumIdentificationConfidence = 0.48;

    int maximumFaceCount = 8;

    int lostTrackTimeoutMs = 1000;
    int identificationRetryIntervalMs = 2000;
    int identityRefreshIntervalMs = 10000;
    int eventUpdateIntervalMs = 500;

    bool useRoi = false;
    NormalizedRect roi;
};

bool isValidFaceConfig(const FaceConfig& config) noexcept;
bool isSupportedFaceTriggerMode(FaceTriggerMode mode) noexcept;

}  // namespace guardvision
