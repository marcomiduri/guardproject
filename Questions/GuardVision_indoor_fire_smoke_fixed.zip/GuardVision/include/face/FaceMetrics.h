#pragma once

#include <cstdint>
#include <string>

#include <face/FaceTypes.h>

namespace guardvision {

struct FaceMetrics {
    std::string streamId;

    bool enabled = false;
    FaceProcessingLevel processingLevel = FaceProcessingLevel::Disabled;

    std::uint64_t receivedFrames = 0;
    std::uint64_t scheduledFrames = 0;
    std::uint64_t analyzedFrames = 0;
    std::uint64_t skippedByInterval = 0;
    std::uint64_t replacedPendingFrames = 0;
    std::uint64_t staleWorkDiscarded = 0;

    std::uint64_t detectedFaces = 0;
    std::uint64_t filteredFaces = 0;
    std::uint64_t appearedTracks = 0;
    std::uint64_t lostTracks = 0;

    std::uint64_t identificationAttempts = 0;
    std::uint64_t identificationMatches = 0;
    std::uint64_t identificationMisses = 0;
    std::uint64_t cachedIdentityUses = 0;

    std::uint64_t droppedUpdateEvents = 0;
    std::uint64_t processingErrors = 0;

    std::int64_t lastProcessingTimeUs = 0;
    std::int64_t maximumProcessingTimeUs = 0;

    int activeTrackCount = 0;
    int assignedWorkerIndex = -1;
};

}  // namespace guardvision
