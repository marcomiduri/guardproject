#pragma once

#include <cstdint>
#include <string>

#include <geometry/Geometry.h>

namespace guardvision {

enum class FaceProcessingLevel { Disabled, DetectAndTrack, DetectTrackAndIdentify };

enum class FaceTriggerMode { ContinuousSoftware, OnboardTriggered, Hybrid };

enum class FaceTrackState { Appeared, Tracking, Lost };

enum class FaceEventType { TracksUpdated, TrackAppeared, TrackLost, IdentityMatched, IdentityChanged };

struct FaceIdentityMatch {
    bool identified = false;
    std::uint64_t identityId = 0;
    std::string displayName;
    double confidence = 0.0;
};

struct FaceTrack {
    std::uint64_t trackId = 0;
    Rect bounds;
    double detectionConfidence = 0.0;
    double qualityScore = 0.0;
    FaceTrackState state = FaceTrackState::Tracking;
    FaceIdentityMatch identity;
};

const char* toString(FaceProcessingLevel level) noexcept;
const char* toString(FaceTriggerMode mode) noexcept;
const char* toString(FaceTrackState state) noexcept;
const char* toString(FaceEventType type) noexcept;

}  // namespace guardvision
