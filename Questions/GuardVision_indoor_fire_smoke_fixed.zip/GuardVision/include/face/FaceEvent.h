#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <face/FaceTypes.h>

namespace guardvision {

struct FaceEvent {
    FaceEventType type = FaceEventType::TracksUpdated;

    std::string streamId;
    // GuardVision-managed stream-registration generation. This is not a
    // camera, decoder, media-source, or application generation counter.
    std::uint64_t generation = 0;
    std::uint64_t sequence = 0;
    std::int64_t timestampMs = 0;

    std::vector<FaceTrack> tracks;
};

}  // namespace guardvision
