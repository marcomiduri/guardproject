#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace guardvision {

struct FaceRegistryEntry {
    std::uint64_t identityId = 0;
    std::string displayName;
    std::vector<float> feature;
};

struct FaceRegistry {
    float threshold = 0.48f;
    std::string model;
    std::vector<FaceRegistryEntry> entries;
};

bool isValidFaceRegistry(const FaceRegistry& registry) noexcept;

}  // namespace guardvision
