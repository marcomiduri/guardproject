#pragma once

#include <cstddef>
#include <memory>
#include <string>

#include <core/DetectionMode.h>
#include <core/GuardVisionConfig.h>
#include <core/Result.h>
#include <core/StreamConfig.h>
#include <core/StreamMetrics.h>
#include <core/ShutdownMode.h>
#include <core/StreamStatus.h>
#include <core/SubmitResult.h>
#include <events/EventListener.h>
#include <face/FaceConfig.h>
#include <face/FaceMetrics.h>
#include <face/FaceRegistry.h>
#include <frame/VideoFrame.h>
#include <hazard/HazardConfig.h>
#include <hazard/HazardMetrics.h>
#include <motion/MotionConfig.h>
#include <motion/MotionMetrics.h>
#include <onboard/OnboardConfig.h>
#include <onboard/OnboardMetrics.h>
#include <onboard/OnboardTypes.h>

namespace guardvision {

class GuardVision {
public:
    GuardVision();
    ~GuardVision();

    GuardVision(const GuardVision&) = delete;
    GuardVision& operator=(const GuardVision&) = delete;

    GuardVision(GuardVision&&) noexcept;
    GuardVision& operator=(GuardVision&&) noexcept;

    static const char* version() noexcept;

    Result initialize(const GuardVisionConfig& config);
    void shutdown(ShutdownMode mode = ShutdownMode::Graceful);
    bool isInitialized() const noexcept;

    Result registerStream(const StreamConfig& config);
    Result unregisterStream(const std::string& streamId);
    Result setMotionConfig(const std::string& streamId, const MotionConfig& config);
    Result getMotionConfig(const std::string& streamId, MotionConfig& output) const;
    Result setFaceConfig(const std::string& streamId, const FaceConfig& config);
    Result getFaceConfig(const std::string& streamId, FaceConfig& output) const;
    Result setFaceRegistry(const FaceRegistry& registry);
    Result setHazardConfig(const std::string& streamId, const HazardConfig& config);
    Result getHazardConfig(const std::string& streamId, HazardConfig& output) const;

    SubmitResult submitFrame(VideoFrame frame);
    Result submitOnboardCandidate(const OnboardCandidate& candidate);

    Result getOnboardConfig(OnboardConfig& output) const;
    Result setOnboardConfig(const OnboardConfig& config);

    Result getStreamStatus(const std::string& streamId, StreamStatus& output) const;
    Result getStreamMetrics(const std::string& streamId, StreamMetrics& output) const;
    Result getMotionMetrics(const std::string& streamId, MotionMetrics& output) const;
    Result getFaceMetrics(const std::string& streamId, FaceMetrics& output) const;
    Result getHazardMetrics(const std::string& streamId, HazardMetrics& output) const;
    Result getOnboardMetrics(const std::string& streamId, OnboardMetrics& output) const;
    RuntimeMetrics getRuntimeMetrics() const;

    // The raw-pointer overload is non-owning. The listener must outlive the
    // registration and must be detached before it is destroyed.
    void setEventListener(IGuardVisionEventListener* listener);
    void setEventListener(std::shared_ptr<IGuardVisionEventListener> listener);
    void setEventListener(std::nullptr_t);
    void clearEventListener();

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace guardvision
