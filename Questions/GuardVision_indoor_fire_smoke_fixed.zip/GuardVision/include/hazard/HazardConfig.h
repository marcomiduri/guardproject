#pragma once

#include <core/DetectionMode.h>
#include <geometry/Geometry.h>
#include <hazard/HazardTypes.h>

namespace guardvision {

struct HazardConfig {
    HazardProcessingLevel processingLevel = HazardProcessingLevel::Disabled;
    DetectionMode detectionMode = DetectionMode::Software;

    int analysisIntervalMs = 250;

    bool fireEnabled = true;
    bool smokeEnabled = true;

    // Common detection threshold. The active vendor engine may also use this as
    // its candidate floor. Per-type thresholds below are applied again after
    // inference; a negative per-type value means "use minimumConfidence".
    double minimumConfidence = 0.4;
    double fireMinimumConfidence = -1.0;
    double smokeMinimumConfidence = -1.0;
    int minimumRegionWidth = 16;
    int minimumRegionHeight = 16;
    int maximumRegionCount = 8;

    // Legacy/common activation count. A per-type value of 0 means use this value.
    int activationFrameCount = 2;
    int fireActivationFrameCount = 0;
    int smokeActivationFrameCount = 0;
    int clearFrameCount = 3;
    int updateEventIntervalMs = 500;

    // If the full-frame pass misses smoke, inspect overlapping quadrants. This
    // increases the apparent size of early/small smoke without changing the model.
    bool smallHazardTilingEnabled = false;

    bool useRoi = false;
    NormalizedRect roi;
};

bool isValidHazardConfig(const HazardConfig& config) noexcept;

}  // namespace guardvision
