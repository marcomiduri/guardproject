#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <geometry/Geometry.h>
#include <hazard/HazardTypes.h>

namespace guardvision {

struct HazardRegion {
    HazardType type = HazardType::Fire;
    Rect bounds;
    double confidence = 0.0;
};

struct HazardEvent {
    HazardEventType type = HazardEventType::Started;
    std::string streamId;
    // GuardVision-managed stream-registration generation. This is not a
    // camera, decoder, media-source, or application generation counter.
    std::uint64_t generation = 0;
    std::uint64_t sequence = 0;
    std::int64_t timestampMs = 0;
    std::vector<HazardRegion> regions;
};

}  // namespace guardvision
