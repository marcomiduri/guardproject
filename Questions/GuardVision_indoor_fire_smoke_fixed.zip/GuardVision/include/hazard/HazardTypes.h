#pragma once

#include <cstdint>

namespace guardvision {

enum class HazardType { Fire, Smoke };

enum class HazardProcessingLevel { Disabled, Detect };

enum class HazardEventType { Started, Updated, Ended };

const char* toString(HazardType type) noexcept;
const char* toString(HazardProcessingLevel level) noexcept;
const char* toString(HazardEventType type) noexcept;

}  // namespace guardvision
