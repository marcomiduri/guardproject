#pragma once

#include <cstdint>
#include <string>

#include <hazard/HazardTypes.h>

namespace guardvision {

struct HazardMetrics {
    std::string streamId;

    bool enabled = false;
    HazardProcessingLevel processingLevel = HazardProcessingLevel::Disabled;

    std::uint64_t receivedFrames = 0;
    std::uint64_t scheduledFrames = 0;
    std::uint64_t analyzedFrames = 0;
    std::uint64_t skippedByInterval = 0;
    std::uint64_t replacedPendingFrames = 0;
    std::uint64_t staleWorkDiscarded = 0;

    std::uint64_t fireDetections = 0;
    std::uint64_t smokeDetections = 0;
    std::uint64_t filteredRegions = 0;

    std::uint64_t startedEvents = 0;
    std::uint64_t updatedEvents = 0;
    std::uint64_t endedEvents = 0;
    std::uint64_t droppedUpdateEvents = 0;
    std::uint64_t processingErrors = 0;

    std::int64_t lastProcessingTimeUs = 0;
    std::int64_t maximumProcessingTimeUs = 0;

    bool activeFireState = false;
    bool activeSmokeState = false;
    int assignedWorkerIndex = -1;
};

}  // namespace guardvision
