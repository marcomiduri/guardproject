#pragma once

#include <cstdint>
#include <string>

#include <motion/MotionTypes.h>

namespace guardvision {

struct MotionMetrics {
    std::string streamId;

    bool enabled = false;
    MotionState state = MotionState::Idle;

    std::uint64_t receivedFrames = 0;
    std::uint64_t analyzedFrames = 0;
    std::uint64_t skippedByInterval = 0;
    std::uint64_t baselineFrames = 0;

    std::uint64_t startedEvents = 0;
    std::uint64_t updatedEvents = 0;
    std::uint64_t endedEvents = 0;

    std::uint64_t extractedRegions = 0;
    std::uint64_t truncatedRegions = 0;

    std::uint64_t staleWorkDiscarded = 0;
    std::uint64_t processingErrors = 0;

    std::int64_t lastProcessingTimeUs = 0;
    std::int64_t maximumProcessingTimeUs = 0;

    double lastChangedAreaRatio = 0.0;

    int analysisWidth = 0;
    int analysisHeight = 0;
};

}  // namespace guardvision
