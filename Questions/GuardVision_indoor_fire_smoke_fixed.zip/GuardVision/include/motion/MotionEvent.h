#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <geometry/Geometry.h>
#include <motion/MotionTypes.h>

namespace guardvision {

struct MotionEvent {
    MotionEventType type = MotionEventType::Updated;

    std::string streamId;

    // GuardVision-managed stream-registration generation. This is not a
    // camera, decoder, media-source, or application generation counter.
    std::uint64_t generation = 0;
    std::uint64_t sequence = 0;
    std::int64_t timestampMs = 0;

    MotionState state = MotionState::Idle;

    double score = 0.0;
    double changedAreaRatio = 0.0;

    Rect analysisArea;

    std::vector<MotionRegion> regions;
};

}  // namespace guardvision
