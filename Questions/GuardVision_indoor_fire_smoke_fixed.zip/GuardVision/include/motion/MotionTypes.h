#pragma once

#include <geometry/Geometry.h>

namespace guardvision {

enum class MotionState { Idle, Candidate, Active, Clearing };

enum class MotionEventType { Started, Updated, Ended };

struct MotionRegion {
    Rect bounds;
    double score = 0.0;
    double changedAreaRatio = 0.0;
};

const char* toString(MotionState state) noexcept;
const char* toString(MotionEventType type) noexcept;

}  // namespace guardvision
