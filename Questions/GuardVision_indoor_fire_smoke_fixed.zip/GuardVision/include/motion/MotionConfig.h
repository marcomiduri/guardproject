#pragma once

#include <core/DetectionMode.h>
#include <geometry/Geometry.h>

namespace guardvision {

struct MotionConfig {
    bool enabled = false;
    DetectionMode detectionMode = DetectionMode::Software;

    int analysisIntervalMs = 100;

    int maximumAnalysisWidth = 320;
    int maximumAnalysisHeight = 180;

    int pixelDifferenceThreshold = 24;

    double startChangedAreaRatio = 0.02;
    double continueChangedAreaRatio = 0.01;

    int activationFrameCount = 2;
    int clearFrameCount = 3;

    int minimumRegionWidth = 12;
    int minimumRegionHeight = 12;
    int minimumRegionArea = 144;

    int maximumRegionCount = 16;

    int eventUpdateIntervalMs = 500;

    int baselineResetGapMs = 5000;

    bool useRoi = false;
    NormalizedRect roi;
};

bool isValidMotionConfig(const MotionConfig& config) noexcept;

}  // namespace guardvision
