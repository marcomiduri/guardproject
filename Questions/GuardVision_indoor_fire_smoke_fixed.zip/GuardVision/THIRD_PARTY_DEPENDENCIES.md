# Third-Party Dependencies

GuardVision is designed for offline builds and does not fetch packages from the network.

## Optional feature matrix

| Build mode | Identify SDK | HazardDetect SDK |
|---|---:|---:|
| Motion only | Not required | Not required |
| Motion + face | Required | Not required |
| Motion + hazard | Not required | Required |
| Full analytics | Required | Required |

```text
GUARDVISION_ENABLE_FACE=ON|OFF
GUARDVISION_ENABLE_HAZARD=ON|OFF
```

A requested enabled dependency is mandatory. CMake never silently disables a requested feature.

## Identify SDK

Default root: `../sdk/Identify/`

Expected header: `../sdk/Identify/include/identify.h`

Supported library layouts include:

```text
../sdk/Identify/debug/Identify.lib
../sdk/Identify/release/Identify.lib
../sdk/Identify/lib/Debug/Identify.lib
../sdk/Identify/lib/Release/Identify.lib
../sdk/Identify/lib/Identify.lib
../sdk/Identify/lib/x64/Identify.lib
```

Equivalent lowercase names and Linux archive/shared-library names are searched.

CMake overrides:

```text
GUARDVISION_IDENTIFY_ROOT
GUARDVISION_IDENTIFY_INCLUDE_DIR
GUARDVISION_IDENTIFY_LIBRARY
GUARDVISION_IDENTIFY_LIBRARY_DEBUG
GUARDVISION_IDENTIFY_LIBRARY_RELEASE
```

Model lookup order:

1. `GuardVisionConfig::identifyResourcePath`
2. `GUARDVISION_IDENTIFY_RESOURCE_DIR`
3. executable/current-working-directory relative `models`, `assets/Pikachu`, or `Pikachu`
4. SDK-relative `../sdk/Identify/models`

## HazardDetect SDK

Default root: `../sdk/HazardDetect/`

Expected header: `../sdk/HazardDetect/include/hazard_detect.h`

Supported library layouts include:

```text
../sdk/HazardDetect/lib-debug/HazardDetect.lib
../sdk/HazardDetect/debug/HazardDetect.lib
../sdk/HazardDetect/release/HazardDetect.lib
../sdk/HazardDetect/lib/Debug/HazardDetect.lib
../sdk/HazardDetect/lib/Release/HazardDetect.lib
../sdk/HazardDetect/lib/HazardDetect.lib
```

CMake overrides:

```text
GUARDVISION_HAZARDDETECT_ROOT
GUARDVISION_HAZARDDETECT_INCLUDE_DIR
GUARDVISION_HAZARDDETECT_LIBRARY
GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG
GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE
```

Model lookup order:

1. `GuardVisionConfig::hazardResourcePath`
2. `GUARDVISION_HAZARD_MODEL_DIR`
3. `HAZARD_DETECT_MODEL`
4. executable/current-working-directory relative `models/fire_smoke.onnx`
5. SDK-relative `../sdk/HazardDetect/models/fire_smoke.onnx`

## Runtime DLL deployment

```text
GUARDVISION_IDENTIFY_RUNTIME_DIR
GUARDVISION_IDENTIFY_RUNTIME_DIR_DEBUG
GUARDVISION_IDENTIFY_RUNTIME_DIR_RELEASE
GUARDVISION_HAZARDDETECT_RUNTIME_DIR
GUARDVISION_HAZARDDETECT_RUNTIME_DIR_DEBUG
GUARDVISION_HAZARDDETECT_RUNTIME_DIR_RELEASE
```

```cmake
guardvision_deploy_runtime(my_executable)
```

The helper deploys only runtimes enabled in the GuardVision package. It copies beside the executable, never into the source tree.

## Debug and Release compatibility

Use proprietary binaries built for the same architecture, compiler ABI/toolset, C/C++ runtime mode, and configuration. Installed GuardVision archives are separated into `lib/Debug` and `lib/Release`, and imported dependency targets select configuration-specific SDK libraries when provided.

## Verification terminology

- **SDK-compatible test library build**: validates headers, symbols, CMake linking, and GuardVision code paths; it is not real inference certification.
- **Real SDK link build**: validates the actual import/static libraries for one toolchain; it still does not prove models or runtime DLL loading.
- **Runtime inference verification**: requires actual DLLs, models, licenses, and representative frames on the target machine.
