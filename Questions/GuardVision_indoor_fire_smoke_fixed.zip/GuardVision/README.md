# GuardVision Source Package

GuardVision is a Qt-independent C++17 static analytics library. The host application owns camera transport, decoding, preview, backend communication, notifications, and recording. It submits decoded `VideoFrame` objects to GuardVision.

```text
namespace: guardvision
target:    GuardVision::guardvision
library:   guardvision.lib (MSVC) / libguardvision.a (GCC/Clang)
```

## Runtime path

```text
GuardVision facade
  -> GuardVision::Impl
  -> StreamManager
  -> FrameScheduler (lightweight routing)
       -> MotionScheduler -> MotionProcessor
       -> FaceScheduler
       -> HazardScheduler
       -> OnboardProcessor / AlarmCorrelator
  -> EventDispatcher
  -> IGuardVisionEventListener
```

Motion analysis now has its own latest-frame-wins worker path, so expensive motion settings do not block face/hazard submission or ordinary frame-routing completion.

## Package contents

- `include/`: public API only
- `src/`: private implementation
- `tests/`: unit, integration, concurrency, and regression tests
- `cmake/`: dependency discovery, compiler options, install package, and runtime deployment helpers
- `scripts/`: standalone Windows build scripts
- `examples/basic-frame-submit/`: minimal host integration example
- `docs/`: architecture, ownership, threading, and update notes
- `../sdk/`: shared location of licensed SDKs used by projects under `Desktop/`
- `../assets/`: shared optional model and test-asset locations
- `bin/`: optional Debug/Release source-tree outputs

## Offline build modes

GuardVision never downloads dependencies.

### Motion-only build — no proprietary SDK required

```powershell
cmake -S . -B _build\motion `
  -G "Visual Studio 16 2019" -A x64 `
  -DGUARDVISION_ENABLE_FACE=OFF `
  -DGUARDVISION_ENABLE_HAZARD=OFF `
  -DGUARDVISION_BUILD_TESTS=ON `
  -DGUARDVISION_WARNINGS_AS_ERRORS=ON

cmake --build _build\motion --config Release --parallel
ctest --test-dir _build\motion -C Release --output-on-failure
```

Equivalent PowerShell helper:

```powershell
.\scripts\build-release.ps1 `
  -EnableFace:$false `
  -EnableHazard:$false `
  -WarningsAsErrors
```

### Full face + hazard build

An offline machine needs:

- CMake 3.15 or newer
- a C++17 compiler
- licensed Identify SDK headers/import libraries/runtime DLLs and model pack
- licensed HazardDetect SDK headers/import libraries/runtime DLLs and model

```powershell
.\scripts\build-release.ps1 `
  -IdentifyRoot D:\SDK\Identify `
  -HazardDetectRoot D:\SDK\HazardDetect `
  -WarningsAsErrors
```

Qt is not required to build GuardVision. Qt 5.7, 5.12, and 5.14 compatibility belongs to the consuming Guard/TestLib application and its selected MSVC ABI.

See [`THIRD_PARTY_DEPENDENCIES.md`](THIRD_PARTY_DEPENDENCIES.md) for accepted SDK layouts and CMake variables.

## Feature switches

```text
-DGUARDVISION_ENABLE_FACE=ON|OFF
-DGUARDVISION_ENABLE_HAZARD=ON|OFF
-DGUARDVISION_BUILD_TESTS=ON|OFF
-DGUARDVISION_BUILD_EXAMPLES=ON|OFF
-DGUARDVISION_WARNINGS_AS_ERRORS=ON|OFF
-DGUARDVISION_ENABLE_ASAN=ON|OFF
-DGUARDVISION_ENABLE_UBSAN=ON|OFF
-DGUARDVISION_PUBLISH_TO_SOURCE_BIN=ON|OFF
```

When a feature is disabled, its SDK is not searched or linked. Public configuration/result types remain available, but enabling that analytic at runtime returns a structured `FaceEngineInitializationFailed` or `HazardEngineInitializationFailed` error.

## Worker configuration

`GuardVisionConfig` exposes separate worker counts:

```cpp
GuardVisionConfig config;
config.frameWorkerCount = 1;   // lightweight routing
config.motionWorkerCount = 1;  // software motion analysis
config.faceWorkerCount = 2;
config.hazardWorkerCount = 2;
```

## Listener ownership

The legacy raw-pointer API is non-owning:

```cpp
guardVision.setEventListener(&listener);
// listener must remain alive until detached
guardVision.clearEventListener();
```

For automatic callback-lifetime protection, use the owning overload:

```cpp
auto listener = std::make_shared<MyListener>();
guardVision.setEventListener(listener);
```

A callback lease retains the shared listener while a callback is in progress. `setEventListener(nullptr)` remains supported and is equivalent to `clearEventListener()`.

## Process-wide model constraint

Identify and HazardDetect runtimes are process-wide. Multiple `GuardVision` instances may share the same initialized model pack, and shutdown occurs only after the last runtime user exits. A later instance that explicitly requests a different model/resource path is rejected rather than silently using the first instance's model. HazardDetect also rejects a conflicting global initialization confidence threshold.

## Install and consume

```powershell
cmake --install _build\release --config Release --prefix D:\GuardVisionSDK
```

Configuration-specific artifacts are kept separate:

```text
D:\GuardVisionSDK\lib\Debug\guardvision.lib
D:\GuardVisionSDK\lib\Release\guardvision.lib
D:\GuardVisionSDK\lib\cmake\GuardVision\...
```

Consumer project:

```cmake
find_package(GuardVision CONFIG REQUIRED)
add_executable(my_app main.cpp)
target_link_libraries(my_app PRIVATE GuardVision::guardvision)

guardvision_deploy_runtime(my_app) # copies only enabled SDK runtimes
```

A motion-only installed package can be consumed without any SDK variables. A feature-enabled package requires the corresponding offline SDK root when it is outside the package prefix.

## Verification boundary

This distributable source package excludes licensed SDK contents.

Verified in the current revision:

- motion-only configure/build/tests with both SDK roots absent: passed
- feature-enabled GCC 14 warnings-as-errors build using local SDK-compatible test libraries: passed
- CTest: passed
- configuration-specific install path: passed
- motion-only relocated installed-package consumer build: passed

The feature-enabled local link test proves build wiring only. Actual vendor SDK binaries, Windows/MSVC ABI compatibility, model loading, runtime DLL deployment, and real inference must be verified on the licensed offline target machine.

See [`docs/source-update-report.md`](docs/source-update-report.md) for the complete revision summary.

## Indoor fire/smoke tuning

This revision adds per-class fire/smoke confidence and activation settings, smoke-first event handling, corrected source-coordinate mapping for resized inference frames, and optional overlapping tile recovery for small early hazards. See [`docs/IndoorFireSmokeDetectionUpdate.md`](docs/IndoorFireSmokeDetectionUpdate.md).

