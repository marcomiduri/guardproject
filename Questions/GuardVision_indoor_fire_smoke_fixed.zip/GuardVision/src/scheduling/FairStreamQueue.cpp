#include "scheduling/FairStreamQueue.h"

namespace guardvision {

FairStreamQueue::FairStreamQueue(std::size_t capacity) : capacity_(capacity) {}

bool FairStreamQueue::tryEnqueue(const StreamToken& token) {
    if (queued_.count(token) > 0) {
        return true;
    }
    if (queue_.size() >= capacity_) {
        return false;
    }
    queue_.push_back(token);
    queued_.insert(token);
    return true;
}

bool FairStreamQueue::dequeue(StreamToken& output) {
    if (queue_.empty()) {
        return false;
    }
    output = queue_.front();
    queue_.pop_front();
    queued_.erase(output);
    return true;
}

void FairStreamQueue::remove(const StreamToken& token) {
    queued_.erase(token);
    for (auto it = queue_.begin(); it != queue_.end(); ++it) {
        if (*it == token) {
            queue_.erase(it);
            return;
        }
    }
}

void FairStreamQueue::clear() {
    queue_.clear();
    queued_.clear();
}

bool FairStreamQueue::empty() const {
    return queue_.empty();
}

std::size_t FairStreamQueue::size() const {
    return queue_.size();
}

}  // namespace guardvision
