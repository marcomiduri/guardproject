#pragma once

#include <cstddef>

namespace guardvision {
namespace scheduling {

inline constexpr std::size_t kMaxPendingRegionalConfirmationsPerStream = 32;

inline bool isValidWorkerIndex(int workerIndex, int workerCount) noexcept {
    return workerIndex >= 0 && workerIndex < workerCount;
}

}  // namespace scheduling
}  // namespace guardvision
