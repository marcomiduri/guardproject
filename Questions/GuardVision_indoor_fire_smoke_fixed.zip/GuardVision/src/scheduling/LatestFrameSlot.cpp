#include "scheduling/LatestFrameSlot.h"

namespace guardvision {

ReplaceResult LatestFrameSlot::replace(FrameRoutingJob job) {
    const bool replacedPending = job_.has_value();
    job_ = std::move(job);
    return replacedPending ? ReplaceResult::ReplacedPending : ReplaceResult::Inserted;
}

std::optional<FrameRoutingJob> LatestFrameSlot::take() {
    if (!job_.has_value()) {
        return std::nullopt;
    }
    FrameRoutingJob taken = std::move(*job_);
    job_.reset();
    return taken;
}

void LatestFrameSlot::clear() {
    job_.reset();
}

bool LatestFrameSlot::hasPending() const {
    return job_.has_value();
}

}  // namespace guardvision
