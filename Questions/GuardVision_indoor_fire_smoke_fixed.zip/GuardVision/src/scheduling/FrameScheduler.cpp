#include "scheduling/FrameScheduler.h"

#include <utility>

namespace guardvision {

FrameScheduler::FrameScheduler(std::size_t readyQueueCapacity, ProcessCallback callback)
: processCallback_(std::move(callback)), readyQueue_(readyQueueCapacity) {}

SchedulerSubmitResult FrameScheduler::submit(FrameRoutingJob job) {
    SchedulerSubmitResult result;
    std::lock_guard<std::mutex> lock(mutex_);
    const StreamToken token = job.token;
    auto it = slots_.find(token.streamId);
    if (it == slots_.end() || it->second.token.generation != token.generation || stopping_) {
        return result;
    }

    const ReplaceResult replaceResult = it->second.slot.replace(std::move(job));
    result.replacedPending = replaceResult == ReplaceResult::ReplacedPending;

    if (!it->second.inFlight) {
        if (tryScheduleLocked(token)) {
            result.enqueued = true;
        } else if (it->second.slot.hasPending()) {
            result.queueOverflow = true;
        }
    }
    result.hasPending = it->second.slot.hasPending();
    result.processing = it->second.processing;
    return result;
}

void FrameScheduler::registerStream(const StreamToken& token) {
    std::lock_guard<std::mutex> lock(mutex_);
    StreamSlotEntry entry;
    entry.token = token;
    slots_[token.streamId] = std::move(entry);
}

void FrameScheduler::complete(const StreamToken& token, bool rescheduleIfPending) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = slots_.find(token.streamId);
        if (it == slots_.end() || it->second.token.generation != token.generation) {
            cv_.notify_all();
            return;
        }
        it->second.processing = false;
        it->second.inFlight = false;
        if (rescheduleIfPending && !stopping_) {
            tryScheduleLocked(token);
        }
    }
    cv_.notify_all();
}

void FrameScheduler::removeStream(const StreamToken& token) {
    std::unique_lock<std::mutex> lock(mutex_);
    auto it = slots_.find(token.streamId);
    if (it == slots_.end() || it->second.token.generation != token.generation) {
        return;
    }

    readyQueue_.remove(token);
    it->second.slot.clear();
    if (it->second.inFlight && !it->second.processing) {
        it->second.inFlight = false;
    }

    cv_.wait(lock, [&]() {
        const auto current = slots_.find(token.streamId);
        return current == slots_.end() || current->second.token.generation != token.generation || !current->second.processing;
    });

    it = slots_.find(token.streamId);
    if (it != slots_.end() && it->second.token.generation == token.generation) {
        slots_.erase(it);
    }
}

void FrameScheduler::stop() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stopping_ = true;
    }
    cv_.notify_all();
}

void FrameScheduler::startWorkers(int workerCount) {
    if (workersRunning_.exchange(true)) {
        return;
    }
    stopping_ = false;
    workers_.clear();
    workers_.reserve(static_cast<std::size_t>(workerCount));
    for (int i = 0; i < workerCount; ++i) {
        workers_.emplace_back([this]() { workerLoop(); });
    }
}

void FrameScheduler::joinWorkers() {
    if (!workersRunning_.exchange(false)) {
        return;
    }
    cv_.notify_all();
    for (auto& worker : workers_) {
        if (worker.joinable()) {
            worker.join();
        }
    }
    workers_.clear();
}

bool FrameScheduler::hasPending(const StreamToken& token) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = slots_.find(token.streamId);
    return it != slots_.end() && it->second.token.generation == token.generation && it->second.slot.hasPending();
}

bool FrameScheduler::isProcessing(const StreamToken& token) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = slots_.find(token.streamId);
    return it != slots_.end() && it->second.token.generation == token.generation && it->second.processing;
}

void FrameScheduler::workerLoop() {
    while (true) {
        StreamToken token;
        FrameRoutingJob job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this]() { return stopping_ || !readyQueue_.empty(); });
            if (stopping_ && readyQueue_.empty()) {
                break;
            }
            if (!readyQueue_.dequeue(token)) {
                continue;
            }

            auto it = slots_.find(token.streamId);
            if (it == slots_.end() || it->second.token.generation != token.generation) {
                continue;
            }
            std::optional<FrameRoutingJob> taken = it->second.slot.take();
            if (!taken.has_value()) {
                it->second.inFlight = false;
                it->second.processing = false;
                cv_.notify_all();
                continue;
            }
            it->second.inFlight = true;
            it->second.processing = true;
            job = std::move(*taken);
        }

        if (processCallback_) {
            processCallback_(std::move(job));
        } else {
            complete(token, false);
        }
    }
}

bool FrameScheduler::tryScheduleLocked(const StreamToken& token) {
    auto it = slots_.find(token.streamId);
    if (it == slots_.end() || it->second.token.generation != token.generation || !it->second.slot.hasPending() || it->second.inFlight) {
        return false;
    }
    if (!readyQueue_.tryEnqueue(token)) {
        return false;
    }
    it->second.inFlight = true;
    it->second.processing = false;
    cv_.notify_one();
    return true;
}

}  // namespace guardvision
