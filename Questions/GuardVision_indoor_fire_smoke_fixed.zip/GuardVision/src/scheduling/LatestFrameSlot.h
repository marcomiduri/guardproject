#pragma once

#include <cstdint>
#include <optional>

#include <frame/VideoFrame.h>

#include "core/StreamToken.h"

namespace guardvision {

struct FrameRoutingJob {
    StreamToken token;
    VideoFrame frame;
    std::int64_t submittedAtMs = 0;
};

enum class ReplaceResult { Inserted, ReplacedPending };

class LatestFrameSlot {
public:
    ReplaceResult replace(FrameRoutingJob job);
    std::optional<FrameRoutingJob> take();
    void clear();
    bool hasPending() const;

private:
    std::optional<FrameRoutingJob> job_;
};

}  // namespace guardvision
