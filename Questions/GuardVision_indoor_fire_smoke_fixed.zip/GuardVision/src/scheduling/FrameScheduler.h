#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "core/StreamToken.h"
#include "scheduling/FairStreamQueue.h"
#include "scheduling/LatestFrameSlot.h"

namespace guardvision {

struct SchedulerSubmitResult {
    bool enqueued = false;
    bool replacedPending = false;
    bool queueOverflow = false;
    bool hasPending = false;
    bool processing = false;
};

class FrameScheduler {
public:
    using ProcessCallback = std::function<void(FrameRoutingJob job)>;

    FrameScheduler(std::size_t readyQueueCapacity, ProcessCallback callback);

    SchedulerSubmitResult submit(FrameRoutingJob job);
    void registerStream(const StreamToken& token);
    void complete(const StreamToken& token, bool rescheduleIfPending);
    void removeStream(const StreamToken& token);
    void stop();
    void startWorkers(int workerCount);
    void joinWorkers();

    bool hasPending(const StreamToken& token) const;
    bool isProcessing(const StreamToken& token) const;

private:
    struct StreamSlotEntry {
        StreamToken token;
        LatestFrameSlot slot;
        bool inFlight = false;
        bool processing = false;
    };

    void workerLoop();
    bool tryScheduleLocked(const StreamToken& token);

    ProcessCallback processCallback_;
    FairStreamQueue readyQueue_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::unordered_map<std::string, StreamSlotEntry> slots_;
    std::atomic<bool> stopping_{false};
    std::atomic<bool> workersRunning_{false};
    std::vector<std::thread> workers_;
};

}  // namespace guardvision
