#pragma once

#include <cstddef>
#include <deque>
#include <mutex>
#include <unordered_set>

#include "core/StreamToken.h"

namespace guardvision {

class FairStreamQueue {
public:
    explicit FairStreamQueue(std::size_t capacity);

    bool tryEnqueue(const StreamToken& token);
    bool dequeue(StreamToken& output);
    void remove(const StreamToken& token);
    void clear();
    bool empty() const;
    std::size_t size() const;

private:
    std::size_t capacity_;
    std::deque<StreamToken> queue_;
    std::unordered_set<StreamToken> queued_;
};

}  // namespace guardvision
