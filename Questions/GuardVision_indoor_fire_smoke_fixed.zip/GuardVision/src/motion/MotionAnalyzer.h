#pragma once

#include <cstdint>
#include <vector>

namespace guardvision {

struct MotionCompareResult {
    double changedAreaRatio = 0.0;
    double score = 0.0;
    std::uint64_t changedPixels = 0;
};

bool compareLumaFrames(const std::vector<std::uint8_t>& previous, const std::vector<std::uint8_t>& current, int width, int height,
                       int pixelDifferenceThreshold, std::vector<std::uint8_t>& changeMask, std::vector<std::uint8_t>& blockActive,
                       MotionCompareResult& result);

inline bool compareLumaFrames(const std::vector<std::uint8_t>& previous, const std::vector<std::uint8_t>& current, int width, int height,
                              int pixelDifferenceThreshold, std::vector<std::uint8_t>& changeMask, MotionCompareResult& result) {
    std::vector<std::uint8_t> blockActive;
    return compareLumaFrames(previous, current, width, height, pixelDifferenceThreshold, changeMask, blockActive, result);
}

void cleanupChangeMask(std::vector<std::uint8_t>& changeMask, int width, int height, std::vector<std::uint8_t>& blockActive);

}  // namespace guardvision
