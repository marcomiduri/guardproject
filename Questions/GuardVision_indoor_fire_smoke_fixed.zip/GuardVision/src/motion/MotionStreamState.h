#pragma once

#include <cstdint>
#include <vector>

#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>
#include <frame/VideoFrame.h>

#include "motion/MotionRegionExtractor.h"

namespace guardvision {

struct MotionStreamState {
    MotionConfig config;

    MotionState state = MotionState::Idle;

    std::vector<std::uint8_t> previousLuma;
    std::vector<std::uint8_t> currentLuma;
    std::vector<std::uint8_t> changeMask;
    std::vector<std::uint8_t> blockActive;
    MotionRegionExtractionScratch regionScratch;
    std::vector<int> sampleX;
    std::vector<int> sampleY;
    Rect samplingRoi{};
    Size samplingAnalysisSize{};

    int analysisWidth = 0;
    int analysisHeight = 0;

    int sourceWidth = 0;
    int sourceHeight = 0;
    PixelFormat sourceFormat = PixelFormat::RGB24;

    Rect analysisAreaFullFrame{};

    bool hasBaseline = false;

    int consecutiveMotionFrames = 0;
    int consecutiveClearFrames = 0;

    std::int64_t lastAnalyzedTimestampMs = -1;
    std::int64_t lastEventTimestampMs = 0;

    void resetMotionState();
    void resetBaseline();
};

}  // namespace guardvision
