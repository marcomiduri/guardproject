#pragma once

#include <cstdint>
#include <vector>

#include <motion/MotionConfig.h>
#include <frame/VideoFrame.h>

#include "motion/MotionStreamState.h"

namespace guardvision {

struct LumaConversionResult {
    bool ok = false;
    int analysisWidth = 0;
    int analysisHeight = 0;
    Rect analysisAreaFullFrame{};
};

bool extractAnalysisLuma(const VideoFrame& frame, const MotionConfig& config, MotionStreamState& state, std::vector<std::uint8_t>& outputLuma,
                         LumaConversionResult& result);

Size computeAnalysisSize(int roiWidth, int roiHeight, int maxWidth, int maxHeight);

}  // namespace guardvision
