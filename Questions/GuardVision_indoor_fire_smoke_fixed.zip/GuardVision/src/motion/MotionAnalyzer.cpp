#include "motion/MotionAnalyzer.h"

#include <algorithm>
#include <cmath>

namespace guardvision {

bool compareLumaFrames(const std::vector<std::uint8_t>& previous, const std::vector<std::uint8_t>& current, int width, int height,
                       int pixelDifferenceThreshold, std::vector<std::uint8_t>& changeMask, std::vector<std::uint8_t>& blockActive,
                       MotionCompareResult& result) {
    result = MotionCompareResult{};
    if (width <= 0 || height <= 0) {
        return false;
    }
    const std::size_t count = static_cast<std::size_t>(width) * static_cast<std::size_t>(height);
    if (previous.size() != count || current.size() != count) {
        return false;
    }

    changeMask.assign(count, 0);
    std::uint64_t changed = 0;
    for (std::size_t i = 0; i < count; ++i) {
        const int diff = std::abs(static_cast<int>(current[i]) - static_cast<int>(previous[i]));
        if (diff >= pixelDifferenceThreshold) {
            changeMask[i] = 1;
            ++changed;
        }
    }

    cleanupChangeMask(changeMask, width, height, blockActive);

    changed = 0;
    for (const std::uint8_t value : changeMask) {
        if (value != 0) {
            ++changed;
        }
    }

    result.changedPixels = changed;
    result.changedAreaRatio = static_cast<double>(changed) / static_cast<double>(count);
    result.score = std::min(1.0, result.changedAreaRatio / 0.25);
    return true;
}

void cleanupChangeMask(std::vector<std::uint8_t>& changeMask, int width, int height, std::vector<std::uint8_t>& blockActive) {
    if (width <= 0 || height <= 0) {
        return;
    }

    const int blockSize = 8;
    const int blocksX = (width + blockSize - 1) / blockSize;
    const int blocksY = (height + blockSize - 1) / blockSize;
    blockActive.assign(static_cast<std::size_t>(blocksX * blocksY), 0);

    for (int by = 0; by < blocksY; ++by) {
        for (int bx = 0; bx < blocksX; ++bx) {
            int changedInBlock = 0;
            const int startX = bx * blockSize;
            const int startY = by * blockSize;
            const int endX = std::min(width, startX + blockSize);
            const int endY = std::min(height, startY + blockSize);
            for (int y = startY; y < endY; ++y) {
                for (int x = startX; x < endX; ++x) {
                    if (changeMask[static_cast<std::size_t>(y * width + x)] != 0) {
                        ++changedInBlock;
                    }
                }
            }
            if (changedInBlock >= 3) {
                blockActive[static_cast<std::size_t>(by * blocksX + bx)] = 1;
            }
        }
    }

    changeMask.assign(changeMask.size(), 0);
    for (int by = 0; by < blocksY; ++by) {
        for (int bx = 0; bx < blocksX; ++bx) {
            if (blockActive[static_cast<std::size_t>(by * blocksX + bx)] == 0) {
                continue;
            }
            const int startX = bx * blockSize;
            const int startY = by * blockSize;
            const int endX = std::min(width, startX + blockSize);
            const int endY = std::min(height, startY + blockSize);
            for (int y = startY; y < endY; ++y) {
                for (int x = startX; x < endX; ++x) {
                    changeMask[static_cast<std::size_t>(y * width + x)] = 1;
                }
            }
        }
    }
}

}  // namespace guardvision
