#include <motion/MotionTypes.h>

namespace guardvision {

const char* toString(MotionState state) noexcept {
    switch (state) {
        case MotionState::Idle:
            return "Idle";
        case MotionState::Candidate:
            return "Candidate";
        case MotionState::Active:
            return "Active";
        case MotionState::Clearing:
            return "Clearing";
    }
    return "Unknown";
}

const char* toString(MotionEventType type) noexcept {
    switch (type) {
        case MotionEventType::Started:
            return "Started";
        case MotionEventType::Updated:
            return "Updated";
        case MotionEventType::Ended:
            return "Ended";
    }
    return "Unknown";
}

}  // namespace guardvision
