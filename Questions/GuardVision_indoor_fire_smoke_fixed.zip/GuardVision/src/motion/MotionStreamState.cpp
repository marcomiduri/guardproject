#include "motion/MotionStreamState.h"

namespace guardvision {

void MotionStreamState::resetMotionState() {
    state = MotionState::Idle;
    consecutiveMotionFrames = 0;
    consecutiveClearFrames = 0;
    lastEventTimestampMs = 0;
}

void MotionStreamState::resetBaseline() {
    previousLuma.clear();
    currentLuma.clear();
    changeMask.clear();
    blockActive.clear();
    regionScratch.labels.clear();
    regionScratch.components.clear();
    sampleX.clear();
    sampleY.clear();
    samplingRoi = Rect{};
    samplingAnalysisSize = Size{};
    hasBaseline = false;
    analysisWidth = 0;
    analysisHeight = 0;
    resetMotionState();
}

}  // namespace guardvision
