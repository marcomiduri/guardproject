#include "motion/MotionProcessor.h"

#include <chrono>
#include <utility>

#include <core/DetectionMode.h>

#include "detail/AtomicUtil.h"
#include "detail/TimeUtil.h"
#include "motion/LumaConverter.h"
#include "motion/MotionAnalyzer.h"
#include "motion/MotionRegionExtractor.h"
#include "motion/MotionStateMachine.h"

namespace guardvision {

bool MotionProcessor::shouldResetBaseline(const VideoFrame& frame, const MotionStreamState& state) const {
    if (frame.width != state.sourceWidth || frame.height != state.sourceHeight || frame.pixelFormat != state.sourceFormat) {
        return true;
    }
    if (state.hasBaseline && state.lastAnalyzedTimestampMs >= 0 && state.config.baselineResetGapMs > 0 &&
        frame.timestampMs - state.lastAnalyzedTimestampMs > state.config.baselineResetGapMs) {
        return true;
    }
    return false;
}

MotionEvent MotionProcessor::makeEndedEvent(const MotionStreamState& state, const StreamToken& token, std::uint64_t sequence,
                                            std::int64_t timestampMs) const {
    MotionEvent event;
    event.type = MotionEventType::Ended;
    event.streamId = token.streamId;
    event.generation = token.generation;
    event.sequence = sequence;
    event.timestampMs = timestampMs;
    event.state = MotionState::Idle;
    event.analysisArea = state.analysisAreaFullFrame;
    return event;
}

MotionProcessResult MotionProcessor::processFrame(const VideoFrame& frame, const StreamToken& token, MotionStreamState& state,
                                                  MotionMetricsState& metrics) {
    MotionProcessResult result;
    const auto start = std::chrono::steady_clock::now();

    metrics.receivedFrames.fetch_add(1);
    if (!runsContinuousSoftware(state.config.detectionMode)) {
        return result;
    }

    if (state.lastAnalyzedTimestampMs >= 0 && state.config.analysisIntervalMs > 0 &&
        frame.timestampMs - state.lastAnalyzedTimestampMs < state.config.analysisIntervalMs) {
        result.skippedByInterval = true;
        metrics.skippedByInterval.fetch_add(1);
        return result;
    }

    if (shouldResetBaseline(frame, state)) {
        state.resetBaseline();
    }

    LumaConversionResult conversion;
    if (!extractAnalysisLuma(frame, state.config, state, state.currentLuma, conversion)) {
        result.hadError = true;
        result.error.code = GuardVisionErrorCode::UnsupportedMotionPixelFormat;
        result.error.component = "MotionProcessor";
        result.error.streamId = token.streamId;
        result.error.message = "Failed to extract analysis luminance.";
        result.error.recoverable = true;
        metrics.processingErrors.fetch_add(1);
        state.resetBaseline();
        return result;
    }

    metrics.analysisWidth = conversion.analysisWidth;
    metrics.analysisHeight = conversion.analysisHeight;

    if (!state.hasBaseline) {
        std::swap(state.previousLuma, state.currentLuma);
        state.hasBaseline = true;
        state.lastAnalyzedTimestampMs = frame.timestampMs;
        result.baselineCreated = true;
        metrics.baselineFrames.fetch_add(1);
        metrics.analyzedFrames.fetch_add(1);
        metrics.lastChangedAreaRatio = 0.0;
        metrics.state = MotionState::Idle;
        return result;
    }

    MotionCompareResult compareResult;
    if (!compareLumaFrames(state.previousLuma, state.currentLuma, conversion.analysisWidth, conversion.analysisHeight,
                           state.config.pixelDifferenceThreshold, state.changeMask, state.blockActive, compareResult)) {
        result.hadError = true;
        result.error.code = GuardVisionErrorCode::MotionProcessingFailed;
        result.error.component = "MotionProcessor";
        result.error.streamId = token.streamId;
        result.error.message = "Motion comparison failed.";
        result.error.recoverable = true;
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    int truncatedCount = 0;
    std::vector<MotionRegion> regions = extractMotionRegions(state.changeMask, conversion.analysisWidth, conversion.analysisHeight, state.config,
                                                             conversion.analysisAreaFullFrame, frame.size(), state.regionScratch, truncatedCount);
    if (truncatedCount > 0) {
        metrics.truncatedRegions.fetch_add(static_cast<std::uint64_t>(truncatedCount));
    }
    metrics.extractedRegions.fetch_add(static_cast<std::uint64_t>(regions.size()));

    MotionStateMachineInput smInput{state,
                                    state.config,
                                    compareResult.changedAreaRatio,
                                    compareResult.score,
                                    std::move(regions),
                                    conversion.analysisAreaFullFrame,
                                    frame.timestampMs,
                                    frame.sequence,
                                    token.generation,
                                    token.streamId};

    result.events = updateMotionStateMachine(smInput);
    state = smInput.state;

    for (const MotionEvent& event : result.events) {
        switch (event.type) {
            case MotionEventType::Started:
                metrics.startedEvents.fetch_add(1);
                break;
            case MotionEventType::Updated:
                metrics.updatedEvents.fetch_add(1);
                break;
            case MotionEventType::Ended:
                metrics.endedEvents.fetch_add(1);
                break;
        }
    }

    std::swap(state.previousLuma, state.currentLuma);
    state.lastAnalyzedTimestampMs = frame.timestampMs;
    metrics.analyzedFrames.fetch_add(1);
    metrics.lastChangedAreaRatio = compareResult.changedAreaRatio;
    metrics.state = state.state;
    result.analyzed = true;

    const auto end = std::chrono::steady_clock::now();
    result.processingTimeUs = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
    metrics.lastProcessingTimeUs = result.processingTimeUs;
    detail::updateAtomicMaximum(metrics.maximumProcessingTimeUs, result.processingTimeUs);

    return result;
}

}  // namespace guardvision
