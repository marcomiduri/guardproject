#pragma once

#include <vector>

#include <core/Error.h>
#include <motion/MotionEvent.h>
#include <frame/VideoFrame.h>

#include "core/StreamToken.h"
#include "metrics/MotionMetricsState.h"
#include "motion/MotionStreamState.h"

namespace guardvision {

struct MotionProcessResult {
    bool receivedFrame = true;
    bool skippedByInterval = false;
    bool baselineCreated = false;
    bool analyzed = false;
    bool hadError = false;
    GuardVisionError error;
    std::int64_t processingTimeUs = 0;
    std::vector<MotionEvent> events;
};

class MotionProcessor {
public:
    MotionProcessResult processFrame(const VideoFrame& frame, const StreamToken& token, MotionStreamState& state, MotionMetricsState& metrics);
    MotionEvent makeEndedEvent(const MotionStreamState& state, const StreamToken& token, std::uint64_t sequence, std::int64_t timestampMs) const;

private:
    bool shouldResetBaseline(const VideoFrame& frame, const MotionStreamState& state) const;
};

}  // namespace guardvision
