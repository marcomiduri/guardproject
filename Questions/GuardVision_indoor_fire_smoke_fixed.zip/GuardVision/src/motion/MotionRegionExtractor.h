#pragma once

#include <cstdint>
#include <vector>

#include <geometry/Geometry.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

namespace guardvision {

struct MotionRegionComponent {
    int minX = 0;
    int minY = 0;
    int maxX = 0;
    int maxY = 0;
    int area = 0;
};

struct MotionRegionExtractionScratch {
    std::vector<int> labels;
    std::vector<MotionRegionComponent> components;
};

std::vector<MotionRegion> extractMotionRegions(const std::vector<std::uint8_t>& changeMask, int analysisWidth, int analysisHeight,
                                               const MotionConfig& config, const Rect& analysisAreaFullFrame, Size sourceFrameSize,
                                               MotionRegionExtractionScratch& scratch, int& truncatedCount);

inline std::vector<MotionRegion> extractMotionRegions(const std::vector<std::uint8_t>& changeMask, int analysisWidth, int analysisHeight,
                                                      const MotionConfig& config, const Rect& analysisAreaFullFrame, Size sourceFrameSize,
                                                      int& truncatedCount) {
    MotionRegionExtractionScratch scratch;
    return extractMotionRegions(changeMask, analysisWidth, analysisHeight, config, analysisAreaFullFrame, sourceFrameSize, scratch, truncatedCount);
}

}  // namespace guardvision
