#include "motion/MotionRegionExtractor.h"

#include <algorithm>
#include <cmath>

namespace guardvision {
namespace {

Rect mapAnalysisRectToFullFrame(const Rect& analysisRect, const Rect& analysisArea, int analysisWidth, int analysisHeight, Size sourceFrameSize) {
    if (!analysisRect.isValid() || !analysisArea.isValid() || analysisWidth <= 0 || analysisHeight <= 0) {
        return Rect{};
    }

    const double scaleX = static_cast<double>(analysisArea.width) / static_cast<double>(analysisWidth);
    const double scaleY = static_cast<double>(analysisArea.height) / static_cast<double>(analysisHeight);
    Rect roiRelative{
      static_cast<int>(std::floor(analysisRect.x * scaleX)),
      static_cast<int>(std::floor(analysisRect.y * scaleY)),
      static_cast<int>(std::ceil(analysisRect.width * scaleX)),
      static_cast<int>(std::ceil(analysisRect.height * scaleY)),
    };
    return clampRect(mapRoiRectToFullFrame(analysisArea, roiRelative), sourceFrameSize);
}

}  // namespace

std::vector<MotionRegion> extractMotionRegions(const std::vector<std::uint8_t>& changeMask, int analysisWidth, int analysisHeight,
                                               const MotionConfig& config, const Rect& analysisAreaFullFrame, Size sourceFrameSize,
                                               MotionRegionExtractionScratch& scratch, int& truncatedCount) {
    truncatedCount = 0;
    std::vector<MotionRegion> regions;
    if (analysisWidth <= 0 || analysisHeight <= 0) {
        return regions;
    }

    const int blockSize = 8;
    const int blocksX = (analysisWidth + blockSize - 1) / blockSize;
    const int blocksY = (analysisHeight + blockSize - 1) / blockSize;
    scratch.labels.assign(static_cast<std::size_t>(blocksX * blocksY), -1);
    scratch.components.clear();
    std::vector<int>& labels = scratch.labels;
    std::vector<MotionRegionComponent>& components = scratch.components;
    int nextLabel = 0;

    auto index = [blocksX](int bx, int by) { return by * blocksX + bx; };

    for (int by = 0; by < blocksY; ++by) {
        for (int bx = 0; bx < blocksX; ++bx) {
            const int startX = bx * blockSize;
            const int startY = by * blockSize;
            const int endX = std::min(analysisWidth, startX + blockSize);
            const int endY = std::min(analysisHeight, startY + blockSize);
            int changed = 0;
            for (int y = startY; y < endY; ++y) {
                for (int x = startX; x < endX; ++x) {
                    if (changeMask[static_cast<std::size_t>(y * analysisWidth + x)] != 0) {
                        ++changed;
                    }
                }
            }
            if (changed == 0) {
                continue;
            }

            int useLabel = -1;
            if (bx > 0 && labels[static_cast<std::size_t>(index(bx - 1, by))] >= 0) {
                useLabel = labels[static_cast<std::size_t>(index(bx - 1, by))];
            }
            if (by > 0 && labels[static_cast<std::size_t>(index(bx, by - 1))] >= 0) {
                const int topLabel = labels[static_cast<std::size_t>(index(bx, by - 1))];
                useLabel = useLabel < 0 ? topLabel : std::min(useLabel, topLabel);
            }
            if (useLabel < 0) {
                useLabel = nextLabel++;
                components.push_back(MotionRegionComponent{startX, startY, endX - 1, endY - 1, changed});
            } else {
                MotionRegionComponent& region = components[static_cast<std::size_t>(useLabel)];
                region.minX = std::min(region.minX, startX);
                region.minY = std::min(region.minY, startY);
                region.maxX = std::max(region.maxX, endX - 1);
                region.maxY = std::max(region.maxY, endY - 1);
                region.area += changed;
            }
            labels[static_cast<std::size_t>(index(bx, by))] = useLabel;
        }
    }

    for (MotionRegionComponent& component : components) {
        const int width = component.maxX - component.minX + 1;
        const int height = component.maxY - component.minY + 1;
        if (width < config.minimumRegionWidth || height < config.minimumRegionHeight || (width * height) < config.minimumRegionArea) {
            continue;
        }

        const Rect analysisRect{component.minX, component.minY, width, height};
        const Rect fullFrameRect = mapAnalysisRectToFullFrame(analysisRect, analysisAreaFullFrame, analysisWidth, analysisHeight, sourceFrameSize);
        if (!fullFrameRect.isValid()) {
            continue;
        }

        MotionRegion region;
        region.bounds = fullFrameRect;
        region.changedAreaRatio = static_cast<double>(component.area) / static_cast<double>(std::max(1, analysisWidth * analysisHeight));
        region.score = std::min(1.0, region.changedAreaRatio / config.startChangedAreaRatio);
        regions.push_back(region);
    }

    std::sort(regions.begin(), regions.end(), [](const MotionRegion& a, const MotionRegion& b) {
        const int areaA = a.bounds.width * a.bounds.height;
        const int areaB = b.bounds.width * b.bounds.height;
        return areaA > areaB;
    });

    if (static_cast<int>(regions.size()) > config.maximumRegionCount) {
        truncatedCount = static_cast<int>(regions.size()) - config.maximumRegionCount;
        regions.resize(static_cast<std::size_t>(config.maximumRegionCount));
    }

    return regions;
}

}  // namespace guardvision
