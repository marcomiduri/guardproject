#include <core/DetectionMode.h>

#include "detail/ConfigNormalization.h"

namespace guardvision {
namespace {

constexpr int kMaxAnalysisDimension = 4096;
constexpr int kMaxRegionCount = 64;
constexpr int kMaxIntervalMs = 3600000;

bool isRatioInRange(double value) noexcept {
    return value >= 0.0 && value <= 1.0;
}

}  // namespace

bool isValidMotionConfig(const MotionConfig& config) noexcept {
    if (config.analysisIntervalMs < 0 || config.analysisIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.maximumAnalysisWidth <= 0 || config.maximumAnalysisWidth > kMaxAnalysisDimension) {
        return false;
    }
    if (config.maximumAnalysisHeight <= 0 || config.maximumAnalysisHeight > kMaxAnalysisDimension) {
        return false;
    }
    if (config.pixelDifferenceThreshold < 0 || config.pixelDifferenceThreshold > 255) {
        return false;
    }
    if (!isRatioInRange(config.startChangedAreaRatio) || !isRatioInRange(config.continueChangedAreaRatio)) {
        return false;
    }
    if (config.startChangedAreaRatio < config.continueChangedAreaRatio) {
        return false;
    }
    if (config.activationFrameCount < 1 || config.clearFrameCount < 1) {
        return false;
    }
    if (config.minimumRegionWidth < 1 || config.minimumRegionHeight < 1 || config.minimumRegionArea < 1) {
        return false;
    }
    if (config.maximumRegionCount < 1 || config.maximumRegionCount > kMaxRegionCount) {
        return false;
    }
    if (config.eventUpdateIntervalMs < 0 || config.eventUpdateIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.baselineResetGapMs < 0 || config.baselineResetGapMs > kMaxIntervalMs) {
        return false;
    }
    if (config.useRoi && !config.roi.isValid()) {
        return false;
    }
    MotionConfig normalized = config;
    normalizeMotionConfig(normalized);
    return true;
}

}  // namespace guardvision
