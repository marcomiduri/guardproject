#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <geometry/Geometry.h>
#include <motion/MotionConfig.h>
#include <motion/MotionEvent.h>
#include <motion/MotionTypes.h>

#include "motion/MotionStreamState.h"

namespace guardvision {

struct MotionStateMachineInput {
    MotionStreamState& state;
    MotionConfig config;
    double changedAreaRatio = 0.0;
    double score = 0.0;
    std::vector<MotionRegion> regions;
    Rect analysisArea;
    std::int64_t timestampMs = 0;
    std::uint64_t sequence = 0;
    std::uint64_t generation = 0;
    std::string streamId;
};

std::vector<MotionEvent> updateMotionStateMachine(MotionStateMachineInput& input);

MotionEvent makeMotionEvent(MotionEventType type, const MotionStateMachineInput& input);

}  // namespace guardvision
