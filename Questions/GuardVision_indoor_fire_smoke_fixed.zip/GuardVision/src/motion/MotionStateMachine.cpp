#include "motion/MotionStateMachine.h"

namespace guardvision {

MotionEvent makeMotionEvent(MotionEventType type, const MotionStateMachineInput& input) {
    MotionEvent event;
    event.type = type;
    event.streamId = input.streamId;
    event.generation = input.generation;
    event.sequence = input.sequence;
    event.timestampMs = input.timestampMs;
    event.state = input.state.state;
    event.score = input.score;
    event.changedAreaRatio = input.changedAreaRatio;
    event.analysisArea = input.analysisArea;
    event.regions = input.regions;
    return event;
}

std::vector<MotionEvent> updateMotionStateMachine(MotionStateMachineInput& input) {
    std::vector<MotionEvent> events;
    MotionStreamState& state = input.state;
    const MotionConfig& config = input.config;

    const bool motionDetected = input.changedAreaRatio >= config.continueChangedAreaRatio;
    const bool startDetected = input.changedAreaRatio >= config.startChangedAreaRatio;

    switch (state.state) {
        case MotionState::Idle:
            if (startDetected) {
                if (config.activationFrameCount <= 1) {
                    state.state = MotionState::Active;
                    state.consecutiveMotionFrames = 0;
                    state.consecutiveClearFrames = 0;
                    events.push_back(makeMotionEvent(MotionEventType::Started, input));
                    state.lastEventTimestampMs = input.timestampMs;
                } else {
                    state.state = MotionState::Candidate;
                    state.consecutiveMotionFrames = 1;
                    state.consecutiveClearFrames = 0;
                }
            }
            break;

        case MotionState::Candidate:
            if (startDetected) {
                ++state.consecutiveMotionFrames;
                if (state.consecutiveMotionFrames >= config.activationFrameCount) {
                    state.state = MotionState::Active;
                    state.consecutiveClearFrames = 0;
                    events.push_back(makeMotionEvent(MotionEventType::Started, input));
                    state.lastEventTimestampMs = input.timestampMs;
                }
            } else {
                state.state = MotionState::Idle;
                state.consecutiveMotionFrames = 0;
            }
            break;

        case MotionState::Active:
            if (motionDetected) {
                state.consecutiveClearFrames = 0;
                if (config.eventUpdateIntervalMs <= 0 || input.timestampMs - state.lastEventTimestampMs >= config.eventUpdateIntervalMs) {
                    events.push_back(makeMotionEvent(MotionEventType::Updated, input));
                    state.lastEventTimestampMs = input.timestampMs;
                }
            } else {
                state.state = MotionState::Clearing;
                state.consecutiveClearFrames = 1;
            }
            break;

        case MotionState::Clearing:
            if (motionDetected) {
                state.state = MotionState::Active;
                state.consecutiveClearFrames = 0;
                if (config.eventUpdateIntervalMs <= 0 || input.timestampMs - state.lastEventTimestampMs >= config.eventUpdateIntervalMs) {
                    events.push_back(makeMotionEvent(MotionEventType::Updated, input));
                    state.lastEventTimestampMs = input.timestampMs;
                }
            } else {
                ++state.consecutiveClearFrames;
                if (state.consecutiveClearFrames >= config.clearFrameCount) {
                    state.state = MotionState::Idle;
                    state.consecutiveMotionFrames = 0;
                    state.consecutiveClearFrames = 0;
                    input.state.state = MotionState::Idle;
                    events.push_back(makeMotionEvent(MotionEventType::Ended, input));
                    state.lastEventTimestampMs = input.timestampMs;
                }
            }
            break;
    }

    input.state.state = state.state;
    return events;
}

}  // namespace guardvision
