#include "motion/LumaConverter.h"

#include <algorithm>
#include <cmath>

namespace guardvision {
namespace {

std::uint8_t rgbToLuma(std::uint8_t r, std::uint8_t g, std::uint8_t b) {
    return static_cast<std::uint8_t>((77 * r + 150 * g + 29 * b) >> 8);
}

void rebuildSamplingMap(MotionStreamState& state, const Rect& roi, const Size& analysisSize, const Size& frameSize) {
    if (state.samplingRoi.x == roi.x && state.samplingRoi.y == roi.y && state.samplingRoi.width == roi.width &&
        state.samplingRoi.height == roi.height && state.samplingAnalysisSize.width == analysisSize.width &&
        state.samplingAnalysisSize.height == analysisSize.height && state.sourceWidth == frameSize.width && state.sourceHeight == frameSize.height &&
        state.sampleX.size() == static_cast<std::size_t>(analysisSize.width) &&
        state.sampleY.size() == static_cast<std::size_t>(analysisSize.height)) {
        return;
    }

    state.sampleX.resize(static_cast<std::size_t>(analysisSize.width));
    state.sampleY.resize(static_cast<std::size_t>(analysisSize.height));

    for (int x = 0; x < analysisSize.width; ++x) {
        const int sourceX = analysisSize.width == 1 ? roi.x : roi.x + (x * roi.width) / analysisSize.width;
        state.sampleX[static_cast<std::size_t>(x)] = std::clamp(sourceX, 0, frameSize.width - 1);
    }
    for (int y = 0; y < analysisSize.height; ++y) {
        const int sourceY = analysisSize.height == 1 ? roi.y : roi.y + (y * roi.height) / analysisSize.height;
        state.sampleY[static_cast<std::size_t>(y)] = std::clamp(sourceY, 0, frameSize.height - 1);
    }

    state.samplingRoi = roi;
    state.samplingAnalysisSize = analysisSize;
}

void convertGrayOrYPlane(const VideoFrame& frame, const MotionStreamState& state, const Size& analysisSize, std::vector<std::uint8_t>& output) {
    const std::uint8_t* source = frame.buffer->data();
    for (int ay = 0; ay < analysisSize.height; ++ay) {
        const std::uint8_t* sourceRow = source + state.sampleY[static_cast<std::size_t>(ay)] * frame.stride;
        std::uint8_t* destinationRow = output.data() + static_cast<std::size_t>(ay * analysisSize.width);
        for (int ax = 0; ax < analysisSize.width; ++ax) {
            destinationRow[ax] = sourceRow[state.sampleX[static_cast<std::size_t>(ax)]];
        }
    }
}

template <int BytesPerPixel, bool SourceIsRgb>
void convertPacked(const VideoFrame& frame, const MotionStreamState& state, const Size& analysisSize, std::vector<std::uint8_t>& output) {
    const std::uint8_t* source = frame.buffer->data();
    for (int ay = 0; ay < analysisSize.height; ++ay) {
        const std::uint8_t* sourceRow = source + state.sampleY[static_cast<std::size_t>(ay)] * frame.stride;
        std::uint8_t* destinationRow = output.data() + static_cast<std::size_t>(ay * analysisSize.width);
        for (int ax = 0; ax < analysisSize.width; ++ax) {
            const std::uint8_t* pixel = sourceRow + state.sampleX[static_cast<std::size_t>(ax)] * BytesPerPixel;
            if constexpr (SourceIsRgb) {
                destinationRow[ax] = rgbToLuma(pixel[0], pixel[1], pixel[2]);
            } else {
                destinationRow[ax] = rgbToLuma(pixel[2], pixel[1], pixel[0]);
            }
        }
    }
}

}  // namespace

Size computeAnalysisSize(int roiWidth, int roiHeight, int maxWidth, int maxHeight) {
    if (roiWidth <= 0 || roiHeight <= 0 || maxWidth <= 0 || maxHeight <= 0) {
        return Size{};
    }
    if (roiWidth <= maxWidth && roiHeight <= maxHeight) {
        return Size{roiWidth, roiHeight};
    }

    const double scaleW = static_cast<double>(maxWidth) / static_cast<double>(roiWidth);
    const double scaleH = static_cast<double>(maxHeight) / static_cast<double>(roiHeight);
    const double scale = std::min(scaleW, scaleH);
    const int outW = std::max(1, static_cast<int>(std::floor(roiWidth * scale)));
    const int outH = std::max(1, static_cast<int>(std::floor(roiHeight * scale)));
    return Size{outW, outH};
}

bool extractAnalysisLuma(const VideoFrame& frame, const MotionConfig& config, MotionStreamState& state, std::vector<std::uint8_t>& outputLuma,
                         LumaConversionResult& result) {
    result = LumaConversionResult{};
    if (!frame.isValid()) {
        return false;
    }

    const Size frameSize = frame.size();
    Rect roiRect{0, 0, frameSize.width, frameSize.height};
    if (config.useRoi) {
        roiRect = normalizedRectToPixels(config.roi, frameSize);
        if (!roiRect.isValid()) {
            return false;
        }
    }

    const Size analysisSize = computeAnalysisSize(roiRect.width, roiRect.height, config.maximumAnalysisWidth, config.maximumAnalysisHeight);
    if (!analysisSize.isValid()) {
        return false;
    }

    const std::size_t pixelCount = static_cast<std::size_t>(analysisSize.width) * static_cast<std::size_t>(analysisSize.height);
    outputLuma.resize(pixelCount);
    rebuildSamplingMap(state, roiRect, analysisSize, frameSize);

    switch (frame.pixelFormat) {
        case PixelFormat::Gray8:
        case PixelFormat::NV12:
        case PixelFormat::I420:
        case PixelFormat::YV12:
            convertGrayOrYPlane(frame, state, analysisSize, outputLuma);
            break;
        case PixelFormat::RGB24:
            convertPacked<3, true>(frame, state, analysisSize, outputLuma);
            break;
        case PixelFormat::BGR24:
            convertPacked<3, false>(frame, state, analysisSize, outputLuma);
            break;
        case PixelFormat::BGRA32:
            convertPacked<4, false>(frame, state, analysisSize, outputLuma);
            break;
        default:
            return false;
    }

    result.ok = true;
    result.analysisWidth = analysisSize.width;
    result.analysisHeight = analysisSize.height;
    result.analysisAreaFullFrame = roiRect;
    state.analysisWidth = analysisSize.width;
    state.analysisHeight = analysisSize.height;
    state.analysisAreaFullFrame = roiRect;
    state.sourceWidth = frameSize.width;
    state.sourceHeight = frameSize.height;
    state.sourceFormat = frame.pixelFormat;
    return true;
}

}  // namespace guardvision
