#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

Result StreamManager::registerStream(const StreamConfig& config) {
    StreamConfig normalizedConfig = config;
    normalizeMotionConfig(normalizedConfig.motion);
    normalizeFaceConfig(normalizedConfig.face);
    normalizeHazardConfig(normalizedConfig.hazard);

    if (!runtimeState_.acceptingSubmissions.load()) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "StreamManager", normalizedConfig.streamId);
    }
    if (!isValidStreamId(normalizedConfig.streamId)) {
        return Result::failure(GuardVisionErrorCode::InvalidStreamConfiguration, "Stream ID is empty, too long, or contains control characters.",
                               "StreamManager", normalizedConfig.streamId);
    }
    if (!isValidMotionConfig(normalizedConfig.motion)) {
        return Result::failure(GuardVisionErrorCode::InvalidMotionConfiguration, "Motion configuration is invalid.", "StreamManager",
                               normalizedConfig.streamId);
    }
    if (!isValidFaceConfig(normalizedConfig.face)) {
        return Result::failure(GuardVisionErrorCode::InvalidFaceConfiguration, "Face configuration is invalid.", "StreamManager",
                               normalizedConfig.streamId);
    }
    if (!isValidHazardConfig(normalizedConfig.hazard)) {
        return Result::failure(GuardVisionErrorCode::InvalidHazardConfiguration, "Hazard configuration is invalid.", "StreamManager",
                               normalizedConfig.streamId);
    }
    if (normalizedConfig.face.processingLevel != FaceProcessingLevel::Disabled && !isSupportedFaceTriggerMode(normalizedConfig.face.triggerMode)) {
        return Result::failure(GuardVisionErrorCode::UnsupportedFaceTriggerMode, "Face trigger mode is not supported.", "StreamManager",
                               normalizedConfig.streamId);
    }
    if (normalizedConfig.face.processingLevel != FaceProcessingLevel::Disabled) {
        const Result engineResult = ensureIdentifyEngine();
        if (!engineResult.ok) {
            return engineResult;
        }
    }
    if (normalizedConfig.hazard.processingLevel == HazardProcessingLevel::Detect) {
        const Result hazardResult = ensureHazardEngine(normalizedConfig.hazard);
        if (!hazardResult.ok) {
            return hazardResult;
        }
    }

    StreamToken token;
    std::shared_ptr<StreamContext> context;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        if (streams_.find(normalizedConfig.streamId) != streams_.end()) {
            return Result::failure(GuardVisionErrorCode::StreamAlreadyExists, "Stream ID is already registered.", "StreamManager",
                                   normalizedConfig.streamId);
        }
        if (static_cast<int>(streams_.size()) >= config_.maxStreams) {
            return Result::failure(GuardVisionErrorCode::MaximumStreamCountReached, "Maximum stream count reached.", "StreamManager",
                                   normalizedConfig.streamId);
        }

        context = std::make_shared<StreamContext>();
        context->config = normalizedConfig;
        context->generation = nextGeneration_.fetch_add(1);
        context->state = StreamState::Active;
        context->stopping = false;
        context->motion.config = normalizedConfig.motion;
        context->motion.resetBaseline();
        context->streamMetrics = metrics_.streamMetricsHandle(normalizedConfig.streamId);
        context->motionMetrics = metrics_.motionMetricsHandle(normalizedConfig.streamId);
        context->faceMetrics = metrics_.faceMetricsHandle(normalizedConfig.streamId);
        context->hazardMetrics = metrics_.hazardMetricsHandle(normalizedConfig.streamId);
        context->onboardMetrics = metrics_.onboardMetricsHandle(normalizedConfig.streamId);
        token = StreamToken{normalizedConfig.streamId, context->generation};
        streams_.emplace(normalizedConfig.streamId, context);
    }

    scheduler_->registerStream(token);
    motionScheduler_->registerStream(token);
    context->motionMetrics->enabled = isMotionAnalyticActive(normalizedConfig.motion);
    context->motionMetrics->state = MotionState::Idle;
    context->faceMetrics->enabled = isFaceAnalyticActive(normalizedConfig.face);
    context->faceMetrics->processingLevel = normalizedConfig.face.processingLevel;
    context->hazardMetrics->enabled = isHazardAnalyticActive(normalizedConfig.hazard);
    context->hazardMetrics->processingLevel = normalizedConfig.hazard.processingLevel;

    if (onboardProcessor_) {
        onboardProcessor_->registerStream(token, normalizedConfig.motion, normalizedConfig.face, normalizedConfig.hazard, context->onboardMetrics);
    }
    if (faceScheduler_ && normalizedConfig.face.processingLevel != FaceProcessingLevel::Disabled) {
        faceScheduler_->registerStream(token, normalizedConfig.face, context->faceMetrics);
    }
    if (hazardScheduler_ && normalizedConfig.hazard.processingLevel == HazardProcessingLevel::Detect) {
        hazardScheduler_->registerStream(token, normalizedConfig.hazard, context->hazardMetrics);
    }
    metrics_.runtime().activeStreams.fetch_add(1);

    {
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        emitStreamStatus(*context, token, false, false);
    }
    return Result::success();
}

Result StreamManager::unregisterStream(const std::string& streamId) {
    if (!runtimeState_.acceptingSubmissions.load()) {
        std::lock_guard<std::mutex> lock(mapMutex_);
        if (streams_.empty()) {
            return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "StreamManager", streamId);
        }
    }

    StreamToken token;
    StreamStatus stoppingStatus;
    std::int64_t finalEventTimestampMs = 0;
    std::shared_ptr<StreamContext> context;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(streamId);
        if (it == streams_.end()) {
            return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
        }
        context = it->second;
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        context->stopping = true;
        context->state = StreamState::Stopping;
        token = StreamToken{streamId, context->generation};
        finalEventTimestampMs = context->lastFrameTimestampMs;
        stoppingStatus = buildStatus(*context, token, scheduler_ && scheduler_->hasPending(token), scheduler_ && scheduler_->isProcessing(token));
    }

    if (dispatcher_) {
        RuntimeEvent event;
        event.type = RuntimeEventType::StreamStatus;
        event.status = stoppingStatus;
        dispatcher_->post(std::move(event));
    }

    if (scheduler_) {
        scheduler_->removeStream(token);
    }
    if (motionScheduler_) {
        motionScheduler_->removeStream(token);
    }
    if (faceScheduler_) {
        faceScheduler_->unregisterStream(token);
    }
    if (hazardScheduler_) {
        hazardScheduler_->unregisterStream(token);
    }

    std::vector<AlarmEvent> endedAlarms;
    if (onboardProcessor_) {
        endedAlarms = onboardProcessor_->unregisterStream(token, finalEventTimestampMs);
    }

    frameStore_.remove(token);
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(streamId);
        if (it != streams_.end() && it->second == context) {
            streams_.erase(it);
        }
    }

    for (AlarmEvent& alarm : endedAlarms) {
        postAlarmEvent(std::move(alarm));
    }

    metrics_.removeStream(streamId);
    metrics_.runtime().activeStreams.fetch_sub(1);

    stoppingStatus.state = StreamState::Stopped;
    stoppingStatus.acceptingFrames = false;
    stoppingStatus.hasPendingFrame = false;
    stoppingStatus.processingFrame = false;
    if (dispatcher_) {
        RuntimeEvent event;
        event.type = RuntimeEventType::StreamStatus;
        event.status = stoppingStatus;
        dispatcher_->post(std::move(event));
    }
    return Result::success();
}

}  // namespace guardvision
