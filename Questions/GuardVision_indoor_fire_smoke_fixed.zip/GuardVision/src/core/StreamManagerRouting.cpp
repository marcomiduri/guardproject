#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/AtomicUtil.h"
#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

void StreamManager::processRoutingJob(FrameRoutingJob job) {
    const StreamToken token = job.token;
    const std::shared_ptr<StreamContext> context = findStreamContext(token.streamId);
    const std::shared_ptr<StreamMetricsState> streamMetrics = context ? context->streamMetrics : nullptr;
    const auto contextIsActive = [&]() {
        if (!context) {
            return false;
        }
        std::lock_guard<std::mutex> lock(context->mutex);
        return !context->stopping && context->generation == token.generation && context->state == StreamState::Active;
    };

    if (!context || !streamMetrics || !contextIsActive()) {
        metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        if (streamMetrics) {
            streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        }
        if (scheduler_) {
            scheduler_->complete(token, false);
        }
        return;
    }

    const int delayMs = detail::testFrameProcessingDelayMs();
    if (delayMs > 0) {
        std::this_thread::sleep_for(std::chrono::milliseconds(delayMs));
    }

    if (!contextIsActive()) {
        metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        if (scheduler_) {
            scheduler_->complete(token, false);
        }
        return;
    }

    const std::int64_t processedAtMs = detail::steadyNowMs();
    const std::int64_t queueDelayMs = processedAtMs - job.submittedAtMs;

    MotionConfig motionConfig;
    FaceConfig faceConfig;
    faceConfig.processingLevel = FaceProcessingLevel::Disabled;
    HazardConfig hazardConfig;
    hazardConfig.processingLevel = HazardProcessingLevel::Disabled;
    {
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        if (context->generation != token.generation || context->stopping) {
            metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
            streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
            if (scheduler_) {
                scheduler_->complete(token, false);
            }
            return;
        }
        motionConfig = context->config.motion;
        faceConfig = context->config.face;
        hazardConfig = context->config.hazard;
    }

    if (motionScheduler_ && runsContinuousSoftware(motionConfig.detectionMode)) {
        FrameRoutingJob motionJob;
        motionJob.token = token;
        motionJob.frame = job.frame;
        motionJob.submittedAtMs = job.submittedAtMs;
        const SchedulerSubmitResult motionSubmit = motionScheduler_->submit(std::move(motionJob));
        if (motionSubmit.queueOverflow && context->motionMetrics) {
            context->motionMetrics->processingErrors.fetch_add(1, std::memory_order_relaxed);
        }
    }

    if (onboardProcessor_ && contextIsActive()) {
        onboardProcessor_->recordFrame(token, job.frame);
    }

    if (contextIsActive()) {
        if (faceScheduler_ && faceConfig.processingLevel != FaceProcessingLevel::Disabled && runsContinuousSoftware(faceConfig.detectionMode)) {
            FaceRoutingJob faceJob;
            faceJob.token = token;
            faceJob.frame = job.frame;
            faceJob.config = faceConfig;
            faceJob.submittedAtMs = job.submittedAtMs;
            faceScheduler_->offerFrame(std::move(faceJob));
        }

        if (hazardScheduler_ && hazardConfig.processingLevel == HazardProcessingLevel::Detect && runsContinuousSoftware(hazardConfig.detectionMode)) {
            HazardRoutingJob hazardJob;
            hazardJob.token = token;
            hazardJob.frame = job.frame;
            hazardJob.config = hazardConfig;
            hazardJob.submittedAtMs = job.submittedAtMs;
            hazardScheduler_->offerFrame(std::move(hazardJob));
        }

        metrics_.runtime().processedFrames.fetch_add(1, std::memory_order_relaxed);
        streamMetrics->processedFrames.fetch_add(1, std::memory_order_relaxed);
        streamMetrics->lastQueueDelayMs = queueDelayMs;
        detail::updateAtomicMaximum(streamMetrics->maximumQueueDelayMs, queueDelayMs);

        {
            std::lock_guard<std::mutex> ctxLock(context->mutex);
            if (context->generation == token.generation && !context->stopping) {
                ++context->processedFrameCount;
            }
        }

        if (dispatcher_ && contextIsActive()) {
            RuntimeEvent event;
            event.type = RuntimeEventType::FrameProcessed;
            event.frameProcessed.streamId = token.streamId;
            event.frameProcessed.generation = token.generation;
            event.frameProcessed.sequence = job.frame.sequence;
            event.frameProcessed.timestampMs = job.frame.timestampMs;
            event.frameProcessed.submittedAtMs = job.submittedAtMs;
            event.frameProcessed.processedAtMs = processedAtMs;
            event.frameProcessed.queueDelayMs = queueDelayMs;
            dispatcher_->post(std::move(event));
        }
    } else {
        metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
    }

    if (scheduler_) {
        scheduler_->complete(token, true);
    }
}

}  // namespace guardvision
