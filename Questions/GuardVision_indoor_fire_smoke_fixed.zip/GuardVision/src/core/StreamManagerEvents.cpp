#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

void StreamManager::postMotionEvents(std::vector<MotionEvent> events) {
    if (!dispatcher_) {
        return;
    }
    for (MotionEvent& event : events) {
        if (!isTokenActive(StreamToken{event.streamId, event.generation})) {
            continue;
        }
        feedSoftwareAlarmsFromMotion(event);
        RuntimeEvent runtimeEvent;
        runtimeEvent.type = RuntimeEventType::Motion;
        runtimeEvent.motion = std::move(event);
        dispatcher_->post(std::move(runtimeEvent));
    }
}

void StreamManager::postFaceEvents(std::vector<FaceEvent> events) {
    if (!dispatcher_) {
        return;
    }
    for (FaceEvent& event : events) {
        if (!isTokenActive(StreamToken{event.streamId, event.generation})) {
            continue;
        }
        const std::string streamId = event.streamId;
        const FaceEventType eventType = event.type;
        feedSoftwareAlarmsFromFace(event);
        RuntimeEvent runtimeEvent;
        runtimeEvent.type = RuntimeEventType::Face;
        runtimeEvent.face = std::move(event);
        if (!dispatcher_->post(std::move(runtimeEvent)) && eventType == FaceEventType::TracksUpdated) {
            if (const std::shared_ptr<FaceMetricsState> metrics = metrics_.findFaceMetricsHandle(streamId)) {
                metrics->droppedUpdateEvents.fetch_add(1);
            }
        }
    }
}

void StreamManager::postHazardEvents(std::vector<HazardEvent> events) {
    if (!dispatcher_) {
        return;
    }
    for (HazardEvent& event : events) {
        if (!isTokenActive(StreamToken{event.streamId, event.generation})) {
            continue;
        }
        const std::string streamId = event.streamId;
        const HazardEventType eventType = event.type;
        feedSoftwareAlarmsFromHazard(event);
        RuntimeEvent runtimeEvent;
        runtimeEvent.type = RuntimeEventType::Hazard;
        runtimeEvent.hazard = std::move(event);
        if (!dispatcher_->post(std::move(runtimeEvent)) && eventType == HazardEventType::Updated) {
            if (const std::shared_ptr<HazardMetricsState> metrics = metrics_.findHazardMetricsHandle(streamId)) {
                metrics->droppedUpdateEvents.fetch_add(1);
            }
        }
    }
}

void StreamManager::postAlarmEvent(AlarmEvent event) {
    if (!dispatcher_) {
        return;
    }
    RuntimeEvent runtimeEvent;
    runtimeEvent.type = RuntimeEventType::Alarm;
    runtimeEvent.alarm = std::move(event);
    dispatcher_->post(std::move(runtimeEvent));
}

void StreamManager::feedSoftwareAlarmsFromMotion(const MotionEvent& event) {
    if (!onboardProcessor_) {
        return;
    }
    if (event.type != MotionEventType::Started && event.type != MotionEventType::Updated) {
        return;
    }
    MotionConfig motionConfig;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(event.streamId);
        if (it == streams_.end()) {
            return;
        }
        std::lock_guard<std::mutex> ctxLock(it->second->mutex);
        motionConfig = it->second->config.motion;
    }
    if (!runsContinuousSoftware(motionConfig.detectionMode)) {
        return;
    }
    std::vector<Rect> regions;
    regions.reserve(event.regions.size());
    for (const MotionRegion& region : event.regions) {
        regions.push_back(region.bounds);
    }
    if (regions.empty()) {
        return;
    }
    onboardProcessor_->onSoftwareMotion(StreamToken{event.streamId, event.generation}, event.timestampMs, event.score, regions);
}

void StreamManager::feedSoftwareAlarmsFromFace(const FaceEvent& event) {
    if (!onboardProcessor_) {
        return;
    }
    FaceConfig faceConfig;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(event.streamId);
        if (it == streams_.end()) {
            return;
        }
        std::lock_guard<std::mutex> ctxLock(it->second->mutex);
        faceConfig = it->second->config.face;
    }
    if (!runsContinuousSoftware(faceConfig.detectionMode)) {
        return;
    }
    std::vector<Rect> regions;
    std::uint64_t trackId = 0;
    double confidence = 0.0;
    for (const FaceTrack& track : event.tracks) {
        regions.push_back(track.bounds);
        trackId = track.trackId;
        confidence = std::max(confidence, track.detectionConfidence);
    }
    if (regions.empty()) {
        return;
    }
    onboardProcessor_->onSoftwareFace(StreamToken{event.streamId, event.generation}, event.timestampMs, confidence, regions, trackId);
}

void StreamManager::feedSoftwareAlarmsFromHazard(const HazardEvent& event) {
    if (!onboardProcessor_) {
        return;
    }
    if (event.type != HazardEventType::Started && event.type != HazardEventType::Updated) {
        return;
    }
    HazardConfig hazardConfig;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(event.streamId);
        if (it == streams_.end()) {
            return;
        }
        std::lock_guard<std::mutex> ctxLock(it->second->mutex);
        hazardConfig = it->second->config.hazard;
    }
    if (!runsContinuousSoftware(hazardConfig.detectionMode)) {
        return;
    }
    std::vector<Rect> regions;
    AlarmType alarmType = AlarmType::Fire;
    double confidence = 0.0;
    for (const HazardRegion& region : event.regions) {
        regions.push_back(region.bounds);
        confidence = std::max(confidence, region.confidence);
        alarmType = region.type == HazardType::Fire ? AlarmType::Fire : AlarmType::Smoke;
    }
    if (regions.empty()) {
        return;
    }
    onboardProcessor_->onSoftwareHazard(StreamToken{event.streamId, event.generation}, alarmType, event.timestampMs, confidence, regions);
}

}  // namespace guardvision
