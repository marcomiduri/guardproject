#pragma once

#include <cstdint>
#include <string>

namespace guardvision {

struct StreamToken {
    std::string streamId;
    std::uint64_t generation = 0;

    bool operator==(const StreamToken& other) const noexcept {
        return generation == other.generation && streamId == other.streamId;
    }
};

}  // namespace guardvision

namespace std {

template <>
struct hash<guardvision::StreamToken> {
    std::size_t operator()(const guardvision::StreamToken& token) const noexcept {
        const std::size_t h1 = std::hash<std::string>{}(token.streamId);
        const std::size_t h2 = std::hash<std::uint64_t>{}(token.generation);
        return h1 ^ (h2 + 0x9e3779b97f4a7c15ULL + (h1 << 6) + (h1 >> 2));
    }
};

}  // namespace std
