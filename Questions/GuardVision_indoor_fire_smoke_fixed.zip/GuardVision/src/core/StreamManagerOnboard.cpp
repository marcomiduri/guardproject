#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

Result StreamManager::submitOnboardCandidate(const OnboardCandidate& candidate) {
    if (!runtimeState_.acceptingSubmissions.load() || !onboardProcessor_) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "OnboardProcessor", candidate.streamId);
    }

    StreamToken token;
    std::uint64_t generation = 0;
    MotionConfig motionConfig;
    FaceConfig faceConfig;
    HazardConfig hazardConfig;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(candidate.streamId);
        if (it == streams_.end()) {
            return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "OnboardProcessor", candidate.streamId);
        }
        std::lock_guard<std::mutex> ctxLock(it->second->mutex);
        token = StreamToken{candidate.streamId, it->second->generation};
        generation = it->second->generation;
        motionConfig = it->second->config.motion;
        faceConfig = it->second->config.face;
        hazardConfig = it->second->config.hazard;
    }

    return onboardProcessor_->submitCandidate(candidate, token, generation, motionConfig, faceConfig, hazardConfig);
}

}  // namespace guardvision
