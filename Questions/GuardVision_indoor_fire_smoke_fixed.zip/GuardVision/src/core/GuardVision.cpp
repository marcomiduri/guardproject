#include <GuardVision.h>
#include <GuardVisionVersion.h>

#include "GuardVisionImpl.h"

namespace guardvision {

const char* GuardVision::version() noexcept {
    return GUARDVISION_VERSION_STRING;
}

GuardVision::GuardVision() : impl_(std::make_unique<Impl>()) {}

GuardVision::~GuardVision() {
    shutdown();
}

GuardVision::GuardVision(GuardVision&&) noexcept = default;

GuardVision& GuardVision::operator=(GuardVision&&) noexcept = default;

Result GuardVision::initialize(const GuardVisionConfig& config) {
    return impl_->initialize(config);
}

void GuardVision::shutdown(ShutdownMode mode) {
    if (impl_) {
        impl_->shutdown(mode);
    }
}

bool GuardVision::isInitialized() const noexcept {
    return impl_ && impl_->isInitialized();
}

Result GuardVision::registerStream(const StreamConfig& config) {
    return impl_->registerStream(config);
}

Result GuardVision::unregisterStream(const std::string& streamId) {
    return impl_->unregisterStream(streamId);
}

Result GuardVision::setMotionConfig(const std::string& streamId, const MotionConfig& config) {
    return impl_->setMotionConfig(streamId, config);
}

Result GuardVision::getMotionConfig(const std::string& streamId, MotionConfig& output) const {
    return impl_->getMotionConfig(streamId, output);
}

SubmitResult GuardVision::submitFrame(VideoFrame frame) {
    return impl_->submitFrame(std::move(frame));
}

Result GuardVision::submitOnboardCandidate(const OnboardCandidate& candidate) {
    return impl_->submitOnboardCandidate(candidate);
}

Result GuardVision::setOnboardConfig(const OnboardConfig& config) {
    return impl_->setOnboardConfig(config);
}

Result GuardVision::getOnboardConfig(OnboardConfig& output) const {
    return impl_->getOnboardConfig(output);
}

Result GuardVision::getStreamStatus(const std::string& streamId, StreamStatus& output) const {
    return impl_->getStreamStatus(streamId, output);
}

Result GuardVision::getStreamMetrics(const std::string& streamId, StreamMetrics& output) const {
    return impl_->getStreamMetrics(streamId, output);
}

Result GuardVision::getMotionMetrics(const std::string& streamId, MotionMetrics& output) const {
    return impl_->getMotionMetrics(streamId, output);
}

Result GuardVision::setFaceConfig(const std::string& streamId, const FaceConfig& config) {
    return impl_->setFaceConfig(streamId, config);
}

Result GuardVision::getFaceConfig(const std::string& streamId, FaceConfig& output) const {
    return impl_->getFaceConfig(streamId, output);
}

Result GuardVision::setFaceRegistry(const FaceRegistry& registry) {
    return impl_->setFaceRegistry(registry);
}

Result GuardVision::getFaceMetrics(const std::string& streamId, FaceMetrics& output) const {
    return impl_->getFaceMetrics(streamId, output);
}

Result GuardVision::setHazardConfig(const std::string& streamId, const HazardConfig& config) {
    return impl_->setHazardConfig(streamId, config);
}

Result GuardVision::getHazardConfig(const std::string& streamId, HazardConfig& output) const {
    return impl_->getHazardConfig(streamId, output);
}

Result GuardVision::getHazardMetrics(const std::string& streamId, HazardMetrics& output) const {
    return impl_->getHazardMetrics(streamId, output);
}

Result GuardVision::getOnboardMetrics(const std::string& streamId, OnboardMetrics& output) const {
    return impl_->getOnboardMetrics(streamId, output);
}

RuntimeMetrics GuardVision::getRuntimeMetrics() const {
    return impl_->getRuntimeMetrics();
}

void GuardVision::setEventListener(IGuardVisionEventListener* listener) {
    impl_->setEventListener(listener);
}

void GuardVision::setEventListener(std::shared_ptr<IGuardVisionEventListener> listener) {
    impl_->setEventListener(std::move(listener));
}

void GuardVision::setEventListener(std::nullptr_t) {
    clearEventListener();
}

void GuardVision::clearEventListener() {
    if (impl_) {
        impl_->clearEventListener();
    }
}

}  // namespace guardvision
