#pragma once

#include <cstdint>
#include <memory>
#include <mutex>

#include <core/StreamConfig.h>
#include <core/StreamState.h>

#include "metrics/FaceMetricsState.h"
#include "metrics/HazardMetricsState.h"
#include "metrics/MetricsRegistry.h"
#include "metrics/MotionMetricsState.h"
#include "metrics/OnboardMetricsState.h"
#include "motion/MotionStreamState.h"

namespace guardvision {

struct StreamContext {
    mutable std::mutex mutex;
    mutable std::mutex motionMutex;
    StreamConfig config;
    std::uint64_t generation = 0;
    StreamState state = StreamState::Registered;

    std::uint64_t acceptedFrameCount = 0;
    std::uint64_t rejectedFrameCount = 0;
    std::uint64_t replacedFrameCount = 0;
    std::uint64_t processedFrameCount = 0;

    std::int64_t lastFrameTimestampMs = 0;
    std::uint64_t lastFrameSequence = 0;

    bool hasAcceptedFrame = false;
    bool stopping = false;

    MotionStreamState motion;

    // Stable metrics ownership for asynchronous work. The registry may remove
    // its lookup entry during stream unregistration, while in-flight jobs keep
    // these states alive until they finish.
    std::shared_ptr<StreamMetricsState> streamMetrics;
    std::shared_ptr<MotionMetricsState> motionMetrics;
    std::shared_ptr<FaceMetricsState> faceMetrics;
    std::shared_ptr<HazardMetricsState> hazardMetrics;
    std::shared_ptr<OnboardMetricsState> onboardMetrics;
};

}  // namespace guardvision
