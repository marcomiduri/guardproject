#include <core/DetectionMode.h>

namespace guardvision {

bool runsContinuousSoftware(DetectionMode mode) noexcept {
    return mode == DetectionMode::Software || mode == DetectionMode::Hybrid;
}

bool acceptsOnboardCandidates(DetectionMode mode) noexcept {
    return mode == DetectionMode::OnboardTriggered || mode == DetectionMode::Hybrid;
}

const char* toString(DetectionMode mode) noexcept {
    switch (mode) {
        case DetectionMode::Disabled:
            return "Disabled";
        case DetectionMode::Software:
            return "Software";
        case DetectionMode::OnboardTriggered:
            return "OnboardTriggered";
        case DetectionMode::Hybrid:
            return "Hybrid";
    }
    return "Unknown";
}

}  // namespace guardvision
