#pragma once

#include <atomic>

namespace guardvision {

struct RuntimeState {
    std::atomic<bool> acceptingSubmissions{false};
    std::atomic<bool> shuttingDown{false};
};

}  // namespace guardvision
