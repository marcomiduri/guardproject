#include "GuardVisionImpl.h"

#include "core/StreamManager.h"
#include "detail/SubmitResultBuilder.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {
namespace {

std::mutex g_runtimeUsersMutex;
std::size_t g_runtimeUsers = 0;

void registerRuntimeUser() {
    std::lock_guard<std::mutex> lock(g_runtimeUsersMutex);
    ++g_runtimeUsers;
}

bool unregisterRuntimeUser() {
    std::lock_guard<std::mutex> lock(g_runtimeUsersMutex);
    if (g_runtimeUsers == 0) {
        return false;
    }
    --g_runtimeUsers;
    return g_runtimeUsers == 0;
}

void shutdownProcessWideEngines() {
#ifdef GUARDVISION_HAVE_FACE
    IdentifyEngine::instance().shutdown();
#endif
#ifdef GUARDVISION_HAVE_HAZARD
    HazardEngine::instance().shutdown();
#endif
}

}  // namespace

GuardVision::Impl::~Impl() {
    shutdown(ShutdownMode::Graceful);
}

Result GuardVision::Impl::notInitializedResult(const std::string& streamId) {
    return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "GuardVision", streamId);
}

Result GuardVision::Impl::initialize(const GuardVisionConfig& config) {
    std::unique_ptr<StreamManager> staleManager;
    {
        std::unique_lock<std::shared_mutex> lock(lifecycleMutex_);
        if (initialized_) {
            return Result::failure(GuardVisionErrorCode::AlreadyInitialized, "GuardVision is already initialized.", "GuardVision");
        }
        if (!isValidGuardVisionConfig(config)) {
            return Result::failure(GuardVisionErrorCode::InvalidConfiguration, "GuardVision configuration is invalid.", "GuardVision");
        }
        if (manager_) {
            if (manager_->isEventDispatchThread()) {
                return Result::failure(GuardVisionErrorCode::AlreadyInitialized,
                                       "GuardVision shutdown is still completing on the event-dispatch thread.", "GuardVision");
            }
            staleManager = std::move(manager_);
        }
    }

    if (staleManager) {
        staleManager->shutdown();
    }

    std::unique_lock<std::shared_mutex> lock(lifecycleMutex_);
    config_ = config;
    manager_ = std::make_unique<StreamManager>(config_, listenerRegistry_);

    const Result started = manager_->start();
    if (!started.ok) {
        manager_.reset();
        return started;
    }

    registerRuntimeUser();
    runtimeUserRegistered_ = true;
    initialized_ = true;
    return Result::success();
}

void GuardVision::Impl::shutdown(ShutdownMode mode) {
    std::unique_ptr<StreamManager> manager;
    bool releaseRuntimeUser = false;
    {
        std::unique_lock<std::shared_mutex> lock(lifecycleMutex_);
        initialized_ = false;
        if (listenerRegistry_) {
            listenerRegistry_->detachAndStop();
        }

        releaseRuntimeUser = runtimeUserRegistered_;
        runtimeUserRegistered_ = false;

        if (manager_) {
            if (manager_->isEventDispatchThread()) {
                // Keep the manager alive until a later call from a non-dispatch
                // thread can join and destroy the EventDispatcher safely. All
                // analytics workers are stopped synchronously by shutdown().
                manager_->shutdown(mode);
            } else {
                manager = std::move(manager_);
            }
        }
    }

    if (manager) {
        manager->shutdown(mode);
    }

    if (releaseRuntimeUser && unregisterRuntimeUser() && mode == ShutdownMode::Graceful) {
        shutdownProcessWideEngines();
    }
}

bool GuardVision::Impl::isInitialized() const noexcept {
    std::shared_lock<std::shared_mutex> lock(lifecycleMutex_);
    return initialized_;
}

Result GuardVision::Impl::registerStream(const StreamConfig& config) {
    return withManager(config.streamId, [&](StreamManager& manager) { return manager.registerStream(config); });
}

Result GuardVision::Impl::unregisterStream(const std::string& streamId) {
    return withManager(streamId, [&](StreamManager& manager) { return manager.unregisterStream(streamId); });
}

Result GuardVision::Impl::setMotionConfig(const std::string& streamId, const MotionConfig& config) {
    return withManager(streamId, [&](StreamManager& manager) { return manager.setMotionConfig(streamId, config); });
}

Result GuardVision::Impl::getMotionConfig(const std::string& streamId, MotionConfig& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getMotionConfig(streamId, output); });
}

SubmitResult GuardVision::Impl::submitFrame(VideoFrame frame) {
    std::shared_lock<std::shared_mutex> lock(lifecycleMutex_);
    if (!initialized_ || !manager_) {
        return detail::makeRejectedSubmitResult(SubmitStatus::NotInitialized, GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.",
                                                "GuardVision", frame.streamId);
    }
    return manager_->submitFrame(std::move(frame));
}

Result GuardVision::Impl::submitOnboardCandidate(const OnboardCandidate& candidate) {
    return withManager(candidate.streamId, [&](StreamManager& manager) { return manager.submitOnboardCandidate(candidate); });
}

Result GuardVision::Impl::setOnboardConfig(const OnboardConfig& config) {
    return withManager({}, [&](StreamManager& manager) { return manager.setOnboardConfig(config); });
}

Result GuardVision::Impl::getOnboardConfig(OnboardConfig& output) const {
    return withManager({}, [&](const StreamManager& manager) { return manager.getOnboardConfig(output); });
}

Result GuardVision::Impl::getStreamStatus(const std::string& streamId, StreamStatus& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getStreamStatus(streamId, output); });
}

Result GuardVision::Impl::getStreamMetrics(const std::string& streamId, StreamMetrics& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getStreamMetrics(streamId, output); });
}

Result GuardVision::Impl::getMotionMetrics(const std::string& streamId, MotionMetrics& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getMotionMetrics(streamId, output); });
}

Result GuardVision::Impl::setFaceConfig(const std::string& streamId, const FaceConfig& config) {
    return withManager(streamId, [&](StreamManager& manager) { return manager.setFaceConfig(streamId, config); });
}

Result GuardVision::Impl::getFaceConfig(const std::string& streamId, FaceConfig& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getFaceConfig(streamId, output); });
}

Result GuardVision::Impl::setFaceRegistry(const FaceRegistry& registry) {
    std::shared_lock<std::shared_mutex> lock(lifecycleMutex_);
    if (!initialized_ || !manager_) {
        return notInitializedResult({});
    }
#ifdef GUARDVISION_HAVE_FACE
    return IdentifyEngine::instance().setFaceRegistry(registry);
#else
    (void)registry;
    return Result::failure(GuardVisionErrorCode::FaceEngineInitializationFailed, "GuardVision was built without face support.", "GuardVision");
#endif
}

Result GuardVision::Impl::getFaceMetrics(const std::string& streamId, FaceMetrics& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getFaceMetrics(streamId, output); });
}

Result GuardVision::Impl::setHazardConfig(const std::string& streamId, const HazardConfig& config) {
    return withManager(streamId, [&](StreamManager& manager) { return manager.setHazardConfig(streamId, config); });
}

Result GuardVision::Impl::getHazardConfig(const std::string& streamId, HazardConfig& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getHazardConfig(streamId, output); });
}

Result GuardVision::Impl::getHazardMetrics(const std::string& streamId, HazardMetrics& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getHazardMetrics(streamId, output); });
}

Result GuardVision::Impl::getOnboardMetrics(const std::string& streamId, OnboardMetrics& output) const {
    return withManager(streamId, [&](const StreamManager& manager) { return manager.getOnboardMetrics(streamId, output); });
}

RuntimeMetrics GuardVision::Impl::getRuntimeMetrics() const {
    std::shared_lock<std::shared_mutex> lock(lifecycleMutex_);
    if (!initialized_ || !manager_) {
        return RuntimeMetrics{};
    }
    return manager_->getRuntimeMetrics();
}

void GuardVision::Impl::setEventListener(IGuardVisionEventListener* listener) {
    if (listenerRegistry_) {
        listenerRegistry_->setListener(listener);
    }
}

void GuardVision::Impl::setEventListener(std::shared_ptr<IGuardVisionEventListener> listener) {
    if (listenerRegistry_) {
        listenerRegistry_->setListener(std::move(listener));
    }
}

void GuardVision::Impl::clearEventListener() {
    if (listenerRegistry_) {
        listenerRegistry_->detachAndStop();
    }
}

}  // namespace guardvision
