#include "core/StreamManager.h"

#include <utility>

#include <core/DetectionMode.h>

namespace guardvision {

void StreamManager::processMotionJob(FrameRoutingJob job) {
    const StreamToken token = job.token;
    const std::shared_ptr<StreamContext> context = findStreamContext(token.streamId);
    const std::shared_ptr<StreamMetricsState> streamMetrics = context ? context->streamMetrics : nullptr;

    const auto complete = [&](bool reschedule) {
        if (motionScheduler_) {
            motionScheduler_->complete(token, reschedule);
        }
    };

    if (!context || !streamMetrics || !context->motionMetrics) {
        metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        if (streamMetrics) {
            streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        }
        complete(false);
        return;
    }

    MotionConfig motionConfig;
    {
        std::lock_guard<std::mutex> lock(context->mutex);
        if (context->stopping || context->generation != token.generation || context->state != StreamState::Active) {
            metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
            streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
            context->motionMetrics->staleWorkDiscarded.fetch_add(1, std::memory_order_relaxed);
            complete(false);
            return;
        }
        motionConfig = context->config.motion;
    }

    if (!runsContinuousSoftware(motionConfig.detectionMode)) {
        complete(true);
        return;
    }

    MotionProcessResult motionResult;
    {
        std::lock_guard<std::mutex> motionLock(context->motionMutex);
        motionResult = motionProcessor_.processFrame(job.frame, token, context->motion, *context->motionMetrics);
    }

    bool active = false;
    {
        std::lock_guard<std::mutex> lock(context->mutex);
        active = !context->stopping && context->generation == token.generation && context->state == StreamState::Active;
    }

    if (!active) {
        metrics_.runtime().staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        streamMetrics->staleJobsDiscarded.fetch_add(1, std::memory_order_relaxed);
        context->motionMetrics->staleWorkDiscarded.fetch_add(1, std::memory_order_relaxed);
        complete(false);
        return;
    }

    if (motionResult.hadError && dispatcher_) {
        RuntimeEvent errorEvent;
        errorEvent.type = RuntimeEventType::Error;
        errorEvent.error = std::move(motionResult.error);
        dispatcher_->post(std::move(errorEvent));
    }
    if (!motionResult.events.empty()) {
        postMotionEvents(std::move(motionResult.events));
    }

    complete(true);
}

}  // namespace guardvision
