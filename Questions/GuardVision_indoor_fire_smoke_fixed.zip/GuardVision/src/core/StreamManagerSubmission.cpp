#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

SubmitResult StreamManager::submitFrame(VideoFrame frame) {
    if (!runtimeState_.acceptingSubmissions.load()) {
        return detail::makeRejectedSubmitResult(SubmitStatus::NotInitialized, GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.",
                                                "StreamManager", frame.streamId);
    }

    metrics_.runtime().submittedFrames.fetch_add(1);

    std::shared_ptr<StreamContext> context;
    StreamToken token;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(frame.streamId);
        if (it == streams_.end()) {
            metrics_.runtime().rejectedFrames.fetch_add(1);
            return detail::makeRejectedSubmitResult(SubmitStatus::StreamNotRegistered, GuardVisionErrorCode::StreamNotFound,
                                                    "Stream ID is not registered.", "StreamManager", frame.streamId);
        }
        context = it->second;
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        if (context->stopping || context->state == StreamState::Stopping) {
            metrics_.runtime().rejectedFrames.fetch_add(1);
            if (context->streamMetrics) {
                context->streamMetrics->rejectedFrames.fetch_add(1);
            }
            return detail::makeRejectedSubmitResult(SubmitStatus::StreamStopping, GuardVisionErrorCode::StreamNotFound, "Stream is stopping.",
                                                    "StreamManager", frame.streamId);
        }
        token = StreamToken{frame.streamId, context->generation};
    }

    const std::shared_ptr<StreamMetricsState> streamMetrics = context->streamMetrics;
    if (!streamMetrics) {
        metrics_.runtime().rejectedFrames.fetch_add(1);
        return detail::makeRejectedSubmitResult(SubmitStatus::InvalidFrame, GuardVisionErrorCode::InternalError,
                                                "Stream metrics state is unavailable.", "StreamManager", frame.streamId);
    }
    streamMetrics->submittedFrames.fetch_add(1);

    if (!frame.isValid()) {
        metrics_.runtime().rejectedFrames.fetch_add(1);
        streamMetrics->rejectedFrames.fetch_add(1);
        return detail::makeRejectedSubmitResult(SubmitStatus::InvalidFrame, GuardVisionErrorCode::InvalidFrame,
                                                "VideoFrame failed structural validation.", "StreamManager", frame.streamId);
    }

    {
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        SubmitResult policy = validateSubmissionPolicy(*context, frame);
        if (!policy.accepted) {
            metrics_.runtime().rejectedFrames.fetch_add(1);
            streamMetrics->rejectedFrames.fetch_add(1);
            return policy;
        }

        context->hasAcceptedFrame = true;
        context->lastFrameSequence = frame.sequence;
        context->lastFrameTimestampMs = frame.timestampMs;
        ++context->acceptedFrameCount;
    }

    metrics_.runtime().acceptedFrames.fetch_add(1);
    streamMetrics->acceptedFrames.fetch_add(1);

    frameStore_.update(token, frame);

    FrameRoutingJob job;
    job.token = token;
    job.submittedAtMs = detail::steadyNowMs();
    job.frame = std::move(frame);

    const SchedulerSubmitResult scheduleResult = scheduler_->submit(std::move(job));
    streamMetrics->hasPendingFrame.store(scheduleResult.hasPending, std::memory_order_relaxed);
    streamMetrics->processingFrame.store(scheduleResult.processing, std::memory_order_relaxed);

    if (scheduleResult.queueOverflow) {
        metrics_.runtime().queueOverflowCount.fetch_add(1);
        streamMetrics->queueOverflowCount.fetch_add(1);
        GuardVisionError error;
        error.code = GuardVisionErrorCode::InternalError;
        error.component = "StreamManager";
        error.streamId = token.streamId;
        error.message = "Ready stream queue overflow.";
        error.recoverable = true;
        if (dispatcher_) {
            RuntimeEvent event;
            event.type = RuntimeEventType::Error;
            event.error = error;
            dispatcher_->post(std::move(event));
        }
    }

    SubmitResult result;
    result.accepted = true;
    if (scheduleResult.replacedPending) {
        result.status = SubmitStatus::ReplacedOlderPendingFrame;
        metrics_.runtime().replacedFrames.fetch_add(1);
        streamMetrics->replacedFrames.fetch_add(1);
    } else {
        result.status = SubmitStatus::Accepted;
    }
    return result;
}

bool StreamManager::isTokenActive(const StreamToken& token) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    const auto it = streams_.find(token.streamId);
    if (it == streams_.end()) {
        return false;
    }
    std::lock_guard<std::mutex> ctxLock(it->second->mutex);
    return !it->second->stopping && it->second->generation == token.generation && it->second->state == StreamState::Active;
}

std::shared_ptr<StreamContext> StreamManager::findStreamContext(const std::string& streamId) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    const auto it = streams_.find(streamId);
    return it != streams_.end() ? it->second : nullptr;
}

SubmitResult StreamManager::validateSubmissionPolicy(StreamContext& context, const VideoFrame& frame) const {
    if (!context.hasAcceptedFrame) {
        return detail::makeAcceptedSubmitResult();
    }

    if (frame.sequence < context.lastFrameSequence) {
        return detail::makeRejectedSubmitResult(SubmitStatus::InvalidSequence, GuardVisionErrorCode::InvalidFrameSequence,
                                                "Frame sequence regressed below the last accepted sequence.", "StreamManager", frame.streamId);
    }

    if (frame.sequence == context.lastFrameSequence) {
        if (frame.timestampMs != context.lastFrameTimestampMs) {
            return detail::makeRejectedSubmitResult(SubmitStatus::InvalidTimestamp, GuardVisionErrorCode::InvalidFrameTimestamp,
                                                    "Equal sequence requires an equal timestamp for intentional still-frame resubmission.",
                                                    "StreamManager", frame.streamId);
        }
    } else if (frame.timestampMs < context.lastFrameTimestampMs) {
        return detail::makeRejectedSubmitResult(SubmitStatus::InvalidTimestamp, GuardVisionErrorCode::InvalidFrameTimestamp,
                                                "Frame timestamp regressed below the last accepted timestamp.", "StreamManager", frame.streamId);
    }

    return detail::makeAcceptedSubmitResult();
}

}  // namespace guardvision
