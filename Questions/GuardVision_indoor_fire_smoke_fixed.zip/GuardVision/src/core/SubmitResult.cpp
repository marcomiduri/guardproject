#include <core/SubmitResult.h>

namespace guardvision {

const char* toString(SubmitStatus status) noexcept {
    switch (status) {
        case SubmitStatus::Accepted:
            return "Accepted";
        case SubmitStatus::ReplacedOlderPendingFrame:
            return "ReplacedOlderPendingFrame";
        case SubmitStatus::StreamNotRegistered:
            return "StreamNotRegistered";
        case SubmitStatus::InvalidFrame:
            return "InvalidFrame";
        case SubmitStatus::InvalidSequence:
            return "InvalidSequence";
        case SubmitStatus::InvalidTimestamp:
            return "InvalidTimestamp";
        case SubmitStatus::StreamStopping:
            return "StreamStopping";
        case SubmitStatus::NotInitialized:
            return "NotInitialized";
        case SubmitStatus::QueueUnavailable:
            return "QueueUnavailable";
        case SubmitStatus::InternalError:
            return "InternalError";
    }
    return "Unknown";
}

}  // namespace guardvision
