#include <core/Result.h>

namespace guardvision {

Result Result::success() {
    Result result;
    result.ok = true;
    result.error.code = GuardVisionErrorCode::None;
    return result;
}

Result Result::failure(GuardVisionErrorCode code, const std::string& message, const std::string& component, const std::string& streamId) {
    Result result;
    result.ok = false;
    result.error.code = code;
    result.error.message = message;
    result.error.component = component;
    result.error.streamId = streamId;
    return result;
}

}  // namespace guardvision
