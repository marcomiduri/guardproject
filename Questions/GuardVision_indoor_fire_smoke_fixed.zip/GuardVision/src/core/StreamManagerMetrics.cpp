#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

Result StreamManager::getStreamStatus(const std::string& streamId, StreamStatus& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    const auto it = streams_.find(streamId);
    if (it == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }

    const StreamToken token{streamId, it->second->generation};
    const bool pending = scheduler_ ? scheduler_->hasPending(token) : false;
    const bool processing = scheduler_ ? scheduler_->isProcessing(token) : false;
    output = buildStatus(*it->second, token, pending, processing);
    return Result::success();
}

Result StreamManager::getStreamMetrics(const std::string& streamId, StreamMetrics& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    if (streams_.find(streamId) == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }

    const StreamToken token{streamId, streams_.at(streamId)->generation};
    const bool pending = scheduler_ ? scheduler_->hasPending(token) : false;
    const bool processing = scheduler_ ? scheduler_->isProcessing(token) : false;
    output = metrics_.snapshotStream(streamId, pending, processing);
    return Result::success();
}

RuntimeMetrics StreamManager::getRuntimeMetrics() const {
    const std::uint64_t dispatched = dispatcher_ ? dispatcher_->dispatchedEvents() : 0;
    const std::uint64_t dropped = dispatcher_ ? dispatcher_->droppedEvents() : 0;
    return metrics_.snapshotRuntime(dispatched, dropped);
}

Result StreamManager::getMotionMetrics(const std::string& streamId, MotionMetrics& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    if (streams_.find(streamId) == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    output = metrics_.snapshotMotion(streamId);
    return Result::success();
}

Result StreamManager::getFaceMetrics(const std::string& streamId, FaceMetrics& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    if (streams_.find(streamId) == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    output = metrics_.snapshotFace(streamId);
    return Result::success();
}

StreamStatus StreamManager::buildStatus(const StreamContext& context, const StreamToken& token, bool pending, bool processing) const {
    StreamStatus status;
    status.streamId = context.config.streamId;
    status.state = context.state;
    status.acceptingFrames = !context.stopping && context.state != StreamState::Stopping && context.state != StreamState::Stopped;
    status.hasPendingFrame = pending;
    status.processingFrame = processing;
    status.generation = token.generation;
    status.lastAcceptedSequence = context.lastFrameSequence;
    status.lastAcceptedTimestampMs = context.lastFrameTimestampMs;
    return status;
}

void StreamManager::emitStreamStatus(const StreamContext& context, const StreamToken& token, bool pending, bool processing) {
    if (!dispatcher_) {
        return;
    }
    RuntimeEvent event;
    event.type = RuntimeEventType::StreamStatus;
    event.status = buildStatus(context, token, pending, processing);
    dispatcher_->post(std::move(event));
}

Result StreamManager::getHazardMetrics(const std::string& streamId, HazardMetrics& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    if (streams_.find(streamId) == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    output = metrics_.snapshotHazard(streamId);
    return Result::success();
}

Result StreamManager::getOnboardMetrics(const std::string& streamId, OnboardMetrics& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    if (streams_.find(streamId) == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    output = metrics_.snapshotOnboard(streamId);
    return Result::success();
}

}  // namespace guardvision
