#include <core/GuardVisionConfig.h>

namespace guardvision {

bool isValidGuardVisionConfig(const GuardVisionConfig& config) noexcept {
    if (config.maxStreams < 1 || config.maxStreams > kGuardVisionMaxStreamsUpperBound) {
        return false;
    }
    if (config.frameWorkerCount < 1 || config.frameWorkerCount > kGuardVisionMaxFrameWorkers) {
        return false;
    }
    if (config.motionWorkerCount < 1 || config.motionWorkerCount > kGuardVisionMaxMotionWorkers) {
        return false;
    }
    if (config.faceWorkerCount < 1 || config.faceWorkerCount > kGuardVisionMaxFaceWorkers) {
        return false;
    }
    if (config.hazardWorkerCount < 1 || config.hazardWorkerCount > kGuardVisionMaxHazardWorkers) {
        return false;
    }
    if (config.eventQueueCapacity < kGuardVisionMinEventQueueCapacity || config.eventQueueCapacity > kGuardVisionMaxEventQueueCapacity) {
        return false;
    }
    if (config.readyStreamQueueCapacity < kGuardVisionMinReadyStreamQueueCapacity ||
        config.readyStreamQueueCapacity > kGuardVisionMaxReadyStreamQueueCapacity) {
        return false;
    }
    return true;
}

}  // namespace guardvision
