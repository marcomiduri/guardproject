#pragma once

#include <memory>
#include <mutex>
#include <shared_mutex>
#include <string>

#include <GuardVision.h>
#include "core/StreamManager.h"
#include "events/EventListenerRegistry.h"

#include <events/EventListener.h>
#include <core/GuardVisionConfig.h>
#include <face/FaceConfig.h>
#include <face/FaceMetrics.h>
#include <hazard/HazardConfig.h>
#include <hazard/HazardMetrics.h>
#include <motion/MotionConfig.h>
#include <onboard/OnboardConfig.h>
#include <onboard/OnboardMetrics.h>
#include <onboard/OnboardTypes.h>
#include <core/StreamStatus.h>

namespace guardvision {

class GuardVision::Impl {
public:
    ~Impl();

    Result initialize(const GuardVisionConfig& config);
    void shutdown(ShutdownMode mode = ShutdownMode::Graceful);
    bool isInitialized() const noexcept;

    Result registerStream(const StreamConfig& config);
    Result unregisterStream(const std::string& streamId);
    Result setMotionConfig(const std::string& streamId, const MotionConfig& config);
    Result getMotionConfig(const std::string& streamId, MotionConfig& output) const;
    Result setFaceConfig(const std::string& streamId, const FaceConfig& config);
    Result getFaceConfig(const std::string& streamId, FaceConfig& output) const;
    Result setFaceRegistry(const FaceRegistry& registry);
    Result setHazardConfig(const std::string& streamId, const HazardConfig& config);
    Result getHazardConfig(const std::string& streamId, HazardConfig& output) const;

    SubmitResult submitFrame(VideoFrame frame);
    Result submitOnboardCandidate(const OnboardCandidate& candidate);

    Result setOnboardConfig(const OnboardConfig& config);
    Result getOnboardConfig(OnboardConfig& output) const;

    Result getStreamStatus(const std::string& streamId, StreamStatus& output) const;
    Result getStreamMetrics(const std::string& streamId, StreamMetrics& output) const;
    Result getMotionMetrics(const std::string& streamId, MotionMetrics& output) const;
    Result getFaceMetrics(const std::string& streamId, FaceMetrics& output) const;
    Result getHazardMetrics(const std::string& streamId, HazardMetrics& output) const;
    Result getOnboardMetrics(const std::string& streamId, OnboardMetrics& output) const;
    RuntimeMetrics getRuntimeMetrics() const;

    void setEventListener(IGuardVisionEventListener* listener);
    void setEventListener(std::shared_ptr<IGuardVisionEventListener> listener);
    void clearEventListener();

private:
    template <typename Operation>
    Result withManager(const std::string& streamId, Operation&& operation) {
        std::shared_lock<std::shared_mutex> lock(lifecycleMutex_);
        if (!initialized_ || !manager_) {
            return notInitializedResult(streamId);
        }
        return operation(*manager_);
    }

    template <typename Operation>
    Result withManager(const std::string& streamId, Operation&& operation) const {
        std::shared_lock<std::shared_mutex> lock(lifecycleMutex_);
        if (!initialized_ || !manager_) {
            return notInitializedResult(streamId);
        }
        return operation(*manager_);
    }

    static Result notInitializedResult(const std::string& streamId);

    mutable std::shared_mutex lifecycleMutex_;
    bool initialized_ = false;
    bool runtimeUserRegistered_ = false;
    GuardVisionConfig config_{};
    std::unique_ptr<StreamManager> manager_;
    EventListenerRegistryPtr listenerRegistry_ = std::make_shared<EventListenerRegistry>();
};

}  // namespace guardvision
