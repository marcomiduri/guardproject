#include "core/StreamManager.h"

#include <chrono>
#include <thread>
#include <utility>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "detail/SubmitResultBuilder.h"
#include "detail/TimeUtil.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {

StreamManager::StreamManager(GuardVisionConfig config, EventListenerRegistryPtr listenerRegistry)
: config_(config), listenerRegistry_(std::move(listenerRegistry)) {}

StreamManager::~StreamManager() {
    shutdown();
}

Result StreamManager::start() {
    dispatcher_ = std::make_unique<EventDispatcher>(static_cast<std::size_t>(config_.eventQueueCapacity), [this]() {
        return listenerRegistry_ ? listenerRegistry_->acquire() : EventListenerRegistry::Lease{};
    });

    motionScheduler_ = std::make_unique<FrameScheduler>(static_cast<std::size_t>(config_.readyStreamQueueCapacity),
                                                        [this](FrameRoutingJob job) { processMotionJob(std::move(job)); });
    motionScheduler_->startWorkers(config_.motionWorkerCount);

    scheduler_ = std::make_unique<FrameScheduler>(static_cast<std::size_t>(config_.readyStreamQueueCapacity),
                                                  [this](FrameRoutingJob job) { processRoutingJob(std::move(job)); });

    faceScheduler_ = std::make_unique<FaceScheduler>([this](std::vector<FaceEvent> events) { postFaceEvents(std::move(events)); },
                                                     [this](GuardVisionError error) {
                                                         if (dispatcher_) {
                                                             RuntimeEvent event;
                                                             event.type = RuntimeEventType::Error;
                                                             event.error = std::move(error);
                                                             dispatcher_->post(std::move(event));
                                                         }
                                                     });
    faceScheduler_->setConfirmationCallback([this](FaceRegionalConfirmationResult result) {
        if (onboardProcessor_) {
            onboardProcessor_->onFaceConfirmation(std::move(result));
        }
    });
    faceScheduler_->setActiveTokenValidator([this](const StreamToken& token) { return isTokenActive(token); });
    faceScheduler_->start(config_.faceWorkerCount);

    hazardScheduler_ = std::make_unique<HazardScheduler>([this](std::vector<HazardEvent> events) { postHazardEvents(std::move(events)); },
                                                         [this](GuardVisionError error) {
                                                             if (dispatcher_) {
                                                                 RuntimeEvent event;
                                                                 event.type = RuntimeEventType::Error;
                                                                 event.error = std::move(error);
                                                                 dispatcher_->post(std::move(event));
                                                             }
                                                         });
    hazardScheduler_->setConfirmationCallback([this](HazardRegionalConfirmationResult result) {
        if (onboardProcessor_) {
            onboardProcessor_->onHazardConfirmation(std::move(result));
        }
    });
    hazardScheduler_->setActiveTokenValidator([this](const StreamToken& token) { return isTokenActive(token); });
    hazardScheduler_->start(config_.hazardWorkerCount);

    OnboardConfig onboardConfig;
    {
        std::lock_guard<std::mutex> lock(onboardConfigMutex_);
        onboardConfig = onboardConfig_;
    }
    onboardProcessor_ = std::make_unique<OnboardProcessor>(onboardConfig);
    onboardProcessor_->setCallbacks(AlarmDispatchCallback{[this](const AlarmEvent& event) {
                                                              if (isTokenActive(StreamToken{event.streamId, event.generation})) {
                                                                  postAlarmEvent(event);
                                                              }
                                                          },
                                                          [this](const GuardVisionError& error) {
                                                              if (dispatcher_) {
                                                                  RuntimeEvent runtimeEvent;
                                                                  runtimeEvent.type = RuntimeEventType::Error;
                                                                  runtimeEvent.error = error;
                                                                  dispatcher_->post(std::move(runtimeEvent));
                                                              }
                                                          }});
    onboardProcessor_->setActiveTokenValidator([this](const StreamToken& token) { return isTokenActive(token); });
    onboardProcessor_->setRegionalConfirmationSchedulers(faceScheduler_.get(), hazardScheduler_.get());
    onboardProcessor_->start();

    scheduler_->startWorkers(config_.frameWorkerCount);
    runtimeState_.acceptingSubmissions = true;
    runtimeState_.shuttingDown = false;
    return Result::success();
}

void StreamManager::shutdown(ShutdownMode mode) {
    std::lock_guard<std::mutex> shutdownLock(shutdownMutex_);
    const bool calledFromDispatcher = isEventDispatchThread();

    runtimeState_.acceptingSubmissions = false;
    runtimeState_.shuttingDown = true;

    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        for (auto& entry : streams_) {
            std::lock_guard<std::mutex> ctxLock(entry.second->mutex);
            entry.second->stopping = true;
            entry.second->state = StreamState::Stopping;
        }
    }

    if (scheduler_) {
        scheduler_->stop();
        scheduler_->joinWorkers();
        scheduler_.reset();
    }

    if (motionScheduler_) {
        motionScheduler_->stop();
        motionScheduler_->joinWorkers();
        motionScheduler_.reset();
    }

    if (faceScheduler_) {
        faceScheduler_->stop(mode == ShutdownMode::Graceful);
        faceScheduler_->join();
        faceScheduler_.reset();
    }

    if (hazardScheduler_) {
        hazardScheduler_->stop();
        hazardScheduler_->join();
        hazardScheduler_.reset();
    }

    if (onboardProcessor_) {
        onboardProcessor_->stop();
        onboardProcessor_->join();
        onboardProcessor_.reset();
    }

    frameStore_.clear();

    if (dispatcher_) {
        dispatcher_->stop();
        if (!calledFromDispatcher) {
            dispatcher_->join();
            dispatcher_.reset();
        }
    }

    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        streams_.clear();
    }

    metrics_.clear();
}

bool StreamManager::isEventDispatchThread() const noexcept {
    return dispatcher_ != nullptr && dispatcher_->isDispatchThread();
}

}  // namespace guardvision
