#include <core/StreamConfig.h>

#include <cctype>

namespace guardvision {

bool isValidStreamId(const std::string& streamId) noexcept {
    if (streamId.empty() || streamId.size() > kMaxStreamIdLength) {
        return false;
    }
    for (const char ch : streamId) {
        if (static_cast<unsigned char>(ch) < 0x20 || ch == 0x7F) {
            return false;
        }
    }
    return true;
}

}  // namespace guardvision
