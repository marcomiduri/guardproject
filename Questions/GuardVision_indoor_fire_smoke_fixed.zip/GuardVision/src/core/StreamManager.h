#pragma once

#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>

#include <events/EventListener.h>
#include <core/GuardVisionConfig.h>
#include <face/FaceConfig.h>
#include <face/FaceMetrics.h>
#include <hazard/HazardConfig.h>
#include <hazard/HazardMetrics.h>
#include <motion/MotionConfig.h>
#include <motion/MotionMetrics.h>
#include <core/Result.h>
#include <core/StreamConfig.h>
#include <core/SubmitResult.h>
#include <frame/VideoFrame.h>
#include <core/StreamMetrics.h>
#include <core/ShutdownMode.h>
#include <core/StreamStatus.h>
#include <onboard/OnboardConfig.h>
#include <onboard/OnboardMetrics.h>
#include <onboard/OnboardTypes.h>

#include "core/RuntimeState.h"
#include "core/StreamContext.h"
#include "core/StreamToken.h"
#include "events/EventDispatcher.h"
#include "events/EventListenerRegistry.h"
#include "frame/LatestFrameStore.h"
#include "metrics/MetricsRegistry.h"
#include "face/FaceScheduler.h"
#include "hazard/HazardScheduler.h"
#include "motion/MotionProcessor.h"
#include "onboard/OnboardProcessor.h"
#include "scheduling/FrameScheduler.h"

namespace guardvision {

class StreamManager {
public:
    StreamManager(GuardVisionConfig config, EventListenerRegistryPtr listenerRegistry);
    ~StreamManager();

    StreamManager(const StreamManager&) = delete;
    StreamManager& operator=(const StreamManager&) = delete;

    Result start();
    void shutdown(ShutdownMode mode = ShutdownMode::Graceful);
    bool isEventDispatchThread() const noexcept;

    Result registerStream(const StreamConfig& config);
    Result unregisterStream(const std::string& streamId);
    Result setMotionConfig(const std::string& streamId, const MotionConfig& config);
    Result getMotionConfig(const std::string& streamId, MotionConfig& output) const;
    Result setFaceConfig(const std::string& streamId, const FaceConfig& config);
    Result getFaceConfig(const std::string& streamId, FaceConfig& output) const;
    Result setHazardConfig(const std::string& streamId, const HazardConfig& config);
    Result getHazardConfig(const std::string& streamId, HazardConfig& output) const;

    SubmitResult submitFrame(VideoFrame frame);
    Result submitOnboardCandidate(const OnboardCandidate& candidate);

    Result setOnboardConfig(const OnboardConfig& config);
    Result getOnboardConfig(OnboardConfig& output) const;

    Result getStreamStatus(const std::string& streamId, StreamStatus& output) const;
    Result getStreamMetrics(const std::string& streamId, StreamMetrics& output) const;
    Result getMotionMetrics(const std::string& streamId, MotionMetrics& output) const;
    Result getFaceMetrics(const std::string& streamId, FaceMetrics& output) const;
    Result getHazardMetrics(const std::string& streamId, HazardMetrics& output) const;
    Result getOnboardMetrics(const std::string& streamId, OnboardMetrics& output) const;
    RuntimeMetrics getRuntimeMetrics() const;

private:
    bool isTokenActive(const StreamToken& token) const;
    std::shared_ptr<StreamContext> findStreamContext(const std::string& streamId) const;
    SubmitResult validateSubmissionPolicy(StreamContext& context, const VideoFrame& frame) const;
    StreamStatus buildStatus(const StreamContext& context, const StreamToken& token, bool pending, bool processing) const;
    void emitStreamStatus(const StreamContext& context, const StreamToken& token, bool pending, bool processing);
    void postMotionEvents(std::vector<MotionEvent> events);
    void postFaceEvents(std::vector<FaceEvent> events);
    void postHazardEvents(std::vector<HazardEvent> events);
    void postAlarmEvent(AlarmEvent event);
    void feedSoftwareAlarmsFromMotion(const MotionEvent& event);
    void feedSoftwareAlarmsFromFace(const FaceEvent& event);
    void feedSoftwareAlarmsFromHazard(const HazardEvent& event);
    void applyMotionConfigLocked(StreamContext& context, const MotionConfig& config);
    void processRoutingJob(FrameRoutingJob job);
    void processMotionJob(FrameRoutingJob job);
    Result ensureIdentifyEngine() const;
    Result ensureHazardEngine(const HazardConfig& config) const;

    GuardVisionConfig config_;
    OnboardConfig onboardConfig_{};
    mutable std::mutex onboardConfigMutex_;
    RuntimeState runtimeState_;
    std::atomic<std::uint64_t> nextGeneration_{1};
    MotionProcessor motionProcessor_;
    std::unique_ptr<FaceScheduler> faceScheduler_;
    std::unique_ptr<HazardScheduler> hazardScheduler_;
    std::unique_ptr<OnboardProcessor> onboardProcessor_;

    mutable std::mutex mapMutex_;
    std::unordered_map<std::string, std::shared_ptr<StreamContext>> streams_;

    LatestFrameStore frameStore_;
    MetricsRegistry metrics_;
    std::unique_ptr<EventDispatcher> dispatcher_;
    std::unique_ptr<FrameScheduler> scheduler_;
    std::unique_ptr<FrameScheduler> motionScheduler_;
    EventListenerRegistryPtr listenerRegistry_;
    mutable std::mutex shutdownMutex_;
};

}  // namespace guardvision
