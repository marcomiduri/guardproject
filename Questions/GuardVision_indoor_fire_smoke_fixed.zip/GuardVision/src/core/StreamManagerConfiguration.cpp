#include "core/StreamManager.h"

#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>

#include "detail/ConfigNormalization.h"
#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"

namespace guardvision {
namespace {

template <typename Scheduler, typename Config, typename MetricsPtr>
void updateSchedulerRegistration(Scheduler* scheduler, bool wasEnabled, bool nowEnabled, const StreamToken& token, const Config& config,
                                 const MetricsPtr& metrics) {
    if (!scheduler) {
        return;
    }
    if (wasEnabled && !nowEnabled) {
        scheduler->unregisterStream(token);
    } else if (!wasEnabled && nowEnabled) {
        scheduler->registerStream(token, config, metrics);
    } else if (wasEnabled && nowEnabled) {
        scheduler->updateStreamConfig(token, config);
    }
}

}  // namespace

Result StreamManager::setMotionConfig(const std::string& streamId, const MotionConfig& config) {
    MotionConfig normalized = config;
    normalizeMotionConfig(normalized);
    if (!runtimeState_.acceptingSubmissions.load()) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "StreamManager", streamId);
    }
    if (!isValidMotionConfig(normalized)) {
        return Result::failure(GuardVisionErrorCode::InvalidMotionConfiguration, "Motion configuration is invalid.", "StreamManager", streamId);
    }

    StreamToken token;
    MotionEvent endedEvent;
    bool emitEnded = false;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(streamId);
        if (it == streams_.end()) {
            return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
        }

        std::lock_guard<std::mutex> ctxLock(it->second->mutex);
        std::lock_guard<std::mutex> motionLock(it->second->motionMutex);
        token = StreamToken{streamId, it->second->generation};
        const bool wasActive = it->second->motion.state == MotionState::Active || it->second->motion.state == MotionState::Clearing;
        if (!isMotionAnalyticActive(normalized) && wasActive) {
            endedEvent = motionProcessor_.makeEndedEvent(it->second->motion, token, it->second->lastFrameSequence, it->second->lastFrameTimestampMs);
            emitEnded = true;
        }
        applyMotionConfigLocked(*it->second, normalized);
        it->second->config.motion = normalized;
    }

    MotionMetricsState& motionMetricState = metrics_.motionMetrics(streamId);
    motionMetricState.enabled = isMotionAnalyticActive(normalized);
    motionMetricState.state = MotionState::Idle;

    if (emitEnded) {
        postMotionEvents({endedEvent});
    }
    if (onboardProcessor_) {
        FaceConfig faceConfig;
        HazardConfig hazardConfig;
        if (std::shared_ptr<StreamContext> context = findStreamContext(streamId)) {
            std::lock_guard<std::mutex> ctxLock(context->mutex);
            faceConfig = context->config.face;
            hazardConfig = context->config.hazard;
        }
        onboardProcessor_->updateStreamConfig(token, normalized, faceConfig, hazardConfig);
    }
    return Result::success();
}

Result StreamManager::getMotionConfig(const std::string& streamId, MotionConfig& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    const auto it = streams_.find(streamId);
    if (it == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    std::lock_guard<std::mutex> ctxLock(it->second->mutex);
    output = it->second->motion.config;
    return Result::success();
}

Result StreamManager::setFaceConfig(const std::string& streamId, const FaceConfig& config) {
    FaceConfig normalized = config;
    normalizeFaceConfig(normalized);
    if (!runtimeState_.acceptingSubmissions.load()) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "StreamManager", streamId);
    }
    if (!isValidFaceConfig(normalized)) {
        return Result::failure(GuardVisionErrorCode::InvalidFaceConfiguration, "Face configuration is invalid.", "StreamManager", streamId);
    }
    if (normalized.processingLevel != FaceProcessingLevel::Disabled && !isSupportedFaceTriggerMode(normalized.triggerMode)) {
        return Result::failure(GuardVisionErrorCode::UnsupportedFaceTriggerMode, "Face trigger mode is not supported.", "StreamManager", streamId);
    }
    if (normalized.processingLevel != FaceProcessingLevel::Disabled) {
        const Result engineResult = ensureIdentifyEngine();
        if (!engineResult.ok) {
            return engineResult;
        }
    }

    StreamToken token;
    std::shared_ptr<StreamContext> context;
    bool wasEnabled = false;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(streamId);
        if (it == streams_.end()) {
            return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
        }
        context = it->second;
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        token = StreamToken{streamId, context->generation};
        wasEnabled = context->config.face.processingLevel != FaceProcessingLevel::Disabled;
        context->config.face = normalized;
    }

    const bool nowEnabled = normalized.processingLevel != FaceProcessingLevel::Disabled;
    context->faceMetrics->enabled = isFaceAnalyticActive(normalized);
    context->faceMetrics->processingLevel = normalized.processingLevel;
    updateSchedulerRegistration(faceScheduler_.get(), wasEnabled, nowEnabled, token, normalized, context->faceMetrics);
    if (onboardProcessor_) {
        MotionConfig motionConfig;
        HazardConfig hazardConfig;
        {
            std::lock_guard<std::mutex> ctxLock(context->mutex);
            motionConfig = context->config.motion;
            hazardConfig = context->config.hazard;
        }
        onboardProcessor_->updateStreamConfig(token, motionConfig, normalized, hazardConfig);
    }
    return Result::success();
}

Result StreamManager::getFaceConfig(const std::string& streamId, FaceConfig& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    const auto it = streams_.find(streamId);
    if (it == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    std::lock_guard<std::mutex> ctxLock(it->second->mutex);
    output = it->second->config.face;
    return Result::success();
}

void StreamManager::applyMotionConfigLocked(StreamContext& context, const MotionConfig& config) {
    context.motion.config = config;
    context.motion.resetBaseline();
    context.motion.resetMotionState();
}

Result StreamManager::ensureIdentifyEngine() const {
#ifdef GUARDVISION_HAVE_FACE
    return IdentifyEngine::instance().initialize(config_.identifyResourcePath);
#else
    return Result::failure(GuardVisionErrorCode::FaceEngineInitializationFailed, "Face support is not available.", "StreamManager");
#endif
}

Result StreamManager::ensureHazardEngine(const HazardConfig& config) const {
#ifdef GUARDVISION_HAVE_HAZARD
    return HazardEngine::instance().initialize(config_.hazardResourcePath, static_cast<float>(config.minimumConfidence));
#else
    (void)config;
    return Result::failure(GuardVisionErrorCode::HazardEngineInitializationFailed, "Hazard support is not available.", "StreamManager");
#endif
}

Result StreamManager::setHazardConfig(const std::string& streamId, const HazardConfig& config) {
    HazardConfig normalized = config;
    normalizeHazardConfig(normalized);
    if (!runtimeState_.acceptingSubmissions.load()) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "GuardVision is not initialized.", "StreamManager", streamId);
    }
    if (!isValidHazardConfig(normalized)) {
        return Result::failure(GuardVisionErrorCode::InvalidHazardConfiguration, "Hazard configuration is invalid.", "StreamManager", streamId);
    }
    if (normalized.processingLevel == HazardProcessingLevel::Detect) {
        const Result engineResult = ensureHazardEngine(normalized);
        if (!engineResult.ok) {
            return engineResult;
        }
    }

    StreamToken token;
    std::shared_ptr<StreamContext> context;
    bool wasEnabled = false;
    {
        std::lock_guard<std::mutex> lock(mapMutex_);
        const auto it = streams_.find(streamId);
        if (it == streams_.end()) {
            return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
        }
        context = it->second;
        std::lock_guard<std::mutex> ctxLock(context->mutex);
        token = StreamToken{streamId, context->generation};
        wasEnabled = context->config.hazard.processingLevel == HazardProcessingLevel::Detect;
        context->config.hazard = normalized;
    }

    const bool nowEnabled = normalized.processingLevel == HazardProcessingLevel::Detect;
    context->hazardMetrics->enabled = isHazardAnalyticActive(normalized);
    context->hazardMetrics->processingLevel = normalized.processingLevel;
    updateSchedulerRegistration(hazardScheduler_.get(), wasEnabled, nowEnabled, token, normalized, context->hazardMetrics);
    if (onboardProcessor_) {
        MotionConfig motionConfig;
        FaceConfig faceConfig;
        {
            std::lock_guard<std::mutex> ctxLock(context->mutex);
            motionConfig = context->config.motion;
            faceConfig = context->config.face;
        }
        onboardProcessor_->updateStreamConfig(token, motionConfig, faceConfig, normalized);
    }
    return Result::success();
}

Result StreamManager::getHazardConfig(const std::string& streamId, HazardConfig& output) const {
    std::lock_guard<std::mutex> lock(mapMutex_);
    const auto it = streams_.find(streamId);
    if (it == streams_.end()) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream ID was not registered.", "StreamManager", streamId);
    }
    std::lock_guard<std::mutex> ctxLock(it->second->mutex);
    output = it->second->config.hazard;
    return Result::success();
}

Result StreamManager::setOnboardConfig(const OnboardConfig& config) {
    if (!isValidOnboardConfig(config)) {
        return Result::failure(GuardVisionErrorCode::InvalidConfiguration, "Onboard configuration is invalid.", "StreamManager");
    }
    {
        std::lock_guard<std::mutex> lock(onboardConfigMutex_);
        onboardConfig_ = config;
    }
    if (onboardProcessor_) {
        onboardProcessor_->setConfig(config);
    }
    return Result::success();
}

Result StreamManager::getOnboardConfig(OnboardConfig& output) const {
    std::lock_guard<std::mutex> lock(onboardConfigMutex_);
    output = onboardConfig_;
    return Result::success();
}

}  // namespace guardvision
