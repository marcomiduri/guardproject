#include <core/StreamState.h>

namespace guardvision {

const char* toString(StreamState state) noexcept {
    switch (state) {
        case StreamState::Registered:
            return "Registered";
        case StreamState::Active:
            return "Active";
        case StreamState::Stopping:
            return "Stopping";
        case StreamState::Stopped:
            return "Stopped";
        case StreamState::Error:
            return "Error";
    }
    return "Unknown";
}

}  // namespace guardvision
