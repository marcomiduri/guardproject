#include <onboard/OnboardTypes.h>

namespace guardvision {

const char* toString(CandidateType type) noexcept {
    switch (type) {
        case CandidateType::Motion:
            return "Motion";
        case CandidateType::Face:
            return "Face";
        case CandidateType::Fire:
            return "Fire";
        case CandidateType::Smoke:
            return "Smoke";
    }
    return "Unknown";
}

const char* toString(CandidateCoordinateSpace space) noexcept {
    switch (space) {
        case CandidateCoordinateSpace::Unknown:
            return "Unknown";
        case CandidateCoordinateSpace::Normalized:
            return "Normalized";
        case CandidateCoordinateSpace::ReferencePixels:
            return "ReferencePixels";
    }
    return "Unknown";
}

}  // namespace guardvision
