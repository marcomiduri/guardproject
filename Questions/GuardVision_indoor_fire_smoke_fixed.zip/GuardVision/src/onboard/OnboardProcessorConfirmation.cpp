#include "onboard/OnboardProcessor.h"

#include <algorithm>
#include <chrono>
#include <utility>

#include <core/DetectionMode.h>
#include <face/FaceEvent.h>
#include <hazard/HazardEvent.h>

#include "detail/TimeUtil.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/OnboardCandidateValidator.h"
#include "onboard/RegionalConfirmation.h"

namespace guardvision {

Result OnboardProcessor::scheduleFaceConfirmation(const OnboardConfirmationContext& context, const MappedCandidateRegion& mapped,
                                                  OnboardMetricsState& metrics) {
    if (faceScheduler_ == nullptr) {
        metrics.candidatesRejected.fetch_add(1);
        metrics.processingErrors.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::FaceQueueUnavailable, "Face scheduler is unavailable for onboard confirmation.",
                               "OnboardProcessor", context.token.streamId);
    }
    FaceRegionalConfirmationRequest request;
    request.token = context.token;
    request.candidateType = context.candidate.type;
    request.candidateTimestampMs = context.candidate.timestampMs;
    request.originalCandidateRegion = mapped.originalCandidate;
    request.mappedCandidateRegion = mapped.mappedCandidate;
    request.expandedAnalysisRegion = mapped.expandedRegion;
    request.matchedFrame = context.frame;
    request.config = context.faceConfig;
    request.config.useRoi = true;
    request.config.roi = NormalizedRect{
      static_cast<double>(mapped.expandedRegion.x) / context.frame.width,
      static_cast<double>(mapped.expandedRegion.y) / context.frame.height,
      static_cast<double>(mapped.expandedRegion.width) / context.frame.width,
      static_cast<double>(mapped.expandedRegion.height) / context.frame.height,
    };
    request.onboardConfidence = context.candidate.confidence;
    request.targetId = context.candidate.targetId;
    request.onboardMetrics = context.metrics;

    FaceConfirmationOfferResult offered = faceScheduler_->offerRegionalConfirmation(std::move(request));
    if (!offered.accepted) {
        metrics.candidatesRejected.fetch_add(1);
        if (offered.stale) {
            metrics.staleGenerationCandidates.fetch_add(1);
            return Result::failure(GuardVisionErrorCode::StaleCandidateGeneration, "Face confirmation request was stale.", "OnboardProcessor",
                                   context.token.streamId);
        }
        metrics.processingErrors.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::FaceQueueUnavailable, "Face confirmation queue is full or unavailable.", "OnboardProcessor",
                               context.token.streamId);
    }
    metrics.regionalConfirmationsRequested.fetch_add(1);
    return Result::success();
}

Result OnboardProcessor::scheduleHazardConfirmation(const OnboardConfirmationContext& context, const MappedCandidateRegion& mapped,
                                                    OnboardMetricsState& metrics) {
    if (hazardScheduler_ == nullptr) {
        metrics.candidatesRejected.fetch_add(1);
        metrics.processingErrors.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::HazardQueueUnavailable, "Hazard scheduler is unavailable for onboard confirmation.",
                               "OnboardProcessor", context.token.streamId);
    }
    HazardRegionalConfirmationRequest request;
    request.token = context.token;
    request.candidateType = context.candidate.type;
    request.candidateTimestampMs = context.candidate.timestampMs;
    request.originalCandidateRegion = mapped.originalCandidate;
    request.mappedCandidateRegion = mapped.mappedCandidate;
    request.expandedAnalysisRegion = mapped.expandedRegion;
    request.matchedFrame = context.frame;
    request.config = context.hazardConfig;
    request.config.useRoi = true;
    request.config.roi = NormalizedRect{
      static_cast<double>(mapped.expandedRegion.x) / context.frame.width,
      static_cast<double>(mapped.expandedRegion.y) / context.frame.height,
      static_cast<double>(mapped.expandedRegion.width) / context.frame.width,
      static_cast<double>(mapped.expandedRegion.height) / context.frame.height,
    };
    request.onboardConfidence = context.candidate.confidence;
    request.targetId = context.candidate.targetId;
    request.onboardMetrics = context.metrics;

    HazardConfirmationOfferResult offered = hazardScheduler_->offerRegionalConfirmation(std::move(request));
    if (!offered.accepted) {
        metrics.candidatesRejected.fetch_add(1);
        if (offered.stale) {
            metrics.staleGenerationCandidates.fetch_add(1);
            return Result::failure(GuardVisionErrorCode::StaleCandidateGeneration, "Hazard confirmation request was stale.", "OnboardProcessor",
                                   context.token.streamId);
        }
        metrics.processingErrors.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::HazardQueueUnavailable, "Hazard confirmation queue is full or unavailable.", "OnboardProcessor",
                               context.token.streamId);
    }
    metrics.regionalConfirmationsRequested.fetch_add(1);
    return Result::success();
}

void OnboardProcessor::workerLoop() {
    while (true) {
        ConfirmationJob job;
        bool hasJob = false;
        {
            std::unique_lock<std::mutex> lock(queueMutex_);
            queueCv_.wait_for(lock, std::chrono::milliseconds(100), [this]() { return stopping_ || !queue_.empty(); });
            if (stopping_ && queue_.empty()) {
                break;
            }
            if (!queue_.empty()) {
                job = std::move(queue_.front());
                queue_.pop_front();
                hasJob = true;
            }
        }
        expireTimedOutIncidents();
        if (hasJob) {
            processConfirmationJob(std::move(job));
        }
    }
}

void OnboardProcessor::processConfirmationJob(ConfirmationJob job) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle =
      job.context.metrics ? job.context.metrics : metricsForStream(job.context.token.streamId);
    if (!metricsHandle) {
        return;
    }
    OnboardMetricsState& metrics = *metricsHandle;
    std::vector<Rect> confirmedRegions;
    bool confirmed = false;

    switch (job.context.candidate.type) {
        case CandidateType::Motion: {
            if (!isTokenActive(job.context.token)) {
                metrics.staleGenerationCandidates.fetch_add(1);
                return;
            }
            for (const MappedCandidateRegion& mapped : job.context.mappedRegions) {
                const auto motionResult = confirmMotionRegion(job.context.frame, mapped.expandedRegion, job.context.motionConfig);
                if (motionResult.confirmed) {
                    confirmed = true;
                    confirmedRegions.insert(confirmedRegions.end(), motionResult.confirmedRegions.begin(), motionResult.confirmedRegions.end());
                }
            }
            break;
        }
        case CandidateType::Face:
        case CandidateType::Fire:
        case CandidateType::Smoke:
            metrics.staleGenerationCandidates.fetch_add(1);
            return;
    }

    if (!isTokenActive(job.context.token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return;
    }

    if (!confirmed || confirmedRegions.empty()) {
        metrics.confirmationsFailed.fetch_add(1);
        if (callbacks_.onError) {
            GuardVisionError error;
            error.code = GuardVisionErrorCode::ConfirmationFailure;
            error.component = "OnboardProcessor";
            error.streamId = job.context.candidate.streamId;
            error.message = "Regional software confirmation failed for onboard candidate.";
            error.recoverable = true;
            callbacks_.onError(error);
        }
        return;
    }

    metrics.confirmationsPassed.fetch_add(1);

    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(job.context.token.streamId);
        if (it != streams_.end() && it->second.generation == job.context.token.generation) {
            correlator = it->second.correlator;
        }
    }
    if (!correlator || !isTokenActive(job.context.token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return;
    }

    expireTimedOutIncidentsForStream(job.context.token, metrics);
    const AlarmDispatchRequest request = correlator->onOnboardEvidence(
      job.context.token.streamId, job.context.token.generation, candidateTypeToAlarm(job.context.candidate.type), job.context.candidate.timestampMs,
      job.context.candidate.confidence, confirmedRegions, job.context.candidate.targetId);
    dispatchIfTokenActive(request, metrics, job.context.token);
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

void OnboardProcessor::onFaceConfirmation(FaceRegionalConfirmationResult result) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle =
      result.onboardMetrics ? result.onboardMetrics : metricsForStream(result.token.streamId);
    if (!metricsHandle) {
        return;
    }
    OnboardMetricsState& metrics = *metricsHandle;
    if (result.stale || !isTokenActive(result.token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return;
    }
    if (result.hadError) {
        metrics.processingErrors.fetch_add(1);
        if (callbacks_.onError) {
            callbacks_.onError(result.error);
        }
        return;
    }
    if (!result.confirmed || result.confirmedRegions.empty()) {
        metrics.confirmationsFailed.fetch_add(1);
        return;
    }

    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(result.token.streamId);
        if (it != streams_.end() && it->second.generation == result.token.generation) {
            correlator = it->second.correlator;
        }
    }
    if (!correlator || !isTokenActive(result.token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return;
    }

    expireTimedOutIncidentsForStream(result.token, metrics);
    const double confidence = std::max(result.onboardConfidence, result.softwareConfidence);
    const AlarmDispatchRequest request =
      correlator->onOnboardEvidence(result.token.streamId, result.token.generation, AlarmType::Face, result.candidateTimestampMs, confidence,
                                    result.confirmedRegions, result.targetId);
    metrics.confirmationsPassed.fetch_add(1);
    dispatchIfTokenActive(request, metrics, result.token);
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

void OnboardProcessor::onHazardConfirmation(HazardRegionalConfirmationResult result) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle =
      result.onboardMetrics ? result.onboardMetrics : metricsForStream(result.token.streamId);
    if (!metricsHandle) {
        return;
    }
    OnboardMetricsState& metrics = *metricsHandle;
    if (result.stale || !isTokenActive(result.token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return;
    }
    if (result.hadError) {
        metrics.processingErrors.fetch_add(1);
        if (callbacks_.onError) {
            callbacks_.onError(result.error);
        }
        return;
    }
    if (!result.confirmed || result.confirmedRegions.empty()) {
        metrics.confirmationsFailed.fetch_add(1);
        return;
    }

    std::vector<Rect> regions;
    regions.reserve(result.confirmedRegions.size());
    for (const HazardRegion& region : result.confirmedRegions) {
        regions.push_back(region.bounds);
    }

    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(result.token.streamId);
        if (it != streams_.end() && it->second.generation == result.token.generation) {
            correlator = it->second.correlator;
        }
    }
    if (!correlator || !isTokenActive(result.token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return;
    }

    expireTimedOutIncidentsForStream(result.token, metrics);
    const AlarmType type = result.candidateType == CandidateType::Smoke ? AlarmType::Smoke : AlarmType::Fire;
    const double confidence = std::max(result.onboardConfidence, result.softwareConfidence);
    const AlarmDispatchRequest request = correlator->onOnboardEvidence(result.token.streamId, result.token.generation, type,
                                                                       result.candidateTimestampMs, confidence, regions, result.targetId);
    metrics.confirmationsPassed.fetch_add(1);
    dispatchIfTokenActive(request, metrics, result.token);
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

}  // namespace guardvision
