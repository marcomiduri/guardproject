#pragma once

#include <core/Error.h>
#include <onboard/OnboardTypes.h>

namespace guardvision {

struct CandidateValidationResult {
    bool ok = false;
    GuardVisionError error;
};

CandidateValidationResult validateOnboardCandidate(const OnboardCandidate& candidate);

}  // namespace guardvision
