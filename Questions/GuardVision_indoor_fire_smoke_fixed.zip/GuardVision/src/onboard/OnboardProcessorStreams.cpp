#include "onboard/OnboardProcessor.h"

#include <algorithm>
#include <chrono>
#include <utility>

#include <core/DetectionMode.h>
#include <face/FaceEvent.h>
#include <hazard/HazardEvent.h>

#include "detail/TimeUtil.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/OnboardCandidateValidator.h"
#include "onboard/RegionalConfirmation.h"

namespace guardvision {

void OnboardProcessor::registerStream(const StreamToken& token, const MotionConfig& motionConfig, const FaceConfig& faceConfig,
                                      const HazardConfig& hazardConfig, std::shared_ptr<OnboardMetricsState> metrics) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    StreamOnboardState state;
    state.frames = std::make_shared<FrameCorrelationStore>(config_.maximumStoredFrames);
    state.correlator = std::make_shared<AlarmCorrelator>(config_);
    state.metrics = std::move(metrics);
    state.generation = token.generation;
    state.motionConfig = motionConfig;
    state.faceConfig = faceConfig;
    state.hazardConfig = hazardConfig;
    streams_.emplace(token.streamId, std::move(state));
}

void OnboardProcessor::updateStreamConfig(const StreamToken& token, const MotionConfig& motionConfig, const FaceConfig& faceConfig,
                                          const HazardConfig& hazardConfig) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    const auto it = streams_.find(token.streamId);
    if (it == streams_.end() || it->second.generation != token.generation) {
        return;
    }
    it->second.motionConfig = motionConfig;
    it->second.faceConfig = faceConfig;
    it->second.hazardConfig = hazardConfig;
}

std::vector<AlarmEvent> OnboardProcessor::unregisterStream(const StreamToken& token, std::int64_t eventTimestampMs) {
    {
        std::lock_guard<std::mutex> lock(queueMutex_);
        for (auto it = queue_.begin(); it != queue_.end();) {
            if (it->context.token.streamId == token.streamId && it->context.token.generation == token.generation) {
                it = queue_.erase(it);
            } else {
                ++it;
            }
        }
    }

    std::shared_ptr<AlarmCorrelator> correlator;
    std::shared_ptr<OnboardMetricsState> metrics;
    std::shared_ptr<FrameCorrelationStore> frames;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end() || it->second.generation != token.generation) {
            return {};
        }
        correlator = it->second.correlator;
        metrics = it->second.metrics;
        frames = it->second.frames;
        streams_.erase(it);
    }
    if (frames) {
        frames->clear();
    }

    std::vector<AlarmDispatchRequest> endedRequests;
    if (correlator) {
        correlator->endAll(eventTimestampMs, endedRequests);
    }
    std::vector<AlarmEvent> endedEvents;
    endedEvents.reserve(endedRequests.size());
    for (const AlarmDispatchRequest& request : endedRequests) {
        if (!request.duplicateSuppressed && !request.rejectedByLimit) {
            endedEvents.push_back(request.event);
            if (metrics) {
                metrics->alarmsEnded.fetch_add(1);
            }
        }
    }
    if (metrics) {
        metrics->activeCorrelationEntries = 0;
    }
    return endedEvents;
}

void OnboardProcessor::recordFrame(const StreamToken& token, VideoFrame frame) {
    std::shared_ptr<FrameCorrelationStore> frames;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end() || it->second.generation != token.generation) {
            return;
        }
        frames = it->second.frames;
    }
    if (frames) {
        frames->addFrame(std::move(frame));
    }
}

std::shared_ptr<OnboardMetricsState> OnboardProcessor::metricsForStream(const std::string& streamId) const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    const auto it = streams_.find(streamId);
    return it != streams_.end() ? it->second.metrics : std::shared_ptr<OnboardMetricsState>{};
}

}  // namespace guardvision
