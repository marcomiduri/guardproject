#include "onboard/FrameCorrelationStore.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace guardvision {

FrameCorrelationStore::FrameCorrelationStore(int maximumFrames) : maximumFrames_(maximumFrames) {}

void FrameCorrelationStore::addFrame(VideoFrame frame) {
    std::lock_guard<std::mutex> lock(mutex_);
    CorrelatedFrame entry;
    entry.sequence = frame.sequence;
    entry.timestampMs = frame.timestampMs;
    entry.frame = std::move(frame);
    frames_.push_back(std::move(entry));
    while (static_cast<int>(frames_.size()) > maximumFrames_) {
        frames_.pop_front();
    }
}

void FrameCorrelationStore::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    frames_.clear();
}

std::optional<CorrelatedFrame> FrameCorrelationStore::findClosestFrame(std::int64_t timestampMs, int maximumDifferenceMs) const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (frames_.empty()) {
        return std::nullopt;
    }

    const CorrelatedFrame* best = nullptr;
    std::int64_t bestDelta = std::numeric_limits<std::int64_t>::max();
    for (const CorrelatedFrame& entry : frames_) {
        const std::int64_t delta = std::llabs(entry.timestampMs - timestampMs);
        if (delta < bestDelta) {
            bestDelta = delta;
            best = &entry;
        }
    }

    if (best == nullptr || bestDelta > maximumDifferenceMs) {
        return std::nullopt;
    }
    return *best;
}

}  // namespace guardvision
