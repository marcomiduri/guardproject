#pragma once

#include <vector>

#include <geometry/Geometry.h>
#include <motion/MotionConfig.h>
#include <onboard/OnboardTypes.h>
#include <frame/VideoFrame.h>

namespace guardvision {

struct RegionalConfirmationResult {
    bool confirmed = false;
    std::vector<Rect> confirmedRegions;
};

RegionalConfirmationResult confirmMotionRegion(const VideoFrame& frame, const Rect& expandedRegion, const MotionConfig& config);

}  // namespace guardvision
