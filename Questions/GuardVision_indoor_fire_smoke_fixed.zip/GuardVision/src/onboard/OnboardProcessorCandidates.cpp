#include "onboard/OnboardProcessor.h"

#include <algorithm>
#include <chrono>
#include <utility>

#include <core/DetectionMode.h>
#include <face/FaceEvent.h>
#include <hazard/HazardEvent.h>

#include "detail/TimeUtil.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/OnboardCandidateValidator.h"
#include "onboard/RegionalConfirmation.h"

namespace guardvision {

AlarmType OnboardProcessor::candidateTypeToAlarm(CandidateType type) const {
    switch (type) {
        case CandidateType::Motion:
            return AlarmType::Motion;
        case CandidateType::Face:
            return AlarmType::Face;
        case CandidateType::Fire:
            return AlarmType::Fire;
        case CandidateType::Smoke:
            return AlarmType::Smoke;
    }
    return AlarmType::Motion;
}

DetectionMode OnboardProcessor::detectionModeFor(CandidateType type, const OnboardConfirmationContext& context) const {
    switch (type) {
        case CandidateType::Motion:
            return context.motionConfig.detectionMode;
        case CandidateType::Face:
            return context.faceConfig.detectionMode;
        case CandidateType::Fire:
        case CandidateType::Smoke:
            return context.hazardConfig.detectionMode;
    }
    return DetectionMode::Disabled;
}

bool OnboardProcessor::acceptsCandidateType(CandidateType type, const OnboardConfirmationContext& context) const {
    return acceptsOnboardCandidates(detectionModeFor(type, context));
}

double OnboardProcessor::expansionFactorFor(CandidateType type, const OnboardConfig& config) {
    switch (type) {
        case CandidateType::Motion:
            return config.motionExpansionFactor;
        case CandidateType::Face:
            return config.faceExpansionFactor;
        case CandidateType::Fire:
        case CandidateType::Smoke:
            return config.hazardExpansionFactor;
    }
    return 1.5;
}

Result OnboardProcessor::submitCandidate(const OnboardCandidate& candidate, const StreamToken& token, std::uint64_t generation,
                                         const MotionConfig& motionConfig, const FaceConfig& faceConfig, const HazardConfig& hazardConfig) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle = metricsForStream(token.streamId);
    if (!metricsHandle) {
        return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream is not registered.", "OnboardProcessor", candidate.streamId);
    }
    OnboardMetricsState& metrics = *metricsHandle;
    metrics.candidatesReceived.fetch_add(1);

    if (candidate.generation != 0 && candidate.generation != generation) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::StaleCandidateGeneration, "Onboard candidate generation does not match active stream.",
                               "OnboardProcessor", candidate.streamId);
    }
    if (!isTokenActive(token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        metrics.candidatesRejected.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::StaleCandidateGeneration, "Stream token is no longer active.", "OnboardProcessor",
                               candidate.streamId);
    }

    const CandidateValidationResult validation = validateOnboardCandidate(candidate);
    if (!validation.ok) {
        metrics.invalidCandidates.fetch_add(1);
        metrics.candidatesRejected.fetch_add(1);
        return Result::failure(validation.error.code, validation.error.message, validation.error.component, candidate.streamId);
    }

    OnboardConfirmationContext context;
    context.token = token;
    context.candidate = candidate;
    context.motionConfig = motionConfig;
    context.faceConfig = faceConfig;
    context.hazardConfig = hazardConfig;
    context.metrics = metricsHandle;

    if (!acceptsCandidateType(candidate.type, context)) {
        metrics.candidatesRejected.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::InvalidCandidate, "Onboard candidates are not accepted for the current detection mode.",
                               "OnboardProcessor", candidate.streamId);
    }

    OnboardConfig configSnapshot;
    std::shared_ptr<FrameCorrelationStore> frameStore;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        configSnapshot = config_;
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end() || it->second.generation != token.generation) {
            metrics.candidatesRejected.fetch_add(1);
            return Result::failure(GuardVisionErrorCode::StreamNotFound, "Stream is not registered.", "OnboardProcessor", candidate.streamId);
        }
        frameStore = it->second.frames;
    }

    const std::optional<CorrelatedFrame> correlated =
      frameStore ? frameStore->findClosestFrame(candidate.timestampMs, configSnapshot.maximumTimestampDifferenceMs) : std::nullopt;
    if (!correlated.has_value()) {
        metrics.candidatesWithoutMatchingFrames.fetch_add(1);
        metrics.staleTimestampCandidates.fetch_add(1);
        metrics.candidatesRejected.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::FrameCorrelationFailure, "No correlated frame exists for onboard candidate timestamp.",
                               "OnboardProcessor", candidate.streamId);
    }

    context.frame = correlated->frame;
    const CandidateMappingResult mapping = mapOnboardCandidateRegions(candidate, context.frame, expansionFactorFor(candidate.type, configSnapshot));
    if (!mapping.ok) {
        metrics.invalidCandidates.fetch_add(1);
        metrics.candidatesRejected.fetch_add(1);
        return Result::failure(mapping.error.code, mapping.error.message, mapping.error.component, candidate.streamId);
    }
    context.mappedRegions = mapping.regions;
    metrics.coordinateConversions.fetch_add(1);
    for (const MappedCandidateRegion& mapped : context.mappedRegions) {
        if (mapped.usedReferenceMapping) {
            metrics.coordinateConversions.fetch_add(1);
        }
        if (mapped.changedResolution) {
            metrics.mainStreamToSubstreamMappings.fetch_add(1);
        }
    }
    metrics.expandedRegions.fetch_add(static_cast<std::uint64_t>(mapping.regions.size()));

    if (!isTokenActive(token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        metrics.candidatesRejected.fetch_add(1);
        return Result::failure(GuardVisionErrorCode::StaleCandidateGeneration, "Stream token became inactive before confirmation scheduling.",
                               "OnboardProcessor", candidate.streamId);
    }

    if (candidate.type == CandidateType::Face) {
        for (const MappedCandidateRegion& mapped : context.mappedRegions) {
            Result scheduled = scheduleFaceConfirmation(context, mapped, metrics);
            if (!scheduled.ok) {
                return scheduled;
            }
        }
        metrics.candidatesAccepted.fetch_add(1);
        return Result::success();
    }
    if (candidate.type == CandidateType::Fire || candidate.type == CandidateType::Smoke) {
        for (const MappedCandidateRegion& mapped : context.mappedRegions) {
            Result scheduled = scheduleHazardConfirmation(context, mapped, metrics);
            if (!scheduled.ok) {
                return scheduled;
            }
        }
        metrics.candidatesAccepted.fetch_add(1);
        return Result::success();
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex_);
        if (static_cast<int>(queue_.size()) >= configSnapshot.maximumPendingCandidates) {
            metrics.candidatesExpired.fetch_add(1);
            metrics.candidatesRejected.fetch_add(1);
            return Result::failure(GuardVisionErrorCode::InternalError, "Onboard confirmation queue is full.", "OnboardProcessor",
                                   candidate.streamId);
        }
        ConfirmationJob job;
        job.context = std::move(context);
        queue_.push_back(std::move(job));
    }
    queueCv_.notify_one();

    metrics.candidatesAccepted.fetch_add(1);
    metrics.regionalConfirmationsRequested.fetch_add(1);
    return Result::success();
}

}  // namespace guardvision
