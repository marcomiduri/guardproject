#include <onboard/OnboardConfig.h>

namespace guardvision {
namespace {

constexpr double kMinExpansion = 1.0;
constexpr double kMaxExpansion = 3.0;

}  // namespace

bool isValidOnboardConfig(const OnboardConfig& config) noexcept {
    if (config.motionExpansionFactor < kMinExpansion || config.motionExpansionFactor > kMaxExpansion) {
        return false;
    }
    if (config.faceExpansionFactor < kMinExpansion || config.faceExpansionFactor > kMaxExpansion) {
        return false;
    }
    if (config.hazardExpansionFactor < kMinExpansion || config.hazardExpansionFactor > kMaxExpansion) {
        return false;
    }
    if (config.maximumTimestampDifferenceMs < 1 || config.maximumTimestampDifferenceMs > 60000) {
        return false;
    }
    if (config.maximumStoredFrames < 1 || config.maximumStoredFrames > 32) {
        return false;
    }
    if (config.maximumPendingCandidates < 1 || config.maximumPendingCandidates > 256) {
        return false;
    }
    if (config.maximumActiveIncidents < 1 || config.maximumActiveIncidents > 256) {
        return false;
    }
    if (config.alarmUpdateIntervalMs < 0 || config.alarmUpdateIntervalMs > 3600000) {
        return false;
    }
    if (config.incidentTimeoutMs < 1 || config.incidentTimeoutMs > 3600000) {
        return false;
    }
    if (config.hybridSpatialOverlapThreshold < 0.0 || config.hybridSpatialOverlapThreshold > 1.0) {
        return false;
    }
    return true;
}

}  // namespace guardvision
