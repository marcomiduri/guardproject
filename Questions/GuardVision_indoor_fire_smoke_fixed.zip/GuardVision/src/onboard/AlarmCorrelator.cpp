#include "onboard/AlarmCorrelator.h"

#include <algorithm>

#include <geometry/Geometry.h>

#include "detail/TimeUtil.h"

namespace guardvision {
namespace {

AlarmDispatchRequest makeLimitRejected(const std::string& streamId) {
    AlarmDispatchRequest request;
    request.rejectedByLimit = true;
    request.error.code = GuardVisionErrorCode::InternalError;
    request.error.component = "AlarmCorrelator";
    request.error.streamId = streamId;
    request.error.message = "Maximum active alarm incident count reached.";
    request.error.recoverable = true;
    return request;
}

}  // namespace

AlarmCorrelator::AlarmCorrelator(OnboardConfig config) : config_(config) {}

void AlarmCorrelator::setConfig(const OnboardConfig& config) {
    std::lock_guard<std::mutex> lock(mutex_);
    config_ = config;
}

void AlarmCorrelator::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    incidents_.clear();
}

void AlarmCorrelator::endAll(std::int64_t timestampMs, std::vector<AlarmDispatchRequest>& output) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& entry : incidents_) {
        if (entry.second.active) {
            const std::int64_t eventTimestampMs = timestampMs > 0 ? std::max(timestampMs, entry.second.lastEvidenceMs) : entry.second.lastEvidenceMs;
            output.push_back(makeEnded(entry.second, eventTimestampMs));
            entry.second.active = false;
        }
    }
    incidents_.clear();
}

void AlarmCorrelator::expireTimedOut(std::int64_t nowMs, std::vector<AlarmDispatchRequest>& output) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto it = incidents_.begin(); it != incidents_.end();) {
        IncidentState& incident = it->second;
        if (incident.active && nowMs - incident.lastActivityMonotonicMs > config_.incidentTimeoutMs) {
            const std::int64_t eventTimestampMs = incident.lastEvidenceMs + config_.incidentTimeoutMs;
            output.push_back(makeEnded(incident, eventTimestampMs));
            it = incidents_.erase(it);
        } else {
            ++it;
        }
    }
}

bool AlarmCorrelator::regionsOverlap(const std::vector<Rect>& a, const std::vector<Rect>& b) const {
    for (const Rect& left : a) {
        for (const Rect& right : b) {
            if (intersectOverUnion(left, right) >= config_.hybridSpatialOverlapThreshold) {
                return true;
            }
        }
    }
    return false;
}

std::size_t AlarmCorrelator::activeIncidentCountLocked() const {
    std::size_t count = 0;
    for (const auto& entry : incidents_) {
        if (entry.second.active) {
            ++count;
        }
    }
    return count;
}

AlarmCorrelator::IncidentState* AlarmCorrelator::findMatchingIncident(const std::string& streamId, AlarmType type, const std::vector<Rect>& regions,
                                                                      const std::string& targetId) {
    if (!targetId.empty()) {
        for (auto& entry : incidents_) {
            IncidentState& incident = entry.second;
            if (incident.active && incident.streamId == streamId && incident.type == type && incident.onboardTargetId == targetId) {
                return &incident;
            }
        }
    }

    for (auto& entry : incidents_) {
        IncidentState& incident = entry.second;
        if (!incident.active || incident.streamId != streamId) {
            continue;
        }
        if (incident.type != type) {
            continue;
        }
        if (regionsOverlap(incident.regions, regions)) {
            return &incident;
        }
    }
    return nullptr;
}

AlarmDispatchRequest AlarmCorrelator::makeStarted(const IncidentState& incident) const {
    AlarmDispatchRequest request;
    request.event.alarmId = incident.alarmId;
    request.event.streamId = incident.streamId;
    request.event.generation = incident.generation;
    request.event.type = incident.type;
    request.event.state = AlarmState::Started;
    request.event.source = incident.source;
    request.event.timestampMs = incident.lastEvidenceMs;
    request.event.confidence = incident.confidence;
    request.event.regions = incident.regions;
    request.event.onboardTargetId = incident.onboardTargetId;
    request.event.softwareTrackId = incident.softwareTrackId;
    return request;
}

AlarmDispatchRequest AlarmCorrelator::makeUpdated(const IncidentState& incident) const {
    AlarmDispatchRequest request = makeStarted(incident);
    request.event.state = AlarmState::Updated;
    return request;
}

AlarmDispatchRequest AlarmCorrelator::makeEnded(const IncidentState& incident, std::int64_t timestampMs) const {
    AlarmDispatchRequest request = makeStarted(incident);
    request.event.state = AlarmState::Ended;
    request.event.timestampMs = timestampMs;
    return request;
}

AlarmDispatchRequest AlarmCorrelator::onSoftwareEvidence(const std::string& streamId, std::uint64_t generation, AlarmType type,
                                                         std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions,
                                                         std::uint64_t softwareTrackId) {
    std::lock_guard<std::mutex> lock(mutex_);
    IncidentState* existing = findMatchingIncident(streamId, type, regions, {});
    if (existing != nullptr) {
        if (existing->source == AlarmSource::Onboard) {
            existing->source = AlarmSource::Hybrid;
        }
        existing->lastEvidenceMs = timestampMs;
        existing->lastActivityMonotonicMs = detail::steadyNowMs();
        existing->confidence = std::max(existing->confidence, confidence);
        existing->regions = regions;
        existing->softwareTrackId = softwareTrackId;
        if (timestampMs - existing->lastUpdateDispatchMs >= config_.alarmUpdateIntervalMs) {
            existing->lastUpdateDispatchMs = timestampMs;
            return makeUpdated(*existing);
        }
        AlarmDispatchRequest suppressed;
        suppressed.duplicateSuppressed = true;
        return suppressed;
    }

    if (activeIncidentCountLocked() >= static_cast<std::size_t>(config_.maximumActiveIncidents)) {
        return makeLimitRejected(streamId);
    }

    const std::string key = streamId + ":" + toString(type) + ":sw:" + std::to_string(softwareTrackId) + ":" + std::to_string(timestampMs);
    IncidentState incident;
    incident.alarmId = nextAlarmId_++;
    incident.generation = generation;
    incident.source = AlarmSource::Software;
    incident.startedAtMs = timestampMs;
    incident.lastEvidenceMs = timestampMs;
    incident.lastActivityMonotonicMs = detail::steadyNowMs();
    incident.lastUpdateDispatchMs = timestampMs;
    incident.confidence = confidence;
    incident.regions = regions;
    incident.softwareTrackId = softwareTrackId;
    incident.active = true;
    incident.streamId = streamId;
    incident.type = type;
    incidents_[key] = incident;
    return makeStarted(incidents_[key]);
}

AlarmDispatchRequest AlarmCorrelator::onOnboardEvidence(const std::string& streamId, std::uint64_t generation, AlarmType type,
                                                        std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions,
                                                        const std::string& onboardTargetId) {
    std::lock_guard<std::mutex> lock(mutex_);
    IncidentState* existing = findMatchingIncident(streamId, type, regions, onboardTargetId);
    if (existing != nullptr) {
        if (existing->source == AlarmSource::Software) {
            existing->source = AlarmSource::Hybrid;
        }
        existing->lastEvidenceMs = timestampMs;
        existing->lastActivityMonotonicMs = detail::steadyNowMs();
        existing->confidence = std::max(existing->confidence, confidence);
        existing->regions = regions;
        existing->onboardTargetId = onboardTargetId;
        if (timestampMs - existing->lastUpdateDispatchMs >= config_.alarmUpdateIntervalMs) {
            existing->lastUpdateDispatchMs = timestampMs;
            return makeUpdated(*existing);
        }
        AlarmDispatchRequest suppressed;
        suppressed.duplicateSuppressed = true;
        return suppressed;
    }

    if (activeIncidentCountLocked() >= static_cast<std::size_t>(config_.maximumActiveIncidents)) {
        return makeLimitRejected(streamId);
    }

    const std::string key = streamId + ":" + toString(type) + ":ob:" + (onboardTargetId.empty() ? "anon" : onboardTargetId);
    IncidentState incident;
    incident.alarmId = nextAlarmId_++;
    incident.generation = generation;
    incident.source = AlarmSource::Onboard;
    incident.startedAtMs = timestampMs;
    incident.lastEvidenceMs = timestampMs;
    incident.lastActivityMonotonicMs = detail::steadyNowMs();
    incident.lastUpdateDispatchMs = timestampMs;
    incident.confidence = confidence;
    incident.regions = regions;
    incident.onboardTargetId = onboardTargetId;
    incident.active = true;
    incident.streamId = streamId;
    incident.type = type;
    incidents_[key] = incident;
    return makeStarted(incidents_[key]);
}

std::size_t AlarmCorrelator::activeIncidentCount() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::size_t count = 0;
    for (const auto& entry : incidents_) {
        if (entry.second.active) {
            ++count;
        }
    }
    return count;
}

}  // namespace guardvision
