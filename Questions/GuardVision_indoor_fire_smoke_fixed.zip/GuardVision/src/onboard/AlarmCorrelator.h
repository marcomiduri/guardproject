#pragma once

#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include <events/AlarmEvent.h>
#include <core/Error.h>
#include <onboard/OnboardConfig.h>

namespace guardvision {

struct AlarmDispatchRequest {
    AlarmEvent event;
    bool duplicateSuppressed = false;
    bool rejectedByLimit = false;
    GuardVisionError error;
};

class AlarmCorrelator {
public:
    explicit AlarmCorrelator(OnboardConfig config);

    void setConfig(const OnboardConfig& config);
    void clear();
    void endAll(std::int64_t timestampMs, std::vector<AlarmDispatchRequest>& output);
    void expireTimedOut(std::int64_t nowMs, std::vector<AlarmDispatchRequest>& output);

    AlarmDispatchRequest onSoftwareEvidence(const std::string& streamId, std::uint64_t generation, AlarmType type, std::int64_t timestampMs,
                                            double confidence, const std::vector<Rect>& regions, std::uint64_t softwareTrackId);

    AlarmDispatchRequest onOnboardEvidence(const std::string& streamId, std::uint64_t generation, AlarmType type, std::int64_t timestampMs,
                                           double confidence, const std::vector<Rect>& regions, const std::string& onboardTargetId);

    std::size_t activeIncidentCount() const;

private:
    struct IncidentState {
        std::uint64_t alarmId = 0;
        std::string streamId;
        std::uint64_t generation = 0;
        AlarmType type = AlarmType::Motion;
        AlarmSource source = AlarmSource::Software;
        std::int64_t startedAtMs = 0;
        std::int64_t lastEvidenceMs = 0;
        std::int64_t lastActivityMonotonicMs = 0;
        std::int64_t lastUpdateDispatchMs = 0;
        double confidence = 0.0;
        std::vector<Rect> regions;
        std::string onboardTargetId;
        std::uint64_t softwareTrackId = 0;
        bool active = false;
    };

    IncidentState* findMatchingIncident(const std::string& streamId, AlarmType type, const std::vector<Rect>& regions, const std::string& targetId);
    AlarmDispatchRequest makeStarted(const IncidentState& incident) const;
    AlarmDispatchRequest makeUpdated(const IncidentState& incident) const;
    AlarmDispatchRequest makeEnded(const IncidentState& incident, std::int64_t timestampMs) const;
    bool regionsOverlap(const std::vector<Rect>& a, const std::vector<Rect>& b) const;
    std::size_t activeIncidentCountLocked() const;

    OnboardConfig config_;
    mutable std::mutex mutex_;
    std::unordered_map<std::string, IncidentState> incidents_;
    std::uint64_t nextAlarmId_ = 1;
};

}  // namespace guardvision
