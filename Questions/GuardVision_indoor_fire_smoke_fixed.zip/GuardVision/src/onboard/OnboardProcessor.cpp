#include "onboard/OnboardProcessor.h"

#include <algorithm>
#include <chrono>
#include <utility>

#include <core/DetectionMode.h>
#include <face/FaceEvent.h>
#include <hazard/HazardEvent.h>

#include "detail/TimeUtil.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/OnboardCandidateValidator.h"
#include "onboard/RegionalConfirmation.h"

namespace guardvision {

OnboardProcessor::OnboardProcessor(OnboardConfig config) : config_(config) {}

OnboardProcessor::~OnboardProcessor() {
    stop();
    join();
}

void OnboardProcessor::setConfig(const OnboardConfig& config) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    config_ = config;
    for (auto& entry : streams_) {
        entry.second.correlator->setConfig(config);
        entry.second.frames = std::make_shared<FrameCorrelationStore>(config.maximumStoredFrames);
    }
}

void OnboardProcessor::setCallbacks(AlarmDispatchCallback callbacks) {
    callbacks_ = std::move(callbacks);
}

void OnboardProcessor::setActiveTokenValidator(std::function<bool(const StreamToken& token)> validator) {
    activeTokenValidator_ = std::move(validator);
}

void OnboardProcessor::setRegionalConfirmationSchedulers(FaceScheduler* faceScheduler, HazardScheduler* hazardScheduler) {
    faceScheduler_ = faceScheduler;
    hazardScheduler_ = hazardScheduler;
}

void OnboardProcessor::start() {
    stopping_ = false;
    worker_ = std::thread([this]() { workerLoop(); });
}

void OnboardProcessor::stop() {
    stopping_ = true;
    queueCv_.notify_all();
}

void OnboardProcessor::join() {
    if (worker_.joinable()) {
        worker_.join();
    }
}

}  // namespace guardvision
