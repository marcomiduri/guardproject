#include "onboard/RegionalConfirmation.h"

#include <motion/MotionTypes.h>

#include "motion/LumaConverter.h"
#include "motion/MotionAnalyzer.h"
#include "motion/MotionRegionExtractor.h"
#include "motion/MotionStreamState.h"

namespace guardvision {

RegionalConfirmationResult confirmMotionRegion(const VideoFrame& frame, const Rect& expandedRegion, const MotionConfig& config) {
    RegionalConfirmationResult result;
    MotionStreamState scratch;
    scratch.config = config;
    scratch.config.useRoi = true;
    scratch.config.roi = NormalizedRect{
      static_cast<double>(expandedRegion.x) / frame.width,
      static_cast<double>(expandedRegion.y) / frame.height,
      static_cast<double>(expandedRegion.width) / frame.width,
      static_cast<double>(expandedRegion.height) / frame.height,
    };

    LumaConversionResult conversion;
    if (!extractAnalysisLuma(frame, scratch.config, scratch, scratch.currentLuma, conversion)) {
        return result;
    }

    std::vector<std::uint8_t> previous(scratch.currentLuma.size(), scratch.currentLuma[0]);
    MotionCompareResult compareResult;
    std::vector<std::uint8_t> changeMask;
    if (!compareLumaFrames(previous, scratch.currentLuma, conversion.analysisWidth, conversion.analysisHeight, config.pixelDifferenceThreshold,
                           changeMask, scratch.blockActive, compareResult)) {
        return result;
    }

    const bool motionDetected = compareResult.changedAreaRatio >= config.startChangedAreaRatio;
    if (!motionDetected) {
        return result;
    }

    const Size frameSize{frame.width, frame.height};
    int truncated = 0;
    auto regions = extractMotionRegions(changeMask, conversion.analysisWidth, conversion.analysisHeight, config, conversion.analysisAreaFullFrame,
                                        frameSize, scratch.regionScratch, truncated);
    for (const MotionRegion& region : regions) {
        result.confirmedRegions.push_back(region.bounds);
    }
    if (!result.confirmedRegions.empty()) {
        result.confirmed = true;
    }
    return result;
}

}  // namespace guardvision
