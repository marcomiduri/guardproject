#include "onboard/OnboardCandidateValidator.h"

namespace guardvision {
namespace {

GuardVisionError makeError(GuardVisionErrorCode code, const std::string& streamId, const char* message) {
    GuardVisionError error;
    error.code = code;
    error.component = "OnboardCandidateValidator";
    error.streamId = streamId;
    error.message = message;
    error.recoverable = true;
    return error;
}

}  // namespace

CandidateValidationResult validateOnboardCandidate(const OnboardCandidate& candidate) {
    CandidateValidationResult result;
    if (candidate.streamId.empty()) {
        result.error = makeError(GuardVisionErrorCode::InvalidCandidate, candidate.streamId, "Onboard candidate stream ID is empty.");
        return result;
    }
    if (candidate.timestampMs < 0) {
        result.error = makeError(GuardVisionErrorCode::InvalidCandidate, candidate.streamId, "Onboard candidate timestamp is invalid.");
        return result;
    }
    if (candidate.regions.empty()) {
        result.error = makeError(GuardVisionErrorCode::InvalidCandidate, candidate.streamId, "Onboard candidate has no regions.");
        return result;
    }

    switch (candidate.type) {
        case CandidateType::Motion:
        case CandidateType::Face:
        case CandidateType::Fire:
        case CandidateType::Smoke:
            break;
        default:
            result.error = makeError(GuardVisionErrorCode::UnsupportedCandidateType, candidate.streamId, "Unsupported onboard candidate type.");
            return result;
    }

    for (const OnboardCandidateRegion& region : candidate.regions) {
        if (region.coordinateSpace == CandidateCoordinateSpace::Unknown) {
            result.error = makeError(GuardVisionErrorCode::UnknownCandidateCoordinateSpace, candidate.streamId,
                                     "Onboard candidate region has unknown coordinate space.");
            return result;
        }
        if (region.coordinateSpace == CandidateCoordinateSpace::Normalized) {
            if (!region.normalizedBounds.isValid()) {
                result.error = makeError(GuardVisionErrorCode::InvalidNormalizedCandidateRect, candidate.streamId,
                                         "Invalid normalized onboard candidate rectangle.");
                return result;
            }
        } else if (region.coordinateSpace == CandidateCoordinateSpace::ReferencePixels) {
            if (region.referenceWidth <= 0 || region.referenceHeight <= 0 || !region.pixelBounds.isValid()) {
                result.error = makeError(GuardVisionErrorCode::MissingCandidateReferenceResolution, candidate.streamId,
                                         "Reference-pixel candidate is missing valid reference dimensions.");
                return result;
            }
        }
    }

    result.ok = true;
    return result;
}

}  // namespace guardvision
