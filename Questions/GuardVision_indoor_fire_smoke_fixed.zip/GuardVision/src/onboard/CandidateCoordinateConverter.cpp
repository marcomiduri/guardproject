#include "onboard/CandidateCoordinateConverter.h"

namespace guardvision {
namespace {

Rect mapRegionToFrame(const OnboardCandidateRegion& region, Size frameSize, bool* usedReferenceMapping) {
    if (usedReferenceMapping) {
        *usedReferenceMapping = false;
    }

    if (region.coordinateSpace == CandidateCoordinateSpace::Normalized) {
        return normalizedRectToPixels(region.normalizedBounds, frameSize);
    }

    if (region.coordinateSpace == CandidateCoordinateSpace::ReferencePixels) {
        if (region.referenceWidth <= 0 || region.referenceHeight <= 0 || !region.pixelBounds.isValid()) {
            return Rect{};
        }
        if (usedReferenceMapping) {
            *usedReferenceMapping = true;
        }
        return mapRectBetweenResolutions(region.pixelBounds, Size{region.referenceWidth, region.referenceHeight}, frameSize);
    }

    return Rect{};
}

}  // namespace

CandidateMappingResult mapOnboardCandidateRegions(const OnboardCandidate& candidate, const VideoFrame& frame, double expansionFactor) {
    CandidateMappingResult result;
    const Size frameSize{frame.width, frame.height};
    if (!frameSize.isValid()) {
        result.error.code = GuardVisionErrorCode::InvalidFrame;
        result.error.component = "CandidateCoordinateConverter";
        result.error.streamId = candidate.streamId;
        result.error.message = "Submitted frame has invalid dimensions.";
        return result;
    }

    result.regions.reserve(candidate.regions.size());
    for (const OnboardCandidateRegion& region : candidate.regions) {
        bool usedReference = false;
        const Rect mapped = mapRegionToFrame(region, frameSize, &usedReference);
        if (!mapped.isValid()) {
            result.error.code = region.coordinateSpace == CandidateCoordinateSpace::Normalized ? GuardVisionErrorCode::InvalidNormalizedCandidateRect
                                                                                               : GuardVisionErrorCode::InvalidPixelCandidateRect;
            result.error.component = "CandidateCoordinateConverter";
            result.error.streamId = candidate.streamId;
            result.error.message = "Failed to map onboard candidate region into frame coordinates.";
            return result;
        }

        MappedCandidateRegion mappedRegion;
        mappedRegion.originalCandidate = mapped;
        mappedRegion.mappedCandidate = mapped;
        mappedRegion.expandedRegion = expandRectAroundCenter(mapped, expansionFactor, frameSize);
        mappedRegion.usedReferenceMapping = usedReference;
        mappedRegion.changedResolution = usedReference && (region.referenceWidth != frame.width || region.referenceHeight != frame.height);
        if (!mappedRegion.expandedRegion.isValid()) {
            result.error.code = GuardVisionErrorCode::InvalidExpansionFactor;
            result.error.component = "CandidateCoordinateConverter";
            result.error.streamId = candidate.streamId;
            result.error.message = "Expanded candidate region is invalid.";
            return result;
        }
        result.regions.push_back(mappedRegion);
        if (usedReference && (region.referenceWidth != frame.width || region.referenceHeight != frame.height)) {
            // counted by caller via metrics
        }
    }

    if (result.regions.empty()) {
        result.error.code = GuardVisionErrorCode::InvalidCandidate;
        result.error.component = "CandidateCoordinateConverter";
        result.error.streamId = candidate.streamId;
        result.error.message = "Onboard candidate has no valid regions.";
        return result;
    }

    result.ok = true;
    return result;
}

}  // namespace guardvision
