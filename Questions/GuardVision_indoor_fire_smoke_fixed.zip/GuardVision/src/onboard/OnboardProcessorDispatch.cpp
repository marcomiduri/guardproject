#include "onboard/OnboardProcessor.h"

#include <algorithm>
#include <chrono>
#include <utility>

#include <core/DetectionMode.h>
#include <face/FaceEvent.h>
#include <hazard/HazardEvent.h>

#include "detail/TimeUtil.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/OnboardCandidateValidator.h"
#include "onboard/RegionalConfirmation.h"

namespace guardvision {

void OnboardProcessor::dispatchAlarmRequest(const AlarmDispatchRequest& request, OnboardMetricsState& metrics) {
    if (request.duplicateSuppressed) {
        metrics.duplicatesSuppressed.fetch_add(1);
        return;
    }
    if (request.rejectedByLimit) {
        metrics.candidatesRejected.fetch_add(1);
        metrics.processingErrors.fetch_add(1);
        if (callbacks_.onError) {
            callbacks_.onError(request.error);
        }
        return;
    }
    if (!callbacks_.onAlarm) {
        return;
    }
    switch (request.event.state) {
        case AlarmState::Started:
            metrics.alarmsStarted.fetch_add(1);
            if (request.event.source == AlarmSource::Hybrid) {
                metrics.hybridAlarms.fetch_add(1);
            }
            break;
        case AlarmState::Updated:
            metrics.alarmsUpdated.fetch_add(1);
            break;
        case AlarmState::Ended:
            metrics.alarmsEnded.fetch_add(1);
            break;
    }
    callbacks_.onAlarm(request.event);
}

bool OnboardProcessor::isTokenActive(const StreamToken& token) const {
    if (activeTokenValidator_) {
        return activeTokenValidator_(token);
    }
    std::lock_guard<std::mutex> lock(stateMutex_);
    const auto it = streams_.find(token.streamId);
    return it != streams_.end() && it->second.generation == token.generation;
}

bool OnboardProcessor::dispatchIfTokenActive(const AlarmDispatchRequest& request, OnboardMetricsState& metrics, const StreamToken& token) {
    if (!isTokenActive(token)) {
        metrics.staleGenerationCandidates.fetch_add(1);
        return false;
    }
    dispatchAlarmRequest(request, metrics);
    return true;
}

void OnboardProcessor::expireTimedOutIncidentsForStream(const StreamToken& token, OnboardMetricsState& metrics) {
    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end() || it->second.generation != token.generation || !it->second.correlator) {
            return;
        }
        correlator = it->second.correlator;
    }
    std::vector<AlarmDispatchRequest> expired;
    correlator->expireTimedOut(detail::steadyNowMs(), expired);
    for (const AlarmDispatchRequest& request : expired) {
        metrics.candidatesExpired.fetch_add(1);
        dispatchIfTokenActive(request, metrics, token);
    }
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

void OnboardProcessor::expireTimedOutIncidents() {
    std::vector<StreamToken> tokens;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        tokens.reserve(streams_.size());
        for (const auto& entry : streams_) {
            tokens.push_back(StreamToken{entry.first, entry.second.generation});
        }
    }
    for (const StreamToken& token : tokens) {
        const std::shared_ptr<OnboardMetricsState> metrics = metricsForStream(token.streamId);
        if (metrics) {
            expireTimedOutIncidentsForStream(token, *metrics);
        }
    }
}

}  // namespace guardvision
