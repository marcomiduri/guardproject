#include "onboard/OnboardProcessor.h"

#include <algorithm>
#include <chrono>
#include <utility>

#include <core/DetectionMode.h>
#include <face/FaceEvent.h>
#include <hazard/HazardEvent.h>

#include "detail/TimeUtil.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/OnboardCandidateValidator.h"
#include "onboard/RegionalConfirmation.h"

namespace guardvision {

void OnboardProcessor::onSoftwareMotion(const StreamToken& token, std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle = metricsForStream(token.streamId);
    if (!metricsHandle) {
        return;
    }
    OnboardMetricsState& metrics = *metricsHandle;
    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end()) {
            return;
        }
        if (!runsContinuousSoftware(it->second.motionConfig.detectionMode) && it->second.motionConfig.detectionMode != DetectionMode::Hybrid) {
            return;
        }
        correlator = it->second.correlator;
    }
    if (!correlator) {
        return;
    }
    expireTimedOutIncidentsForStream(token, metrics);
    const AlarmDispatchRequest request =
      correlator->onSoftwareEvidence(token.streamId, token.generation, AlarmType::Motion, timestampMs, confidence, regions, 0);
    dispatchIfTokenActive(request, metrics, token);
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

void OnboardProcessor::onSoftwareFace(const StreamToken& token, std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions,
                                      std::uint64_t trackId) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle = metricsForStream(token.streamId);
    if (!metricsHandle) {
        return;
    }
    OnboardMetricsState& metrics = *metricsHandle;
    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end()) {
            return;
        }
        if (!runsContinuousSoftware(it->second.faceConfig.detectionMode) && it->second.faceConfig.detectionMode != DetectionMode::Hybrid) {
            return;
        }
        correlator = it->second.correlator;
    }
    if (!correlator) {
        return;
    }
    expireTimedOutIncidentsForStream(token, metrics);
    const AlarmDispatchRequest request =
      correlator->onSoftwareEvidence(token.streamId, token.generation, AlarmType::Face, timestampMs, confidence, regions, trackId);
    dispatchIfTokenActive(request, metrics, token);
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

void OnboardProcessor::onSoftwareHazard(const StreamToken& token, AlarmType type, std::int64_t timestampMs, double confidence,
                                        const std::vector<Rect>& regions) {
    const std::shared_ptr<OnboardMetricsState> metricsHandle = metricsForStream(token.streamId);
    if (!metricsHandle) {
        return;
    }
    OnboardMetricsState& metrics = *metricsHandle;
    std::shared_ptr<AlarmCorrelator> correlator;
    {
        std::lock_guard<std::mutex> lock(stateMutex_);
        const auto it = streams_.find(token.streamId);
        if (it == streams_.end()) {
            return;
        }
        if (!runsContinuousSoftware(it->second.hazardConfig.detectionMode) && it->second.hazardConfig.detectionMode != DetectionMode::Hybrid) {
            return;
        }
        correlator = it->second.correlator;
    }
    if (!correlator) {
        return;
    }
    expireTimedOutIncidentsForStream(token, metrics);
    const AlarmDispatchRequest request = correlator->onSoftwareEvidence(token.streamId, token.generation, type, timestampMs, confidence, regions, 0);
    dispatchIfTokenActive(request, metrics, token);
    metrics.activeCorrelationEntries = correlator->activeIncidentCount();
}

}  // namespace guardvision
