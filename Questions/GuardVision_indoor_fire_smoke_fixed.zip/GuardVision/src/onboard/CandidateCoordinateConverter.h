#pragma once

#include <core/Error.h>
#include <geometry/Geometry.h>
#include <onboard/OnboardTypes.h>
#include <frame/VideoFrame.h>

namespace guardvision {

struct MappedCandidateRegion {
    Rect originalCandidate;
    Rect mappedCandidate;
    Rect expandedRegion;
    bool usedReferenceMapping = false;
    bool changedResolution = false;
};

struct CandidateMappingResult {
    bool ok = false;
    GuardVisionError error;
    std::vector<MappedCandidateRegion> regions;
};

CandidateMappingResult mapOnboardCandidateRegions(const OnboardCandidate& candidate, const VideoFrame& frame, double expansionFactor);

}  // namespace guardvision
