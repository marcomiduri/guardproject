#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>
#include <onboard/OnboardConfig.h>
#include <onboard/OnboardTypes.h>
#include <core/Result.h>
#include <frame/VideoFrame.h>

#include "core/StreamToken.h"
#include "face/FaceScheduler.h"
#include "hazard/HazardScheduler.h"
#include "metrics/OnboardMetricsState.h"
#include "onboard/AlarmCorrelator.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/FrameCorrelationStore.h"

namespace guardvision {

struct OnboardConfirmationContext {
    StreamToken token;
    OnboardCandidate candidate;
    VideoFrame frame;
    std::vector<MappedCandidateRegion> mappedRegions;
    MotionConfig motionConfig;
    FaceConfig faceConfig;
    HazardConfig hazardConfig;
    std::shared_ptr<OnboardMetricsState> metrics;
};

struct AlarmDispatchCallback {
    std::function<void(const AlarmEvent&)> onAlarm;
    std::function<void(const GuardVisionError&)> onError;
};

class OnboardProcessor {
public:
    explicit OnboardProcessor(OnboardConfig config);
    ~OnboardProcessor();

    OnboardProcessor(const OnboardProcessor&) = delete;
    OnboardProcessor& operator=(const OnboardProcessor&) = delete;

    void setConfig(const OnboardConfig& config);
    void setCallbacks(AlarmDispatchCallback callbacks);
    void setActiveTokenValidator(std::function<bool(const StreamToken& token)> validator);
    void setRegionalConfirmationSchedulers(FaceScheduler* faceScheduler, HazardScheduler* hazardScheduler);
    void start();
    void stop();
    void join();

    void registerStream(const StreamToken& token, const MotionConfig& motionConfig, const FaceConfig& faceConfig, const HazardConfig& hazardConfig,
                        std::shared_ptr<OnboardMetricsState> metrics);
    void updateStreamConfig(const StreamToken& token, const MotionConfig& motionConfig, const FaceConfig& faceConfig,
                            const HazardConfig& hazardConfig);
    std::vector<AlarmEvent> unregisterStream(const StreamToken& token, std::int64_t eventTimestampMs);

    void recordFrame(const StreamToken& token, VideoFrame frame);
    Result submitCandidate(const OnboardCandidate& candidate, const StreamToken& token, std::uint64_t generation, const MotionConfig& motionConfig,
                           const FaceConfig& faceConfig, const HazardConfig& hazardConfig);

    void onSoftwareMotion(const StreamToken& token, std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions);
    void onSoftwareFace(const StreamToken& token, std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions,
                        std::uint64_t trackId);
    void onSoftwareHazard(const StreamToken& token, AlarmType type, std::int64_t timestampMs, double confidence, const std::vector<Rect>& regions);
    void onFaceConfirmation(FaceRegionalConfirmationResult result);
    void onHazardConfirmation(HazardRegionalConfirmationResult result);

private:
    struct StreamOnboardState {
        std::shared_ptr<FrameCorrelationStore> frames;
        std::shared_ptr<AlarmCorrelator> correlator;
        std::shared_ptr<OnboardMetricsState> metrics;
        std::uint64_t generation = 0;
        MotionConfig motionConfig;
        FaceConfig faceConfig;
        HazardConfig hazardConfig;
    };

    struct ConfirmationJob {
        OnboardConfirmationContext context;
    };

    AlarmType candidateTypeToAlarm(CandidateType type) const;
    DetectionMode detectionModeFor(CandidateType type, const OnboardConfirmationContext& context) const;
    bool acceptsCandidateType(CandidateType type, const OnboardConfirmationContext& context) const;
    static double expansionFactorFor(CandidateType type, const OnboardConfig& config);
    void dispatchAlarmRequest(const AlarmDispatchRequest& request, OnboardMetricsState& metrics);
    void workerLoop();
    void processConfirmationJob(ConfirmationJob job);
    bool isTokenActive(const StreamToken& token) const;
    bool dispatchIfTokenActive(const AlarmDispatchRequest& request, OnboardMetricsState& metrics, const StreamToken& token);
    void expireTimedOutIncidents();
    void expireTimedOutIncidentsForStream(const StreamToken& token, OnboardMetricsState& metrics);
    Result scheduleFaceConfirmation(const OnboardConfirmationContext& context, const MappedCandidateRegion& mapped, OnboardMetricsState& metrics);
    Result scheduleHazardConfirmation(const OnboardConfirmationContext& context, const MappedCandidateRegion& mapped, OnboardMetricsState& metrics);
    std::shared_ptr<OnboardMetricsState> metricsForStream(const std::string& streamId) const;

    OnboardConfig config_;
    AlarmDispatchCallback callbacks_;
    std::function<bool(const StreamToken& token)> activeTokenValidator_;
    FaceScheduler* faceScheduler_ = nullptr;
    HazardScheduler* hazardScheduler_ = nullptr;

    std::atomic<bool> stopping_{false};
    std::thread worker_;
    std::mutex queueMutex_;
    std::condition_variable queueCv_;
    std::deque<ConfirmationJob> queue_;

    mutable std::mutex stateMutex_;
    std::unordered_map<std::string, StreamOnboardState> streams_;
};

}  // namespace guardvision
