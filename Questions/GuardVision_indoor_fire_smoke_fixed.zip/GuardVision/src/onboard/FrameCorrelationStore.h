#pragma once

#include <cstdint>
#include <deque>
#include <mutex>
#include <optional>
#include <string>

#include <frame/VideoFrame.h>

namespace guardvision {

struct CorrelatedFrame {
    std::uint64_t sequence = 0;
    std::int64_t timestampMs = 0;
    VideoFrame frame;
};

class FrameCorrelationStore {
public:
    explicit FrameCorrelationStore(int maximumFrames = 8);

    void addFrame(VideoFrame frame);
    void clear();
    std::optional<CorrelatedFrame> findClosestFrame(std::int64_t timestampMs, int maximumDifferenceMs) const;

private:
    int maximumFrames_;
    mutable std::mutex mutex_;
    std::deque<CorrelatedFrame> frames_;
};

}  // namespace guardvision
