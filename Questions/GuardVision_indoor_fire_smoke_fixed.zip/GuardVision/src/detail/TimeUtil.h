#pragma once

#include <chrono>
#include <cstdlib>

namespace guardvision {
namespace detail {

inline std::int64_t steadyNowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

inline int testFrameProcessingDelayMs() {
#if defined(GUARDVISION_TEST_HOOKS)
    const char* value = std::getenv("GUARDVISION_TEST_FRAME_PROCESSING_DELAY_MS");
    if (value == nullptr || *value == '\0') {
        return 0;
    }
    return std::atoi(value);
#else
    return 0;
#endif
}

}  // namespace detail
}  // namespace guardvision
