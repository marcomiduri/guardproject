#pragma once

#include <string>

#include <core/SubmitResult.h>

namespace guardvision {
namespace detail {

inline SubmitResult makeAcceptedSubmitResult() {
    SubmitResult result;
    result.status = SubmitStatus::Accepted;
    result.accepted = true;
    return result;
}

inline SubmitResult makeRejectedSubmitResult(SubmitStatus status, GuardVisionErrorCode code, const std::string& message, const std::string& component,
                                             const std::string& streamId = std::string()) {
    SubmitResult result;
    result.status = status;
    result.accepted = false;
    result.error.code = code;
    result.error.component = component;
    result.error.streamId = streamId;
    result.error.message = message;
    return result;
}

}  // namespace detail
}  // namespace guardvision
