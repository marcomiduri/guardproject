#include "detail/ConfigNormalization.h"

namespace guardvision {

void normalizeMotionConfig(MotionConfig& config) noexcept {
    if (config.detectionMode == DetectionMode::Disabled) {
        config.enabled = false;
        return;
    }
    config.enabled = true;
}

void normalizeFaceConfig(FaceConfig& config) noexcept {
    if (config.detectionMode == DetectionMode::Disabled) {
        config.processingLevel = FaceProcessingLevel::Disabled;
        return;
    }
    if (config.processingLevel == FaceProcessingLevel::Disabled) {
        config.detectionMode = DetectionMode::Disabled;
        return;
    }
    switch (config.detectionMode) {
        case DetectionMode::Software:
            config.triggerMode = FaceTriggerMode::ContinuousSoftware;
            break;
        case DetectionMode::OnboardTriggered:
            config.triggerMode = FaceTriggerMode::OnboardTriggered;
            break;
        case DetectionMode::Hybrid:
            config.triggerMode = FaceTriggerMode::Hybrid;
            break;
        default:
            break;
    }
}

void normalizeHazardConfig(HazardConfig& config) noexcept {
    if (config.detectionMode == DetectionMode::Disabled) {
        config.processingLevel = HazardProcessingLevel::Disabled;
        return;
    }
    if (config.processingLevel == HazardProcessingLevel::Disabled) {
        config.detectionMode = DetectionMode::Disabled;
        return;
    }
}

bool isMotionAnalyticActive(const MotionConfig& config) noexcept {
    return config.detectionMode != DetectionMode::Disabled;
}

bool isFaceAnalyticActive(const FaceConfig& config) noexcept {
    return config.detectionMode != DetectionMode::Disabled && config.processingLevel != FaceProcessingLevel::Disabled;
}

bool isHazardAnalyticActive(const HazardConfig& config) noexcept {
    return config.detectionMode != DetectionMode::Disabled && config.processingLevel == HazardProcessingLevel::Detect;
}

}  // namespace guardvision
