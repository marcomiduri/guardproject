#pragma once

#include <atomic>

namespace guardvision::detail {

template <typename T>
void updateAtomicMaximum(std::atomic<T>& target, T value) noexcept {
    T current = target.load(std::memory_order_relaxed);
    while (current < value && !target.compare_exchange_weak(current, value, std::memory_order_relaxed, std::memory_order_relaxed)) {
    }
}

}  // namespace guardvision::detail
