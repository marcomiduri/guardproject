#pragma once

#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <face/FaceTypes.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>

namespace guardvision {

void normalizeMotionConfig(MotionConfig& config) noexcept;
void normalizeFaceConfig(FaceConfig& config) noexcept;
void normalizeHazardConfig(HazardConfig& config) noexcept;

bool isMotionAnalyticActive(const MotionConfig& config) noexcept;
bool isFaceAnalyticActive(const FaceConfig& config) noexcept;
bool isHazardAnalyticActive(const HazardConfig& config) noexcept;

}  // namespace guardvision
