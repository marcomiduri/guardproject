#pragma once

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>

#include <face/FaceMetrics.h>
#include <hazard/HazardMetrics.h>
#include <motion/MotionMetrics.h>
#include <onboard/OnboardMetrics.h>
#include <core/StreamMetrics.h>

#include "metrics/FaceMetricsState.h"
#include "metrics/HazardMetricsState.h"
#include "metrics/MotionMetricsState.h"
#include "metrics/OnboardMetricsState.h"

namespace guardvision {

struct StreamMetricsState {
    std::atomic<std::uint64_t> submittedFrames{0};
    std::atomic<std::uint64_t> acceptedFrames{0};
    std::atomic<std::uint64_t> rejectedFrames{0};
    std::atomic<std::uint64_t> replacedFrames{0};
    std::atomic<std::uint64_t> processedFrames{0};
    std::atomic<std::uint64_t> staleJobsDiscarded{0};
    std::atomic<std::uint64_t> queueOverflowCount{0};
    std::atomic<std::int64_t> lastQueueDelayMs{0};
    std::atomic<std::int64_t> maximumQueueDelayMs{0};
    std::atomic<bool> hasPendingFrame{false};
    std::atomic<bool> processingFrame{false};
};

struct RuntimeMetricsState {
    std::atomic<std::uint64_t> activeStreams{0};
    std::atomic<std::uint64_t> submittedFrames{0};
    std::atomic<std::uint64_t> acceptedFrames{0};
    std::atomic<std::uint64_t> rejectedFrames{0};
    std::atomic<std::uint64_t> replacedFrames{0};
    std::atomic<std::uint64_t> processedFrames{0};
    std::atomic<std::uint64_t> staleJobsDiscarded{0};
    std::atomic<std::uint64_t> queueOverflowCount{0};
    std::atomic<std::uint64_t> dispatchedEvents{0};
    std::atomic<std::uint64_t> droppedEvents{0};
};

class MetricsRegistry {
public:
    std::shared_ptr<StreamMetricsState> streamMetricsHandle(const std::string& streamId);
    std::shared_ptr<MotionMetricsState> motionMetricsHandle(const std::string& streamId);
    std::shared_ptr<FaceMetricsState> faceMetricsHandle(const std::string& streamId);
    std::shared_ptr<HazardMetricsState> hazardMetricsHandle(const std::string& streamId);
    std::shared_ptr<OnboardMetricsState> onboardMetricsHandle(const std::string& streamId);

    std::shared_ptr<FaceMetricsState> findFaceMetricsHandle(const std::string& streamId) const;
    std::shared_ptr<HazardMetricsState> findHazardMetricsHandle(const std::string& streamId) const;

    StreamMetricsState& streamMetrics(const std::string& streamId);
    MotionMetricsState& motionMetrics(const std::string& streamId);
    FaceMetricsState& faceMetrics(const std::string& streamId);
    HazardMetricsState& hazardMetrics(const std::string& streamId);
    OnboardMetricsState& onboardMetrics(const std::string& streamId);

    void removeStream(const std::string& streamId);
    RuntimeMetricsState& runtime();
    StreamMetrics snapshotStream(const std::string& streamId, bool hasPending, bool processing) const;
    MotionMetrics snapshotMotion(const std::string& streamId) const;
    FaceMetrics snapshotFace(const std::string& streamId) const;
    HazardMetrics snapshotHazard(const std::string& streamId) const;
    OnboardMetrics snapshotOnboard(const std::string& streamId) const;
    RuntimeMetrics snapshotRuntime(std::uint64_t dispatchedEvents, std::uint64_t droppedEvents) const;
    void clear();

private:
    mutable std::mutex mutex_;
    std::unordered_map<std::string, std::shared_ptr<StreamMetricsState>> streams_;
    std::unordered_map<std::string, std::shared_ptr<MotionMetricsState>> motionStreams_;
    std::unordered_map<std::string, std::shared_ptr<FaceMetricsState>> faceStreams_;
    std::unordered_map<std::string, std::shared_ptr<HazardMetricsState>> hazardStreams_;
    std::unordered_map<std::string, std::shared_ptr<OnboardMetricsState>> onboardStreams_;
    RuntimeMetricsState runtime_;
};

}  // namespace guardvision
