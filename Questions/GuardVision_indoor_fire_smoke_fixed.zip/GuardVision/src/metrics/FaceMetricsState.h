#pragma once

#include <atomic>
#include <cstdint>

#include <face/FaceTypes.h>

namespace guardvision {

struct FaceMetricsState {
    std::atomic<bool> enabled{false};
    std::atomic<FaceProcessingLevel> processingLevel{FaceProcessingLevel::Disabled};

    std::atomic<std::uint64_t> receivedFrames{0};
    std::atomic<std::uint64_t> scheduledFrames{0};
    std::atomic<std::uint64_t> analyzedFrames{0};
    std::atomic<std::uint64_t> skippedByInterval{0};
    std::atomic<std::uint64_t> replacedPendingFrames{0};
    std::atomic<std::uint64_t> staleWorkDiscarded{0};

    std::atomic<std::uint64_t> detectedFaces{0};
    std::atomic<std::uint64_t> filteredFaces{0};
    std::atomic<std::uint64_t> appearedTracks{0};
    std::atomic<std::uint64_t> lostTracks{0};

    std::atomic<std::uint64_t> identificationAttempts{0};
    std::atomic<std::uint64_t> identificationMatches{0};
    std::atomic<std::uint64_t> identificationMisses{0};
    std::atomic<std::uint64_t> cachedIdentityUses{0};

    std::atomic<std::uint64_t> droppedUpdateEvents{0};
    std::atomic<std::uint64_t> processingErrors{0};

    std::atomic<std::int64_t> lastProcessingTimeUs{0};
    std::atomic<std::int64_t> maximumProcessingTimeUs{0};

    std::atomic<int> activeTrackCount{0};
    std::atomic<int> assignedWorkerIndex{-1};
};

}  // namespace guardvision
