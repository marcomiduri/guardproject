#include "metrics/MetricsRegistry.h"

namespace guardvision {
namespace {

template <typename State>
std::shared_ptr<State> getOrCreateState(std::unordered_map<std::string, std::shared_ptr<State>>& states, const std::string& streamId) {
    auto [it, inserted] = states.try_emplace(streamId);
    if (inserted || !it->second) {
        it->second = std::make_shared<State>();
    }
    return it->second;
}

template <typename State>
std::shared_ptr<State> findState(const std::unordered_map<std::string, std::shared_ptr<State>>& states, const std::string& streamId) {
    const auto it = states.find(streamId);
    return it != states.end() ? it->second : std::shared_ptr<State>{};
}

template <typename Atomic>
auto loadMetric(const Atomic& value) noexcept {
    return value.load(std::memory_order_relaxed);
}

}  // namespace

std::shared_ptr<StreamMetricsState> MetricsRegistry::streamMetricsHandle(const std::string& streamId) {
    std::lock_guard<std::mutex> lock(mutex_);
    return getOrCreateState(streams_, streamId);
}

std::shared_ptr<MotionMetricsState> MetricsRegistry::motionMetricsHandle(const std::string& streamId) {
    std::lock_guard<std::mutex> lock(mutex_);
    return getOrCreateState(motionStreams_, streamId);
}

std::shared_ptr<FaceMetricsState> MetricsRegistry::faceMetricsHandle(const std::string& streamId) {
    std::lock_guard<std::mutex> lock(mutex_);
    return getOrCreateState(faceStreams_, streamId);
}

std::shared_ptr<HazardMetricsState> MetricsRegistry::hazardMetricsHandle(const std::string& streamId) {
    std::lock_guard<std::mutex> lock(mutex_);
    return getOrCreateState(hazardStreams_, streamId);
}

std::shared_ptr<OnboardMetricsState> MetricsRegistry::onboardMetricsHandle(const std::string& streamId) {
    std::lock_guard<std::mutex> lock(mutex_);
    return getOrCreateState(onboardStreams_, streamId);
}

std::shared_ptr<FaceMetricsState> MetricsRegistry::findFaceMetricsHandle(const std::string& streamId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return findState(faceStreams_, streamId);
}

std::shared_ptr<HazardMetricsState> MetricsRegistry::findHazardMetricsHandle(const std::string& streamId) const {
    std::lock_guard<std::mutex> lock(mutex_);
    return findState(hazardStreams_, streamId);
}

StreamMetricsState& MetricsRegistry::streamMetrics(const std::string& streamId) {
    return *streamMetricsHandle(streamId);
}

MotionMetricsState& MetricsRegistry::motionMetrics(const std::string& streamId) {
    return *motionMetricsHandle(streamId);
}

FaceMetricsState& MetricsRegistry::faceMetrics(const std::string& streamId) {
    return *faceMetricsHandle(streamId);
}

HazardMetricsState& MetricsRegistry::hazardMetrics(const std::string& streamId) {
    return *hazardMetricsHandle(streamId);
}

OnboardMetricsState& MetricsRegistry::onboardMetrics(const std::string& streamId) {
    return *onboardMetricsHandle(streamId);
}

void MetricsRegistry::removeStream(const std::string& streamId) {
    std::lock_guard<std::mutex> lock(mutex_);
    streams_.erase(streamId);
    motionStreams_.erase(streamId);
    faceStreams_.erase(streamId);
    hazardStreams_.erase(streamId);
    onboardStreams_.erase(streamId);
}

RuntimeMetricsState& MetricsRegistry::runtime() {
    return runtime_;
}

StreamMetrics MetricsRegistry::snapshotStream(const std::string& streamId, bool hasPending, bool processing) const {
    StreamMetrics snapshot;
    snapshot.streamId = streamId;
    snapshot.hasPendingFrame = hasPending;
    snapshot.processingFrame = processing;

    std::shared_ptr<StreamMetricsState> state;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        state = findState(streams_, streamId);
    }
    if (!state) {
        return snapshot;
    }

    snapshot.submittedFrames = loadMetric(state->submittedFrames);
    snapshot.acceptedFrames = loadMetric(state->acceptedFrames);
    snapshot.rejectedFrames = loadMetric(state->rejectedFrames);
    snapshot.replacedFrames = loadMetric(state->replacedFrames);
    snapshot.processedFrames = loadMetric(state->processedFrames);
    snapshot.staleJobsDiscarded = loadMetric(state->staleJobsDiscarded);
    snapshot.queueOverflowCount = loadMetric(state->queueOverflowCount);
    snapshot.lastQueueDelayMs = loadMetric(state->lastQueueDelayMs);
    snapshot.maximumQueueDelayMs = loadMetric(state->maximumQueueDelayMs);
    return snapshot;
}

MotionMetrics MetricsRegistry::snapshotMotion(const std::string& streamId) const {
    MotionMetrics snapshot;
    snapshot.streamId = streamId;

    std::shared_ptr<MotionMetricsState> state;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        state = findState(motionStreams_, streamId);
    }
    if (!state) {
        return snapshot;
    }

    snapshot.enabled = loadMetric(state->enabled);
    snapshot.state = loadMetric(state->state);
    snapshot.receivedFrames = loadMetric(state->receivedFrames);
    snapshot.analyzedFrames = loadMetric(state->analyzedFrames);
    snapshot.skippedByInterval = loadMetric(state->skippedByInterval);
    snapshot.baselineFrames = loadMetric(state->baselineFrames);
    snapshot.startedEvents = loadMetric(state->startedEvents);
    snapshot.updatedEvents = loadMetric(state->updatedEvents);
    snapshot.endedEvents = loadMetric(state->endedEvents);
    snapshot.extractedRegions = loadMetric(state->extractedRegions);
    snapshot.truncatedRegions = loadMetric(state->truncatedRegions);
    snapshot.staleWorkDiscarded = loadMetric(state->staleWorkDiscarded);
    snapshot.processingErrors = loadMetric(state->processingErrors);
    snapshot.lastProcessingTimeUs = loadMetric(state->lastProcessingTimeUs);
    snapshot.maximumProcessingTimeUs = loadMetric(state->maximumProcessingTimeUs);
    snapshot.lastChangedAreaRatio = loadMetric(state->lastChangedAreaRatio);
    snapshot.analysisWidth = loadMetric(state->analysisWidth);
    snapshot.analysisHeight = loadMetric(state->analysisHeight);
    return snapshot;
}

FaceMetrics MetricsRegistry::snapshotFace(const std::string& streamId) const {
    FaceMetrics snapshot;
    snapshot.streamId = streamId;

    const std::shared_ptr<FaceMetricsState> state = findFaceMetricsHandle(streamId);
    if (!state) {
        return snapshot;
    }

    snapshot.enabled = loadMetric(state->enabled);
    snapshot.processingLevel = loadMetric(state->processingLevel);
    snapshot.receivedFrames = loadMetric(state->receivedFrames);
    snapshot.scheduledFrames = loadMetric(state->scheduledFrames);
    snapshot.analyzedFrames = loadMetric(state->analyzedFrames);
    snapshot.skippedByInterval = loadMetric(state->skippedByInterval);
    snapshot.replacedPendingFrames = loadMetric(state->replacedPendingFrames);
    snapshot.staleWorkDiscarded = loadMetric(state->staleWorkDiscarded);
    snapshot.detectedFaces = loadMetric(state->detectedFaces);
    snapshot.filteredFaces = loadMetric(state->filteredFaces);
    snapshot.appearedTracks = loadMetric(state->appearedTracks);
    snapshot.lostTracks = loadMetric(state->lostTracks);
    snapshot.identificationAttempts = loadMetric(state->identificationAttempts);
    snapshot.identificationMatches = loadMetric(state->identificationMatches);
    snapshot.identificationMisses = loadMetric(state->identificationMisses);
    snapshot.cachedIdentityUses = loadMetric(state->cachedIdentityUses);
    snapshot.droppedUpdateEvents = loadMetric(state->droppedUpdateEvents);
    snapshot.processingErrors = loadMetric(state->processingErrors);
    snapshot.lastProcessingTimeUs = loadMetric(state->lastProcessingTimeUs);
    snapshot.maximumProcessingTimeUs = loadMetric(state->maximumProcessingTimeUs);
    snapshot.activeTrackCount = loadMetric(state->activeTrackCount);
    snapshot.assignedWorkerIndex = loadMetric(state->assignedWorkerIndex);
    return snapshot;
}

HazardMetrics MetricsRegistry::snapshotHazard(const std::string& streamId) const {
    HazardMetrics snapshot;
    snapshot.streamId = streamId;

    const std::shared_ptr<HazardMetricsState> state = findHazardMetricsHandle(streamId);
    if (!state) {
        return snapshot;
    }

    snapshot.enabled = loadMetric(state->enabled);
    snapshot.processingLevel = loadMetric(state->processingLevel);
    snapshot.receivedFrames = loadMetric(state->receivedFrames);
    snapshot.scheduledFrames = loadMetric(state->scheduledFrames);
    snapshot.analyzedFrames = loadMetric(state->analyzedFrames);
    snapshot.skippedByInterval = loadMetric(state->skippedByInterval);
    snapshot.replacedPendingFrames = loadMetric(state->replacedPendingFrames);
    snapshot.staleWorkDiscarded = loadMetric(state->staleWorkDiscarded);
    snapshot.fireDetections = loadMetric(state->fireDetections);
    snapshot.smokeDetections = loadMetric(state->smokeDetections);
    snapshot.filteredRegions = loadMetric(state->filteredRegions);
    snapshot.startedEvents = loadMetric(state->startedEvents);
    snapshot.updatedEvents = loadMetric(state->updatedEvents);
    snapshot.endedEvents = loadMetric(state->endedEvents);
    snapshot.droppedUpdateEvents = loadMetric(state->droppedUpdateEvents);
    snapshot.processingErrors = loadMetric(state->processingErrors);
    snapshot.lastProcessingTimeUs = loadMetric(state->lastProcessingTimeUs);
    snapshot.maximumProcessingTimeUs = loadMetric(state->maximumProcessingTimeUs);
    snapshot.activeFireState = loadMetric(state->activeFireState);
    snapshot.activeSmokeState = loadMetric(state->activeSmokeState);
    snapshot.assignedWorkerIndex = loadMetric(state->assignedWorkerIndex);
    return snapshot;
}

OnboardMetrics MetricsRegistry::snapshotOnboard(const std::string& streamId) const {
    OnboardMetrics snapshot;

    std::shared_ptr<OnboardMetricsState> state;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        state = findState(onboardStreams_, streamId);
    }
    if (!state) {
        return snapshot;
    }

    snapshot.candidatesReceived = loadMetric(state->candidatesReceived);
    snapshot.candidatesAccepted = loadMetric(state->candidatesAccepted);
    snapshot.candidatesRejected = loadMetric(state->candidatesRejected);
    snapshot.invalidCandidates = loadMetric(state->invalidCandidates);
    snapshot.staleGenerationCandidates = loadMetric(state->staleGenerationCandidates);
    snapshot.staleTimestampCandidates = loadMetric(state->staleTimestampCandidates);
    snapshot.candidatesWithoutMatchingFrames = loadMetric(state->candidatesWithoutMatchingFrames);
    snapshot.candidatesExpired = loadMetric(state->candidatesExpired);
    snapshot.coordinateConversions = loadMetric(state->coordinateConversions);
    snapshot.mainStreamToSubstreamMappings = loadMetric(state->mainStreamToSubstreamMappings);
    snapshot.expandedRegions = loadMetric(state->expandedRegions);
    snapshot.regionalConfirmationsRequested = loadMetric(state->regionalConfirmationsRequested);
    snapshot.confirmationsPassed = loadMetric(state->confirmationsPassed);
    snapshot.confirmationsFailed = loadMetric(state->confirmationsFailed);
    snapshot.alarmsStarted = loadMetric(state->alarmsStarted);
    snapshot.alarmsUpdated = loadMetric(state->alarmsUpdated);
    snapshot.alarmsEnded = loadMetric(state->alarmsEnded);
    snapshot.hybridAlarms = loadMetric(state->hybridAlarms);
    snapshot.duplicatesSuppressed = loadMetric(state->duplicatesSuppressed);
    snapshot.activeCorrelationEntries = loadMetric(state->activeCorrelationEntries);
    snapshot.capabilityQueryFailures = loadMetric(state->capabilityQueryFailures);
    snapshot.alarmSubscriptionFailures = loadMetric(state->alarmSubscriptionFailures);
    snapshot.processingErrors = loadMetric(state->processingErrors);
    return snapshot;
}

RuntimeMetrics MetricsRegistry::snapshotRuntime(std::uint64_t dispatchedEvents, std::uint64_t droppedEvents) const {
    RuntimeMetrics snapshot;
    snapshot.activeStreams = loadMetric(runtime_.activeStreams);
    snapshot.submittedFrames = loadMetric(runtime_.submittedFrames);
    snapshot.acceptedFrames = loadMetric(runtime_.acceptedFrames);
    snapshot.rejectedFrames = loadMetric(runtime_.rejectedFrames);
    snapshot.replacedFrames = loadMetric(runtime_.replacedFrames);
    snapshot.processedFrames = loadMetric(runtime_.processedFrames);
    snapshot.staleJobsDiscarded = loadMetric(runtime_.staleJobsDiscarded);
    snapshot.queueOverflowCount = loadMetric(runtime_.queueOverflowCount);
    snapshot.dispatchedEvents = dispatchedEvents;
    snapshot.droppedEvents = droppedEvents;
    return snapshot;
}

void MetricsRegistry::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    streams_.clear();
    motionStreams_.clear();
    faceStreams_.clear();
    hazardStreams_.clear();
    onboardStreams_.clear();
    runtime_.activeStreams.store(0, std::memory_order_relaxed);
    runtime_.submittedFrames.store(0, std::memory_order_relaxed);
    runtime_.acceptedFrames.store(0, std::memory_order_relaxed);
    runtime_.rejectedFrames.store(0, std::memory_order_relaxed);
    runtime_.replacedFrames.store(0, std::memory_order_relaxed);
    runtime_.processedFrames.store(0, std::memory_order_relaxed);
    runtime_.staleJobsDiscarded.store(0, std::memory_order_relaxed);
    runtime_.queueOverflowCount.store(0, std::memory_order_relaxed);
}

}  // namespace guardvision
