#pragma once

#include <atomic>
#include <cstdint>

#include <motion/MotionMetrics.h>
#include <motion/MotionTypes.h>

namespace guardvision {

struct MotionMetricsState {
    std::atomic<bool> enabled{false};
    std::atomic<MotionState> state{MotionState::Idle};

    std::atomic<std::uint64_t> receivedFrames{0};
    std::atomic<std::uint64_t> analyzedFrames{0};
    std::atomic<std::uint64_t> skippedByInterval{0};
    std::atomic<std::uint64_t> baselineFrames{0};

    std::atomic<std::uint64_t> startedEvents{0};
    std::atomic<std::uint64_t> updatedEvents{0};
    std::atomic<std::uint64_t> endedEvents{0};

    std::atomic<std::uint64_t> extractedRegions{0};
    std::atomic<std::uint64_t> truncatedRegions{0};

    std::atomic<std::uint64_t> staleWorkDiscarded{0};
    std::atomic<std::uint64_t> processingErrors{0};

    std::atomic<std::int64_t> lastProcessingTimeUs{0};
    std::atomic<std::int64_t> maximumProcessingTimeUs{0};

    std::atomic<double> lastChangedAreaRatio{0.0};

    std::atomic<int> analysisWidth{0};
    std::atomic<int> analysisHeight{0};
};

}  // namespace guardvision
