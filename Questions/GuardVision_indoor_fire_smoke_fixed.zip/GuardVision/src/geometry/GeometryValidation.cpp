#include <geometry/Geometry.h>

#include <algorithm>
#include <cmath>

namespace guardvision {
namespace {

int clampInt(int value, int minValue, int maxValue) {
    return std::max(minValue, std::min(value, maxValue));
}

Rect makeInvalidRect() {
    return Rect{};
}

}  // namespace

Rect clampRect(const Rect& rect, Size frameSize) {
    if (!frameSize.isValid() || !rect.isValid()) {
        return makeInvalidRect();
    }

    const int clampedX = clampInt(rect.x, 0, frameSize.width - 1);
    const int clampedY = clampInt(rect.y, 0, frameSize.height - 1);
    const int maxWidth = frameSize.width - clampedX;
    const int maxHeight = frameSize.height - clampedY;
    const int clampedWidth = std::min(rect.width, maxWidth);
    const int clampedHeight = std::min(rect.height, maxHeight);
    if (clampedWidth <= 0 || clampedHeight <= 0) {
        return makeInvalidRect();
    }
    return Rect{clampedX, clampedY, clampedWidth, clampedHeight};
}

Rect normalizedRectToPixels(const NormalizedRect& rect, Size frameSize) {
    if (!rect.isValid() || !frameSize.isValid()) {
        return makeInvalidRect();
    }

    const int x = static_cast<int>(std::floor(rect.x * frameSize.width));
    const int y = static_cast<int>(std::floor(rect.y * frameSize.height));
    const int right = static_cast<int>(std::ceil((rect.x + rect.width) * frameSize.width));
    const int bottom = static_cast<int>(std::ceil((rect.y + rect.height) * frameSize.height));
    Rect pixelRect{x, y, std::max(0, right - x), std::max(0, bottom - y)};
    return clampRect(pixelRect, frameSize);
}

Rect mapRectBetweenResolutions(const Rect& rect, Size sourceSize, Size targetSize) {
    if (!rect.isValid() || !sourceSize.isValid() || !targetSize.isValid()) {
        return makeInvalidRect();
    }

    const double scaleX = static_cast<double>(targetSize.width) / static_cast<double>(sourceSize.width);
    const double scaleY = static_cast<double>(targetSize.height) / static_cast<double>(sourceSize.height);
    Rect mapped{
      static_cast<int>(std::floor(rect.x * scaleX)),
      static_cast<int>(std::floor(rect.y * scaleY)),
      static_cast<int>(std::round(rect.width * scaleX)),
      static_cast<int>(std::round(rect.height * scaleY)),
    };
    return clampRect(mapped, targetSize);
}

Rect expandRectAroundCenter(const Rect& rect, double scale, Size frameSize) {
    if (!rect.isValid() || !frameSize.isValid() || scale <= 0.0) {
        return makeInvalidRect();
    }

    const double centerX = rect.x + (rect.width / 2.0);
    const double centerY = rect.y + (rect.height / 2.0);
    const int newWidth = static_cast<int>(std::round(rect.width * scale));
    const int newHeight = static_cast<int>(std::round(rect.height * scale));
    Rect expanded{
      static_cast<int>(std::round(centerX - (newWidth / 2.0))),
      static_cast<int>(std::round(centerY - (newHeight / 2.0))),
      newWidth,
      newHeight,
    };
    return clampRect(expanded, frameSize);
}

Rect mapRoiRectToFullFrame(const Rect& roi, const Rect& roiRelativeRect) {
    if (!roi.isValid() || !roiRelativeRect.isValid()) {
        return makeInvalidRect();
    }

    Rect mapped{
      roi.x + roiRelativeRect.x,
      roi.y + roiRelativeRect.y,
      roiRelativeRect.width,
      roiRelativeRect.height,
    };
    Rect local{
      mapped.x - roi.x,
      mapped.y - roi.y,
      mapped.width,
      mapped.height,
    };
    const Rect clampedLocal = clampRect(local, Size{roi.width, roi.height});
    if (!clampedLocal.isValid()) {
        return makeInvalidRect();
    }
    return Rect{
      clampedLocal.x + roi.x,
      clampedLocal.y + roi.y,
      clampedLocal.width,
      clampedLocal.height,
    };
}

double intersectOverUnion(const Rect& a, const Rect& b) noexcept {
    if (!a.isValid() || !b.isValid()) {
        return 0.0;
    }

    const int overlapLeft = std::max(a.x, b.x);
    const int overlapTop = std::max(a.y, b.y);
    const int overlapRight = std::min(a.right(), b.right());
    const int overlapBottom = std::min(a.bottom(), b.bottom());
    if (overlapRight <= overlapLeft || overlapBottom <= overlapTop) {
        return 0.0;
    }

    const double intersection = static_cast<double>(overlapRight - overlapLeft) * static_cast<double>(overlapBottom - overlapTop);
    const double areaA = static_cast<double>(a.width) * static_cast<double>(a.height);
    const double areaB = static_cast<double>(b.width) * static_cast<double>(b.height);
    const double unionArea = areaA + areaB - intersection;
    if (unionArea <= 0.0) {
        return 0.0;
    }
    return intersection / unionArea;
}

}  // namespace guardvision
