#include <geometry/Geometry.h>

namespace guardvision {

bool Size::isValid() const noexcept {
    return width > 0 && height > 0;
}

bool Rect::isValid() const noexcept {
    return width > 0 && height > 0;
}

int Rect::right() const noexcept {
    return x + width;
}

int Rect::bottom() const noexcept {
    return y + height;
}

bool NormalizedRect::isValid() const noexcept {
    return x >= 0.0 && y >= 0.0 && width > 0.0 && height > 0.0 && (x + width) <= 1.0 && (y + height) <= 1.0;
}

}  // namespace guardvision
