#pragma once

#include <condition_variable>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>

#include <events/EventListener.h>

namespace guardvision {

class EventListenerRegistry {
public:
    class Lease {
    public:
        Lease() = default;
        Lease(EventListenerRegistry* registry, IGuardVisionEventListener* listener, std::shared_ptr<IGuardVisionEventListener> keepAlive,
              std::thread::id ownerThread);
        Lease(const Lease&) = delete;
        Lease& operator=(const Lease&) = delete;
        Lease(Lease&& other) noexcept;
        Lease& operator=(Lease&& other) noexcept;
        ~Lease();

        IGuardVisionEventListener* get() const noexcept;
        explicit operator bool() const noexcept;

    private:
        void release();

        EventListenerRegistry* registry_ = nullptr;
        IGuardVisionEventListener* listener_ = nullptr;
        std::shared_ptr<IGuardVisionEventListener> keepAlive_;
        std::thread::id ownerThread_{};
    };

    void setListener(IGuardVisionEventListener* listener);
    void setListener(std::shared_ptr<IGuardVisionEventListener> listener);
    void detachAndStop();
    Lease acquire();

private:
    void setListenerImpl(IGuardVisionEventListener* listener, std::shared_ptr<IGuardVisionEventListener> owner);
    void releaseLease(std::thread::id ownerThread);
    int activeCallbacksForThreadLocked(std::thread::id threadId) const;
    void applyPendingListenerLocked();

    mutable std::mutex mutex_;
    std::condition_variable cv_;
    IGuardVisionEventListener* listener_ = nullptr;
    std::shared_ptr<IGuardVisionEventListener> ownedListener_;
    IGuardVisionEventListener* pendingListener_ = nullptr;
    std::shared_ptr<IGuardVisionEventListener> pendingOwnedListener_;
    std::unordered_map<std::thread::id, int> activeCallbacksByThread_;
    int activeCallbacks_ = 0;
    bool acceptingCallbacks_ = true;
    bool pendingListenerChange_ = false;
};

using EventListenerRegistryPtr = std::shared_ptr<EventListenerRegistry>;

}  // namespace guardvision
