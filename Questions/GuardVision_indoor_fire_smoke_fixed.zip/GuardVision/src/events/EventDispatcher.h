#pragma once

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <deque>
#include <functional>
#include <mutex>
#include <thread>

#include <events/EventListener.h>

#include "events/EventListenerRegistry.h"
#include "events/RuntimeEvent.h"

namespace guardvision {

class EventDispatcher {
public:
    using ListenerProvider = std::function<EventListenerRegistry::Lease()>;

    explicit EventDispatcher(std::size_t capacity, ListenerProvider listenerProvider);
    ~EventDispatcher();

    EventDispatcher(const EventDispatcher&) = delete;
    EventDispatcher& operator=(const EventDispatcher&) = delete;

    bool post(RuntimeEvent event);
    void stop();
    void join();
    bool isDispatchThread() const noexcept;

    std::uint64_t dispatchedEvents() const;
    std::uint64_t droppedEvents() const;
    std::uint64_t listenerFailures() const;

private:
    void dispatchLoop();
    void dispatchToListener(IGuardVisionEventListener& listener, const RuntimeEvent& event);
    bool pushEventLocked(RuntimeEvent event);
    void evictOldestFrameProcessedLocked();

    std::size_t capacity_;
    ListenerProvider listenerProvider_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::deque<RuntimeEvent> queue_;
    std::thread thread_;
    std::atomic<bool> stopping_{false};
    std::atomic<std::uint64_t> dispatchedEvents_{0};
    std::atomic<std::uint64_t> droppedEvents_{0};
    std::atomic<std::uint64_t> listenerFailures_{0};
};

}  // namespace guardvision
