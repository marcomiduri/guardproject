#include "events/EventListenerRegistry.h"

#include <utility>

namespace guardvision {

EventListenerRegistry::Lease::Lease(EventListenerRegistry* registry, IGuardVisionEventListener* listener,
                                    std::shared_ptr<IGuardVisionEventListener> keepAlive, std::thread::id ownerThread)
: registry_(registry), listener_(listener), keepAlive_(std::move(keepAlive)), ownerThread_(ownerThread) {}

EventListenerRegistry::Lease::Lease(Lease&& other) noexcept
: registry_(std::exchange(other.registry_, nullptr)),
  listener_(std::exchange(other.listener_, nullptr)),
  keepAlive_(std::move(other.keepAlive_)),
  ownerThread_(std::exchange(other.ownerThread_, std::thread::id{})) {}

EventListenerRegistry::Lease& EventListenerRegistry::Lease::operator=(Lease&& other) noexcept {
    if (this != &other) {
        release();
        registry_ = std::exchange(other.registry_, nullptr);
        listener_ = std::exchange(other.listener_, nullptr);
        keepAlive_ = std::move(other.keepAlive_);
        ownerThread_ = std::exchange(other.ownerThread_, std::thread::id{});
    }
    return *this;
}

EventListenerRegistry::Lease::~Lease() {
    release();
}

IGuardVisionEventListener* EventListenerRegistry::Lease::get() const noexcept {
    return listener_;
}

EventListenerRegistry::Lease::operator bool() const noexcept {
    return listener_ != nullptr;
}

void EventListenerRegistry::Lease::release() {
    if (registry_ != nullptr) {
        registry_->releaseLease(ownerThread_);
        registry_ = nullptr;
        listener_ = nullptr;
        keepAlive_.reset();
        ownerThread_ = std::thread::id{};
    }
}

int EventListenerRegistry::activeCallbacksForThreadLocked(std::thread::id threadId) const {
    const auto it = activeCallbacksByThread_.find(threadId);
    return it != activeCallbacksByThread_.end() ? it->second : 0;
}

void EventListenerRegistry::applyPendingListenerLocked() {
    if (!pendingListenerChange_ || activeCallbacks_ != 0) {
        return;
    }
    listener_ = pendingListener_;
    ownedListener_ = std::move(pendingOwnedListener_);
    pendingListener_ = nullptr;
    pendingListenerChange_ = false;
    acceptingCallbacks_ = listener_ != nullptr;
}

void EventListenerRegistry::setListener(IGuardVisionEventListener* listener) {
    setListenerImpl(listener, {});
}

void EventListenerRegistry::setListener(std::shared_ptr<IGuardVisionEventListener> listener) {
    IGuardVisionEventListener* raw = listener.get();
    setListenerImpl(raw, std::move(listener));
}

void EventListenerRegistry::setListenerImpl(IGuardVisionEventListener* listener, std::shared_ptr<IGuardVisionEventListener> owner) {
    std::unique_lock<std::mutex> lock(mutex_);
    acceptingCallbacks_ = false;
    listener_ = nullptr;
    ownedListener_.reset();

    const std::thread::id currentThread = std::this_thread::get_id();
    if (activeCallbacksForThreadLocked(currentThread) > 0) {
        pendingListener_ = listener;
        pendingOwnedListener_ = std::move(owner);
        pendingListenerChange_ = true;
        return;
    }

    cv_.wait(lock, [this]() { return activeCallbacks_ == 0; });
    pendingListener_ = nullptr;
    pendingOwnedListener_.reset();
    pendingListenerChange_ = false;
    listener_ = listener;
    ownedListener_ = std::move(owner);
    acceptingCallbacks_ = listener_ != nullptr;
}

void EventListenerRegistry::detachAndStop() {
    setListener(static_cast<IGuardVisionEventListener*>(nullptr));
}

EventListenerRegistry::Lease EventListenerRegistry::acquire() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!acceptingCallbacks_ || listener_ == nullptr) {
        return Lease{};
    }
    const std::thread::id ownerThread = std::this_thread::get_id();
    ++activeCallbacks_;
    ++activeCallbacksByThread_[ownerThread];
    return Lease(this, listener_, ownedListener_, ownerThread);
}

void EventListenerRegistry::releaseLease(std::thread::id ownerThread) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (activeCallbacks_ > 0) {
        --activeCallbacks_;
    }
    const auto it = activeCallbacksByThread_.find(ownerThread);
    if (it != activeCallbacksByThread_.end()) {
        if (--it->second <= 0) {
            activeCallbacksByThread_.erase(it);
        }
    }
    applyPendingListenerLocked();
    cv_.notify_all();
}

}  // namespace guardvision
