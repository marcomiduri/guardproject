#include "events/EventDispatcher.h"

#include <exception>

#include <face/FaceTypes.h>
#include <hazard/HazardTypes.h>

namespace guardvision {
namespace {

bool isDroppableUpdate(const RuntimeEvent& event) noexcept {
    return event.type == RuntimeEventType::FrameProcessed ||
           (event.type == RuntimeEventType::Motion && event.motion.type == MotionEventType::Updated) ||
           (event.type == RuntimeEventType::Face && event.face.type == FaceEventType::TracksUpdated) ||
           (event.type == RuntimeEventType::Hazard && event.hazard.type == HazardEventType::Updated);
}

}  // namespace

EventDispatcher::EventDispatcher(std::size_t capacity, ListenerProvider listenerProvider)
: capacity_(capacity), listenerProvider_(std::move(listenerProvider)) {
    thread_ = std::thread([this]() { dispatchLoop(); });
}

EventDispatcher::~EventDispatcher() {
    stop();
    join();
}

bool EventDispatcher::post(RuntimeEvent event) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (stopping_) {
        return false;
    }
    if (pushEventLocked(std::move(event))) {
        cv_.notify_one();
        return true;
    }
    droppedEvents_.fetch_add(1, std::memory_order_relaxed);
    return false;
}

void EventDispatcher::stop() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stopping_ = true;
    }
    cv_.notify_all();
}

void EventDispatcher::join() {
    if (thread_.joinable()) {
        if (isDispatchThread()) {
            return;
        }
        thread_.join();
    }
}

bool EventDispatcher::isDispatchThread() const noexcept {
    return thread_.joinable() && thread_.get_id() == std::this_thread::get_id();
}

std::uint64_t EventDispatcher::dispatchedEvents() const {
    return dispatchedEvents_.load(std::memory_order_relaxed);
}

std::uint64_t EventDispatcher::droppedEvents() const {
    return droppedEvents_.load(std::memory_order_relaxed);
}

std::uint64_t EventDispatcher::listenerFailures() const {
    return listenerFailures_.load(std::memory_order_relaxed);
}

void EventDispatcher::dispatchLoop() {
    while (true) {
        RuntimeEvent event;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this]() { return stopping_ || !queue_.empty(); });
            if (stopping_ && queue_.empty()) {
                break;
            }
            event = std::move(queue_.front());
            queue_.pop_front();
        }

        EventListenerRegistry::Lease lease = listenerProvider_ ? listenerProvider_() : EventListenerRegistry::Lease{};
        if (lease) {
            try {
                dispatchToListener(*lease.get(), event);
            } catch (const std::exception&) {
                listenerFailures_.fetch_add(1, std::memory_order_relaxed);
            } catch (...) {
                listenerFailures_.fetch_add(1, std::memory_order_relaxed);
            }
        }
        dispatchedEvents_.fetch_add(1, std::memory_order_relaxed);
    }
}

void EventDispatcher::dispatchToListener(IGuardVisionEventListener& listener, const RuntimeEvent& event) {
    switch (event.type) {
        case RuntimeEventType::StreamStatus:
            listener.onStreamStatus(event.status);
            break;
        case RuntimeEventType::FrameProcessed:
            listener.onFrameProcessed(event.frameProcessed);
            break;
        case RuntimeEventType::Motion:
            listener.onMotion(event.motion);
            break;
        case RuntimeEventType::Face:
            listener.onFace(event.face);
            break;
        case RuntimeEventType::Hazard:
            listener.onHazard(event.hazard);
            break;
        case RuntimeEventType::Alarm:
            listener.onAlarm(event.alarm);
            break;
        case RuntimeEventType::Error:
            listener.onError(event.error);
            break;
    }
}

bool EventDispatcher::pushEventLocked(RuntimeEvent event) {
    if (queue_.size() < capacity_) {
        queue_.push_back(std::move(event));
        return true;
    }

    if (isDroppableUpdate(event)) {
        return false;
    }

    evictOldestFrameProcessedLocked();
    if (queue_.size() < capacity_) {
        queue_.push_back(std::move(event));
        return true;
    }

    return false;
}

void EventDispatcher::evictOldestFrameProcessedLocked() {
    for (auto it = queue_.begin(); it != queue_.end(); ++it) {
        if (isDroppableUpdate(*it)) {
            queue_.erase(it);
            droppedEvents_.fetch_add(1, std::memory_order_relaxed);
            return;
        }
    }
}

}  // namespace guardvision
