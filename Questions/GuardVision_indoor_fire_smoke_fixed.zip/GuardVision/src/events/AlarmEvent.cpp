#include <events/AlarmEvent.h>

namespace guardvision {

const char* toString(AlarmType type) noexcept {
    switch (type) {
        case AlarmType::Motion:
            return "Motion";
        case AlarmType::Face:
            return "Face";
        case AlarmType::Fire:
            return "Fire";
        case AlarmType::Smoke:
            return "Smoke";
    }
    return "Unknown";
}

const char* toString(AlarmState state) noexcept {
    switch (state) {
        case AlarmState::Started:
            return "Started";
        case AlarmState::Updated:
            return "Updated";
        case AlarmState::Ended:
            return "Ended";
    }
    return "Unknown";
}

const char* toString(AlarmSource source) noexcept {
    switch (source) {
        case AlarmSource::Software:
            return "Software";
        case AlarmSource::Onboard:
            return "Onboard";
        case AlarmSource::Hybrid:
            return "Hybrid";
    }
    return "Unknown";
}

}  // namespace guardvision
