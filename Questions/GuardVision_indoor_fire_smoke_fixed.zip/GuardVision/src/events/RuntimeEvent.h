#pragma once

#include <events/AlarmEvent.h>
#include <core/Error.h>
#include <face/FaceEvent.h>
#include <events/FrameProcessedEvent.h>
#include <hazard/HazardEvent.h>
#include <motion/MotionEvent.h>
#include <core/StreamStatus.h>

namespace guardvision {

enum class RuntimeEventType { StreamStatus, FrameProcessed, Motion, Face, Hazard, Alarm, Error };

struct RuntimeEvent {
    RuntimeEventType type = RuntimeEventType::Error;
    StreamStatus status;
    FrameProcessedEvent frameProcessed;
    MotionEvent motion;
    FaceEvent face;
    HazardEvent hazard;
    AlarmEvent alarm;
    GuardVisionError error;
};

}  // namespace guardvision
