#pragma once

#include <cstdint>
#include <vector>

#include <core/Error.h>
#include <hazard/HazardConfig.h>
#include <hazard/HazardEvent.h>
#include <frame/VideoFrame.h>

#include "core/StreamToken.h"
#include "hazard/HazardFrameConverter.h"
#include "hazard/HazardStateRegistry.h"
#include "metrics/HazardMetricsState.h"

namespace guardvision {

struct HazardProcessingScratch {
    HazardImageConversion conversion;
    HazardFrameConversionScratch frameConversion;
};

struct HazardProcessResult {
    bool skippedByInterval = false;
    bool hadError = false;
    GuardVisionError error;
    std::int64_t processingTimeUs = 0;
    std::vector<HazardEvent> events;
};

class HazardProcessor {
public:
    HazardProcessResult processFrame(const VideoFrame& frame, const StreamToken& token, const HazardConfig& config, HazardStateRegistry& state,
                                     HazardMetricsState& metrics, std::int64_t& lastAnalyzedTimestampMs, HazardProcessingScratch& scratch);

    std::vector<HazardEvent> endActiveStates(const StreamToken& token, const HazardConfig& config, HazardStateRegistry& state,
                                             HazardMetricsState& metrics, std::uint64_t sequence, std::int64_t timestampMs);
};

}  // namespace guardvision
