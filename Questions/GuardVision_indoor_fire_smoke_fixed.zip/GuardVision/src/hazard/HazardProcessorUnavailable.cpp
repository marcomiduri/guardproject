#include "hazard/HazardProcessor.h"

namespace guardvision {

HazardProcessResult HazardProcessor::processFrame(const VideoFrame&, const StreamToken& token, const HazardConfig&, HazardStateRegistry&,
                                                  HazardMetricsState& metrics, std::int64_t&, HazardProcessingScratch&) {
    metrics.processingErrors.fetch_add(1, std::memory_order_relaxed);

    HazardProcessResult result;
    result.hadError = true;
    result.error = GuardVisionError{GuardVisionErrorCode::HazardEngineInitializationFailed, token.streamId, "HazardProcessor",
                                    "GuardVision was built without hazard support.",        false,          0};
    return result;
}

std::vector<HazardEvent> HazardProcessor::endActiveStates(const StreamToken&, const HazardConfig&, HazardStateRegistry&, HazardMetricsState&,
                                                          std::uint64_t, std::int64_t) {
    return {};
}

}  // namespace guardvision
