#include "hazard/HazardProcessor.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <mutex>
#include <utility>
#include <vector>

#ifdef GUARDVISION_HAVE_HAZARD
#include <hazard_detect.h>
#endif

#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"
#include "hazard/HazardFrameConverter.h"

#include "detail/AtomicUtil.h"
namespace guardvision {
namespace {

GuardVisionError makeVendorError(GuardVisionErrorCode code, const char* component, const char* message, int vendorCode, const std::string& streamId) {
    GuardVisionError error;
    error.code = code;
    error.component = component;
    error.message = message;
    error.streamId = streamId;
    error.recoverable = true;
    error.vendorErrorCode = vendorCode;
    return error;
}

bool normalizedBoxIsValid(const float x, const float y, const float width, const float height, const float confidence) {
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(width) || !std::isfinite(height) || !std::isfinite(confidence)) {
        return false;
    }
    if (width <= 0.f || height <= 0.f) {
        return false;
    }
    const float right = x + width;
    const float bottom = y + height;
    return right > 0.f && bottom > 0.f && x < 1.f && y < 1.f;
}

double minimumConfidenceFor(HazardType hazardType, const HazardConfig& config) noexcept {
    const double perType = hazardType == HazardType::Smoke ? config.smokeMinimumConfidence : config.fireMinimumConfidence;
    return perType >= 0.0 ? perType : config.minimumConfidence;
}

Rect normalizedDetectionToFullFrame(const float x, const float y, const float width, const float height, const HazardImageConversion& conversion,
                                    const Rect& detectionArea) {
    // HazardDetect coordinates are normalized to the actual inference image/tile.
    // conversion.roiFullFrame is still in source-frame pixels even when the
    // inference image was downscaled. Map through that source ROI so small
    // detections do not become artificially smaller after downscaling.
    const double scaleX = static_cast<double>(conversion.roiFullFrame.width) / static_cast<double>(conversion.width);
    const double scaleY = static_cast<double>(conversion.roiFullFrame.height) / static_cast<double>(conversion.height);
    const double localX = static_cast<double>(detectionArea.x) + static_cast<double>(x) * detectionArea.width;
    const double localY = static_cast<double>(detectionArea.y) + static_cast<double>(y) * detectionArea.height;
    const double localW = static_cast<double>(width) * detectionArea.width;
    const double localH = static_cast<double>(height) * detectionArea.height;

    const int px = conversion.roiFullFrame.x + static_cast<int>(std::lround(localX * scaleX));
    const int py = conversion.roiFullFrame.y + static_cast<int>(std::lround(localY * scaleY));
    const int pw = std::max(1, static_cast<int>(std::lround(localW * scaleX)));
    const int ph = std::max(1, static_cast<int>(std::lround(localH * scaleY)));

    // Clamp to the configured source ROI itself, not to the downscaled inference
    // dimensions. This is important when the camera uses a non-zero ROI origin.
    const int left = std::max(conversion.roiFullFrame.x, px);
    const int top = std::max(conversion.roiFullFrame.y, py);
    const int right = std::min(conversion.roiFullFrame.x + conversion.roiFullFrame.width, px + pw);
    const int bottom = std::min(conversion.roiFullFrame.y + conversion.roiFullFrame.height, py + ph);
    return Rect{left, top, std::max(0, right - left), std::max(0, bottom - top)};
}

double intersectionOverUnion(const Rect& a, const Rect& b) noexcept {
    const int left = std::max(a.x, b.x);
    const int top = std::max(a.y, b.y);
    const int right = std::min(a.x + a.width, b.x + b.width);
    const int bottom = std::min(a.y + a.height, b.y + b.height);
    const int intersectionWidth = std::max(0, right - left);
    const int intersectionHeight = std::max(0, bottom - top);
    const double intersection = static_cast<double>(intersectionWidth) * intersectionHeight;
    if (intersection <= 0.0) {
        return 0.0;
    }
    const double unionArea = static_cast<double>(a.width) * a.height + static_cast<double>(b.width) * b.height - intersection;
    return unionArea > 0.0 ? intersection / unionArea : 0.0;
}

void appendDistinctRegion(std::vector<HazardRegion>& regions, HazardRegion region, int maximumRegionCount) {
    for (HazardRegion& existing : regions) {
        if (intersectionOverUnion(existing.bounds, region.bounds) >= 0.45) {
            if (region.confidence > existing.confidence) {
                existing = std::move(region);
            }
            return;
        }
    }
    if (static_cast<int>(regions.size()) < maximumRegionCount) {
        regions.push_back(std::move(region));
    }
}

std::vector<Rect> makeSmallHazardTiles(int width, int height) {
    std::vector<Rect> tiles;
    if (width < 96 || height < 96) {
        return tiles;
    }

    // 2x2 with ~12.5% overlap on each internal seam. The model sees an early
    // plume/flame at roughly twice its full-frame scale without exploding the
    // number of inference passes.
    const int overlapX = std::max(8, width / 8);
    const int overlapY = std::max(8, height / 8);
    const int midX = width / 2;
    const int midY = height / 2;
    const int leftWidth = std::min(width, midX + overlapX);
    const int rightX = std::max(0, midX - overlapX);
    const int topHeight = std::min(height, midY + overlapY);
    const int bottomY = std::max(0, midY - overlapY);

    tiles.push_back(Rect{0, 0, leftWidth, topHeight});
    tiles.push_back(Rect{rightX, 0, width - rightX, topHeight});
    tiles.push_back(Rect{0, bottomY, leftWidth, height - bottomY});
    tiles.push_back(Rect{rightX, bottomY, width - rightX, height - bottomY});
    return tiles;
}

bool mapVendorType(int vendorType, HazardType& out) {
    switch (vendorType) {
        case HAZARD_TYPE_FIRE:
        case HAZARD_TYPE_FLAME:
            out = HazardType::Fire;
            return true;
        case HAZARD_TYPE_SMOKE:
            out = HazardType::Smoke;
            return true;
        default:
            return false;
    }
}

constexpr int kMaxHazardDetectDimension = 1280;
constexpr int kMinHazardDetectDimension = 8;

bool hazardDetectionDimensionsAreSafe(int width, int height) {
    if (width < kMinHazardDetectDimension || height < kMinHazardDetectDimension) {
        return false;
    }
    const std::int64_t pixels = static_cast<std::int64_t>(width) * static_cast<std::int64_t>(height);
    return pixels > 0 && pixels <= static_cast<std::int64_t>(3840) * 2160;
}

void downscaleConversionForDetection(HazardImageConversion& conversion) {
    if (!hazardDetectionDimensionsAreSafe(conversion.width, conversion.height)) {
        conversion.pixels.clear();
        conversion.width = 0;
        conversion.height = 0;
        conversion.stride = 0;
        return;
    }

    const int maxSide = std::max(conversion.width, conversion.height);
    if (maxSide <= kMaxHazardDetectDimension) {
        return;
    }

    const int newWidth = std::max(
      kMinHazardDetectDimension, static_cast<int>(std::lround(static_cast<double>(conversion.width) * static_cast<double>(kMaxHazardDetectDimension) /
                                                              static_cast<double>(maxSide))));
    const int newHeight = std::max(kMinHazardDetectDimension,
                                   static_cast<int>(std::lround(static_cast<double>(conversion.height) *
                                                                static_cast<double>(kMaxHazardDetectDimension) / static_cast<double>(maxSide))));

    std::vector<std::uint8_t> scaled(static_cast<std::size_t>(newWidth) * static_cast<std::size_t>(newHeight) * 3);
    for (int y = 0; y < newHeight; ++y) {
        const int srcY = (y * conversion.height) / newHeight;
        for (int x = 0; x < newWidth; ++x) {
            const int srcX = (x * conversion.width) / newWidth;
            const std::size_t srcOffset = static_cast<std::size_t>((srcY * conversion.width + srcX) * 3);
            const std::size_t dstOffset = static_cast<std::size_t>((y * newWidth + x) * 3);
            scaled[dstOffset] = conversion.pixels[srcOffset];
            scaled[dstOffset + 1] = conversion.pixels[srcOffset + 1];
            scaled[dstOffset + 2] = conversion.pixels[srcOffset + 2];
        }
    }

    conversion.pixels = std::move(scaled);
    conversion.width = newWidth;
    conversion.height = newHeight;
    conversion.stride = newWidth * 3;
}

}  // namespace

HazardProcessResult HazardProcessor::processFrame(const VideoFrame& frame, const StreamToken& token, const HazardConfig& config,
                                                  HazardStateRegistry& state, HazardMetricsState& metrics, std::int64_t& lastAnalyzedTimestampMs,
                                                  HazardProcessingScratch& scratch) {
    HazardProcessResult result;
    const auto start = std::chrono::steady_clock::now();

    if (lastAnalyzedTimestampMs >= 0 && config.analysisIntervalMs > 0 && frame.timestampMs - lastAnalyzedTimestampMs < config.analysisIntervalMs) {
        result.skippedByInterval = true;
        metrics.skippedByInterval.fetch_add(1);
        return result;
    }

#ifndef GUARDVISION_HAVE_HAZARD
    result.hadError = true;
    result.error = makeVendorError(GuardVisionErrorCode::HazardEngineInitializationFailed, "HazardProcessor", "Hazard support is not available.", -1,
                                   token.streamId);
    metrics.processingErrors.fetch_add(1);
    return result;
#else
    if (!HazardEngine::instance().isInitialized()) {
        result.hadError = true;
        result.error =
          makeVendorError(GuardVisionErrorCode::HazardModelMissing, "HazardProcessor", "HazardDetect engine is not initialized.", -1, token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    HazardImageConversion& conversion = scratch.conversion;
    if (!convertFrameForHazardDetect(frame, config, conversion, scratch.frameConversion)) {
        result.hadError = true;
        result.error = conversion.error;
        result.error.streamId = token.streamId;
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    downscaleConversionForDetection(conversion);
    if (conversion.width <= 0 || conversion.height <= 0 || conversion.pixels.empty()) {
        result.hadError = true;
        result.error = makeVendorError(GuardVisionErrorCode::InvalidFrame, "HazardProcessor", "Hazard conversion produced an unsafe frame size.", -1,
                                       token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    std::vector<HazardRegion> fireRegions;
    std::vector<HazardRegion> smokeRegions;
    fireRegions.reserve(static_cast<std::size_t>(config.maximumRegionCount));
    smokeRegions.reserve(static_cast<std::size_t>(config.maximumRegionCount));

    auto consumeDetections = [&](const HazardDetection* detections, int detectionCount, const Rect& detectionArea, bool acceptFire, bool acceptSmoke) {
        for (int index = 0; index < detectionCount; ++index) {
            const HazardDetection& detection = detections[index];
            if (!normalizedBoxIsValid(detection.x, detection.y, detection.width, detection.height, detection.confidence)) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }

            HazardType hazardType = HazardType::Fire;
            if (!mapVendorType(static_cast<int>(detection.type), hazardType)) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }
            if (hazardType == HazardType::Fire) {
                metrics.fireDetections.fetch_add(1);
                if (!config.fireEnabled || !acceptFire) {
                    metrics.filteredRegions.fetch_add(1);
                    continue;
                }
            } else {
                metrics.smokeDetections.fetch_add(1);
                if (!config.smokeEnabled || !acceptSmoke) {
                    metrics.filteredRegions.fetch_add(1);
                    continue;
                }
            }

            if (static_cast<double>(detection.confidence) < minimumConfidenceFor(hazardType, config)) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }

            HazardRegion region;
            region.type = hazardType;
            region.confidence = static_cast<double>(detection.confidence);
            region.bounds = normalizedDetectionToFullFrame(detection.x, detection.y, detection.width, detection.height, conversion, detectionArea);
            if (region.bounds.width < config.minimumRegionWidth || region.bounds.height < config.minimumRegionHeight) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }

            if (hazardType == HazardType::Fire) {
                appendDistinctRegion(fireRegions, std::move(region), config.maximumRegionCount);
            } else {
                appendDistinctRegion(smokeRegions, std::move(region), config.maximumRegionCount);
            }
        }
    };

    HazardDetection detections[HAZARD_DETECT_MAX_OUTPUT];
    int detectionCount = 0;
    {
        // Identify and HazardDetect are not safe concurrently in-process. Use the
        // same recursive vendor lock that guards HF* session and registry calls.
        std::lock_guard<std::recursive_mutex> vendorLock(IdentifyEngine::instance().apiMutex());
        detectionCount = HazardDetect_DetectBgr(conversion.pixels.data(), conversion.width, conversion.height, conversion.stride, detections,
                                                HAZARD_DETECT_MAX_OUTPUT);
        if (detectionCount >= 0) {
            consumeDetections(detections, detectionCount, Rect{0, 0, conversion.width, conversion.height}, true, true);
        }

        const bool needSmallSmokePass = config.smallHazardTilingEnabled && config.smokeEnabled && smokeRegions.empty();
        const bool needSmallFirePass = config.smallHazardTilingEnabled && config.fireEnabled && fireRegions.empty();
        if (detectionCount >= 0 && (needSmallSmokePass || needSmallFirePass)) {
            const std::vector<Rect> tiles = makeSmallHazardTiles(conversion.width, conversion.height);
            for (const Rect& tile : tiles) {
                HazardDetection tileDetections[HAZARD_DETECT_MAX_OUTPUT];
                const std::uint8_t* tileStart = conversion.pixels.data() +
                                                static_cast<std::size_t>(tile.y * conversion.stride + tile.x * 3);
                const int tileCount = HazardDetect_DetectBgr(tileStart, tile.width, tile.height, conversion.stride, tileDetections,
                                                             HAZARD_DETECT_MAX_OUTPUT);
                // The full-frame result is still useful if an optional tile pass
                // fails, so do not turn a tile-only failure into a lost frame.
                if (tileCount < 0) {
                    continue;
                }
                consumeDetections(tileDetections, tileCount, tile, needSmallFirePass, needSmallSmokePass);
            }
        }
    }
    if (detectionCount < 0) {
        const char* lastError = HazardDetect_LastError();
        result.hadError = true;
        result.error = makeVendorError(GuardVisionErrorCode::HazardProcessingFailed, "HazardProcessor",
                                       lastError != nullptr ? lastError : "HazardDetect_DetectBgr failed.", -1, token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    result.events = state.update(fireRegions, smokeRegions, config, token.streamId, token.generation, frame.sequence, frame.timestampMs, &metrics);

    lastAnalyzedTimestampMs = frame.timestampMs;
    metrics.analyzedFrames.fetch_add(1);

    const auto end = std::chrono::steady_clock::now();
    result.processingTimeUs = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
    metrics.lastProcessingTimeUs = result.processingTimeUs;
    detail::updateAtomicMaximum(metrics.maximumProcessingTimeUs, result.processingTimeUs);
    return result;
#endif
}

std::vector<HazardEvent> HazardProcessor::endActiveStates(const StreamToken& token, const HazardConfig& config, HazardStateRegistry& state,
                                                          HazardMetricsState& metrics, std::uint64_t sequence, std::int64_t timestampMs) {
    (void)config;
    return state.endActiveStates(token.streamId, token.generation, sequence, timestampMs, &metrics);
}

}  // namespace guardvision
