#include <hazard/HazardConfig.h>

namespace guardvision {
namespace {

constexpr int kMaxIntervalMs = 3600000;
constexpr int kMaxRegionCount = 64;
constexpr int kMaxRegionDimension = 4096;

bool isUnitRatio(double value) noexcept {
    return value >= 0.0 && value <= 1.0;
}

}  // namespace

bool isValidHazardConfig(const HazardConfig& config) noexcept {
    if (config.analysisIntervalMs < 0 || config.analysisIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (!isUnitRatio(config.minimumConfidence)) {
        return false;
    }
    if (config.fireMinimumConfidence >= 0.0 && !isUnitRatio(config.fireMinimumConfidence)) {
        return false;
    }
    if (config.smokeMinimumConfidence >= 0.0 && !isUnitRatio(config.smokeMinimumConfidence)) {
        return false;
    }
    if (config.minimumRegionWidth < 1 || config.minimumRegionWidth > kMaxRegionDimension) {
        return false;
    }
    if (config.minimumRegionHeight < 1 || config.minimumRegionHeight > kMaxRegionDimension) {
        return false;
    }
    if (config.maximumRegionCount < 1 || config.maximumRegionCount > kMaxRegionCount) {
        return false;
    }
    if (config.activationFrameCount < 1 || config.activationFrameCount > 1000) {
        return false;
    }
    if (config.fireActivationFrameCount < 0 || config.fireActivationFrameCount > 1000) {
        return false;
    }
    if (config.smokeActivationFrameCount < 0 || config.smokeActivationFrameCount > 1000) {
        return false;
    }
    if (config.clearFrameCount < 1 || config.clearFrameCount > 1000) {
        return false;
    }
    if (config.updateEventIntervalMs < 0 || config.updateEventIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.useRoi && !config.roi.isValid()) {
        return false;
    }
    if (config.processingLevel == HazardProcessingLevel::Disabled) {
        return true;
    }
    if (!config.fireEnabled && !config.smokeEnabled) {
        return false;
    }
    return true;
}

}  // namespace guardvision
