#include "hazard/HazardStateRegistry.h"

namespace guardvision {
namespace {

int activationFramesFor(HazardType hazardType, const HazardConfig& config) noexcept {
    const int perType = hazardType == HazardType::Smoke ? config.smokeActivationFrameCount : config.fireActivationFrameCount;
    return perType > 0 ? perType : config.activationFrameCount;
}

}  // namespace


void HazardStateRegistry::reset() {
    fire_ = TypeState{};
    smoke_ = TypeState{};
}

bool HazardStateRegistry::isFireActive() const noexcept {
    return fire_.state == AlarmState::Active || fire_.state == AlarmState::Clearing;
}

bool HazardStateRegistry::isSmokeActive() const noexcept {
    return smoke_.state == AlarmState::Active || smoke_.state == AlarmState::Clearing;
}

HazardEvent HazardStateRegistry::makeEvent(HazardEventType type, HazardType hazardType, const std::string& streamId, std::uint64_t generation,
                                           std::uint64_t sequence, std::int64_t timestampMs, const std::vector<HazardRegion>& regions) const {
    HazardEvent event;
    event.type = type;
    event.streamId = streamId;
    event.generation = generation;
    event.sequence = sequence;
    event.timestampMs = timestampMs;
    event.regions = regions;
    if (event.regions.empty() && type != HazardEventType::Ended) {
        HazardRegion placeholder;
        placeholder.type = hazardType;
        event.regions.push_back(placeholder);
    } else if (!event.regions.empty()) {
        for (HazardRegion& region : event.regions) {
            region.type = hazardType;
        }
    }
    return event;
}

std::vector<HazardEvent> HazardStateRegistry::updateType(HazardType hazardType, const std::vector<HazardRegion>& regions, const HazardConfig& config,
                                                         const std::string& streamId, std::uint64_t generation, std::uint64_t sequence,
                                                         std::int64_t timestampMs, TypeState& state, HazardMetricsState* metrics) {
    std::vector<HazardEvent> events;
    const bool detected = !regions.empty();
    const int activationFrames = activationFramesFor(hazardType, config);

    switch (state.state) {
        case AlarmState::Idle:
            if (detected) {
                if (activationFrames <= 1) {
                    state.state = AlarmState::Active;
                    state.consecutiveDetectionFrames = 0;
                    state.consecutiveClearFrames = 0;
                    state.lastRegions = regions;
                    events.push_back(makeEvent(HazardEventType::Started, hazardType, streamId, generation, sequence, timestampMs, regions));
                    state.lastEventTimestampMs = timestampMs;
                    if (metrics != nullptr) {
                        metrics->startedEvents.fetch_add(1);
                    }
                } else {
                    state.state = AlarmState::Candidate;
                    state.consecutiveDetectionFrames = 1;
                    state.consecutiveClearFrames = 0;
                }
            }
            break;

        case AlarmState::Candidate:
            if (detected) {
                ++state.consecutiveDetectionFrames;
                if (state.consecutiveDetectionFrames >= activationFrames) {
                    state.state = AlarmState::Active;
                    state.consecutiveClearFrames = 0;
                    state.lastRegions = regions;
                    events.push_back(makeEvent(HazardEventType::Started, hazardType, streamId, generation, sequence, timestampMs, regions));
                    state.lastEventTimestampMs = timestampMs;
                    if (metrics != nullptr) {
                        metrics->startedEvents.fetch_add(1);
                    }
                }
            } else {
                state.state = AlarmState::Idle;
                state.consecutiveDetectionFrames = 0;
            }
            break;

        case AlarmState::Active:
            if (detected) {
                state.consecutiveClearFrames = 0;
                state.lastRegions = regions;
                if (config.updateEventIntervalMs <= 0 || timestampMs - state.lastEventTimestampMs >= config.updateEventIntervalMs) {
                    events.push_back(makeEvent(HazardEventType::Updated, hazardType, streamId, generation, sequence, timestampMs, regions));
                    state.lastEventTimestampMs = timestampMs;
                    if (metrics != nullptr) {
                        metrics->updatedEvents.fetch_add(1);
                    }
                }
            } else {
                state.state = AlarmState::Clearing;
                state.consecutiveClearFrames = 1;
            }
            break;

        case AlarmState::Clearing:
            if (detected) {
                state.state = AlarmState::Active;
                state.consecutiveClearFrames = 0;
                state.lastRegions = regions;
                if (config.updateEventIntervalMs <= 0 || timestampMs - state.lastEventTimestampMs >= config.updateEventIntervalMs) {
                    events.push_back(makeEvent(HazardEventType::Updated, hazardType, streamId, generation, sequence, timestampMs, regions));
                    state.lastEventTimestampMs = timestampMs;
                    if (metrics != nullptr) {
                        metrics->updatedEvents.fetch_add(1);
                    }
                }
            } else {
                ++state.consecutiveClearFrames;
                if (state.consecutiveClearFrames >= config.clearFrameCount) {
                    state.state = AlarmState::Idle;
                    state.consecutiveDetectionFrames = 0;
                    state.consecutiveClearFrames = 0;
                    events.push_back(makeEvent(HazardEventType::Ended, hazardType, streamId, generation, sequence, timestampMs, {}));
                    state.lastRegions.clear();
                    state.lastEventTimestampMs = timestampMs;
                    if (metrics != nullptr) {
                        metrics->endedEvents.fetch_add(1);
                    }
                }
            }
            break;
    }

    return events;
}

std::vector<HazardEvent> HazardStateRegistry::update(const std::vector<HazardRegion>& fireRegions, const std::vector<HazardRegion>& smokeRegions,
                                                     const HazardConfig& config, const std::string& streamId, std::uint64_t generation,
                                                     std::uint64_t sequence, std::int64_t timestampMs, HazardMetricsState* metrics) {
    std::vector<HazardEvent> events;
    // Smoke is intentionally evaluated first. In indoor incidents visible smoke
    // frequently precedes sustained flame and is the preferred early-warning event.
    if (config.smokeEnabled) {
        auto smokeEvents = updateType(HazardType::Smoke, smokeRegions, config, streamId, generation, sequence, timestampMs, smoke_, metrics);
        events.insert(events.end(), smokeEvents.begin(), smokeEvents.end());
    }
    if (config.fireEnabled) {
        auto fireEvents = updateType(HazardType::Fire, fireRegions, config, streamId, generation, sequence, timestampMs, fire_, metrics);
        events.insert(events.end(), fireEvents.begin(), fireEvents.end());
    }
    if (metrics != nullptr) {
        metrics->activeFireState = isFireActive();
        metrics->activeSmokeState = isSmokeActive();
    }
    return events;
}

std::vector<HazardEvent> HazardStateRegistry::endActiveStates(const std::string& streamId, std::uint64_t generation, std::uint64_t sequence,
                                                              std::int64_t timestampMs, HazardMetricsState* metrics) {
    std::vector<HazardEvent> events;
    if (isFireActive()) {
        fire_ = TypeState{};
        events.push_back(makeEvent(HazardEventType::Ended, HazardType::Fire, streamId, generation, sequence, timestampMs, {}));
        if (metrics != nullptr) {
            metrics->endedEvents.fetch_add(1);
        }
    }
    if (isSmokeActive()) {
        smoke_ = TypeState{};
        events.push_back(makeEvent(HazardEventType::Ended, HazardType::Smoke, streamId, generation, sequence, timestampMs, {}));
        if (metrics != nullptr) {
            metrics->endedEvents.fetch_add(1);
        }
    }
    if (metrics != nullptr) {
        metrics->activeFireState = false;
        metrics->activeSmokeState = false;
    }
    return events;
}

}  // namespace guardvision
