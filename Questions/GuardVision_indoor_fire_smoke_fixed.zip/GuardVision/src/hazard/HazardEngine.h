#pragma once

#include <atomic>
#include <mutex>
#include <string>

#include <core/Result.h>

namespace guardvision {

class HazardEngine {
public:
    static HazardEngine& instance();

    Result initialize(const std::string& modelPathOverride, float confidenceThreshold);
    void shutdown();
    bool isInitialized() const noexcept;
    std::string modelPath() const;
    std::mutex& detectionMutex() noexcept {
        return detectionMutex_;
    }

private:
    HazardEngine() = default;

    mutable std::mutex mutex_;
    std::mutex detectionMutex_;
    std::atomic<bool> initialized_{false};
    std::string modelPath_;
    float confidenceThreshold_ = 0.0f;
};

std::string discoverHazardModelPath(const std::string& overridePath);

}  // namespace guardvision
