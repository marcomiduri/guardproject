#pragma once

#include <cstdint>
#include <vector>

#include <core/Error.h>
#include <geometry/Geometry.h>
#include <hazard/HazardConfig.h>
#include <frame/VideoFrame.h>

namespace guardvision {

struct HazardFrameConversionScratch {
    std::vector<std::uint8_t> fullFrameBgr;
};

struct HazardImageConversion {
    bool ok = false;
    GuardVisionError error;
    Rect roiFullFrame;
    std::vector<std::uint8_t> pixels;
    int width = 0;
    int height = 0;
    int stride = 0;
};

bool convertFrameForHazardDetect(const VideoFrame& frame, const HazardConfig& config, HazardImageConversion& output,
                                 HazardFrameConversionScratch& scratch);

inline bool convertFrameForHazardDetect(const VideoFrame& frame, const HazardConfig& config, HazardImageConversion& output) {
    HazardFrameConversionScratch scratch;
    return convertFrameForHazardDetect(frame, config, output, scratch);
}

}  // namespace guardvision
