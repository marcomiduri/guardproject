#include "hazard/HazardScheduler.h"

#include "scheduling/SchedulerConstants.h"

#include <algorithm>
#include <utility>

#include <events/AlarmEvent.h>

namespace guardvision {

HazardScheduler::HazardScheduler(EventCallback eventCallback, ErrorCallback errorCallback)
: eventCallback_(std::move(eventCallback)), errorCallback_(std::move(errorCallback)) {}

HazardScheduler::~HazardScheduler() {
    stop();
    join();
}

void HazardScheduler::start(int workerCount) {
    if (workersRunning_.exchange(true)) {
        return;
    }
    stopping_ = false;
    workerCount_ = std::max(1, workerCount);
    workers_.clear();
    workers_.reserve(static_cast<std::size_t>(workerCount_));
    workerThreads_.clear();
    for (int index = 0; index < workerCount_; ++index) {
        workers_.push_back(std::make_unique<WorkerState>());
        workerThreads_.emplace_back([this, index]() { workerLoop(index); });
    }
}

void HazardScheduler::stop() {
    stopping_ = true;
    for (const auto& worker : workers_) {
        worker->cv.notify_all();
    }
}

void HazardScheduler::join() {
    for (std::thread& thread : workerThreads_) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    workerThreads_.clear();
    for (const auto& worker : workers_) {
        std::lock_guard<std::mutex> lock(worker->mutex);
        worker->slots.clear();
        worker->readyStreams.clear();
    }
    workers_.clear();
    workerCount_ = 0;
    workersRunning_ = false;
    stopping_ = false;
    std::lock_guard<std::mutex> affinityLock(affinityMutex_);
    streamWorkerAffinity_.clear();
}

int HazardScheduler::registerStream(const StreamToken& token, const HazardConfig& config, std::shared_ptr<HazardMetricsState> metrics) {
    if (!metrics || workerCount_ <= 0) {
        return -1;
    }
    int workerIndex = 0;
    std::size_t minimumLoad = static_cast<std::size_t>(-1);
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        for (int index = 0; index < workerCount_; ++index) {
            WorkerState& candidate = *workers_[static_cast<std::size_t>(index)];
            std::lock_guard<std::mutex> workerLock(candidate.mutex);
            const std::size_t load = candidate.slots.size() + candidate.readyStreams.size();
            if (load < minimumLoad) {
                minimumLoad = load;
                workerIndex = index;
            }
        }
        streamWorkerAffinity_[token.streamId] = workerIndex;
    }

    auto slot = std::make_shared<WorkerStreamSlot>();
    slot->token = token;
    slot->config = config;
    slot->active = config.processingLevel == HazardProcessingLevel::Detect;
    slot->state.reset();
    slot->lastAnalyzedTimestampMs = -1;
    slot->metrics = std::move(metrics);

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    {
        std::lock_guard<std::mutex> lock(worker.mutex);
        worker.slots[token.streamId] = slot;
    }

    slot->metrics->assignedWorkerIndex = workerIndex;
    slot->metrics->enabled = slot->active;
    slot->metrics->processingLevel = config.processingLevel;
    return workerIndex;
}

void HazardScheduler::unregisterStream(const StreamToken& token) {
    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(token.streamId);
        if (it != streamWorkerAffinity_.end()) {
            workerIndex = it->second;
            streamWorkerAffinity_.erase(it);
        }
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        return;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    std::shared_ptr<WorkerStreamSlot> slot;
    {
        std::unique_lock<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(token.streamId);
        if (it == worker.slots.end() || !it->second || it->second->token.generation != token.generation) {
            return;
        }
        slot = it->second;
        slot->active = false;
        slot->pending.clear();
        slot->pendingConfirmations.clear();
        worker.readyStreams.remove(token);
        if (slot->inFlight && !slot->processing) {
            slot->inFlight = false;
        }
        worker.cv.wait(lock, [&]() { return !slot->processing; });
        const auto current = worker.slots.find(token.streamId);
        if (current != worker.slots.end() && current->second == slot) {
            worker.slots.erase(current);
        }
    }

    slot->state.reset();
    if (slot->metrics) {
        slot->metrics->enabled = false;
        slot->metrics->activeFireState = false;
        slot->metrics->activeSmokeState = false;
        slot->metrics->assignedWorkerIndex = -1;
    }
}

void HazardScheduler::updateStreamConfig(const StreamToken& token, const HazardConfig& config) {
    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(token.streamId);
        if (it == streamWorkerAffinity_.end()) {
            return;
        }
        workerIndex = it->second;
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        return;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    std::shared_ptr<WorkerStreamSlot> slot;
    std::vector<HazardEvent> endedEvents;
    {
        std::unique_lock<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(token.streamId);
        if (it == worker.slots.end() || !it->second || it->second->token.generation != token.generation) {
            return;
        }
        slot = it->second;
        slot->active = false;
        slot->pending.clear();
        slot->pendingConfirmations.clear();
        worker.readyStreams.remove(token);
        if (slot->inFlight && !slot->processing) {
            slot->inFlight = false;
        }
        worker.cv.wait(lock, [&]() { return !slot->processing; });
        if (slot->metrics && config.processingLevel == HazardProcessingLevel::Disabled) {
            endedEvents = processor_.endActiveStates(token, slot->config, slot->state, *slot->metrics, 0, 0);
        }
        slot->config = config;
        slot->state.reset();
        slot->lastAnalyzedTimestampMs = -1;
        slot->active = config.processingLevel == HazardProcessingLevel::Detect;
    }

    if (slot->metrics) {
        slot->metrics->enabled = slot->active;
        slot->metrics->processingLevel = config.processingLevel;
        slot->metrics->activeFireState = false;
        slot->metrics->activeSmokeState = false;
    }
    if (!endedEvents.empty() && eventCallback_) {
        eventCallback_(std::move(endedEvents));
    }
}

HazardOfferResult HazardScheduler::offerFrame(HazardRoutingJob job) {
    HazardOfferResult result;
    if (job.config.processingLevel == HazardProcessingLevel::Disabled) {
        return result;
    }

    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(job.token.streamId);
        if (it == streamWorkerAffinity_.end()) {
            return result;
        }
        workerIndex = it->second;
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        return result;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    {
        std::lock_guard<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(job.token.streamId);
        if (it == worker.slots.end() || !it->second) {
            return result;
        }
        const std::shared_ptr<WorkerStreamSlot>& slot = it->second;
        if (slot->metrics) {
            slot->metrics->receivedFrames.fetch_add(1);
        }
        if (!slot->active || slot->token.generation != job.token.generation) {
            if (slot->metrics) {
                slot->metrics->staleWorkDiscarded.fetch_add(1);
            }
            return result;
        }
        slot->config = job.config;
        FrameRoutingJob routingJob{job.token, job.frame, job.submittedAtMs};
        const ReplaceResult replaceResult = slot->pending.replace(std::move(routingJob));
        result.replacedPending = replaceResult == ReplaceResult::ReplacedPending;
        result.accepted = true;
        if (result.replacedPending && slot->metrics) {
            slot->metrics->replacedPendingFrames.fetch_add(1);
        }
        if (!slot->inFlight) {
            if (tryScheduleLocked(worker, slot)) {
                if (slot->metrics) {
                    slot->metrics->scheduledFrames.fetch_add(1);
                }
            } else {
                slot->pending.clear();
                result.accepted = false;
                result.queueUnavailable = true;
                if (slot->metrics) {
                    slot->metrics->processingErrors.fetch_add(1);
                }
            }
        }
    }
    worker.cv.notify_one();
    return result;
}

HazardConfirmationOfferResult HazardScheduler::offerRegionalConfirmation(HazardRegionalConfirmationRequest request) {
    HazardConfirmationOfferResult result;
    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(request.token.streamId);
        if (it == streamWorkerAffinity_.end()) {
            result.stale = true;
            return result;
        }
        workerIndex = it->second;
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        result.stale = true;
        return result;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    {
        std::lock_guard<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(request.token.streamId);
        if (it == worker.slots.end() || !it->second || it->second->token.generation != request.token.generation || !it->second->active) {
            result.stale = true;
            if (it != worker.slots.end() && it->second && it->second->metrics) {
                it->second->metrics->staleWorkDiscarded.fetch_add(1);
            }
            return result;
        }
        const std::shared_ptr<WorkerStreamSlot>& slot = it->second;
        if (slot->metrics) {
            slot->metrics->receivedFrames.fetch_add(1);
        }
        if (slot->pendingConfirmations.size() >= scheduling::kMaxPendingRegionalConfirmationsPerStream) {
            result.queueFull = true;
            if (slot->metrics) {
                slot->metrics->processingErrors.fetch_add(1);
            }
            return result;
        }
        slot->pendingConfirmations.push_back(std::move(request));
        bool newlyScheduled = false;
        if (!slot->inFlight) {
            newlyScheduled = tryScheduleLocked(worker, slot);
            if (!newlyScheduled) {
                slot->pendingConfirmations.pop_back();
                result.queueFull = true;
                if (slot->metrics) {
                    slot->metrics->processingErrors.fetch_add(1);
                }
                return result;
            }
        }
        if (newlyScheduled && slot->metrics) {
            slot->metrics->scheduledFrames.fetch_add(1);
        }
        result.accepted = true;
    }
    worker.cv.notify_one();
    return result;
}

void HazardScheduler::setConfirmationCallback(ConfirmationCallback callback) {
    confirmationCallback_ = std::move(callback);
}

void HazardScheduler::setActiveTokenValidator(ActiveTokenValidator validator) {
    activeTokenValidator_ = std::move(validator);
}

bool HazardScheduler::tryScheduleLocked(WorkerState& worker, const std::shared_ptr<WorkerStreamSlot>& slot) {
    if (!slot || slot->inFlight || (!slot->pending.hasPending() && slot->pendingConfirmations.empty())) {
        return false;
    }
    if (!worker.readyStreams.tryEnqueue(slot->token)) {
        return false;
    }
    slot->inFlight = true;
    slot->processing = false;
    return true;
}

std::optional<HazardScheduler::WorkerWorkItem> HazardScheduler::takeWorkForStreamLocked(WorkerState& worker,
                                                                                        const std::shared_ptr<WorkerStreamSlot>& slot) {
    if (!slot) {
        return std::nullopt;
    }
    if (slot->pending.hasPending()) {
        const std::optional<FrameRoutingJob> routingJob = slot->pending.take();
        if (routingJob.has_value()) {
            WorkerWorkItem item;
            item.type = WorkerWorkItem::Type::Frame;
            item.frameJob.token = routingJob->token;
            item.frameJob.frame = std::move(routingJob->frame);
            item.frameJob.submittedAtMs = routingJob->submittedAtMs;
            item.frameJob.config = slot->config;
            return item;
        }
    }
    if (!slot->pendingConfirmations.empty()) {
        WorkerWorkItem item;
        item.type = WorkerWorkItem::Type::Confirmation;
        item.confirmationRequest = std::move(slot->pendingConfirmations.front());
        slot->pendingConfirmations.pop_front();
        return item;
    }
    slot->inFlight = false;
    slot->processing = false;
    worker.readyStreams.remove(slot->token);
    return std::nullopt;
}

void HazardScheduler::processSlot(WorkerStreamSlot& slot, HazardRoutingJob job, HazardMetricsState& metrics) {
    if ((activeTokenValidator_ && !activeTokenValidator_(job.token)) || slot.token.generation != job.token.generation) {
        metrics.staleWorkDiscarded.fetch_add(1);
        return;
    }

    HazardProcessResult processResult =
      processor_.processFrame(job.frame, job.token, job.config, slot.state, metrics, slot.lastAnalyzedTimestampMs, slot.processingScratch);
    if (processResult.hadError && errorCallback_) {
        errorCallback_(processResult.error);
    }
    if (activeTokenValidator_ && !activeTokenValidator_(job.token)) {
        metrics.staleWorkDiscarded.fetch_add(1);
        return;
    }
    if (!processResult.events.empty() && eventCallback_) {
        eventCallback_(std::move(processResult.events));
    }
}

void HazardScheduler::processConfirmation(WorkerStreamSlot& slot, HazardRegionalConfirmationRequest request, HazardMetricsState& metrics) {
    HazardRegionalConfirmationResult result;
    result.token = request.token;
    result.candidateType = request.candidateType;
    result.candidateTimestampMs = request.candidateTimestampMs;
    result.originalCandidateRegion = request.originalCandidateRegion;
    result.mappedCandidateRegion = request.mappedCandidateRegion;
    result.expandedAnalysisRegion = request.expandedAnalysisRegion;
    result.onboardConfidence = request.onboardConfidence;
    result.targetId = request.targetId;
    result.onboardMetrics = std::move(request.onboardMetrics);

    if (slot.token.generation != request.token.generation || (activeTokenValidator_ && !activeTokenValidator_(request.token))) {
        result.stale = true;
        metrics.staleWorkDiscarded.fetch_add(1);
        if (confirmationCallback_) {
            confirmationCallback_(std::move(result));
        }
        return;
    }

    HazardStateRegistry confirmationState;
    std::int64_t lastAnalyzedTimestampMs = -1;
    HazardProcessResult processResult = processor_.processFrame(request.matchedFrame, request.token, request.config, confirmationState, metrics,
                                                                lastAnalyzedTimestampMs, slot.processingScratch);
    if (processResult.hadError) {
        result.hadError = true;
        result.error = processResult.error;
        if (errorCallback_) {
            errorCallback_(processResult.error);
        }
    }
    if (activeTokenValidator_ && !activeTokenValidator_(request.token)) {
        result.stale = true;
        result.confirmed = false;
        metrics.staleWorkDiscarded.fetch_add(1);
        if (confirmationCallback_) {
            confirmationCallback_(std::move(result));
        }
        return;
    }

    const AlarmType requestedType = request.candidateType == CandidateType::Smoke ? AlarmType::Smoke : AlarmType::Fire;
    for (const HazardEvent& event : processResult.events) {
        for (const HazardRegion& region : event.regions) {
            const AlarmType regionType = region.type == HazardType::Smoke ? AlarmType::Smoke : AlarmType::Fire;
            if (region.bounds.isValid() && regionType == requestedType) {
                result.confirmedRegions.push_back(region);
                result.softwareConfidence = std::max(result.softwareConfidence, region.confidence);
            }
        }
    }
    result.confirmed = !result.confirmedRegions.empty();
    if (confirmationCallback_) {
        confirmationCallback_(std::move(result));
    }
}

void HazardScheduler::workerLoop(int workerIndex) {
    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    while (true) {
        StreamToken token;
        std::shared_ptr<WorkerStreamSlot> slot;
        std::optional<WorkerWorkItem> work;
        {
            std::unique_lock<std::mutex> lock(worker.mutex);
            worker.cv.wait(lock, [&]() { return stopping_.load() || !worker.readyStreams.empty(); });
            if (stopping_.load() && worker.readyStreams.empty()) {
                break;
            }
            if (!worker.readyStreams.dequeue(token)) {
                continue;
            }
            const auto it = worker.slots.find(token.streamId);
            if (it == worker.slots.end() || !it->second || it->second->token.generation != token.generation) {
                continue;
            }
            slot = it->second;
            work = takeWorkForStreamLocked(worker, slot);
            if (!work.has_value()) {
                worker.cv.notify_all();
                continue;
            }
            slot->processing = true;
        }

        if (slot->metrics) {
            if (work->type == WorkerWorkItem::Type::Frame) {
                processSlot(*slot, std::move(work->frameJob), *slot->metrics);
            } else {
                processConfirmation(*slot, std::move(work->confirmationRequest), *slot->metrics);
            }
        }

        bool scheduled = false;
        {
            std::lock_guard<std::mutex> lock(worker.mutex);
            slot->processing = false;
            slot->inFlight = false;
            const auto it = worker.slots.find(token.streamId);
            if (it != worker.slots.end() && it->second == slot && slot->active && !stopping_.load()) {
                scheduled = tryScheduleLocked(worker, slot);
            }
        }
        worker.cv.notify_all();
        if (scheduled) {
            if (slot->metrics) {
                slot->metrics->scheduledFrames.fetch_add(1);
            }
            worker.cv.notify_one();
        }
    }
}

}  // namespace guardvision
