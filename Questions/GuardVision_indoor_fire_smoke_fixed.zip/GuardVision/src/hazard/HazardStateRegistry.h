#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include <hazard/HazardConfig.h>
#include <hazard/HazardEvent.h>
#include <hazard/HazardTypes.h>

#include "metrics/HazardMetricsState.h"

namespace guardvision {

class HazardStateRegistry {
public:
    void reset();

    std::vector<HazardEvent> update(const std::vector<HazardRegion>& fireRegions, const std::vector<HazardRegion>& smokeRegions,
                                    const HazardConfig& config, const std::string& streamId, std::uint64_t generation, std::uint64_t sequence,
                                    std::int64_t timestampMs, HazardMetricsState* metrics);

    std::vector<HazardEvent> endActiveStates(const std::string& streamId, std::uint64_t generation, std::uint64_t sequence, std::int64_t timestampMs,
                                             HazardMetricsState* metrics);

    bool isFireActive() const noexcept;
    bool isSmokeActive() const noexcept;

private:
    enum class AlarmState { Idle, Candidate, Active, Clearing };

    struct TypeState {
        AlarmState state = AlarmState::Idle;
        int consecutiveDetectionFrames = 0;
        int consecutiveClearFrames = 0;
        std::int64_t lastEventTimestampMs = -1;
        std::vector<HazardRegion> lastRegions;
    };

    HazardEvent makeEvent(HazardEventType type, HazardType hazardType, const std::string& streamId, std::uint64_t generation, std::uint64_t sequence,
                          std::int64_t timestampMs, const std::vector<HazardRegion>& regions) const;

    std::vector<HazardEvent> updateType(HazardType hazardType, const std::vector<HazardRegion>& regions, const HazardConfig& config,
                                        const std::string& streamId, std::uint64_t generation, std::uint64_t sequence, std::int64_t timestampMs,
                                        TypeState& state, HazardMetricsState* metrics);

    TypeState fire_;
    TypeState smoke_;
};

}  // namespace guardvision
