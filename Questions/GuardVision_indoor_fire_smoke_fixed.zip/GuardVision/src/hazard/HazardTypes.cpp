#include <hazard/HazardTypes.h>

namespace guardvision {

const char* toString(HazardType type) noexcept {
    switch (type) {
        case HazardType::Fire:
            return "Fire";
        case HazardType::Smoke:
            return "Smoke";
    }
    return "Unknown";
}

const char* toString(HazardProcessingLevel level) noexcept {
    switch (level) {
        case HazardProcessingLevel::Disabled:
            return "Disabled";
        case HazardProcessingLevel::Detect:
            return "Detect";
    }
    return "Unknown";
}

const char* toString(HazardEventType type) noexcept {
    switch (type) {
        case HazardEventType::Started:
            return "Started";
        case HazardEventType::Updated:
            return "Updated";
        case HazardEventType::Ended:
            return "Ended";
    }
    return "Unknown";
}

}  // namespace guardvision
