#include "hazard/HazardEngine.h"

#include <cstdlib>
#include <cmath>
#include <filesystem>
#include <vector>

#ifdef GUARDVISION_HAVE_HAZARD
#include <hazard_detect.h>
#endif

namespace guardvision {
namespace {

bool isHazardModelFile(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::is_regular_file(path, ec) || ec) {
        return false;
    }
    return path.filename() == "fire_smoke.onnx" || path.extension() == ".onnx";
}

void appendCandidate(std::vector<std::filesystem::path>& candidates, const std::filesystem::path& path) {
    if (!path.empty()) {
        candidates.push_back(path);
    }
}

std::string normalizeModelPath(const std::filesystem::path& path) {
    std::error_code ec;
    const std::filesystem::path canonicalPath = std::filesystem::weakly_canonical(path, ec);
    if (!ec && isHazardModelFile(canonicalPath)) {
        return canonicalPath.string();
    }
    ec.clear();
    const std::filesystem::path absolutePath = std::filesystem::absolute(path, ec);
    return ec ? path.lexically_normal().string() : absolutePath.lexically_normal().string();
}

}  // namespace

HazardEngine& HazardEngine::instance() {
    static HazardEngine engine;
    return engine;
}

std::string discoverHazardModelPath(const std::string& overridePath) {
    if (!overridePath.empty()) {
        return overridePath;
    }

    if (const char* envPath = std::getenv("GUARDVISION_HAZARD_MODEL_DIR")) {
        if (*envPath != '\0') {
            const std::filesystem::path envModel = std::filesystem::path(envPath) / "fire_smoke.onnx";
            if (isHazardModelFile(envModel)) {
                return envModel.string();
            }
            if (isHazardModelFile(envPath)) {
                return std::string(envPath);
            }
        }
    }

    if (const char* envPath = std::getenv("HAZARD_DETECT_MODEL")) {
        if (*envPath != '\0' && isHazardModelFile(envPath)) {
            return std::string(envPath);
        }
    }

    std::vector<std::filesystem::path> candidates;
#ifdef GUARDVISION_HAZARDDETECT_RESOURCE_DIR
    appendCandidate(candidates, std::filesystem::path(GUARDVISION_HAZARDDETECT_RESOURCE_DIR) / "fire_smoke.onnx");
#endif
    appendCandidate(candidates, "models/fire_smoke.onnx");
    appendCandidate(candidates, "fire_smoke.onnx");
    appendCandidate(candidates, "assets/models/fire_smoke.onnx");
    appendCandidate(candidates, "sdk/HazardDetect/models/fire_smoke.onnx");
    appendCandidate(candidates, "../sdk/HazardDetect/models/fire_smoke.onnx");
    appendCandidate(candidates, "../../sdk/HazardDetect/models/fire_smoke.onnx");

    for (const auto& candidate : candidates) {
        if (isHazardModelFile(candidate)) {
            std::error_code ec;
            return std::filesystem::absolute(candidate, ec).string();
        }
    }
    return {};
}

Result HazardEngine::initialize(const std::string& modelPathOverride, float confidenceThreshold) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (initialized_.load(std::memory_order_acquire)) {
        if (!modelPathOverride.empty()) {
            std::string requestedPath = discoverHazardModelPath(modelPathOverride);
            if (requestedPath.empty() || !isHazardModelFile(requestedPath)) {
                return Result::failure(GuardVisionErrorCode::HazardModelMissing, "The requested HazardDetect model was not found.", "HazardEngine");
            }
            requestedPath = normalizeModelPath(requestedPath);
            if (requestedPath != modelPath_) {
                return Result::failure(GuardVisionErrorCode::InvalidConfiguration, "HazardEngine is already initialized with a different model.",
                                       "HazardEngine");
            }
        }
        if (std::fabs(confidenceThreshold - confidenceThreshold_) > 0.000001f) {
            return Result::failure(GuardVisionErrorCode::InvalidConfiguration,
                                   "HazardEngine is already initialized with a different global confidence threshold.", "HazardEngine");
        }
        return Result::success();
    }

#ifndef GUARDVISION_HAVE_HAZARD
    return Result::failure(GuardVisionErrorCode::HazardEngineInitializationFailed, "Hazard support is not available.", "HazardEngine");
#else
    modelPath_ = discoverHazardModelPath(modelPathOverride);
    if (isHazardModelFile(modelPath_)) {
        modelPath_ = normalizeModelPath(modelPath_);
    }
    if (modelPath_.empty() || !isHazardModelFile(modelPath_)) {
        return Result::failure(GuardVisionErrorCode::HazardModelMissing, "HazardDetect model was not found.", "HazardEngine");
    }

    if (HazardDetect_Init(modelPath_.c_str(), confidenceThreshold) == 0) {
        const char* lastError = HazardDetect_LastError();
        GuardVisionError error;
        error.code = GuardVisionErrorCode::HazardEngineInitializationFailed;
        error.component = "HazardEngine";
        error.message = lastError != nullptr ? lastError : "HazardDetect_Init failed.";
        error.recoverable = false;
        error.vendorErrorCode = -1;
        return Result::failure(error.code, error.message, error.component, error.streamId);
    }

    confidenceThreshold_ = confidenceThreshold;
    initialized_.store(true, std::memory_order_release);
    return Result::success();
#endif
}

void HazardEngine::shutdown() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!initialized_.load(std::memory_order_acquire)) {
        return;
    }
#ifdef GUARDVISION_HAVE_HAZARD
    HazardDetect_Shutdown();
#endif
    initialized_.store(false, std::memory_order_release);
    modelPath_.clear();
    confidenceThreshold_ = 0.0f;
}

bool HazardEngine::isInitialized() const noexcept {
    return initialized_.load(std::memory_order_acquire);
}

std::string HazardEngine::modelPath() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return modelPath_;
}

}  // namespace guardvision
