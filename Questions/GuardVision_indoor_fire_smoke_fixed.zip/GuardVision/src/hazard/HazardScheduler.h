#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <core/Error.h>
#include <hazard/HazardConfig.h>
#include <hazard/HazardEvent.h>
#include <onboard/OnboardTypes.h>
#include <frame/VideoFrame.h>

#include "core/StreamToken.h"
#include "hazard/HazardProcessor.h"
#include "hazard/HazardStateRegistry.h"
#include "metrics/HazardMetricsState.h"
#include "metrics/OnboardMetricsState.h"
#include "scheduling/FairStreamQueue.h"
#include "scheduling/LatestFrameSlot.h"

namespace guardvision {

struct HazardRoutingJob {
    StreamToken token;
    VideoFrame frame;
    HazardConfig config;
    std::int64_t submittedAtMs = 0;
};

struct HazardOfferResult {
    bool accepted = false;
    bool replacedPending = false;
    bool queueUnavailable = false;
};

struct HazardRegionalConfirmationRequest {
    StreamToken token;
    CandidateType candidateType = CandidateType::Fire;
    std::int64_t candidateTimestampMs = 0;
    Rect originalCandidateRegion;
    Rect mappedCandidateRegion;
    Rect expandedAnalysisRegion;
    VideoFrame matchedFrame;
    HazardConfig config;
    double onboardConfidence = 0.0;
    std::string targetId;
    std::shared_ptr<OnboardMetricsState> onboardMetrics;
};

struct HazardRegionalConfirmationResult {
    StreamToken token;
    CandidateType candidateType = CandidateType::Fire;
    std::int64_t candidateTimestampMs = 0;
    Rect originalCandidateRegion;
    Rect mappedCandidateRegion;
    Rect expandedAnalysisRegion;
    std::vector<HazardRegion> confirmedRegions;
    double softwareConfidence = 0.0;
    double onboardConfidence = 0.0;
    std::string targetId;
    std::shared_ptr<OnboardMetricsState> onboardMetrics;
    bool confirmed = false;
    bool stale = false;
    bool hadError = false;
    GuardVisionError error;
};

struct HazardConfirmationOfferResult {
    bool accepted = false;
    bool queueFull = false;
    bool stale = false;
};

class HazardScheduler {
public:
    using EventCallback = std::function<void(std::vector<HazardEvent>)>;
    using ErrorCallback = std::function<void(GuardVisionError)>;
    using ConfirmationCallback = std::function<void(HazardRegionalConfirmationResult)>;
    using ActiveTokenValidator = std::function<bool(const StreamToken& token)>;

    HazardScheduler(EventCallback eventCallback, ErrorCallback errorCallback);
    ~HazardScheduler();

    void start(int workerCount);
    void stop();
    void join();

    int registerStream(const StreamToken& token, const HazardConfig& config, std::shared_ptr<HazardMetricsState> metrics);
    void unregisterStream(const StreamToken& token);
    void updateStreamConfig(const StreamToken& token, const HazardConfig& config);
    HazardOfferResult offerFrame(HazardRoutingJob job);
    HazardConfirmationOfferResult offerRegionalConfirmation(HazardRegionalConfirmationRequest request);
    void setConfirmationCallback(ConfirmationCallback callback);
    void setActiveTokenValidator(ActiveTokenValidator validator);

private:
    struct WorkerWorkItem {
        enum class Type { Frame, Confirmation };
        Type type = Type::Frame;
        HazardRoutingJob frameJob;
        HazardRegionalConfirmationRequest confirmationRequest;
    };

    struct WorkerStreamSlot {
        StreamToken token;
        HazardConfig config;
        LatestFrameSlot pending;
        bool inFlight = false;
        bool processing = false;
        bool active = false;
        HazardStateRegistry state;
        std::int64_t lastAnalyzedTimestampMs = -1;
        std::deque<HazardRegionalConfirmationRequest> pendingConfirmations;
        std::shared_ptr<HazardMetricsState> metrics;
        HazardProcessingScratch processingScratch;
    };

    struct WorkerState {
        std::mutex mutex;
        std::condition_variable cv;
        FairStreamQueue readyStreams{256};
        std::unordered_map<std::string, std::shared_ptr<WorkerStreamSlot>> slots;
    };

    void workerLoop(int workerIndex);
    void processSlot(WorkerStreamSlot& slot, HazardRoutingJob job, HazardMetricsState& metrics);
    void processConfirmation(WorkerStreamSlot& slot, HazardRegionalConfirmationRequest request, HazardMetricsState& metrics);
    bool tryScheduleLocked(WorkerState& worker, const std::shared_ptr<WorkerStreamSlot>& slot);
    std::optional<WorkerWorkItem> takeWorkForStreamLocked(WorkerState& worker, const std::shared_ptr<WorkerStreamSlot>& slot);

    EventCallback eventCallback_;
    ErrorCallback errorCallback_;
    ConfirmationCallback confirmationCallback_;
    ActiveTokenValidator activeTokenValidator_;
    HazardProcessor processor_;

    std::atomic<bool> stopping_{false};
    std::atomic<bool> workersRunning_{false};
    int workerCount_ = 0;

    mutable std::mutex affinityMutex_;
    std::unordered_map<std::string, int> streamWorkerAffinity_;

    std::vector<std::unique_ptr<WorkerState>> workers_;
    std::vector<std::thread> workerThreads_;
};

}  // namespace guardvision
