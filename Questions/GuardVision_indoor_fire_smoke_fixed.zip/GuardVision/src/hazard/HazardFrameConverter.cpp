#include "hazard/HazardFrameConverter.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include <geometry/Geometry.h>

namespace guardvision {
namespace {

void setConversionError(HazardImageConversion& output, GuardVisionErrorCode code, const char* message) {
    output.ok = false;
    output.error.code = code;
    output.error.component = "HazardFrameConverter";
    output.error.message = message;
    output.error.recoverable = true;
}

Rect computeRoiRect(const VideoFrame& frame, const HazardConfig& config) {
    if (!config.useRoi) {
        return Rect{0, 0, frame.width, frame.height};
    }
    return clampRect(normalizedRectToPixels(config.roi, frame.size()), frame.size());
}

std::uint8_t clampByte(int value) {
    return static_cast<std::uint8_t>(std::max(0, std::min(255, value)));
}

void yuvToBgr(std::uint8_t y, std::uint8_t u, std::uint8_t v, std::uint8_t& b, std::uint8_t& g, std::uint8_t& r) {
    const int c = static_cast<int>(y);
    const int d = static_cast<int>(u) - 128;
    const int e = static_cast<int>(v) - 128;
    b = clampByte(c + ((359 * e) >> 8));
    g = clampByte(c - ((88 * d + 183 * e) >> 8));
    r = clampByte(c + ((454 * d) >> 8));
}

void copyGrayToBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::uint8_t value = source[y * srcStride + x];
            const std::size_t offset = static_cast<std::size_t>((y * width + x) * 3);
            dest[offset] = value;
            dest[offset + 1] = value;
            dest[offset + 2] = value;
        }
    }
}

void copyRgbToBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::size_t srcOffset = static_cast<std::size_t>(y * srcStride + x * 3);
            const std::size_t dstOffset = static_cast<std::size_t>((y * width + x) * 3);
            dest[dstOffset] = source[srcOffset + 2];
            dest[dstOffset + 1] = source[srcOffset + 1];
            dest[dstOffset + 2] = source[srcOffset];
        }
    }
}

void copyBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        std::memcpy(dest.data() + static_cast<std::size_t>(y * width * 3), source + static_cast<std::size_t>(y * srcStride),
                    static_cast<std::size_t>(width * 3));
    }
}

void copyBgraToBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::size_t srcOffset = static_cast<std::size_t>(y * srcStride + x * 4);
            const std::size_t dstOffset = static_cast<std::size_t>((y * width + x) * 3);
            dest[dstOffset] = source[srcOffset];
            dest[dstOffset + 1] = source[srcOffset + 1];
            dest[dstOffset + 2] = source[srcOffset + 2];
        }
    }
}

void convertNv12ToBgr(const std::uint8_t* data, int width, int height, int stride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    const std::uint8_t* yPlane = data;
    const std::uint8_t* uvPlane = data + static_cast<std::size_t>(stride * height);
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::uint8_t yValue = yPlane[y * stride + x];
            const int uvX = (x / 2) * 2;
            const int uvY = y / 2;
            const std::uint8_t u = uvPlane[uvY * stride + uvX];
            const std::uint8_t v = uvPlane[uvY * stride + uvX + 1];
            std::uint8_t b = 0;
            std::uint8_t g = 0;
            std::uint8_t r = 0;
            yuvToBgr(yValue, u, v, b, g, r);
            const std::size_t offset = static_cast<std::size_t>((y * width + x) * 3);
            dest[offset] = b;
            dest[offset + 1] = g;
            dest[offset + 2] = r;
        }
    }
}

void convertI420FamilyToBgr(const std::uint8_t* data, int width, int height, int stride, bool vBeforeU, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    const std::size_t ySize = static_cast<std::size_t>(stride * height);
    const int chromaHeight = (height + 1) / 2;
    const int chromaStride = (stride + 1) / 2;
    const std::size_t chromaPlaneSize = static_cast<std::size_t>(chromaStride * chromaHeight);
    const std::uint8_t* yPlane = data;
    const std::uint8_t* uPlane = vBeforeU ? data + ySize + chromaPlaneSize : data + ySize;
    const std::uint8_t* vPlane = vBeforeU ? data + ySize : data + ySize + chromaPlaneSize;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::uint8_t yValue = yPlane[y * stride + x];
            const int cx = x / 2;
            const int cy = y / 2;
            const std::uint8_t u = uPlane[cy * chromaStride + cx];
            const std::uint8_t v = vPlane[cy * chromaStride + cx];
            std::uint8_t b = 0;
            std::uint8_t g = 0;
            std::uint8_t r = 0;
            yuvToBgr(yValue, u, v, b, g, r);
            const std::size_t offset = static_cast<std::size_t>((y * width + x) * 3);
            dest[offset] = b;
            dest[offset + 1] = g;
            dest[offset + 2] = r;
        }
    }
}

void cropRectToBgr(const std::uint8_t* fullBgr, int fullWidth, const Rect& roi, std::vector<std::uint8_t>& dest, int& outWidth, int& outHeight) {
    outWidth = roi.width;
    outHeight = roi.height;
    dest.resize(static_cast<std::size_t>(roi.width * roi.height * 3));
    for (int y = 0; y < roi.height; ++y) {
        const int srcY = roi.y + y;
        const std::uint8_t* srcRow = fullBgr + static_cast<std::size_t>((srcY * fullWidth + roi.x) * 3);
        std::memcpy(dest.data() + static_cast<std::size_t>(y * roi.width * 3), srcRow, static_cast<std::size_t>(roi.width * 3));
    }
}

}  // namespace

bool convertFrameForHazardDetect(const VideoFrame& frame, const HazardConfig& config, HazardImageConversion& output,
                                 HazardFrameConversionScratch& scratch) {
    output.ok = false;
    output.error = GuardVisionError{};
    output.roiFullFrame = Rect{};
    output.pixels.clear();
    output.width = 0;
    output.height = 0;
    output.stride = 0;
    scratch.fullFrameBgr.clear();
    if (!frame.buffer || frame.width <= 0 || frame.height <= 0) {
        setConversionError(output, GuardVisionErrorCode::InvalidFrame, "Hazard conversion requires a valid frame.");
        return false;
    }

    const Rect roi = computeRoiRect(frame, config);
    if (!roi.isValid()) {
        setConversionError(output, GuardVisionErrorCode::InvalidHazardConfiguration, "Hazard ROI is invalid.");
        return false;
    }

    std::vector<std::uint8_t>& convertedBgr = config.useRoi ? scratch.fullFrameBgr : output.pixels;
    const std::uint8_t* data = frame.buffer->data();
    switch (frame.pixelFormat) {
        case PixelFormat::Gray8:
            copyGrayToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::RGB24:
            copyRgbToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::BGR24:
            copyBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::BGRA32:
            copyBgraToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::NV12:
            convertNv12ToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::I420:
            convertI420FamilyToBgr(data, frame.width, frame.height, frame.stride, false, convertedBgr);
            break;
        case PixelFormat::YV12:
            convertI420FamilyToBgr(data, frame.width, frame.height, frame.stride, true, convertedBgr);
            break;
        default:
            setConversionError(output, GuardVisionErrorCode::UnsupportedHazardPixelFormat, "Hazard processing does not support this pixel format.");
            return false;
    }

    output.roiFullFrame = roi;
    if (config.useRoi) {
        cropRectToBgr(scratch.fullFrameBgr.data(), frame.width, roi, output.pixels, output.width, output.height);
    } else {
        output.width = frame.width;
        output.height = frame.height;
    }
    output.stride = output.width * 3;
    output.ok = true;
    return true;
}

}  // namespace guardvision
