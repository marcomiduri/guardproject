#include "FrameValidation.h"

#include <limits>

#include <core/StreamConfig.h>

namespace guardvision {
namespace detail {

bool checkedMultiply(std::size_t lhs, std::size_t rhs, std::size_t& out) noexcept {
    if (lhs == 0 || rhs == 0) {
        out = 0;
        return true;
    }
    if (lhs > std::numeric_limits<std::size_t>::max() / rhs) {
        return false;
    }
    out = lhs * rhs;
    return true;
}

bool checkedAdd(std::size_t lhs, std::size_t rhs, std::size_t& out) noexcept {
    if (lhs > std::numeric_limits<std::size_t>::max() - rhs) {
        return false;
    }
    out = lhs + rhs;
    return true;
}

int minimumStrideBytes(int width, PixelFormat format) noexcept {
    if (width <= 0) {
        return 0;
    }
    switch (format) {
        case PixelFormat::BGR24:
        case PixelFormat::RGB24:
            return width * 3;
        case PixelFormat::BGRA32:
            return width * 4;
        case PixelFormat::Gray8:
            return width;
        case PixelFormat::NV12:
        case PixelFormat::I420:
        case PixelFormat::YV12:
            return width;
    }
    return 0;
}

}  // namespace detail

bool isSupportedPixelFormat(PixelFormat format) noexcept {
    switch (format) {
        case PixelFormat::BGR24:
        case PixelFormat::RGB24:
        case PixelFormat::BGRA32:
        case PixelFormat::Gray8:
        case PixelFormat::NV12:
        case PixelFormat::I420:
        case PixelFormat::YV12:
            return true;
    }
    return false;
}

bool isPlanarPixelFormat(PixelFormat format) noexcept {
    switch (format) {
        case PixelFormat::NV12:
        case PixelFormat::I420:
        case PixelFormat::YV12:
            return true;
        default:
            return false;
    }
}

std::size_t minimumBufferSize(int width, int height, int stride, PixelFormat format) {
    if (width <= 0 || height <= 0 || stride <= 0 || !isSupportedPixelFormat(format)) {
        return 0;
    }

    const int minStride = detail::minimumStrideBytes(width, format);
    if (stride < minStride) {
        return 0;
    }

    std::size_t total = 0;
    std::size_t part = 0;

    switch (format) {
        case PixelFormat::BGR24:
        case PixelFormat::RGB24:
        case PixelFormat::BGRA32:
        case PixelFormat::Gray8:
            if (!detail::checkedMultiply(static_cast<std::size_t>(stride), static_cast<std::size_t>(height), part)) {
                return 0;
            }
            return part;

        case PixelFormat::NV12: {
            if (!detail::checkedMultiply(static_cast<std::size_t>(stride), static_cast<std::size_t>(height), part)) {
                return 0;
            }
            total = part;
            const int uvHeight = (height + 1) / 2;
            if (!detail::checkedMultiply(static_cast<std::size_t>(stride), static_cast<std::size_t>(uvHeight), part)) {
                return 0;
            }
            if (!detail::checkedAdd(total, part, total)) {
                return 0;
            }
            return total;
        }

        case PixelFormat::I420:
        case PixelFormat::YV12: {
            if (!detail::checkedMultiply(static_cast<std::size_t>(stride), static_cast<std::size_t>(height), part)) {
                return 0;
            }
            total = part;
            const int chromaWidth = (width + 1) / 2;
            const int chromaHeight = (height + 1) / 2;
            const int chromaStride = (stride + 1) / 2;
            if (chromaStride < chromaWidth) {
                return 0;
            }
            if (!detail::checkedMultiply(static_cast<std::size_t>(chromaStride), static_cast<std::size_t>(chromaHeight), part)) {
                return 0;
            }
            if (!detail::checkedAdd(total, part, total)) {
                return 0;
            }
            if (!detail::checkedAdd(total, part, total)) {
                return 0;
            }
            return total;
        }
    }

    return 0;
}

bool VideoFrame::isValid() const noexcept {
    if (!isValidStreamId(streamId)) {
        return false;
    }
    if (width <= 0 || height <= 0 || stride <= 0) {
        return false;
    }
    if (!isSupportedPixelFormat(pixelFormat)) {
        return false;
    }
    if (timestampMs < 0) {
        return false;
    }
    if (!buffer) {
        return false;
    }

    const std::size_t required = minimumBufferSize(width, height, stride, pixelFormat);
    if (required == 0 || buffer->sizeBytes() < required) {
        return false;
    }

    return true;
}

Size VideoFrame::size() const noexcept {
    return Size{width, height};
}

}  // namespace guardvision
