#include <frame/FrameBuffer.h>

#include <cstring>

namespace guardvision {

FrameBuffer::FrameBuffer(std::size_t sizeBytes) : data_(sizeBytes) {}

std::shared_ptr<FrameBuffer> FrameBuffer::allocate(std::size_t sizeBytes) {
    return std::shared_ptr<FrameBuffer>(new FrameBuffer(sizeBytes));
}

std::shared_ptr<FrameBuffer> FrameBuffer::copyFrom(const std::uint8_t* source, std::size_t sizeBytes) {
    if (sizeBytes > 0 && source == nullptr) {
        return nullptr;
    }
    auto buffer = allocate(sizeBytes);
    if (sizeBytes > 0) {
        std::memcpy(buffer->data_.data(), source, sizeBytes);
    }
    return buffer;
}

const std::uint8_t* FrameBuffer::data() const noexcept {
    return data_.empty() ? nullptr : data_.data();
}

std::size_t FrameBuffer::sizeBytes() const noexcept {
    return data_.size();
}

bool FrameBuffer::empty() const noexcept {
    return data_.empty();
}

}  // namespace guardvision
