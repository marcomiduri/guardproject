#include <frame/VideoFrame.h>

namespace guardvision {

// VideoFrame structural helpers live in FrameValidation.cpp.

}  // namespace guardvision
