#include "frame/LatestFrameStore.h"

namespace guardvision {

std::size_t LatestFrameStore::shardIndex(const Key& key) noexcept {
    return KeyHash{}(key) % kShardCount;
}

void LatestFrameStore::update(const StreamToken& token, VideoFrame frame) {
    Key key{token.streamId, token.generation};
    Shard& shard = shards_[shardIndex(key)];
    std::lock_guard<std::mutex> lock(shard.mutex);
    shard.frames.insert_or_assign(std::move(key), std::move(frame));
}

std::optional<VideoFrame> LatestFrameStore::get(const StreamToken& token) const {
    const Key key{token.streamId, token.generation};
    const Shard& shard = shards_[shardIndex(key)];
    std::lock_guard<std::mutex> lock(shard.mutex);
    const auto it = shard.frames.find(key);
    if (it == shard.frames.end()) {
        return std::nullopt;
    }
    return it->second;
}

void LatestFrameStore::remove(const StreamToken& token) {
    const Key key{token.streamId, token.generation};
    Shard& shard = shards_[shardIndex(key)];
    std::lock_guard<std::mutex> lock(shard.mutex);
    shard.frames.erase(key);
}

void LatestFrameStore::clear() {
    for (Shard& shard : shards_) {
        std::lock_guard<std::mutex> lock(shard.mutex);
        shard.frames.clear();
    }
}

}  // namespace guardvision
