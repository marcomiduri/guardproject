#pragma once

#include <cstddef>
#include <cstdint>

#include <frame/VideoFrame.h>

namespace guardvision {
namespace detail {

bool checkedMultiply(std::size_t lhs, std::size_t rhs, std::size_t& out) noexcept;
bool checkedAdd(std::size_t lhs, std::size_t rhs, std::size_t& out) noexcept;
int minimumStrideBytes(int width, PixelFormat format) noexcept;

}  // namespace detail
}  // namespace guardvision
