#pragma once

#include <array>
#include <cstddef>
#include <mutex>
#include <optional>
#include <unordered_map>

#include <frame/VideoFrame.h>

#include "core/StreamToken.h"

namespace guardvision {

class LatestFrameStore {
public:
    void update(const StreamToken& token, VideoFrame frame);
    std::optional<VideoFrame> get(const StreamToken& token) const;
    void remove(const StreamToken& token);
    void clear();

private:
    struct Key {
        std::string streamId;
        std::uint64_t generation = 0;
        bool operator==(const Key& other) const noexcept {
            return streamId == other.streamId && generation == other.generation;
        }
    };

    struct KeyHash {
        std::size_t operator()(const Key& key) const noexcept {
            return std::hash<std::string>{}(key.streamId) ^ (std::hash<std::uint64_t>{}(key.generation) << 1U);
        }
    };

    struct Shard {
        mutable std::mutex mutex;
        std::unordered_map<Key, VideoFrame, KeyHash> frames;
    };

    static constexpr std::size_t kShardCount = 16;
    static std::size_t shardIndex(const Key& key) noexcept;

    std::array<Shard, kShardCount> shards_;
};

}  // namespace guardvision
