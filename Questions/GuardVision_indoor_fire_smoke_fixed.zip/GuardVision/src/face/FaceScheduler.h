#pragma once

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <core/Error.h>
#include <face/FaceConfig.h>
#include <face/FaceEvent.h>
#include <onboard/OnboardTypes.h>
#include <frame/VideoFrame.h>

#include "core/StreamToken.h"
#include "face/FaceProcessor.h"
#include "face/FaceTrackRegistry.h"
#include "metrics/FaceMetricsState.h"
#include "metrics/OnboardMetricsState.h"
#include "scheduling/FairStreamQueue.h"
#include "scheduling/LatestFrameSlot.h"

namespace guardvision {

struct FaceRoutingJob {
    StreamToken token;
    VideoFrame frame;
    FaceConfig config;
    std::int64_t submittedAtMs = 0;
};

struct FaceOfferResult {
    bool accepted = false;
    bool replacedPending = false;
    bool queueUnavailable = false;
};

struct FaceRegionalConfirmationRequest {
    StreamToken token;
    CandidateType candidateType = CandidateType::Face;
    std::int64_t candidateTimestampMs = 0;
    Rect originalCandidateRegion;
    Rect mappedCandidateRegion;
    Rect expandedAnalysisRegion;
    VideoFrame matchedFrame;
    FaceConfig config;
    double onboardConfidence = 0.0;
    std::string targetId;
    std::shared_ptr<OnboardMetricsState> onboardMetrics;
};

struct FaceRegionalConfirmationResult {
    StreamToken token;
    CandidateType candidateType = CandidateType::Face;
    std::int64_t candidateTimestampMs = 0;
    Rect originalCandidateRegion;
    Rect mappedCandidateRegion;
    Rect expandedAnalysisRegion;
    std::vector<Rect> confirmedRegions;
    double softwareConfidence = 0.0;
    std::uint64_t softwareTrackId = 0;
    double onboardConfidence = 0.0;
    std::string targetId;
    std::shared_ptr<OnboardMetricsState> onboardMetrics;
    bool confirmed = false;
    bool stale = false;
    bool hadError = false;
    GuardVisionError error;
};

struct FaceConfirmationOfferResult {
    bool accepted = false;
    bool queueFull = false;
    bool stale = false;
};

class FaceScheduler {
public:
    using EventCallback = std::function<void(std::vector<FaceEvent>)>;
    using ErrorCallback = std::function<void(GuardVisionError)>;
    using ConfirmationCallback = std::function<void(FaceRegionalConfirmationResult)>;
    using ActiveTokenValidator = std::function<bool(const StreamToken& token)>;

    FaceScheduler(EventCallback eventCallback, ErrorCallback errorCallback);
    ~FaceScheduler();

    void start(int workerCount);
    void stop(bool releaseNativeSessions = true);
    void join();

    int registerStream(const StreamToken& token, const FaceConfig& config, std::shared_ptr<FaceMetricsState> metrics);
    void unregisterStream(const StreamToken& token);
    void updateStreamConfig(const StreamToken& token, const FaceConfig& config);
    FaceOfferResult offerFrame(FaceRoutingJob job);
    FaceConfirmationOfferResult offerRegionalConfirmation(FaceRegionalConfirmationRequest request);
    void setConfirmationCallback(ConfirmationCallback callback);
    void setActiveTokenValidator(ActiveTokenValidator validator);

private:
    struct WorkerWorkItem {
        enum class Type { Frame, Confirmation, DestroySession };
        Type type = Type::Frame;
        FaceRoutingJob frameJob;
        FaceRegionalConfirmationRequest confirmationRequest;
    };

    struct WorkerStreamSlot {
        StreamToken token;
        FaceConfig config;
        LatestFrameSlot pending;
        bool inFlight = false;
        bool processing = false;
        bool active = false;
        bool destroyRequested = false;
        void* sessionHandle = nullptr;
        FaceSessionSettingsCache sessionSettings;
        FaceTrackRegistry tracks{8};
        std::int64_t lastAnalyzedTimestampMs = -1;
        std::deque<FaceRegionalConfirmationRequest> pendingConfirmations;
        std::shared_ptr<FaceMetricsState> metrics;
        FaceProcessingScratch processingScratch;
    };

    struct WorkerState {
        std::mutex mutex;
        std::condition_variable cv;
        FairStreamQueue readyStreams{256};
        std::unordered_map<std::string, std::shared_ptr<WorkerStreamSlot>> slots;
    };

    void workerLoop(int workerIndex);
    void processSlot(WorkerStreamSlot& slot, FaceRoutingJob job, FaceMetricsState& metrics);
    void processConfirmation(WorkerStreamSlot& slot, FaceRegionalConfirmationRequest request, FaceMetricsState& metrics);
    bool tryScheduleLocked(WorkerState& worker, const std::shared_ptr<WorkerStreamSlot>& slot);
    std::optional<WorkerWorkItem> takeWorkForStreamLocked(WorkerState& worker, const std::shared_ptr<WorkerStreamSlot>& slot);

    EventCallback eventCallback_;
    ErrorCallback errorCallback_;
    ConfirmationCallback confirmationCallback_;
    ActiveTokenValidator activeTokenValidator_;
    FaceProcessor processor_;

    std::atomic<bool> stopping_{false};
    std::atomic<bool> workersRunning_{false};
    int workerCount_ = 0;

    mutable std::mutex affinityMutex_;
    std::unordered_map<std::string, int> streamWorkerAffinity_;

    std::vector<std::unique_ptr<WorkerState>> workers_;
    std::vector<std::thread> workerThreads_;
};

}  // namespace guardvision
