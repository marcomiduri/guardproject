#include "face/FaceProcessor.h"

namespace guardvision {

FaceProcessResult FaceProcessor::processFrame(const VideoFrame&, const StreamToken& token, const FaceConfig&, FaceTrackRegistry&,
                                              FaceMetricsState& metrics, std::int64_t&, void*& sessionHandle,
                                              FaceSessionSettingsCache& sessionSettings, FaceProcessingScratch&) {
    sessionHandle = nullptr;
    sessionSettings.reset();
    metrics.processingErrors.fetch_add(1, std::memory_order_relaxed);

    FaceProcessResult result;
    result.hadError = true;
    result.error = GuardVisionError{GuardVisionErrorCode::FaceEngineInitializationFailed, token.streamId, "FaceProcessor",
                                    "GuardVision was built without face support.",        false,          0};
    return result;
}

void FaceProcessor::destroySession(void*& sessionHandle, FaceSessionSettingsCache& sessionSettings) {
    sessionHandle = nullptr;
    sessionSettings.reset();
}

bool FaceProcessor::ensureSession(void*&, const FaceConfig&, FaceSessionSettingsCache&, GuardVisionError& error) const {
    error = GuardVisionError{GuardVisionErrorCode::FaceEngineInitializationFailed, {},    "FaceProcessor",
                             "GuardVision was built without face support.",        false, 0};
    return false;
}

void FaceProcessor::applySessionSettings(void*, const FaceConfig&, FaceSessionSettingsCache&) const {}

}  // namespace guardvision
