#include <face/FaceRegistry.h>

#include <algorithm>
#include <cmath>
#include <unordered_set>

namespace guardvision {

bool isValidFaceRegistry(const FaceRegistry& registry) noexcept {
    if (!std::isfinite(registry.threshold) || registry.threshold < 0.0f || registry.threshold > 1.0f) {
        return false;
    }

    std::size_t featureDimension = 0;
    std::unordered_set<std::uint64_t> identityIds;
    for (const FaceRegistryEntry& entry : registry.entries) {
        if (entry.identityId == 0 || entry.displayName.empty() || entry.feature.empty() || entry.feature.size() > 8192) {
            return false;
        }
        if (!identityIds.insert(entry.identityId).second) {
            return false;
        }
        if (featureDimension == 0) {
            featureDimension = entry.feature.size();
        } else if (entry.feature.size() != featureDimension) {
            return false;
        }
        if (!std::all_of(entry.feature.begin(), entry.feature.end(), [](float value) { return std::isfinite(value); })) {
            return false;
        }
    }
    return true;
}

}  // namespace guardvision
