#include <face/FaceConfig.h>

namespace guardvision {
namespace {

constexpr int kMaxIntervalMs = 3600000;
constexpr int kMaxFaceCount = 64;
constexpr int kMaxFaceDimension = 4096;

bool isUnitRatio(double value) noexcept {
    return value >= 0.0 && value <= 1.0;
}

}  // namespace

bool isSupportedFaceTriggerMode(FaceTriggerMode mode) noexcept {
    return mode == FaceTriggerMode::ContinuousSoftware || mode == FaceTriggerMode::OnboardTriggered || mode == FaceTriggerMode::Hybrid;
}

bool isValidFaceConfig(const FaceConfig& config) noexcept {
    if (config.analysisIntervalMs < 0 || config.analysisIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.minimumFaceWidth < 1 || config.minimumFaceWidth > kMaxFaceDimension) {
        return false;
    }
    if (config.minimumFaceHeight < 1 || config.minimumFaceHeight > kMaxFaceDimension) {
        return false;
    }
    if (!isUnitRatio(config.minimumDetectionConfidence) || !isUnitRatio(config.minimumQualityScore) ||
        !isUnitRatio(config.minimumIdentificationConfidence)) {
        return false;
    }
    if (config.maximumFaceCount < 1 || config.maximumFaceCount > kMaxFaceCount) {
        return false;
    }
    if (config.lostTrackTimeoutMs < 0 || config.lostTrackTimeoutMs > kMaxIntervalMs) {
        return false;
    }
    if (config.identificationRetryIntervalMs < 0 || config.identificationRetryIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.identityRefreshIntervalMs < 0 || config.identityRefreshIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.eventUpdateIntervalMs < 0 || config.eventUpdateIntervalMs > kMaxIntervalMs) {
        return false;
    }
    if (config.useRoi && !config.roi.isValid()) {
        return false;
    }
    if (config.processingLevel == FaceProcessingLevel::Disabled) {
        return true;
    }
    return isSupportedFaceTriggerMode(config.triggerMode);
}

}  // namespace guardvision
