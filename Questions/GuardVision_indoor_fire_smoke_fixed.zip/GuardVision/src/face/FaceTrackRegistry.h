#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include <face/FaceConfig.h>
#include <face/FaceEvent.h>
#include <face/FaceTypes.h>

#include "metrics/FaceMetricsState.h"

namespace guardvision {

struct InternalTrackState {
    std::uint64_t trackId = 0;
    int vendorTrackId = -1;
    Rect bounds;
    double detectionConfidence = 0.0;
    double qualityScore = 0.0;
    FaceTrackState state = FaceTrackState::Tracking;
    FaceIdentityMatch identity;
    std::int64_t lastSeenTimestampMs = 0;
    std::int64_t lastIdentificationAttemptMs = 0;
    std::int64_t lastIdentityRefreshMs = 0;
    bool pendingLostEvent = false;
};

class FaceTrackRegistry {
public:
    explicit FaceTrackRegistry(int maximumFaceCount);

    void reset();
    bool shouldAttemptIdentification(int vendorTrackId, const FaceConfig& config, std::int64_t nowMs) const;
    void recordIdentificationAttempt(int vendorTrackId, std::int64_t nowMs);
    const FaceIdentityMatch* cachedIdentityForVendorTrack(int vendorTrackId) const;
    std::vector<FaceEvent> updateDetections(const std::vector<FaceTrack>& detections,
                                            const std::unordered_map<int, FaceIdentityMatch>& frameIdentities, const FaceConfig& config,
                                            const std::string& streamId, std::uint64_t generation, std::uint64_t sequence, std::int64_t timestampMs,
                                            std::int64_t nowMs, FaceMetricsState* metrics);
    int activeTrackCount() const;

private:
    std::uint64_t mapVendorTrackId(int vendorTrackId, const Rect& bounds, const std::vector<std::uint64_t>& reservedTrackIds, std::int64_t nowMs,
                                   std::int64_t maxTrackAgeMs);
    FaceEvent makeEvent(FaceEventType type, const std::string& streamId, std::uint64_t generation, std::uint64_t sequence, std::int64_t timestampMs,
                        const FaceTrack& track) const;

    std::uint64_t nextTrackId_ = 1;
    std::unordered_map<int, std::uint64_t> vendorToInternal_;
    std::unordered_map<std::uint64_t, InternalTrackState> tracks_;
    std::unordered_map<int, std::int64_t> vendorLastAttemptMs_;
};

}  // namespace guardvision
