#pragma once

#include <cstdint>
#include <vector>

#include <core/Error.h>
#include <face/FaceConfig.h>
#include <face/FaceEvent.h>
#include <frame/VideoFrame.h>

#include "core/StreamToken.h"
#include "face/FaceFrameConverter.h"
#include "face/FaceTrackRegistry.h"
#include "metrics/FaceMetricsState.h"

namespace guardvision {

struct FaceProcessingScratch {
    FaceImageConversion conversion;
    FaceFrameConversionScratch frameConversion;
};

struct FaceSessionSettingsCache {
    bool valid = false;
    FaceProcessingLevel processingLevel = FaceProcessingLevel::Disabled;
    int maximumFaceCount = 0;
    int minimumFacePixelSize = 0;
    double detectionThreshold = 0.0;

    void reset() noexcept {
        valid = false;
        processingLevel = FaceProcessingLevel::Disabled;
        maximumFaceCount = 0;
        minimumFacePixelSize = 0;
        detectionThreshold = 0.0;
    }
};

struct FaceProcessResult {
    bool skippedByInterval = false;
    bool hadError = false;
    GuardVisionError error;
    std::int64_t processingTimeUs = 0;
    std::vector<FaceEvent> events;
};

class FaceProcessor {
public:
    FaceProcessResult processFrame(const VideoFrame& frame, const StreamToken& token, const FaceConfig& config, FaceTrackRegistry& tracks,
                                   FaceMetricsState& metrics, std::int64_t& lastAnalyzedTimestampMs, void*& sessionHandle,
                                   FaceSessionSettingsCache& sessionSettings, FaceProcessingScratch& scratch);
    void destroySession(void*& sessionHandle, FaceSessionSettingsCache& sessionSettings);

private:
    bool ensureSession(void*& sessionHandle, const FaceConfig& config, FaceSessionSettingsCache& sessionSettings, GuardVisionError& error) const;
    void applySessionSettings(void* sessionHandle, const FaceConfig& config, FaceSessionSettingsCache& sessionSettings) const;
};

}  // namespace guardvision
