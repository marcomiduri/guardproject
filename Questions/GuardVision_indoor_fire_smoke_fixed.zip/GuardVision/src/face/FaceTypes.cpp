#include <face/FaceTypes.h>

namespace guardvision {

const char* toString(FaceProcessingLevel level) noexcept {
    switch (level) {
        case FaceProcessingLevel::Disabled:
            return "Disabled";
        case FaceProcessingLevel::DetectAndTrack:
            return "DetectAndTrack";
        case FaceProcessingLevel::DetectTrackAndIdentify:
            return "DetectTrackAndIdentify";
    }
    return "Unknown";
}

const char* toString(FaceTriggerMode mode) noexcept {
    switch (mode) {
        case FaceTriggerMode::ContinuousSoftware:
            return "ContinuousSoftware";
        case FaceTriggerMode::OnboardTriggered:
            return "OnboardTriggered";
        case FaceTriggerMode::Hybrid:
            return "Hybrid";
    }
    return "Unknown";
}

const char* toString(FaceTrackState state) noexcept {
    switch (state) {
        case FaceTrackState::Appeared:
            return "Appeared";
        case FaceTrackState::Tracking:
            return "Tracking";
        case FaceTrackState::Lost:
            return "Lost";
    }
    return "Unknown";
}

const char* toString(FaceEventType type) noexcept {
    switch (type) {
        case FaceEventType::TracksUpdated:
            return "TracksUpdated";
        case FaceEventType::TrackAppeared:
            return "TrackAppeared";
        case FaceEventType::TrackLost:
            return "TrackLost";
        case FaceEventType::IdentityMatched:
            return "IdentityMatched";
        case FaceEventType::IdentityChanged:
            return "IdentityChanged";
    }
    return "Unknown";
}

}  // namespace guardvision
