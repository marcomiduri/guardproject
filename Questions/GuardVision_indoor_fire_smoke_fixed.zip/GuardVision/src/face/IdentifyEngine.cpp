#include "face/IdentifyEngine.h"

#include <cstdlib>
#include <filesystem>
#include <limits>
#include <vector>

#include <identify.h>

namespace guardvision {
namespace {

bool pathContainsModelPack(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::is_directory(path, ec) || ec) {
        return false;
    }
    for (const auto& entry : std::filesystem::directory_iterator(path, ec)) {
        if (ec) {
            break;
        }
        if (entry.is_regular_file() && entry.path().extension() == ".mnn") {
            return true;
        }
    }
    return false;
}

bool isIdentifyResourceFile(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::is_regular_file(path, ec) || ec) {
        return false;
    }
    const auto size = std::filesystem::file_size(path, ec);
    if (ec || size == 0) {
        return false;
    }
    const std::string filename = path.filename().string();
    // InspireFace/Identify "Pikachu" CPU model pack (tar resource archive, no extension).
    if (filename == "Pikachu") {
        return true;
    }
    if (path.extension() == ".mnn") {
        return true;
    }
    return false;
}

bool isValidIdentifyResourcePath(const std::filesystem::path& path) {
    return pathContainsModelPack(path) || isIdentifyResourceFile(path);
}

std::string normalizeResourcePath(const std::filesystem::path& path) {
    std::error_code ec;
    const std::filesystem::path canonicalPath = std::filesystem::weakly_canonical(path, ec);
    if (!ec && isValidIdentifyResourcePath(canonicalPath)) {
        return canonicalPath.string();
    }
    ec.clear();
    const std::filesystem::path absolutePath = std::filesystem::absolute(path, ec);
    if (!ec && isValidIdentifyResourcePath(absolutePath)) {
        return absolutePath.lexically_normal().string();
    }
    return path.lexically_normal().string();
}

void appendCandidate(std::vector<std::filesystem::path>& candidates, const std::filesystem::path& path) {
    if (path.empty()) {
        return;
    }
    candidates.push_back(path);
}

}  // namespace

IdentifyEngine& IdentifyEngine::instance() {
    static IdentifyEngine engine;
    return engine;
}

std::string discoverIdentifyResourcePath(const std::string& overridePath) {
    if (!overridePath.empty()) {
        return overridePath;
    }

    if (const char* envPath = std::getenv("GUARDVISION_IDENTIFY_RESOURCE_DIR")) {
        if (*envPath != '\0') {
            return std::string(envPath);
        }
    }

    std::vector<std::filesystem::path> candidates;
#ifdef GUARDVISION_IDENTIFY_RESOURCE_DIR
    appendCandidate(candidates, GUARDVISION_IDENTIFY_RESOURCE_DIR);
    appendCandidate(candidates, std::filesystem::path(GUARDVISION_IDENTIFY_RESOURCE_DIR) / "Pikachu");
#endif
    appendCandidate(candidates, "models/Pikachu");
    appendCandidate(candidates, "models");
    appendCandidate(candidates, "assets/Pikachu");
    appendCandidate(candidates, "Pikachu");
    appendCandidate(candidates, "../assets/Pikachu");
    appendCandidate(candidates, "../../assets/Pikachu");
    appendCandidate(candidates, "../../../assets/Pikachu");
    appendCandidate(candidates, "sdk/Identify/models/Pikachu");
    appendCandidate(candidates, "sdk/Identify/models");
    appendCandidate(candidates, "../sdk/Identify/models/Pikachu");
    appendCandidate(candidates, "../../sdk/Identify/models/Pikachu");

    for (const auto& candidate : candidates) {
        if (isValidIdentifyResourcePath(candidate)) {
            return normalizeResourcePath(candidate);
        }
    }
    return {};
}

Result IdentifyEngine::initialize(const std::string& resourcePathOverride) {
    std::lock_guard<std::recursive_mutex> lock(apiMutex_);
    if (initialized_.load(std::memory_order_acquire)) {
        if (resourcePathOverride.empty()) {
            return Result::success();
        }
        std::string requestedPath = discoverIdentifyResourcePath(resourcePathOverride);
        if (!isValidIdentifyResourcePath(requestedPath)) {
            return Result::failure(GuardVisionErrorCode::FaceModelMissing, "The requested Identify model pack was not found.", "IdentifyEngine");
        }
        requestedPath = normalizeResourcePath(requestedPath);
        if (requestedPath != resourcePath_) {
            return Result::failure(GuardVisionErrorCode::InvalidConfiguration, "IdentifyEngine is already initialized with a different model pack.",
                                   "IdentifyEngine");
        }
        return Result::success();
    }

    resourcePath_ = discoverIdentifyResourcePath(resourcePathOverride);
    if (!resourcePathOverride.empty() && isValidIdentifyResourcePath(resourcePath_)) {
        resourcePath_ = normalizeResourcePath(resourcePath_);
    }
    if (resourcePath_.empty() || !isValidIdentifyResourcePath(resourcePath_)) {
        return Result::failure(GuardVisionErrorCode::FaceModelMissing, "Identify model pack was not found.", "IdentifyEngine");
    }

    const HResult launchResult = HFLaunchIdentify(resourcePath_.c_str());
    if (launchResult != HSUCCEED) {
        GuardVisionError error;
        error.code = GuardVisionErrorCode::FaceEngineInitializationFailed;
        error.component = "IdentifyEngine";
        error.message = "HFLaunchIdentify failed.";
        error.recoverable = false;
        error.vendorErrorCode = static_cast<int>(launchResult);
        return Result::failure(error.code, error.message, error.component, error.streamId);
    }

    Result hubResult = enableFeatureHub(registry_.threshold);
    if (!hubResult.ok) {
        HFTerminateIdentify();
        return hubResult;
    }

    initialized_.store(true, std::memory_order_release);
    return Result::success();
}

Result IdentifyEngine::enableFeatureHub(float threshold) {
    HFFeatureHubConfiguration hubConfig{};
    hubConfig.primaryKeyMode = HF_PK_MANUAL_INPUT;
    hubConfig.enablePersistence = HF_STATUS_DISABLE;
    hubConfig.persistenceDbPath = nullptr;
    hubConfig.searchThreshold = threshold;
    hubConfig.searchMode = HF_SEARCH_MODE_EAGER;
    const HResult hubResult = HFFeatureHubDataEnable(hubConfig);
    if (hubResult != HSUCCEED) {
        GuardVisionError error;
        error.code = GuardVisionErrorCode::FaceEngineInitializationFailed;
        error.component = "IdentifyEngine";
        error.message = "HFFeatureHubDataEnable failed.";
        error.recoverable = false;
        error.vendorErrorCode = static_cast<int>(hubResult);
        return Result::failure(error.code, error.message, error.component, error.streamId);
    }

    featureHubEnabled_ = true;
    return Result::success();
}

Result IdentifyEngine::setFaceRegistry(const FaceRegistry& registry) {
    std::lock_guard<std::recursive_mutex> lock(apiMutex_);
    if (!initialized_.load(std::memory_order_acquire)) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "Identify engine is not initialized.", "IdentifyEngine");
    }
    if (!isValidFaceRegistry(registry)) {
        return Result::failure(GuardVisionErrorCode::InvalidFaceConfiguration, "Face registry is invalid.", "IdentifyEngine");
    }

    if (featureHubEnabled_) {
        HFFeatureHubDataDisable();
        featureHubEnabled_ = false;
    }

    registry_ = registry;
    displayNameById_.clear();

    Result hubResult = enableFeatureHub(registry_.threshold);
    if (!hubResult.ok) {
        return hubResult;
    }

    std::size_t inserted = 0;
    HResult lastInsertError = HSUCCEED;
    for (const FaceRegistryEntry& entry : registry_.entries) {
        if (entry.identityId > static_cast<std::uint64_t>(std::numeric_limits<HFaceId>::max()) ||
            entry.feature.size() > static_cast<std::size_t>(std::numeric_limits<HInt32>::max())) {
            continue;
        }

        HFFaceFeature feature{};
        feature.size = static_cast<HInt32>(entry.feature.size());
        feature.data = const_cast<float*>(entry.feature.data());

        HFFaceFeatureIdentity identity{};
        identity.id = static_cast<HFaceId>(entry.identityId);
        identity.feature = &feature;

        HFaceId allocatedId = 0;
        const HResult insertResult = HFFeatureHubInsertFeature(identity, &allocatedId);
        if (insertResult != HSUCCEED) {
            lastInsertError = insertResult;
            continue;
        }

        displayNameById_[entry.identityId] = entry.displayName;
        ++inserted;
    }

    if (!registry_.entries.empty() && inserted == 0) {
        GuardVisionError error;
        error.code = GuardVisionErrorCode::FaceEngineInitializationFailed;
        error.component = "IdentifyEngine";
        error.message = "No face registry entries could be inserted into FeatureHub.";
        error.recoverable = true;
        error.vendorErrorCode = static_cast<int>(lastInsertError);
        return Result::failure(error.code, error.message, error.component, error.streamId);
    }

    return Result::success();
}

Result IdentifyEngine::searchFaceFeature(const HFFaceFeature& feature, double minimumConfidence, FaceIdentityMatch& match) {
    std::lock_guard<std::recursive_mutex> lock(apiMutex_);
    if (!initialized_.load(std::memory_order_acquire) || !featureHubEnabled_) {
        return Result::failure(GuardVisionErrorCode::NotInitialized, "Identify FeatureHub is not initialized.", "IdentifyEngine");
    }

    HFFaceFeatureIdentity identity{};
    HFloat confidence = 0.0f;
    const HResult searchResult = HFFeatureHubFaceSearch(feature, &confidence, &identity);
    if (searchResult != HSUCCEED || static_cast<double>(confidence) < minimumConfidence) {
        return Result::failure(GuardVisionErrorCode::FaceIdentitySearchFailed, "No matching face identity found.", "IdentifyEngine");
    }

    match.identified = true;
    match.identityId = static_cast<std::uint64_t>(identity.id);
    match.confidence = static_cast<double>(confidence);

    const auto nameIt = displayNameById_.find(match.identityId);
    if (nameIt != displayNameById_.end() && !nameIt->second.empty()) {
        match.displayName = nameIt->second;
    } else {
        match.displayName = std::to_string(match.identityId);
    }

    return Result::success();
}

void IdentifyEngine::shutdown() {
    std::lock_guard<std::recursive_mutex> lock(apiMutex_);
    if (!initialized_.load(std::memory_order_acquire)) {
        return;
    }
    if (featureHubEnabled_) {
        HFFeatureHubDataDisable();
        featureHubEnabled_ = false;
    }
    HFTerminateIdentify();
    initialized_.store(false, std::memory_order_release);
    resourcePath_.clear();
    registry_ = FaceRegistry{};
    displayNameById_.clear();
}

bool IdentifyEngine::isInitialized() const noexcept {
    return initialized_.load(std::memory_order_acquire);
}

std::string IdentifyEngine::resourcePath() const {
    std::lock_guard<std::recursive_mutex> lock(apiMutex_);
    return resourcePath_;
}

}  // namespace guardvision
