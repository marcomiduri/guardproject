#include "face/FaceTrackRegistry.h"

#include <algorithm>

namespace guardvision {

FaceTrackRegistry::FaceTrackRegistry(int) {}

namespace {

constexpr double kVendorTrackReuseIou = 0.65;

bool containsTrackId(const std::vector<std::uint64_t>& trackIds, std::uint64_t trackId) {
    return std::find(trackIds.begin(), trackIds.end(), trackId) != trackIds.end();
}

}  // namespace

void FaceTrackRegistry::reset() {
    vendorToInternal_.clear();
    tracks_.clear();
    vendorLastAttemptMs_.clear();
    nextTrackId_ = 1;
}

std::uint64_t FaceTrackRegistry::mapVendorTrackId(int vendorTrackId, const Rect& bounds, const std::vector<std::uint64_t>& reservedTrackIds,
                                                  std::int64_t nowMs, std::int64_t maxTrackAgeMs) {
    const auto it = vendorToInternal_.find(vendorTrackId);
    if (it != vendorToInternal_.end()) {
        return it->second;
    }

    std::uint64_t bestTrackId = 0;
    double bestOverlap = 0.0;
    for (const auto& entry : tracks_) {
        const std::uint64_t candidateTrackId = entry.first;
        if (containsTrackId(reservedTrackIds, candidateTrackId)) {
            continue;
        }
        const InternalTrackState& state = entry.second;
        if (maxTrackAgeMs > 0 && nowMs - state.lastSeenTimestampMs > maxTrackAgeMs) {
            continue;
        }
        const double overlap = intersectOverUnion(state.bounds, bounds);
        if (overlap > bestOverlap) {
            bestOverlap = overlap;
            bestTrackId = candidateTrackId;
        }
    }
    if (bestTrackId != 0 && bestOverlap >= kVendorTrackReuseIou) {
        InternalTrackState& state = tracks_[bestTrackId];
        vendorToInternal_.erase(state.vendorTrackId);
        vendorLastAttemptMs_.erase(state.vendorTrackId);
        vendorToInternal_.emplace(vendorTrackId, bestTrackId);
        return bestTrackId;
    }

    const std::uint64_t trackId = nextTrackId_++;
    vendorToInternal_.emplace(vendorTrackId, trackId);
    return trackId;
}

FaceEvent FaceTrackRegistry::makeEvent(FaceEventType type, const std::string& streamId, std::uint64_t generation, std::uint64_t sequence,
                                       std::int64_t timestampMs, const FaceTrack& track) const {
    FaceEvent event;
    event.type = type;
    event.streamId = streamId;
    event.generation = generation;
    event.sequence = sequence;
    event.timestampMs = timestampMs;
    event.tracks = {track};
    return event;
}

bool FaceTrackRegistry::shouldAttemptIdentification(int vendorTrackId, const FaceConfig& config, std::int64_t nowMs) const {
    if (config.processingLevel != FaceProcessingLevel::DetectTrackAndIdentify) {
        return false;
    }

    const auto trackIt = vendorToInternal_.find(vendorTrackId);
    if (trackIt != vendorToInternal_.end()) {
        const InternalTrackState& state = tracks_.at(trackIt->second);
        if (state.identity.identified) {
            if (config.identityRefreshIntervalMs > 0 && nowMs - state.lastIdentityRefreshMs >= config.identityRefreshIntervalMs) {
                return true;
            }
            return false;
        }
    }

    const auto attemptIt = vendorLastAttemptMs_.find(vendorTrackId);
    const std::int64_t lastAttemptMs = attemptIt != vendorLastAttemptMs_.end() ? attemptIt->second : -1;
    if (lastAttemptMs < 0 || nowMs - lastAttemptMs >= config.identificationRetryIntervalMs) {
        return true;
    }
    return false;
}

void FaceTrackRegistry::recordIdentificationAttempt(int vendorTrackId, std::int64_t nowMs) {
    vendorLastAttemptMs_[vendorTrackId] = nowMs;
    const auto trackIt = vendorToInternal_.find(vendorTrackId);
    if (trackIt != vendorToInternal_.end()) {
        tracks_[trackIt->second].lastIdentificationAttemptMs = nowMs;
    }
}

const FaceIdentityMatch* FaceTrackRegistry::cachedIdentityForVendorTrack(int vendorTrackId) const {
    const auto trackIt = vendorToInternal_.find(vendorTrackId);
    if (trackIt == vendorToInternal_.end()) {
        return nullptr;
    }
    const InternalTrackState& state = tracks_.at(trackIt->second);
    return state.identity.identified ? &state.identity : nullptr;
}

std::vector<FaceEvent> FaceTrackRegistry::updateDetections(const std::vector<FaceTrack>& detections,
                                                           const std::unordered_map<int, FaceIdentityMatch>& frameIdentities,
                                                           const FaceConfig& config, const std::string& streamId, std::uint64_t generation,
                                                           std::uint64_t sequence, std::int64_t timestampMs, std::int64_t nowMs,
                                                           FaceMetricsState* metrics) {
    std::vector<FaceEvent> events;
    std::vector<std::uint64_t> trackIds;
    trackIds.reserve(tracks_.size());
    for (const auto& entry : tracks_) {
        trackIds.push_back(entry.first);
    }

    std::vector<FaceTrack> activeTracks;
    activeTracks.reserve(detections.size());
    std::vector<std::uint64_t> reservedTrackIds;
    reservedTrackIds.reserve(detections.size());

    for (const FaceTrack& detection : detections) {
        const int vendorTrackId = static_cast<int>(detection.trackId);
        const std::uint64_t trackId = mapVendorTrackId(vendorTrackId, detection.bounds, reservedTrackIds, nowMs, config.lostTrackTimeoutMs);
        reservedTrackIds.push_back(trackId);
        InternalTrackState& state = tracks_[trackId];
        const bool isNew = state.trackId == 0;
        state.trackId = trackId;
        state.vendorTrackId = vendorTrackId;
        state.bounds = detection.bounds;
        state.detectionConfidence = detection.detectionConfidence;
        state.qualityScore = detection.qualityScore;
        state.lastSeenTimestampMs = timestampMs;
        state.pendingLostEvent = false;

        FaceTrack publicTrack = detection;
        publicTrack.trackId = trackId;
        publicTrack.state = isNew ? FaceTrackState::Appeared : FaceTrackState::Tracking;
        state.state = publicTrack.state;

        const auto identityIt = frameIdentities.find(vendorTrackId);
        if (identityIt != frameIdentities.end() && identityIt->second.identified) {
            const FaceIdentityMatch& candidate = identityIt->second;
            if (!state.identity.identified) {
                state.identity = candidate;
                state.lastIdentityRefreshMs = nowMs;
                publicTrack.identity = candidate;
                events.push_back(makeEvent(FaceEventType::IdentityMatched, streamId, generation, sequence, timestampMs, publicTrack));
            } else if (state.identity.identityId != candidate.identityId) {
                state.identity = candidate;
                state.lastIdentityRefreshMs = nowMs;
                publicTrack.identity = candidate;
                events.push_back(makeEvent(FaceEventType::IdentityChanged, streamId, generation, sequence, timestampMs, publicTrack));
            } else {
                publicTrack.identity = state.identity;
            }
        } else if (state.identity.identified) {
            publicTrack.identity = state.identity;
            if (metrics != nullptr) {
                metrics->cachedIdentityUses.fetch_add(1, std::memory_order_relaxed);
            }
        }

        activeTracks.push_back(publicTrack);

        if (isNew) {
            events.push_back(makeEvent(FaceEventType::TrackAppeared, streamId, generation, sequence, timestampMs, publicTrack));
        }
    }

    for (const std::uint64_t trackId : trackIds) {
        InternalTrackState& state = tracks_[trackId];
        const bool stillVisible =
          std::any_of(activeTracks.begin(), activeTracks.end(), [trackId](const FaceTrack& track) { return track.trackId == trackId; });
        if (stillVisible) {
            continue;
        }
        if (state.pendingLostEvent) {
            continue;
        }
        if (nowMs - state.lastSeenTimestampMs >= config.lostTrackTimeoutMs) {
            FaceTrack lostTrack;
            lostTrack.trackId = state.trackId;
            lostTrack.bounds = state.bounds;
            lostTrack.detectionConfidence = state.detectionConfidence;
            lostTrack.qualityScore = state.qualityScore;
            lostTrack.state = FaceTrackState::Lost;
            lostTrack.identity = state.identity;
            events.push_back(makeEvent(FaceEventType::TrackLost, streamId, generation, sequence, timestampMs, lostTrack));
            vendorToInternal_.erase(state.vendorTrackId);
            vendorLastAttemptMs_.erase(state.vendorTrackId);
            tracks_.erase(trackId);
        }
    }

    while (static_cast<int>(tracks_.size()) > config.maximumFaceCount) {
        auto oldest = tracks_.begin();
        for (auto it = tracks_.begin(); it != tracks_.end(); ++it) {
            if (it->second.lastSeenTimestampMs < oldest->second.lastSeenTimestampMs) {
                oldest = it;
            }
        }
        vendorToInternal_.erase(oldest->second.vendorTrackId);
        vendorLastAttemptMs_.erase(oldest->second.vendorTrackId);
        tracks_.erase(oldest);
    }

    if (!activeTracks.empty()) {
        FaceEvent update;
        update.type = FaceEventType::TracksUpdated;
        update.streamId = streamId;
        update.generation = generation;
        update.sequence = sequence;
        update.timestampMs = timestampMs;
        update.tracks = std::move(activeTracks);
        events.push_back(std::move(update));
    }

    return events;
}

int FaceTrackRegistry::activeTrackCount() const {
    return static_cast<int>(tracks_.size());
}

}  // namespace guardvision
