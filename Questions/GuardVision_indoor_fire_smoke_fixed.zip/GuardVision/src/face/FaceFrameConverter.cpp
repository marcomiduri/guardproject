#include "face/FaceFrameConverter.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include <geometry/Geometry.h>

namespace guardvision {
namespace {

void setConversionError(FaceImageConversion& output, GuardVisionErrorCode code, const char* message) {
    output.ok = false;
    output.error.code = code;
    output.error.component = "FaceFrameConverter";
    output.error.message = message;
    output.error.recoverable = true;
}

Rect computeRoiRect(const VideoFrame& frame, const FaceConfig& config) {
    if (!config.useRoi) {
        return Rect{0, 0, frame.width, frame.height};
    }
    return clampRect(normalizedRectToPixels(config.roi, frame.size()), frame.size());
}

void copyGrayToBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::uint8_t value = source[y * srcStride + x];
            const std::size_t offset = static_cast<std::size_t>((y * width + x) * 3);
            dest[offset] = value;
            dest[offset + 1] = value;
            dest[offset + 2] = value;
        }
    }
}

void copyRgbToBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::size_t srcOffset = static_cast<std::size_t>(y * srcStride + x * 3);
            const std::size_t dstOffset = static_cast<std::size_t>((y * width + x) * 3);
            dest[dstOffset] = source[srcOffset + 2];
            dest[dstOffset + 1] = source[srcOffset + 1];
            dest[dstOffset + 2] = source[srcOffset];
        }
    }
}

void copyBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        std::memcpy(dest.data() + static_cast<std::size_t>(y * width * 3), source + static_cast<std::size_t>(y * srcStride),
                    static_cast<std::size_t>(width * 3));
    }
}

void copyBgraToBgr(const std::uint8_t* source, int width, int height, int srcStride, std::vector<std::uint8_t>& dest) {
    dest.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const std::size_t srcOffset = static_cast<std::size_t>(y * srcStride + x * 4);
            const std::size_t dstOffset = static_cast<std::size_t>((y * width + x) * 3);
            dest[dstOffset] = source[srcOffset];
            dest[dstOffset + 1] = source[srcOffset + 1];
            dest[dstOffset + 2] = source[srcOffset + 2];
        }
    }
}

void cropRectToBgr(const std::uint8_t* fullBgr, int fullWidth, const Rect& roi, std::vector<std::uint8_t>& dest, int& outWidth, int& outHeight) {
    outWidth = roi.width;
    outHeight = roi.height;
    dest.resize(static_cast<std::size_t>(roi.width * roi.height * 3));
    for (int y = 0; y < roi.height; ++y) {
        const int srcY = roi.y + y;
        const std::uint8_t* srcRow = fullBgr + static_cast<std::size_t>((srcY * fullWidth + roi.x) * 3);
        std::memcpy(dest.data() + static_cast<std::size_t>(y * roi.width * 3), srcRow, static_cast<std::size_t>(roi.width * 3));
    }
}

constexpr int kMaxFaceDetectDimension = 1280;
constexpr int kMinFaceDetectDimension = 8;

void downscaleConversionForDetection(FaceImageConversion& conversion) {
    if (conversion.width < kMinFaceDetectDimension || conversion.height < kMinFaceDetectDimension) {
        conversion.pixels.clear();
        conversion.width = 0;
        conversion.height = 0;
        conversion.stride = 0;
        return;
    }

    const int maxSide = std::max(conversion.width, conversion.height);
    if (maxSide <= kMaxFaceDetectDimension) {
        return;
    }

    const int newWidth =
      std::max(kMinFaceDetectDimension, static_cast<int>(std::lround(static_cast<double>(conversion.width) *
                                                                     static_cast<double>(kMaxFaceDetectDimension) / static_cast<double>(maxSide))));
    const int newHeight =
      std::max(kMinFaceDetectDimension, static_cast<int>(std::lround(static_cast<double>(conversion.height) *
                                                                     static_cast<double>(kMaxFaceDetectDimension) / static_cast<double>(maxSide))));

    std::vector<std::uint8_t> scaled(static_cast<std::size_t>(newWidth) * static_cast<std::size_t>(newHeight) * 3);
    for (int y = 0; y < newHeight; ++y) {
        const int srcY = (y * conversion.height) / newHeight;
        for (int x = 0; x < newWidth; ++x) {
            const int srcX = (x * conversion.width) / newWidth;
            const std::size_t srcOffset = static_cast<std::size_t>((srcY * conversion.width + srcX) * 3);
            const std::size_t dstOffset = static_cast<std::size_t>((y * newWidth + x) * 3);
            scaled[dstOffset] = conversion.pixels[srcOffset];
            scaled[dstOffset + 1] = conversion.pixels[srcOffset + 1];
            scaled[dstOffset + 2] = conversion.pixels[srcOffset + 2];
        }
    }

    conversion.pixels = std::move(scaled);
    conversion.width = newWidth;
    conversion.height = newHeight;
    conversion.stride = newWidth * 3;
}

}  // namespace

bool convertFrameForIdentify(const VideoFrame& frame, const FaceConfig& config, FaceImageConversion& output, FaceFrameConversionScratch& scratch) {
    output.ok = false;
    output.error = GuardVisionError{};
    output.width = 0;
    output.height = 0;
    output.stride = 0;
    output.boundsReferenceWidth = 0;
    output.boundsReferenceHeight = 0;
    output.roiFullFrame = Rect{};
    output.pixels.clear();
    scratch.fullFrameBgr.clear();
    if (!frame.buffer || frame.width <= 0 || frame.height <= 0) {
        setConversionError(output, GuardVisionErrorCode::InvalidFrame, "Face conversion requires a valid frame.");
        return false;
    }

    const Rect roi = computeRoiRect(frame, config);
    if (!roi.isValid()) {
        setConversionError(output, GuardVisionErrorCode::InvalidFaceConfiguration, "Face ROI is invalid.");
        return false;
    }

    std::vector<std::uint8_t>& convertedBgr = config.useRoi ? scratch.fullFrameBgr : output.pixels;
    const std::uint8_t* data = frame.buffer->data();
    switch (frame.pixelFormat) {
        case PixelFormat::Gray8:
            copyGrayToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::RGB24:
            copyRgbToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::BGR24:
            copyBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        case PixelFormat::BGRA32:
            copyBgraToBgr(data, frame.width, frame.height, frame.stride, convertedBgr);
            break;
        default:
            setConversionError(output, GuardVisionErrorCode::UnsupportedFacePixelFormat, "Face processing does not support this pixel format.");
            return false;
    }

    output.roiFullFrame = roi;
    if (config.useRoi) {
        cropRectToBgr(scratch.fullFrameBgr.data(), frame.width, roi, output.pixels, output.width, output.height);
    } else {
        output.width = frame.width;
        output.height = frame.height;
    }
    output.boundsReferenceWidth = output.roiFullFrame.width;
    output.boundsReferenceHeight = output.roiFullFrame.height;
    downscaleConversionForDetection(output);
    if (output.width <= 0 || output.height <= 0 || output.pixels.empty()) {
        setConversionError(output, GuardVisionErrorCode::InvalidFrame, "Face conversion produced an invalid downscaled frame.");
        return false;
    }
    output.stride = output.width * 3;
    output.ok = true;
    return true;
}

}  // namespace guardvision
