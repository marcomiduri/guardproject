#pragma once

#include <cstdint>
#include <vector>

#include <core/Error.h>
#include <face/FaceConfig.h>
#include <frame/VideoFrame.h>

namespace guardvision {

struct FaceFrameConversionScratch {
    std::vector<std::uint8_t> fullFrameBgr;
};

struct FaceImageConversion {
    bool ok = false;
    GuardVisionError error;
    int width = 0;
    int height = 0;
    int stride = 0;
    int boundsReferenceWidth = 0;
    int boundsReferenceHeight = 0;
    Rect roiFullFrame{};
    std::vector<std::uint8_t> pixels;
};

bool convertFrameForIdentify(const VideoFrame& frame, const FaceConfig& config, FaceImageConversion& output, FaceFrameConversionScratch& scratch);

inline bool convertFrameForIdentify(const VideoFrame& frame, const FaceConfig& config, FaceImageConversion& output) {
    FaceFrameConversionScratch scratch;
    return convertFrameForIdentify(frame, config, output, scratch);
}

}  // namespace guardvision
