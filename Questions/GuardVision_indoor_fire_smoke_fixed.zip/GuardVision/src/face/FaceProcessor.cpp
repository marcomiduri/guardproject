#include "face/FaceProcessor.h"

#include <chrono>
#include <cmath>
#include <mutex>
#include <unordered_map>
#include <vector>

#include <identify.h>

#include "face/FaceFrameConverter.h"
#include "face/IdentifyEngine.h"

#include "detail/AtomicUtil.h"
namespace guardvision {
namespace {

GuardVisionError makeVendorError(GuardVisionErrorCode code, const char* component, const char* message, HResult vendorCode,
                                 const std::string& streamId) {
    GuardVisionError error;
    error.code = code;
    error.component = component;
    error.message = message;
    error.streamId = streamId;
    error.recoverable = true;
    error.vendorErrorCode = static_cast<int>(vendorCode);
    return error;
}

Rect mapDetectionToFullFrame(const HFaceRect& rect, const FaceImageConversion& conversion) {
    const int detectWidth = conversion.width;
    const int detectHeight = conversion.height;
    const int referenceWidth = conversion.boundsReferenceWidth > 0 ? conversion.boundsReferenceWidth : detectWidth;
    const int referenceHeight = conversion.boundsReferenceHeight > 0 ? conversion.boundsReferenceHeight : detectHeight;
    if (detectWidth <= 0 || detectHeight <= 0 || referenceWidth <= 0 || referenceHeight <= 0) {
        return Rect{rect.x + conversion.roiFullFrame.x, rect.y + conversion.roiFullFrame.y, rect.width, rect.height};
    }

    const double scaleX = static_cast<double>(referenceWidth) / static_cast<double>(detectWidth);
    const double scaleY = static_cast<double>(referenceHeight) / static_cast<double>(detectHeight);
    return Rect{conversion.roiFullFrame.x + static_cast<int>(std::lround(rect.x * scaleX)),
                conversion.roiFullFrame.y + static_cast<int>(std::lround(rect.y * scaleY)),
                std::max(1, static_cast<int>(std::lround(rect.width * scaleX))), std::max(1, static_cast<int>(std::lround(rect.height * scaleY)))};
}

bool passesFilters(const Rect& bounds, double detectionConfidence, double qualityScore, const FaceConfig& config) {
    return bounds.width >= config.minimumFaceWidth && bounds.height >= config.minimumFaceHeight &&
           detectionConfidence >= config.minimumDetectionConfidence && qualityScore >= config.minimumQualityScore;
}

}  // namespace

bool FaceProcessor::ensureSession(void*& sessionHandle, const FaceConfig& config, FaceSessionSettingsCache& sessionSettings,
                                  GuardVisionError& error) const {
    if (!IdentifyEngine::instance().isInitialized()) {
        error = makeVendorError(GuardVisionErrorCode::FaceModelMissing, "FaceProcessor", "Identify engine is not initialized.",
                                static_cast<HResult>(-1), {});
        return false;
    }

    if (sessionHandle != nullptr && sessionSettings.valid &&
        (sessionSettings.processingLevel != config.processingLevel || sessionSettings.maximumFaceCount != config.maximumFaceCount)) {
        HFReleaseIdentifySession(static_cast<HFSession>(sessionHandle));
        sessionHandle = nullptr;
        sessionSettings.reset();
    }

    if (sessionHandle != nullptr) {
        applySessionSettings(sessionHandle, config, sessionSettings);
        return true;
    }

    HFSessionCustomParameter parameter{};
    parameter.enable_recognition = config.processingLevel == FaceProcessingLevel::DetectTrackAndIdentify ? HF_STATUS_ENABLE : HF_STATUS_DISABLE;
    parameter.enable_face_quality = HF_STATUS_ENABLE;

    HFSession session = nullptr;
    const HResult createResult = HFCreateIdentifySession(parameter, HF_DETECT_MODE_LIGHT_TRACK, config.maximumFaceCount, 320, -1, &session);
    if (createResult != HSUCCEED || session == nullptr) {
        error =
          makeVendorError(GuardVisionErrorCode::FaceSessionCreationFailed, "FaceProcessor", "HFCreateIdentifySession failed.", createResult, {});
        return false;
    }

    sessionHandle = session;
    sessionSettings.processingLevel = config.processingLevel;
    sessionSettings.maximumFaceCount = config.maximumFaceCount;
    applySessionSettings(sessionHandle, config, sessionSettings);
    return true;
}

void FaceProcessor::applySessionSettings(void* sessionHandle, const FaceConfig& config, FaceSessionSettingsCache& sessionSettings) const {
    const int minimumFacePixelSize = std::min(config.minimumFaceWidth, config.minimumFaceHeight);
    if (sessionSettings.valid && sessionSettings.minimumFacePixelSize == minimumFacePixelSize &&
        sessionSettings.detectionThreshold == config.minimumDetectionConfidence) {
        return;
    }

    HFSession session = static_cast<HFSession>(sessionHandle);
    HFSessionSetFilterMinimumFacePixelSize(session, minimumFacePixelSize);
    HFSessionSetFaceDetectThreshold(session, static_cast<HFloat>(config.minimumDetectionConfidence));

    // FeatureHub's threshold is process-global. Keep it configured once by
    // IdentifyEngine and apply the per-stream identification threshold to the
    // returned confidence below, avoiding cross-stream configuration races.
    sessionSettings.valid = true;
    sessionSettings.processingLevel = config.processingLevel;
    sessionSettings.maximumFaceCount = config.maximumFaceCount;
    sessionSettings.minimumFacePixelSize = minimumFacePixelSize;
    sessionSettings.detectionThreshold = config.minimumDetectionConfidence;
}

void FaceProcessor::destroySession(void*& sessionHandle, FaceSessionSettingsCache& sessionSettings) {
    if (sessionHandle == nullptr) {
        return;
    }
    std::lock_guard<std::recursive_mutex> identifyLock(IdentifyEngine::instance().apiMutex());
    HFReleaseIdentifySession(static_cast<HFSession>(sessionHandle));
    sessionHandle = nullptr;
    sessionSettings.reset();
}

FaceProcessResult FaceProcessor::processFrame(const VideoFrame& frame, const StreamToken& token, const FaceConfig& config, FaceTrackRegistry& tracks,
                                              FaceMetricsState& metrics, std::int64_t& lastAnalyzedTimestampMs, void*& sessionHandle,
                                              FaceSessionSettingsCache& sessionSettings, FaceProcessingScratch& scratch) {
    FaceProcessResult result;
    const auto start = std::chrono::steady_clock::now();

    if (lastAnalyzedTimestampMs >= 0 && config.analysisIntervalMs > 0 && frame.timestampMs - lastAnalyzedTimestampMs < config.analysisIntervalMs) {
        result.skippedByInterval = true;
        metrics.skippedByInterval.fetch_add(1);
        return result;
    }

    GuardVisionError sessionError;
    std::lock_guard<std::recursive_mutex> identifyLock(IdentifyEngine::instance().apiMutex());
    if (!ensureSession(sessionHandle, config, sessionSettings, sessionError)) {
        result.hadError = true;
        result.error = sessionError;
        result.error.streamId = token.streamId;
        metrics.processingErrors.fetch_add(1);
        destroySession(sessionHandle, sessionSettings);
        return result;
    }

    FaceImageConversion& conversion = scratch.conversion;
    if (!convertFrameForIdentify(frame, config, conversion, scratch.frameConversion)) {
        result.hadError = true;
        result.error = conversion.error;
        result.error.streamId = token.streamId;
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    HFImageData imageData{};
    imageData.data = conversion.pixels.data();
    imageData.width = conversion.width;
    imageData.height = conversion.height;
    imageData.format = HF_STREAM_BGR;
    imageData.rotation = HF_CAMERA_ROTATION_0;

    HFImageStream imageStream = nullptr;
    const HResult streamResult = HFCreateImageStream(&imageData, &imageStream);
    if (streamResult != HSUCCEED || imageStream == nullptr) {
        result.hadError = true;
        result.error =
          makeVendorError(GuardVisionErrorCode::FaceProcessingFailed, "FaceProcessor", "HFCreateImageStream failed.", streamResult, token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    HFMultipleFaceData faceData{};
    const HResult trackResult = HFExecuteFaceTrack(static_cast<HFSession>(sessionHandle), imageStream, &faceData);
    if (trackResult != HSUCCEED) {
        HFReleaseImageStream(imageStream);
        result.hadError = true;
        result.error =
          makeVendorError(GuardVisionErrorCode::FaceProcessingFailed, "FaceProcessor", "HFExecuteFaceTrack failed.", trackResult, token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    HFFaceQualityConfidence qualityData{};
    HFGetFaceQualityConfidence(static_cast<HFSession>(sessionHandle), &qualityData);

    std::unordered_map<int, FaceIdentityMatch> frameIdentities;
    if (config.processingLevel == FaceProcessingLevel::DetectTrackAndIdentify) {
        for (int index = 0; index < faceData.detectedNum; ++index) {
            const int vendorTrackId = faceData.trackIds[index];
            const HFaceRect rect = faceData.rects[index];
            const Rect fullBounds = mapDetectionToFullFrame(rect, conversion);
            const double detectionConfidence = faceData.detConfidence != nullptr ? static_cast<double>(faceData.detConfidence[index]) : 0.0;
            const double qualityScore = qualityData.confidence != nullptr ? static_cast<double>(qualityData.confidence[index]) : detectionConfidence;
            if (!passesFilters(fullBounds, detectionConfidence, qualityScore, config)) {
                continue;
            }

            if (const FaceIdentityMatch* cached = tracks.cachedIdentityForVendorTrack(vendorTrackId)) {
                frameIdentities.emplace(vendorTrackId, *cached);
                metrics.cachedIdentityUses.fetch_add(1);
                continue;
            }
            if (!tracks.shouldAttemptIdentification(vendorTrackId, config, frame.timestampMs)) {
                continue;
            }

            HFFaceFeature feature{};
            if (HFCreateFaceFeature(&feature) != HSUCCEED) {
                continue;
            }
            metrics.identificationAttempts.fetch_add(1);
            tracks.recordIdentificationAttempt(vendorTrackId, frame.timestampMs);
            const HResult extractResult = HFFaceFeatureExtract(static_cast<HFSession>(sessionHandle), imageStream, faceData.tokens[index], &feature);
            if (extractResult != HSUCCEED) {
                HFReleaseFaceFeature(&feature);
                metrics.identificationMisses.fetch_add(1);
                continue;
            }

            FaceIdentityMatch match;
            const Result searchResult = IdentifyEngine::instance().searchFaceFeature(feature, config.minimumIdentificationConfidence, match);
            HFReleaseFaceFeature(&feature);
            if (!searchResult.ok) {
                metrics.identificationMisses.fetch_add(1);
                continue;
            }

            frameIdentities.emplace(vendorTrackId, match);
            metrics.identificationMatches.fetch_add(1);
        }
    }

    std::vector<FaceTrack> detections;
    detections.reserve(static_cast<std::size_t>(faceData.detectedNum));
    for (int index = 0; index < faceData.detectedNum; ++index) {
        metrics.detectedFaces.fetch_add(1);
        const HFaceRect rect = faceData.rects[index];
        const Rect fullBounds = mapDetectionToFullFrame(rect, conversion);
        const double detectionConfidence = faceData.detConfidence != nullptr ? static_cast<double>(faceData.detConfidence[index]) : 0.0;
        const double qualityScore = qualityData.confidence != nullptr ? static_cast<double>(qualityData.confidence[index]) : detectionConfidence;
        if (!passesFilters(fullBounds, detectionConfidence, qualityScore, config)) {
            metrics.filteredFaces.fetch_add(1);
            continue;
        }

        FaceTrack track;
        track.trackId = static_cast<std::uint64_t>(faceData.trackIds[index]);
        track.bounds = fullBounds;
        track.detectionConfidence = detectionConfidence;
        track.qualityScore = qualityScore;
        track.state = FaceTrackState::Tracking;
        const auto identityIt = frameIdentities.find(faceData.trackIds[index]);
        if (identityIt != frameIdentities.end()) {
            track.identity = identityIt->second;
        } else if (const FaceIdentityMatch* cached = tracks.cachedIdentityForVendorTrack(faceData.trackIds[index])) {
            track.identity = *cached;
        }
        detections.push_back(track);
    }

    const std::int64_t nowMs = frame.timestampMs;
    result.events = tracks.updateDetections(detections, frameIdentities, config, token.streamId, token.generation, frame.sequence, frame.timestampMs,
                                            nowMs, &metrics);

    HFReleaseImageStream(imageStream);
    lastAnalyzedTimestampMs = frame.timestampMs;
    metrics.analyzedFrames.fetch_add(1);
    metrics.activeTrackCount = tracks.activeTrackCount();

    for (const FaceEvent& event : result.events) {
        switch (event.type) {
            case FaceEventType::TrackAppeared:
                metrics.appearedTracks.fetch_add(1);
                break;
            case FaceEventType::TrackLost:
                metrics.lostTracks.fetch_add(1);
                break;
            default:
                break;
        }
    }

    const auto end = std::chrono::steady_clock::now();
    result.processingTimeUs = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
    metrics.lastProcessingTimeUs = result.processingTimeUs;
    detail::updateAtomicMaximum(metrics.maximumProcessingTimeUs, result.processingTimeUs);
    return result;
}

}  // namespace guardvision
