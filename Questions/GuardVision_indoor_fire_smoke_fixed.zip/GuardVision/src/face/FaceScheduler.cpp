#include "face/FaceScheduler.h"

#include "scheduling/SchedulerConstants.h"

#include <algorithm>
#include <utility>

namespace guardvision {

FaceScheduler::FaceScheduler(EventCallback eventCallback, ErrorCallback errorCallback)
: eventCallback_(std::move(eventCallback)), errorCallback_(std::move(errorCallback)) {}

FaceScheduler::~FaceScheduler() {
    stop();
    join();
}

void FaceScheduler::start(int workerCount) {
    if (workersRunning_.exchange(true)) {
        return;
    }
    stopping_ = false;
    workerCount_ = std::max(1, workerCount);
    workers_.clear();
    workers_.reserve(static_cast<std::size_t>(workerCount_));
    workerThreads_.clear();
    for (int index = 0; index < workerCount_; ++index) {
        workers_.push_back(std::make_unique<WorkerState>());
        workerThreads_.emplace_back([this, index]() { workerLoop(index); });
    }
}

void FaceScheduler::stop(bool releaseNativeSessions) {
    for (const auto& worker : workers_) {
        {
            std::lock_guard<std::mutex> lock(worker->mutex);
            for (auto& entry : worker->slots) {
                const std::shared_ptr<WorkerStreamSlot>& slot = entry.second;
                if (!slot) {
                    continue;
                }
                slot->active = false;
                slot->pending.clear();
                slot->pendingConfirmations.clear();

                if (releaseNativeSessions) {
                    // Graceful shutdown releases each Identify session on its
                    // owning worker thread before the process-global engine is
                    // terminated.
                    slot->destroyRequested = true;
                    tryScheduleLocked(*worker, slot);
                } else {
                    // Process-exit shutdown must not enter unstable vendor
                    // release APIs. Cancel queued work and leave the opaque
                    // session for the operating system to reclaim after every
                    // GuardVision worker has joined.
                    slot->destroyRequested = false;
                    worker->readyStreams.remove(slot->token);
                    if (slot->inFlight && !slot->processing) {
                        slot->inFlight = false;
                    }
                }
            }
        }
        worker->cv.notify_all();
    }
    stopping_.store(true, std::memory_order_release);
    for (const auto& worker : workers_) {
        worker->cv.notify_all();
    }
}

void FaceScheduler::join() {
    for (std::thread& thread : workerThreads_) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    workerThreads_.clear();

    for (const auto& worker : workers_) {
        std::lock_guard<std::mutex> lock(worker->mutex);
        worker->slots.clear();
        worker->readyStreams.clear();
    }
    workers_.clear();
    workerCount_ = 0;
    workersRunning_ = false;
    stopping_ = false;
    std::lock_guard<std::mutex> affinityLock(affinityMutex_);
    streamWorkerAffinity_.clear();
}

int FaceScheduler::registerStream(const StreamToken& token, const FaceConfig& config, std::shared_ptr<FaceMetricsState> metrics) {
    if (!metrics || workerCount_ <= 0) {
        return -1;
    }

    int workerIndex = 0;
    std::size_t minimumLoad = static_cast<std::size_t>(-1);
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        for (int index = 0; index < workerCount_; ++index) {
            WorkerState& candidate = *workers_[static_cast<std::size_t>(index)];
            std::lock_guard<std::mutex> workerLock(candidate.mutex);
            const std::size_t load = candidate.slots.size() + candidate.readyStreams.size();
            if (load < minimumLoad) {
                minimumLoad = load;
                workerIndex = index;
            }
        }
        streamWorkerAffinity_[token.streamId] = workerIndex;
    }

    auto slot = std::make_shared<WorkerStreamSlot>();
    slot->token = token;
    slot->config = config;
    slot->active = config.processingLevel != FaceProcessingLevel::Disabled;
    slot->tracks = FaceTrackRegistry(config.maximumFaceCount);
    slot->lastAnalyzedTimestampMs = -1;
    slot->metrics = std::move(metrics);

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    {
        std::lock_guard<std::mutex> lock(worker.mutex);
        worker.slots[token.streamId] = slot;
    }

    slot->metrics->assignedWorkerIndex = workerIndex;
    slot->metrics->enabled = slot->active;
    slot->metrics->processingLevel = config.processingLevel;
    return workerIndex;
}

void FaceScheduler::unregisterStream(const StreamToken& token) {
    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(token.streamId);
        if (it != streamWorkerAffinity_.end()) {
            workerIndex = it->second;
            streamWorkerAffinity_.erase(it);
        }
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        return;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    std::shared_ptr<WorkerStreamSlot> slot;
    {
        std::unique_lock<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(token.streamId);
        if (it == worker.slots.end() || !it->second || it->second->token.generation != token.generation) {
            return;
        }
        slot = it->second;
        slot->active = false;
        slot->pending.clear();
        slot->pendingConfirmations.clear();
        worker.readyStreams.remove(token);
        if (slot->inFlight && !slot->processing) {
            slot->inFlight = false;
        }
        worker.cv.wait(lock, [&]() { return !slot->processing; });
        slot->destroyRequested = true;
        tryScheduleLocked(worker, slot);
        worker.cv.notify_one();
        worker.cv.wait(lock, [&]() { return !slot->processing && !slot->destroyRequested && slot->sessionHandle == nullptr; });
        const auto current = worker.slots.find(token.streamId);
        if (current != worker.slots.end() && current->second == slot) {
            worker.slots.erase(current);
        }
    }

    if (slot->metrics) {
        slot->metrics->enabled = false;
        slot->metrics->activeTrackCount = 0;
        slot->metrics->assignedWorkerIndex = -1;
    }
}

void FaceScheduler::updateStreamConfig(const StreamToken& token, const FaceConfig& config) {
    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(token.streamId);
        if (it == streamWorkerAffinity_.end()) {
            return;
        }
        workerIndex = it->second;
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        return;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    std::shared_ptr<WorkerStreamSlot> slot;
    {
        std::unique_lock<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(token.streamId);
        if (it == worker.slots.end() || !it->second || it->second->token.generation != token.generation) {
            return;
        }
        slot = it->second;
        const bool requiresSessionRebuild =
          slot->sessionHandle != nullptr &&
          (slot->config.processingLevel != config.processingLevel || slot->config.maximumFaceCount != config.maximumFaceCount);
        slot->active = false;
        slot->pending.clear();
        slot->pendingConfirmations.clear();
        worker.readyStreams.remove(token);
        if (slot->inFlight && !slot->processing) {
            slot->inFlight = false;
        }
        worker.cv.wait(lock, [&]() { return !slot->processing; });

        // Most camera-settings edits (ROI, confidence, interval, quality and
        // detection thresholds) do not require rebuilding the native Identify
        // session. Releasing that session is a known unstable vendor teardown
        // path, especially after a backend registry has enabled FeatureHub.
        // Keep the session on its owning worker and let FaceProcessor apply the
        // non-structural settings on the next frame.
        if (requiresSessionRebuild) {
            slot->destroyRequested = true;
            tryScheduleLocked(worker, slot);
            worker.cv.notify_one();
            worker.cv.wait(lock, [&]() { return !slot->processing && !slot->destroyRequested && slot->sessionHandle == nullptr; });
        }
        slot->config = config;
        slot->tracks.reset();
        slot->lastAnalyzedTimestampMs = -1;
        slot->active = config.processingLevel != FaceProcessingLevel::Disabled;
    }

    if (slot->metrics) {
        slot->metrics->enabled = slot->active;
        slot->metrics->processingLevel = config.processingLevel;
        slot->metrics->activeTrackCount = 0;
    }
}

FaceOfferResult FaceScheduler::offerFrame(FaceRoutingJob job) {
    FaceOfferResult result;
    if (job.config.processingLevel == FaceProcessingLevel::Disabled) {
        return result;
    }

    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(job.token.streamId);
        if (it == streamWorkerAffinity_.end()) {
            return result;
        }
        workerIndex = it->second;
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        return result;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    {
        std::lock_guard<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(job.token.streamId);
        if (it == worker.slots.end() || !it->second) {
            return result;
        }
        const std::shared_ptr<WorkerStreamSlot>& slot = it->second;
        if (slot->metrics) {
            slot->metrics->receivedFrames.fetch_add(1);
        }
        if (!slot->active || slot->token.generation != job.token.generation) {
            if (slot->metrics) {
                slot->metrics->staleWorkDiscarded.fetch_add(1);
            }
            return result;
        }

        slot->config = job.config;
        FrameRoutingJob routingJob{job.token, job.frame, job.submittedAtMs};
        const ReplaceResult replaceResult = slot->pending.replace(std::move(routingJob));
        result.replacedPending = replaceResult == ReplaceResult::ReplacedPending;
        result.accepted = true;
        if (result.replacedPending && slot->metrics) {
            slot->metrics->replacedPendingFrames.fetch_add(1);
        }

        if (!slot->inFlight) {
            if (tryScheduleLocked(worker, slot)) {
                if (slot->metrics) {
                    slot->metrics->scheduledFrames.fetch_add(1);
                }
            } else {
                slot->pending.clear();
                result.accepted = false;
                result.queueUnavailable = true;
                if (slot->metrics) {
                    slot->metrics->processingErrors.fetch_add(1);
                }
            }
        }
    }
    worker.cv.notify_one();
    return result;
}

FaceConfirmationOfferResult FaceScheduler::offerRegionalConfirmation(FaceRegionalConfirmationRequest request) {
    FaceConfirmationOfferResult result;
    int workerIndex = -1;
    {
        std::lock_guard<std::mutex> affinityLock(affinityMutex_);
        const auto it = streamWorkerAffinity_.find(request.token.streamId);
        if (it == streamWorkerAffinity_.end()) {
            result.stale = true;
            return result;
        }
        workerIndex = it->second;
    }
    if (!scheduling::isValidWorkerIndex(workerIndex, workerCount_)) {
        result.stale = true;
        return result;
    }

    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    {
        std::lock_guard<std::mutex> lock(worker.mutex);
        const auto it = worker.slots.find(request.token.streamId);
        if (it == worker.slots.end() || !it->second || it->second->token.generation != request.token.generation || !it->second->active) {
            result.stale = true;
            if (it != worker.slots.end() && it->second && it->second->metrics) {
                it->second->metrics->staleWorkDiscarded.fetch_add(1);
            }
            return result;
        }
        const std::shared_ptr<WorkerStreamSlot>& slot = it->second;
        if (slot->metrics) {
            slot->metrics->receivedFrames.fetch_add(1);
        }
        if (slot->pendingConfirmations.size() >= scheduling::kMaxPendingRegionalConfirmationsPerStream) {
            result.queueFull = true;
            if (slot->metrics) {
                slot->metrics->processingErrors.fetch_add(1);
            }
            return result;
        }
        slot->pendingConfirmations.push_back(std::move(request));
        bool newlyScheduled = false;
        if (!slot->inFlight) {
            newlyScheduled = tryScheduleLocked(worker, slot);
            if (!newlyScheduled) {
                slot->pendingConfirmations.pop_back();
                result.queueFull = true;
                if (slot->metrics) {
                    slot->metrics->processingErrors.fetch_add(1);
                }
                return result;
            }
        }
        if (newlyScheduled && slot->metrics) {
            slot->metrics->scheduledFrames.fetch_add(1);
        }
        result.accepted = true;
    }
    worker.cv.notify_one();
    return result;
}

void FaceScheduler::setConfirmationCallback(ConfirmationCallback callback) {
    confirmationCallback_ = std::move(callback);
}

void FaceScheduler::setActiveTokenValidator(ActiveTokenValidator validator) {
    activeTokenValidator_ = std::move(validator);
}

bool FaceScheduler::tryScheduleLocked(WorkerState& worker, const std::shared_ptr<WorkerStreamSlot>& slot) {
    if (!slot || slot->inFlight || (!slot->destroyRequested && !slot->pending.hasPending() && slot->pendingConfirmations.empty())) {
        return false;
    }
    if (!worker.readyStreams.tryEnqueue(slot->token)) {
        return false;
    }
    slot->inFlight = true;
    slot->processing = false;
    return true;
}

std::optional<FaceScheduler::WorkerWorkItem> FaceScheduler::takeWorkForStreamLocked(WorkerState& worker,
                                                                                    const std::shared_ptr<WorkerStreamSlot>& slot) {
    if (!slot) {
        return std::nullopt;
    }
    if (slot->destroyRequested) {
        WorkerWorkItem item;
        item.type = WorkerWorkItem::Type::DestroySession;
        return item;
    }
    if (slot->pending.hasPending()) {
        const std::optional<FrameRoutingJob> routingJob = slot->pending.take();
        if (routingJob.has_value()) {
            WorkerWorkItem item;
            item.type = WorkerWorkItem::Type::Frame;
            item.frameJob.token = routingJob->token;
            item.frameJob.frame = std::move(routingJob->frame);
            item.frameJob.submittedAtMs = routingJob->submittedAtMs;
            item.frameJob.config = slot->config;
            return item;
        }
    }
    if (!slot->pendingConfirmations.empty()) {
        WorkerWorkItem item;
        item.type = WorkerWorkItem::Type::Confirmation;
        item.confirmationRequest = std::move(slot->pendingConfirmations.front());
        slot->pendingConfirmations.pop_front();
        return item;
    }
    slot->inFlight = false;
    slot->processing = false;
    worker.readyStreams.remove(slot->token);
    return std::nullopt;
}

void FaceScheduler::processSlot(WorkerStreamSlot& slot, FaceRoutingJob job, FaceMetricsState& metrics) {
    if ((activeTokenValidator_ && !activeTokenValidator_(job.token)) || slot.token.generation != job.token.generation) {
        metrics.staleWorkDiscarded.fetch_add(1);
        return;
    }

    FaceProcessResult processResult = processor_.processFrame(job.frame, job.token, job.config, slot.tracks, metrics, slot.lastAnalyzedTimestampMs,
                                                              slot.sessionHandle, slot.sessionSettings, slot.processingScratch);
    if (processResult.hadError && errorCallback_) {
        errorCallback_(processResult.error);
    }
    if (activeTokenValidator_ && !activeTokenValidator_(job.token)) {
        metrics.staleWorkDiscarded.fetch_add(1);
        return;
    }
    if (!processResult.events.empty() && eventCallback_) {
        eventCallback_(std::move(processResult.events));
    }
}

void FaceScheduler::processConfirmation(WorkerStreamSlot& slot, FaceRegionalConfirmationRequest request, FaceMetricsState& metrics) {
    FaceRegionalConfirmationResult result;
    result.token = request.token;
    result.candidateType = request.candidateType;
    result.candidateTimestampMs = request.candidateTimestampMs;
    result.originalCandidateRegion = request.originalCandidateRegion;
    result.mappedCandidateRegion = request.mappedCandidateRegion;
    result.expandedAnalysisRegion = request.expandedAnalysisRegion;
    result.onboardConfidence = request.onboardConfidence;
    result.targetId = request.targetId;
    result.onboardMetrics = std::move(request.onboardMetrics);

    if (slot.token.generation != request.token.generation || (activeTokenValidator_ && !activeTokenValidator_(request.token))) {
        result.stale = true;
        metrics.staleWorkDiscarded.fetch_add(1);
        if (confirmationCallback_) {
            confirmationCallback_(std::move(result));
        }
        return;
    }

    FaceTrackRegistry confirmationTracks(request.config.maximumFaceCount);
    std::int64_t lastAnalyzedTimestampMs = -1;
    FaceProcessResult processResult =
      processor_.processFrame(request.matchedFrame, request.token, request.config, confirmationTracks, metrics, lastAnalyzedTimestampMs,
                              slot.sessionHandle, slot.sessionSettings, slot.processingScratch);
    if (processResult.hadError) {
        result.hadError = true;
        result.error = processResult.error;
        if (errorCallback_) {
            errorCallback_(processResult.error);
        }
    }
    if (activeTokenValidator_ && !activeTokenValidator_(request.token)) {
        result.stale = true;
        result.confirmed = false;
        metrics.staleWorkDiscarded.fetch_add(1);
        if (confirmationCallback_) {
            confirmationCallback_(std::move(result));
        }
        return;
    }
    for (const FaceEvent& event : processResult.events) {
        for (const FaceTrack& track : event.tracks) {
            if (track.bounds.isValid()) {
                result.confirmedRegions.push_back(track.bounds);
                result.softwareConfidence = std::max(result.softwareConfidence, track.detectionConfidence);
                result.softwareTrackId = track.trackId;
            }
        }
    }
    result.confirmed = !result.confirmedRegions.empty();
    if (confirmationCallback_) {
        confirmationCallback_(std::move(result));
    }
}

void FaceScheduler::workerLoop(int workerIndex) {
    WorkerState& worker = *workers_[static_cast<std::size_t>(workerIndex)];
    while (true) {
        StreamToken token;
        std::shared_ptr<WorkerStreamSlot> slot;
        std::optional<WorkerWorkItem> work;
        {
            std::unique_lock<std::mutex> lock(worker.mutex);
            worker.cv.wait(lock, [&]() { return stopping_.load() || !worker.readyStreams.empty(); });
            if (stopping_.load() && worker.readyStreams.empty()) {
                break;
            }
            if (!worker.readyStreams.dequeue(token)) {
                continue;
            }
            const auto it = worker.slots.find(token.streamId);
            if (it == worker.slots.end() || !it->second || it->second->token.generation != token.generation) {
                continue;
            }
            slot = it->second;
            work = takeWorkForStreamLocked(worker, slot);
            if (!work.has_value()) {
                worker.cv.notify_all();
                continue;
            }
            slot->processing = true;
        }

        if (work->type == WorkerWorkItem::Type::DestroySession) {
            processor_.destroySession(slot->sessionHandle, slot->sessionSettings);
        } else if (slot->metrics) {
            if (work->type == WorkerWorkItem::Type::Frame) {
                processSlot(*slot, std::move(work->frameJob), *slot->metrics);
            } else {
                processConfirmation(*slot, std::move(work->confirmationRequest), *slot->metrics);
            }
        }

        bool scheduled = false;
        {
            std::lock_guard<std::mutex> lock(worker.mutex);
            if (work->type == WorkerWorkItem::Type::DestroySession) {
                slot->destroyRequested = false;
            }
            slot->processing = false;
            slot->inFlight = false;
            const auto it = worker.slots.find(token.streamId);
            if (it != worker.slots.end() && it->second == slot &&
                (slot->destroyRequested || (slot->active && !stopping_.load(std::memory_order_acquire)))) {
                scheduled = tryScheduleLocked(worker, slot);
            }
        }
        worker.cv.notify_all();
        if (scheduled) {
            if (slot->metrics) {
                slot->metrics->scheduledFrames.fetch_add(1);
            }
            worker.cv.notify_one();
        }
    }
}

}  // namespace guardvision
