#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <unordered_map>

#include <face/FaceRegistry.h>
#include <face/FaceTypes.h>
#include <core/Result.h>

struct HFFaceFeature;

namespace guardvision {

class IdentifyEngine {
public:
    static IdentifyEngine& instance();

    Result initialize(const std::string& resourcePathOverride);
    void shutdown();
    bool isInitialized() const noexcept;
    std::string resourcePath() const;
    Result setFaceRegistry(const FaceRegistry& registry);
    Result searchFaceFeature(const HFFaceFeature& feature, double minimumConfidence, FaceIdentityMatch& match);
    std::recursive_mutex& apiMutex() noexcept {
        return apiMutex_;
    }

private:
    IdentifyEngine() = default;
    Result enableFeatureHub(float threshold);

    mutable std::recursive_mutex apiMutex_;
    std::atomic<bool> initialized_{false};
    bool featureHubEnabled_ = false;
    std::string resourcePath_;
    FaceRegistry registry_;
    std::unordered_map<std::uint64_t, std::string> displayNameById_;
};

std::string discoverIdentifyResourcePath(const std::string& overridePath);

}  // namespace guardvision
