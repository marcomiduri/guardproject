#include "face/IdentifyEngine.h"

namespace guardvision {

IdentifyEngine& IdentifyEngine::instance() {
    static IdentifyEngine engine;
    return engine;
}

std::string discoverIdentifyResourcePath(const std::string&) {
    return {};
}

Result IdentifyEngine::initialize(const std::string&) {
    return Result::failure(GuardVisionErrorCode::FaceEngineInitializationFailed, "GuardVision was built without face support.", "IdentifyEngine");
}

Result IdentifyEngine::enableFeatureHub(float) {
    return Result::failure(GuardVisionErrorCode::FaceEngineInitializationFailed, "GuardVision was built without face support.", "IdentifyEngine");
}

Result IdentifyEngine::setFaceRegistry(const FaceRegistry&) {
    return Result::failure(GuardVisionErrorCode::FaceEngineInitializationFailed, "GuardVision was built without face support.", "IdentifyEngine");
}

Result IdentifyEngine::searchFaceFeature(const HFFaceFeature&, double, FaceIdentityMatch&) {
    return Result::failure(GuardVisionErrorCode::FaceEngineInitializationFailed, "GuardVision was built without face support.", "IdentifyEngine");
}

void IdentifyEngine::shutdown() {
    std::lock_guard<std::recursive_mutex> lock(apiMutex_);
    initialized_.store(false, std::memory_order_release);
    featureHubEnabled_ = false;
    resourcePath_.clear();
    registry_ = FaceRegistry{};
    displayNameById_.clear();
}

bool IdentifyEngine::isInitialized() const noexcept {
    return false;
}

std::string IdentifyEngine::resourcePath() const {
    return {};
}

}  // namespace guardvision
