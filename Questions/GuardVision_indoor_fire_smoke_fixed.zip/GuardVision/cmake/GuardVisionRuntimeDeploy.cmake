# Runtime deployment helper for executables that link the GuardVision static
# library. The library itself has no runtime directory, so DLLs are copied next
# to the consumer/test/example executable instead of next to guardvision.lib.

set(GUARDVISION_IDENTIFY_RUNTIME_DIR "" CACHE PATH
    "Directory containing Identify runtime DLLs for all configurations")
set(GUARDVISION_IDENTIFY_RUNTIME_DIR_DEBUG "" CACHE PATH
    "Directory containing Identify Debug runtime DLLs")
set(GUARDVISION_IDENTIFY_RUNTIME_DIR_RELEASE "" CACHE PATH
    "Directory containing Identify Release runtime DLLs")
set(GUARDVISION_HAZARDDETECT_RUNTIME_DIR "" CACHE PATH
    "Directory containing HazardDetect runtime DLLs for all configurations")
set(GUARDVISION_HAZARDDETECT_RUNTIME_DIR_DEBUG "" CACHE PATH
    "Directory containing HazardDetect Debug runtime DLLs")
set(GUARDVISION_HAZARDDETECT_RUNTIME_DIR_RELEASE "" CACHE PATH
    "Directory containing HazardDetect Release runtime DLLs")
set(GUARDVISION_OPENCV_RUNTIME_DIR "" CACHE PATH
    "Directory containing OpenCV runtime DLLs for all configurations")
set(GUARDVISION_OPENCV_RUNTIME_DIR_DEBUG "" CACHE PATH
    "Directory containing OpenCV Debug runtime DLLs")
set(GUARDVISION_OPENCV_RUNTIME_DIR_RELEASE "" CACHE PATH
    "Directory containing OpenCV Release runtime DLLs")

function(_guardvision_runtime_source out_var generic_dir debug_dir release_dir)
    if(generic_dir AND EXISTS "${generic_dir}")
        if(NOT debug_dir AND NOT release_dir)
            set(${out_var} "${generic_dir}" PARENT_SCOPE)
            return()
        endif()
    endif()

    if(debug_dir AND EXISTS "${debug_dir}" AND release_dir AND EXISTS "${release_dir}")
        set(${out_var} "$<IF:$<CONFIG:Debug>,${debug_dir},${release_dir}>" PARENT_SCOPE)
        return()
    endif()

    if(release_dir AND EXISTS "${release_dir}")
        set(${out_var} "${release_dir}" PARENT_SCOPE)
        return()
    endif()

    if(debug_dir AND EXISTS "${debug_dir}")
        set(${out_var} "${debug_dir}" PARENT_SCOPE)
        return()
    endif()

    set(${out_var} "" PARENT_SCOPE)
endfunction()

function(_guardvision_copy_runtime_directory target_name source_dir label)
    if(NOT source_dir)
        return()
    endif()

    add_custom_command(TARGET ${target_name} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E echo
            "GuardVision: deploying ${label} runtime to $<TARGET_FILE_DIR:${target_name}>"
        COMMAND ${CMAKE_COMMAND} -E copy_directory
            "${source_dir}"
            "$<TARGET_FILE_DIR:${target_name}>"
        VERBATIM)
endfunction()

function(guardvision_deploy_runtime target_name)
    if(NOT WIN32 OR NOT TARGET ${target_name})
        return()
    endif()

    set(_guardvision_face_enabled TRUE)
    set(_guardvision_hazard_enabled TRUE)
    if(DEFINED GuardVision_FACE_ENABLED)
        set(_guardvision_face_enabled ${GuardVision_FACE_ENABLED})
    elseif(DEFINED GUARDVISION_ENABLE_FACE)
        set(_guardvision_face_enabled ${GUARDVISION_ENABLE_FACE})
    endif()
    if(DEFINED GuardVision_HAZARD_ENABLED)
        set(_guardvision_hazard_enabled ${GuardVision_HAZARD_ENABLED})
    elseif(DEFINED GUARDVISION_ENABLE_HAZARD)
        set(_guardvision_hazard_enabled ${GUARDVISION_ENABLE_HAZARD})
    endif()

    if(_guardvision_face_enabled)
        _guardvision_runtime_source(_identify_runtime
            "${GUARDVISION_IDENTIFY_RUNTIME_DIR}"
            "${GUARDVISION_IDENTIFY_RUNTIME_DIR_DEBUG}"
            "${GUARDVISION_IDENTIFY_RUNTIME_DIR_RELEASE}")
        _guardvision_copy_runtime_directory(${target_name} "${_identify_runtime}" "Identify")
    endif()

    if(_guardvision_hazard_enabled)
        _guardvision_runtime_source(_hazard_runtime
            "${GUARDVISION_HAZARDDETECT_RUNTIME_DIR}"
            "${GUARDVISION_HAZARDDETECT_RUNTIME_DIR_DEBUG}"
            "${GUARDVISION_HAZARDDETECT_RUNTIME_DIR_RELEASE}")
        _guardvision_copy_runtime_directory(${target_name} "${_hazard_runtime}" "HazardDetect")

        _guardvision_runtime_source(_opencv_runtime
            "${GUARDVISION_OPENCV_RUNTIME_DIR}"
            "${GUARDVISION_OPENCV_RUNTIME_DIR_DEBUG}"
            "${GUARDVISION_OPENCV_RUNTIME_DIR_RELEASE}")
        _guardvision_copy_runtime_directory(${target_name} "${_opencv_runtime}" "OpenCV")
    endif()
endfunction()

# Compatibility wrapper retained for older project files. Runtime deployment is
# meaningful only for executable targets, so this now delegates to the public
# helper rather than attaching DLL copying to the static library target.
function(guardvision_configure_runtime_deploy target_name)
    guardvision_deploy_runtime(${target_name})
endfunction()
