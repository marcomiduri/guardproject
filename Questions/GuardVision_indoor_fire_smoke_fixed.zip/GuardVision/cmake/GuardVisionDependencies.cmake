# GuardVision proprietary SDK discovery.
#
# Face and hazard support are independently optional. A motion-only build does
# not search for or link either proprietary SDK. When a feature is enabled, the
# requested SDK is mandatory and a missing dependency fails configuration with
# a clear diagnostic.

if(DEFINED GUARDVISION_PACKAGE_ROOT)
    set(_guardvision_default_identify_root "${GUARDVISION_PACKAGE_ROOT}/sdk/Identify")
    set(_guardvision_default_hazard_root "${GUARDVISION_PACKAGE_ROOT}/sdk/HazardDetect")
else()
    set(_guardvision_default_identify_root "${CMAKE_CURRENT_SOURCE_DIR}/../sdk/Identify")
    set(_guardvision_default_hazard_root "${CMAKE_CURRENT_SOURCE_DIR}/../sdk/HazardDetect")
endif()

set(GUARDVISION_IDENTIFY_ROOT "${_guardvision_default_identify_root}" CACHE PATH
    "Root directory of the Identify SDK")
set(GUARDVISION_HAZARDDETECT_ROOT "${_guardvision_default_hazard_root}" CACHE PATH
    "Root directory of the HazardDetect SDK")

set(GUARDVISION_IDENTIFY_INCLUDE_DIR "" CACHE PATH "Directory containing identify.h")
set(GUARDVISION_IDENTIFY_LIBRARY "" CACHE FILEPATH "Identify SDK library used for all configurations")
set(GUARDVISION_IDENTIFY_LIBRARY_DEBUG "" CACHE FILEPATH "Identify SDK Debug library")
set(GUARDVISION_IDENTIFY_LIBRARY_RELEASE "" CACHE FILEPATH "Identify SDK Release library")
set(GUARDVISION_HAZARDDETECT_INCLUDE_DIR "" CACHE PATH "Directory containing hazard_detect.h")
set(GUARDVISION_HAZARDDETECT_LIBRARY "" CACHE FILEPATH "HazardDetect SDK library used for all configurations")
set(GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG "" CACHE FILEPATH "HazardDetect SDK Debug library")
set(GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE "" CACHE FILEPATH "HazardDetect SDK Release library")

function(_guardvision_find_library_for_config out_var root_dir config_kind)
    if(config_kind STREQUAL "DEBUG")
        set(_suffixes
            debug Debug
            lib-debug lib/Debug lib/debug
            bin-debug bin/Debug bin/debug
            lib lib/x64 bin)
    else()
        set(_suffixes
            release Release
            lib-release lib/Release lib/release
            bin-release bin/Release bin/release
            lib lib/x64 bin)
    endif()

    find_library(_found_library
        NAMES ${ARGN}
        PATHS "${root_dir}"
        PATH_SUFFIXES ${_suffixes}
        NO_DEFAULT_PATH)
    set(${out_var} "${_found_library}" PARENT_SCOPE)
    unset(_found_library CACHE)
endfunction()

function(_guardvision_configure_imported_target target_name include_dir generic_lib debug_lib release_lib)
    if(TARGET ${target_name})
        return()
    endif()

    add_library(${target_name} UNKNOWN IMPORTED GLOBAL)
    set_target_properties(${target_name} PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${include_dir}")

    if(debug_lib AND release_lib)
        set_target_properties(${target_name} PROPERTIES
            IMPORTED_CONFIGURATIONS "DEBUG;RELEASE;RELWITHDEBINFO;MINSIZEREL"
            IMPORTED_LOCATION_DEBUG "${debug_lib}"
            IMPORTED_LOCATION_RELEASE "${release_lib}"
            IMPORTED_LOCATION_RELWITHDEBINFO "${release_lib}"
            IMPORTED_LOCATION_MINSIZEREL "${release_lib}")
    elseif(generic_lib)
        set_target_properties(${target_name} PROPERTIES IMPORTED_LOCATION "${generic_lib}")
    elseif(release_lib)
        set_target_properties(${target_name} PROPERTIES IMPORTED_LOCATION "${release_lib}")
    elseif(debug_lib)
        set_target_properties(${target_name} PROPERTIES IMPORTED_LOCATION "${debug_lib}")
    endif()
endfunction()

function(_guardvision_define_identify_target)
    if(TARGET GuardVision::Identify)
        return()
    endif()

    if(NOT GUARDVISION_IDENTIFY_INCLUDE_DIR)
        find_path(_guardvision_identify_include_candidate
            NAMES identify.h
            PATHS "${GUARDVISION_IDENTIFY_ROOT}"
            PATH_SUFFIXES include Include
            NO_DEFAULT_PATH)
        if(_guardvision_identify_include_candidate)
            set(GUARDVISION_IDENTIFY_INCLUDE_DIR "${_guardvision_identify_include_candidate}" CACHE PATH "Directory containing identify.h" FORCE)
        endif()
        unset(_guardvision_identify_include_candidate CACHE)
    endif()

    if(NOT GUARDVISION_IDENTIFY_LIBRARY_DEBUG)
        _guardvision_find_library_for_config(
            GUARDVISION_IDENTIFY_LIBRARY_DEBUG "${GUARDVISION_IDENTIFY_ROOT}" DEBUG identify Identify)
    endif()
    if(NOT GUARDVISION_IDENTIFY_LIBRARY_RELEASE)
        _guardvision_find_library_for_config(
            GUARDVISION_IDENTIFY_LIBRARY_RELEASE "${GUARDVISION_IDENTIFY_ROOT}" RELEASE identify Identify)
    endif()
    if(NOT GUARDVISION_IDENTIFY_LIBRARY)
        if(GUARDVISION_IDENTIFY_LIBRARY_RELEASE)
            set(GUARDVISION_IDENTIFY_LIBRARY "${GUARDVISION_IDENTIFY_LIBRARY_RELEASE}" CACHE FILEPATH "" FORCE)
        elseif(GUARDVISION_IDENTIFY_LIBRARY_DEBUG)
            set(GUARDVISION_IDENTIFY_LIBRARY "${GUARDVISION_IDENTIFY_LIBRARY_DEBUG}" CACHE FILEPATH "" FORCE)
        endif()
    endif()

    if(NOT GUARDVISION_IDENTIFY_INCLUDE_DIR OR
       (NOT GUARDVISION_IDENTIFY_LIBRARY AND NOT GUARDVISION_IDENTIFY_LIBRARY_DEBUG AND NOT GUARDVISION_IDENTIFY_LIBRARY_RELEASE))
        message(FATAL_ERROR
            "GuardVision face support is enabled, but the Identify SDK was not found. "
            "Copy it into Desktop/sdk/Identify, set GUARDVISION_IDENTIFY_ROOT/library variables, "
            "or configure with -DGUARDVISION_ENABLE_FACE=OFF for a motion/hazard-only build.")
    endif()

    _guardvision_configure_imported_target(
        GuardVision::Identify
        "${GUARDVISION_IDENTIFY_INCLUDE_DIR}"
        "${GUARDVISION_IDENTIFY_LIBRARY}"
        "${GUARDVISION_IDENTIFY_LIBRARY_DEBUG}"
        "${GUARDVISION_IDENTIFY_LIBRARY_RELEASE}")
endfunction()

function(_guardvision_define_hazard_target)
    if(TARGET GuardVision::HazardDetect)
        return()
    endif()

    if(NOT GUARDVISION_HAZARDDETECT_INCLUDE_DIR)
        find_path(_guardvision_hazard_include_candidate
            NAMES hazard_detect.h
            PATHS "${GUARDVISION_HAZARDDETECT_ROOT}"
            PATH_SUFFIXES include Include
            NO_DEFAULT_PATH)
        if(_guardvision_hazard_include_candidate)
            set(GUARDVISION_HAZARDDETECT_INCLUDE_DIR "${_guardvision_hazard_include_candidate}" CACHE PATH "Directory containing hazard_detect.h" FORCE)
        endif()
        unset(_guardvision_hazard_include_candidate CACHE)
    endif()

    if(NOT GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG)
        _guardvision_find_library_for_config(
            GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG "${GUARDVISION_HAZARDDETECT_ROOT}" DEBUG hazard_detect HazardDetect hazarddetect)
    endif()
    if(NOT GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE)
        _guardvision_find_library_for_config(
            GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE "${GUARDVISION_HAZARDDETECT_ROOT}" RELEASE hazard_detect HazardDetect hazarddetect)
    endif()
    if(NOT GUARDVISION_HAZARDDETECT_LIBRARY)
        if(GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE)
            set(GUARDVISION_HAZARDDETECT_LIBRARY "${GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE}" CACHE FILEPATH "" FORCE)
        elseif(GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG)
            set(GUARDVISION_HAZARDDETECT_LIBRARY "${GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG}" CACHE FILEPATH "" FORCE)
        endif()
    endif()

    if(NOT GUARDVISION_HAZARDDETECT_INCLUDE_DIR OR
       (NOT GUARDVISION_HAZARDDETECT_LIBRARY AND NOT GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG AND NOT GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE))
        message(FATAL_ERROR
            "GuardVision hazard support is enabled, but the HazardDetect SDK was not found. "
            "Copy it into Desktop/sdk/HazardDetect, set GUARDVISION_HAZARDDETECT_ROOT/library variables, "
            "or configure with -DGUARDVISION_ENABLE_HAZARD=OFF for a motion/face-only build.")
    endif()

    _guardvision_configure_imported_target(
        GuardVision::HazardDetect
        "${GUARDVISION_HAZARDDETECT_INCLUDE_DIR}"
        "${GUARDVISION_HAZARDDETECT_LIBRARY}"
        "${GUARDVISION_HAZARDDETECT_LIBRARY_DEBUG}"
        "${GUARDVISION_HAZARDDETECT_LIBRARY_RELEASE}")
endfunction()

function(guardvision_define_dependency_targets enable_face enable_hazard)
    if(enable_face)
        _guardvision_define_identify_target()
    endif()
    if(enable_hazard)
        _guardvision_define_hazard_target()
    endif()
endfunction()

function(guardvision_configure_dependencies target_name enable_face enable_hazard)
    guardvision_define_dependency_targets(${enable_face} ${enable_hazard})

    if(enable_face)
        target_compile_definitions(${target_name} PRIVATE GUARDVISION_HAVE_FACE=1)
        target_link_libraries(${target_name} PRIVATE GuardVision::Identify)
    endif()

    if(enable_hazard)
        target_compile_definitions(${target_name} PRIVATE GUARDVISION_HAVE_HAZARD=1)
        target_link_libraries(${target_name} PRIVATE GuardVision::HazardDetect)
    endif()
endfunction()
