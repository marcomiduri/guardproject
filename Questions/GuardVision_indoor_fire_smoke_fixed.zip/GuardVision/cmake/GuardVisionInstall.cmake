function(guardvision_install_target target_name)
    include(CMakePackageConfigHelpers)

    set(_guardvision_package_dir "${CMAKE_INSTALL_LIBDIR}/cmake/GuardVision")

    # Keep Debug and non-Debug artifacts separate so installing multiple
    # configurations into one SDK prefix never overwrites guardvision.lib.
    set(_guardvision_binary_config "$<IF:$<CONFIG:Debug>,Debug,Release>")
    install(TARGETS ${target_name}
        EXPORT GuardVisionTargets
        ARCHIVE DESTINATION "${CMAKE_INSTALL_LIBDIR}/${_guardvision_binary_config}"
        LIBRARY DESTINATION "${CMAKE_INSTALL_LIBDIR}/${_guardvision_binary_config}"
        RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}/${_guardvision_binary_config}"
        INCLUDES DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}"
    )

    install(DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/include/"
        DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}"
    )

    install(EXPORT GuardVisionTargets
        FILE GuardVisionTargets.cmake
        NAMESPACE GuardVision::
        DESTINATION "${_guardvision_package_dir}"
    )

    configure_package_config_file(
        "${CMAKE_CURRENT_SOURCE_DIR}/cmake/GuardVisionConfig.cmake.in"
        "${CMAKE_CURRENT_BINARY_DIR}/GuardVisionConfig.cmake"
        INSTALL_DESTINATION "${_guardvision_package_dir}"
    )

    write_basic_package_version_file(
        "${CMAKE_CURRENT_BINARY_DIR}/GuardVisionConfigVersion.cmake"
        VERSION ${PROJECT_VERSION}
        COMPATIBILITY SameMajorVersion
    )

    install(FILES
        "${CMAKE_CURRENT_BINARY_DIR}/GuardVisionConfig.cmake"
        "${CMAKE_CURRENT_BINARY_DIR}/GuardVisionConfigVersion.cmake"
        "${CMAKE_CURRENT_SOURCE_DIR}/cmake/GuardVisionDependencies.cmake"
        "${CMAKE_CURRENT_SOURCE_DIR}/cmake/GuardVisionRuntimeDeploy.cmake"
        DESTINATION "${_guardvision_package_dir}"
    )
endfunction()
