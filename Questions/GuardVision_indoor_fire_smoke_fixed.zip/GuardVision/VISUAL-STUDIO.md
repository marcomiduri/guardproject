# GuardVision — Visual Studio 2019

GuardVision is a CMake project. The installer ships **source only**; Visual Studio solution files must be generated once on your PC (CMake embeds your install path).

## After DABoard setup (recommended)

If you left **"Generate Visual Studio 2019 projects"** checked during install, `GuardVision.sln` should already exist in this folder.

If not, run either:

```bat
cd Desktop\scripts
configure-installed-sources.cmd
```

or from this folder:

```bat
GENERATE-VS2019-PROJECTS.cmd
```

## Open in Visual Studio 2019

```
Desktop\GuardVision\GuardVision.sln
```

Select **Debug | x64** or **Release | x64**, then build the `guardvision` project.

Double-click `open-visual-studio.cmd` to generate the solution if needed and open Visual Studio.

## Requirements

- Visual Studio 2019 with **Desktop development with C++**
- **CMake** (Visual Studio installer component or standalone CMake in PATH)

## Output libraries

After building, Guard links against:

```
Desktop\GuardVision\bin\Debug\guardvision.lib
Desktop\GuardVision\bin\Release\guardvision.lib
```

## Command-line builds

From `Desktop\GuardVision\scripts`:

```bat
build-release.cmd
```

This builds **only** `guardvision.lib` and skips CTest. On an installed DABoard package this is the recommended path (tests can hang or time out under `Program Files` or on offline PCs without full SDK runtime).

To run CTest explicitly (dev machines):

```bat
build-release-with-tests.cmd
```

Install to any writable folder (default: `Documents\DABoard`). You choose the location during setup.

Run `configure-installed-sources.cmd` or `GENERATE-VS2019-PROJECTS.cmd` once after install so CMake embeds your install path. Paths with spaces are supported. Avoid `Program Files` if you lack write permission there.
