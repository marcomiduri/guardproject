# Behavior-Preserving Cleanup, Refactoring, and Optimization

This revision preserves the GuardVision facade, stream lifecycle, public events, processing modes, latest-frame-wins policy, and host-submitted-frame architecture.

## Build and package reliability

- Face and hazard SDKs are independently optional.
- Motion-only builds require no proprietary SDK headers or libraries.
- Enabled dependencies remain mandatory and fail CMake configuration clearly when missing.
- Installed packages recreate only the imported SDK targets actually required by that build.
- Debug and Release archives install into separate configuration directories.
- Qt remains outside the standalone library build.
- The Windows helper supports feature switches, tests, examples, custom toolchains, clean builds, and install prefixes.

## Performance changes

- The facade uses a shared lifecycle lock rather than serializing every stream submission.
- Main frame routing no longer executes software motion analysis.
- A dedicated motion scheduler provides per-stream latest-frame replacement and independent worker concurrency.
- Face and hazard submission therefore proceeds without waiting for heavy motion conversion or analysis.
- Scheduler results avoid redundant pending/processing lock queries.
- Latest-frame storage is sharded.
- Luma conversion uses specialized loops and cached sampling maps.
- Face/hazard worker assignment is sticky and least-loaded.
- Face session settings are cached.
- Independent metric atomics use relaxed memory order, and maxima use compare-exchange updates.

## Lifecycle and safety

- Face sessions are destroyed on their owning workers.
- Process-wide engines remain alive until the last GuardVision runtime user exits.
- Conflicting explicit process-wide model configurations are rejected.
- Shared listener registration protects ownership through callback completion.
- The raw listener API is retained as an explicitly non-owning compatibility path.
- Stream generation checks prevent stale jobs from affecting re-registered streams.

## Test and fixture cleanup

- Correct packed and planar frame allocation.
- No mutation of published immutable buffers.
- Warnings-as-errors clean test code.
- Multi-instance shutdown regression coverage.
- SDK-free motion-only build and tests.

## Verification language

This source ZIP excludes proprietary SDK files. Local SDK-compatible test libraries may be used to validate compilation and symbol wiring, but that is separate from real SDK linking and real inference certification.

## 2026 behavior-preserving maintenance pass

- Centralized the repeated initialized-manager guard used by the public facade without changing lock scope or return values.
- Fixed the SDK-disabled IdentifyEngine shutdown implementation so motion-only builds compile and reset the same local state as SDK-enabled builds.
- Shared scheduler queue constants and worker-index validation between face and hazard schedulers.
- Avoided unnecessary default construction in the metrics and latest-frame maps.
- Simplified latest-frame replacement bookkeeping while preserving latest-frame-wins behavior.

## Final conservative maintenance pass

- Removed unused configuration-translation-unit dependencies.
- Consolidated identical face/hazard scheduler enable/disable/update branching in one internal helper.
- Reused the listener registry's explicit detach operation from the public clear-listener path.
- Preserved public APIs, scheduler ordering, lock scope, stream lifecycle, and event behavior.

