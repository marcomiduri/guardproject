# Architecture

GuardVision receives already-decoded frames and produces motion, face, hazard, and alarm events.

It does not own camera connections, RTSP, HCNetSDK, decoding, Qt UI, recording, backend communication, sounds, or notifications.

The runtime is coordinated by `StreamManager`:

- `FrameScheduler` performs bounded, latest-frame-wins routing per stream.
- `MotionScheduler` independently runs software motion analysis with the same latest-frame-wins policy.
- `FaceScheduler` and `HazardScheduler` own their bounded analytic worker paths.
- `OnboardProcessor` correlates vendor-neutral candidates with bounded recent frames, performs regional confirmation, and sends evidence to `AlarmCorrelator`.
- `EventDispatcher` delivers callbacks asynchronously.

Face and hazard are compile-time optional features. Their public API types remain stable even when a feature is disabled.
