# Frame Ownership

`VideoFrame` carries `std::shared_ptr<const FrameBuffer>`. A submitted frame therefore retains its decoded bytes while asynchronous GuardVision work is pending.

The host may create a buffer with `FrameBuffer::copyFrom()` or `FrameBuffer::allocate()`. The host must not mutate bytes after exposing them through a const frame buffer contract.
