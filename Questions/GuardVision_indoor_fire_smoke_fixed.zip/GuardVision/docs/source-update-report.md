# GuardVision Revised Source Update Report

## Implemented order

1. Added true optional face and hazard builds. A motion-only build configures, compiles, tests, installs, and can be consumed without either proprietary SDK.
2. Moved software motion processing to a dedicated latest-frame-wins scheduler so the main routing worker remains lightweight.
3. Changed installed archives to configuration-specific `lib/Debug` and `lib/Release` directories.
4. Added deterministic conflict validation for process-wide Identify/HazardDetect model paths and HazardDetect global initialization threshold.
5. Added owning `shared_ptr` listener registration, `clearEventListener()`, and preserved raw-pointer compatibility with an explicit lifetime contract.
6. Updated documentation to distinguish SDK-compatible link tests, real SDK linking, and real runtime inference verification.

## Build-system changes

- New options:
  - `GUARDVISION_ENABLE_FACE`
  - `GUARDVISION_ENABLE_HAZARD`
- Dependency discovery runs only for enabled features.
- Disabled-feature processor implementations preserve link completeness and return structured unavailable-feature errors.
- Installed package records which features were built and recreates only required imported dependency targets.
- Runtime deployment copies only enabled SDK runtime directories.
- Windows build scripts accept `-EnableFace:$false` and `-EnableHazard:$false`.

## Runtime changes

- Added `GuardVisionConfig::motionWorkerCount`.
- Added an independent motion `FrameScheduler` and `StreamManager::processMotionJob()`.
- Main routing now performs correlation and submits motion/face/hazard work without executing motion analysis inline.
- Stream registration, removal, and shutdown coordinate both routing and motion schedulers.

## Listener safety

Available forms:

```cpp
guardVision.setEventListener(&hostOwnedListener); // non-owning
guardVision.setEventListener(sharedListener);     // owning
guardVision.clearEventListener();
```

Shared listener ownership is copied into callback leases. The raw form remains safe only when the host detaches before destruction.

## Process-wide engine behavior

The first successful explicit model/resource configuration remains process-wide. A later conflicting explicit path now returns `InvalidConfiguration`; it is never silently accepted. HazardDetect also validates its global initialization threshold.

## Verification completed in this environment

- GCC 14 full feature-enabled build with warnings-as-errors: passed
- Full CTest suite: passed
- SDK-free motion-only configure/build with warnings-as-errors: passed
- SDK-free motion-only CTest suite: passed
- Motion-only install and external CMake consumer: passed
- Configuration-specific Release install/export location: passed

Feature-enabled builds used local SDK-compatible test libraries available in the workspace. This validates code and link wiring, not licensed vendor runtime behavior.

## Target-machine verification still required

- MSVC/Windows Debug and Release builds with the actual licensed SDK packages
- actual runtime DLL deployment
- real Identify model initialization and inference
- real HazardDetect model initialization and inference
- long-duration multi-camera performance soak
- Qt 5.7, 5.12, and 5.14 host consumer smoke tests
