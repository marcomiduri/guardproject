# Onboard and Hybrid Processing

The host converts camera-specific events into vendor-neutral `OnboardCandidate` objects.

GuardVision validates the candidate, finds the closest stored frame by timestamp, maps normalized or reference-pixel regions into frame coordinates, expands the region, runs software confirmation, and correlates the result into Software, Onboard, or Hybrid alarm incidents.
