# Implementation Status

This package contains the updated GuardVision `include/`, `src/`, and `tests/` implementation arranged as a standalone source tree.

Build and model-backed runtime verification require the licensed Identify SDK, HazardDetect SDK, and their model resources, which are not included in this archive.
