# Public API Boundary

The public API is under `include/` and exposes standard C++ and GuardVision-owned types only.

Primary facade: `guardvision::GuardVision`.

Key operations:

- initialize / shutdown
- registerStream / unregisterStream
- submitFrame
- set/get motion, face, hazard, and onboard configuration
- submitOnboardCandidate
- stream and analytic metrics
- raw non-owning event-listener registration
- owning `std::shared_ptr<IGuardVisionEventListener>` registration
- explicit `clearEventListener()`

Private schedulers, vendor SDK handles, worker state, and synchronization types remain under `src/`.

Face and hazard public models remain available in feature-disabled builds. Runtime requests for a disabled analytic fail through structured GuardVision errors rather than missing symbols or CMake-time dependency failures.

## Stream generation semantics

`StreamStatus::generation` and the `generation` field on frame, motion, face, hazard, and alarm events are owned by GuardVision. The value identifies one registration lifetime of a `streamId` and changes when that stream is unregistered and registered again.

Applications must not compare this value with a camera SDK generation, decoder generation, playback generation, reconnect counter, or any other application-owned counter. Use the GuardVision generation only to reject stale GuardVision events. Keep source generations separately and translate a current GuardVision event to the current source generation before forwarding it to source-owned components such as packet recorders.


## Deterministic process-exit shutdown

`GuardVision::shutdown(ShutdownMode::ProcessExit)` is intended only for final
application exit. It synchronously blocks new submissions, detaches callbacks,
stops and joins every GuardVision-owned worker/dispatcher thread, and clears
GuardVision state. It intentionally does not call vendor session-release or
process-global engine termination APIs, which avoids vendor teardown crashes
after active streams. The operating system reclaims those opaque resources when
the process exits. Ordinary reusable shutdown must continue to use the default
`ShutdownMode::Graceful`.
