# Threading Model

- `FrameScheduler`: bounded lightweight routing workers with latest-pending replacement per stream.
- `MotionScheduler`: independent latest-frame-wins software motion workers. Heavy motion analysis cannot hold the main routing path.
- `FaceScheduler`: bounded asynchronous face processing with persistent per-stream sessions.
- `HazardScheduler`: bounded asynchronous hazard processing with reusable process-wide runtime.
- `OnboardProcessor`: bounded candidate correlation and alarm maintenance.
- `EventDispatcher`: bounded asynchronous event delivery.

Public listener callbacks occur outside internal processing locks. Stream unregister and shutdown invalidate stale work before publication.

The raw listener registration is non-owning. The `shared_ptr` overload retains listener ownership for the registration and for every in-progress callback lease.
