@echo off
setlocal
set "SLN=%~dp0GuardVision.sln"
if not exist "%SLN%" (
    echo Visual Studio solution not found. Generating GuardVision VS2019 projects...
    call "%~dp0scripts\prepare-vs.cmd" || exit /b 1
)
start "" "%SLN%"
