#include <chrono>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>

#include <core/DetectionMode.h>
#include <face/FaceConfig.h>
#include <face/FaceEvent.h>
#include <face/FaceMetrics.h>
#include <face/FaceTypes.h>
#include <frame/FrameBuffer.h>
#include <geometry/Geometry.h>
#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <motion/MotionConfig.h>
#include <frame/VideoFrame.h>

#include "face/IdentifyEngine.h"
#include "face/FaceTrackRegistry.h"
#include "JpegLoadHelper.h"
#include "scheduling/LatestFrameSlot.h"

namespace {

using namespace guardvision;

int g_failures = 0;

void expectTrue(bool condition, const char* message) {
    if (!condition) {
        ++g_failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}

void expectFalse(bool condition, const char* message) {
    expectTrue(!condition, message);
}

std::string resolveAssetPath(const char* relativePath) {
    const std::string relative(relativePath);
    const std::string assetRelative = relative.rfind("assets/", 0) == 0 ? relative.substr(7) : relative;
    const std::vector<std::string> candidates = {
      relative,
      std::string("../") + relative,
      std::string("../../") + relative,
      std::string("../assets/") + assetRelative,
      std::string("../../assets/") + assetRelative,
      std::string("../../../assets/") + assetRelative,
    };
    for (const std::string& candidate : candidates) {
        std::error_code ec;
        if (std::filesystem::is_regular_file(candidate, ec) && !ec) {
            return candidate;
        }
    }
    return {};
}

std::vector<std::uint8_t> loadBinaryFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    return std::vector<std::uint8_t>((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
}

FaceConfig defaultFaceConfig() {
    FaceConfig config;
    config.processingLevel = FaceProcessingLevel::DetectAndTrack;
    config.triggerMode = FaceTriggerMode::ContinuousSoftware;
    config.analysisIntervalMs = 0;
    config.minimumFaceWidth = 20;
    config.minimumFaceHeight = 20;
    config.minimumDetectionConfidence = 0.3;
    config.minimumQualityScore = 0.1;
    config.maximumFaceCount = 4;
    return config;
}

void testFaceConfigValidation() {
    FaceConfig config = defaultFaceConfig();
    expectTrue(isValidFaceConfig(config), "default face config valid");

    config.minimumDetectionConfidence = 1.5;
    expectFalse(isValidFaceConfig(config), "reject out-of-range detection confidence");
    config = defaultFaceConfig();

    config.triggerMode = FaceTriggerMode::OnboardTriggered;
    expectTrue(isValidFaceConfig(config), "onboard trigger valid");
    expectTrue(isSupportedFaceTriggerMode(FaceTriggerMode::Hybrid), "hybrid trigger supported");
    expectTrue(isSupportedFaceTriggerMode(FaceTriggerMode::ContinuousSoftware), "continuous software supported");
}

class TestFaceListener : public IGuardVisionEventListener {
public:
    std::vector<FaceEvent> faceEvents;
    std::mutex mutex;

    void onFace(const FaceEvent& event) override {
        std::lock_guard<std::mutex> lock(mutex);
        faceEvents.push_back(event);
    }
};

bool waitForFaceAnalyzed(GuardVision& guardVision, const std::string& streamId, std::uint64_t minAnalyzed, int timeoutMs) {
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    while (std::chrono::steady_clock::now() < deadline) {
        FaceMetrics metrics;
        if (guardVision.getFaceMetrics(streamId, metrics).ok && metrics.analyzedFrames >= minAnalyzed) {
            return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    return false;
}

void testOnboardTriggerRegistration() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    if (!guardVision.initialize(config).ok) {
        std::cout << "SKIPPED: onboard trigger registration (GuardVision init failed)\n";
        return;
    }

    StreamConfig streamConfig;
    streamConfig.streamId = "face-trigger-test";
    streamConfig.face = defaultFaceConfig();
    streamConfig.face.triggerMode = FaceTriggerMode::OnboardTriggered;
    streamConfig.face.detectionMode = DetectionMode::OnboardTriggered;
    if (!guardVision.registerStream(streamConfig).ok) {
        std::cout << "SKIPPED: onboard trigger registration (face engine unavailable)\n";
        guardVision.shutdown();
        return;
    }
    expectTrue(true, "register accepts onboard trigger mode");
    guardVision.shutdown();
}

void testIdentifyEngineLaunchOnly() {
    const std::string modelPath = discoverIdentifyResourcePath("");
    if (modelPath.empty()) {
        std::cout << "SKIPPED: assets/Pikachu model pack not found\n";
        return;
    }

    const Result initResult = IdentifyEngine::instance().initialize(modelPath);
    if (!initResult.ok) {
        std::cout << "FAIL: IdentifyEngine init: " << initResult.error.message << " vendor=" << initResult.error.vendorErrorCode << '\n';
        ++g_failures;
        return;
    }
    std::cout << "PASS: IdentifyEngine initialized from " << IdentifyEngine::instance().resourcePath() << '\n';
    IdentifyEngine::instance().shutdown();
}

void testIdentifyIntegrationWithFaceJpg() {
    const std::string facePath = resolveAssetPath("assets/face.jpg");
    if (facePath.empty()) {
        std::cout << "SKIPPED: assets/face.jpg not found\n";
        return;
    }

    const std::string modelPath = discoverIdentifyResourcePath("");
    if (modelPath.empty()) {
        std::cout << "SKIPPED: assets/Pikachu model pack not found\n";
        return;
    }

    const std::vector<std::uint8_t> jpegData = loadBinaryFile(facePath);
    expectFalse(jpegData.empty(), "face.jpg loaded");
    if (jpegData.empty()) {
        return;
    }

    JpegImage image;
    std::string decodeError;
    if (!loadJpegAsBgr(facePath, image, &decodeError)) {
        std::cout << "SKIPPED: face.jpg decode failed: " << decodeError << '\n';
        return;
    }

    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    config.identifyResourcePath = modelPath;
    const Result initResult = guardVision.initialize(config);
    if (!initResult.ok) {
        std::cout << "SKIPPED: GuardVision init failed: " << initResult.error.message << '\n';
        return;
    }

    TestFaceListener listener;
    guardVision.setEventListener(&listener);

    StreamConfig streamConfig;
    streamConfig.streamId = "face-jpg-test";
    streamConfig.face = defaultFaceConfig();
    streamConfig.face.minimumDetectionConfidence = 0.3;
    streamConfig.face.minimumFaceWidth = 20;
    streamConfig.face.minimumFaceHeight = 20;
    streamConfig.face.analysisIntervalMs = 0;
    const Result registerResult = guardVision.registerStream(streamConfig);
    if (!registerResult.ok) {
        std::cout << "FAIL: register face stream: " << registerResult.error.message << " vendor=" << registerResult.error.vendorErrorCode << '\n';
        guardVision.shutdown();
        return;
    }
    expectTrue(registerResult.ok, "register face stream");

    VideoFrame frame;
    frame.streamId = streamConfig.streamId;
    frame.width = image.width;
    frame.height = image.height;
    frame.stride = image.width * 3;
    frame.sequence = 1;
    frame.timestampMs = 100;
    frame.pixelFormat = PixelFormat::BGR24;
    frame.buffer = FrameBuffer::copyFrom(image.bgr.data(), image.bgr.size());

    expectTrue(guardVision.submitFrame(frame).accepted, "submit face.jpg frame");
    const bool analyzed = waitForFaceAnalyzed(guardVision, streamConfig.streamId, 1, 10000);

    FaceMetrics metrics;
    guardVision.getFaceMetrics(streamConfig.streamId, metrics);
    std::cout << "face.jpg analyzedFrames=" << metrics.analyzedFrames << " detectedFaces=" << metrics.detectedFaces
              << " filteredFaces=" << metrics.filteredFaces << " appearedTracks=" << metrics.appearedTracks << '\n';

    expectTrue(analyzed, "face.jpg frame analyzed asynchronously");
    if (metrics.detectedFaces > 0) {
        expectTrue(metrics.appearedTracks >= 1 || metrics.analyzedFrames >= 1, "face detected in face.jpg");
        std::cout << "PASS: face.jpg produced Identify detections\n";
    } else {
        std::cout << "PASS: face.jpg analyzed with zero detections (reported honestly)\n";
    }

    guardVision.shutdown();
}

void testInitWithoutModels() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    expectTrue(guardVision.initialize(config).ok, "initialize succeeds without Identify models when face disabled");
    guardVision.shutdown();
}

void testFaceRegisterRequiresModels() {
    if (!discoverIdentifyResourcePath("").empty()) {
        std::cout << "SKIPPED: face register requires models (models present)\n";
        return;
    }

    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    expectTrue(guardVision.initialize(config).ok, "initialize without models");

    StreamConfig streamConfig;
    streamConfig.streamId = "face-model-missing";
    streamConfig.face = defaultFaceConfig();
    expectFalse(guardVision.registerStream(streamConfig).ok, "face-enabled register fails when models missing");
    guardVision.shutdown();
}

void testFaceLatestFrameReplacement() {
    LatestFrameSlot slot;
    FrameRoutingJob first;
    first.token = StreamToken{"face-stream", 1};
    first.submittedAtMs = 1;
    expectTrue(slot.replace(std::move(first)) == ReplaceResult::Inserted, "face slot accepts first frame");

    FrameRoutingJob second;
    second.token = StreamToken{"face-stream", 1};
    second.submittedAtMs = 2;
    expectTrue(slot.replace(std::move(second)) == ReplaceResult::ReplacedPending, "face slot replaces pending latest frame");
    expectTrue(slot.hasPending(), "face slot keeps one pending frame");
}

void testFaceTrackRegistryIdentityCache() {
    FaceTrackRegistry registry(4);
    FaceConfig config = defaultFaceConfig();
    config.processingLevel = FaceProcessingLevel::DetectTrackAndIdentify;
    config.identificationRetryIntervalMs = 5000;
    config.identityRefreshIntervalMs = 10000;

    expectTrue(registry.shouldAttemptIdentification(42, config, 1000), "first identification attempt allowed");
    registry.recordIdentificationAttempt(42, 1000);
    expectFalse(registry.shouldAttemptIdentification(42, config, 2000), "retry blocked before interval");

    FaceTrack detection;
    detection.trackId = 42;
    detection.bounds = Rect{10, 10, 80, 80};
    detection.detectionConfidence = 0.9;
    detection.qualityScore = 0.8;
    detection.state = FaceTrackState::Tracking;

    std::unordered_map<int, FaceIdentityMatch> identities;
    FaceIdentityMatch match;
    match.identified = true;
    match.identityId = 7;
    match.displayName = "user-7";
    match.confidence = 0.91;
    identities.emplace(42, match);

    const std::vector<FaceEvent> events = registry.updateDetections({detection}, identities, config, "cache-test", 1, 1, 1000, 1000, nullptr);
    expectFalse(events.empty(), "identity update emits events");
    expectFalse(registry.shouldAttemptIdentification(42, config, 1500), "cached identity skips search");

    config.identityRefreshIntervalMs = 100;
    expectTrue(registry.shouldAttemptIdentification(42, config, 1200), "refresh interval allows new attempt");
}

void testFaceTrackRegistryReusesStableOverlappingTrack() {
    FaceTrackRegistry registry(4);
    FaceConfig config = defaultFaceConfig();
    config.lostTrackTimeoutMs = 1000;

    FaceTrack first;
    first.trackId = 10;
    first.bounds = Rect{20, 20, 80, 80};
    first.detectionConfidence = 0.9;
    first.qualityScore = 0.8;

    const std::vector<FaceEvent> firstEvents = registry.updateDetections({first}, {}, config, "reuse-test", 1, 1, 1000, 1000, nullptr);
    std::uint64_t firstPublicId = 0;
    for (const FaceEvent& event : firstEvents) {
        if (event.type == FaceEventType::TracksUpdated && !event.tracks.empty()) {
            firstPublicId = event.tracks.front().trackId;
        }
    }
    expectTrue(firstPublicId != 0, "first overlapping face gets public track id");

    FaceTrack sameFaceNewVendor;
    sameFaceNewVendor.trackId = 99;
    sameFaceNewVendor.bounds = Rect{22, 21, 80, 80};
    sameFaceNewVendor.detectionConfidence = 0.9;
    sameFaceNewVendor.qualityScore = 0.8;

    const std::vector<FaceEvent> secondEvents = registry.updateDetections({sameFaceNewVendor}, {}, config, "reuse-test", 1, 2, 1040, 1040, nullptr);
    std::uint64_t secondPublicId = 0;
    bool appearedAgain = false;
    for (const FaceEvent& event : secondEvents) {
        if (event.type == FaceEventType::TrackAppeared) {
            appearedAgain = true;
        }
        if (event.type == FaceEventType::TracksUpdated && !event.tracks.empty()) {
            secondPublicId = event.tracks.front().trackId;
        }
    }

    expectTrue(secondPublicId == firstPublicId, "overlapping face keeps public track id when vendor id changes");
    expectFalse(appearedAgain, "overlapping vendor-id change does not emit new appeared track");
}

void testNoCallbackAfterShutdown() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    if (!guardVision.initialize(config).ok) {
        std::cout << "SKIPPED: no callback after shutdown init failed\n";
        return;
    }

    TestFaceListener listener;
    guardVision.setEventListener(&listener);
    guardVision.shutdown();
    guardVision.setEventListener(nullptr);

    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    expectTrue(listener.faceEvents.empty(), "no face callbacks after shutdown");
}

void testMotionRegressionBrief() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    if (!guardVision.initialize(config).ok) {
        std::cout << "SKIPPED: motion regression init failed\n";
        return;
    }

    StreamConfig streamConfig;
    streamConfig.streamId = "motion-regression";
    streamConfig.motion.enabled = true;
    streamConfig.motion.analysisIntervalMs = 0;
    expectTrue(guardVision.registerStream(streamConfig).ok, "register motion stream");

    VideoFrame frame;
    frame.streamId = streamConfig.streamId;
    frame.width = 160;
    frame.height = 120;
    frame.stride = 160;
    frame.sequence = 1;
    frame.timestampMs = 100;
    frame.pixelFormat = PixelFormat::Gray8;
    const std::vector<std::uint8_t> grayData(160 * 120, 10);
    frame.buffer = FrameBuffer::copyFrom(grayData.data(), grayData.size());

    expectTrue(guardVision.submitFrame(frame).accepted, "submit motion frame");
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
    while (std::chrono::steady_clock::now() < deadline) {
        MotionMetrics metrics;
        if (guardVision.getMotionMetrics(streamConfig.streamId, metrics).ok && metrics.analyzedFrames >= 1) {
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }

    MotionMetrics metrics;
    guardVision.getMotionMetrics(streamConfig.streamId, metrics);
    expectTrue(metrics.analyzedFrames >= 1, "motion still analyzes with face workers present");
    guardVision.shutdown();
}

}  // namespace

int runTask5Tests() {
    std::cout << "task5: FaceConfig validation\n";
    testFaceConfigValidation();
    std::cout << "task5: init without models\n";
    testInitWithoutModels();
    std::cout << "task5: face register requires models\n";
    testFaceRegisterRequiresModels();
    std::cout << "task5: latest-frame replacement\n";
    testFaceLatestFrameReplacement();
    std::cout << "task5: identity cache\n";
    testFaceTrackRegistryIdentityCache();
    std::cout << "task5: overlapping track reuse\n";
    testFaceTrackRegistryReusesStableOverlappingTrack();
    std::cout << "task5: onboard trigger mode\n";
    testOnboardTriggerRegistration();
    std::cout << "task5: motion regression\n";
    testMotionRegressionBrief();
    std::cout << "task5: shutdown callback guard\n";
    testNoCallbackAfterShutdown();
    std::cout << "task5: Identify engine launch\n";
    testIdentifyEngineLaunchOnly();
    std::cout << "task5: face.jpg integration\n";
    testIdentifyIntegrationWithFaceJpg();
    return g_failures;
}
