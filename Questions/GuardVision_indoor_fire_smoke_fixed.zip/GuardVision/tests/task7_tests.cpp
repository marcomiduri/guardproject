#include <iostream>
#include <limits>
#include <chrono>
#include <mutex>
#include <thread>

#include <core/DetectionMode.h>
#include <geometry/Geometry.h>
#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <onboard/OnboardConfig.h>
#include <onboard/OnboardMetrics.h>
#include <onboard/OnboardTypes.h>
#include <core/StreamConfig.h>
#include <frame/VideoFrame.h>

#include "detail/TimeUtil.h"
#include "onboard/AlarmCorrelator.h"
#include "onboard/CandidateCoordinateConverter.h"
#include "onboard/FrameCorrelationStore.h"
#include "onboard/OnboardCandidateValidator.h"

namespace {

using namespace guardvision;

int g_failures = 0;

void expectTrue(bool condition, const char* message) {
    if (!condition) {
        ++g_failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}

VideoFrame makeRgbFrame(const std::string& streamId, int width, int height, std::uint64_t sequence, std::int64_t timestampMs) {
    VideoFrame frame;
    frame.streamId = streamId;
    frame.width = width;
    frame.height = height;
    frame.stride = width * 3;
    frame.sequence = sequence;
    frame.timestampMs = timestampMs;
    frame.pixelFormat = PixelFormat::RGB24;
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(frame.stride * height), 128);
    frame.buffer = FrameBuffer::copyFrom(bytes.data(), bytes.size());
    return frame;
}

void fillRgbRect(VideoFrame& frame, int x, int y, int w, int h, std::uint8_t value) {
    std::vector<std::uint8_t> data(frame.buffer->data(), frame.buffer->data() + frame.buffer->sizeBytes());
    for (int row = y; row < y + h; ++row) {
        for (int col = x; col < x + w; ++col) {
            const auto offset = static_cast<std::size_t>(row * frame.stride + col * 3);
            data[offset] = value;
            data[offset + 1] = value;
            data[offset + 2] = value;
        }
    }
    frame.buffer = FrameBuffer::copyFrom(data.data(), data.size());
}

void testDetectionModeDefaults() {
    MotionConfig motion;
    FaceConfig face;
    HazardConfig hazard;
    expectTrue(motion.detectionMode == DetectionMode::Software, "motion default software");
    expectTrue(face.detectionMode == DetectionMode::Software, "face default software");
    expectTrue(hazard.detectionMode == DetectionMode::Software, "hazard default software");
    expectTrue(runsContinuousSoftware(DetectionMode::Software), "software runs continuous");
    expectTrue(!runsContinuousSoftware(DetectionMode::OnboardTriggered), "onboard does not run continuous");
    expectTrue(acceptsOnboardCandidates(DetectionMode::Hybrid), "hybrid accepts onboard");
}

void testCandidateValidation() {
    OnboardCandidate candidate;
    candidate.streamId = "s1";
    candidate.timestampMs = 100;
    candidate.type = CandidateType::Motion;
    OnboardCandidateRegion region;
    region.coordinateSpace = CandidateCoordinateSpace::Normalized;
    region.normalizedBounds = NormalizedRect{0.1, 0.1, 0.2, 0.2};
    candidate.regions.push_back(region);
    expectTrue(validateOnboardCandidate(candidate).ok, "valid normalized candidate");

    candidate.regions[0].normalizedBounds = NormalizedRect{0.0, 0.0, 1.2, 1.0};
    expectTrue(!validateOnboardCandidate(candidate).ok, "invalid normalized candidate");

    candidate.regions[0].coordinateSpace = CandidateCoordinateSpace::ReferencePixels;
    candidate.regions[0].pixelBounds = Rect{10, 10, 20, 20};
    candidate.regions[0].referenceWidth = 0;
    expectTrue(!validateOnboardCandidate(candidate).ok, "missing reference dimensions");
}

void testCoordinateMapping() {
    VideoFrame frame = makeRgbFrame("s1", 1280, 720, 1, 100);
    OnboardCandidate candidate;
    candidate.streamId = "s1";
    candidate.timestampMs = 100;
    candidate.type = CandidateType::Face;
    OnboardCandidateRegion region;
    region.coordinateSpace = CandidateCoordinateSpace::Normalized;
    region.normalizedBounds = NormalizedRect{0.5, 0.5, 0.25, 0.25};
    candidate.regions.push_back(region);
    const CandidateMappingResult mapped = mapOnboardCandidateRegions(candidate, frame, 1.5);
    expectTrue(mapped.ok, "normalized mapping");
    expectTrue(!mapped.regions.empty(), "mapped region exists");
    expectTrue(mapped.regions.front().expandedRegion.width >= mapped.regions.front().mappedCandidate.width, "expansion width");

    region.coordinateSpace = CandidateCoordinateSpace::ReferencePixels;
    region.pixelBounds = Rect{960, 540, 100, 100};
    region.referenceWidth = 1920;
    region.referenceHeight = 1080;
    candidate.regions = {region};
    const CandidateMappingResult scaled = mapOnboardCandidateRegions(candidate, frame, 2.0);
    expectTrue(scaled.ok, "reference pixel mapping");
    expectTrue(scaled.regions.front().mappedCandidate.x > 0, "substream mapping x");
}

void testExpansionAndIoU() {
    const Rect expanded = expandRectAroundCenter(Rect{100, 100, 40, 40}, 1.5, Size{640, 480});
    expectTrue(expanded.width >= 60, "motion expansion 1.5x");
    const Rect hazardExpanded = expandRectAroundCenter(Rect{100, 100, 40, 40}, 2.0, Size{640, 480});
    expectTrue(hazardExpanded.width >= 80, "hazard expansion 2.0x");
    const double iou = intersectOverUnion(Rect{0, 0, 100, 100}, Rect{50, 50, 100, 100});
    expectTrue(iou > 0.1 && iou < 0.5, "iou overlap");
}

void testFrameCorrelation() {
    FrameCorrelationStore store(4);
    store.addFrame(makeRgbFrame("s1", 640, 480, 1, 100));
    store.addFrame(makeRgbFrame("s1", 640, 480, 2, 200));
    const auto match = store.findClosestFrame(210, 50);
    expectTrue(match.has_value(), "closest valid frame");
    expectTrue(!store.findClosestFrame(1000, 50).has_value(), "outside correlation window");
}

void testAlarmCorrelator() {
    OnboardConfig config;
    config.alarmUpdateIntervalMs = 500;
    AlarmCorrelator correlator(config);
    const auto first = correlator.onSoftwareEvidence("s1", 1, AlarmType::Motion, 100, 0.8, {Rect{10, 10, 20, 20}}, 0);
    expectTrue(!first.duplicateSuppressed, "software alarm started");
    const auto duplicate = correlator.onSoftwareEvidence("s1", 1, AlarmType::Motion, 150, 0.8, {Rect{12, 12, 20, 20}}, 0);
    expectTrue(duplicate.duplicateSuppressed, "duplicate suppressed");
    const auto hybrid = correlator.onOnboardEvidence("s1", 1, AlarmType::Motion, 700, 0.9, {Rect{11, 11, 20, 20}}, "t1");
    expectTrue(!hybrid.duplicateSuppressed, "hybrid update or start");
    expectTrue(hybrid.event.source == AlarmSource::Hybrid, "hybrid source");
}

void testAlarmCorrelatorActiveIncidentLimit() {
    OnboardConfig config;
    config.maximumActiveIncidents = 1;
    AlarmCorrelator correlator(config);

    const auto first = correlator.onSoftwareEvidence("s1", 1, AlarmType::Motion, 100, 0.8, {Rect{10, 10, 20, 20}}, 0);
    expectTrue(!first.duplicateSuppressed && !first.rejectedByLimit, "first incident accepted at limit");

    const auto update = correlator.onSoftwareEvidence("s1", 1, AlarmType::Motion, 700, 0.9, {Rect{11, 11, 20, 20}}, 0);
    expectTrue(!update.rejectedByLimit, "matching incident updates at limit");

    const auto rejected = correlator.onSoftwareEvidence("s1", 1, AlarmType::Face, 800, 0.9, {Rect{200, 200, 20, 20}}, 2);
    expectTrue(rejected.rejectedByLimit, "unrelated incident rejected at limit");
    expectTrue(correlator.activeIncidentCount() == 1, "active incident count remains bounded");
}

void testAlarmCorrelatorTargetIdAndTimeoutClockDomain() {
    OnboardConfig config;
    config.alarmUpdateIntervalMs = 0;
    config.incidentTimeoutMs = 150;
    AlarmCorrelator correlator(config);

    const auto first = correlator.onOnboardEvidence("target-stream", 1, AlarmType::Face, 1000, 0.8, {Rect{10, 10, 20, 20}}, "target-1");
    const auto moved = correlator.onOnboardEvidence("target-stream", 1, AlarmType::Face, 1100, 0.9, {Rect{400, 300, 20, 20}}, "target-1");
    expectTrue(!moved.rejectedByLimit, "same onboard target updates after moving without overlap");
    expectTrue(moved.event.alarmId == first.event.alarmId, "same onboard target keeps alarm identity");
    expectTrue(correlator.activeIncidentCount() == 1, "same target does not create duplicate incident");

    std::vector<AlarmDispatchRequest> expired;
    correlator.expireTimedOut(detail::steadyNowMs() + config.incidentTimeoutMs + 1, expired);
    expectTrue(expired.size() == 1, "timeout expires one incident");
    if (!expired.empty()) {
        expectTrue(expired.front().event.state == AlarmState::Ended, "timeout emits ended state");
        expectTrue(expired.front().event.timestampMs == 1100 + config.incidentTimeoutMs, "timeout event timestamp remains in media timestamp domain");
    }
}

class AlarmListener : public IGuardVisionEventListener {
public:
    std::mutex mutex;
    std::vector<AlarmEvent> events;

    void onAlarm(const AlarmEvent& event) override {
        std::lock_guard<std::mutex> lock(mutex);
        events.push_back(event);
    }
};

void testAlarmTimeoutMaintenanceWithoutNewEvidence() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(guardVision.initialize(config).ok, "alarm timeout init");

    OnboardConfig onboard;
    onboard.incidentTimeoutMs = 150;
    onboard.alarmUpdateIntervalMs = 0;
    expectTrue(guardVision.setOnboardConfig(onboard).ok, "alarm timeout onboard config");

    MotionConfig motion;
    motion.enabled = true;
    motion.detectionMode = DetectionMode::Software;
    motion.analysisIntervalMs = 0;
    motion.activationFrameCount = 1;
    motion.clearFrameCount = 3;
    motion.startChangedAreaRatio = 0.001;
    motion.continueChangedAreaRatio = 0.0005;
    motion.minimumRegionWidth = 4;
    motion.minimumRegionHeight = 4;
    motion.minimumRegionArea = 16;
    motion.eventUpdateIntervalMs = 0;

    StreamConfig stream;
    stream.streamId = "alarm-timeout";
    stream.motion = motion;

    AlarmListener listener;
    guardVision.setEventListener(&listener);
    expectTrue(guardVision.registerStream(stream).ok, "alarm timeout stream");

    VideoFrame baseline = makeRgbFrame(stream.streamId, 160, 120, 0, 0);
    expectTrue(guardVision.submitFrame(baseline).accepted, "alarm timeout baseline");
    std::this_thread::sleep_for(std::chrono::milliseconds(150));

    VideoFrame changed = makeRgbFrame(stream.streamId, 160, 120, 1, 100);
    fillRgbRect(changed, 40, 40, 60, 60, 240);
    expectTrue(guardVision.submitFrame(std::move(changed)).accepted, "alarm timeout changed");

    std::this_thread::sleep_for(std::chrono::milliseconds(600));

    int started = 0;
    int ended = 0;
    {
        std::lock_guard<std::mutex> lock(listener.mutex);
        for (const AlarmEvent& event : listener.events) {
            if (event.state == AlarmState::Started) {
                ++started;
            } else if (event.state == AlarmState::Ended) {
                ++ended;
            }
        }
    }
    expectTrue(started >= 1, "timeout test started alarm");
    expectTrue(ended == 1, "timeout emitted one ended alarm");

    OnboardMetrics metrics;
    expectTrue(guardVision.getOnboardMetrics(stream.streamId, metrics).ok, "timeout onboard metrics");
    expectTrue(metrics.alarmsEnded >= 1, "timeout ended metric");
    expectTrue(metrics.candidatesExpired >= 1, "timeout expired metric");

    guardVision.setEventListener(nullptr);
    guardVision.shutdown();
}

}  // namespace

int runTask7Tests() {
    std::cout << "task7: detection mode defaults\n";
    testDetectionModeDefaults();
    std::cout << "task7: candidate validation\n";
    testCandidateValidation();
    std::cout << "task7: coordinate mapping\n";
    testCoordinateMapping();
    std::cout << "task7: expansion and iou\n";
    testExpansionAndIoU();
    std::cout << "task7: frame correlation\n";
    testFrameCorrelation();
    std::cout << "task7: alarm correlator\n";
    testAlarmCorrelator();
    std::cout << "task7: active incident limit\n";
    testAlarmCorrelatorActiveIncidentLimit();
    std::cout << "task7: target id timeout clock\n";
    testAlarmCorrelatorTargetIdAndTimeoutClockDomain();
    std::cout << "task7: alarm timeout maintenance\n";
    testAlarmTimeoutMaintenanceWithoutNewEvidence();
    return g_failures;
}
