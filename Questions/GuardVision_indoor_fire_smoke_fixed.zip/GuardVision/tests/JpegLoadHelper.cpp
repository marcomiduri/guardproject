#include "JpegLoadHelper.h"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <objidl.h>
#include <gdiplus.h>
#pragma comment(lib, "gdiplus.lib")
#endif

#include <string>

#ifdef _WIN32
namespace {

bool ensureGdiplusStarted() {
    static bool started = false;
    static ULONG_PTR token = 0;
    if (started) {
        return true;
    }
    Gdiplus::GdiplusStartupInput startupInput;
    started = Gdiplus::GdiplusStartup(&token, &startupInput, nullptr) == Gdiplus::Ok;
    return started;
}

std::wstring toWidePath(const std::string& path) {
    if (path.empty()) {
        return {};
    }
    const int length = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
    if (length <= 0) {
        return std::wstring(path.begin(), path.end());
    }
    std::wstring wide(static_cast<std::size_t>(length), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, &wide[0], length);
    if (!wide.empty() && wide.back() == L'\0') {
        wide.pop_back();
    }
    return wide;
}

}  // namespace
#endif

bool loadJpegAsBgr(const std::string& path, JpegImage& output, std::string* errorMessage) {
#ifdef _WIN32
    if (!ensureGdiplusStarted()) {
        if (errorMessage) {
            *errorMessage = "GDI+ startup failed";
        }
        return false;
    }

    const std::wstring widePath = toWidePath(path);
    Gdiplus::Bitmap bitmap(widePath.c_str());
    if (bitmap.GetLastStatus() != Gdiplus::Ok) {
        if (errorMessage) {
            *errorMessage = "Failed to decode JPEG";
        }
        return false;
    }

    const int width = static_cast<int>(bitmap.GetWidth());
    const int height = static_cast<int>(bitmap.GetHeight());
    Gdiplus::BitmapData data{};
    Gdiplus::Rect rect(0, 0, width, height);
    if (bitmap.LockBits(&rect, Gdiplus::ImageLockModeRead, PixelFormat24bppRGB, &data) != Gdiplus::Ok) {
        if (errorMessage) {
            *errorMessage = "Failed to lock JPEG bitmap";
        }
        return false;
    }

    output.width = width;
    output.height = height;
    output.bgr.resize(static_cast<std::size_t>(width * height * 3));
    for (int y = 0; y < height; ++y) {
        const auto* srcRow = static_cast<const std::uint8_t*>(data.Scan0) + static_cast<std::size_t>(y * data.Stride);
        std::uint8_t* dstRow = output.bgr.data() + static_cast<std::size_t>(y * width * 3);
        for (int x = 0; x < width; ++x) {
            dstRow[x * 3 + 0] = srcRow[x * 3 + 2];
            dstRow[x * 3 + 1] = srcRow[x * 3 + 1];
            dstRow[x * 3 + 2] = srcRow[x * 3 + 0];
        }
    }
    bitmap.UnlockBits(&data);
    return true;
#else
    (void)path;
    (void)output;
    if (errorMessage) {
        *errorMessage = "JPEG helper is only available on Windows";
    }
    return false;
#endif
}
