#include <chrono>
#include <cstring>
#include <iostream>
#include <memory>
#include <algorithm>
#include <vector>

#include <frame/FrameBuffer.h>
#include <geometry/Geometry.h>
#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <core/SubmitResult.h>
#include <frame/VideoFrame.h>

namespace {

using namespace guardvision;

int g_failures = 0;

void expectTrue(bool condition, const char* message) {
    if (!condition) {
        ++g_failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}

void expectFalse(bool condition, const char* message) {
    expectTrue(!condition, message);
}

VideoFrame makeRgbFrame(const std::string& streamId, int width, int height, int stride, std::uint64_t sequence, std::int64_t timestampMs,
                        const std::vector<std::uint8_t>& bytes) {
    VideoFrame frame;
    frame.streamId = streamId;
    frame.width = width;
    frame.height = height;
    frame.stride = stride;
    frame.sequence = sequence;
    frame.timestampMs = timestampMs;
    frame.pixelFormat = PixelFormat::RGB24;
    frame.buffer = FrameBuffer::copyFrom(bytes.data(), bytes.size());
    return frame;
}

std::vector<std::uint8_t> makePackedBuffer(int width, int height, int stride, int bytesPerPixel) {
    const int rowBytes = std::max(stride, width * bytesPerPixel);
    return std::vector<std::uint8_t>(static_cast<std::size_t>(rowBytes) * static_cast<std::size_t>(height), 1);
}

StreamConfig makeStreamConfig(const std::string& streamId, const std::string& displayName = {}) {
    StreamConfig config;
    config.streamId = streamId;
    config.displayName = displayName;
    return config;
}

void testGeometry() {
    expectTrue(Size{640, 480}.isValid(), "valid size");
    expectFalse(Size{0, 480}.isValid(), "invalid size width");

    Rect rect{10, 20, 100, 50};
    expectTrue(rect.isValid(), "valid rect");
    expectTrue(rect.right() == 110, "rect right");
    expectTrue(rect.bottom() == 70, "rect bottom");

    const Rect clamped = clampRect(Rect{-10, -5, 200, 200}, Size{640, 480});
    expectTrue(clamped.x == 0 && clamped.y == 0, "clamp origin");

    const Rect normalized = normalizedRectToPixels(NormalizedRect{0.0, 0.0, 0.5, 0.5}, Size{100, 100});
    expectTrue(normalized.width == 50 && normalized.height == 50, "normalized conversion");

    const Rect mapped = mapRectBetweenResolutions(Rect{10, 10, 20, 20}, Size{100, 100}, Size{200, 200});
    expectTrue(mapped.width == 40 && mapped.height == 40, "resolution mapping");

    const Rect expanded = expandRectAroundCenter(Rect{40, 40, 20, 20}, 2.0, Size{200, 200});
    expectTrue(expanded.width >= 20, "rect expansion");

    const Rect roiMapped = mapRoiRectToFullFrame(Rect{0, 0, 640, 480}, Rect{10, 10, 50, 50});
    expectTrue(roiMapped.x == 10 && roiMapped.y == 10, "roi mapping");
}

void testFrameBuffer() {
    auto empty = FrameBuffer::allocate(0);
    expectTrue(empty && empty->empty(), "empty allocation");

    const std::vector<std::uint8_t> source{1, 2, 3, 4};
    auto copied = FrameBuffer::copyFrom(source.data(), source.size());
    expectTrue(copied && copied->sizeBytes() == 4, "copy size");
    expectTrue(std::memcmp(copied->data(), source.data(), 4) == 0, "copy contents");
    expectTrue(FrameBuffer::copyFrom(nullptr, 4) == nullptr, "null copy rejected");

    std::shared_ptr<FrameBuffer> shared = copied;
    expectTrue(shared.use_count() >= 2, "shared ownership");
}

void testVideoFrame() {
    auto rgb = makeRgbFrame("stream-a", 2, 2, 6, 0, 0, makePackedBuffer(2, 2, 6, 3));
    expectTrue(rgb.isValid(), "valid rgb24");

    VideoFrame bgr = rgb;
    bgr.pixelFormat = PixelFormat::BGR24;
    expectTrue(bgr.isValid(), "valid bgr24");

    VideoFrame bgra = rgb;
    bgra.stride = 8;
    bgra.pixelFormat = PixelFormat::BGRA32;
    bgra.buffer = FrameBuffer::copyFrom(makePackedBuffer(2, 2, 8, 4).data(), 16);
    expectTrue(bgra.isValid(), "valid bgra32");

    VideoFrame gray = rgb;
    gray.stride = 2;
    gray.pixelFormat = PixelFormat::Gray8;
    gray.buffer = FrameBuffer::copyFrom(makePackedBuffer(2, 2, 2, 1).data(), 4);
    expectTrue(gray.isValid(), "valid gray8");

    VideoFrame nv12 = rgb;
    nv12.stride = 2;
    nv12.pixelFormat = PixelFormat::NV12;
    nv12.buffer = FrameBuffer::copyFrom(makePackedBuffer(2, 2, 2, 2).data(), 6);
    expectTrue(nv12.isValid(), "valid nv12");

    VideoFrame i420 = rgb;
    i420.stride = 2;
    i420.pixelFormat = PixelFormat::I420;
    i420.buffer = FrameBuffer::copyFrom(std::vector<std::uint8_t>(6, 1).data(), 6);
    expectTrue(i420.isValid(), "valid i420");

    VideoFrame yv12 = i420;
    yv12.pixelFormat = PixelFormat::YV12;
    expectTrue(yv12.isValid(), "valid yv12");

    VideoFrame invalid = rgb;
    invalid.buffer.reset();
    expectFalse(invalid.isValid(), "null buffer rejected");

    invalid = rgb;
    invalid.width = 0;
    expectFalse(invalid.isValid(), "zero width rejected");

    invalid = rgb;
    invalid.stride = 1;
    expectFalse(invalid.isValid(), "insufficient stride rejected");

    invalid = rgb;
    invalid.buffer = FrameBuffer::allocate(1);
    expectFalse(invalid.isValid(), "insufficient buffer rejected");

    invalid = rgb;
    invalid.streamId.clear();
    expectFalse(invalid.isValid(), "empty stream rejected");
}

void testGuardVisionLifecycle() {
    GuardVision gv;

    GuardVisionConfig badConfig{};
    badConfig.maxStreams = 0;
    expectFalse(gv.initialize(badConfig).ok, "invalid config rejected");

    GuardVisionConfig config{};
    config.maxStreams = 2;
    expectTrue(gv.initialize(config).ok, "initialize succeeds");
    expectTrue(gv.isInitialized(), "initialized flag");
    expectFalse(gv.initialize(config).ok, "duplicate initialize rejected");

    StreamConfig stream = makeStreamConfig("camera-a", "Camera A");
    expectTrue(gv.registerStream(stream).ok, "register stream");
    expectFalse(gv.registerStream(stream).ok, "duplicate stream rejected");

    auto frame = makeRgbFrame("camera-a", 4, 4, 12, 0, 0, makePackedBuffer(4, 4, 12, 3));
    SubmitResult accepted = gv.submitFrame(frame);
    expectTrue(accepted.accepted, "valid submission accepted");

    frame.sequence = 1;
    frame.timestampMs = 10;
    accepted = gv.submitFrame(frame);
    expectTrue(accepted.accepted, "second submission accepted");

    frame.streamId = "missing";
    SubmitResult missing = gv.submitFrame(frame);
    expectTrue(missing.status == SubmitStatus::StreamNotRegistered, "unregistered stream rejected");

    expectTrue(gv.unregisterStream("camera-a").ok, "unregister stream");
    frame.streamId = "camera-a";
    missing = gv.submitFrame(frame);
    expectTrue(missing.status == SubmitStatus::StreamNotRegistered, "submit after unregister rejected");

    expectTrue(gv.registerStream(stream).ok, "register again");
    frame.sequence = 0;
    frame.timestampMs = 0;
    accepted = gv.submitFrame(frame);
    expectTrue(accepted.accepted, "submit after re-register accepted");

    GuardVision limited;
    GuardVisionConfig limitedConfig{};
    limitedConfig.maxStreams = 1;
    expectTrue(limited.initialize(limitedConfig).ok, "limited initialize");
    expectTrue(limited.registerStream(makeStreamConfig("s1")).ok, "first limited stream");
    expectFalse(limited.registerStream(makeStreamConfig("s2")).ok, "maximum stream count enforced");
    expectFalse(limited.unregisterStream("missing").ok, "unknown stream rejected");

    GuardVision fresh;
    frame.streamId = "camera-a";
    missing = fresh.submitFrame(frame);
    expectTrue(missing.status == SubmitStatus::NotInitialized, "submit before initialize rejected");

    gv.shutdown();
    expectFalse(gv.isInitialized(), "shutdown clears initialized");
    gv.shutdown();
    missing = gv.submitFrame(frame);
    expectTrue(missing.status == SubmitStatus::NotInitialized, "submit after shutdown rejected");
}

void testProcessExitShutdown() {
    GuardVision gv;
    GuardVisionConfig config{};
    config.maxStreams = 2;
    expectTrue(gv.initialize(config).ok, "process-exit init");
    expectTrue(gv.registerStream(makeStreamConfig("process-exit-a")).ok, "process-exit first stream");
    expectTrue(gv.registerStream(makeStreamConfig("process-exit-b")).ok, "process-exit second stream");

    const auto bytes = makePackedBuffer(16, 16, 48, 3);
    for (std::uint64_t sequence = 0; sequence < 64; ++sequence) {
        expectTrue(gv.submitFrame(makeRgbFrame("process-exit-a", 16, 16, 48, sequence, static_cast<std::int64_t>(sequence), bytes)).accepted,
                   "process-exit active submission a");
        expectTrue(gv.submitFrame(makeRgbFrame("process-exit-b", 16, 16, 48, sequence, static_cast<std::int64_t>(sequence), bytes)).accepted,
                   "process-exit active submission b");
    }

    gv.shutdown(ShutdownMode::ProcessExit);
    expectFalse(gv.isInitialized(), "process-exit shutdown clears initialized");
    gv.shutdown(ShutdownMode::ProcessExit);
    const SubmitResult after = gv.submitFrame(makeRgbFrame("process-exit-a", 16, 16, 48, 65, 65, bytes));
    expectTrue(after.status == SubmitStatus::NotInitialized, "process-exit rejects later submissions");
}

class LifetimeListener final : public IGuardVisionEventListener {
public:
    explicit LifetimeListener(std::shared_ptr<int> destructionCount) : destructionCount_(std::move(destructionCount)) {}
    ~LifetimeListener() override {
        ++(*destructionCount_);
    }

private:
    std::shared_ptr<int> destructionCount_;
};

void testOwnedListenerLifetime() {
    GuardVision gv;
    GuardVisionConfig config{};
    expectTrue(gv.initialize(config).ok, "owned listener init");

    auto destructionCount = std::make_shared<int>(0);
    auto listener = std::make_shared<LifetimeListener>(destructionCount);
    std::weak_ptr<LifetimeListener> weakListener = listener;
    gv.setEventListener(listener);
    listener.reset();
    expectFalse(weakListener.expired(), "shared listener retained by GuardVision");

    gv.clearEventListener();
    expectTrue(weakListener.expired(), "shared listener released after clear");
    expectTrue(*destructionCount == 1, "shared listener destroyed once");
    gv.shutdown();
}

void testSubmissionPolicy() {
    GuardVision gv;
    GuardVisionConfig config{};
    expectTrue(gv.initialize(config).ok, "policy init");
    expectTrue(gv.registerStream(makeStreamConfig("policy")).ok, "policy register");

    auto frame = makeRgbFrame("policy", 2, 2, 6, 1, 100, makePackedBuffer(2, 2, 6, 3));
    expectTrue(gv.submitFrame(frame).accepted, "policy first frame");

    frame.sequence = 0;
    SubmitResult seq = gv.submitFrame(frame);
    expectTrue(seq.status == SubmitStatus::InvalidSequence, "decreasing sequence rejected");

    frame.sequence = 2;
    frame.timestampMs = 50;
    SubmitResult ts = gv.submitFrame(frame);
    expectTrue(ts.status == SubmitStatus::InvalidTimestamp, "decreasing timestamp rejected");

    frame.sequence = 2;
    frame.timestampMs = 100;
    expectTrue(gv.submitFrame(frame).accepted, "equal sequence with equal timestamp accepted");
    gv.shutdown();
}

void testSubmitPerformance() {
    GuardVision gv;
    GuardVisionConfig config{};
    config.maxStreams = 1;
    expectTrue(gv.initialize(config).ok, "performance init");
    expectTrue(gv.registerStream(makeStreamConfig("perf")).ok, "performance register");

    auto frame = makeRgbFrame("perf", 64, 64, 192, 0, 0, makePackedBuffer(64, 64, 192, 3));

    const auto start = std::chrono::steady_clock::now();
    for (std::uint64_t i = 0; i < 10000; ++i) {
        VideoFrame submission = frame;
        submission.sequence = i;
        submission.timestampMs = static_cast<std::int64_t>(i);
        const SubmitResult result = gv.submitFrame(std::move(submission));
        expectTrue(result.accepted, "performance submission accepted");
    }
    const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start);
    std::cout << "benchmark submitFrame x10000: " << elapsed.count() << " ms\n";

    const std::vector<std::uint8_t> source(static_cast<std::size_t>(1920 * 1080 * 3), 7);
    const auto copyStart = std::chrono::steady_clock::now();
    for (int i = 0; i < 100; ++i) {
        const auto copied = FrameBuffer::copyFrom(source.data(), source.size());
        expectTrue(copied && copied->sizeBytes() == source.size(), "performance copyFrom");
    }
    const auto copyElapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - copyStart);
    std::cout << "benchmark FrameBuffer::copyFrom 1080p x100: " << copyElapsed.count() << " ms\n";
    gv.shutdown();
}

}  // namespace

int runTask3Tests();
int runTask4Tests();

int runTask5Tests();

int runTask6Tests();
int runTask7Tests();

int main() {
    std::cout.setf(std::ios::unitbuf);
    testGeometry();
    testFrameBuffer();
    testVideoFrame();
    testGuardVisionLifecycle();
    testProcessExitShutdown();
    testOwnedListenerLifetime();
    testSubmissionPolicy();
    testSubmitPerformance();

    g_failures += runTask3Tests();
    g_failures += runTask4Tests();
    g_failures += runTask5Tests();
    g_failures += runTask6Tests();
    g_failures += runTask7Tests();

    if (g_failures == 0) {
        std::cout << "guardvision_tests: PASS\n";
        return 0;
    }

    std::cerr << "guardvision_tests: FAIL (" << g_failures << " failures)\n";
    return 1;
}
