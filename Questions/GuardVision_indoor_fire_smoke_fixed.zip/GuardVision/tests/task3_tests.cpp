#include <atomic>
#include <chrono>
#include <condition_variable>
#include <iostream>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>

#include <frame/FrameBuffer.h>
#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <core/StreamState.h>
#include <core/SubmitResult.h>
#include <frame/VideoFrame.h>

#include "events/EventDispatcher.h"
#include "events/EventListenerRegistry.h"
#include "frame/LatestFrameStore.h"
#include "scheduling/FrameScheduler.h"
#include "scheduling/LatestFrameSlot.h"

namespace {

using namespace guardvision;

int g_task3Failures = 0;

void expectTrue(bool condition, const char* message) {
    if (!condition) {
        ++g_task3Failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}

void expectFalse(bool condition, const char* message) {
    expectTrue(!condition, message);
}

StreamConfig makeStreamConfig(const std::string& streamId, const std::string& displayName = {}) {
    StreamConfig config;
    config.streamId = streamId;
    config.displayName = displayName;
    return config;
}

VideoFrame makeFrame(const std::string& streamId, std::uint64_t sequence) {
    VideoFrame frame;
    frame.streamId = streamId;
    frame.width = 2;
    frame.height = 2;
    frame.stride = 6;
    frame.sequence = sequence;
    frame.timestampMs = static_cast<std::int64_t>(sequence);
    frame.pixelFormat = PixelFormat::RGB24;
    frame.buffer = FrameBuffer::copyFrom(std::vector<std::uint8_t>(24, 1).data(), 24);
    return frame;
}

void testLatestFrameSlot() {
    LatestFrameSlot slot;
    expectFalse(slot.hasPending(), "slot empty");

    FrameRoutingJob first;
    first.token = StreamToken{"s1", 1};
    expectTrue(slot.replace(std::move(first)) == ReplaceResult::Inserted, "slot insert");

    FrameRoutingJob second;
    second.token = StreamToken{"s1", 1};
    expectTrue(slot.replace(std::move(second)) == ReplaceResult::ReplacedPending, "slot replace");

    auto taken = slot.take();
    expectTrue(taken.has_value(), "slot take");
    expectFalse(slot.hasPending(), "slot empty after take");
    slot.clear();
}

void testLatestFrameStore() {
    LatestFrameStore store;
    StreamToken token{"s1", 1};
    store.update(token, makeFrame("s1", 1));
    expectTrue(store.get(token).has_value(), "store get");
    store.update(token, makeFrame("s1", 2));
    expectTrue(store.get(token)->sequence == 2, "store replace");
    store.remove(token);
    expectFalse(store.get(token).has_value(), "store remove");
    store.clear();
}

void testEventDispatcher() {
    auto registry = std::make_shared<EventListenerRegistry>();
    EventDispatcher dispatcher(8, [registry]() { return registry->acquire(); });

    for (int i = 0; i < 4; ++i) {
        RuntimeEvent event;
        event.type = RuntimeEventType::StreamStatus;
        event.status.streamId = "s";
        dispatcher.post(std::move(event));
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    dispatcher.stop();
    dispatcher.join();
    expectTrue(dispatcher.dispatchedEvents() + dispatcher.droppedEvents() == 4, "dispatcher accounts for posted status events");
}

void waitForProcessed(GuardVision& gv, const std::string& streamId, std::uint64_t minimum) {
    for (int i = 0; i < 200; ++i) {
        StreamMetrics metrics;
        if (gv.getStreamMetrics(streamId, metrics).ok && metrics.processedFrames >= minimum) {
            return;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void testAsyncSubmissionAndGeneration() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "task3 init");

    expectTrue(gv.registerStream(makeStreamConfig("generation-test")).ok, "register gen test");
    auto frame = makeFrame("generation-test", 0);
    expectTrue(gv.submitFrame(std::move(frame)).accepted, "submit gen test");
    waitForProcessed(gv, "generation-test", 1);

    expectTrue(gv.unregisterStream("generation-test").ok, "unregister gen test");
    expectTrue(gv.registerStream(makeStreamConfig("generation-test")).ok, "re-register gen test");

    StreamStatus status;
    expectTrue(gv.getStreamStatus("generation-test", status).ok, "status after re-register");
    expectTrue(status.generation >= 2, "generation incremented");

    frame = makeFrame("generation-test", 0);
    expectTrue(gv.submitFrame(std::move(frame)).accepted, "submit after re-register");
    waitForProcessed(gv, "generation-test", 1);

    gv.shutdown();
}

void testLatestFrameStoreGenerationMismatch() {
    LatestFrameStore store;
    StreamToken tokenV1{"s1", 1};
    StreamToken tokenV2{"s1", 2};
    store.update(tokenV1, makeFrame("s1", 10));
    store.remove(tokenV1);
    store.update(tokenV2, makeFrame("s1", 20));
    expectFalse(store.get(tokenV1).has_value(), "removed generation not retained");
    expectTrue(store.get(tokenV2)->sequence == 20, "new generation retained");
    store.remove(tokenV2);
}

class TestListener : public IGuardVisionEventListener {
public:
    std::atomic<int> statusEvents{0};
    std::atomic<int> processedEvents{0};

    void onStreamStatus(const StreamStatus& /*status*/) override {
        statusEvents.fetch_add(1);
    }
    void onFrameProcessed(const FrameProcessedEvent& /*event*/) override {
        processedEvents.fetch_add(1);
    }
};

void testEventDispatcherWithListener() {
    TestListener listener;
    auto registry = std::make_shared<EventListenerRegistry>();
    registry->setListener(&listener);
    EventDispatcher dispatcher(4, [registry]() { return registry->acquire(); });

    for (int i = 0; i < 6; ++i) {
        RuntimeEvent event;
        event.type = RuntimeEventType::FrameProcessed;
        event.frameProcessed.streamId = "s";
        dispatcher.post(std::move(event));
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    dispatcher.stop();
    dispatcher.join();
    expectTrue(listener.processedEvents.load() > 0, "listener receives queued frame events");
    expectTrue(dispatcher.dispatchedEvents() + dispatcher.droppedEvents() == 6, "dispatcher accounts for every posted event");
}

class ThrowingListener : public IGuardVisionEventListener {
public:
    std::atomic<int> calls{0};
    bool throwOnFirst = true;

    void onFrameProcessed(const FrameProcessedEvent& /*event*/) override {
        const int call = calls.fetch_add(1);
        if (throwOnFirst && call == 0) {
            throw std::runtime_error("listener failure");
        }
    }
};

void testEventDispatcherListenerExceptionSafety() {
    ThrowingListener listener;
    auto registry = std::make_shared<EventListenerRegistry>();
    registry->setListener(&listener);
    EventDispatcher dispatcher(8, [registry]() { return registry->acquire(); });

    for (int i = 0; i < 2; ++i) {
        RuntimeEvent event;
        event.type = RuntimeEventType::FrameProcessed;
        event.frameProcessed.streamId = "throwing";
        dispatcher.post(std::move(event));
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    dispatcher.stop();
    dispatcher.join();
    expectTrue(listener.calls.load() >= 2, "dispatcher continues after listener exception");
    expectTrue(dispatcher.listenerFailures() == 1, "listener failure counted once");
}

class BlockingListener : public IGuardVisionEventListener {
public:
    std::mutex mutex;
    std::condition_variable enteredCv;
    std::condition_variable releaseCv;
    bool entered = false;
    bool release = false;
    std::atomic<int> callbacks{0};

    void onFrameProcessed(const FrameProcessedEvent& /*event*/) override {
        {
            std::lock_guard<std::mutex> lock(mutex);
            entered = true;
            callbacks.fetch_add(1);
        }
        enteredCv.notify_all();
        std::unique_lock<std::mutex> lock(mutex);
        releaseCv.wait(lock, [this]() { return release; });
    }

    void allowReturn() {
        {
            std::lock_guard<std::mutex> lock(mutex);
            release = true;
        }
        releaseCv.notify_all();
    }
};

void testEventDispatcherDetachWaitsForActiveCallback() {
    BlockingListener listener;
    auto registry = std::make_shared<EventListenerRegistry>();
    registry->setListener(&listener);
    EventDispatcher dispatcher(8, [registry]() { return registry->acquire(); });

    RuntimeEvent event;
    event.type = RuntimeEventType::FrameProcessed;
    event.frameProcessed.streamId = "blocking";
    dispatcher.post(std::move(event));

    {
        std::unique_lock<std::mutex> lock(listener.mutex);
        listener.enteredCv.wait_for(lock, std::chrono::seconds(2), [&]() { return listener.entered; });
    }

    std::atomic<bool> detached{false};
    std::thread detachThread([&]() {
        registry->setListener(nullptr);
        detached = true;
    });
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    expectFalse(detached.load(), "detach waits for active callback");
    listener.allowReturn();
    detachThread.join();
    expectTrue(detached.load(), "detach completes after callback");

    RuntimeEvent late;
    late.type = RuntimeEventType::FrameProcessed;
    late.frameProcessed.streamId = "late";
    dispatcher.post(std::move(late));
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    dispatcher.stop();
    dispatcher.join();
    expectTrue(listener.callbacks.load() == 1, "detached listener receives no new callbacks");
}

class SelfDetachingListener : public IGuardVisionEventListener {
public:
    explicit SelfDetachingListener(std::shared_ptr<EventListenerRegistry> registry) : registry_(std::move(registry)) {}

    std::atomic<int> callbacks{0};
    std::atomic<bool> detached{false};

    void onFrameProcessed(const FrameProcessedEvent& /*event*/) override {
        callbacks.fetch_add(1);
        registry_->setListener(nullptr);
        detached = true;
    }

private:
    std::shared_ptr<EventListenerRegistry> registry_;
};

void testEventDispatcherSelfDetachDoesNotDeadlock() {
    auto registry = std::make_shared<EventListenerRegistry>();
    SelfDetachingListener listener(registry);
    registry->setListener(&listener);
    EventDispatcher dispatcher(8, [registry]() { return registry->acquire(); });

    RuntimeEvent first;
    first.type = RuntimeEventType::FrameProcessed;
    first.frameProcessed.streamId = "self-detach";
    dispatcher.post(std::move(first));

    for (int i = 0; i < 200 && !listener.detached.load(); ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    expectTrue(listener.detached.load(), "listener can detach itself without deadlock");

    RuntimeEvent late;
    late.type = RuntimeEventType::FrameProcessed;
    late.frameProcessed.streamId = "after-self-detach";
    dispatcher.post(std::move(late));
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    dispatcher.stop();
    dispatcher.join();
    expectTrue(listener.callbacks.load() == 1, "self-detached listener receives no later callback");
}

void testEventDispatcherDropCountedOnce() {
    BlockingListener listener;
    auto registry = std::make_shared<EventListenerRegistry>();
    registry->setListener(&listener);
    EventDispatcher dispatcher(1, [registry]() { return registry->acquire(); });

    RuntimeEvent blocking;
    blocking.type = RuntimeEventType::FrameProcessed;
    blocking.frameProcessed.streamId = "blocking-drop";
    dispatcher.post(std::move(blocking));
    {
        std::unique_lock<std::mutex> lock(listener.mutex);
        listener.enteredCv.wait_for(lock, std::chrono::seconds(2), [&]() { return listener.entered; });
    }

    RuntimeEvent queued;
    queued.type = RuntimeEventType::FrameProcessed;
    queued.frameProcessed.streamId = "queued";
    expectTrue(dispatcher.post(std::move(queued)), "first queued update fits capacity");

    RuntimeEvent dropped;
    dropped.type = RuntimeEventType::FrameProcessed;
    dropped.frameProcessed.streamId = "dropped";
    expectFalse(dispatcher.post(std::move(dropped)), "second queued update is dropped");
    expectTrue(dispatcher.droppedEvents() == 1, "one rejected update increments drop metric once");

    listener.allowReturn();
    registry->setListener(nullptr);
    dispatcher.stop();
    dispatcher.join();
}

class ShutdownFromCallbackListener : public IGuardVisionEventListener {
public:
    explicit ShutdownFromCallbackListener(GuardVision* guardVision) : guardVision_(guardVision) {}

    std::atomic<bool> shutdownReturned{false};

    void onFrameProcessed(const FrameProcessedEvent& /*event*/) override {
        guardVision_->shutdown();
        shutdownReturned = true;
    }

private:
    GuardVision* guardVision_ = nullptr;
};

void testShutdownFromCallbackDoesNotDeadlock() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(guardVision.initialize(config).ok, "callback shutdown init");

    ShutdownFromCallbackListener listener(&guardVision);
    guardVision.setEventListener(&listener);
    expectTrue(guardVision.registerStream(makeStreamConfig("callback-shutdown")).ok, "callback shutdown stream");
    expectTrue(guardVision.submitFrame(makeFrame("callback-shutdown", 1)).accepted, "callback shutdown frame");

    for (int i = 0; i < 400 && !listener.shutdownReturned.load(); ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    expectTrue(listener.shutdownReturned.load(), "shutdown returns when called by listener callback");

    // Finalize the deferred dispatcher join from a non-dispatch thread.
    guardVision.shutdown();
}

void testFrameSchedulerLatestAndFairness() {
    std::mutex processedMutex;
    std::vector<std::uint64_t> processedSequences;
    std::atomic<int> processedCount{0};
    FrameScheduler* schedulerPtr = nullptr;

    FrameScheduler scheduler(16, [&](FrameRoutingJob job) {
        {
            std::lock_guard<std::mutex> lock(processedMutex);
            processedSequences.push_back(job.frame.sequence);
        }
        processedCount.fetch_add(1);
        schedulerPtr->complete(job.token, true);
    });
    schedulerPtr = &scheduler;

    scheduler.registerStream({"fast", 1});
    scheduler.registerStream({"slow", 1});

    FrameRoutingJob fastJob;
    fastJob.token = {"fast", 1};
    fastJob.frame = makeFrame("fast", 100);
    scheduler.submit(std::move(fastJob));

    FrameRoutingJob fastReplace;
    fastReplace.token = {"fast", 1};
    fastReplace.frame = makeFrame("fast", 103);
    const auto replaceResult = scheduler.submit(std::move(fastReplace));
    expectTrue(replaceResult.replacedPending, "scheduler replaced pending");

    FrameRoutingJob slowJob;
    slowJob.token = {"slow", 1};
    slowJob.frame = makeFrame("slow", 1);
    scheduler.submit(std::move(slowJob));

    scheduler.startWorkers(1);

    for (int i = 0; i < 300 && processedCount.load() < 2; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    scheduler.stop();
    scheduler.joinWorkers();

    expectTrue(processedCount.load() >= 2, "both streams processed");
    bool sawLatestFast = false;
    {
        std::lock_guard<std::mutex> lock(processedMutex);
        for (const auto seq : processedSequences) {
            if (seq == 103) {
                sawLatestFast = true;
            }
            expectFalse(seq == 100, "replaced fast frame not processed");
        }
    }
    expectTrue(sawLatestFast, "latest fast frame processed");
}

void testMetricsAndLifecycle() {
    GuardVision gv;
    GuardVisionConfig config;
    config.maxStreams = 2;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "metrics init");
    expectTrue(gv.registerStream(makeStreamConfig("metrics-a")).ok, "register metrics-a");
    expectTrue(gv.registerStream(makeStreamConfig("metrics-b")).ok, "register metrics-b");
    expectFalse(gv.registerStream(makeStreamConfig("metrics-a")).ok, "duplicate register rejected");

    expectTrue(gv.submitFrame(makeFrame("metrics-a", 1)).accepted, "metrics submit");
    waitForProcessed(gv, "metrics-a", 1);

    StreamMetrics streamMetrics;
    expectTrue(gv.getStreamMetrics("metrics-a", streamMetrics).ok, "stream metrics");
    expectTrue(streamMetrics.submittedFrames >= 1, "submitted metric");
    expectTrue(streamMetrics.processedFrames >= 1, "processed metric");

    RuntimeMetrics runtime = gv.getRuntimeMetrics();
    expectTrue(runtime.activeStreams == 2, "active stream metric");

    expectTrue(gv.unregisterStream("metrics-a").ok, "unregister metrics-a");
    expectFalse(gv.getStreamMetrics("metrics-a", streamMetrics).ok, "removed stream metrics missing");
    gv.shutdown();
}

void testFairnessPublicApi() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "fairness init");

    for (int i = 1; i <= 4; ++i) {
        expectTrue(gv.registerStream(makeStreamConfig("synthetic-" + std::to_string(i))).ok, "fairness register");
    }

    for (int round = 0; round < 40; ++round) {
        for (int i = 1; i <= 4; ++i) {
            const std::string streamId = "synthetic-" + std::to_string(i);
            for (int burst = 0; burst < (i == 1 ? 5 : 1); ++burst) {
                gv.submitFrame(makeFrame(streamId, static_cast<std::uint64_t>(round * 10 + burst)));
            }
        }
    }

    for (int i = 1; i <= 4; ++i) {
        waitForProcessed(gv, "synthetic-" + std::to_string(i), 1);
        StreamMetrics metrics;
        expectTrue(gv.getStreamMetrics("synthetic-" + std::to_string(i), metrics).ok, "fairness metrics");
        expectTrue(metrics.processedFrames >= 1, "stream received processing opportunity");
    }

    gv.shutdown();
}

void testRemovalUnderLoad() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "removal init");
    for (int i = 1; i <= 4; ++i) {
        expectTrue(gv.registerStream(makeStreamConfig("load-" + std::to_string(i))).ok, "removal register");
    }

    for (int i = 0; i < 30; ++i) {
        for (int s = 1; s <= 4; ++s) {
            gv.submitFrame(makeFrame("load-" + std::to_string(s), static_cast<std::uint64_t>(i)));
        }
    }

    expectTrue(gv.unregisterStream("load-2").ok, "removal under load");
    const SubmitResult rejected = gv.submitFrame(makeFrame("load-2", 999));
    expectFalse(rejected.accepted, "removed stream rejects frames");

    waitForProcessed(gv, "load-1", 1);
    waitForProcessed(gv, "load-3", 1);
    gv.shutdown();
}

void testShutdownUnderLoad() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 2;
    expectTrue(gv.initialize(config).ok, "shutdown init");
    for (int i = 1; i <= 4; ++i) {
        expectTrue(gv.registerStream(makeStreamConfig("shutdown-" + std::to_string(i))).ok, "shutdown register");
    }

    for (int i = 0; i < 100; ++i) {
        for (int s = 1; s <= 4; ++s) {
            gv.submitFrame(makeFrame("shutdown-" + std::to_string(s), static_cast<std::uint64_t>(i)));
        }
    }

    gv.shutdown();
    expectFalse(gv.isInitialized(), "shutdown marks uninitialized");
}

void testMultipleGuardVisionInstancesShutdownIndependently() {
    GuardVision first;
    GuardVision second;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;

    expectTrue(first.initialize(config).ok, "first multi-instance init");
    expectTrue(second.initialize(config).ok, "second multi-instance init");
    expectTrue(first.registerStream(makeStreamConfig("first-instance")).ok, "first multi-instance stream");
    expectTrue(second.registerStream(makeStreamConfig("second-instance")).ok, "second multi-instance stream");

    first.shutdown();
    expectTrue(second.submitFrame(makeFrame("second-instance", 1)).accepted, "second instance remains operational after first shutdown");
    waitForProcessed(second, "second-instance", 1);
    second.shutdown();
}

void testReplacementStatus() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "replacement init");
    expectTrue(gv.registerStream(makeStreamConfig("replace-test")).ok, "replacement register");

#if defined(GUARDVISION_TEST_HOOKS)
    _putenv("GUARDVISION_TEST_FRAME_PROCESSING_DELAY_MS=50");
#endif

    SubmitResult first = gv.submitFrame(makeFrame("replace-test", 1));
    expectTrue(first.accepted, "first accepted");
    SubmitResult second = gv.submitFrame(makeFrame("replace-test", 2));
    expectTrue(second.accepted, "second accepted");
#if defined(GUARDVISION_TEST_HOOKS)
    expectTrue(second.status == SubmitStatus::ReplacedOlderPendingFrame || second.status == SubmitStatus::Accepted,
               "replacement status when delayed");
#endif

    waitForProcessed(gv, "replace-test", 1);
    StreamMetrics metrics;
    expectTrue(gv.getStreamMetrics("replace-test", metrics).ok, "replacement metrics");
    expectTrue(metrics.submittedFrames >= 2, "replacement submitted count");

#if defined(GUARDVISION_TEST_HOOKS)
    _putenv("GUARDVISION_TEST_FRAME_PROCESSING_DELAY_MS=");
#endif
    gv.shutdown();
}

}  // namespace

int runTask3Tests() {
    testLatestFrameSlot();
    testLatestFrameStore();
    testLatestFrameStoreGenerationMismatch();
    testEventDispatcher();
    testEventDispatcherWithListener();
    testEventDispatcherListenerExceptionSafety();
    testEventDispatcherDetachWaitsForActiveCallback();
    testEventDispatcherSelfDetachDoesNotDeadlock();
    testEventDispatcherDropCountedOnce();
    testShutdownFromCallbackDoesNotDeadlock();
    testFrameSchedulerLatestAndFairness();
    testMetricsAndLifecycle();
    testAsyncSubmissionAndGeneration();
    testFairnessPublicApi();
    testRemovalUnderLoad();
    testShutdownUnderLoad();
    testMultipleGuardVisionInstancesShutdownIndependently();
    testReplacementStatus();
    return g_task3Failures;
}
