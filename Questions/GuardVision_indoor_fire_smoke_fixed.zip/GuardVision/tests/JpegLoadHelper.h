#pragma once

#include <cstdint>
#include <string>
#include <vector>

struct JpegImage {
    int width = 0;
    int height = 0;
    std::vector<std::uint8_t> bgr;
};

bool loadJpegAsBgr(const std::string& path, JpegImage& output, std::string* errorMessage);
