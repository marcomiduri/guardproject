#include <algorithm>
#include <chrono>
#include <cstring>
#include <functional>
#include <iostream>
#include <thread>
#include <vector>

#include <frame/FrameBuffer.h>
#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <motion/MotionConfig.h>
#include <motion/MotionTypes.h>
#include <frame/VideoFrame.h>

#include "motion/LumaConverter.h"
#include "motion/MotionAnalyzer.h"
#include "motion/MotionRegionExtractor.h"
#include "motion/MotionStateMachine.h"
#include "motion/MotionStreamState.h"

namespace {

using namespace guardvision;

int g_failures = 0;

void expectTrue(bool condition, const char* message) {
    if (!condition) {
        ++g_failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}

void expectFalse(bool condition, const char* message) {
    expectTrue(!condition, message);
}

StreamConfig makeStreamConfig(const std::string& streamId, const std::string& displayName, const MotionConfig& motion) {
    StreamConfig config;
    config.streamId = streamId;
    config.displayName = displayName;
    config.motion = motion;
    return config;
}

VideoFrame makeGrayFrame(const std::string& streamId, int width, int height, std::uint64_t sequence, std::uint8_t fillValue) {
    VideoFrame frame;
    frame.streamId = streamId;
    frame.width = width;
    frame.height = height;
    frame.stride = width;
    frame.sequence = sequence;
    frame.timestampMs = static_cast<std::int64_t>(sequence * 100);
    frame.pixelFormat = PixelFormat::Gray8;
    std::vector<std::uint8_t> data(static_cast<std::size_t>(width * height), fillValue);
    frame.buffer = FrameBuffer::copyFrom(data.data(), data.size());
    return frame;
}

void fillRectGray(VideoFrame& frame, int x, int y, int w, int h, std::uint8_t value) {
    std::vector<std::uint8_t> data(frame.buffer->data(), frame.buffer->data() + frame.buffer->sizeBytes());
    for (int row = y; row < y + h; ++row) {
        for (int col = x; col < x + w; ++col) {
            data[static_cast<std::size_t>(row * frame.stride + col)] = value;
        }
    }
    frame.buffer = FrameBuffer::copyFrom(data.data(), data.size());
}

VideoFrame makeFormatFrame(PixelFormat format, const std::string& streamId, int width, int height, std::uint64_t sequence) {
    VideoFrame frame;
    frame.streamId = streamId;
    frame.width = width;
    frame.height = height;
    frame.sequence = sequence;
    frame.timestampMs = static_cast<std::int64_t>(sequence * 100);
    frame.pixelFormat = format;

    switch (format) {
        case PixelFormat::RGB24:
        case PixelFormat::BGR24:
            frame.stride = width * 3;
            break;
        case PixelFormat::BGRA32:
            frame.stride = width * 4;
            break;
        case PixelFormat::Gray8:
        case PixelFormat::NV12:
        case PixelFormat::I420:
        case PixelFormat::YV12:
            frame.stride = width;
            break;
        default:
            return frame;
    }

    const std::size_t size = minimumBufferSize(width, height, frame.stride, format);
    std::vector<std::uint8_t> data(size, 80);
    frame.buffer = FrameBuffer::copyFrom(data.data(), data.size());
    return frame;
}

bool testLumaForFormat(PixelFormat format) {
    MotionStreamState state;
    state.config.enabled = true;
    state.config.maximumAnalysisWidth = 64;
    state.config.maximumAnalysisHeight = 64;
    VideoFrame frame = makeFormatFrame(format, "fmt", 32, 24, 1);
    if (!frame.isValid()) {
        return false;
    }
    std::vector<std::uint8_t> luma;
    LumaConversionResult conversion;
    return extractAnalysisLuma(frame, state.config, state, luma, conversion) && conversion.analysisWidth > 0 && conversion.analysisHeight > 0;
}

void testMotionConfigValidation() {
    MotionConfig config;
    expectTrue(isValidMotionConfig(config), "default disabled config");
    config.enabled = true;
    expectTrue(isValidMotionConfig(config), "enabled default config");
    config.startChangedAreaRatio = 0.005;
    expectFalse(isValidMotionConfig(config), "start below continue rejected");
    config.startChangedAreaRatio = 0.02;
    config.continueChangedAreaRatio = 1.5;
    expectFalse(isValidMotionConfig(config), "ratio above 1 rejected");
    config.continueChangedAreaRatio = 0.01;
    config.activationFrameCount = 0;
    expectFalse(isValidMotionConfig(config), "activation below 1 rejected");
}

void testLumaConversionGray8() {
    expectTrue(testLumaForFormat(PixelFormat::Gray8), "gray8 luma");
}

void testLumaConversionAllFormats() {
    expectTrue(testLumaForFormat(PixelFormat::RGB24), "rgb24 luma");
    expectTrue(testLumaForFormat(PixelFormat::BGR24), "bgr24 luma");
    expectTrue(testLumaForFormat(PixelFormat::BGRA32), "bgra32 luma");
    expectTrue(testLumaForFormat(PixelFormat::NV12), "nv12 luma");
    expectTrue(testLumaForFormat(PixelFormat::I420), "i420 luma");
    expectTrue(testLumaForFormat(PixelFormat::YV12), "yv12 luma");
}

void testRoiLumaMapping() {
    MotionStreamState state;
    state.config.enabled = true;
    state.config.useRoi = true;
    state.config.roi = NormalizedRect{0.25, 0.25, 0.5, 0.5};
    state.config.maximumAnalysisWidth = 64;
    state.config.maximumAnalysisHeight = 64;
    VideoFrame frame = makeGrayFrame("roi", 160, 120, 1, 50);
    std::vector<std::uint8_t> luma;
    LumaConversionResult conversion;
    expectTrue(extractAnalysisLuma(frame, state.config, state, luma, conversion), "roi luma");
    expectTrue(conversion.analysisAreaFullFrame.width == 80 && conversion.analysisAreaFullFrame.height == 60, "roi full-frame mapping");
}

void testDownscaleNoUpscale() {
    Size size = computeAnalysisSize(160, 120, 320, 180);
    expectTrue(size.width == 160 && size.height == 120, "no upscale");
    size = computeAnalysisSize(640, 480, 320, 180);
    expectTrue(size.width <= 320 && size.height <= 180, "downscale bounded");
}

void testMotionComparison() {
    std::vector<std::uint8_t> previous(64, 10);
    std::vector<std::uint8_t> current(64, 80);
    std::vector<std::uint8_t> mask;
    MotionCompareResult result;
    expectTrue(compareLumaFrames(previous, current, 8, 8, 24, mask, result), "compare");
    expectTrue(result.changedAreaRatio > 0.0, "changed ratio");
    expectTrue(compareLumaFrames(previous, previous, 8, 8, 24, mask, result), "identical");
    expectTrue(result.changedAreaRatio == 0.0, "identical ratio");
}

void testRegionExtraction() {
    std::vector<std::uint8_t> mask(64, 0);
    for (int i = 0; i < 32; ++i) {
        mask[static_cast<std::size_t>(i)] = 1;
    }
    int truncated = 0;
    MotionConfig config;
    config.enabled = true;
    config.minimumRegionWidth = 4;
    config.minimumRegionHeight = 4;
    config.minimumRegionArea = 16;
    config.maximumRegionCount = 2;
    Rect analysisArea{0, 0, 320, 240};
    auto regions = extractMotionRegions(mask, 8, 8, config, analysisArea, Size{320, 240}, truncated);
    expectTrue(!regions.empty(), "region extracted");
}

void testStateMachineConfirmation() {
    MotionStreamState state;
    MotionConfig config;
    config.enabled = true;
    config.activationFrameCount = 2;
    config.clearFrameCount = 2;
    config.startChangedAreaRatio = 0.01;
    config.continueChangedAreaRatio = 0.005;
    config.eventUpdateIntervalMs = 0;
    state.config = config;

    MotionStateMachineInput input{state, config, 0.0, 0.0, {}, {}, 0, 0, 0, {}};
    input.changedAreaRatio = 0.02;
    input.score = 0.5;
    input.analysisArea = Rect{0, 0, 100, 100};
    input.timestampMs = 100;
    input.sequence = 1;
    input.generation = 1;
    input.streamId = "s1";

    auto events = updateMotionStateMachine(input);
    expectTrue(events.empty(), "first candidate no started");
    expectTrue(input.state.state == MotionState::Candidate, "candidate");
    input.timestampMs = 200;
    input.sequence = 2;
    events = updateMotionStateMachine(input);
    expectTrue(!events.empty(), "started after confirmation");
    expectTrue(events.front().type == MotionEventType::Started, "started type");
}

void waitForMotion(GuardVision& gv, const std::string& streamId, std::uint64_t minimumStarted) {
    for (int i = 0; i < 300; ++i) {
        MotionMetrics metrics;
        if (gv.getMotionMetrics(streamId, metrics).ok && metrics.startedEvents >= minimumStarted) {
            return;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void testIntegrationMovingObject() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "integration init");

    MotionConfig motion;
    motion.enabled = true;
    motion.analysisIntervalMs = 0;
    motion.activationFrameCount = 1;
    motion.clearFrameCount = 1;
    motion.startChangedAreaRatio = 0.001;
    motion.continueChangedAreaRatio = 0.0005;
    motion.eventUpdateIntervalMs = 0;

    StreamConfig stream;
    stream.streamId = "motion-test";
    stream.motion = motion;
    expectTrue(gv.registerStream(stream).ok, "register motion stream");

    VideoFrame stable = makeGrayFrame("motion-test", 160, 120, 0, 20);
    expectTrue(gv.submitFrame(stable).accepted, "baseline submit");
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    for (std::uint64_t seq = 1; seq <= 3; ++seq) {
        VideoFrame moved = makeGrayFrame("motion-test", 160, 120, seq, 20);
        fillRectGray(moved, 40, 40, 60, 60, static_cast<std::uint8_t>(100 + seq * 20));
        expectTrue(gv.submitFrame(std::move(moved)).accepted, "moved submit");
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    waitForMotion(gv, "motion-test", 1);

    MotionMetrics metrics;
    expectTrue(gv.getMotionMetrics("motion-test", metrics).ok, "metrics");
    expectTrue(metrics.startedEvents >= 1, "started event emitted");
    gv.shutdown();
}

void waitForMetric(GuardVision& gv, const std::string& streamId, const std::function<bool(const MotionMetrics&)>& predicate, int attempts = 300) {
    for (int i = 0; i < attempts; ++i) {
        MotionMetrics metrics;
        if (gv.getMotionMetrics(streamId, metrics).ok && predicate(metrics)) {
            return;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

MotionConfig fastMotionConfig() {
    MotionConfig motion;
    motion.enabled = true;
    motion.analysisIntervalMs = 0;
    motion.activationFrameCount = 1;
    motion.clearFrameCount = 2;
    motion.startChangedAreaRatio = 0.001;
    motion.continueChangedAreaRatio = 0.0005;
    motion.eventUpdateIntervalMs = 0;
    return motion;
}

void testIntegrationStableScene() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "stable init");

    StreamConfig stream = makeStreamConfig("motion-test", "Motion", fastMotionConfig());
    expectTrue(gv.registerStream(stream).ok, "stable register");

    for (std::uint64_t seq = 0; seq < 20; ++seq) {
        VideoFrame frame = makeGrayFrame("motion-test", 160, 120, seq, 30);
        expectTrue(gv.submitFrame(std::move(frame)).accepted, "stable submit");
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    MotionMetrics metrics;
    expectTrue(gv.getMotionMetrics("motion-test", metrics).ok, "stable metrics");
    expectTrue(metrics.baselineFrames >= 1, "baseline created");
    expectTrue(metrics.analyzedFrames >= 5, "frames analyzed");
    expectTrue(metrics.startedEvents == 0, "no false started on stable scene");
    gv.shutdown();
}

void testIntegrationResolutionChange() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "resolution init");

    StreamConfig stream = makeStreamConfig("motion-test", "Motion", fastMotionConfig());
    expectTrue(gv.registerStream(stream).ok, "resolution register");

    VideoFrame baseline = makeGrayFrame("motion-test", 160, 120, 0, 40);
    expectTrue(gv.submitFrame(baseline).accepted, "resolution baseline");
    std::this_thread::sleep_for(std::chrono::milliseconds(150));

    VideoFrame changedSize = makeGrayFrame("motion-test", 320, 240, 1, 40);
    fillRectGray(changedSize, 100, 80, 80, 80, 200);
    expectTrue(gv.submitFrame(std::move(changedSize)).accepted, "resolution change submit");
    std::this_thread::sleep_for(std::chrono::milliseconds(300));

    MotionMetrics metrics;
    expectTrue(gv.getMotionMetrics("motion-test", metrics).ok, "resolution metrics");
    expectTrue(metrics.baselineFrames >= 2, "baseline reset on resolution change");
    expectTrue(metrics.startedEvents == 0, "no immediate started after reset");
    gv.shutdown();
}

void testIntegrationDisableUnderMotion() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "disable init");

    MotionConfig motion = fastMotionConfig();
    StreamConfig stream = makeStreamConfig("motion-test", "Motion", motion);
    expectTrue(gv.registerStream(stream).ok, "disable register");

    VideoFrame baseline = makeGrayFrame("motion-test", 160, 120, 0, 10);
    gv.submitFrame(baseline);
    std::this_thread::sleep_for(std::chrono::milliseconds(150));

    for (std::uint64_t seq = 1; seq <= 4; ++seq) {
        VideoFrame moved = makeGrayFrame("motion-test", 160, 120, seq, 10);
        fillRectGray(moved, 30, 30, 70, 70, static_cast<std::uint8_t>(120 + seq * 10));
        gv.submitFrame(std::move(moved));
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
    }
    waitForMotion(gv, "motion-test", 1);

    MotionConfig disabled = motion;
    disabled.detectionMode = DetectionMode::Disabled;
    disabled.enabled = false;
    expectTrue(gv.setMotionConfig("motion-test", disabled).ok, "disable motion");
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    MotionMetrics metrics;
    expectTrue(gv.getMotionMetrics("motion-test", metrics).ok, "disable metrics");
    expectTrue(metrics.enabled == false, "motion disabled");
    expectTrue(metrics.state == MotionState::Idle, "state cleared");
    expectTrue(metrics.endedEvents >= 1, "ended on disable while active");

    disabled.enabled = true;
    expectTrue(gv.setMotionConfig("motion-test", disabled).ok, "re-enable motion");
    VideoFrame rebase = makeGrayFrame("motion-test", 160, 120, 100, 15);
    gv.submitFrame(std::move(rebase));
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    expectTrue(gv.getMotionMetrics("motion-test", metrics).ok, "re-enable metrics");
    expectTrue(metrics.baselineFrames >= 1, "new baseline after re-enable");
    gv.shutdown();
}

void testIntegrationMotionClear() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "clear init");

    MotionConfig motion = fastMotionConfig();
    motion.clearFrameCount = 3;
    StreamConfig stream = makeStreamConfig("motion-test", "Motion", motion);
    expectTrue(gv.registerStream(stream).ok, "clear register");

    VideoFrame baseline = makeGrayFrame("motion-test", 160, 120, 0, 5);
    gv.submitFrame(baseline);
    std::this_thread::sleep_for(std::chrono::milliseconds(150));

    for (std::uint64_t seq = 1; seq <= 3; ++seq) {
        VideoFrame moved = makeGrayFrame("motion-test", 160, 120, seq, 5);
        fillRectGray(moved, 20, 20, 80, 80, static_cast<std::uint8_t>(150));
        gv.submitFrame(std::move(moved));
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
    }
    waitForMotion(gv, "motion-test", 1);

    for (std::uint64_t seq = 4; seq <= 10; ++seq) {
        VideoFrame stable = makeGrayFrame("motion-test", 160, 120, seq, 5);
        gv.submitFrame(std::move(stable));
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
    }
    waitForMetric(gv, "motion-test", [](const MotionMetrics& m) { return m.endedEvents >= 1; });

    MotionMetrics metrics;
    expectTrue(gv.getMotionMetrics("motion-test", metrics).ok, "clear metrics");
    expectTrue(metrics.endedEvents >= 1, "ended after clear confirmation");
    expectTrue(metrics.state == MotionState::Idle, "idle after clear");
    gv.shutdown();
}

void testIntegrationStreamRemoval() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 1;
    expectTrue(gv.initialize(config).ok, "removal init");

    StreamConfig stream = makeStreamConfig("motion-test", "Motion", fastMotionConfig());
    expectTrue(gv.registerStream(stream).ok, "removal register");

    VideoFrame baseline = makeGrayFrame("motion-test", 160, 120, 0, 8);
    gv.submitFrame(baseline);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    for (std::uint64_t seq = 1; seq <= 5; ++seq) {
        VideoFrame moved = makeGrayFrame("motion-test", 160, 120, seq, 8);
        fillRectGray(moved, 10, 10, 90, 90, static_cast<std::uint8_t>(180));
        gv.submitFrame(std::move(moved));
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    waitForMotion(gv, "motion-test", 1);
    expectTrue(gv.unregisterStream("motion-test").ok, "unregister under motion");
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
    MotionMetrics metrics;
    expectFalse(gv.getMotionMetrics("motion-test", metrics).ok, "metrics unavailable after removal");
    gv.shutdown();
}

void testIntegrationMultiStream() {
    GuardVision gv;
    GuardVisionConfig config;
    config.frameWorkerCount = 2;
    config.maxStreams = 8;
    expectTrue(gv.initialize(config).ok, "multi init");

    for (int i = 1; i <= 4; ++i) {
        StreamConfig stream = makeStreamConfig("stream-" + std::to_string(i), "S" + std::to_string(i), fastMotionConfig());
        expectTrue(gv.registerStream(stream).ok, "multi register");
    }

    for (int round = 0; round < 15; ++round) {
        for (int i = 1; i <= 4; ++i) {
            const std::string id = "stream-" + std::to_string(i);
            VideoFrame frame = makeGrayFrame(id, 128, 96, static_cast<std::uint64_t>(round * 4 + i), static_cast<std::uint8_t>(20 + i * 5));
            if (round % 3 == i % 3) {
                fillRectGray(frame, 20, 20, 40, 40, static_cast<std::uint8_t>(100 + round));
            }
            gv.submitFrame(std::move(frame));
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    for (int i = 1; i <= 4; ++i) {
        MotionMetrics metrics;
        expectTrue(gv.getMotionMetrics("stream-" + std::to_string(i), metrics).ok, "multi metrics");
        expectTrue(metrics.analyzedFrames >= 1, "stream analyzed independently");
    }
    gv.shutdown();
}

}  // namespace

int runTask4Tests() {
    testMotionConfigValidation();
    testLumaConversionGray8();
    testLumaConversionAllFormats();
    testRoiLumaMapping();
    testDownscaleNoUpscale();
    testMotionComparison();
    testRegionExtraction();
    testStateMachineConfirmation();
    testIntegrationMovingObject();
    testIntegrationStableScene();
    testIntegrationResolutionChange();
    testIntegrationDisableUnderMotion();
    testIntegrationMotionClear();
    testIntegrationStreamRemoval();
    testIntegrationMultiStream();
    return g_failures;
}
