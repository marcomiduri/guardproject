#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-$(cd "$(dirname "$0")" && pwd)/fire_smoke_candidate.onnx}"
URL='https://huggingface.co/DarshanM0di/fireandsmoke/resolve/main/best%20%284%29.onnx?download=true'
EXPECTED='5043e0efd1d474bcc901716e97946b8f8a787e4bd29451891f8dccfbe93322b6'
TMP="${OUT}.download"
curl -L --fail --retry 3 "$URL" -o "$TMP"
ACTUAL="$(sha256sum "$TMP" | awk '{print $1}')"
if [[ "$ACTUAL" != "$EXPECTED" ]]; then
  rm -f "$TMP"
  echo "SHA-256 mismatch: expected $EXPECTED got $ACTUAL" >&2
  exit 1
fi
mv -f "$TMP" "$OUT"
echo "Saved: $OUT"
echo "SHA-256 verified: $ACTUAL"
