param(
    [string]$OutputPath = (Join-Path $PSScriptRoot "fire_smoke_candidate.onnx")
)

$ErrorActionPreference = "Stop"
$Url = "https://huggingface.co/DarshanM0di/fireandsmoke/resolve/main/best%20%284%29.onnx?download=true"
$ExpectedSha256 = "5043e0efd1d474bcc901716e97946b8f8a787e4bd29451891f8dccfbe93322b6"
$TempPath = "$OutputPath.download"

Write-Host "Downloading public fire/smoke ONNX candidate..."
Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $TempPath
$Actual = (Get-FileHash -Algorithm SHA256 $TempPath).Hash.ToLowerInvariant()
if ($Actual -ne $ExpectedSha256) {
    Remove-Item -Force $TempPath -ErrorAction SilentlyContinue
    throw "SHA-256 mismatch. Expected $ExpectedSha256, got $Actual"
}
Move-Item -Force $TempPath $OutputPath
Write-Host "Saved: $OutputPath"
Write-Host "SHA-256 verified: $Actual"
