# Fire/Smoke Model Evaluation Kit

This folder downloads the public MIT-licensed `DarshanM0di/fireandsmoke` ONNX candidate and verifies the published SHA-256.

**Do not blindly rename it to `fire_smoke.onnx` and overwrite Guard's production model.** Guard currently calls a proprietary HazardDetect SDK. That SDK's expected ONNX output contract is not present in the uploaded source.

Recommended test flow:

1. Run the download script.
2. Keep the file outside the production `models` directory initially.
3. Set `GUARD_HAZARD_MODEL` to the downloaded file for an A/B test on a licensed test machine.
4. Confirm `HazardDetect_Init` accepts it and verify that returned classes/boxes are correct.
5. Benchmark against a labeled indoor validation set, especially steam/reflections/monitors and early smoke.
6. Only deploy if the model is compatible and materially improves false-positive rate and smoke recall.

Published model SHA-256:

`5043e0efd1d474bcc901716e97946b8f8a787e4bd29451891f8dccfbe93322b6`
