#!/usr/bin/env python3
"""Export WeedBlaster YOLOv8s .pt weights to ONNX for C++ runtimes."""
from pathlib import Path
import argparse

from ultralytics import YOLO


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", nargs="?", default="weedblaster_yolov8s_best.pt")
    parser.add_argument("--imgsz", type=int, default=1280)
    parser.add_argument("--opset", type=int, default=12)
    args = parser.parse_args()

    model_path = Path(args.model).resolve()
    if not model_path.exists():
        raise SystemExit(f"Model not found: {model_path}")

    model = YOLO(str(model_path))
    exported = model.export(format="onnx", imgsz=args.imgsz, opset=args.opset, simplify=False)
    print(exported)


if __name__ == "__main__":
    main()
