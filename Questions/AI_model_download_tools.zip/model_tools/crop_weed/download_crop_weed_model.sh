#!/usr/bin/env bash
set -euo pipefail
OUT="${1:-$(cd "$(dirname "$0")" && pwd)/weedblaster_yolov8s_best.pt}"
URL='https://huggingface.co/NvMayMay/weedblaster-vision-yolov8s/resolve/main/best.pt?download=true'
EXPECTED='2a10f51e1d78db493b6c75662986748bebc01562fbce70f7f2b49f0176b4ecb6'
TMP="${OUT}.download"
curl -L --fail --retry 3 "$URL" -o "$TMP"
ACTUAL="$(sha256sum "$TMP" | awk '{print $1}')"
if [[ "$ACTUAL" != "$EXPECTED" ]]; then
  rm -f "$TMP"
  echo "SHA-256 mismatch: expected $EXPECTED got $ACTUAL" >&2
  exit 1
fi
mv -f "$TMP" "$OUT"
echo "Saved: $OUT"
echo "SHA-256 verified: $ACTUAL"
