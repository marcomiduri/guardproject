param(
    [string]$OutputPath = (Join-Path $PSScriptRoot "weedblaster_yolov8s_best.pt")
)

$ErrorActionPreference = "Stop"
$Url = "https://huggingface.co/NvMayMay/weedblaster-vision-yolov8s/resolve/main/best.pt?download=true"
$ExpectedSha256 = "2a10f51e1d78db493b6c75662986748bebc01562fbce70f7f2b49f0176b4ecb6"
$TempPath = "$OutputPath.download"

Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $TempPath
$Actual = (Get-FileHash -Algorithm SHA256 $TempPath).Hash.ToLowerInvariant()
if ($Actual -ne $ExpectedSha256) {
    Remove-Item -Force $TempPath -ErrorAction SilentlyContinue
    throw "SHA-256 mismatch. Expected $ExpectedSha256, got $Actual"
}
Move-Item -Force $TempPath $OutputPath
Write-Host "Saved: $OutputPath"
Write-Host "SHA-256 verified: $Actual"
