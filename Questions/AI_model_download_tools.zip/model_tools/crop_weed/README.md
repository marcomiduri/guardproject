# Crop/Weed Model Kit

Recommended ready model: `NvMayMay/weedblaster-vision-yolov8s`.

Classes:

1. Maize
2. Sugar Beet
3. Soy
4. Sunflower
5. Potato
6. Pea
7. Bean
8. Pumpkin
9. Weed

The source weight is `best.pt` (22.6 MB). The model page lists an **AGPL-3.0** license. Review the license before commercial/closed-source integration.

Published SHA-256:

`2a10f51e1d78db493b6c75662986748bebc01562fbce70f7f2b49f0176b4ecb6`

Use `export_to_onnx.py` after downloading if a C++ ONNX runtime is desired.
