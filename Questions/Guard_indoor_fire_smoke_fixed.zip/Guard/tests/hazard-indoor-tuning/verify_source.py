from pathlib import Path

root = Path(__file__).resolve().parents[2]
defaults = (root / 'src/model/CameraDetectionSettings.h').read_text(encoding='utf-8')
controller = (root / 'src/runtime/camera/CameraRuntimeController.cpp').read_text(encoding='utf-8')

checks = {
    'indoor hazard analysis interval is explicit': 'hazard.analysisIntervalMs = 120;' in defaults,
    'vendor candidate floor retains faint smoke': 'hazard.minimumConfidence = 0.25;' in defaults,
    'fire uses stricter post-filter': 'hazard.fireMinimumConfidence = 0.55;' in defaults,
    'smoke has dedicated post-filter': 'hazard.smokeMinimumConfidence = 0.38;' in defaults,
    'small hazards are not discarded at 8px': 'hazard.minimumRegionWidth = 4;' in defaults and 'hazard.minimumRegionHeight = 4;' in defaults,
    'single-frame alarm is disabled': 'hazard.activationFrameCount = 2;' in defaults,
    'fire requires longer confirmation': 'hazard.fireActivationFrameCount = 3;' in defaults,
    'smoke confirms earlier': 'hazard.smokeActivationFrameCount = 2;' in defaults,
    'small-hazard tiling is enabled': 'hazard.smallHazardTilingEnabled = true;' in defaults,
    'config equality includes fire threshold': 'left.fireMinimumConfidence == right.fireMinimumConfidence' in controller,
    'config equality includes smoke threshold': 'left.smokeMinimumConfidence == right.smokeMinimumConfidence' in controller,
    'config equality includes fire activation': 'left.fireActivationFrameCount == right.fireActivationFrameCount' in controller,
    'config equality includes smoke activation': 'left.smokeActivationFrameCount == right.smokeActivationFrameCount' in controller,
    'config equality includes small-hazard tiling': 'left.smallHazardTilingEnabled == right.smallHazardTilingEnabled' in controller,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(f'{len(failed)} indoor hazard tuning source check(s) failed')
print('Indoor fire/smoke tuning source verification passed.')
