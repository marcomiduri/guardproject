#ifndef CAMERADETECTIONSETTINGS_H
#define CAMERADETECTIONSETTINGS_H

#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>

struct CameraDetectionSettings {
    guardvision::MotionConfig motion;
    guardvision::FaceConfig face;
    guardvision::HazardConfig hazard;
    bool recordVideoForMotion = true;

    CameraDetectionSettings() {
        motion.detectionMode = guardvision::DetectionMode::Software;
        motion.enabled = true;
        motion.analysisIntervalMs = 100;
        motion.activationFrameCount = 1;

        face.detectionMode = guardvision::DetectionMode::Software;
        face.processingLevel = guardvision::FaceProcessingLevel::DetectTrackAndIdentify;
        face.useRoi = false;
        face.roi = guardvision::NormalizedRect{0.0, 0.0, 1.0, 1.0};

        hazard.detectionMode = guardvision::DetectionMode::Software;
        hazard.processingLevel = guardvision::HazardProcessingLevel::Detect;
        hazard.analysisIntervalMs = 120;
        // Keep the engine floor low enough to retain faint early smoke, then
        // apply stricter class-specific filtering and temporal confirmation.
        hazard.minimumConfidence = 0.25;
        hazard.fireMinimumConfidence = 0.55;
        hazard.smokeMinimumConfidence = 0.38;
        hazard.minimumRegionWidth = 4;
        hazard.minimumRegionHeight = 4;
        hazard.activationFrameCount = 2;
        hazard.fireActivationFrameCount = 3;
        hazard.smokeActivationFrameCount = 2;
        hazard.clearFrameCount = 3;
        hazard.smallHazardTilingEnabled = true;
        hazard.updateEventIntervalMs = 250;
    }
};

inline void normalizeEnabledFaceProcessing(guardvision::FaceConfig& face) {
    if (face.detectionMode == guardvision::DetectionMode::Disabled) {
        face.processingLevel = guardvision::FaceProcessingLevel::Disabled;
        return;
    }

    if (face.processingLevel == guardvision::FaceProcessingLevel::Disabled ||
        face.processingLevel == guardvision::FaceProcessingLevel::DetectAndTrack) {
        face.processingLevel = guardvision::FaceProcessingLevel::DetectTrackAndIdentify;
    }
}

#endif  // CAMERADETECTIONSETTINGS_H
