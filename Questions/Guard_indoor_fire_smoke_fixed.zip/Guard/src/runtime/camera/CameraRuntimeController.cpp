#include "CameraRuntimeController.h"

#include "GuardVisionEventListenerAdapter.h"
#include "media/recording/RecordingStorageManager.h"

#include <events/AlarmEvent.h>
#include <core/DetectionMode.h>
#include <face/FaceTypes.h>
#include <GuardVision.h>
#include <hazard/HazardTypes.h>
#include <motion/MotionTypes.h>
#include <core/StreamConfig.h>

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QEvent>
#include <QFileInfo>
#include <QElapsedTimer>
#include <QThread>
#include <QUuid>
#include <QUrl>

#include <cmath>
#include <utility>

namespace {

QString normalizedPathForComparison(const QString& path) {
    QString normalized = QDir::cleanPath(QFileInfo(path).absoluteFilePath());
#ifdef Q_OS_WIN
    normalized = normalized.toLower();
#endif
    return normalized;
}

bool sameDirectoryPath(const QString& left, const QString& right) {
    return normalizedPathForComparison(left) == normalizedPathForComparison(right);
}

bool sameRect(const guardvision::NormalizedRect& left, const guardvision::NormalizedRect& right) {
    return left.x == right.x && left.y == right.y && left.width == right.width && left.height == right.height;
}


bool sameMotionConfig(const guardvision::MotionConfig& left, const guardvision::MotionConfig& right) {
    return left.detectionMode == right.detectionMode && left.enabled == right.enabled && left.analysisIntervalMs == right.analysisIntervalMs &&
           left.maximumAnalysisWidth == right.maximumAnalysisWidth && left.maximumAnalysisHeight == right.maximumAnalysisHeight &&
           left.pixelDifferenceThreshold == right.pixelDifferenceThreshold && left.startChangedAreaRatio == right.startChangedAreaRatio &&
           left.continueChangedAreaRatio == right.continueChangedAreaRatio && left.activationFrameCount == right.activationFrameCount &&
           left.clearFrameCount == right.clearFrameCount && left.minimumRegionWidth == right.minimumRegionWidth &&
           left.minimumRegionHeight == right.minimumRegionHeight && left.minimumRegionArea == right.minimumRegionArea &&
           left.maximumRegionCount == right.maximumRegionCount && left.eventUpdateIntervalMs == right.eventUpdateIntervalMs &&
           left.baselineResetGapMs == right.baselineResetGapMs && left.useRoi == right.useRoi && sameRect(left.roi, right.roi);
}

bool sameFaceConfig(const guardvision::FaceConfig& left, const guardvision::FaceConfig& right) {
    return left.detectionMode == right.detectionMode && left.processingLevel == right.processingLevel && left.triggerMode == right.triggerMode &&
           left.analysisIntervalMs == right.analysisIntervalMs && left.minimumFaceWidth == right.minimumFaceWidth &&
           left.minimumFaceHeight == right.minimumFaceHeight && left.minimumDetectionConfidence == right.minimumDetectionConfidence &&
           left.minimumQualityScore == right.minimumQualityScore &&
           left.minimumIdentificationConfidence == right.minimumIdentificationConfidence && left.maximumFaceCount == right.maximumFaceCount &&
           left.lostTrackTimeoutMs == right.lostTrackTimeoutMs && left.identificationRetryIntervalMs == right.identificationRetryIntervalMs &&
           left.identityRefreshIntervalMs == right.identityRefreshIntervalMs && left.eventUpdateIntervalMs == right.eventUpdateIntervalMs &&
           left.useRoi == right.useRoi && sameRect(left.roi, right.roi);
}

bool sameHazardConfig(const guardvision::HazardConfig& left, const guardvision::HazardConfig& right) {
    return left.detectionMode == right.detectionMode && left.processingLevel == right.processingLevel &&
           left.analysisIntervalMs == right.analysisIntervalMs && left.fireEnabled == right.fireEnabled && left.smokeEnabled == right.smokeEnabled &&
           left.minimumConfidence == right.minimumConfidence && left.fireMinimumConfidence == right.fireMinimumConfidence &&
           left.smokeMinimumConfidence == right.smokeMinimumConfidence && left.minimumRegionWidth == right.minimumRegionWidth &&
           left.minimumRegionHeight == right.minimumRegionHeight && left.maximumRegionCount == right.maximumRegionCount &&
           left.activationFrameCount == right.activationFrameCount && left.fireActivationFrameCount == right.fireActivationFrameCount &&
           left.smokeActivationFrameCount == right.smokeActivationFrameCount && left.clearFrameCount == right.clearFrameCount &&
           left.updateEventIntervalMs == right.updateEventIntervalMs && left.smallHazardTilingEnabled == right.smallHazardTilingEnabled && left.useRoi == right.useRoi && sameRect(left.roi, right.roi);
}

bool sameDetectionSettings(const CameraDetectionSettings& left, const CameraDetectionSettings& right) {
    return left.motion.detectionMode == right.motion.detectionMode && left.motion.enabled == right.motion.enabled &&
           left.motion.analysisIntervalMs == right.motion.analysisIntervalMs &&
           left.motion.activationFrameCount == right.motion.activationFrameCount && left.motion.useRoi == right.motion.useRoi &&
           sameRect(left.motion.roi, right.motion.roi) && left.face.detectionMode == right.face.detectionMode &&
           left.face.processingLevel == right.face.processingLevel &&
           left.face.minimumIdentificationConfidence == right.face.minimumIdentificationConfidence && left.face.useRoi == right.face.useRoi &&
           sameRect(left.face.roi, right.face.roi) && left.hazard.detectionMode == right.hazard.detectionMode &&
           left.hazard.processingLevel == right.hazard.processingLevel && left.hazard.analysisIntervalMs == right.hazard.analysisIntervalMs &&
           left.hazard.minimumConfidence == right.hazard.minimumConfidence &&
           left.hazard.fireMinimumConfidence == right.hazard.fireMinimumConfidence &&
           left.hazard.smokeMinimumConfidence == right.hazard.smokeMinimumConfidence &&
           left.hazard.minimumRegionWidth == right.hazard.minimumRegionWidth && left.hazard.minimumRegionHeight == right.hazard.minimumRegionHeight &&
           left.hazard.activationFrameCount == right.hazard.activationFrameCount &&
           left.hazard.fireActivationFrameCount == right.hazard.fireActivationFrameCount &&
           left.hazard.smokeActivationFrameCount == right.hazard.smokeActivationFrameCount && left.hazard.clearFrameCount == right.hazard.clearFrameCount &&
           left.hazard.updateEventIntervalMs == right.hazard.updateEventIntervalMs && left.hazard.smallHazardTilingEnabled == right.hazard.smallHazardTilingEnabled && left.hazard.useRoi == right.hazard.useRoi &&
           sameRect(left.hazard.roi, right.hazard.roi) && left.recordVideoForMotion == right.recordVideoForMotion;
}

QString sanitizedStreamToken(QString token) {
    token.remove(QLatin1Char('{'));
    token.remove(QLatin1Char('}'));
    for (int i = 0; i < token.size(); ++i) {
        const QChar ch = token.at(i);
        if (!ch.isLetterOrNumber() && ch != QLatin1Char('-') && ch != QLatin1Char('_')) {
            token[i] = QLatin1Char('-');
        }
    }
    if (token.isEmpty()) {
        token = QString::number(QDateTime::currentMSecsSinceEpoch());
    }
    return token;
}

QString makeControllerStreamId(const QString& cameraId) {
    QString instanceId = QUuid::createUuid().toString();
    instanceId.remove(QLatin1Char('{'));
    instanceId.remove(QLatin1Char('}'));
    return QStringLiteral("guard-%1-%2").arg(sanitizedStreamToken(cameraId), instanceId.left(8));
}

bool isHikvisionType(const QString& type) {
    return type.contains(QStringLiteral("Hikvision"), Qt::CaseInsensitive);
}

bool isFaceEngineAvailabilityError(guardvision::GuardVisionErrorCode code) {
    return code == guardvision::GuardVisionErrorCode::NotInitialized || code == guardvision::GuardVisionErrorCode::FaceModelMissing ||
           code == guardvision::GuardVisionErrorCode::FaceEngineInitializationFailed;
}

bool hasResolvedFaceIdentity(const CameraFaceOverlay& overlay) {
    return overlay.identified && overlay.faceRegistryId > 0 && !overlay.displayName.trimmed().isEmpty();
}

const CameraFaceOverlay* findFaceOverlayByTrackId(const QVector<CameraFaceOverlay>& overlays, quint64 trackId) {
    if (trackId == 0)
        return nullptr;
    for (const CameraFaceOverlay& overlay : overlays) {
        if (overlay.trackId == trackId)
            return &overlay;
    }
    return nullptr;
}

void preserveResolvedFaceIdentity(CameraFaceOverlay& overlay, const CameraFaceOverlay* previous) {
    if (hasResolvedFaceIdentity(overlay) || !previous || !hasResolvedFaceIdentity(*previous))
        return;
    overlay.identified = true;
    overlay.faceRegistryId = previous->faceRegistryId;
    overlay.displayName = previous->displayName;
    overlay.identityConfidence = previous->identityConfidence;
}

QString cameraRuntimeStateName(CameraRuntimeController::State state) {
    switch (state) {
        case CameraRuntimeController::State::Disconnected:
            return QStringLiteral("Disconnected");
        case CameraRuntimeController::State::Connecting:
            return QStringLiteral("Connecting");
        case CameraRuntimeController::State::Connected:
            return QStringLiteral("Connected");
        case CameraRuntimeController::State::Reconnecting:
            return QStringLiteral("Reconnecting");
        case CameraRuntimeController::State::Error:
            return QStringLiteral("Error");
    }
    return QStringLiteral("Unknown");
}

}  // namespace

CameraRuntimeController::CameraRuntimeController(const CameraUiModel& camera, guardvision::GuardVision* guardVision,
                                                 GuardVisionEventListenerAdapter* eventAdapter, CameraView* view, bool testMode,
                                                 guard::recording::RecordingStorageManager* storageManager, const QString& retainedStreamId,
                                                 bool retainedNativeFaceIdentificationPrepared, quint64 retainedNextSubmissionSequence,
                                                 qint64 retainedNextSubmissionTimestampMs, QObject* parent)
: QObject(parent),
  camera_(camera),
  testMode_(testMode),
  guardVision_(guardVision),
  eventAdapter_(eventAdapter),
  view_(view),
  mediaController_(this),
  recorder_(storageManager ? storageManager : guard::recording::RecordingStorageManager::instance(), this),
  streamId_(retainedStreamId.trimmed().isEmpty() ? makeControllerStreamId(camera.id) : retainedStreamId.trimmed()),
  ownsReusableGuardVisionStreamSlot_(!retainedStreamId.trimmed().isEmpty()),
  retainedStreamNativeFaceIdentificationPrepared_(retainedNativeFaceIdentificationPrepared),
  nativeFaceIdentificationPrepared_(retainedNativeFaceIdentificationPrepared),
  fileLoggingEnabled_(guard::diagnostics::CameraFileLogger::persistentLoggingEnabled()) {
    qRegisterMetaType<GuardFaceOccurrence>("GuardFaceOccurrence");
    qRegisterMetaType<GuardHazardOccurrence>("GuardHazardOccurrence");
    mediaController_.setSubmissionCursor(retainedNextSubmissionSequence, retainedNextSubmissionTimestampMs);
    recorder_.setEnabled(settings_.recordVideoForMotion);
    stopPollTimer_.setInterval(10);
    connect(&stopPollTimer_, &QTimer::timeout, this, &CameraRuntimeController::continueAsynchronousStop);

    connect(&mediaController_, &MediaSourceController::statusChanged, this, [this](int statusValue, const QString& message) {
        if (stopping_) {
            return;
        }
        const SourceStatus status = static_cast<SourceStatus>(statusValue);
        switch (status) {
            case SourceStatus::Connecting:
                setState(State::Connecting, message);
                break;
            case SourceStatus::Reconnecting:
                setState(State::Reconnecting, message);
                break;
            case SourceStatus::Playing:
                setState(State::Connected, message);
                break;
            case SourceStatus::Error:
                setState(State::Error, message);
                break;
            case SourceStatus::Stopped:
            case SourceStatus::Completed:
            case SourceStatus::Ready:
            case SourceStatus::NoSource:
                if (!stopping_ && state_ != State::Error) {
                    setState(State::Disconnected, message);
                }
                break;
            case SourceStatus::Loading:
                break;
        }
    });

    connect(&mediaController_, &MediaSourceController::previewFrameReady, this, [this](const QImage& frame, quint64 generation) {
        if (!stopping_ && activeSourceGeneration_ != 0 && generation == activeSourceGeneration_) {
            latestFrame_ = frame;
            if (view_) {
                view_->setFrame(frame);
            }
        }
    });
    // Every decoded source - test image/video, RTSP, and HCNetSDK - enters the
    // same CameraRuntimeController frame path. Source adapters may differ, but
    // display, recording, GuardVision submission, overlays, and backend events
    // are never bypassed for normal cameras.
    connect(&mediaController_, &MediaSourceController::frameReadyForSubmission, this, &CameraRuntimeController::handleDecodedFrame);
    connect(&mediaController_, &MediaSourceController::encodedPacketReady, this,
            [this](const guard::recording::EncodedVideoPacket& packet) { recorder_.submitPacket(packet); });
    connect(&mediaController_, &MediaSourceController::encodedStreamInfoChanged, this,
            [this](const guard::recording::EncodedStreamInfo& info, quint64 generation) {
                if (generation != 0 && generation == activeSourceGeneration_) {
                    recorder_.updateStreamInfo(generation, info);
                }
            });
    connect(&mediaController_, &MediaSourceController::sourceMessage, this, [this](const QString& message) { appendLog(message); });
    connect(&mediaController_, &MediaSourceController::decoderError, this, [this](const QString& message) {
        appendLog(tr("Decoder error: %1").arg(message));
        const bool wasStopping = stopping_;
        if (!wasStopping) {
            stop();
            setState(State::Error, message);
            emit fatalRuntimeError(camera_.id, message);
        }
    });
    connect(&mediaController_, &MediaSourceController::playbackFinished, this, [this](quint64 generation) {
        if (generation != activeSourceGeneration_) {
            return;
        }
        appendLog(tr("Source playback completed."));
    });
    connect(
      &mediaController_, &MediaSourceController::onboardCapabilitiesChanged, this,
      [this](const guard::CameraOnboardCapabilities& capabilities, quint64 generation) {
          if (generation != activeSourceGeneration_) {
              return;
          }
          capabilities_ = capabilities;
          appendLog(
            tr("Onboard capabilities updated. Alarm subscription: %1").arg(capabilities.alarmSubscriptionActive ? tr("active") : tr("inactive")));
          emit capabilitiesChanged(camera_.id);
      });
    connect(&mediaController_, &MediaSourceController::onboardCandidateReady, this, [this](guard::ParsedOnboardEvent event, quint64 generation) {
        if (generation != activeSourceGeneration_ || !guardVision_ || !guardVision_->isInitialized() || !streamRegistered_) {
            return;
        }

        guardvision::DetectionMode mode = guardvision::DetectionMode::Disabled;
        switch (event.candidate.type) {
            case guardvision::CandidateType::Motion:
                mode = settings_.motion.detectionMode;
                break;
            case guardvision::CandidateType::Face:
                mode = settings_.face.detectionMode;
                break;
            case guardvision::CandidateType::Fire:
            case guardvision::CandidateType::Smoke:
                mode = settings_.hazard.detectionMode;
                break;
        }
        if (mode != guardvision::DetectionMode::OnboardTriggered && mode != guardvision::DetectionMode::Hybrid) {
            return;
        }

        event.candidate.generation = 0;
        const guardvision::Result result = guardVision_->submitOnboardCandidate(event.candidate);
        if (!result.ok) {
            appendLog(tr("Onboard candidate rejected: %1").arg(QString::fromStdString(result.error.message)));
        } else if (!event.logMessage.isEmpty()) {
            appendLog(event.logMessage);
        }
    });

    connect(&recorder_, &guard::recording::MotionVideoRecorder::recordingStarted, this,
            [this](const QString& path) { appendLog(tr("Motion recording started: %1").arg(path)); });
    connect(&recorder_, &guard::recording::MotionVideoRecorder::recordingFinished, this,
            [this](const QString& path, quint64 count) { appendLog(tr("Motion recording finalized: %1 (%2 packets/frames)").arg(path).arg(count)); });
    connect(&recorder_, &guard::recording::MotionVideoRecorder::recordingError, this,
            [this](const QString& message) { appendLog(tr("Recording error: %1").arg(message)); });
    connect(&recorder_, &guard::recording::MotionVideoRecorder::recordingWarning, this,
            [this](const QString& message) { appendLog(tr("Recording warning: %1").arg(message)); });

    if (eventAdapter_) {
        connect(eventAdapter_, &GuardVisionEventListenerAdapter::motionReceived, this, &CameraRuntimeController::onMotionEvent, Qt::QueuedConnection);
        connect(eventAdapter_, &GuardVisionEventListenerAdapter::faceReceived, this, &CameraRuntimeController::onFaceEvent, Qt::QueuedConnection);
        connect(eventAdapter_, &GuardVisionEventListenerAdapter::hazardReceived, this, &CameraRuntimeController::onHazardEvent, Qt::QueuedConnection);
        connect(eventAdapter_, &GuardVisionEventListenerAdapter::alarmReceived, this, &CameraRuntimeController::onAlarmEvent, Qt::QueuedConnection);
        connect(
          eventAdapter_, &GuardVisionEventListenerAdapter::errorReceived, this,
          [this](int, const QString& message, const QString& component, const QString& streamId) {
              if (streamId.isEmpty() || streamId == streamId_) {
                  appendLog(tr("GuardVision error [%1]: %2").arg(component, message));
              }
          },
          Qt::QueuedConnection);
    }

    if (fileLoggingEnabled_) {
        QString fileLogError;
        if (fileLogger_.configure(camera_.displayName(), camera_.id, &fileLogError)) {
            appendLog(tr("Camera log file initialized: %1").arg(fileLogger_.filePath()));
            appendLog(tr("Camera log session started. Camera ID: %1").arg(camera_.id));
        } else {
            appendLog(tr("Camera file logging could not be initialized: %1").arg(fileLogError));
        }
    } else {
        appendLog(tr("Camera file logging is disabled in Application Settings."));
    }
}

CameraRuntimeController::~CameraRuntimeController() {
    prepareForApplicationShutdown();
    recorder_.shutdown();
}

QString CameraRuntimeController::cameraId() const {
    return camera_.id;
}
QString CameraRuntimeController::streamId() const {
    return streamId_;
}
CameraUiModel CameraRuntimeController::camera() const {
    return camera_;
}
CameraDetectionSettings CameraRuntimeController::detectionSettings() const {
    return settings_;
}
CameraTestSourceSettings CameraRuntimeController::testSourceSettings() const {
    return testSourceSettings_;
}
guard::CameraOnboardCapabilities CameraRuntimeController::capabilities() const {
    return capabilities_;
}
QStringList CameraRuntimeController::logMessages() const {
    return logs_;
}
QString CameraRuntimeController::logFilePath() const {
    return fileLogger_.filePath();
}
QString CameraRuntimeController::logDirectoryPath() const {
    return fileLogger_.directoryPath();
}
bool CameraRuntimeController::fileLoggingEnabled() const {
    return fileLoggingEnabled_;
}
CameraRuntimeController::State CameraRuntimeController::state() const {
    return state_;
}
bool CameraRuntimeController::isConnected() const {
    return state_ == State::Connected;
}
bool CameraRuntimeController::isStreamRegistered() const {
    return streamRegistered_;
}
bool CameraRuntimeController::ownsReusableGuardVisionStreamSlot() const {
    return ownsReusableGuardVisionStreamSlot_;
}
bool CameraRuntimeController::isGuardVisionStreamActive() const {
    return streamRegistered_ && !streamRetainedForReuse_ && activeGuardVisionGeneration_ != 0;
}

bool CameraRuntimeController::isNativeFaceIdentificationPrepared() const {
    return nativeFaceIdentificationPrepared_;
}

quint64 CameraRuntimeController::nextSubmissionSequence() const {
    return mediaController_.nextSubmissionSequence();
}

qint64 CameraRuntimeController::nextSubmissionTimestampMs() const {
    return mediaController_.nextSubmissionTimestampMs();
}

void CameraRuntimeController::updateCamera(const CameraUiModel& camera) {
    const bool connectionChanged = !cameraConnectionFieldsEqual(camera_, camera);
    const bool backendMappingChanged =
      camera_.backendCameraId.trimmed() != camera.backendCameraId.trimmed() || camera_.roomId.trimmed() != camera.roomId.trimmed();
    const QString previousName = camera_.displayName();
    const QString previousLogPath = fileLogger_.filePath();
    const bool nameChanged = previousName != camera.displayName();

    if (connectionChanged) {
        const bool wasRunning = mediaController_.isRunning() || (streamRegistered_ && !streamRetainedForReuse_);
        if (wasRunning)
            stop();
        appendLog(tr("Camera connection settings updated."));
    }

    camera_ = camera;
    if (backendMappingChanged) {
        appendLog(camera_.backendCameraId.trimmed().isEmpty() ? tr("Backend room mapping detached; local camera monitoring remains available.")
                                                              : tr("Backend room mapping attached."));
    }
    if (nameChanged && fileLoggingEnabled_) {
        QString fileLogError;
        if (fileLogger_.configure(camera_.displayName(), camera_.id, &fileLogError)) {
            lastFileLogError_.clear();
            emit logFileChanged(camera_.id, fileLogger_.filePath());
            appendLog(tr("Camera renamed from %1 to %2. Previous log file: %3").arg(previousName, camera_.displayName(), previousLogPath));
            appendLog(tr("Camera log file changed to: %1").arg(fileLogger_.filePath()));
        } else {
            appendLog(tr("Camera log file could not be changed after rename: %1").arg(fileLogError));
        }
    } else if (nameChanged) {
        appendLog(tr("Camera renamed from %1 to %2. File logging is disabled.").arg(previousName, camera_.displayName()));
    }
}

void CameraRuntimeController::setFileLoggingEnabled(bool enabled) {
    if (fileLoggingEnabled_ == enabled)
        return;

    if (!enabled) {
        appendLog(tr("Camera file logging disabled from Application Settings."));
        fileLoggingEnabled_ = false;
        lastFileLogError_.clear();
        fileLogger_.close();
        emit logFileChanged(camera_.id, QString());
        return;
    }

    fileLoggingEnabled_ = true;
    QString error;
    if (!fileLogger_.configure(camera_.displayName(), camera_.id, &error)) {
        appendLog(tr("Camera file logging could not be enabled: %1").arg(error));
        emit logFileChanged(camera_.id, QString());
        return;
    }

    lastFileLogError_.clear();
    emit logFileChanged(camera_.id, fileLogger_.filePath());
    appendLog(tr("Camera file logging enabled from Application Settings."));
    appendLog(tr("Camera log file initialized: %1").arg(fileLogger_.filePath()));
}

void CameraRuntimeController::reloadFileLoggingSettings() {
    const bool enabled = guard::diagnostics::CameraFileLogger::persistentLoggingEnabled();
    if (!enabled) {
        setFileLoggingEnabled(false);
        return;
    }

    const QString effectiveDirectory = guard::diagnostics::CameraFileLogger::effectiveDirectoryPath();
    if (fileLoggingEnabled_ && fileLogger_.isReady() && sameDirectoryPath(fileLogger_.directoryPath(), effectiveDirectory)) {
        return;
    }

    fileLoggingEnabled_ = true;
    const QString previousPath = fileLogger_.filePath();
    QString error;
    if (!fileLogger_.configure(camera_.displayName(), camera_.id, &error)) {
        appendLog(tr("Camera log folder could not be applied: %1").arg(error));
        emit logFileChanged(camera_.id, previousPath);
        return;
    }

    lastFileLogError_.clear();
    emit logFileChanged(camera_.id, fileLogger_.filePath());
    appendLog(previousPath.isEmpty() ? tr("Camera file logging enabled from Application Settings.")
                                     : tr("Camera log folder updated from Application Settings."));
    appendLog(tr("Camera log file initialized: %1").arg(fileLogger_.filePath()));
}

bool CameraRuntimeController::validateTestSourceSettings(const CameraTestSourceSettings& settings, QString* errorMessage) const {
    if (!testMode_ || !settings.usesFile()) {
        return true;
    }

    const QFileInfo fileInfo(settings.filePath.trimmed());
    if (settings.filePath.trimmed().isEmpty() || !fileInfo.exists() || !fileInfo.isFile()) {
        if (errorMessage) {
            *errorMessage = tr("The selected test media file does not exist.");
        }
        return false;
    }

    const QString suffix = fileInfo.suffix().toLower();
    const bool imageExtension =
      suffix == QStringLiteral("jpg") || suffix == QStringLiteral("jpeg") || suffix == QStringLiteral("png") || suffix == QStringLiteral("bmp");
    const bool videoExtension =
      suffix == QStringLiteral("mp4") || suffix == QStringLiteral("avi") || suffix == QStringLiteral("mov") || suffix == QStringLiteral("mkv");

    if (settings.type == CameraTestSourceType::ImageFile && !imageExtension) {
        if (errorMessage) {
            *errorMessage = tr("The selected test source must be a JPG, JPEG, PNG, or BMP image.");
        }
        return false;
    }
    if (settings.type == CameraTestSourceType::VideoFile && !videoExtension) {
        if (errorMessage) {
            *errorMessage = tr("The selected test source must be an MP4, AVI, MOV, or MKV video.");
        }
        return false;
    }
    return true;
}

bool CameraRuntimeController::configureSource(QString* errorMessage) {
    if (testMode_ && testSourceSettings_.usesFile()) {
        if (!validateTestSourceSettings(testSourceSettings_, errorMessage)) {
            return false;
        }
        const QString absolutePath = QFileInfo(testSourceSettings_.filePath).absoluteFilePath();
        mediaController_.configureFile(absolutePath);
        appendLog(tr("Test source selected: %1").arg(absolutePath));
        return true;
    }

    if (isHikvisionType(camera_.type)) {
        if (camera_.address.trimmed().isEmpty()) {
            if (errorMessage) {
                *errorMessage = tr("Camera IP address is required.");
            }
            return false;
        }
        if (camera_.username.trimmed().isEmpty()) {
            if (errorMessage) {
                *errorMessage = tr("Camera username is required.");
            }
            return false;
        }
        HcNetSdkSourceConfig config;
        config.ip = camera_.address.trimmed();
        config.port = camera_.sdkPort;
        config.username = camera_.username;
        config.password = camera_.password;
        config.channel = camera_.channel;
        config.streamType = camera_.stream.contains(QStringLiteral("Sub"), Qt::CaseInsensitive) ? 1 : 0;
        mediaController_.configureHcNetSdk(config);
        return true;
    }

    const QString url = buildRtspUrl();
    const QUrl parsed(url);
    if (url.isEmpty() || !parsed.isValid() || parsed.scheme().compare(QStringLiteral("rtsp"), Qt::CaseInsensitive) != 0) {
        if (errorMessage) {
            *errorMessage = tr("A valid rtsp:// URL or camera address is required.");
        }
        return false;
    }
    RtspSourceConfig config;
    config.url = url;
    config.username = camera_.username;
    config.password = camera_.password;
    mediaController_.configureRtsp(config);
    return true;
}

QString CameraRuntimeController::buildRtspUrl() const {
    if (!camera_.rtspUrl.trimmed().isEmpty()) {
        return camera_.rtspUrl.trimmed();
    }
    if (camera_.address.trimmed().isEmpty()) {
        return QString();
    }
    QUrl url;
    url.setScheme(QStringLiteral("rtsp"));
    url.setHost(camera_.address.trimmed());
    url.setPort(camera_.rtspPort);
    const int profile = camera_.stream.contains(QStringLiteral("Sub"), Qt::CaseInsensitive) ? 2 : 1;
    url.setPath(QStringLiteral("/Streaming/Channels/%1").arg(qMax(1, camera_.channel) * 100 + profile));
    return url.toString();
}

bool CameraRuntimeController::registerStream(QString* errorMessage) {
    if (!guardVision_ || !guardVision_->isInitialized()) {
        if (errorMessage) {
            *errorMessage = tr("GuardVision is not initialized.");
        }
        return false;
    }

    // A retained stream may only be adopted when this exact controller was
    // constructed with an explicit retained stream ID. Fresh controllers get a
    // unique process-lifetime stream ID, even when they represent the same
    // backend camera after a room switch. This prevents a newly created camera
    // tile from adopting stale native GuardVision/Identify state left by a
    // previous controller and removes the debug-heap double-free path observed
    // during repeated room switches.
    if (!streamRegistered_ && ownsReusableGuardVisionStreamSlot_) {
        guardvision::StreamStatus existingStatus;
        const guardvision::Result existingStatusResult = guardVision_->getStreamStatus(streamId_.toStdString(), existingStatus);
        if (existingStatusResult.ok && existingStatus.generation != 0) {
            streamRegistered_ = true;
            ownsReusableGuardVisionStreamSlot_ = true;
            streamRetainedForReuse_ = true;
            registeredGuardVisionGeneration_ = static_cast<quint64>(existingStatus.generation);

            // Never reapply native face configuration while adopting a retained
            // process-lifetime slot. The slot already owns its vendor face
            // session, and rebuilding that session is the crash path observed
            // before media startup. Identification is prepared later only when
            // the inherited slot explicitly reports that no native Identify
            // session exists.
            if (retainedStreamNativeFaceIdentificationPrepared_) {
                nativeFaceIdentificationPrepared_ = true;
                appendLog(tr("Retained GuardVision face session is already prepared; native face configuration was not reapplied."));
            }

            appendLog(tr("Adopted retained GuardVision stream slot: %1 (generation %2)").arg(streamId_).arg(registeredGuardVisionGeneration_));
        }
    }

    // Normal CameraWidget Disconnect no longer calls per-stream unregister.
    // The vendor Identify session teardown inside unregisterStream() crashed
    // when another camera remained active. Reuse the retained stream instead.
    if (streamRegistered_ && streamRetainedForReuse_) {
        guardvision::StreamStatus retainedStatus;
        const guardvision::Result retainedStatusResult = guardVision_->getStreamStatus(streamId_.toStdString(), retainedStatus);
        if (retainedStatusResult.ok && retainedStatus.generation != 0) {
            registeredGuardVisionGeneration_ = static_cast<quint64>(retainedStatus.generation);
            activeGuardVisionGeneration_ = registeredGuardVisionGeneration_;
            streamRetainedForReuse_ = false;
            appendLog(tr("Reactivating this camera's GuardVision stream: %1 (generation %2)").arg(streamId_).arg(activeGuardVisionGeneration_));
            emit guardVisionStreamRegistered(camera_.id);
            return true;
        }

        appendLog(tr("Retained GuardVision stream is no longer available; registering a replacement."));
        streamRegistered_ = false;
        ownsReusableGuardVisionStreamSlot_ = false;
        streamRetainedForReuse_ = false;
        registeredGuardVisionGeneration_ = 0;
        activeGuardVisionGeneration_ = 0;
    }

    guardvision::StreamConfig config;
    config.streamId = streamId_.toStdString();
    config.displayName = camera_.displayName().toStdString();
    config.motion = settings_.motion;
    config.face = effectiveFaceConfig(settings_.face);
    config.hazard = settings_.hazard;

    const bool faceRequested = config.face.processingLevel != guardvision::FaceProcessingLevel::Disabled;
    guardvision::Result result = guardVision_->registerStream(config);
    bool faceFallbackUsed = false;
    QString faceUnavailableMessage;

    // If face analytics cannot initialize at all, retry the same stream with
    // face processing disabled so motion, hazard, source playback, and recording
    // remain operational. A no-room stream normally uses DetectAndTrack and does
    // not initialize IdentifyEngine yet.
    if (!result.ok && faceRequested && isFaceEngineAvailabilityError(result.error.code)) {
        faceFallbackUsed = true;
        faceUnavailableMessage = QString::fromStdString(result.error.message);
        guardvision::StreamConfig degradedConfig = config;
        degradedConfig.face.processingLevel = guardvision::FaceProcessingLevel::Disabled;
        degradedConfig.face.detectionMode = guardvision::DetectionMode::Disabled;
        result = guardVision_->registerStream(degradedConfig);
    }

    if (!result.ok) {
        if (errorMessage) {
            *errorMessage = QString::fromStdString(result.error.message);
        }
        return false;
    }

    guardvision::StreamStatus status;
    guardvision::Result statusResult;
    for (int attempt = 0; attempt < 3; ++attempt) {
        statusResult = guardVision_->getStreamStatus(config.streamId, status);
        if (statusResult.ok && status.generation != 0)
            break;
        if (attempt < 2)
            QThread::msleep(10);
    }
    if (!statusResult.ok || status.generation == 0) {
        // Registration succeeded, so the native slot may already exist even if
        // its status is not visible yet. Never call per-stream unregister here:
        // that vendor teardown is the four-camera room-disconnect crash path.
        // Keep ownership with this controller so removal/room switching can
        // preserve the slot and a later start can retry status adoption.
        streamRegistered_ = true;
        ownsReusableGuardVisionStreamSlot_ = true;
        streamRetainedForReuse_ = true;
        registeredGuardVisionGeneration_ = 0;
        activeGuardVisionGeneration_ = 0;
        if (errorMessage) {
            *errorMessage =
              statusResult.ok ? tr("GuardVision returned an invalid stream generation.") : QString::fromStdString(statusResult.error.message);
        }
        appendLog(tr("GuardVision stream registration is pending status visibility; the native slot was retained for retry."));
        return false;
    }

    streamRegistered_ = true;
    ownsReusableGuardVisionStreamSlot_ = true;
    streamRetainedForReuse_ = false;
    registeredGuardVisionGeneration_ = static_cast<quint64>(status.generation);
    activeGuardVisionGeneration_ = registeredGuardVisionGeneration_;
    appendLog(tr("GuardVision stream registered: %1 (generation %2)").arg(streamId_).arg(activeGuardVisionGeneration_));
    if (settings_.face.detectionMode != guardvision::DetectionMode::Disabled && !nativeFaceIdentificationPrepared_) {
        appendLog(tr("Face identification deferred until a room registry is available; detect-and-track remains active."));
    }

    if (faceFallbackUsed) {
        const QString message = faceUnavailableMessage.isEmpty()
                                  ? tr("Face identification is unavailable. Camera monitoring will continue.")
                                  : tr("Face identification is unavailable: %1. Camera monitoring will continue.").arg(faceUnavailableMessage);
        appendLog(message);
        emit faceIdentificationUnavailable(camera_.id, faceUnavailableMessage);
    }

    // This signal is intentionally emitted before the media producer starts.
    // MainWindow can now prepare IdentifyEngine and apply a registry downloaded
    // during splash startup before the first image/video frame is submitted.
    emit guardVisionStreamRegistered(camera_.id);
    return true;
}

bool CameraRuntimeController::start(QString* errorMessage) {
    appendLog(tr("Camera start requested. Camera: %1; source type: %2")
                .arg(camera_.displayName(), testMode_ && testSourceSettings_.usesFile() ? tr("test media") : camera_.type));
    const bool hasActiveRuntime = mediaController_.isRunning() || activeSourceGeneration_ != 0 || (streamRegistered_ && !streamRetainedForReuse_) ||
                                  activeGuardVisionGeneration_ != 0;
    if (hasActiveRuntime)
        stop();
    if (stopping_ || mediaController_.isRunning() || (streamRegistered_ && !streamRetainedForReuse_)) {
        if (errorMessage)
            *errorMessage = tr("The previous camera session has not stopped safely.");
        setState(State::Error, errorMessage ? *errorMessage : tr("The previous camera session has not stopped safely."));
        return false;
    }
    stopping_ = false;
    resetRuntimeState();

    if (!configureSource(errorMessage)) {
        const QString failure = errorMessage ? *errorMessage : tr("Invalid source configuration.");
        appendLog(tr("Camera start failed during source configuration: %1").arg(failure));
        setState(State::Error, failure);
        return false;
    }

    if (shouldUseFreshStreamForStillImageFaceSession()) {
        retireRetainedStreamForFreshStillImageFaceSession();
    }

    if (!registerStream(errorMessage)) {
        const QString failure = errorMessage ? *errorMessage : tr("Stream registration failed.");
        appendLog(tr("Camera start failed during GuardVision stream registration: %1").arg(failure));
        setState(State::Error, failure);
        return false;
    }

    recorder_.setEnabled(settings_.recordVideoForMotion);
    quint64 generation = 0;
    if (!mediaController_.start(streamId_, &generation)) {
        // Keep the registered stream for reuse. Per-stream vendor teardown is
        // deliberately deferred to the shared GuardVision shutdown.
        activeGuardVisionGeneration_ = 0;
        streamRetainedForReuse_ = streamRegistered_;
        appendLog(tr("Camera source failed to start; GuardVision stream retained for safe reuse."));
        if (errorMessage && errorMessage->isEmpty()) {
            *errorMessage = tr("The camera source could not be started.");
        }
        const QString failure = errorMessage ? *errorMessage : tr("The camera source could not be started.");
        appendLog(tr("Camera source start failed: %1").arg(failure));
        setState(State::Error, failure);
        return false;
    }

    activeSourceGeneration_ = generation;
    const guard::recording::EncodedStreamInfo streamInfo = mediaController_.encodedStreamInfo();
    recorder_.startSource(camera_.id, camera_.displayName(), streamId_, generation, streamInfo,
                          QString::fromLatin1(guardvision::toString(settings_.motion.detectionMode)));
    if (settings_.recordVideoForMotion) {
        appendLog(tr("Motion recording enabled. Output: %1").arg(recorder_.outputDirectory()));
        if (!streamInfo.isValid()) {
            appendLog(tr("Encoded recording is waiting for stream information; decoded-frame fallback is available."));
        }
    }
    setState(State::Connecting, tr("Connecting"));
    appendLog(tr("Camera source started."));
    return true;
}

void CameraRuntimeController::stop() {
    beginStop();
    if (!stopping_) {
        return;
    }

    appendLog(tr("Waiting synchronously for the media source to quiesce."));
    const bool sourceQuiesced = mediaController_.stopAndWaitForQuiescence(5000);
    if (!sourceQuiesced) {
        appendLog(tr("Camera source teardown timed out; GuardVision remains registered to avoid a decoder/session race."));
        setState(State::Error, tr("Camera source did not stop safely"));
        stopping_ = false;
        stoppingSourceGeneration_ = 0;
        return;
    }
    appendLog(tr("Media source quiesced."));
    finalizeStop();
}

void CameraRuntimeController::requestStop() {
    // HCNetSDK owns external callback threads whose teardown API is currently
    // join-based. Keep that source on the proven synchronous shutdown path.
    // File and RTSP workers expose non-blocking quiescence state and can use the
    // deferred UI-safe teardown below.
    if (mediaController_.activeType() == FrameSourceType::HcNetSdkCamera) {
        stop();
        return;
    }

    beginStop();
    if (!stopping_) {
        return;
    }

    appendLog(tr("Asynchronous camera teardown started."));
    stopElapsed_.restart();
    stopTimeoutLogged_ = false;

    if (mediaController_.isQuiescent()) {
        appendLog(tr("Media source was already quiescent; scheduling final camera cleanup."));
        QTimer::singleShot(0, this, [this]() {
            if (stopping_) {
                finalizeStop();
            }
        });
        return;
    }
    stopPollTimer_.start();
}

void CameraRuntimeController::beginStop() {
    if (stopping_) {
        return;
    }
    appendLog(tr("Camera stop requested."));
    stopping_ = true;
    stoppingSourceGeneration_ = activeSourceGeneration_;

    // Stop accepting decoded frames first, then finalize recording and quiesce
    // the source worker. The GuardVision stream is retained after quiescence;
    // per-stream vendor-session teardown is deferred to application shutdown.
    activeSourceGeneration_ = 0;
    // Reject already-queued GuardVision callbacks while the producer drains.
    // The registered stream remains available for a later reconnect.
    activeGuardVisionGeneration_ = 0;
    appendLog(tr("Recording stop requested for source generation %1.").arg(stoppingSourceGeneration_));
    recorder_.stopSource(stoppingSourceGeneration_);
    appendLog(tr("Media source stop requested."));
    mediaController_.stop();
}

void CameraRuntimeController::continueAsynchronousStop() {
    if (!stopping_) {
        stopPollTimer_.stop();
        return;
    }
    if (!mediaController_.isQuiescent()) {
        if (!stopTimeoutLogged_ && stopElapsed_.isValid() && stopElapsed_.elapsed() >= 5000) {
            stopTimeoutLogged_ = true;
            appendLog(tr("Camera source is still stopping after 5 seconds; waiting without unregistering GuardVision."));
        }
        return;
    }

    stopPollTimer_.stop();
    appendLog(tr("Media source quiesced; scheduling final camera cleanup on the next UI turn."));
    QTimer::singleShot(0, this, [this]() {
        if (stopping_) {
            finalizeStop();
        }
    });
}

void CameraRuntimeController::finalizeStop() {
    if (!stopping_) {
        return;
    }
    stopPollTimer_.stop();

    QVector<quint64> lostTrackIds;
    lostTrackIds.reserve(faceOverlays_.size());
    for (const CameraFaceOverlay& overlay : faceOverlays_) {
        if (overlay.trackId != 0) {
            lostTrackIds.append(overlay.trackId);
        }
    }
    const QString localCameraKey = camera_.localFaceTrackCameraKey();

    // Do not call GuardVision::unregisterStream() for a normal per-camera
    // Disconnect. Runtime logs proved that the Windows process terminated
    // inside that call when another camera remained active. The producer is
    // already fully quiescent and the active generation is zero, so retaining
    // the stream cannot accept stale CameraRuntimeController callbacks.
    // The same stream is reused on the next Connect, and the shared
    // GuardVision::shutdown() releases all retained streams after all camera
    // controllers have stopped.
    streamRetainedForReuse_ = streamRegistered_;
    activeGuardVisionGeneration_ = 0;
    if (streamRetainedForReuse_) {
        appendLog(tr("GuardVision stream retained for safe reconnect; per-stream unregister deferred to application shutdown."));
    }

    for (quint64 trackId : lostTrackIds) {
        emit faceTrackLost(localCameraKey, trackId);
    }
    capabilities_ = guard::CameraOnboardCapabilities{};
    resetRuntimeState();
    if (view_) {
        view_->clearFrame();
    }
    emit hazardSessionStopped(localCameraKey);
    setState(State::Disconnected, tr("Disconnected"));
    appendLog(tr("Camera stopped safely."));
    stoppingSourceGeneration_ = 0;
    stopTimeoutLogged_ = false;
    stopping_ = false;
}

void CameraRuntimeController::prepareForApplicationShutdown() {
    if (preparedForApplicationShutdown_) {
        return;
    }
    preparedForApplicationShutdown_ = true;

    // Stop every asynchronous producer from targeting this controller before
    // the application begins final process shutdown. This includes native
    // GuardVision callbacks, decoder-worker signals, and recorder-worker
    // signals. Disconnecting all three closes the windows that remained when
    // Exit was selected while a source was actively playing.
    if (eventAdapter_) {
        QObject::disconnect(eventAdapter_, nullptr, this, nullptr);
    }
    QObject::disconnect(&mediaController_, nullptr, this, nullptr);
    QObject::disconnect(&recorder_, nullptr, this, nullptr);

    stopPollTimer_.stop();
    stopSynchronouslyForDestruction();

    // isQuiescent() only means decoding has stopped; it does not mean the file
    // or RTSP QThread event loop has exited. Join those threads before Qt global
    // teardown begins. The worker objects themselves remain process-lifetime
    // because the controller is intentionally detached on final Exit.
    mediaController_.shutdownWorkerThreadsForApplicationExit();
    appendLog(tr("Media decoder worker threads joined for application shutdown."));

    // MotionVideoRecorder owns a std::thread and may still be finalizing a
    // decoded-frame MP4 when the media source has already become quiescent. Join
    // it explicitly while Qt/OpenCV are still alive. This is safe and separate
    // from the intentionally skipped GuardVision/vendor destruction path.
    recorder_.shutdown();
    appendLog(tr("Motion recording worker joined for application shutdown."));

    // Queued signal deliveries posted before disconnect() are not guaranteed to
    // be cancelled by Qt. Every producer thread is now joined, so no new events
    // can be posted and stale MetaCall deliveries can be safely discarded.
    QCoreApplication::removePostedEvents(&mediaController_, QEvent::MetaCall);
    QCoreApplication::removePostedEvents(&recorder_, QEvent::MetaCall);
    QCoreApplication::removePostedEvents(this, QEvent::MetaCall);
    appendLog(tr("Camera runtime prepared for coordinated application shutdown."));
}

void CameraRuntimeController::stopSynchronouslyForDestruction() {
    stopPollTimer_.stop();
    if (!stopping_) {
        beginStop();
    }
    if (!stopping_) {
        return;
    }

    // Destruction cannot leave producer callbacks alive. Waiting indefinitely
    // here is safe because the object is already leaving the UI lifecycle.
    mediaController_.stopAndWaitForQuiescence(0);
    appendLog(tr("Media source quiesced during controller destruction."));
    // MainWindow owns GuardVision and shuts it down only after all camera
    // controllers have drained their producers. Avoid unsafe per-stream vendor
    // teardown here as well.
    streamRetainedForReuse_ = streamRegistered_;
    activeGuardVisionGeneration_ = 0;
    if (streamRetainedForReuse_) {
        appendLog(tr("GuardVision stream retained for coordinated application shutdown."));
    }
    capabilities_ = guard::CameraOnboardCapabilities{};
    stoppingSourceGeneration_ = 0;
    stopping_ = false;
}

bool CameraRuntimeController::waitForGuardVisionStreamIdle(int timeoutMs, int quietPeriodMs) const {
    if (!streamRegistered_ || !guardVision_ || !guardVision_->isInitialized())
        return true;

    QElapsedTimer elapsed;
    QElapsedTimer quiet;
    elapsed.start();
    quiet.start();
    bool quietStarted = false;

    for (;;) {
        guardvision::StreamStatus status;
        const guardvision::Result result = guardVision_->getStreamStatus(streamId_.toStdString(), status);
        const bool busy = result.ok && (status.hasPendingFrame || status.processingFrame);
        if (busy || !result.ok) {
            quietStarted = false;
        } else if (!quietStarted) {
            quiet.restart();
            quietStarted = true;
        } else if (quiet.elapsed() >= quietPeriodMs) {
            return true;
        }

        if (timeoutMs > 0 && elapsed.elapsed() >= timeoutMs)
            return false;
        QThread::msleep(2);
    }
}

bool CameraRuntimeController::applyConfigsToRegisteredStream(const CameraDetectionSettings& settings, QString* errorMessage) {
    if (!streamRegistered_ || !guardVision_ || !guardVision_->isInitialized()) {
        return true;
    }

    const CameraDetectionSettings old = settings_;
    const guardvision::FaceConfig oldEffectiveFace = effectiveFaceConfig(old.face);
    const guardvision::FaceConfig newEffectiveFace = effectiveFaceConfig(settings.face);
    const bool motionChanged = !sameMotionConfig(old.motion, settings.motion);
    const bool faceChanged = !sameFaceConfig(oldEffectiveFace, newEffectiveFace);
    const bool hazardChanged = !sameHazardConfig(old.hazard, settings.hazard);

    guardvision::Result result = guardvision::Result::success();
    if (motionChanged) {
        result = guardVision_->setMotionConfig(streamId_.toStdString(), settings.motion);
        if (!result.ok) {
            if (errorMessage)
                *errorMessage = QString::fromStdString(result.error.message);
            return false;
        }
    }
    if (faceChanged) {
        result = guardVision_->setFaceConfig(streamId_.toStdString(), newEffectiveFace);
        if (!result.ok) {
            if (motionChanged)
                guardVision_->setMotionConfig(streamId_.toStdString(), old.motion);
            if (errorMessage)
                *errorMessage = QString::fromStdString(result.error.message);
            return false;
        }
    }
    if (hazardChanged) {
        result = guardVision_->setHazardConfig(streamId_.toStdString(), settings.hazard);
        if (!result.ok) {
            if (motionChanged)
                guardVision_->setMotionConfig(streamId_.toStdString(), old.motion);
            if (faceChanged)
                guardVision_->setFaceConfig(streamId_.toStdString(), oldEffectiveFace);
            if (errorMessage)
                *errorMessage = QString::fromStdString(result.error.message);
            return false;
        }
    }
    return true;
}

bool CameraRuntimeController::applyDetectionSettings(const CameraDetectionSettings& settings, QString* errorMessage) {
    return applyCameraSettings(settings, testSourceSettings_, errorMessage);
}

bool CameraRuntimeController::applyCameraSettings(const CameraDetectionSettings& settings, const CameraTestSourceSettings& testSourceSettings,
                                                  QString* errorMessage) {
    CameraTestSourceSettings normalizedTestSettings = testMode_ ? testSourceSettings : CameraTestSourceSettings{};
    if (!validateTestSourceSettings(normalizedTestSettings, errorMessage)) {
        return false;
    }
    if (normalizedTestSettings.usesFile()) {
        normalizedTestSettings.filePath = QFileInfo(normalizedTestSettings.filePath).absoluteFilePath();
    } else {
        normalizedTestSettings.filePath.clear();
    }

    CameraDetectionSettings normalizedSettings = settings;
    if (normalizedTestSettings.usesFile()) {
        const auto normalizeMode = [](guardvision::DetectionMode mode) {
            return (mode == guardvision::DetectionMode::OnboardTriggered || mode == guardvision::DetectionMode::Hybrid)
                     ? guardvision::DetectionMode::Software
                     : mode;
        };

        normalizedSettings.motion.detectionMode = normalizeMode(normalizedSettings.motion.detectionMode);
        normalizedSettings.motion.enabled = normalizedSettings.motion.detectionMode != guardvision::DetectionMode::Disabled;

        normalizedSettings.face.detectionMode = normalizeMode(normalizedSettings.face.detectionMode);
        normalizeEnabledFaceProcessing(normalizedSettings.face);

        normalizedSettings.hazard.detectionMode = normalizeMode(normalizedSettings.hazard.detectionMode);
        normalizedSettings.hazard.processingLevel = normalizedSettings.hazard.detectionMode == guardvision::DetectionMode::Disabled
                                                      ? guardvision::HazardProcessingLevel::Disabled
                                                      : guardvision::HazardProcessingLevel::Detect;
    }

    // Preserve identification as the configured intent. The effective runtime
    // config is downgraded to DetectAndTrack until a room-scoped registry is
    // available, then upgraded without changing the user's camera settings.
    normalizeEnabledFaceProcessing(normalizedSettings.face);

    const bool sourceChanged = normalizedTestSettings != testSourceSettings_;
    const bool detectionSettingsChanged = !sameDetectionSettings(normalizedSettings, settings_);
    const bool wasRunning = mediaController_.isRunning() || (streamRegistered_ && !streamRetainedForReuse_);

    if (sourceReplacementInProgress_) {
        if (errorMessage)
            *errorMessage = tr("A camera source replacement is already in progress.");
        return false;
    }

    // Never reconfigure a registered native stream while its old image/video
    // producer is still submitting frames. Stop and fully quiesce the old source
    // first, then require a short continuous-idle period before changing any
    // GuardVision configuration or opening the replacement file.
    if (sourceChanged && wasRunning) {
        sourceReplacementInProgress_ = true;
        appendLog(tr("Test source replacement started; stopping the current source before reconfiguration."));
        stop();
        if (stopping_ || mediaController_.isRunning() || activeSourceGeneration_ != 0) {
            sourceReplacementInProgress_ = false;
            if (errorMessage && errorMessage->isEmpty())
                *errorMessage = tr("The current source could not be stopped safely for replacement.");
            return false;
        }
        if (!waitForGuardVisionStreamIdle(5000)) {
            sourceReplacementInProgress_ = false;
            if (errorMessage)
                *errorMessage = tr("GuardVision did not become idle before source replacement.");
            appendLog(errorMessage ? *errorMessage : tr("GuardVision did not become idle before source replacement."));
            return false;
        }
    }

    // A pure source replacement keeps the existing stream configuration. This
    // avoids touching vendor face/hazard sessions that can still be completing
    // delayed event state transitions after the final old frame.
    if (detectionSettingsChanged && !applyConfigsToRegisteredStream(normalizedSettings, errorMessage)) {
        sourceReplacementInProgress_ = false;
        return false;
    }

    settings_ = normalizedSettings;
    testSourceSettings_ = normalizedTestSettings;
    recorder_.setEnabled(settings_.recordVideoForMotion);
    if (settings_.recordVideoForMotion && activeSourceGeneration_ != 0) {
        recorder_.updateStreamInfo(activeSourceGeneration_, mediaController_.encodedStreamInfo());
    }
    clearDisabledOverlays();

    appendLog(tr("Detection settings updated: motion=%1, face=%2, hazard=%3, record=%4")
                .arg(static_cast<int>(settings_.motion.detectionMode))
                .arg(static_cast<int>(settings_.face.detectionMode))
                .arg(static_cast<int>(settings_.hazard.detectionMode))
                .arg(settings_.recordVideoForMotion ? tr("on") : tr("off")));

    if (testMode_) {
        if (testSourceSettings_.usesFile()) {
            appendLog(tr("Per-camera test source updated: %1").arg(QFileInfo(testSourceSettings_.filePath).fileName()));
        } else {
            appendLog(tr("Per-camera test source disabled; configured camera source will be used."));
        }
    }

    emit settingsChanged(camera_.id);

    if (sourceChanged && wasRunning) {
        appendLog(tr("Starting the replacement test source after the previous source quiesced."));
        const bool started = start(errorMessage);
        sourceReplacementInProgress_ = false;
        if (started)
            appendLog(tr("Test source replacement completed safely."));
        return started;
    }
    sourceReplacementInProgress_ = false;
    return true;
}

guardvision::FaceConfig CameraRuntimeController::effectiveFaceConfig(const guardvision::FaceConfig& configured) const {
    guardvision::FaceConfig effective = configured;
    if (effective.detectionMode == guardvision::DetectionMode::Disabled) {
        effective.processingLevel = guardvision::FaceProcessingLevel::Disabled;
        return effective;
    }

    if (nativeFaceIdentificationPrepared_) {
        normalizeEnabledFaceProcessing(effective);
    } else {
        // Starting IdentifyEngine without a room-scoped registry caused the
        // vendor face session to terminate the process several seconds after an
        // unknown face first appeared. Detection and tracking do not require the
        // registry and are safe for local/no-room monitoring.
        effective.processingLevel = guardvision::FaceProcessingLevel::DetectAndTrack;
    }
    return effective;
}

bool CameraRuntimeController::prepareFaceIdentification(float threshold, QString* errorMessage) {
    if (settings_.face.detectionMode == guardvision::DetectionMode::Disabled) {
        faceIdentificationRequested_ = false;
        faceIdentificationEnabled_ = false;
        if (errorMessage)
            *errorMessage = tr("Face detection is disabled for this camera.");
        return false;
    }

    settings_.face.minimumIdentificationConfidence = threshold;
    faceIdentificationRequested_ = true;

    // A retained process-lifetime GuardVision slot carries its already-created
    // native Identify session into the replacement room controller. Reapplying
    // setFaceConfig() to that same prepared session re-enters the vendor face
    // lifecycle and can terminate the process before the new media source even
    // starts. Preparation is therefore strictly idempotent.
    if (nativeFaceIdentificationPrepared_) {
        retainedStreamNativeFaceIdentificationPrepared_ = true;
        return true;
    }

    // Do not mark the native session as prepared before a stream actually
    // exists. Room restoration creates controllers before the user presses
    // Connect; confusing registry intent with native state caused the retained
    // slot to be reconfigured synchronously during adoption.
    if (!isGuardVisionStreamActive() || !guardVision_ || !guardVision_->isInitialized()) {
        return true;
    }

    guardvision::FaceConfig identifyConfig = settings_.face;
    normalizeEnabledFaceProcessing(identifyConfig);
    identifyConfig.minimumIdentificationConfidence = threshold;

    const guardvision::Result result = guardVision_->setFaceConfig(streamId_.toStdString(), identifyConfig);
    if (result.ok) {
        nativeFaceIdentificationPrepared_ = true;
        retainedStreamNativeFaceIdentificationPrepared_ = true;
        appendLog(tr("Face identification engine prepared for the room registry."));
        return true;
    }

    // Do not issue a second setFaceConfig() as a rollback. A second synchronous
    // vendor-session transition after failure is unsafe and is unnecessary:
    // the stream continues in its existing detect-and-track mode.
    faceIdentificationRequested_ = false;
    faceIdentificationEnabled_ = false;
    const QString message = QString::fromStdString(result.error.message);
    appendLog(tr("Face identification preparation failed; detect-and-track remains active: %1").arg(message));
    if (errorMessage) {
        *errorMessage = message;
    }
    if (result.error.code == guardvision::GuardVisionErrorCode::FaceModelMissing ||
        (result.error.code == guardvision::GuardVisionErrorCode::FaceEngineInitializationFailed && !result.error.recoverable)) {
        emit faceIdentificationUnavailable(camera_.id, message);
    }
    return false;
}

void CameraRuntimeController::suspendFaceIdentification() {
    const bool wasEnabled = faceIdentificationEnabled_;
    faceIdentificationRequested_ = false;
    faceIdentificationEnabled_ = false;
    faceDisplayNamesById_.clear();

    bool overlaysChanged = false;
    for (CameraFaceOverlay& overlay : faceOverlays_) {
        if (overlay.identified || overlay.faceRegistryId != 0 || !overlay.displayName.isEmpty()) {
            overlay.identified = false;
            overlay.faceRegistryId = 0;
            overlay.displayName.clear();
            overlay.identityConfidence = 0.0;
            overlaysChanged = true;
        }
    }
    if (overlaysChanged && view_) {
        const guardvision::NormalizedRect& roi = settings_.face.roi;
        view_->setFaceOverlays(faceOverlays_, QRectF(roi.x, roi.y, roi.width, roi.height), settings_.face.useRoi);
    }

    // Do not downgrade a prepared native stream here. Changing away from
    // Identify can tear down the same vendor session that made per-stream
    // unregister unsafe. Guard instead masks identity payloads until a new
    // room registry is accepted.
    if (wasEnabled) {
        appendLog(tr("Face identification results suspended because no active room registry is available; face tracking remains active."));
    }
}

void CameraRuntimeController::syncFaceIdentificationFromRegistry(float threshold, const QHash<quint64, QString>& displayNamesById) {
    faceDisplayNamesById_ = displayNamesById;
    settings_.face.minimumIdentificationConfidence = threshold;
    faceIdentificationRequested_ = true;

    // Room cameras are restored before the user presses Connect. Cache the
    // registry request now, but never infer that a native Identify session is
    // prepared until the retained/fresh stream is active. The direct
    // guardVisionStreamRegistered callback invokes this method again before the
    // first media frame is submitted.
    if (!isGuardVisionStreamActive()) {
        faceIdentificationEnabled_ = false;
        return;
    }

    if (!nativeFaceIdentificationPrepared_) {
        QString preparationError;
        if (!prepareFaceIdentification(threshold, &preparationError)) {
            return;
        }
    }
    faceIdentificationEnabled_ = true;

    bool overlaysChanged = false;
    for (CameraFaceOverlay& overlay : faceOverlays_) {
        if (overlay.faceRegistryId > 0 && overlay.displayName.trimmed().isEmpty()) {
            overlay.displayName = faceDisplayNamesById_.value(overlay.faceRegistryId).trimmed();
        }
        const bool identified = overlay.faceRegistryId > 0 && !overlay.displayName.trimmed().isEmpty();
        if (overlay.identified != identified) {
            overlay.identified = identified;
            overlaysChanged = true;
        }
    }
    if (overlaysChanged && view_) {
        const guardvision::NormalizedRect& roi = settings_.face.roi;
        view_->setFaceOverlays(faceOverlays_, QRectF(roi.x, roi.y, roi.width, roi.height), settings_.face.useRoi);
    }
}

void CameraRuntimeController::handleDecodedFrame(const QImage& frame, quint64 sequence, qint64 timestampMs, quint64 generation) {
    if (stopping_ || generation != activeSourceGeneration_) {
        appendLog(tr("Dropped stale decoded frame: cameraId=%1 expectedGeneration=%2 receivedGeneration=%3 sourceType=%4 mediaPath=%5")
                    .arg(camera_.id)
                    .arg(activeSourceGeneration_)
                    .arg(generation)
                    .arg(testSourceSettings_.usesFile() ? static_cast<int>(testSourceSettings_.type) : 0)
                    .arg(testSourceSettings_.filePath));
        return;
    }
    latestFrame_ = frame;
    RecentFrame recent;
    recent.sequence = sequence;
    recent.timestampMs = timestampMs;
    recentFrames_.append(recent);
    while (recentFrames_.size() > 12)
        recentFrames_.removeFirst();
    if (view_) {
        view_->setFrame(frame);
    }

    const bool stillImageSource = mediaController_.activeType() == FrameSourceType::ImageFile;
    if (stillImageSource) {
        const bool hazardEnabled = settings_.hazard.detectionMode != guardvision::DetectionMode::Disabled &&
                                   settings_.hazard.processingLevel == guardvision::HazardProcessingLevel::Detect;
        const int pipelineIntervalMs = hazardEnabled ? kStillImageHazardPipelineIntervalMs : kStillImagePipelineIntervalMs;
        const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
        if (nowMs - lastStillImagePipelineMs_ < pipelineIntervalMs) {
            return;
        }
        lastStillImagePipelineMs_ = nowMs;
    }

    recorder_.submitDecodedFrame(frame, timestampMs, generation);

    if (stillImageSource) {
        // A test photo repeatedly emits the same pixels. That is useful for
        // preview and decoded-frame recording, but feeding the same unknown
        // face forever into the native Identify/tracking session makes rapid
        // Connect/Disconnect cycles unsafe. Submit a short stable sample
        // window for analytics, then keep the camera preview and recording
        // path alive without continuing to stress the native face pipeline.
        if (stillImageGuardVisionSubmissions_ >= kMaxStillImageGuardVisionSubmissions) {
            if (!stillImageSubmissionPausedLogged_) {
                stillImageSubmissionPausedLogged_ = true;
                appendLog(tr("Still-image analytics submission paused after the stable sample window; preview and recording remain active."));
            }
            return;
        }
        ++stillImageGuardVisionSubmissions_;
    }

    if (!guardVision_) {
        return;
    }

    bool shouldStop = false;
    const guardvision::SubmitResult result = FrameSubmissionPipeline::submitDecodedFrame(
      *guardVision_, streamId_, streamRegistered_, FrameSubmissionPipeline::fromRgbImage(frame, sequence, timestampMs, generation),
      activeSourceGeneration_, submissionState_, &shouldStop);

    if (result.accepted && submissionState_.counters.accepted == 1) {
        appendLog(tr("First frame accepted by GuardVision. Source: %1; shared frame pipeline active.")
                    .arg(frameSourceTypeLabel(mediaController_.activeType())));
    } else if (!result.accepted && submissionState_.counters.rejected == 1) {
        appendLog(tr("First frame rejected by GuardVision: %1").arg(QString::fromStdString(result.error.message)));
    }
    if (shouldStop) {
        const QString message = tr("Frame submission failed and the camera was stopped: %1").arg(QString::fromStdString(result.error.message));
        appendLog(message);
        stop();
        setState(State::Error, message);
        emit fatalRuntimeError(camera_.id, message);
    }
}

QImage CameraRuntimeController::frameForEvent(quint64 sequence, qint64 timestampMs) const {
    if (latestFrame_.isNull()) {
        return QImage();
    }
    if (sequence != 0) {
        for (int i = recentFrames_.size() - 1; i >= 0; --i) {
            if (recentFrames_.at(i).sequence == sequence) {
                return latestFrame_.copy();
            }
        }
    }
    int bestIndex = -1;
    qint64 bestDistance = 0;
    for (int i = 0; i < recentFrames_.size(); ++i) {
        const qint64 distance = qAbs(recentFrames_.at(i).timestampMs - timestampMs);
        if (bestIndex < 0 || distance < bestDistance) {
            bestIndex = i;
            bestDistance = distance;
        }
    }
    Q_UNUSED(bestIndex);
    return latestFrame_.copy();
}

void CameraRuntimeController::onMotionEvent(QString streamId, int eventType, int, quint64 generation, quint64, qint64 timestampMs, double, double,
                                            int, int, int, int, int, QVector<QRect> regions, QVector<double> regionScores,
                                            QVector<double> regionAreaRatios) {
    if (streamId != streamId_) {
        return;
    }
    const guardvision::MotionEventType type = static_cast<guardvision::MotionEventType>(eventType);
    if (!streamRegistered_ || activeGuardVisionGeneration_ == 0 || generation != activeGuardVisionGeneration_) {
        appendLog(tr("Dropped stale GuardVision motion event: cameraId=%1 eventGeneration=%2 activeGuardVisionGeneration=%3 eventType=%4")
                    .arg(camera_.id)
                    .arg(generation)
                    .arg(activeGuardVisionGeneration_)
                    .arg(eventType));
        return;
    }
    const quint64 sourceGeneration = activeSourceGeneration_;
    if (sourceGeneration == 0) {
        return;
    }
    if (type == guardvision::MotionEventType::Started) {
        recorder_.notifyMotionStarted(timestampMs, sourceGeneration);
        appendLog(tr("Motion started."));
    } else if (type == guardvision::MotionEventType::Updated) {
        recorder_.notifyMotionUpdated(timestampMs, sourceGeneration);
    } else if (type == guardvision::MotionEventType::Ended) {
        recorder_.notifyMotionEnded(timestampMs, sourceGeneration);
        appendLog(tr("Motion ended."));
    }

    if (type == guardvision::MotionEventType::Started || type == guardvision::MotionEventType::Updated) {
        motionOverlays_.clear();
        for (int i = 0; i < regions.size(); ++i) {
            CameraMotionOverlay overlay;
            overlay.bounds = regions.at(i);
            overlay.score = i < regionScores.size() ? regionScores.at(i) : 0.0;
            overlay.changedAreaRatio = i < regionAreaRatios.size() ? regionAreaRatios.at(i) : 0.0;
            motionOverlays_.append(overlay);
        }
    } else if (type == guardvision::MotionEventType::Ended) {
        motionOverlays_.clear();
    }
    refreshMotionOverlay();
}

void CameraRuntimeController::onFaceEvent(QString streamId, int eventType, quint64 generation, quint64 sequence, qint64 timestampMs,
                                          QVector<QRect> bounds, QVector<quint64> trackIds, QVector<quint64> identityIds,
                                          QVector<QString> displayNames, QVector<double> confidences, QVector<bool> identifiedFlags) {
    if (streamId != streamId_) {
        return;
    }
    if (!streamRegistered_ || activeGuardVisionGeneration_ == 0 || generation != activeGuardVisionGeneration_) {
        return;
    }

    const guardvision::FaceEventType type = static_cast<guardvision::FaceEventType>(eventType);
    if (type == guardvision::FaceEventType::TrackLost) {
        for (quint64 trackId : trackIds) {
            emit faceTrackLost(camera_.localFaceTrackCameraKey(), trackId);
            for (int i = faceOverlays_.size() - 1; i >= 0; --i) {
                if (faceOverlays_.at(i).trackId == trackId)
                    faceOverlays_.remove(i);
            }
        }
        if (trackIds.isEmpty())
            faceOverlays_.clear();
        if (view_) {
            const guardvision::NormalizedRect& roi = settings_.face.roi;
            view_->setFaceOverlays(faceOverlays_, QRectF(roi.x, roi.y, roi.width, roi.height), settings_.face.useRoi);
        }
        return;
    }

    if (type != guardvision::FaceEventType::TracksUpdated && type != guardvision::FaceEventType::TrackAppeared &&
        type != guardvision::FaceEventType::IdentityMatched && type != guardvision::FaceEventType::IdentityChanged) {
        return;
    }

    QVector<CameraFaceOverlay> overlays;
    overlays.reserve(bounds.size());
    for (int i = 0; i < bounds.size(); ++i) {
        QRect safeBounds = bounds.at(i).normalized();
        if (!latestFrame_.isNull())
            safeBounds = safeBounds.intersected(latestFrame_.rect());
        if (safeBounds.isEmpty())
            continue;

        CameraFaceOverlay overlay;
        overlay.bounds = safeBounds;
        overlay.trackId = i < trackIds.size() ? trackIds.at(i) : 0;
        overlay.faceRegistryId = faceIdentificationEnabled_ && i < identityIds.size() ? identityIds.at(i) : 0;
        overlay.displayName = faceIdentificationEnabled_ && i < displayNames.size() ? displayNames.at(i).trimmed() : QString();
        const double rawConfidence = faceIdentificationEnabled_ && i < confidences.size() ? confidences.at(i) : 0.0;
        overlay.identityConfidence = std::isfinite(rawConfidence) ? qBound(0.0, rawConfidence, 1.0) : 0.0;

        if (overlay.displayName.isEmpty() && overlay.faceRegistryId > 0) {
            overlay.displayName = faceDisplayNamesById_.value(overlay.faceRegistryId).trimmed();
        }

        const bool guardVisionIdentified = faceIdentificationEnabled_ && i < identifiedFlags.size() ? identifiedFlags.at(i) : false;
        overlay.identified = (guardVisionIdentified || overlay.faceRegistryId > 0) && overlay.faceRegistryId > 0 && !overlay.displayName.isEmpty();

        preserveResolvedFaceIdentity(overlay, findFaceOverlayByTrackId(faceOverlays_, overlay.trackId));
        overlays.append(overlay);

        GuardFaceOccurrence occurrence;
        occurrence.camera = camera_;
        occurrence.trackId = overlay.trackId;
        occurrence.faceRegistryId = overlay.faceRegistryId;
        occurrence.identified = overlay.identified;
        occurrence.displayName = overlay.displayName;
        occurrence.similarity = overlay.identityConfidence;
        occurrence.bounds = overlay.bounds;
        occurrence.timestampMs = timestampMs;
        occurrence.frame = frameForEvent(sequence, timestampMs);
        emit faceOccurrenceReady(occurrence);
    }

    if (type == guardvision::FaceEventType::TracksUpdated) {
        // TracksUpdated is a geometry refresh for all active tracks. Preserve the
        // last resolved identity for each track when the tracking payload omits it.
        faceOverlays_ = overlays;
    } else {
        for (const CameraFaceOverlay& overlay : overlays) {
            bool updated = false;
            if (overlay.trackId != 0) {
                for (int i = 0; i < faceOverlays_.size(); ++i) {
                    if (faceOverlays_.at(i).trackId == overlay.trackId) {
                        faceOverlays_[i] = overlay;
                        updated = true;
                        break;
                    }
                }
            }
            if (!updated)
                faceOverlays_.append(overlay);
        }
    }
    if (view_) {
        const guardvision::NormalizedRect& roi = settings_.face.roi;
        view_->setFaceOverlays(faceOverlays_, QRectF(roi.x, roi.y, roi.width, roi.height), settings_.face.useRoi);
    }
}

void CameraRuntimeController::onHazardEvent(QString streamId, int eventType, quint64 generation, quint64 sequence, qint64 timestampMs,
                                            QVector<QRect> bounds, QVector<int> hazardTypes, QVector<double> confidences) {
    if (streamId != streamId_) {
        return;
    }
    if (!streamRegistered_ || activeGuardVisionGeneration_ == 0 || generation != activeGuardVisionGeneration_) {
        return;
    }

    const guardvision::HazardEventType type = static_cast<guardvision::HazardEventType>(eventType);
    if (type == guardvision::HazardEventType::Ended) {
        if (hazardTypes.isEmpty()) {
            fireOverlays_.clear();
            smokeOverlays_.clear();
            appendLog(tr("Hazard ended."));
        } else {
            for (int hazardType : hazardTypes) {
                if (hazardType == static_cast<int>(guardvision::HazardType::Smoke)) {
                    smokeOverlays_.clear();
                    appendLog(tr("Smoke ended."));
                } else {
                    fireOverlays_.clear();
                    appendLog(tr("Fire ended."));
                }
            }
        }
    } else {
        fireOverlays_.clear();
        smokeOverlays_.clear();
        for (int i = 0; i < bounds.size(); ++i) {
            CameraHazardOverlay overlay;
            overlay.bounds = bounds.at(i);
            overlay.hazardType = i < hazardTypes.size() ? hazardTypes.at(i) : static_cast<int>(guardvision::HazardType::Fire);
            overlay.confidence = i < confidences.size() ? confidences.at(i) : 0.0;
            if (overlay.hazardType == static_cast<int>(guardvision::HazardType::Smoke)) {
                smokeOverlays_.append(overlay);
            } else {
                fireOverlays_.append(overlay);
            }
        }
        if (type == guardvision::HazardEventType::Started) {
            if (!fireOverlays_.isEmpty())
                appendLog(tr("Fire started."));
            if (!smokeOverlays_.isEmpty())
                appendLog(tr("Smoke started."));
        }
    }
    refreshHazardOverlays();

    GuardHazardOccurrence occurrence;
    occurrence.camera = camera_;
    occurrence.eventType = eventType;
    occurrence.timestampMs = timestampMs;
    occurrence.frame = frameForEvent(sequence, timestampMs);
    const int detectionCount = qMax(bounds.size(), qMax(hazardTypes.size(), confidences.size()));
    for (int i = 0; i < detectionCount; ++i) {
        GuardHazardDetection detection;
        detection.bounds = i < bounds.size() ? bounds.at(i) : QRect();
        detection.hazardType = i < hazardTypes.size() ? hazardTypes.at(i) : static_cast<int>(guardvision::HazardType::Fire);
        detection.confidence = i < confidences.size() ? confidences.at(i) : 0.0;
        occurrence.detections.append(detection);
    }
    emit hazardOccurrenceReady(occurrence);
}

void CameraRuntimeController::onAlarmEvent(QString streamId, quint64 generation, int alarmType, int alarmState, int, qint64 timestampMs, double,
                                           QVector<QRect>, QString, quint64) {
    if (streamId != streamId_) {
        return;
    }
    if (!streamRegistered_ || activeGuardVisionGeneration_ == 0 || generation != activeGuardVisionGeneration_) {
        appendLog(
          tr("Dropped stale GuardVision alarm event: cameraId=%1 eventGeneration=%2 activeGuardVisionGeneration=%3 alarmType=%4 alarmState=%5")
            .arg(camera_.id)
            .arg(generation)
            .arg(activeGuardVisionGeneration_)
            .arg(alarmType)
            .arg(alarmState));
        return;
    }
    const quint64 sourceGeneration = activeSourceGeneration_;
    if (sourceGeneration == 0) {
        return;
    }
    const guardvision::AlarmType type = static_cast<guardvision::AlarmType>(alarmType);
    const guardvision::AlarmState state = static_cast<guardvision::AlarmState>(alarmState);
    if (type == guardvision::AlarmType::Motion && (settings_.motion.detectionMode == guardvision::DetectionMode::OnboardTriggered ||
                                                   settings_.motion.detectionMode == guardvision::DetectionMode::Hybrid)) {
        if (state == guardvision::AlarmState::Started) {
            recorder_.notifyMotionStarted(timestampMs, sourceGeneration);
        } else if (state == guardvision::AlarmState::Updated) {
            recorder_.notifyMotionUpdated(timestampMs, sourceGeneration);
        } else if (state == guardvision::AlarmState::Ended) {
            recorder_.notifyMotionEnded(timestampMs, sourceGeneration);
        }
    }
}

void CameraRuntimeController::refreshMotionOverlay() {
    if (!view_) {
        return;
    }
    const guardvision::NormalizedRect& roi = settings_.motion.roi;
    const bool show = settings_.motion.useRoi && settings_.motion.detectionMode != guardvision::DetectionMode::Disabled;
    view_->setMotionOverlays(motionOverlays_, QRectF(roi.x, roi.y, roi.width, roi.height), show);
}

void CameraRuntimeController::refreshHazardOverlays() {
    if (!view_) {
        return;
    }
    QVector<CameraHazardOverlay> merged = fireOverlays_;
    merged += smokeOverlays_;
    const guardvision::NormalizedRect& roi = settings_.hazard.roi;
    view_->setHazardOverlays(merged, QRectF(roi.x, roi.y, roi.width, roi.height), settings_.hazard.useRoi);
}

bool CameraRuntimeController::shouldUseFreshStreamForStillImageFaceSession() const {
    if (!testMode_ || testSourceSettings_.type != CameraTestSourceType::ImageFile)
        return false;
    if (settings_.face.detectionMode == guardvision::DetectionMode::Disabled ||
        settings_.face.processingLevel == guardvision::FaceProcessingLevel::Disabled) {
        return false;
    }

    // A first connect has no native slot to retire. The dangerous path is a
    // reconnect of the same static photo into a retained native stream that may
    // still own unknown-face tracker/Identify state from the previous session.
    return streamRegistered_ || streamRetainedForReuse_ || ownsReusableGuardVisionStreamSlot_ || nativeFaceIdentificationPrepared_;
}

void CameraRuntimeController::retireRetainedStreamForFreshStillImageFaceSession() {
    const QString previousStreamId = streamId_;
    streamId_ = makeControllerStreamId(camera_.id);

    streamRegistered_ = false;
    ownsReusableGuardVisionStreamSlot_ = false;
    streamRetainedForReuse_ = false;
    retainedStreamNativeFaceIdentificationPrepared_ = false;
    registeredGuardVisionGeneration_ = 0;
    activeGuardVisionGeneration_ = 0;
    nativeFaceIdentificationPrepared_ = false;
    faceIdentificationEnabled_ = false;
    faceOverlays_.clear();
    submissionState_ = SubmissionState{};
    lastStillImagePipelineMs_ = 0;
    stillImageGuardVisionSubmissions_ = 0;
    stillImageSubmissionPausedLogged_ = false;

    if (!previousStreamId.isEmpty()) {
        appendLog(
          tr("Still-image face analytics reconnect uses a fresh GuardVision stream; previous stream %1 is retained until application shutdown.")
            .arg(previousStreamId));
    }
}

void CameraRuntimeController::clearDisabledOverlays() {
    if (!view_) {
        return;
    }
    if (settings_.motion.detectionMode == guardvision::DetectionMode::Disabled) {
        motionOverlays_.clear();
        view_->clearMotionOverlays();
    } else {
        refreshMotionOverlay();
    }
    if (settings_.face.detectionMode == guardvision::DetectionMode::Disabled) {
        faceOverlays_.clear();
        view_->setFaceOverlays(QVector<CameraFaceOverlay>(), QRectF(), false);
    }
    if (settings_.hazard.detectionMode == guardvision::DetectionMode::Disabled) {
        fireOverlays_.clear();
        smokeOverlays_.clear();
        view_->clearHazardOverlays();
    } else {
        refreshHazardOverlays();
    }
}

void CameraRuntimeController::resetRuntimeState() {
    submissionState_ = SubmissionState{};
    lastStillImagePipelineMs_ = 0;
    stillImageGuardVisionSubmissions_ = 0;
    stillImageSubmissionPausedLogged_ = false;
    recentFrames_.clear();
    latestFrame_ = QImage();
    faceOverlays_.clear();
    motionOverlays_.clear();
    fireOverlays_.clear();
    smokeOverlays_.clear();
    if (view_) {
        view_->clearAllOverlays();
    }
}

void CameraRuntimeController::setState(State state, const QString& message) {
    if (state_ == state && message.isEmpty()) {
        return;
    }
    const State previousState = state_;
    state_ = state;
    const QString detail = message.trimmed().isEmpty() ? QString() : QStringLiteral("; %1").arg(message.trimmed());
    appendLog(QStringLiteral("Camera state changed: %1 -> %2%3").arg(cameraRuntimeStateName(previousState), cameraRuntimeStateName(state_), detail));
    emit stateChanged(camera_.id, static_cast<int>(state_), message);
}

void CameraRuntimeController::appendLog(const QString& message) {
    if (message.trimmed().isEmpty()) {
        return;
    }
    const QString timestamp = QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz"));
    const QString entry = QStringLiteral("%1  %2").arg(timestamp, message);
    logs_.append(entry);
    while (logs_.size() > 1000) {
        logs_.removeFirst();
    }

    QString failureEntry;
    QString fileLogError;
    if (fileLoggingEnabled_ && fileLogger_.isReady() && fileLogger_.appendLine(entry, &fileLogError)) {
        lastFileLogError_.clear();
    } else if (!fileLogError.isEmpty() && fileLogError != lastFileLogError_) {
        lastFileLogError_ = fileLogError;
        failureEntry = QStringLiteral("%1  %2").arg(timestamp, tr("Camera log file write failed: %1").arg(fileLogError));
        logs_.append(failureEntry);
        while (logs_.size() > 1000) {
            logs_.removeFirst();
        }
    }

    emit logAppended(camera_.id, entry);
    if (!failureEntry.isEmpty()) {
        emit logAppended(camera_.id, failureEntry);
    }
}
