import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { defineConfig } from 'vitest/config';

const root = path.dirname(fileURLToPath(import.meta.url));

function readDatabaseUrlFromEnvFile(): string | undefined {
	try {
		const content = readFileSync(path.resolve(root, '.env'), 'utf8');
		const match = content.match(/^DATABASE_URL=(.+)$/m);
		return match?.[1]?.trim();
	} catch {
		return undefined;
	}
}

export default defineConfig({
	resolve: {
		alias: {
			'@': path.resolve(root, 'src')
		}
	},
	test: {
		environment: 'node',
		include: ['src/**/*.{test,spec}.ts'],
		env: {
			DATABASE_URL: readDatabaseUrlFromEnvFile() ?? 'postgresql://postgres:test@127.0.0.1:5432/test'
		}
	}
});
