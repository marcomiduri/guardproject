CREATE TABLE "users" (
	"id" text PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"email" text NOT NULL,
	"password_hash" text NOT NULL,
	"role" text DEFAULT 'user' NOT NULL,
	"face_registry_id" integer,
	"face_registered_at" timestamp,
	"face_embedding" jsonb,
	"face_model" text,
	"birthday" date,
	"job" text,
	"position" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE SEQUENCE "user_face_registry_id_seq" START WITH 1000;
--> statement-breakpoint
CREATE TABLE "guard_cameras" (
	"id" text PRIMARY KEY NOT NULL,
	"room_id" text NOT NULL,
	"installation_id" text,
	"client_camera_id" text,
	"name" text DEFAULT '' NOT NULL,
	"type" text DEFAULT 'hikvision' NOT NULL,
	"direction" text DEFAULT 'in' NOT NULL,
	"device_address" text NOT NULL,
	"sdk_port" integer DEFAULT 8000 NOT NULL,
	"rtsp_port" integer DEFAULT 554 NOT NULL,
	"rtsp_url" text,
	"username" text DEFAULT 'admin' NOT NULL,
	"password" text DEFAULT '' NOT NULL,
	"channel" integer DEFAULT 1 NOT NULL,
	"stream_type" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'unknown' NOT NULL,
	"last_seen_at" timestamp,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "guard_cameras_direction_check" CHECK ("guard_cameras"."direction" in ('in', 'out')),
	CONSTRAINT "guard_cameras_status_check" CHECK ("guard_cameras"."status" in ('online', 'offline', 'unknown'))
);
--> statement-breakpoint
CREATE TABLE "guard_face_appearances" (
	"id" text PRIMARY KEY NOT NULL,
	"face_registry_id" integer,
	"user_id" text,
	"room_id" text NOT NULL,
	"camera_id" text NOT NULL,
	"camera_name" text,
	"camera_address" text,
	"direction" text NOT NULL,
	"event_type" text NOT NULL,
	"recognition_status" text DEFAULT 'IDENTIFIED' NOT NULL,
	"similarity" real,
	"approved" boolean,
	"track_id" integer,
	"source" text DEFAULT 'GUARD' NOT NULL,
	"supersedes_event_id" text,
	"rectangle" jsonb,
	"has_face_image" boolean DEFAULT false NOT NULL,
	"occurred_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "guard_face_appearances_direction_check" CHECK ("guard_face_appearances"."direction" in ('in', 'out'))
);
--> statement-breakpoint
CREATE TABLE "guard_hazard_events" (
	"id" text PRIMARY KEY NOT NULL,
	"room_id" text NOT NULL,
	"camera_id" text NOT NULL,
	"hazard_type" text NOT NULL,
	"confidence" real,
	"detections" jsonb,
	"status" text DEFAULT 'NEW' NOT NULL,
	"source" text DEFAULT 'GUARD' NOT NULL,
	"test_scenario" text,
	"has_snapshot_image" boolean DEFAULT false NOT NULL,
	"snapshot_path" text,
	"snapshot_width" integer,
	"snapshot_height" integer,
	"snapshot_size_bytes" integer,
	"occurred_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"acknowledged_at" timestamp,
	"acknowledged_by" text,
	"resolved_at" timestamp,
	"resolved_by" text
);
--> statement-breakpoint
CREATE TABLE "guard_installation_room_assignments" (
	"id" text PRIMARY KEY NOT NULL,
	"installation_id" text NOT NULL,
	"room_id" text NOT NULL,
	"connected_at" timestamp DEFAULT now() NOT NULL,
	"disconnected_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "guard_installations" (
	"id" text PRIMARY KEY NOT NULL,
	"room_id" text NOT NULL,
	"hardware_id_hash" text,
	"device_name" text DEFAULT 'Guard' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"application_version" text,
	"device_token_hash" text NOT NULL,
	"previous_device_token_hash" text,
	"device_token_issued_at" timestamp DEFAULT now() NOT NULL,
	"device_token_rotated_at" timestamp,
	"registered_at" timestamp DEFAULT now() NOT NULL,
	"last_seen_at" timestamp DEFAULT now() NOT NULL,
	"revoked_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "guard_installations_status_check" CHECK ("guard_installations"."status" in ('active', 'disconnected', 'revoked'))
);
--> statement-breakpoint
CREATE TABLE "guard_room_activation_codes" (
	"id" text PRIMARY KEY NOT NULL,
	"room_id" text NOT NULL,
	"code_hash" text NOT NULL,
	"expires_at" timestamp NOT NULL,
	"max_uses" integer DEFAULT 1 NOT NULL,
	"used_count" integer DEFAULT 0 NOT NULL,
	"used_at" timestamp,
	"used_by_installation_id" text,
	"created_by" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"revoked_at" timestamp,
	CONSTRAINT "guard_room_activation_codes_max_uses_check" CHECK ("guard_room_activation_codes"."max_uses" > 0),
	CONSTRAINT "guard_room_activation_codes_used_count_check" CHECK ("guard_room_activation_codes"."used_count" >= 0)
);
--> statement-breakpoint
CREATE TABLE "guard_room_occupancy" (
	"room_id" text PRIMARY KEY NOT NULL,
	"current_count" integer DEFAULT 0 NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "guard_room_presence" (
	"room_id" text NOT NULL,
	"user_id" text NOT NULL,
	"entered_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "guard_room_presence_room_id_user_id_pk" PRIMARY KEY("room_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "guard_rooms" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"max_members" integer DEFAULT 1 NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "in_out_event_images" (
	"id" text PRIMARY KEY NOT NULL,
	"event_id" text NOT NULL,
	"image_type" text NOT NULL,
	"storage_path" text NOT NULL,
	"mime_type" text NOT NULL,
	"width" integer NOT NULL,
	"height" integer NOT NULL,
	"size_bytes" integer NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "room_orders" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"room_id" text NOT NULL,
	"start_time" timestamp NOT NULL,
	"end_time" timestamp NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "guard_cameras" ADD CONSTRAINT "guard_cameras_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_cameras" ADD CONSTRAINT "guard_cameras_installation_id_guard_installations_id_fk" FOREIGN KEY ("installation_id") REFERENCES "public"."guard_installations"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_face_appearances" ADD CONSTRAINT "guard_face_appearances_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_face_appearances" ADD CONSTRAINT "guard_face_appearances_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_hazard_events" ADD CONSTRAINT "guard_hazard_events_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_hazard_events" ADD CONSTRAINT "guard_hazard_events_acknowledged_by_users_id_fk" FOREIGN KEY ("acknowledged_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_hazard_events" ADD CONSTRAINT "guard_hazard_events_resolved_by_users_id_fk" FOREIGN KEY ("resolved_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_installation_room_assignments" ADD CONSTRAINT "guard_installation_room_assignments_installation_id_guard_installations_id_fk" FOREIGN KEY ("installation_id") REFERENCES "public"."guard_installations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_installation_room_assignments" ADD CONSTRAINT "guard_installation_room_assignments_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_installations" ADD CONSTRAINT "guard_installations_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_room_activation_codes" ADD CONSTRAINT "guard_room_activation_codes_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_room_activation_codes" ADD CONSTRAINT "guard_room_activation_codes_used_by_installation_id_guard_installations_id_fk" FOREIGN KEY ("used_by_installation_id") REFERENCES "public"."guard_installations"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_room_activation_codes" ADD CONSTRAINT "guard_room_activation_codes_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_room_occupancy" ADD CONSTRAINT "guard_room_occupancy_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_room_presence" ADD CONSTRAINT "guard_room_presence_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "guard_room_presence" ADD CONSTRAINT "guard_room_presence_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "in_out_event_images" ADD CONSTRAINT "in_out_event_images_event_id_guard_face_appearances_id_fk" FOREIGN KEY ("event_id") REFERENCES "public"."guard_face_appearances"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "room_orders" ADD CONSTRAINT "room_orders_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "room_orders" ADD CONSTRAINT "room_orders_room_id_guard_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."guard_rooms"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "users_face_registry_id_unique" ON "users" USING btree ("face_registry_id");--> statement-breakpoint
CREATE UNIQUE INDEX "guard_cameras_installation_room_client_camera_unique" ON "guard_cameras" USING btree ("installation_id","room_id","client_camera_id");--> statement-breakpoint
CREATE INDEX "guard_cameras_installation_id_idx" ON "guard_cameras" USING btree ("installation_id");--> statement-breakpoint
CREATE INDEX "guard_face_appearances_camera_id_idx" ON "guard_face_appearances" USING btree ("camera_id");--> statement-breakpoint
CREATE INDEX "guard_face_appearances_room_id_idx" ON "guard_face_appearances" USING btree ("room_id");--> statement-breakpoint
CREATE INDEX "guard_hazard_events_camera_id_idx" ON "guard_hazard_events" USING btree ("camera_id");--> statement-breakpoint
CREATE INDEX "guard_hazard_events_room_id_idx" ON "guard_hazard_events" USING btree ("room_id");--> statement-breakpoint
CREATE INDEX "guard_installation_room_assignments_installation_idx" ON "guard_installation_room_assignments" USING btree ("installation_id");--> statement-breakpoint
CREATE INDEX "guard_installation_room_assignments_room_idx" ON "guard_installation_room_assignments" USING btree ("room_id");--> statement-breakpoint
CREATE UNIQUE INDEX "guard_installation_room_assignments_active_unique" ON "guard_installation_room_assignments" USING btree ("installation_id") WHERE "guard_installation_room_assignments"."disconnected_at" is null;--> statement-breakpoint
CREATE UNIQUE INDEX "guard_installations_hardware_id_hash_unique" ON "guard_installations" USING btree ("hardware_id_hash");--> statement-breakpoint
CREATE INDEX "guard_installations_room_id_idx" ON "guard_installations" USING btree ("room_id");--> statement-breakpoint
CREATE UNIQUE INDEX "guard_room_activation_codes_code_hash_unique" ON "guard_room_activation_codes" USING btree ("code_hash");--> statement-breakpoint
CREATE INDEX "guard_room_activation_codes_room_id_idx" ON "guard_room_activation_codes" USING btree ("room_id");
--> statement-breakpoint
INSERT INTO "guard_rooms" ("id", "name", "max_members", "sort_order", "created_at", "updated_at")
VALUES ('default-room', 'Default Room', 50, 0, now(), now());
--> statement-breakpoint
INSERT INTO "guard_room_occupancy" ("room_id", "current_count", "updated_at")
VALUES ('default-room', 0, now());