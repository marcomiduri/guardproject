DROP INDEX IF EXISTS "guard_installations_client_installation_unique";
--> statement-breakpoint
ALTER TABLE "guard_installations" DROP COLUMN IF EXISTS "client_installation_id";
