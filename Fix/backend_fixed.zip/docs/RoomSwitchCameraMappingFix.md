# Room switch camera mapping fix

## Problem

A Guard installation can disconnect from one room and connect to another while keeping the same local cameras. Backend camera IDs are room-specific, but an already-open Room Connection dialog could still submit the previous room's backend camera IDs. The backend interpreted those IDs as a request to reuse/move the historical camera records and returned `Camera belongs to another room`.

## Backend behavior

Room connection and camera upsert now use the tuple:

- installation ID;
- selected room ID;
- stable `clientCameraId`.

A supplied camera ID that belongs to another room of the same installation is treated as a stale mapping. The old camera row remains attached to its original room for event-history integrity, while the backend creates or finds the camera mapping in the selected room.

A camera ID owned by another Guard installation remains rejected.

## Compatibility

No schema or migration is required. Existing camera and event history remains unchanged.
