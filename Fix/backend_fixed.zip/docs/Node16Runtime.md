# Node.js 16 runtime update

This backend has been adjusted to run under Node.js 16.20.x instead of Node.js 24.

## Required runtime

```text
Node.js 16.20.2
npm 8.x or newer
```

Use `nvm use` from the backend directory, or install Node.js 16.20.2 manually on Windows.

## Main changes

- Added `.nvmrc` with `16.20.2`.
- Added `engines.node = ">=16.20.2 <17"`.
- Replaced Node 20/24-only `--env-file` script usage.
- Replaced Node 20+ `--import tsx` usage with the Node 16-compatible `--loader tsx` path.
- Added a local `.env` parser in `scripts/env.mjs`.
- Added `scripts/start.mjs` so production startup can load `.env` under Node 16.
- Added `scripts/run-ts-script.mjs` for seed/import scripts under Node 16.
- Replaced the global `fetch()` use in `scripts/verify-guard-staging.mjs` with `node:http`/`node:https`, because global fetch is not available in Node 16.
- Downgraded dev-tooling packages that required Node 18/20/22/24.

## Install after this change

The old lockfiles were removed because they pinned packages whose engines required newer Node versions.

```bash
npm install
npm run dev
```

For production:

```bash
npm run build
npm run start
```

## Notes

The backend TypeScript/Express application itself did not depend on Node 24 features. The main incompatibilities were package engines and script flags.
