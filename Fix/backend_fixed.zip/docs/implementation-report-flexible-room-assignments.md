# Implementation Report — Flexible Guard Room Assignments

Date: 2026-07-02

## Scope

- One backend Guard installation now represents one Guard PC.
- Room assignments are recorded separately with connected/disconnected timestamps.
- A deliberate disconnect closes the active assignment but preserves the installation and device credential.
- An existing installation may connect to any available room by proving possession of its `installationId` and device credential.
- The same installation ID is retained across room moves.
- Camera uniqueness is room-specific, so the same local `clientCameraId` receives a different backend camera ID in another room while old camera/event history remains intact.
- Old room JWTs stop working because access middleware validates the installation's active status and current room on every request.

## Database

Migration `0008_flexible_room_assignments.sql` adds assignment history and updates installation/camera uniqueness indexes.

## Verification

- `npm run check`: passed.
- `npm test`: 76 tests passed; 4 PostgreSQL-dependent integration tests skipped because no configured migrated integration database was available.
- `npm run lint`: passed.
- `npm run build`: passed.
