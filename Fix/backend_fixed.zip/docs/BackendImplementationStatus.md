# Backend Implementation Status

## Implemented

- Transactional room registration.
- Hashed installation hardware identity.
- Hashed, revocable and rotating device credentials.
- Short-lived installation JWTs containing room and scope authorization only.
- Installation revocation and heartbeat handling.
- Canonical backend camera IDs, direction, synchronization and heartbeats.
- Face registry, face events, hazard events, notification settings and realtime delivery.
- Event idempotency and image handling.
- Legacy admin room activation-code APIs remain available but are not required by the temporary open Guard registration flow.

## Commercial licensing boundary

Commercial licensing has been removed from this backend. The backend no longer
contains product-license validation, product-trial calculation, license conversion,
commercial entitlement database fields, commercial JWT claims or a product-license
activation endpoint.

The native Guard application is responsible for validating its local license before
it registers with a room.

## Migration

`drizzle/0004_remove_commercial_licensing.sql` removes obsolete commercial fields
from `guard_installations` while preserving installation IDs, rooms, credentials,
cameras, revocation state and event history.
