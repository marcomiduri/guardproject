# Guard Backend Tasks — Revised Licensing Boundary

Commercial Guard licensing is outside the JavaScript backend. The native Guard
application and its license-generator certificate chain own product-license
validation and product-trial/perpetual behavior.

## Backend responsibilities

1. Store Guard installation identity using a normalized hardware-ID hash.
2. Create, list, consume and revoke temporary room activation codes.
3. Register or restore one installation transactionally.
4. Issue and rotate hashed device credentials.
5. Issue short-lived JWTs with installation, room and scope claims.
6. Enforce installation revocation, room ownership and camera ownership.
7. Synchronize up to four cameras with canonical backend IDs and required direction.
8. Process installation and camera heartbeats.
9. Serve face registry and effective notification settings.
10. Store recognized, unknown and hazard events idempotently.
11. Broadcast operational events to authorized admin and staff clients.

## Explicit non-responsibilities

The backend does not generate, validate, store or display commercial product
licenses. It does not manage a product trial, convert a trial to a permanent license,
or include commercial entitlement in JWTs or API responses.

## Required verification

- Database migrations preserve installation, room, camera, credential and event data.
- Activation remains transactional and idempotent.
- Device credentials remain hashed and revocable.
- JWT scopes and installation revocation remain enforced.
- Activation-code administration remains admin-only.
- Camera and event ownership checks remain unchanged.
- Unit, API, integration, type, lint and production-build checks pass.
