# Room connection and face-registry synchronization implementation

## Room connection

Implemented contracts:

- `GET /api/guard/available-rooms`
- `POST /api/guard/installations/connect`
- `POST /api/guard/auth/token`
- `POST /api/guard/installations/disconnect`
- compatibility alias: `DELETE /api/guard/installations/current`

The connect request contains `roomId`, device information, optional `installationId` + `deviceCredential` for reconnect, and optional camera data. Hardware identifiers, activation codes, license keys, and `clientInstallationId` are not part of this contract.

Normal disconnect keeps the credential valid and marks the installation `disconnected`. A later token exchange using the same installation ID and credential returns a new short-lived JWT and sets the installation back to `active`. Administrative revocation is unchanged and blocks token exchange.

## Face registry

The backend remains authoritative for the face registry:

- `GET /api/guard/faces/version` returns lightweight version metadata.
- `GET /api/guard/faces` returns the matching full registry and its version.
- successful face registration, registered-face display-name changes, and deletion of a registered user recompute the registry version;
- successful changes broadcast `face_registry.updated` to authenticated Guard WebSocket clients;
- realtime messages include only `version`, `scope`, and `updatedAt`—never embeddings;
- missed realtime messages are harmless because Guard also polls the version endpoint.

The current registry scope is explicitly `global`, matching the pre-existing backend behavior. Room-authorized registry partitioning requires a separate room-membership policy and can be added later without changing the invalidation protocol.

Registry versions include the model, timestamp, IDs, display names, and feature values in the digest, so an embedding replacement invalidates clients even if external data repair preserves timestamps.

## Failure behavior

- Failed feature extraction or persistence does not broadcast an update.
- If realtime delivery fails, version polling still discovers the change.
- Backend credentials, JWTs, activation codes, and embeddings are not included in registry notifications or logs.

## Verification performed

- `npm run check`: passed.
- `npm test -- --reporter=dot`: 74 passed, 4 skipped. The skipped tests require a configured PostgreSQL integration database.
- `npm run lint`: passed.
- `npm run build`: passed.
