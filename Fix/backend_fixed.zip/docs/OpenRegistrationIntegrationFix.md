# Temporary Open Registration Integration Fix

## Purpose

This transitional build removes the old commercial-license and room-code checks from the initial Guard registration request so the complete local-network integration can be tested before the replacement licensing and enrollment model is introduced.

## Root cause of `Unauthorized`

The registration request still crossed two obsolete bootstrap checks:

- `POST /api/guard/installations/activate` required `X-Guard-Api-Key`;
- the activation service required and consumed a room activation code.

Guard no longer had a legitimate commercial license or frontend-managed room code to satisfy those checks, so registration stopped before a device credential and JWT could be issued.

## Current transitional flow

1. Guard sends an existing room ID/name, Hardware ID, device name, version, and cameras.
2. The backend creates or restores the installation and returns a random opaque device credential.
3. Guard stores the credential using protected local storage.
4. Guard exchanges the credential for a short-lived installation JWT.
5. Camera, face, hazard, heartbeat, registry, and settings requests continue to require that JWT and retain installation/room/camera ownership checks.

## Security boundary

Only the initial registration endpoint is temporarily open. Operational Guard APIs are still protected by device credentials, JWTs, scopes, ownership, and revocation checks.

This flow is for integration testing and must be replaced by the approved licensing/enrollment design before production deployment.

## Verification

- TypeScript check passed.
- 62 backend tests passed.
- ESLint/Prettier check passed.
- Production TypeScript build passed.
