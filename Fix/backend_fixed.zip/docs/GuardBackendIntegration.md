# Guard Backend Integration

## Responsibility boundary

The backend manages installation registration and operational security. Commercial
Guard licensing is validated and enforced locally by the native Guard application.
The backend and web frontend do not generate or validate product licenses, manage
product trials, or expose commercial entitlement state.

For the current integration-test build, initial room registration is intentionally open.
No product license, room activation code or shared bootstrap API key is required.

## Installation flow

1. Guard selects an existing backend room and provides its normalized Hardware ID,
   device name, application version and optional camera list.
2. Guard calls `POST /api/guard/installations/activate`.
3. The backend creates or restores the installation transactionally, maps cameras and
   generates a new opaque device credential.
4. Guard stores the device credential in protected local storage.
5. Guard exchanges the device credential at `POST /api/guard/auth/token` for a
   short-lived JWT.
6. Guard uses the JWT for camera, registry, heartbeat, settings and event APIs.

This open bootstrap exists only so the full integration can be tested before the new
licensing/enrollment model is implemented.

## Core endpoints

| Method                | Path                                      | Authentication          | Purpose                                             |
| --------------------- | ----------------------------------------- | ----------------------- | --------------------------------------------------- |
| POST                  | `/api/guard/installations/activate`       | none (temporary)        | Register or restore an installation                 |
| POST                  | `/api/guard/auth/token`                   | device credential       | Rotate credential and issue a short-lived JWT       |
| GET                   | `/api/guard/installations/current`        | Guard JWT               | Read current installation, room and camera mappings |
| DELETE                | `/api/guard/installations/current`        | Guard JWT               | Revoke/unregister the installation                  |
| POST                  | `/api/guard/installations/heartbeat`      | Guard JWT               | Update installation last-seen state                 |
| GET/POST/PATCH/DELETE | `/api/guard/cameras`                      | Guard JWT               | Synchronize installation-owned cameras              |
| POST                  | `/api/guard/cameras/{cameraId}/heartbeat` | Guard JWT               | Update camera status                                |
| GET                   | `/api/guard/faces`                        | Guard JWT               | Download the face registry                          |
| GET                   | `/api/guard/faces/version`                | Guard JWT               | Check the registry version                          |
| GET                   | `/api/guard/notification-settings`        | Guard JWT               | Read effective local-warning settings               |
| POST                  | `/api/guard/events/appeared`              | Guard JWT               | Upload a recognized face event                      |
| POST                  | `/api/guard/events/unknown-appeared`      | Guard JWT               | Upload an unknown face event                        |
| POST                  | `/api/guard/events/hazard-detected`       | Guard JWT               | Upload a hazard event                               |

There is no backend product-license activation endpoint.

## Activation request

```json
{
	"roomIdentifier": "Warehouse",
	"hardwareId": "9567-A0AA-88FF-473C",
	"deviceName": "Warehouse Guard PC",
	"guardVersion": "2.0.0",
	"cameras": [
		{
			"clientCameraId": "local-camera-1",
			"name": "Front Entrance",
			"direction": "in",
			"deviceAddress": "192.168.1.50"
		}
	]
}
```

## Session response

Activation and token exchange return installation/session data without commercial
entitlement fields:

```json
{
	"installationId": "installation-uuid",
	"guardInstanceId": "installation-uuid",
	"deviceName": "Warehouse Guard PC",
	"room": {
		"id": "room-uuid",
		"name": "Warehouse"
	},
	"deviceCredential": "one-time-or-rotated-opaque-secret",
	"accessToken": "short-lived-jwt",
	"expiresIn": 900,
	"expiresAt": "2026-07-01T12:15:00Z",
	"serverTime": "2026-07-01T12:00:00Z",
	"cameras": [
		{
			"clientCameraId": "local-camera-1",
			"backendCameraId": "camera-uuid",
			"cameraId": "camera-uuid",
			"id": "camera-uuid"
		}
	]
}
```

Compatibility aliases currently remain for `deviceToken`, `guardInstanceId`,
`cameraId` and `id`; new clients should prefer `deviceCredential`, `installationId`
and `backendCameraId`.

## JWT contract

Guard JWTs contain installation identity, room identity and scopes only. They do not
contain product-license, product-trial or commercial entitlement claims.

```json
{
	"sub": "installation-uuid",
	"roomId": "room-uuid",
	"scope": [
		"rooms:read",
		"cameras:read",
		"cameras:write",
		"cameras:heartbeat",
		"events:write",
		"faces:read",
		"settings:read",
		"installation:manage"
	]
}
```

## Security rules

- Activation codes and device credentials are stored only as hashes.
- Raw hardware IDs are not stored or logged.
- JWTs and device credentials must never be logged.
- Revoked installations cannot obtain or use sessions.
- Camera ownership and room ownership are enforced on every Guard API.
- Backend failure must not stop Guard local camera monitoring.
