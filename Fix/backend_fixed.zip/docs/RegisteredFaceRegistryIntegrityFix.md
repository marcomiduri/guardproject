# Registered face registry integrity fix

The Guard face-registry endpoint continues to return the existing numeric contract:

- `id`
- `name`
- `feature`

The registry now includes only entries that:

- use the configured face model;
- have a positive registry ID;
- have a non-empty trimmed display name;
- contain only finite feature values;
- use the same feature-vector dimension as the other returned entries.

The registry version is now content-sensitive. A display-name change updates the version, causing connected Guard applications to download the new name instead of retaining an old cached registry.

Automated tests cover name preservation, model filtering, vector validation, and name-sensitive registry versioning.
