# Flexible Guard room assignments

A Guard installation identifies one Guard PC and is no longer permanently bound to one room.

- A normal room disconnect closes the active room-assignment record, marks the installation `disconnected`, leaves the long-lived device credential valid, and invalidates the short-lived room JWT.
- A disconnected installation can select any available room and reconnect by proving `installationId + deviceCredential`.
- Connecting to a different room updates the installation's current room, creates a new assignment-history record, and creates or restores room-specific backend camera mappings.
- Existing face events, hazard events, camera records, and prior assignment history are never moved to the new room.
- Administrative revocation remains separate and invalidates future authentication.
- The token endpoint does not reactivate a deliberately disconnected installation; the room-connect endpoint must be used so a room is selected explicitly.
