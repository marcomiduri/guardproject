# Room Connection Reconnect Fix

## Final behavior

A normal Guard room disconnect is a reversible operational state, not a security revocation.

- The installation becomes `disconnected`.
- The existing long-lived device credential hash is retained.
- The current short-lived JWT stops working because protected routes require an `active` installation.
- Guard later reconnects by exchanging the same protected device credential for a new JWT.
- The token exchange reactivates the same installation ID.
- Existing room, camera, face-event, hazard-event, and audit records remain attached.
- No administrator recovery is required.

Administrative revocation remains separate:

- The installation becomes `revoked`.
- Token exchange is rejected with `INSTALLATION_REVOKED`.
- Historical records are preserved.

## Room connection identity

The public room-connection contract uses `roomId` for first connect, and `installationId` + `deviceCredential` for reconnect. It does not accept or store a Hardware ID, Hardware ID hash, or `clientInstallationId` for room connection. Hardware-bound local licensing remains a separate feature.

A disconnected installation cannot be reactivated through the public connect endpoint. It must prove possession of the saved device credential through `POST /api/guard/auth/token`.

## Database

Migration `0000_init.sql` defines the current Guard schema (nullable `hardware_id_hash` for room-connected installations; no `client_installation_id`).
