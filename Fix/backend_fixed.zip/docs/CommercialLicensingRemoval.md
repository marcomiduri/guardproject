# Commercial Licensing Removal Report

## Summary

Commercial product licensing was removed from the backend without changing room
registration, device authentication, camera ownership or operational event flow.

## Removed

- `GuardAppLicense-v1` TypeScript implementation and tests.
- Product-license activation route, validator and service method.
- Trial/license entitlement calculation and responses.
- Commercial entitlement JWT claim and middleware gate.
- Trial/license database columns and check constraint.
- Trial/offline-grace environment settings used only by commercial entitlement.

## Preserved

- Temporary room activation codes.
- Hardware-ID hashing for installation identity.
- Device credentials and credential rotation.
- Short-lived JWTs, scopes and revocation.
- Installation/camera heartbeats.
- Cameras, registry, settings, face events, hazard events and realtime flow.

## Migration

`0004_remove_commercial_licensing.sql` drops only obsolete commercial fields. It does
not recreate or delete installation, room, camera, credential or event records.

## Cleanup and verification

The cleanup also consolidated repeated safety-event query joins, removed obsolete
license helpers, kept installation-hardware normalization in a dedicated identity
module, and formatted the touched source consistently.

Verified on the source package:

- `npm run check` — passed;
- `npm test` — 11 test files and 60 tests passed;
- `npm run lint` — passed;
- `npm run build` — passed.

The SQL migration was reviewed and packaged, but it was not applied to a live
PostgreSQL database in this environment. It must be executed through the normal
migration process against a backup/staging database before production rollout.
