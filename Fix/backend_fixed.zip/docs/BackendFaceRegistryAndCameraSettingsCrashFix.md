# Guard / GuardVision / Backend Crash Investigation and Fix

## Reported symptoms

- Guard is stable in `--test` mode.
- In normal mode with the backend connected, Guard could terminate during face identification after loading backend face-registry data.
- Guard could also terminate when camera detection settings were saved.
- The same camera workflows were stable without the backend.

## Root causes identified

### 1. Camera-settings changes unnecessarily rebuilt the native Identify session
`CameraRuntimeController::applyConfigsToRegisteredStream()` always called `setMotionConfig`, `setFaceConfig`, and `setHazardConfig` whenever any detection setting changed. In GuardVision, `FaceScheduler::updateStreamConfig()` always destroyed the native InspireFace Identify session before applying a face config.

The existing project already documents that native Identify-session teardown is an unstable vendor path. With a backend registry loaded, FeatureHub and Identify are active together, making unnecessary session destruction particularly risky.

### 2. Live face-registry replacement entered a process-global FeatureHub teardown path
`IdentifyEngine::setFaceRegistry()` replaces registry contents by disabling and re-enabling InspireFace FeatureHub. Doing this while live camera Identify sessions are active can conflict with native session state even when application-level calls are serialized.

### 3. Registry validation was not strict enough at all boundaries
The backend already filtered non-finite vectors and mixed dimensions, but duplicate registry IDs and an invalid configured threshold were not independently normalized. Guard and GuardVision also accepted registry structures that could still be unsafe for a native SDK (duplicate IDs, inconsistent dimensions at the library boundary, empty display names, or unreasonably large feature vectors).

## Fixes

### Guard
- Added per-analytic config comparisons. A camera-settings save calls GuardVision only for the analytic config that actually changed.
- A face config is no longer re-applied just because a motion, hazard, recording, or unrelated camera setting changed.
- A changed backend registry is kept pending while any GuardVision camera stream is active. It is applied after all active streams are quiesced, preventing live FeatureHub replacement.
- Registry JSON parsing now rejects duplicate IDs and oversized/inconsistent feature vectors and normalizes invalid thresholds.

### GuardVision
- `FaceScheduler::updateStreamConfig()` now reuses the existing native Identify session for non-structural settings such as ROI, confidence, interval, quality, and detection thresholds.
- Native Identify-session recreation is restricted to structural changes that actually require it (processing-level or maximum-face-count changes).
- `isValidFaceRegistry()` now validates unique positive IDs, non-empty display names, consistent feature dimensions, finite values, and a defensive feature-size limit.

### Backend
- Registry construction now independently filters duplicate face-registry IDs.
- Invalid/non-finite/out-of-range `FACE_RECOGNITION_THRESHOLD` values are normalized to `0.48` before they are exposed to Guard.
- Existing model, finite-vector, and consistent-dimension filtering remains intact.

## Verification performed

- Guard source regression checks passed for face-registry startup lifecycle, camera-settings connection lock, normal camera frame pipeline, and cached registry reconnect behavior.
- GuardVision configured and built successfully with proprietary face/hazard SDK features disabled, which verifies the portable library build and the modified source integration.
- `guardvision_tests` passed in that reduced-feature build.
- Full InspireFace/HazardDetect runtime compilation was not possible in this environment because the uploaded projects do not contain those proprietary SDKs. The final Windows build should therefore still be exercised with the production SDK DLLs/model packs.

## Recommended Windows runtime regression test

1. Start backend with at least two registered faces.
2. Launch Guard in normal mode and connect all configured cameras.
3. Confirm known/unknown face identification runs for several minutes.
4. Open Camera Settings repeatedly and change ROI, confidence, motion, hazard, and recording settings while streams are active.
5. Add/update/delete a registered backend face while cameras are active. Guard should keep the old registry active and the new version pending rather than terminating.
6. Disconnect all cameras and allow the registry refresh to run; reconnect and verify the new registry is used.
7. Repeat room reconnect and camera reconnect scenarios.
8. Run the same test with multiple simultaneous cameras.

## Files changed

- Guard: `src/runtime/camera/CameraRuntimeController.cpp`
- Guard: `src/app/MainWindow.cpp`
- Guard: `src/services/api/FaceRegistryLoader.cpp`
- GuardVision: `src/face/FaceScheduler.cpp`
- GuardVision: `src/face/FaceRegistry.cpp`
- backend: `src/services/guard-faces.ts`
