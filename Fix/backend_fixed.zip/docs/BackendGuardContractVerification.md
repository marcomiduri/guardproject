# Backend–Guard Contract Verification

## Current contract

| Area              | Verified backend behavior                                                                    |
| ----------------- | -------------------------------------------------------------------------------------------- |
| Room registration | Temporary open bootstrap, normalized/hashed hardware identity, transactional create/restore |
| Device session    | Hashed long-lived credential, rotation, short-lived JWT                                      |
| Authorization     | Installation ID, room ID, scopes and revocation                                              |
| Cameras           | Backend IDs are canonical; client IDs support idempotent mapping                             |
| Heartbeats        | Installation and camera last-seen/status updates                                             |
| Registry/settings | Face registry version/data and effective notification settings                               |
| Events            | Face and hazard uploads, ownership checks and idempotency                                    |
| Realtime          | Operational face/hazard/settings updates                                                     |

## Removed contract

The following are intentionally absent:

- backend-managed product trial;
- commercial entitlement response object;
- commercial entitlement JWT claim;
- backend product-license validation;
- `POST /api/guard/installations/license`;
- product-license fields in installation administration responses.

## Required Guard behavior

Guard sends no product license or room activation code in this transitional build.
After registration, backend authentication remains mandatory and uses the protected
device credential plus short-lived Guard JWTs. Installation, room and camera ownership
checks remain unchanged.
