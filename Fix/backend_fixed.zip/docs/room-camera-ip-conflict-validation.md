# Room Camera IP Conflict Validation

Camera IP addresses must be unique within a room.

Validation is applied to:

- camera creation;
- camera updates, excluding the camera being edited;
- Guard room-connect camera payloads;
- installation activation camera payloads.

Addresses are trimmed and compared case-insensitively. A conflict returns a validation error and does not modify camera records.

Room switching preserves historical camera records and event references. Camera mappings are scoped by room, while the Guard installation can disconnect from one room and connect to another before the selected room camera list is restored.
