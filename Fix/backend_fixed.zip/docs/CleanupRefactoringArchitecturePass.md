# Cleanup / Refactoring / Architecture Pass

## Scope

This pass keeps the completed Guard backend behavior unchanged while tightening the implementation around maintainability, runtime diagnostics, and generated artifact hygiene.

## Backend changes

- Added `src/utils/logger.ts` as a small centralized logger.
- Replaced runtime `console.*` calls in server bootstrap, API error handling, realtime websocket handling, notification-setting broadcasts, face-event image handling, hazard snapshot handling, registry invalidation, and pending-order broadcast paths.
- Added `LOG_LEVEL` support with `debug`, `info`, `warn`, `error`, and `silent` levels.
- Preserved all route paths, request/response payloads, database writes, event broadcasts, authorization checks, and service calls.

## Behavior preserved

- HTTP API contracts are unchanged.
- Guard device authentication and realtime websocket authentication are unchanged.
- Face, unknown-entry, hazard, notification-setting, and room-order flows are unchanged.
- Existing idempotency and backend-authoritative data behavior remain unchanged.

## Operational note

Default logging remains `info`, matching the previous visible startup/runtime output. Set `LOG_LEVEL=warn`, `LOG_LEVEL=error`, or `LOG_LEVEL=silent` to reduce production console output without editing source code.

## Verification

Source-level verification was performed in this environment. Full `npm run check`, `npm run lint`, `npm run test`, and database-backed integration tests should be run on the project machine with dependencies and the configured database available.
