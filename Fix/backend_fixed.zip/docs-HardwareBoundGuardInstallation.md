# Hardware-bound Guard installation identity

This update simplifies Guard room connection identity.

## Rule

For backend room connection, the canonical installation identity is now resolved by the physical Guard machine hardware ID:

```text
same normalized hardwareId + same backend database
= same guard_installations.id
```

The backend stores only `hardware_id_hash`, not the raw hardware ID.

## Connect flow

Guard sends `hardwareId` in `/api/guard/installations/connect` and `/api/guard/auth/token`.

On room connect the backend:

1. hashes `hardwareId`,
2. looks up an existing installation by current or legacy hardware hash,
3. if found, reuses that same `installationId`,
4. if the local Guard credential was lost after rebuild/reinstall, issues a fresh device credential,
5. updates room/camera mappings against the canonical installation ID.

## Legacy recovery

Earlier builds could create installations without `hardware_id_hash`. If a hardware-bound Guard reconnects to a room whose cameras still belong to one of those legacy installation rows, the backend can reclaim those camera rows and bind them to the hardware-bound installation. This prevents:

```text
400 BAD_REQUEST: Camera belongs to another Guard installation
```

when the same PC reconnects after rebuilding or reinstalling Guard.
