import { describe, expect, it } from 'vitest';
import { detectFaceImageFormat } from '@/utils/face-image-buffer.js';

describe('detectFaceImageFormat', () => {
	it('detects JPEG', () => {
		expect(detectFaceImageFormat(Buffer.from([0xff, 0xd8, 0xff, 0xe0]))).toBe('jpeg');
	});

	it('detects PNG', () => {
		expect(
			detectFaceImageFormat(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
		).toBe('png');
	});

	it('detects WebP', () => {
		expect(detectFaceImageFormat(Buffer.from('RIFFxxxxWEBP', 'ascii'))).toBe('webp');
	});

	it('returns null for unknown bytes', () => {
		expect(detectFaceImageFormat(Buffer.from([0x00, 0x01]))).toBeNull();
	});
});
