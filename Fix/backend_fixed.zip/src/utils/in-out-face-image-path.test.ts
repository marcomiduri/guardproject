import { describe, expect, it } from 'vitest';
import { toSafePathSegment } from '@/utils/safe-path-segment.js';
import { inOutFaceImagesService } from '@/services/in-out-face-images.js';

describe('toSafePathSegment', () => {
	it('sanitizes unsafe characters', () => {
		expect(toSafePathSegment('camera/../001')).toBe('camera_001');
	});

	it('falls back when empty', () => {
		expect(toSafePathSegment('   ')).toBe('unknown');
	});
});

describe('inOutFaceImagesService.buildRelativeStoragePath', () => {
	it('builds date and camera based relative paths', () => {
		const facePath = inOutFaceImagesService.buildRelativeStoragePath(
			'event-123',
			'camera-001',
			new Date('2026-06-18T10:15:00Z'),
			'face_crop'
		);
		const framePath = inOutFaceImagesService.buildRelativeStoragePath(
			'event-123',
			'camera-001',
			new Date('2026-06-18T10:15:00Z'),
			'event_frame'
		);

		expect(facePath).toBe('in-out-faces/2026/06/18/camera-001/event-123_face.jpg');
		expect(framePath).toBe('in-out-faces/2026/06/18/camera-001/event-123_frame.jpg');
	});
});
