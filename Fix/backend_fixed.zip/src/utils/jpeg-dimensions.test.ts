import { describe, expect, it } from 'vitest';
import { readJpegDimensions } from '@/utils/jpeg-dimensions.js';

describe('readJpegDimensions', () => {
	it('reads width and height from a minimal JPEG SOF segment', () => {
		const buffer = Buffer.from([
			0xff, 0xd8, 0xff, 0xc0, 0x00, 0x11, 0x08, 0x00, 0x64, 0x00, 0x80, 0x03, 0x01, 0x11, 0x00,
			0x02, 0x11, 0x01, 0x03, 0x11, 0x01, 0xff, 0xd9
		]);

		expect(readJpegDimensions(buffer)).toEqual({ width: 128, height: 100 });
	});
});
