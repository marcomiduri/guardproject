import { unlink, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export type FaceImageFormat = 'jpeg' | 'png' | 'webp';

export function detectFaceImageFormat(buffer: Buffer): FaceImageFormat | null {
	if (buffer.length >= 2 && buffer[0] === 0xff && buffer[1] === 0xd8) {
		return 'jpeg';
	}

	if (
		buffer.length >= 8 &&
		buffer[0] === 0x89 &&
		buffer[1] === 0x50 &&
		buffer[2] === 0x4e &&
		buffer[3] === 0x47
	) {
		return 'png';
	}

	if (
		buffer.length >= 12 &&
		buffer[0] === 0x52 &&
		buffer[1] === 0x49 &&
		buffer[2] === 0x46 &&
		buffer[3] === 0x46 &&
		buffer[8] === 0x57 &&
		buffer[9] === 0x45 &&
		buffer[10] === 0x42 &&
		buffer[11] === 0x50
	) {
		return 'webp';
	}

	return null;
}

function extractionExtension(format: FaceImageFormat): string {
	return format === 'jpeg' ? 'jpg' : format;
}

/**
 * Profile photos are stored as `{userId}.jpg`. When the bytes are PNG/WebP, write a
 * sidecar file with the matching extension so Qt's face extractor can load the image.
 */
export async function writeFaceImageForExtraction(
	facesDir: string,
	userId: string,
	imageBuffer: Buffer
): Promise<{ storagePath: string; extractionPath: string }> {
	const format = detectFaceImageFormat(imageBuffer);
	if (!format) {
		throw new Error('Image must be JPEG, PNG, or WebP');
	}

	const storagePath = join(facesDir, `${userId}.jpg`);
	await writeFile(storagePath, imageBuffer);

	if (format === 'jpeg') {
		return { storagePath, extractionPath: storagePath };
	}

	const extractionPath = join(facesDir, `${userId}.extract.${extractionExtension(format)}`);
	await writeFile(extractionPath, imageBuffer);

	return { storagePath, extractionPath };
}

export async function removeFaceExtractionSidecar(
	extractionPath: string,
	storagePath: string
): Promise<void> {
	if (extractionPath === storagePath) {
		return;
	}

	try {
		await unlink(extractionPath);
	} catch {
		// Ignore missing sidecar files.
	}
}
