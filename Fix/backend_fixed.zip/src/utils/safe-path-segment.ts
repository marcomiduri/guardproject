/** Safe single path segment for camera IDs and similar identifiers. */
export function toSafePathSegment(value: string, fallback = 'unknown'): string {
	const trimmed = value.trim();
	if (!trimmed) {
		return fallback;
	}

	const sanitized = trimmed
		.replace(/[\\/]+/g, '_')
		.replace(/\.\.+/g, '_')
		.replace(/[^a-zA-Z0-9._-]+/g, '_')
		.replace(/_+/g, '_')
		.replace(/^\.+/, '');

	return sanitized.length > 0 ? sanitized.slice(0, 120) : fallback;
}
