const LOG_LEVELS = ['debug', 'info', 'warn', 'error', 'silent'] as const;

type LogLevel = (typeof LOG_LEVELS)[number];

const LOG_LEVEL_PRIORITY: Record<LogLevel, number> = {
	debug: 10,
	info: 20,
	warn: 30,
	error: 40,
	silent: 50
};

function resolveLogLevel(value: string | undefined): LogLevel {
	const normalized = value?.trim().toLowerCase();
	return LOG_LEVELS.includes(normalized as LogLevel) ? (normalized as LogLevel) : 'info';
}

const currentLogLevel = resolveLogLevel(process.env.LOG_LEVEL);

function shouldLog(level: Exclude<LogLevel, 'silent'>): boolean {
	return LOG_LEVEL_PRIORITY[level] >= LOG_LEVEL_PRIORITY[currentLogLevel];
}

export const logger = {
	debug(message: string, ...args: unknown[]): void {
		if (shouldLog('debug')) console.debug(message, ...args);
	},
	info(message: string, ...args: unknown[]): void {
		if (shouldLog('info')) console.info(message, ...args);
	},
	warn(message: string, ...args: unknown[]): void {
		if (shouldLog('warn')) console.warn(message, ...args);
	},
	error(message: string, ...args: unknown[]): void {
		if (shouldLog('error')) console.error(message, ...args);
	}
};
