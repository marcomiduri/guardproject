/** Read width/height from JPEG SOF markers without decoding the full image. */
export function readJpegDimensions(buffer: Buffer): { width: number; height: number } | null {
	if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8) {
		return null;
	}

	let offset = 2;
	while (offset + 4 < buffer.length) {
		if (buffer[offset] !== 0xff) {
			offset += 1;
			continue;
		}

		const marker = buffer[offset + 1];
		if (marker === 0xd9 || marker === 0xda) {
			break;
		}

		const segmentLength = buffer.readUInt16BE(offset + 2);
		if (segmentLength < 2 || offset + 2 + segmentLength > buffer.length) {
			break;
		}

		const isStartOfFrame =
			marker === 0xc0 ||
			marker === 0xc1 ||
			marker === 0xc2 ||
			marker === 0xc3 ||
			marker === 0xc5 ||
			marker === 0xc6 ||
			marker === 0xc7 ||
			marker === 0xc9 ||
			marker === 0xca ||
			marker === 0xcb ||
			marker === 0xcd ||
			marker === 0xce ||
			marker === 0xcf;

		if (isStartOfFrame && segmentLength >= 7) {
			const height = buffer.readUInt16BE(offset + 5);
			const width = buffer.readUInt16BE(offset + 7);
			if (width > 0 && height > 0) {
				return { width, height };
			}
			return null;
		}

		offset += 2 + segmentLength;
	}

	return null;
}
