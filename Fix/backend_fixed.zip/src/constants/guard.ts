/** Keep in sync with Web frontend `HAZARD_LAMP_HOLD_MS` in roomHazardStore. */
export const ACTIVE_HAZARD_WINDOW_MS = 5 * 60 * 1000;

/** Default cooldown between duplicate safety events for the same camera + hazard type. */
export const DEFAULT_SAFETY_EVENT_COOLDOWN_MS = 60 * 1000;
