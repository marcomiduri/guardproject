import pg from 'pg';

import { env } from '@/config/env.js';

const PLACEHOLDER_PASSWORDS = new Set(['change-me', 'changeme', 'your_password', 'your-password']);

function formatSetupHelp(): string {
	return [
		'Edit backend\\.env and set DATABASE_URL to your PostgreSQL connection string.',
		'Create the database if needed, then run:',
		'  cd backend',
		'  npm run db:migrate',
		'',
		'Example:',
		'  DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/image'
	].join('\n');
}

export function assertDatabaseUrlConfigured(): void {
	let parsed: URL;
	try {
		parsed = new URL(env.DATABASE_URL);
	} catch {
		throw new Error(`DATABASE_URL is not a valid URL.\n\n${formatSetupHelp()}`);
	}

	if (parsed.protocol !== 'postgresql:' && parsed.protocol !== 'postgres:') {
		throw new Error(
			`DATABASE_URL must use the postgresql:// scheme (current value starts with ${parsed.protocol}).\n\n${formatSetupHelp()}`
		);
	}

	const password = decodeURIComponent(parsed.password);
	if (!password || PLACEHOLDER_PASSWORDS.has(password.toLowerCase())) {
		throw new Error(
			`DATABASE_URL still uses a placeholder PostgreSQL password.\n\n${formatSetupHelp()}`
		);
	}
}

export async function verifyDatabaseConnection(): Promise<void> {
	assertDatabaseUrlConfigured();

	const pool = new pg.Pool({
		connectionString: env.DATABASE_URL,
		max: 1,
		connectionTimeoutMillis: 10_000
	});

	try {
		await pool.query('select 1');
	} catch (err) {
		const detail = err instanceof Error ? err.message : String(err);
		throw new Error(`PostgreSQL connection failed: ${detail}\n\n${formatSetupHelp()}`);
	} finally {
		await pool.end();
	}
}
