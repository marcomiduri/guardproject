import { date, integer, jsonb, pgTable, text, timestamp, uniqueIndex } from 'drizzle-orm/pg-core';

export const USER_ROLES = ['user', 'admin', 'staff'] as const;
export type UserRole = (typeof USER_ROLES)[number];

export function assertUserRole(value: string): UserRole {
	if (!USER_ROLES.includes(value as UserRole)) {
		throw new Error(`role must be one of: ${USER_ROLES.join(', ')}`);
	}
	return value as UserRole;
}

export const users = pgTable(
	'users',
	{
		id: text('id').primaryKey(),
		username: text('username').notNull(),
		email: text('email').notNull().unique(),
		passwordHash: text('password_hash').notNull(),
		role: text('role').notNull().default('user'),
		faceRegistryId: integer('face_registry_id'),
		faceRegisteredAt: timestamp('face_registered_at'),
		faceEmbedding: jsonb('face_embedding').$type<number[]>(),
		faceModel: text('face_model'),
		birthday: date('birthday'),
		job: text('job'),
		position: text('position'),
		createdAt: timestamp('created_at').defaultNow().notNull(),
		updatedAt: timestamp('updated_at')
			.defaultNow()
			.$onUpdate(() => new Date())
			.notNull()
	},
	(table) => [uniqueIndex('users_face_registry_id_unique').on(table.faceRegistryId)]
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
