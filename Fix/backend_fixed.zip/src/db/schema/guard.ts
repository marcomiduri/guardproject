import { sql } from 'drizzle-orm';
import {
	boolean,
	check,
	index,
	integer,
	jsonb,
	pgTable,
	primaryKey,
	real,
	text,
	timestamp,
	uniqueIndex
} from 'drizzle-orm/pg-core';
import { users } from '@/db/schema/auth.js';

export const GUARD_CAMERA_TYPES = ['hikvision', 'generic_rtsp'] as const;
export type GuardCameraType = (typeof GUARD_CAMERA_TYPES)[number];

export const GUARD_CAMERA_DIRECTIONS = ['in', 'out'] as const;
export type GuardCameraDirection = (typeof GUARD_CAMERA_DIRECTIONS)[number];

export const GUARD_CAMERA_STATUSES = ['online', 'offline', 'unknown'] as const;
export type GuardCameraStatus = (typeof GUARD_CAMERA_STATUSES)[number];

export const GUARD_HAZARD_TYPES = ['fire', 'smoke', 'flame', 'unknown'] as const;
export type GuardHazardType = (typeof GUARD_HAZARD_TYPES)[number];

export const GUARD_SAFETY_EVENT_STATUSES = [
	'NEW',
	'ACKNOWLEDGED',
	'RESOLVED',
	'FALSE_ALARM'
] as const;
export type GuardSafetyEventStatus = (typeof GUARD_SAFETY_EVENT_STATUSES)[number];

export const GUARD_SAFETY_EVENT_SOURCES = ['GUARD', 'GUARD2', 'TEST_MODE'] as const;
export type GuardSafetyEventSource = (typeof GUARD_SAFETY_EVENT_SOURCES)[number];

export const GUARD_RECOGNITION_STATUSES = [
	'IDENTIFIED',
	'UNIDENTIFIED',
	'LOW_CONFIDENCE',
	'ERROR'
] as const;
export type GuardRecognitionStatus = (typeof GUARD_RECOGNITION_STATUSES)[number];

export const GUARD_INSTALLATION_STATUSES = ['active', 'disconnected', 'revoked'] as const;
export type GuardInstallationStatus = (typeof GUARD_INSTALLATION_STATUSES)[number];

export type GuardDetectionRectangle = {
	x: number;
	y: number;
	width: number;
	height: number;
	coordinateSpace?: string;
};

export type GuardHazardDetection = {
	type: string;
	confidence?: number;
	rectangle?: GuardDetectionRectangle;
};

export const guardRooms = pgTable('guard_rooms', {
	id: text('id').primaryKey(),
	name: text('name').notNull(),
	maxMembers: integer('max_members').notNull().default(1),
	sortOrder: integer('sort_order').notNull().default(0),
	createdAt: timestamp('created_at').defaultNow().notNull(),
	updatedAt: timestamp('updated_at').defaultNow().notNull()
});

export const guardInstallations = pgTable(
	'guard_installations',
	{
		id: text('id').primaryKey(),
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id, { onDelete: 'restrict' }),
		hardwareIdHash: text('hardware_id_hash'),
		deviceName: text('device_name').notNull().default('Guard'),
		status: text('status').notNull().default('active'),
		applicationVersion: text('application_version'),
		deviceTokenHash: text('device_token_hash').notNull(),
		previousDeviceTokenHash: text('previous_device_token_hash'),
		deviceTokenIssuedAt: timestamp('device_token_issued_at').defaultNow().notNull(),
		deviceTokenRotatedAt: timestamp('device_token_rotated_at'),
		registeredAt: timestamp('registered_at').defaultNow().notNull(),
		lastSeenAt: timestamp('last_seen_at').defaultNow().notNull(),
		revokedAt: timestamp('revoked_at'),
		createdAt: timestamp('created_at').defaultNow().notNull(),
		updatedAt: timestamp('updated_at').defaultNow().notNull()
	},
	(table) => [
		uniqueIndex('guard_installations_hardware_id_hash_unique').on(table.hardwareIdHash),
		index('guard_installations_room_id_idx').on(table.roomId),
		check(
			'guard_installations_status_check',
			sql`${table.status} in ('active', 'disconnected', 'revoked')`
		)
	]
);

export const guardInstallationRoomAssignments = pgTable(
	'guard_installation_room_assignments',
	{
		id: text('id').primaryKey(),
		installationId: text('installation_id')
			.notNull()
			.references(() => guardInstallations.id, { onDelete: 'cascade' }),
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id, { onDelete: 'restrict' }),
		connectedAt: timestamp('connected_at').defaultNow().notNull(),
		disconnectedAt: timestamp('disconnected_at'),
		createdAt: timestamp('created_at').defaultNow().notNull()
	},
	(table) => [
		index('guard_installation_room_assignments_installation_idx').on(table.installationId),
		index('guard_installation_room_assignments_room_idx').on(table.roomId),
		uniqueIndex('guard_installation_room_assignments_active_unique')
			.on(table.installationId)
			.where(sql`${table.disconnectedAt} is null`)
	]
);

export const guardRoomActivationCodes = pgTable(
	'guard_room_activation_codes',
	{
		id: text('id').primaryKey(),
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id, { onDelete: 'cascade' }),
		codeHash: text('code_hash').notNull(),
		expiresAt: timestamp('expires_at').notNull(),
		maxUses: integer('max_uses').notNull().default(1),
		usedCount: integer('used_count').notNull().default(0),
		usedAt: timestamp('used_at'),
		usedByInstallationId: text('used_by_installation_id').references(() => guardInstallations.id, {
			onDelete: 'set null'
		}),
		createdBy: text('created_by').references(() => users.id, { onDelete: 'set null' }),
		createdAt: timestamp('created_at').defaultNow().notNull(),
		revokedAt: timestamp('revoked_at')
	},
	(table) => [
		uniqueIndex('guard_room_activation_codes_code_hash_unique').on(table.codeHash),
		index('guard_room_activation_codes_room_id_idx').on(table.roomId),
		check('guard_room_activation_codes_max_uses_check', sql`${table.maxUses} > 0`),
		check('guard_room_activation_codes_used_count_check', sql`${table.usedCount} >= 0`)
	]
);

export const guardCameras = pgTable(
	'guard_cameras',
	{
		id: text('id').primaryKey(),
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id, { onDelete: 'cascade' }),
		installationId: text('installation_id').references(() => guardInstallations.id, {
			onDelete: 'set null'
		}),
		clientCameraId: text('client_camera_id'),
		name: text('name').notNull().default(''),
		type: text('type').notNull().default('hikvision'),
		direction: text('direction').notNull().default('in'),
		deviceAddress: text('device_address').notNull(),
		sdkPort: integer('sdk_port').notNull().default(8000),
		rtspPort: integer('rtsp_port').notNull().default(554),
		rtspUrl: text('rtsp_url'),
		username: text('username').notNull().default('admin'),
		password: text('password').notNull().default(''),
		channel: integer('channel').notNull().default(1),
		streamType: integer('stream_type').notNull().default(0),
		status: text('status').notNull().default('unknown'),
		lastSeenAt: timestamp('last_seen_at'),
		sortOrder: integer('sort_order').notNull().default(0),
		createdAt: timestamp('created_at').defaultNow().notNull(),
		updatedAt: timestamp('updated_at').defaultNow().notNull()
	},
	(table) => [
		uniqueIndex('guard_cameras_installation_room_client_camera_unique').on(
			table.installationId,
			table.roomId,
			table.clientCameraId
		),
		index('guard_cameras_installation_id_idx').on(table.installationId),
		check('guard_cameras_direction_check', sql`${table.direction} in ('in', 'out')`),
		check('guard_cameras_status_check', sql`${table.status} in ('online', 'offline', 'unknown')`)
	]
);

export const guardFaceAppearances = pgTable(
	'guard_face_appearances',
	{
		id: text('id').primaryKey(),
		faceRegistryId: integer('face_registry_id'),
		userId: text('user_id').references(() => users.id),
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id),
		cameraId: text('camera_id').notNull(),
		cameraName: text('camera_name'),
		cameraAddress: text('camera_address'),
		direction: text('direction').notNull(),
		eventType: text('event_type').notNull(),
		recognitionStatus: text('recognition_status').notNull().default('IDENTIFIED'),
		similarity: real('similarity'),
		approved: boolean('approved'),
		trackId: integer('track_id'),
		source: text('source').notNull().default('GUARD'),
		supersedesEventId: text('supersedes_event_id'),
		rectangle: jsonb('rectangle').$type<GuardDetectionRectangle>(),
		hasFaceImage: boolean('has_face_image').notNull().default(false),
		occurredAt: timestamp('occurred_at').defaultNow().notNull()
	},
	(table) => [
		index('guard_face_appearances_camera_id_idx').on(table.cameraId),
		index('guard_face_appearances_room_id_idx').on(table.roomId),
		check('guard_face_appearances_direction_check', sql`${table.direction} in ('in', 'out')`)
	]
);

export const IN_OUT_EVENT_IMAGE_TYPES = ['face_crop', 'event_frame'] as const;
export type InOutEventImageType = (typeof IN_OUT_EVENT_IMAGE_TYPES)[number];

export const inOutEventImages = pgTable('in_out_event_images', {
	id: text('id').primaryKey(),
	eventId: text('event_id')
		.notNull()
		.references(() => guardFaceAppearances.id, { onDelete: 'cascade' }),
	imageType: text('image_type').notNull(),
	storagePath: text('storage_path').notNull(),
	mimeType: text('mime_type').notNull(),
	width: integer('width').notNull(),
	height: integer('height').notNull(),
	sizeBytes: integer('size_bytes').notNull(),
	createdAt: timestamp('created_at').defaultNow().notNull()
});

export const guardHazardEvents = pgTable(
	'guard_hazard_events',
	{
		id: text('id').primaryKey(),
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id, { onDelete: 'cascade' }),
		cameraId: text('camera_id').notNull(),
		hazardType: text('hazard_type').notNull(),
		confidence: real('confidence'),
		detections: jsonb('detections').$type<GuardHazardDetection[]>(),
		status: text('status').notNull().default('NEW'),
		source: text('source').notNull().default('GUARD'),
		testScenario: text('test_scenario'),
		hasSnapshotImage: boolean('has_snapshot_image').notNull().default(false),
		snapshotPath: text('snapshot_path'),
		snapshotWidth: integer('snapshot_width'),
		snapshotHeight: integer('snapshot_height'),
		snapshotSizeBytes: integer('snapshot_size_bytes'),
		occurredAt: timestamp('occurred_at').defaultNow().notNull(),
		createdAt: timestamp('created_at').defaultNow().notNull(),
		acknowledgedAt: timestamp('acknowledged_at'),
		acknowledgedBy: text('acknowledged_by').references(() => users.id),
		resolvedAt: timestamp('resolved_at'),
		resolvedBy: text('resolved_by').references(() => users.id)
	},
	(table) => [
		index('guard_hazard_events_camera_id_idx').on(table.cameraId),
		index('guard_hazard_events_room_id_idx').on(table.roomId)
	]
);

export const guardRoomOccupancy = pgTable('guard_room_occupancy', {
	roomId: text('room_id')
		.primaryKey()
		.references(() => guardRooms.id, { onDelete: 'cascade' }),
	currentCount: integer('current_count').notNull().default(0),
	updatedAt: timestamp('updated_at').defaultNow().notNull()
});

export const guardRoomPresence = pgTable(
	'guard_room_presence',
	{
		roomId: text('room_id')
			.notNull()
			.references(() => guardRooms.id, { onDelete: 'cascade' }),
		userId: text('user_id')
			.notNull()
			.references(() => users.id, { onDelete: 'cascade' }),
		enteredAt: timestamp('entered_at').defaultNow().notNull()
	},
	(table) => [primaryKey({ columns: [table.roomId, table.userId] })]
);

export const ROOM_ORDER_STATUSES = [
	'pending',
	'approved',
	'cancelled',
	'rejected',
	'expired'
] as const;
export type RoomOrderStatus = (typeof ROOM_ORDER_STATUSES)[number];

export const roomOrders = pgTable('room_orders', {
	id: text('id').primaryKey(),
	userId: text('user_id')
		.notNull()
		.references(() => users.id, { onDelete: 'cascade' }),
	roomId: text('room_id')
		.notNull()
		.references(() => guardRooms.id),
	startTime: timestamp('start_time').notNull(),
	endTime: timestamp('end_time').notNull(),
	status: text('status').notNull().default('pending'),
	createdAt: timestamp('created_at').defaultNow().notNull(),
	updatedAt: timestamp('updated_at').defaultNow().notNull()
});

export type GuardRoom = typeof guardRooms.$inferSelect;
export type NewGuardRoom = typeof guardRooms.$inferInsert;
export type GuardInstallation = typeof guardInstallations.$inferSelect;
export type NewGuardInstallation = typeof guardInstallations.$inferInsert;
export type GuardInstallationRoomAssignment = typeof guardInstallationRoomAssignments.$inferSelect;
export type NewGuardInstallationRoomAssignment =
	typeof guardInstallationRoomAssignments.$inferInsert;
export type GuardRoomActivationCode = typeof guardRoomActivationCodes.$inferSelect;
export type NewGuardRoomActivationCode = typeof guardRoomActivationCodes.$inferInsert;
export type GuardCamera = typeof guardCameras.$inferSelect;
export type NewGuardCamera = typeof guardCameras.$inferInsert;
export type GuardFaceAppearance = typeof guardFaceAppearances.$inferSelect;
export type NewGuardFaceAppearance = typeof guardFaceAppearances.$inferInsert;
export type InOutEventImage = typeof inOutEventImages.$inferSelect;
export type NewInOutEventImage = typeof inOutEventImages.$inferInsert;
export type GuardHazardEvent = typeof guardHazardEvents.$inferSelect;
export type NewGuardHazardEvent = typeof guardHazardEvents.$inferInsert;
export type RoomOrder = typeof roomOrders.$inferSelect;
export type NewRoomOrder = typeof roomOrders.$inferInsert;
