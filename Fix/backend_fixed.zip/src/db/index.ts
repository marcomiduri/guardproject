import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import { env } from '@/config/env.js';
import * as schema from '@/db/schema/index.js';

const pool = new pg.Pool({
	connectionString: env.DATABASE_URL,
	allowExitOnIdle: true
});

export const db = drizzle(pool, { schema });

export async function closeDb(): Promise<void> {
	await pool.end();
}
