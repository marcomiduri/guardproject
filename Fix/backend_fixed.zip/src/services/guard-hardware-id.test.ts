import { describe, expect, it } from 'vitest';
import { guardHardwareIdFormatValid, normalizeGuardHardwareId } from './guard-hardware-id.js';

describe('Guard installation hardware ID normalization', () => {
	it('normalizes equivalent formatted identifiers consistently', () => {
		expect(normalizeGuardHardwareId('9567-A0AA-88FF-473C')).toBe('9567A0AA88FF473C');
		expect(normalizeGuardHardwareId('9567 a0aa 88ff 473c')).toBe('9567A0AA88FF473C');
	});

	it('accepts only a normalized 16-digit hexadecimal identifier', () => {
		expect(guardHardwareIdFormatValid('9567A0AA88FF473C')).toBe(true);
		expect(guardHardwareIdFormatValid('9567A0AA')).toBe(false);
	});
});
