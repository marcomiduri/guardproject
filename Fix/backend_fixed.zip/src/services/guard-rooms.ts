import { randomUUID } from 'node:crypto';
import { and, asc, count, eq, ilike, or, sql, type SQL } from 'drizzle-orm';
import { db } from '@/db/index.js';
import {
	guardCameras,
	guardFaceAppearances,
	guardInstallationRoomAssignments,
	guardInstallations,
	guardRoomOccupancy,
	guardRoomPresence,
	guardRooms,
	roomOrders
} from '@/db/schema/guard.js';
import { inOutFaceImagesService } from '@/services/in-out-face-images.js';
import { buildPagination, type PaginatedListData } from '@/http/responses.js';
import { collectColumnFilterConditions } from '@/lib/db/column-filters.js';
import {
	numberColumnFilter,
	textColumnFilter,
	timestampColumnFilter
} from '@/lib/db/filter-sql.js';
import { clampListPagination } from '@/lib/db/pagination.js';
import type {
	GuardRoomsColumnFilter,
	GuardRoomsListSortField,
	ListGuardRoomsOptions
} from '@/types/guard-rooms-list.js';
import type { UpdateInput } from '@/types/input.js';
import { badRequest, notFound } from '@/services/errors.js';

export type GuardRoomRecord = {
	id: string;
	name: string;
	maxMembers: number;
	sortOrder: number;
	currentCount: number;
	cameraCount: number;
	createdAt: Date;
	updatedAt: Date;
};

export type PaginatedGuardRoomsList = PaginatedListData<GuardRoomRecord>;

export type CreateGuardRoomInput = {
	id?: string;
	name: string;
	maxMembers: number;
	sortOrder?: number;
};

export type UpdateGuardRoomInput = UpdateInput<CreateGuardRoomInput>;

function mapRoom(
	row: typeof guardRooms.$inferSelect,
	currentCount: number,
	cameraCount: number
): GuardRoomRecord {
	return {
		id: row.id,
		name: row.name,
		maxMembers: row.maxMembers,
		sortOrder: row.sortOrder,
		currentCount,
		cameraCount,
		createdAt: row.createdAt,
		updatedAt: row.updatedAt
	};
}

async function getOccupancyCount(roomId: string): Promise<number> {
	const [row] = await db
		.select({ currentCount: guardRoomOccupancy.currentCount })
		.from(guardRoomOccupancy)
		.where(eq(guardRoomOccupancy.roomId, roomId))
		.limit(1);
	return row?.currentCount ?? 0;
}

async function getCameraCount(roomId: string): Promise<number> {
	const [row] = await db
		.select({ total: count() })
		.from(guardCameras)
		.where(eq(guardCameras.roomId, roomId));
	return Number(row?.total ?? 0);
}

const currentCountExpr = sql<number>`coalesce(${guardRoomOccupancy.currentCount}, 0)`;
const cameraCountExpr = sql<number>`(
	select count(*)::int
	from ${guardCameras}
	where ${guardCameras.roomId} = ${guardRooms.id}
)`;

function buildColumnFilterCondition(filter: GuardRoomsColumnFilter): SQL | undefined {
	const { column, comparator, value } = filter;

	switch (column) {
		case 'name':
			return textColumnFilter(guardRooms.name, comparator, value);
		case 'currentCount':
			return numberColumnFilter(currentCountExpr, comparator, value);
		case 'cameraCount':
			return numberColumnFilter(cameraCountExpr, comparator, value);
		case 'maxMembers':
			return numberColumnFilter(sql`${guardRooms.maxMembers}`, comparator, value);
		case 'sortOrder':
			return numberColumnFilter(sql`${guardRooms.sortOrder}`, comparator, value);
		case 'createdAt':
			return timestampColumnFilter(
				sql`${guardRooms.createdAt}::text`,
				guardRooms.createdAt,
				comparator,
				value
			);
	}

	return undefined;
}

function buildSearchCondition(search: string | undefined): SQL | undefined {
	const trimmed = search?.trim();
	if (!trimmed) return undefined;

	const term = `%${trimmed}%`;
	return or(
		ilike(guardRooms.name, term),
		ilike(guardRooms.id, term),
		ilike(sql`${guardRooms.maxMembers}::text`, term),
		ilike(sql`${currentCountExpr}::text`, term),
		ilike(sql`${cameraCountExpr}::text`, term)
	);
}

function buildWhereClause(options: ListGuardRoomsOptions): SQL | undefined {
	const conditions: SQL[] = [];

	const searchCondition = buildSearchCondition(options.search);
	if (searchCondition) conditions.push(searchCondition);

	for (const columnCondition of collectColumnFilterConditions(
		options.columnFilters,
		buildColumnFilterCondition
	)) {
		conditions.push(columnCondition);
	}

	return conditions.length ? and(...conditions) : undefined;
}

function mapListRow(row: {
	id: string;
	name: string;
	maxMembers: number;
	sortOrder: number;
	currentCount: number;
	cameraCount: number;
	createdAt: Date;
	updatedAt: Date;
}): GuardRoomRecord {
	return {
		id: row.id,
		name: row.name,
		maxMembers: row.maxMembers,
		sortOrder: row.sortOrder,
		currentCount: Number(row.currentCount ?? 0),
		cameraCount: Number(row.cameraCount ?? 0),
		createdAt: row.createdAt,
		updatedAt: row.updatedAt
	};
}

async function ensureOccupancyRow(roomId: string): Promise<void> {
	const [existing] = await db
		.select({ roomId: guardRoomOccupancy.roomId })
		.from(guardRoomOccupancy)
		.where(eq(guardRoomOccupancy.roomId, roomId))
		.limit(1);
	if (existing) return;

	await db.insert(guardRoomOccupancy).values({
		roomId,
		currentCount: 0,
		updatedAt: new Date()
	});
}

export const guardRoomsService = {
	async listPaginated(options: ListGuardRoomsOptions = {}): Promise<PaginatedGuardRoomsList> {
		const { limit, offset } = clampListPagination(options);
		const sortOrder = options.sortOrder ?? 'asc';
		const whereClause = buildWhereClause(options);

		const baseFrom = db
			.select({
				id: guardRooms.id,
				name: guardRooms.name,
				maxMembers: guardRooms.maxMembers,
				sortOrder: guardRooms.sortOrder,
				currentCount: currentCountExpr.as('current_count'),
				cameraCount: cameraCountExpr.as('camera_count'),
				createdAt: guardRooms.createdAt,
				updatedAt: guardRooms.updatedAt
			})
			.from(guardRooms)
			.leftJoin(guardRoomOccupancy, eq(guardRooms.id, guardRoomOccupancy.roomId));

		const countQuery = db
			.select({ count: sql<number>`count(*)` })
			.from(guardRooms)
			.leftJoin(guardRoomOccupancy, eq(guardRooms.id, guardRoomOccupancy.roomId));

		const countResult = whereClause ? await countQuery.where(whereClause) : await countQuery;
		const total = Number(countResult[0]?.count ?? 0);

		const sortColumnMap: Record<GuardRoomsListSortField, SQL> = {
			name: sql`${guardRooms.name}`,
			currentCount: sql`${currentCountExpr}`,
			cameraCount: sql`${cameraCountExpr}`,
			maxMembers: sql`${guardRooms.maxMembers}`,
			sortOrder: sql`${guardRooms.sortOrder}`,
			createdAt: sql`${guardRooms.createdAt}`
		};

		const sortCol = options.sortBy ? sortColumnMap[options.sortBy] : sortColumnMap.sortOrder;
		const sortDirection = sortOrder === 'asc' ? sql`ASC` : sql`DESC`;

		const itemsQuery = baseFrom
			.orderBy(sql`${sortCol} ${sortDirection} NULLS LAST`, asc(guardRooms.id))
			.limit(limit)
			.offset(offset);

		const rows = whereClause ? await itemsQuery.where(whereClause) : await itemsQuery;

		return {
			items: rows.map(mapListRow),
			pagination: buildPagination({
				total,
				limit,
				offset,
				itemCount: rows.length
			})
		};
	},

	async list(): Promise<GuardRoomRecord[]> {
		const rows = await db
			.select()
			.from(guardRooms)
			.orderBy(asc(guardRooms.sortOrder), asc(guardRooms.createdAt));

		const results: GuardRoomRecord[] = [];
		for (const row of rows) {
			results.push(mapRoom(row, await getOccupancyCount(row.id), await getCameraCount(row.id)));
		}
		return results;
	},

	async listSummaries(): Promise<
		Pick<GuardRoomRecord, 'id' | 'name' | 'maxMembers' | 'sortOrder' | 'currentCount'>[]
	> {
		const rooms = await this.list();
		return rooms.map(({ id, name, maxMembers, sortOrder, currentCount }) => ({
			id,
			name,
			maxMembers,
			sortOrder,
			currentCount
		}));
	},

	async getById(id: string): Promise<GuardRoomRecord> {
		const [row] = await db.select().from(guardRooms).where(eq(guardRooms.id, id)).limit(1);
		if (!row) {
			throw notFound('Room not found');
		}
		return mapRoom(row, await getOccupancyCount(row.id), await getCameraCount(row.id));
	},

	async create(input: CreateGuardRoomInput): Promise<GuardRoomRecord> {
		const name = input.name.trim();
		if (!name) {
			throw badRequest('name is required');
		}
		if (!Number.isInteger(input.maxMembers) || input.maxMembers < 1) {
			throw badRequest('maxMembers must be a positive integer');
		}

		const [totalRow] = await db.select({ total: count() }).from(guardRooms);
		const sortOrder = input.sortOrder ?? Number(totalRow?.total ?? 0);
		const now = new Date();
		const id = input.id?.trim() || randomUUID();

		const [row] = await db
			.insert(guardRooms)
			.values({
				id,
				name,
				maxMembers: input.maxMembers,
				sortOrder,
				createdAt: now,
				updatedAt: now
			})
			.returning();

		await ensureOccupancyRow(row.id);
		return mapRoom(row, 0, 0);
	},

	async update(id: string, input: UpdateGuardRoomInput): Promise<GuardRoomRecord> {
		await this.getById(id);

		const patch: Partial<typeof guardRooms.$inferInsert> = {
			updatedAt: new Date()
		};

		if (input.name !== undefined) {
			const name = input.name.trim();
			if (!name) throw badRequest('name is required');
			patch.name = name;
		}
		if (input.maxMembers !== undefined) {
			if (!Number.isInteger(input.maxMembers) || input.maxMembers < 1) {
				throw badRequest('maxMembers must be a positive integer');
			}
			patch.maxMembers = input.maxMembers;
		}
		if (input.sortOrder !== undefined) patch.sortOrder = input.sortOrder;

		const [row] = await db.update(guardRooms).set(patch).where(eq(guardRooms.id, id)).returning();

		return mapRoom(row, await getOccupancyCount(row.id), await getCameraCount(row.id));
	},

	async remove(id: string): Promise<void> {
		await this.getById(id);

		const appearanceRows = await db
			.select({ id: guardFaceAppearances.id })
			.from(guardFaceAppearances)
			.where(eq(guardFaceAppearances.roomId, id));

		for (const row of appearanceRows) {
			await inOutFaceImagesService.deleteStoredImagesForEvent(row.id);
		}

		await db.transaction(async (tx) => {
			await tx
				.delete(guardInstallationRoomAssignments)
				.where(eq(guardInstallationRoomAssignments.roomId, id));
			await tx.delete(guardInstallations).where(eq(guardInstallations.roomId, id));
			await tx.delete(guardFaceAppearances).where(eq(guardFaceAppearances.roomId, id));
			await tx.delete(roomOrders).where(eq(roomOrders.roomId, id));

			const result = await tx
				.delete(guardRooms)
				.where(eq(guardRooms.id, id))
				.returning({ id: guardRooms.id });

			if (result.length === 0) {
				throw notFound('Room not found');
			}
		});
	},

	async listPresence(roomId: string) {
		await this.getById(roomId);
		return db
			.select({
				userId: guardRoomPresence.userId,
				enteredAt: guardRoomPresence.enteredAt
			})
			.from(guardRoomPresence)
			.where(eq(guardRoomPresence.roomId, roomId))
			.orderBy(asc(guardRoomPresence.enteredAt));
	}
};
