import type { WebSocket } from 'ws';
import { describe, expect, it, vi } from 'vitest';
import { guardRealtimeHub } from '@/services/guard-realtime-hub.js';

describe('Guard realtime registry invalidation', () => {
	it('broadcasts only lightweight registry metadata without embeddings', () => {
		const send = vi.fn();
		const socket = {
			OPEN: 1,
			readyState: 1,
			send
		} as unknown as WebSocket;

		guardRealtimeHub.addClient({
			ws: socket,
			installationId: 'installation-1',
			roomId: 'room-1'
		});
		try {
			const sent = guardRealtimeHub.publishFaceRegistryUpdated({
				version: 'v2:abc',
				scope: 'global',
				updatedAt: '2026-07-01T12:00:00.000Z'
			});
			expect(sent).toBe(1);
			expect(send).toHaveBeenCalledOnce();
			const payload = JSON.parse(String(send.mock.calls[0]?.[0]));
			expect(payload).toEqual({
				type: 'face_registry.updated',
				version: 'v2:abc',
				scope: 'global',
				updatedAt: '2026-07-01T12:00:00.000Z'
			});
			expect(JSON.stringify(payload)).not.toMatch(/embedding|feature/i);
		} finally {
			guardRealtimeHub.removeClient(socket);
		}
	});
	it('keeps only one client entry when the same socket is registered again', () => {
		const send = vi.fn();
		const socket = {
			OPEN: 1,
			readyState: 1,
			send
		} as unknown as WebSocket;

		guardRealtimeHub.addClient({
			ws: socket,
			installationId: 'installation-old',
			roomId: 'room-old'
		});
		guardRealtimeHub.addClient({
			ws: socket,
			installationId: 'installation-new',
			roomId: 'room-new'
		});

		try {
			const sent = guardRealtimeHub.publishFaceRegistryUpdated({
				version: 'v3:def',
				scope: 'global',
				updatedAt: '2026-07-02T12:00:00.000Z'
			});

			expect(sent).toBe(1);
			expect(send).toHaveBeenCalledOnce();
		} finally {
			guardRealtimeHub.removeClient(socket);
		}
	});
});
