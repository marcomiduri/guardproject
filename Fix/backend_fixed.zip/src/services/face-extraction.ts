﻿import { spawn } from 'node:child_process';
import { existsSync, statSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { env } from '@/config/env.js';

export type ExtractedFaceFeature = {
	model: string;
	dimension: number;
	feature: number[];
};

type ExtractorResult =
	| { ok: true; model: string; dimension: number; feature: number[] }
	| { ok: false; error: string };

/** Walk up from this module and collect layout roots (packaged, Web install, monorepo). */
function collectSearchRoots(): string[] {
	const moduleDir = dirname(fileURLToPath(import.meta.url));
	const roots: string[] = [];
	let dir = moduleDir;

	for (let i = 0; i < 10; i++) {
		roots.push(dir);
		const parent = dirname(dir);
		if (parent === dir) {
			break;
		}
		dir = parent;
	}

	return roots;
}

function resolveDefaultExtractorBin(): string {
	const relativeBins = [
		// Packaged Electron: resources/face-extractor/...
		'face-extractor/extract_face_feature.exe',
		'face-extractor/extract_face_feature',
		// MC POS Web / repo Web root: electron/face-extractor-runtime/...
		'electron/face-extractor-runtime/extract_face_feature.exe',
		'electron/face-extractor-runtime/extract_face_feature',
		// Monorepo root
		'Web/electron/face-extractor-runtime/extract_face_feature.exe',
		'Web/electron/face-extractor-runtime/extract_face_feature',
		'Guard/tools/extract-face-feature/release/extract_face_feature.exe',
		'Guard/tools/extract-face-feature/release/extract_face_feature',
		'Guard/bin/extract_face_feature.exe',
		'Guard/bin/extract_face_feature'
	];

	const candidates: string[] = [];
	for (const root of collectSearchRoots()) {
		for (const relative of relativeBins) {
			candidates.push(resolve(root, relative));
		}
	}

	for (const candidate of candidates) {
		if (existsSync(candidate)) {
			return candidate;
		}
	}

	return (
		candidates[0] ??
		resolve(
			collectSearchRoots()[0] ?? process.cwd(),
			'face-extractor/extract_face_feature.exe'
		)
	);
}

function modelPackExists(candidate: string): boolean {
	if (!existsSync(candidate)) {
		return false;
	}

	const stat = statSync(candidate);
	return stat.isFile() || stat.isDirectory();
}

function resolveDefaultModelPath(): string {
	const relativeModels = [
		'face-extractor/models/Pikachu',
		'electron/face-extractor-runtime/models/Pikachu',
		'Web/electron/face-extractor-runtime/models/Pikachu',
		'Guard/sdk/Identify/models/Pikachu',
		'Guard/tools/extract-face-feature/release/models/Pikachu',
		'Guard/bin/models/Pikachu',
		'Guard/bin/Pikachu'
	];

	const candidates: string[] = [];
	for (const root of collectSearchRoots()) {
		for (const relative of relativeModels) {
			candidates.push(resolve(root, relative));
		}
	}

	for (const candidate of candidates) {
		if (modelPackExists(candidate)) {
			return candidate;
		}
	}

	return (
		candidates[0] ??
		resolve(collectSearchRoots()[0] ?? process.cwd(), 'face-extractor/models/Pikachu')
	);
}

function isMissingDllExitCode(code: number | null): boolean {
	if (code === null) {
		return false;
	}

	// Windows STATUS_DLL_NOT_FOUND (0xC0000135)
	return code === 3221225781 || code === -1073741515;
}

function parseExtractorOutput(raw: string): ExtractorResult | null {
	const trimmed = raw.trim();
	if (!trimmed) {
		return null;
	}

	const jsonCandidates = trimmed
		.split(/\r?\n/)
		.map((line) => line.trim())
		.filter((line) => line.startsWith('{') && line.endsWith('}'));

	for (let i = jsonCandidates.length - 1; i >= 0; i--) {
		try {
			return JSON.parse(jsonCandidates[i]) as ExtractorResult;
		} catch {
			continue;
		}
	}

	try {
		return JSON.parse(trimmed) as ExtractorResult;
	} catch {
		return null;
	}
}

function extractorFailureMessage(code: number | null, stderr: string, output: string): string {
	const parsed = parseExtractorOutput(output);
	if (parsed && !parsed.ok && parsed.error) {
		return parsed.error;
	}

	if (isMissingDllExitCode(code)) {
		return (
			'Face extractor failed to start (missing Qt or InspireFace DLLs beside extract_face_feature.exe). ' +
			'Rebuild Guard tools with Guard/scripts/build-tools.ps1 or run the full Guard release build.'
		);
	}

	return stderr.trim() || output.trim() || `Face extractor exited with code ${code ?? 'unknown'}`;
}

function validateFeaturePayload(payload: ExtractorResult): ExtractedFaceFeature {
	if (!payload.ok) {
		throw new Error(payload.error || 'Face feature extraction failed');
	}

	if (!Array.isArray(payload.feature) || payload.feature.length === 0) {
		throw new Error('Extractor returned an empty feature vector');
	}

	if (typeof payload.dimension === 'number' && payload.dimension !== payload.feature.length) {
		throw new Error('Extractor returned a feature vector with an unexpected dimension');
	}

	for (const value of payload.feature) {
		if (typeof value !== 'number' || !Number.isFinite(value)) {
			throw new Error('Extractor returned an invalid feature vector');
		}
	}

	return {
		model: payload.model,
		dimension: payload.feature.length,
		feature: payload.feature
	};
}

export async function extractFaceFeatureFromImage(
	imagePath: string
): Promise<ExtractedFaceFeature> {
	const extractorBin = env.FACE_EXTRACTOR_BIN.trim() || resolveDefaultExtractorBin();
	const modelPath = env.IDENTIFY_MODEL_PATH.trim() || resolveDefaultModelPath();
	const absoluteImagePath = resolve(imagePath);
	const absoluteModelPath = resolve(modelPath);

	if (!existsSync(extractorBin)) {
		throw new Error(
			`Face extractor not found at ${extractorBin}. ` +
				`Set FACE_EXTRACTOR_BIN, or ensure extract_face_feature.exe is under ` +
				`resources/face-extractor (desktop install) or electron/face-extractor-runtime (Web source).`
		);
	}

	if (!existsSync(absoluteImagePath)) {
		throw new Error(`Face image not found at ${absoluteImagePath}`);
	}

	if (!modelPackExists(absoluteModelPath)) {
		throw new Error(
			`InspireFace model not found at ${absoluteModelPath}. Set IDENTIFY_MODEL_PATH or place the Pikachu model pack at Guard/sdk/Identify/models/Pikachu.`
		);
	}

	const extractorDir = dirname(extractorBin);
	const pathEntries = [extractorDir, process.env.PATH ?? ''].filter(Boolean);

	const stdout = await new Promise<string>((resolvePromise, rejectPromise) => {
		const child = spawn(
			extractorBin,
			['--model', absoluteModelPath, '--image', absoluteImagePath],
			{
				windowsHide: true,
				cwd: extractorDir,
				env: {
					...process.env,
					PATH: pathEntries.join(';')
				}
			}
		);

		let output = '';
		let stderr = '';

		child.stdout.on('data', (chunk: Buffer | string) => {
			output += chunk.toString();
		});

		child.stderr.on('data', (chunk: Buffer | string) => {
			stderr += chunk.toString();
		});

		child.on('error', (error) => {
			rejectPromise(error);
		});

		child.on('close', (code) => {
			const parsed = parseExtractorOutput(output);
			if (parsed?.ok && code === 0) {
				resolvePromise(JSON.stringify(parsed));
				return;
			}

			if (code !== 0 || parsed?.ok === false) {
				rejectPromise(new Error(extractorFailureMessage(code, stderr, output)));
				return;
			}

			resolvePromise(output.trim());
		});
	});

	let parsed: ExtractorResult;
	try {
		parsed = JSON.parse(stdout) as ExtractorResult;
	} catch {
		throw new Error('Face extractor returned invalid JSON');
	}

	return validateFeaturePayload(parsed);
}
