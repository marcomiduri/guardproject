import { describe, expect, it } from 'vitest';
import { AppError } from '@/services/errors.js';
import {
	formatApiErrorBody,
	formatUnknownErrorBody,
	isRetryableHttpStatus
} from '@/services/api-error.js';

describe('api-error', () => {
	it('classifies retryable HTTP statuses', () => {
		expect(isRetryableHttpStatus(500)).toBe(true);
		expect(isRetryableHttpStatus(429)).toBe(true);
		expect(isRetryableHttpStatus(404)).toBe(false);
	});

	it('formats AppError responses with nested error object', () => {
		const body = formatApiErrorBody(new AppError('Camera not found', 404, 'CAMERA_NOT_FOUND'));
		expect(body).toEqual({
			error: {
				code: 'CAMERA_NOT_FOUND',
				message: 'Camera not found',
				retryable: false
			}
		});
	});

	it('honors explicit retryable flags', () => {
		const body = formatApiErrorBody(new AppError('Token expired', 401, 'TOKEN_EXPIRED', true));
		expect(body.error.retryable).toBe(true);
	});

	it('formats unknown errors consistently', () => {
		expect(formatUnknownErrorBody(503, 'Service unavailable')).toEqual({
			error: {
				code: 'INTERNAL_ERROR',
				message: 'Service unavailable',
				retryable: true
			}
		});
	});
});
