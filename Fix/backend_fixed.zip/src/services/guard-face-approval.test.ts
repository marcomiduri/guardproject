import { describe, expect, it } from 'vitest';
import {
	isPrivilegedGuardOperatorRole,
	resolveRecognizedFaceApproval
} from '@/services/guard-face-approval.js';

describe('guard face approval policy', () => {
	it('treats admin and staff as approved privileged operators', () => {
		expect(isPrivilegedGuardOperatorRole('admin')).toBe(true);
		expect(isPrivilegedGuardOperatorRole(' STAFF ')).toBe(true);
		expect(isPrivilegedGuardOperatorRole('user')).toBe(false);
	});

	it('does not require a room order for privileged incoming operators', () => {
		expect(
			resolveRecognizedFaceApproval({
				direction: 'in',
				userRole: 'admin',
				hasApprovedRoomOrder: false
			})
		).toBe(true);
		expect(
			resolveRecognizedFaceApproval({
				direction: 'in',
				userRole: 'staff',
				hasApprovedRoomOrder: false
			})
		).toBe(true);
	});

	it('keeps room-order approval for ordinary incoming users', () => {
		expect(
			resolveRecognizedFaceApproval({
				direction: 'in',
				userRole: 'user',
				hasApprovedRoomOrder: false
			})
		).toBe(false);
		expect(
			resolveRecognizedFaceApproval({
				direction: 'in',
				userRole: 'user',
				hasApprovedRoomOrder: true
			})
		).toBe(true);
	});

	it('stores outgoing recognition approval as not applicable', () => {
		expect(
			resolveRecognizedFaceApproval({
				direction: 'out',
				userRole: 'admin',
				hasApprovedRoomOrder: false
			})
		).toBeNull();
	});
});
