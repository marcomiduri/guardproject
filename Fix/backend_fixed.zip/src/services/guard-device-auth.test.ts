import { describe, expect, it } from 'vitest';
import {
	constantTimeHashEquals,
	deriveRotatedDeviceToken,
	formatActivationCode,
	hashActivationCode,
	hashDeviceToken,
	hashHardwareId,
	hardwareIdHashFormatValid,
	normalizeActivationCode,
	generateDeviceToken
} from './guard-device-auth.js';

describe('Guard device authentication helpers', () => {
	it('normalizes and formats activation codes', () => {
		expect(normalizeActivationCode('x7km-9q2p-f4tr')).toBe('X7KM9Q2PF4TR');
		expect(formatActivationCode('X7KM9Q2PF4TR')).toBe('X7KM-9Q2P-F4TR');
	});

	it('hashes equivalent activation-code forms identically', () => {
		expect(hashActivationCode('X7KM-9Q2P-F4TR')).toBe(hashActivationCode('x7km9q2pf4tr'));
	});

	it('hashes normalized hardware IDs to the v1 fingerprint format', () => {
		expect(hashHardwareId('ABCD-EF01-2345-6789')).toBe(
			'v1:1c1181e7f8dece465e066361d49886efa49b372e3e029fcdf21b9621e4021366'
		);
		expect(hashHardwareId('ABCD-EF01-2345-6789')).toBe(hashHardwareId('abcdef0123456789'));
		expect(hardwareIdHashFormatValid(hashHardwareId('ABCD-EF01-2345-6789'))).toBe(true);
	});

	it('creates random initial credentials and derives stable rotation credentials', () => {
		const initialA = generateDeviceToken();
		const initialB = generateDeviceToken();
		expect(initialA).not.toBe(initialB);
		expect(initialA.length).toBeGreaterThan(32);

		const rotatedA = deriveRotatedDeviceToken('installation-1', initialA);
		const rotatedB = deriveRotatedDeviceToken('installation-1', initialA);
		expect(rotatedA).toBe(rotatedB);
		expect(rotatedA).not.toBe(initialA);
	});

	it('compares stored token hashes safely', () => {
		const hash = hashDeviceToken('device-token');
		expect(constantTimeHashEquals(hash, hashDeviceToken('device-token'))).toBe(true);
		expect(constantTimeHashEquals(hash, hashDeviceToken('other-token'))).toBe(false);
		expect(constantTimeHashEquals(null, hash)).toBe(false);
	});
});
