import { SignJWT, jwtVerify } from 'jose';
import { env } from '@/config/env.js';
import type { JwtPayload } from '@/types/auth.js';

const secretKey = new TextEncoder().encode(env.JWT_SECRET);

export async function signAccessToken(payload: JwtPayload): Promise<string> {
	return new SignJWT({ email: payload.email, role: payload.role })
		.setProtectedHeader({ alg: 'HS256' })
		.setSubject(payload.sub)
		.setIssuedAt()
		.setExpirationTime(env.JWT_EXPIRES_IN)
		.sign(secretKey);
}

export async function verifyAccessToken(token: string): Promise<JwtPayload> {
	const { payload } = await jwtVerify(token, secretKey, {
		algorithms: ['HS256']
	});

	if (!payload.sub || typeof payload.email !== 'string' || typeof payload.role !== 'string') {
		throw new Error('Invalid token payload');
	}

	return {
		sub: payload.sub,
		email: payload.email,
		role: payload.role
	};
}
