import { randomUUID } from 'node:crypto';
import { and, asc, eq, gte, ilike, lt, lte, or, sql, type SQL } from 'drizzle-orm';

import { db } from '@/db/index.js';
import { users } from '@/db/schema/auth.js';
import { guardRooms, roomOrders, type RoomOrderStatus } from '@/db/schema/guard.js';
import { buildPagination, type PaginatedListData } from '@/http/responses.js';
import { collectColumnFilterConditions } from '@/lib/db/column-filters.js';
import { clampListPagination } from '@/lib/db/pagination.js';
import type {
	AdminRoomOrderColumnFilter,
	AdminRoomOrderListSortField,
	ListAdminRoomOrdersOptions,
	ListRoomOrdersOptions,
	RoomOrderColumnFilter,
	RoomOrderListSortField
} from '@/types/room-orders-list.js';
import type { ColumnFilterComparator } from '@/types/list-query.js';
import { guardRoomsService } from '@/services/guard-rooms.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { realtimeHub } from '@/services/realtime-hub.js';
import { badRequest, notFound } from '@/services/errors.js';
import { logger } from '@/utils/logger.js';

export type RoomOrderRecord = {
	id: string;
	roomId: string;
	roomName: string;
	startTime: string;
	endTime: string;
	status: RoomOrderStatus;
	createdAt: string;
	updatedAt: string;
};

export type AdminRoomOrderRecord = RoomOrderRecord & {
	userId: string;
	username: string;
};

export type PaginatedRoomOrdersList = PaginatedListData<RoomOrderRecord>;
export type PaginatedAdminRoomOrdersList = PaginatedListData<AdminRoomOrderRecord>;

export type CreateRoomOrderInput = {
	roomId: string;
	startTime: Date;
	endTime: Date;
};

export type UpdateRoomOrderInput = CreateRoomOrderInput;

function mapRoomOrder(row: {
	id: string;
	roomId: string;
	roomName: string;
	startTime: Date;
	endTime: Date;
	status: string;
	createdAt: Date;
	updatedAt: Date;
}): RoomOrderRecord {
	return {
		id: row.id,
		roomId: row.roomId,
		roomName: row.roomName,
		startTime: row.startTime.toISOString(),
		endTime: row.endTime.toISOString(),
		status: row.status as RoomOrderStatus,
		createdAt: row.createdAt.toISOString(),
		updatedAt: row.updatedAt.toISOString()
	};
}

function buildStatusFilterCondition(
	comparator: ColumnFilterComparator,
	value: string
): SQL | undefined {
	const text = value.trim().toLowerCase();

	if (comparator === 'eq') return eq(roomOrders.status, text);
	if (comparator === 'contains') return ilike(roomOrders.status, `%${text}%`);

	return undefined;
}

function buildTimestampFilterCondition(
	column: 'startTime' | 'endTime' | 'createdAt',
	comparator: ColumnFilterComparator,
	value: string
): SQL | undefined {
	const columnRef =
		column === 'startTime'
			? roomOrders.startTime
			: column === 'endTime'
				? roomOrders.endTime
				: roomOrders.createdAt;

	if (comparator === 'gte') return gte(columnRef, new Date(value));
	if (comparator === 'lte') return lte(columnRef, new Date(value));

	const expr = sql`${columnRef}::text`;
	if (comparator === 'eq') return sql`${expr} = ${value}`;
	if (comparator === 'contains') return ilike(expr, `%${value}%`);

	return undefined;
}

function mapAdminRoomOrder(row: {
	id: string;
	userId: string;
	username: string;
	roomId: string;
	roomName: string;
	startTime: Date;
	endTime: Date;
	status: string;
	createdAt: Date;
	updatedAt: Date;
}): AdminRoomOrderRecord {
	return {
		...mapRoomOrder(row),
		userId: row.userId,
		username: row.username
	};
}

function buildColumnFilterCondition(
	filter: RoomOrderColumnFilter | AdminRoomOrderColumnFilter,
	admin = false
): SQL | undefined {
	const { column, comparator, value } = filter;

	if (admin && column === 'username') {
		if (comparator === 'eq') return eq(users.username, value);
		if (comparator === 'contains') return ilike(users.username, `%${value}%`);
		return undefined;
	}

	switch (column) {
		case 'roomName': {
			if (comparator === 'eq') return eq(guardRooms.name, value);
			if (comparator === 'contains') return ilike(guardRooms.name, `%${value}%`);
			break;
		}
		case 'status':
			return buildStatusFilterCondition(comparator, value);
		case 'startTime':
			return buildTimestampFilterCondition('startTime', comparator, value);
		case 'endTime':
			return buildTimestampFilterCondition('endTime', comparator, value);
		case 'createdAt':
			return buildTimestampFilterCondition('createdAt', comparator, value);
	}

	return undefined;
}

function buildSearchCondition(search: string | undefined, admin = false): SQL | undefined {
	const trimmed = search?.trim();
	if (!trimmed) return undefined;

	const term = `%${trimmed}%`;

	const parts: SQL[] = [
		ilike(guardRooms.name, term),
		ilike(roomOrders.status, term),
		ilike(sql`${roomOrders.startTime}::text`, term),
		ilike(sql`${roomOrders.endTime}::text`, term),
		ilike(sql`${roomOrders.createdAt}::text`, term)
	];

	if (admin) {
		parts.push(ilike(users.username, term));
	}

	return or(...parts);
}

function buildUserWhereClause(options: ListRoomOrdersOptions): SQL {
	const conditions: SQL[] = [eq(roomOrders.userId, options.userId)];

	const searchCondition = buildSearchCondition(options.search);
	if (searchCondition) conditions.push(searchCondition);

	conditions.push(
		...collectColumnFilterConditions(options.columnFilters, (filter) =>
			buildColumnFilterCondition(filter)
		)
	);

	return and(...conditions)!;
}

function buildAdminWhereClause(options: ListAdminRoomOrdersOptions): SQL | undefined {
	const conditions: SQL[] = [];

	const searchCondition = buildSearchCondition(options.search, true);
	if (searchCondition) conditions.push(searchCondition);

	conditions.push(
		...collectColumnFilterConditions(options.columnFilters, (filter) =>
			buildColumnFilterCondition(filter, true)
		)
	);

	return conditions.length ? and(...conditions) : undefined;
}

async function expireDueOrders(now = new Date()): Promise<void> {
	await db
		.delete(roomOrders)
		.where(and(eq(roomOrders.status, 'pending'), lt(roomOrders.endTime, now)));

	await db
		.update(roomOrders)
		.set({ status: 'expired', updatedAt: now })
		.where(and(eq(roomOrders.status, 'approved'), lt(roomOrders.endTime, now)));
}

async function countPendingOrders(): Promise<number> {
	await expireDueOrders();

	const [row] = await db
		.select({ count: sql<number>`count(*)` })
		.from(roomOrders)
		.where(eq(roomOrders.status, 'pending'));

	return Number(row?.count ?? 0);
}

async function publishPendingOrdersCount(): Promise<void> {
	try {
		const count = await countPendingOrders();
		realtimeHub.publishPendingOrdersCount(count);
	} catch (err) {
		logger.error('[room-orders] failed to publish pending orders count', err);
	}
}

function buildUserSelectQuery() {
	return db
		.select({
			id: roomOrders.id,
			roomId: roomOrders.roomId,
			roomName: guardRooms.name,
			startTime: roomOrders.startTime,
			endTime: roomOrders.endTime,
			status: roomOrders.status,
			createdAt: roomOrders.createdAt,
			updatedAt: roomOrders.updatedAt
		})
		.from(roomOrders)
		.innerJoin(guardRooms, eq(roomOrders.roomId, guardRooms.id));
}

function buildAdminSelectQuery() {
	return db
		.select({
			id: roomOrders.id,
			userId: roomOrders.userId,
			username: users.username,
			roomId: roomOrders.roomId,
			roomName: guardRooms.name,
			startTime: roomOrders.startTime,
			endTime: roomOrders.endTime,
			status: roomOrders.status,
			createdAt: roomOrders.createdAt,
			updatedAt: roomOrders.updatedAt
		})
		.from(roomOrders)
		.innerJoin(guardRooms, eq(roomOrders.roomId, guardRooms.id))
		.innerJoin(users, eq(roomOrders.userId, users.id));
}

export const roomOrdersService = {
	async countPending(): Promise<number> {
		return countPendingOrders();
	},

	async hasApprovedAccessAt(userId: string, roomId: string, at: Date): Promise<boolean> {
		await expireDueOrders(at);

		const [order] = await db
			.select({ id: roomOrders.id })
			.from(roomOrders)
			.where(
				and(
					eq(roomOrders.userId, userId),
					eq(roomOrders.roomId, roomId),
					eq(roomOrders.status, 'approved'),
					lte(roomOrders.startTime, at),
					gte(roomOrders.endTime, at)
				)
			)
			.limit(1);

		return Boolean(order);
	},

	async list(options: ListRoomOrdersOptions): Promise<PaginatedRoomOrdersList> {
		await expireDueOrders();

		const { limit, offset } = clampListPagination(options);
		const sortOrder = options.sortOrder ?? 'desc';
		const whereClause = buildUserWhereClause(options);

		const countQuery = db
			.select({ count: sql<number>`count(*)` })
			.from(roomOrders)
			.innerJoin(guardRooms, eq(roomOrders.roomId, guardRooms.id))
			.where(whereClause);

		const countResult = await countQuery;
		const total = Number(countResult[0]?.count ?? 0);

		const sortColumnMap: Record<RoomOrderListSortField, SQL> = {
			roomName: sql`${guardRooms.name}`,
			startTime: sql`${roomOrders.startTime}`,
			endTime: sql`${roomOrders.endTime}`,
			status: sql`${roomOrders.status}`,
			createdAt: sql`${roomOrders.createdAt}`
		};

		const sortCol = options.sortBy ? sortColumnMap[options.sortBy] : sortColumnMap.createdAt;
		const sortDirection = sortOrder === 'asc' ? sql`ASC` : sql`DESC`;

		const rows = await buildUserSelectQuery()
			.where(whereClause)
			.orderBy(sql`${sortCol} ${sortDirection} NULLS LAST`, asc(roomOrders.id))
			.limit(limit)
			.offset(offset);

		return {
			items: rows.map(mapRoomOrder),
			pagination: buildPagination({
				total,
				limit,
				offset,
				itemCount: rows.length
			})
		};
	},

	async listAll(options: ListAdminRoomOrdersOptions = {}): Promise<PaginatedAdminRoomOrdersList> {
		await expireDueOrders();

		const { limit, offset } = clampListPagination(options);
		const sortOrder = options.sortOrder ?? 'desc';
		const whereClause = buildAdminWhereClause(options);

		const countQuery = db
			.select({ count: sql<number>`count(*)` })
			.from(roomOrders)
			.innerJoin(guardRooms, eq(roomOrders.roomId, guardRooms.id))
			.innerJoin(users, eq(roomOrders.userId, users.id));

		const countResult = whereClause ? await countQuery.where(whereClause) : await countQuery;
		const total = Number(countResult[0]?.count ?? 0);

		const sortColumnMap: Record<AdminRoomOrderListSortField, SQL> = {
			username: sql`${users.username}`,
			roomName: sql`${guardRooms.name}`,
			startTime: sql`${roomOrders.startTime}`,
			endTime: sql`${roomOrders.endTime}`,
			status: sql`${roomOrders.status}`,
			createdAt: sql`${roomOrders.createdAt}`
		};

		const sortCol = options.sortBy ? sortColumnMap[options.sortBy] : sortColumnMap.createdAt;
		const sortDirection = sortOrder === 'asc' ? sql`ASC` : sql`DESC`;

		const itemsQuery = buildAdminSelectQuery()
			.orderBy(sql`${sortCol} ${sortDirection} NULLS LAST`, asc(roomOrders.id))
			.limit(limit)
			.offset(offset);

		const rows = whereClause ? await itemsQuery.where(whereClause) : await itemsQuery;

		return {
			items: rows.map(mapAdminRoomOrder),
			pagination: buildPagination({
				total,
				limit,
				offset,
				itemCount: rows.length
			})
		};
	},

	async create(userId: string, input: CreateRoomOrderInput): Promise<RoomOrderRecord> {
		if (input.endTime <= input.startTime) {
			throw badRequest('endTime must be after startTime');
		}

		const faceStatus = await faceRegistrationService.getStatus(userId);
		if (!faceStatus.imageUrl) {
			throw badRequest('Profile photo is required before placing an order');
		}

		await guardRoomsService.getById(input.roomId);

		const now = new Date();
		const id = randomUUID();

		const [row] = await db
			.insert(roomOrders)
			.values({
				id,
				userId,
				roomId: input.roomId,
				startTime: input.startTime,
				endTime: input.endTime,
				status: 'pending',
				createdAt: now,
				updatedAt: now
			})
			.returning();

		const room = await guardRoomsService.getById(row.roomId);

		const [userRow] = await db
			.select({ username: users.username })
			.from(users)
			.where(eq(users.id, userId))
			.limit(1);

		const order = mapRoomOrder({
			id: row.id,
			roomId: row.roomId,
			roomName: room.name,
			startTime: row.startTime,
			endTime: row.endTime,
			status: row.status,
			createdAt: row.createdAt,
			updatedAt: row.updatedAt
		});

		realtimeHub.publishRoomOrderCreated({
			id: order.id,
			userId,
			userName: userRow?.username?.trim() || userId,
			roomId: order.roomId,
			roomName: order.roomName,
			startTime: order.startTime,
			endTime: order.endTime,
			createdAt: order.createdAt
		});

		void publishPendingOrdersCount();

		return order;
	},

	async getByIdForUser(userId: string, orderId: string): Promise<RoomOrderRecord> {
		await expireDueOrders();

		const [row] = await buildUserSelectQuery()
			.where(and(eq(roomOrders.id, orderId), eq(roomOrders.userId, userId)))
			.limit(1);

		if (!row) {
			throw notFound('Order not found');
		}

		return mapRoomOrder(row);
	},

	async getByIdForAdmin(orderId: string): Promise<AdminRoomOrderRecord> {
		await expireDueOrders();

		const [row] = await buildAdminSelectQuery().where(eq(roomOrders.id, orderId)).limit(1);

		if (!row) {
			throw notFound('Order not found');
		}

		return mapAdminRoomOrder(row);
	},

	async updateForUser(
		userId: string,
		orderId: string,
		input: UpdateRoomOrderInput
	): Promise<RoomOrderRecord> {
		const existing = await this.getByIdForUser(userId, orderId);

		if (existing.status !== 'pending') {
			throw badRequest('Only pending orders can be updated');
		}

		if (input.endTime <= input.startTime) {
			throw badRequest('endTime must be after startTime');
		}

		await guardRoomsService.getById(input.roomId);

		const now = new Date();

		await db
			.update(roomOrders)
			.set({
				roomId: input.roomId,
				startTime: input.startTime,
				endTime: input.endTime,
				updatedAt: now
			})
			.where(and(eq(roomOrders.id, orderId), eq(roomOrders.userId, userId)));

		const order = await this.getByIdForUser(userId, orderId);

		const [userRow] = await db
			.select({ username: users.username })
			.from(users)
			.where(eq(users.id, userId))
			.limit(1);

		realtimeHub.publishRoomOrderUpdated({
			id: order.id,
			userId,
			userName: userRow?.username?.trim() || userId,
			roomId: order.roomId,
			roomName: order.roomName,
			startTime: order.startTime,
			endTime: order.endTime,
			updatedAt: order.updatedAt
		});

		return order;
	},

	async updateStatusForAdmin(
		orderId: string,
		status: Extract<RoomOrderStatus, 'approved' | 'rejected'>
	): Promise<AdminRoomOrderRecord> {
		const existing = await this.getByIdForAdmin(orderId);

		if (existing.status !== 'pending') {
			throw badRequest('Only pending orders can be approved or rejected');
		}

		const now = new Date();

		await db
			.update(roomOrders)
			.set({
				status,
				updatedAt: now
			})
			.where(eq(roomOrders.id, orderId));

		void publishPendingOrdersCount();

		const order = await this.getByIdForAdmin(orderId);

		realtimeHub.publishRoomOrderReviewed({
			id: order.id,
			userId: order.userId,
			roomId: order.roomId,
			roomName: order.roomName,
			startTime: order.startTime,
			endTime: order.endTime,
			status,
			updatedAt: order.updatedAt
		});

		return order;
	},

	async deleteForUser(userId: string, orderId: string): Promise<void> {
		const order = await this.getByIdForUser(userId, orderId);

		if (order.status === 'approved' || order.status === 'expired') {
			throw badRequest('This order cannot be deleted');
		}

		await db
			.delete(roomOrders)
			.where(and(eq(roomOrders.id, orderId), eq(roomOrders.userId, userId)));

		if (order.status === 'pending') {
			void publishPendingOrdersCount();
		}
	}
};
