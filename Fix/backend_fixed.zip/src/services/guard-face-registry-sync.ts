import { guardFacesService, type GuardFaceRegistryVersion } from '@/services/guard-faces.js';
import { guardRealtimeHub } from '@/services/guard-realtime-hub.js';
import { logger } from '@/utils/logger.js';

/**
 * Publish a lightweight invalidation after a committed registry-affecting change.
 * The data change must remain successful even when version lookup or realtime
 * delivery is temporarily unavailable; Guard polling will recover later.
 */
export async function publishCurrentFaceRegistryInvalidation(): Promise<GuardFaceRegistryVersion | null> {
	try {
		const registry = await guardFacesService.getRegistryVersion();
		guardRealtimeHub.publishFaceRegistryUpdated({
			version: registry.version,
			scope: registry.scope,
			updatedAt: registry.updatedAt
		});
		return registry;
	} catch (error) {
		logger.warn(
			'[guard-face-registry] invalidation publication deferred:',
			error instanceof Error ? error.message : 'unknown error'
		);
		return null;
	}
}
