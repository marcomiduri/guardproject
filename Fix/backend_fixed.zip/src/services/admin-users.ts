import { and, asc, eq, ilike, isNotNull, isNull, or, sql, type SQL } from 'drizzle-orm';

import { db } from '@/db/index.js';

import { assertUserRole, users, type UserRole } from '@/db/schema/auth.js';

import { buildPagination, type PaginatedListData } from '@/http/responses.js';
import { collectColumnFilterConditions } from '@/lib/db/column-filters.js';
import { textColumnFilter, timestampColumnFilter } from '@/lib/db/filter-sql.js';
import { clampListPagination } from '@/lib/db/pagination.js';
import { assertCanDemoteAdmin } from '@/services/admin-guard.js';
import type {
	AdminUsersColumnFilter,
	AdminUsersListSortField,
	ListAdminUsersOptions
} from '@/types/admin-users-list.js';
import type { ColumnFilterComparator } from '@/types/list-query.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { notFound } from '@/services/errors.js';

export type AdminUserRecord = {
	id: string;
	username: string;
	email: string;
	role: string;
	birthday: string | null;
	job: string | null;
	position: string | null;
	faceRegisteredAt: string | null;
	createdAt: string;
	updatedAt: string;
};

export type AdminUserDetail = AdminUserRecord & {
	faceRegistryId: number | null;
	faceModel: string | null;
	hasPhoto: boolean;
};

export type PaginatedAdminUsersList = PaginatedListData<AdminUserRecord>;

function toAdminUserRecord(user: {
	id: string;
	username: string;
	email: string;
	role: string;
	birthday: string | null;
	job: string | null;
	position: string | null;
	faceRegisteredAt: Date | null;
	createdAt: Date;
	updatedAt: Date;
}): AdminUserRecord {
	return {
		id: user.id,
		username: user.username,
		email: user.email,
		role: user.role,
		birthday: user.birthday,
		job: user.job,
		position: user.position,
		faceRegisteredAt: user.faceRegisteredAt?.toISOString() ?? null,
		createdAt: user.createdAt.toISOString(),
		updatedAt: user.updatedAt.toISOString()
	};
}

function toAdminUserDetail(
	user: {
		id: string;
		username: string;
		email: string;
		role: string;
		birthday: string | null;
		job: string | null;
		position: string | null;
		faceRegisteredAt: Date | null;
		faceRegistryId: number | null;
		faceModel: string | null;
		createdAt: Date;
		updatedAt: Date;
	},
	hasPhoto: boolean
): AdminUserDetail {
	return {
		...toAdminUserRecord(user),
		faceRegistryId: user.faceRegistryId,
		faceModel: user.faceModel,
		hasPhoto
	};
}

function resolveRoleFilterValue(value: string): string {
	const lower = value.trim().toLowerCase();
	if (lower === 'admin') return 'admin';
	if (lower === 'user') return 'user';
	if (lower === 'staff') return 'staff';
	return value.trim();
}

function buildFaceRegisteredFilterCondition(
	comparator: ColumnFilterComparator,
	value: string
): SQL | undefined {
	const lower = value.trim().toLowerCase();

	if (comparator === 'eq') {
		if (lower === 'yes' || lower === 'registered') return isNotNull(users.faceRegisteredAt);
		if (lower === 'no' || lower === 'unregistered') return isNull(users.faceRegisteredAt);
	}

	if (comparator === 'contains') {
		if (lower.includes('yes') || lower.includes('registered'))
			return isNotNull(users.faceRegisteredAt);
		if (lower.includes('no') || lower.includes('unregistered'))
			return isNull(users.faceRegisteredAt);
	}

	const expr = sql`${users.faceRegisteredAt}::text`;
	if (comparator === 'eq') return sql`${expr} = ${value}`;
	if (comparator === 'contains') return ilike(expr, `%${value}%`);
	if (comparator === 'gte') return sql`${expr} >= ${value}`;
	if (comparator === 'lte') return sql`${expr} <= ${value}`;

	return undefined;
}

function buildColumnFilterCondition(filter: AdminUsersColumnFilter): SQL | undefined {
	const { column, comparator, value } = filter;

	switch (column) {
		case 'username':
			return textColumnFilter(users.username, comparator, value);
		case 'email':
			return textColumnFilter(users.email, comparator, value);
		case 'birthday':
			return timestampColumnFilter(sql`${users.birthday}::text`, users.birthday, comparator, value);
		case 'job':
			return textColumnFilter(users.job, comparator, value);
		case 'position':
			return textColumnFilter(users.position, comparator, value);
		case 'role': {
			const role = resolveRoleFilterValue(value);
			if (comparator === 'eq') return eq(users.role, role);
			if (comparator === 'contains') return ilike(users.role, `%${role}%`);
			break;
		}
		case 'faceRegisteredAt':
			return buildFaceRegisteredFilterCondition(comparator, value);
		case 'createdAt':
			return timestampColumnFilter(
				sql`${users.createdAt}::text`,
				users.createdAt,
				comparator,
				value
			);
	}

	return undefined;
}

function buildSearchCondition(search: string | undefined): SQL | undefined {
	const trimmed = search?.trim();
	if (!trimmed) return undefined;

	const term = `%${trimmed}%`;
	const parts: SQL[] = [
		ilike(users.username, term),
		ilike(users.email, term),
		ilike(sql`${users.birthday}::text`, term),
		ilike(users.job, term),
		ilike(users.position, term),
		ilike(users.role, term),
		ilike(sql`${users.faceRegisteredAt}::text`, term),
		ilike(sql`${users.createdAt}::text`, term)
	];

	const lower = trimmed.toLowerCase();
	if (lower === 'yes' || lower === 'registered') {
		parts.push(isNotNull(users.faceRegisteredAt));
	}
	if (lower === 'no' || lower === 'unregistered') {
		parts.push(isNull(users.faceRegisteredAt));
	}
	if (lower === 'admin') {
		parts.push(eq(users.role, 'admin'));
	}
	if (lower === 'user') {
		parts.push(eq(users.role, 'user'));
	}
	if (lower === 'staff') {
		parts.push(eq(users.role, 'staff'));
	}

	return or(...parts);
}

function buildWhereClause(options: ListAdminUsersOptions): SQL | undefined {
	const conditions: SQL[] = [];

	const searchCondition = buildSearchCondition(options.search);
	if (searchCondition) conditions.push(searchCondition);

	conditions.push(
		...collectColumnFilterConditions(options.columnFilters, buildColumnFilterCondition)
	);

	return conditions.length ? and(...conditions) : undefined;
}

export const adminUsersService = {
	async list(options: ListAdminUsersOptions = {}): Promise<PaginatedAdminUsersList> {
		const { limit, offset } = clampListPagination(options);
		const sortOrder = options.sortOrder ?? 'asc';
		const whereClause = buildWhereClause(options);

		const countQuery = db.select({ count: sql<number>`count(*)` }).from(users);
		const countResult = whereClause ? await countQuery.where(whereClause) : await countQuery;
		const total = Number(countResult[0]?.count ?? 0);

		const sortColumnMap: Record<AdminUsersListSortField, SQL> = {
			username: sql`${users.username}`,
			email: sql`${users.email}`,
			birthday: sql`${users.birthday}`,
			job: sql`${users.job}`,
			position: sql`${users.position}`,
			role: sql`${users.role}`,
			faceRegisteredAt: sql`${users.faceRegisteredAt}`,
			createdAt: sql`${users.createdAt}`
		};

		const sortCol = options.sortBy ? sortColumnMap[options.sortBy] : sortColumnMap.username;
		const sortDirection = sortOrder === 'asc' ? sql`ASC` : sql`DESC`;

		const itemsQuery = db
			.select({
				id: users.id,
				username: users.username,
				email: users.email,
				role: users.role,
				birthday: users.birthday,
				job: users.job,
				position: users.position,
				faceRegisteredAt: users.faceRegisteredAt,
				createdAt: users.createdAt,
				updatedAt: users.updatedAt
			})
			.from(users)
			.orderBy(sql`${sortCol} ${sortDirection} NULLS LAST`, asc(users.id))
			.limit(limit)
			.offset(offset);

		const rows = whereClause ? await itemsQuery.where(whereClause) : await itemsQuery;

		return {
			items: rows.map(toAdminUserRecord),
			pagination: buildPagination({
				total,
				limit,
				offset,
				itemCount: rows.length
			})
		};
	},

	async getById(id: string): Promise<AdminUserDetail> {
		const user = await db.query.users.findFirst({
			where: eq(users.id, id),
			columns: {
				id: true,
				username: true,
				email: true,
				role: true,
				birthday: true,
				job: true,
				position: true,
				faceRegisteredAt: true,
				faceRegistryId: true,
				faceModel: true,
				createdAt: true,
				updatedAt: true
			}
		});

		if (!user) {
			throw notFound('User not found');
		}

		const faceStatus = await faceRegistrationService.getStatus(id);

		return toAdminUserDetail(user, faceStatus.imageUrl !== null);
	},

	async updateRole(id: string, role: UserRole): Promise<AdminUserDetail> {
		const user = await db.query.users.findFirst({
			where: eq(users.id, id),
			columns: { id: true, role: true }
		});

		if (!user) {
			throw notFound('User not found');
		}

		const nextRole = assertUserRole(role);

		if (user.role === nextRole) {
			return this.getById(id);
		}

		if (user.role === 'admin' && nextRole !== 'admin') {
			await assertCanDemoteAdmin(user.role, nextRole);
		}

		await db.update(users).set({ role: nextRole }).where(eq(users.id, id));

		return this.getById(id);
	}
};
