import bcrypt from 'bcryptjs';
import { and, eq, ne } from 'drizzle-orm';

import { db } from '@/db/index.js';
import { users } from '@/db/schema/auth.js';
import { guardFaceAppearances } from '@/db/schema/guard.js';
import { BCRYPT_SALT_ROUNDS } from '@/constants/auth.js';
import { toAuthUser } from '@/lib/auth/map-user.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { assertCanDeleteAdmin } from '@/services/admin-guard.js';
import { badRequest, invalidPassword, notFound } from '@/services/errors.js';
import { signAccessToken } from '@/services/jwt.js';
import { publishCurrentFaceRegistryInvalidation } from '@/services/guard-face-registry-sync.js';
import type { AuthUser } from '@/types/auth.js';

async function loadUser(userId: string) {
	const user = await db.query.users.findFirst({
		where: eq(users.id, userId)
	});

	if (!user) {
		throw notFound('User not found');
	}

	return user;
}

async function verifyCurrentPassword(
	user: typeof users.$inferSelect,
	currentPassword: string
): Promise<void> {
	const valid = await bcrypt.compare(currentPassword, user.passwordHash);
	if (!valid) {
		throw invalidPassword();
	}
}

async function removeUserAccount(userId: string): Promise<void> {
	const user = await loadUser(userId);

	await assertCanDeleteAdmin(user.role);

	await db.transaction(async (tx) => {
		await tx
			.update(guardFaceAppearances)
			.set({ userId: null })
			.where(eq(guardFaceAppearances.userId, userId));

		const deleted = await tx.delete(users).where(eq(users.id, userId)).returning({ id: users.id });
		if (deleted.length === 0) {
			throw notFound('User not found');
		}
	});

	await faceRegistrationService.deleteStoredFace(userId);
	if (user.faceRegistryId) {
		await publishCurrentFaceRegistryInvalidation();
	}
}

export const userAccountService = {
	async updateEmail(
		userId: string,
		input: { email: string; currentPassword: string }
	): Promise<{ user: AuthUser; accessToken: string }> {
		const user = await loadUser(userId);
		await verifyCurrentPassword(user, input.currentPassword);

		if (input.email === user.email) {
			throw badRequest('New email must be different from your current email');
		}

		const existing = await db.query.users.findFirst({
			where: and(eq(users.email, input.email), ne(users.id, userId)),
			columns: { id: true }
		});

		if (existing) {
			throw badRequest('An account with this email already exists');
		}

		const [updated] = await db
			.update(users)
			.set({ email: input.email })
			.where(eq(users.id, userId))
			.returning();

		const accessToken = await signAccessToken({
			sub: updated.id,
			email: updated.email,
			role: updated.role
		});

		return { user: toAuthUser(updated), accessToken };
	},

	async updatePassword(
		userId: string,
		input: { currentPassword: string; newPassword: string }
	): Promise<AuthUser> {
		const user = await loadUser(userId);
		await verifyCurrentPassword(user, input.currentPassword);

		const passwordHash = await bcrypt.hash(input.newPassword, BCRYPT_SALT_ROUNDS);

		const [updated] = await db
			.update(users)
			.set({ passwordHash })
			.where(eq(users.id, userId))
			.returning();

		return toAuthUser(updated);
	},

	async closeAccount(userId: string, currentPassword: string): Promise<void> {
		const user = await loadUser(userId);
		await verifyCurrentPassword(user, currentPassword);
		await removeUserAccount(userId);
	}
};

export async function deleteUserAccountById(userId: string): Promise<void> {
	await removeUserAccount(userId);
}
