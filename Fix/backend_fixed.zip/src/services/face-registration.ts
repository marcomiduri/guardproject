import { mkdir, readFile, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { existsSync } from 'node:fs';
import { eq, sql } from 'drizzle-orm';
import { env } from '@/config/env.js';
import { db } from '@/db/index.js';
import { users } from '@/db/schema/auth.js';
import { extractFaceFeatureFromImage } from '@/services/face-extraction.js';
import { badRequest, notFound } from '@/services/errors.js';
import { publishCurrentFaceRegistryInvalidation } from '@/services/guard-face-registry-sync.js';
import {
	removeFaceExtractionSidecar,
	writeFaceImageForExtraction
} from '@/utils/face-image-buffer.js';

const FACES_DIR = join(env.UPLOADS_DIR, 'faces');

export type FaceRegistrationStatus = {
	registered: boolean;
	registeredAt: string | null;
	faceRegistryId: number | null;
	faceModel: string | null;
	featureDimension: number | null;
	imageUrl: string | null;
	registryVersion?: string;
	registryUpdatedAt?: string;
	registryScope?: string;
};

async function ensureFacesDir(): Promise<void> {
	await mkdir(FACES_DIR, { recursive: true });
}

function faceImagePath(userId: string): string {
	return join(FACES_DIR, `${userId}.jpg`);
}

async function allocateFaceRegistryId(): Promise<number> {
	const result = await db.execute<{ id: number }>(
		sql`SELECT nextval('user_face_registry_id_seq')::int AS id`
	);

	const row = result.rows[0];
	const id = row?.id;
	if (!Number.isInteger(id) || id <= 0) {
		throw new Error('Failed to allocate face registry id from sequence');
	}

	return id;
}

/**
 * Returns the user's stable face_registry_id, allocating from the DB sequence on first registration.
 */
export async function ensureFaceRegistryId(userId: string): Promise<number> {
	const user = await db.query.users.findFirst({
		where: eq(users.id, userId),
		columns: { faceRegistryId: true }
	});

	if (!user) {
		throw notFound('User not found');
	}

	if (user.faceRegistryId != null && user.faceRegistryId > 0) {
		return user.faceRegistryId;
	}

	const faceRegistryId = await allocateFaceRegistryId();

	await db.update(users).set({ faceRegistryId }).where(eq(users.id, userId));

	return faceRegistryId;
}

export const faceRegistrationService = {
	async getStatus(userId: string): Promise<FaceRegistrationStatus> {
		const user = await db.query.users.findFirst({
			where: eq(users.id, userId)
		});

		if (!user) {
			throw notFound('User not found');
		}

		const imagePath = faceImagePath(userId);
		const hasImage = existsSync(imagePath);
		const hasEmbedding = Array.isArray(user.faceEmbedding) && user.faceEmbedding.length > 0;

		return {
			registered: Boolean(user.faceRegisteredAt && hasImage && hasEmbedding),
			registeredAt: user.faceRegisteredAt?.toISOString() ?? null,
			faceRegistryId: user.faceRegistryId ?? null,
			faceModel: user.faceModel ?? null,
			featureDimension: hasEmbedding ? user.faceEmbedding!.length : null,
			imageUrl: hasImage ? '/api/me/face/image' : null
		};
	},

	async registerFace(userId: string, imageBuffer: Buffer): Promise<FaceRegistrationStatus> {
		const user = await db.query.users.findFirst({
			where: eq(users.id, userId)
		});

		if (!user) {
			throw notFound('User not found');
		}

		if (imageBuffer.length < 32) {
			throw badRequest('Image is too small to use for face registration');
		}

		await ensureFacesDir();

		let extractionPath: string;
		let storagePath: string;
		try {
			const paths = await writeFaceImageForExtraction(FACES_DIR, userId, imageBuffer);
			extractionPath = paths.extractionPath;
			storagePath = paths.storagePath;
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid face image');
		}

		let extracted;
		try {
			extracted = await extractFaceFeatureFromImage(extractionPath);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Face feature extraction failed');
		} finally {
			await removeFaceExtractionSidecar(extractionPath, storagePath);
		}

		const faceRegistryId = await ensureFaceRegistryId(userId);
		const registeredAt = new Date();

		await db
			.update(users)
			.set({
				faceRegisteredAt: registeredAt,
				faceEmbedding: extracted.feature,
				faceModel: env.FACE_MODEL_NAME,
				updatedAt: registeredAt
			})
			.where(eq(users.id, userId));

		const registry = await publishCurrentFaceRegistryInvalidation();

		return {
			registered: true,
			registeredAt: registeredAt.toISOString(),
			faceRegistryId,
			faceModel: env.FACE_MODEL_NAME,
			featureDimension: extracted.feature.length,
			imageUrl: '/api/me/face/image',
			...(registry
				? {
						registryVersion: registry.version,
						registryUpdatedAt: registry.updatedAt,
						registryScope: registry.scope
					}
				: {})
		};
	},

	async readFaceImage(userId: string): Promise<Buffer> {
		const imagePath = faceImagePath(userId);
		if (!existsSync(imagePath)) {
			throw notFound('Face image not found');
		}

		return readFile(imagePath);
	},

	async deleteStoredFace(userId: string): Promise<void> {
		try {
			await unlink(faceImagePath(userId));
		} catch {
			// Ignore missing files.
		}
	}
};
