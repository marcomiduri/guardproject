import { decodeJwt } from 'jose';
import { describe, expect, it } from 'vitest';
import { signGuardAccessToken, verifyGuardAccessToken } from './guard-jwt.js';

const installationId = '11111111-1111-1111-1111-111111111111';
const roomId = '22222222-2222-2222-2222-222222222222';

describe('Guard installation JWTs', () => {
	it('contain only installation, room and scope authorization data', async () => {
		const token = await signGuardAccessToken({
			installationId,
			roomId,
			scope: ['events:write', 'faces:read']
		});

		const decoded = decodeJwt(token);
		expect(decoded.sub).toBe(installationId);
		expect(decoded.roomId).toBe(roomId);
		expect(decoded.scope).toEqual(['events:write', 'faces:read']);
		expect(decoded).not.toHaveProperty('entitlement');
		expect(decoded).not.toHaveProperty('licenseType');
		expect(decoded).not.toHaveProperty('trialExpiresAt');

		await expect(verifyGuardAccessToken(token)).resolves.toEqual({
			installationId,
			roomId,
			scope: ['events:write', 'faces:read']
		});
	});
});
