import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
	DEFAULT_ADMIN_NOTIFICATION_SETTINGS,
	type AdminNotificationSettings
} from '@/types/admin-notification-settings.js';

const backendRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const settingsPath = path.join(backendRoot, 'data', 'admin-notification-settings.json');

let cachedSettings: AdminNotificationSettings = { ...DEFAULT_ADMIN_NOTIFICATION_SETTINGS };
let loaded = false;

function normalizeSettings(
	value: Partial<AdminNotificationSettings> | null | undefined
): AdminNotificationSettings {
	return {
		notifyUnapprovedIncoming:
			value?.notifyUnapprovedIncoming ??
			DEFAULT_ADMIN_NOTIFICATION_SETTINGS.notifyUnapprovedIncoming,
		notifyUnknownIncoming:
			value?.notifyUnknownIncoming ?? DEFAULT_ADMIN_NOTIFICATION_SETTINGS.notifyUnknownIncoming
	};
}

async function ensureLoaded(): Promise<void> {
	if (loaded) {
		return;
	}

	try {
		const raw = await readFile(settingsPath, 'utf8');
		cachedSettings = normalizeSettings(JSON.parse(raw) as Partial<AdminNotificationSettings>);
	} catch {
		cachedSettings = { ...DEFAULT_ADMIN_NOTIFICATION_SETTINGS };
	}

	loaded = true;
}

async function persist(settings: AdminNotificationSettings): Promise<void> {
	await mkdir(path.dirname(settingsPath), { recursive: true });
	await writeFile(settingsPath, `${JSON.stringify(settings, null, 2)}\n`, 'utf8');
	cachedSettings = settings;
	loaded = true;
}

export const adminNotificationSettingsService = {
	async get(): Promise<AdminNotificationSettings> {
		await ensureLoaded();
		return { ...cachedSettings };
	},

	async update(input: Partial<AdminNotificationSettings>): Promise<AdminNotificationSettings> {
		await ensureLoaded();
		const next = normalizeSettings({ ...cachedSettings, ...input });
		await persist(next);
		return { ...next };
	}
};
