import { eq } from 'drizzle-orm';

import { db } from '@/db/index.js';
import { users } from '@/db/schema/auth.js';
import { toAuthUser } from '@/lib/auth/map-user.js';
import type { AuthUser } from '@/types/auth.js';
import { notFound } from '@/services/errors.js';
import { publishCurrentFaceRegistryInvalidation } from '@/services/guard-face-registry-sync.js';
import type { UpdateProfileInput } from '@/validators/profile.js';

export const userProfileService = {
	async update(userId: string, input: UpdateProfileInput): Promise<AuthUser> {
		const patch: Partial<typeof users.$inferInsert> = {};

		if (input.username !== undefined) {
			patch.username = input.username;
		}

		if (input.birthday !== undefined) {
			patch.birthday = input.birthday;
		}

		if (input.job !== undefined) {
			patch.job = input.job;
		}

		if (input.position !== undefined) {
			patch.position = input.position;
		}

		const [user] = await db.update(users).set(patch).where(eq(users.id, userId)).returning();

		if (!user) {
			throw notFound('User not found');
		}

		if (input.username !== undefined && user.faceRegistryId && user.faceEmbedding) {
			await publishCurrentFaceRegistryInvalidation();
		}

		return toAuthUser(user);
	}
};
