import { and, eq, isNotNull } from 'drizzle-orm';
import { createHash } from 'node:crypto';
import { env } from '@/config/env.js';
import { db } from '@/db/index.js';
import { users, type User } from '@/db/schema/auth.js';

const GLOBAL_REGISTRY_SCOPE = 'global';

export type GuardFaceEntry = {
	id: number;
	name: string;
	feature: number[];
};

export type GuardFaceUserInfo = {
	id: number;
	name: string;
};

export type GuardFaceRegistry = {
	version: string;
	updatedAt: string;
	scope: string;
	threshold: number;
	model: string;
	faces: GuardFaceEntry[];
};

export type GuardFaceRegistryVersion = {
	version: string;
	updatedAt: string;
	scope: string;
	count: number;
	model: string;
	threshold: number;
};

type RegisteredFaceRow = Pick<
	User,
	'faceRegistryId' | 'username' | 'faceEmbedding' | 'faceModel' | 'faceRegisteredAt' | 'updatedAt'
>;

export type RegisteredFaceCollection = {
	faces: GuardFaceEntry[];
	latestChangedAt: Date | null;
	featureDimension: number | null;
};

/**
 * Build one internally consistent registry for the configured recognition model.
 * GuardVision cannot safely compare embeddings from different models or dimensions.
 */
export function collectRegisteredFaceEntries(
	rows: RegisteredFaceRow[],
	expectedModel: string
): RegisteredFaceCollection {
	const faces: GuardFaceEntry[] = [];
	let latestChangedAt: Date | null = null;
	let featureDimension: number | null = null;
	const seenRegistryIds = new Set<number>();

	for (const user of rows) {
		if (
			!user.faceRegistryId ||
			!Array.isArray(user.faceEmbedding) ||
			user.faceModel !== expectedModel
		) {
			continue;
		}

		const name = user.username.trim();
		if (!name || seenRegistryIds.has(user.faceRegistryId)) continue;

		const feature = user.faceEmbedding.filter(
			(value): value is number => typeof value === 'number' && Number.isFinite(value)
		);
		if (feature.length === 0 || feature.length !== user.faceEmbedding.length) continue;

		if (featureDimension === null) featureDimension = feature.length;
		else if (feature.length !== featureDimension) continue;

		const changedAt =
			user.updatedAt && user.faceRegisteredAt
				? user.updatedAt > user.faceRegisteredAt
					? user.updatedAt
					: user.faceRegisteredAt
				: (user.updatedAt ?? user.faceRegisteredAt);
		if (changedAt && (!latestChangedAt || changedAt > latestChangedAt)) latestChangedAt = changedAt;

		seenRegistryIds.add(user.faceRegistryId);
		faces.push({ id: user.faceRegistryId, name, feature });
	}

	faces.sort((left, right) => left.id - right.id);
	return { faces, latestChangedAt, featureDimension };
}

export function buildRegistryVersion(
	faces: GuardFaceEntry[],
	latestChangedAt: Date | null,
	model: string
): string {
	// Include the actual feature values in the digest. A changed embedding must
	// invalidate Guard even when an external data repair preserves timestamps.
	const hash = createHash('sha256')
		.update(model)
		.update('\0')
		.update(latestChangedAt?.toISOString() ?? '')
		.update('\0');

	for (const face of faces) {
		hash.update(String(face.id)).update('\0').update(face.name).update('\0');
		const valueBuffer = Buffer.allocUnsafe(face.feature.length * 8);
		face.feature.forEach((value, index) => valueBuffer.writeDoubleLE(value, index * 8));
		hash.update(valueBuffer);
	}

	return `v2:${hash.digest('hex').slice(0, 24)}`;
}

async function loadRegistryCollection(): Promise<RegisteredFaceCollection> {
	const rows = await db.query.users.findMany({
		where: and(isNotNull(users.faceEmbedding), eq(users.faceModel, env.FACE_MODEL_NAME))
	});
	return collectRegisteredFaceEntries(rows, env.FACE_MODEL_NAME);
}

function registryMetadata(collection: RegisteredFaceCollection) {
	const changedAt = collection.latestChangedAt ?? new Date(0);
	return {
		version: buildRegistryVersion(
			collection.faces,
			collection.latestChangedAt,
			env.FACE_MODEL_NAME
		),
		updatedAt: changedAt.toISOString(),
		scope: GLOBAL_REGISTRY_SCOPE,
		count: collection.faces.length,
		model: env.FACE_MODEL_NAME,
		threshold:
			Number.isFinite(env.FACE_RECOGNITION_THRESHOLD) &&
			env.FACE_RECOGNITION_THRESHOLD >= 0 &&
			env.FACE_RECOGNITION_THRESHOLD <= 1
				? env.FACE_RECOGNITION_THRESHOLD
				: 0.48
	};
}

export const guardFacesService = {
	async getRegistry(): Promise<GuardFaceRegistry> {
		const collection = await loadRegistryCollection();
		const metadata = registryMetadata(collection);
		return {
			version: metadata.version,
			updatedAt: metadata.updatedAt,
			scope: metadata.scope,
			threshold: metadata.threshold,
			model: metadata.model,
			faces: collection.faces
		};
	},

	async getRegistryVersion(): Promise<GuardFaceRegistryVersion> {
		const collection = await loadRegistryCollection();
		return registryMetadata(collection);
	},

	async getUserByFaceRegistryId(faceRegistryId: number): Promise<GuardFaceUserInfo | null> {
		const user = await db.query.users.findFirst({
			where: and(
				eq(users.faceRegistryId, faceRegistryId),
				isNotNull(users.faceEmbedding),
				eq(users.faceModel, env.FACE_MODEL_NAME)
			)
		});

		if (
			!user ||
			!Array.isArray(user.faceEmbedding) ||
			user.faceEmbedding.length === 0 ||
			!user.username.trim()
		) {
			return null;
		}

		return { id: faceRegistryId, name: user.username.trim() };
	}
};
