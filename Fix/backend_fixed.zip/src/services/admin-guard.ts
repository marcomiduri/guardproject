import { count, eq } from 'drizzle-orm';

import { db } from '@/db/index.js';
import { users } from '@/db/schema/auth.js';
import { badRequest } from '@/services/errors.js';

async function assertNotLastAdminAccount(action: 'remove' | 'delete'): Promise<void> {
	const [row] = await db.select({ total: count() }).from(users).where(eq(users.role, 'admin'));
	if ((row?.total ?? 0) <= 1) {
		throw badRequest(
			action === 'delete'
				? 'Cannot delete the last admin account'
				: 'Cannot remove the last admin account'
		);
	}
}

export async function assertCanDemoteAdmin(currentRole: string, nextRole: string): Promise<void> {
	if (currentRole === 'admin' && nextRole !== 'admin') {
		await assertNotLastAdminAccount('remove');
	}
}

export async function assertCanDeleteAdmin(role: string): Promise<void> {
	if (role === 'admin') {
		await assertNotLastAdminAccount('delete');
	}
}
