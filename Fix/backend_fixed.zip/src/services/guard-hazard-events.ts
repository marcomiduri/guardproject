import { randomUUID } from 'node:crypto';
import { alias } from 'drizzle-orm/pg-core';
import { and, asc, desc, eq, gte, ilike, lte, or, sql, type SQL } from 'drizzle-orm';
import { db } from '@/db/index.js';
import { users } from '@/db/schema/auth.js';
import {
	GUARD_HAZARD_TYPES,
	GUARD_SAFETY_EVENT_STATUSES,
	guardCameras,
	guardHazardEvents,
	guardRooms,
	type GuardHazardDetection,
	type GuardHazardType,
	type GuardSafetyEventSource,
	type GuardSafetyEventStatus
} from '@/db/schema/guard.js';
import { ACTIVE_HAZARD_WINDOW_MS, DEFAULT_SAFETY_EVENT_COOLDOWN_MS } from '@/constants/guard.js';
import { buildPagination, type PaginatedListData } from '@/http/responses.js';
import { collectColumnFilterConditions } from '@/lib/db/column-filters.js';
import { clampListPagination } from '@/lib/db/pagination.js';
import { badRequest, notFound } from '@/services/errors.js';
import { formatCameraDisplayLabel } from '@/services/guard-camera-snapshot.js';
import { guardCamerasService } from '@/services/guard-cameras.js';
import { realtimeHub } from '@/services/realtime-hub.js';
import { safetyEventImagesService } from '@/services/safety-event-images.js';
import { serializeHazardDetectedEvent } from '@/types/guard-events.js';
import type {
	ListSafetyEventsOptions,
	SafetyEventsColumnFilter,
	SafetyEventsListSortField
} from '@/types/safety-events-list.js';
import type { ColumnFilterComparator } from '@/types/list-query.js';
import { logger } from '@/utils/logger.js';

function safetyEventCooldownMs(): number {
	const parsed = Number.parseInt(process.env.SAFETY_EVENT_COOLDOWN_MS ?? '', 10);
	if (!Number.isFinite(parsed) || parsed < 10_000) {
		return DEFAULT_SAFETY_EVENT_COOLDOWN_MS;
	}

	return parsed;
}

export type RecordSafetyEventInput = {
	eventId?: string;
	cameraId: string;
	hazardType: GuardHazardType;
	confidence?: number;
	detections?: GuardHazardDetection[];
	occurredAt?: Date;
	source?: GuardSafetyEventSource;
	testScenario?: string;
	snapshotBuffer?: Buffer;
	snapshotMimeType?: string;
	installationId?: string;
	roomId?: string;
};

export type SafetyEventRecord = {
	id: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	hazardType: GuardHazardType;
	confidence: number | null;
	detections: GuardHazardDetection[] | null;
	status: GuardSafetyEventStatus;
	source: GuardSafetyEventSource;
	testScenario: string | null;
	snapshotUrl: string | null;
	snapshotWidth: number | null;
	snapshotHeight: number | null;
	snapshotSizeBytes: number | null;
	occurredAt: Date;
	createdAt: Date;
	acknowledgedAt: Date | null;
	acknowledgedBy: string | null;
	acknowledgedByName: string | null;
	resolvedAt: Date | null;
	resolvedBy: string | null;
	resolvedByName: string | null;
	idempotent?: boolean;
};

export type PaginatedSafetyEventsList = PaginatedListData<SafetyEventRecord>;

const HAZARD_TYPE_LABELS: Record<GuardHazardType, string> = {
	fire: 'Fire',
	smoke: 'Smoke',
	flame: 'Flame',
	unknown: 'Unknown'
};

const STATUS_LABELS: Record<GuardSafetyEventStatus, string> = {
	NEW: 'New',
	ACKNOWLEDGED: 'Acknowledged',
	RESOLVED: 'Resolved',
	FALSE_ALARM: 'False Alarm'
};

const cameraNameExpr = sql<string>`coalesce(nullif(trim(${guardCameras.name}), ''), nullif(trim(${guardCameras.deviceAddress}), ''), ${guardHazardEvents.cameraId})`;

const acknowledgedByUser = alias(users, 'acknowledged_by_user');
const resolvedByUser = alias(users, 'resolved_by_user');

type SafetyEventRow = {
	id: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string | null;
	cameraAddress: string | null;
	hazardType: string;
	confidence: number | null;
	detections: GuardHazardDetection[] | null;
	status: string;
	source: string;
	testScenario: string | null;
	hasSnapshotImage: boolean;
	snapshotPath: string | null;
	snapshotWidth: number | null;
	snapshotHeight: number | null;
	snapshotSizeBytes: number | null;
	occurredAt: Date;
	createdAt: Date;
	acknowledgedAt: Date | null;
	acknowledgedBy: string | null;
	acknowledgedByName: string | null;
	resolvedAt: Date | null;
	resolvedBy: string | null;
	resolvedByName: string | null;
};

function hazardTypeMatchesLabel(hazardType: string, needle: string): boolean {
	const label = HAZARD_TYPE_LABELS[hazardType as GuardHazardType] ?? hazardType;
	return (
		label.toLowerCase().includes(needle.toLowerCase()) ||
		hazardType.toLowerCase().includes(needle.toLowerCase())
	);
}

function statusMatchesLabel(status: string, needle: string): boolean {
	const label = STATUS_LABELS[status as GuardSafetyEventStatus] ?? status;
	return (
		label.toLowerCase().includes(needle.toLowerCase()) ||
		status.toLowerCase().includes(needle.toLowerCase())
	);
}

function resolveHazardTypeFilterValue(value: string): string {
	const trimmed = value.trim().toLowerCase();

	for (const hazardType of GUARD_HAZARD_TYPES) {
		if (trimmed === hazardType) return hazardType;
		if (HAZARD_TYPE_LABELS[hazardType].toLowerCase() === trimmed) return hazardType;
	}

	return value.trim();
}

function resolveStatusFilterValue(value: string): string | undefined {
	const trimmed = value.trim().toLowerCase();

	for (const status of GUARD_SAFETY_EVENT_STATUSES) {
		if (trimmed === status.toLowerCase()) return status;
		if (trimmed === status.replace('_', ' ').toLowerCase()) return status;
		if (STATUS_LABELS[status].toLowerCase() === trimmed) return status;
	}

	return undefined;
}

function buildSearchCondition(search: string | undefined): SQL | undefined {
	const trimmed = search?.trim();
	if (!trimmed) return undefined;

	const term = `%${trimmed}%`;
	const parts: SQL[] = [
		ilike(guardRooms.name, term),
		ilike(guardCameras.name, term),
		ilike(guardCameras.deviceAddress, term),
		ilike(cameraNameExpr, term),
		ilike(guardHazardEvents.hazardType, term),
		ilike(guardHazardEvents.status, term),
		ilike(guardHazardEvents.source, term),
		ilike(sql`${guardHazardEvents.confidence}::text`, term),
		ilike(sql`${guardHazardEvents.occurredAt}::text`, term)
	];

	for (const hazardType of GUARD_HAZARD_TYPES) {
		if (hazardTypeMatchesLabel(hazardType, trimmed)) {
			parts.push(eq(guardHazardEvents.hazardType, hazardType));
		}
	}

	for (const status of GUARD_SAFETY_EVENT_STATUSES) {
		if (statusMatchesLabel(status, trimmed)) {
			parts.push(eq(guardHazardEvents.status, status));
		}
	}

	return or(...parts);
}

function buildHazardTypeFilterCondition(
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const text = resolveHazardTypeFilterValue(String(value));

	if (comparator === 'eq') {
		if (GUARD_HAZARD_TYPES.includes(text as GuardHazardType)) {
			return eq(guardHazardEvents.hazardType, text);
		}
		return undefined;
	}

	if (comparator === 'contains') {
		const lower = text.toLowerCase();
		const matches = GUARD_HAZARD_TYPES.filter((hazardType) =>
			hazardTypeMatchesLabel(hazardType, lower)
		);
		if (matches.length > 0) {
			return or(...matches.map((hazardType) => eq(guardHazardEvents.hazardType, hazardType)));
		}
		return ilike(guardHazardEvents.hazardType, `%${text}%`);
	}

	return undefined;
}

function buildStatusFilterCondition(
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const text = String(value);

	if (comparator === 'eq') {
		const resolved = resolveStatusFilterValue(text);
		if (!resolved) return undefined;
		return eq(guardHazardEvents.status, resolved);
	}

	if (comparator === 'contains') {
		const lower = text.trim().toLowerCase();
		const matches = GUARD_SAFETY_EVENT_STATUSES.filter((status) =>
			statusMatchesLabel(status, lower)
		);
		if (matches.length > 0) {
			return or(...matches.map((status) => eq(guardHazardEvents.status, status)));
		}
		return ilike(guardHazardEvents.status, `%${text}%`);
	}

	return undefined;
}

/** Column filter values are percentages (0–100), matching the UI display. Stored values are 0–1. */
function buildConfidenceFilterCondition(
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const percent = Number(value);
	if (!Number.isFinite(percent)) return undefined;

	const decimal = percent / 100;

	if (comparator === 'eq') {
		const roundedPercent = Math.round(percent * 10) / 10;
		return sql`round((${guardHazardEvents.confidence} * 100)::numeric, 1) = ${roundedPercent}`;
	}

	if (comparator === 'gte') return gte(guardHazardEvents.confidence, decimal);
	if (comparator === 'lte') return lte(guardHazardEvents.confidence, decimal);

	return undefined;
}

function buildColumnFilterCondition(filter: SafetyEventsColumnFilter): SQL | undefined {
	const { column, comparator, value } = filter;

	switch (column) {
		case 'hazardType':
			return buildHazardTypeFilterCondition(comparator, value);

		case 'roomName': {
			const text = String(value);
			if (comparator === 'eq') return eq(guardRooms.name, text);
			if (comparator === 'contains') return ilike(guardRooms.name, `%${text}%`);
			break;
		}

		case 'cameraName': {
			const text = String(value);
			if (comparator === 'eq') return eq(cameraNameExpr, text);
			if (comparator === 'contains') {
				return or(
					ilike(guardCameras.name, `%${text}%`),
					ilike(guardCameras.deviceAddress, `%${text}%`),
					ilike(cameraNameExpr, `%${text}%`)
				);
			}
			break;
		}

		case 'confidence':
			return buildConfidenceFilterCondition(comparator, value);

		case 'status':
			return buildStatusFilterCondition(comparator, value);

		case 'occurredAt': {
			const text = String(value);
			const expr = sql`${guardHazardEvents.occurredAt}::text`;
			if (comparator === 'eq') return sql`${expr} = ${text}`;
			if (comparator === 'contains') return ilike(expr, `%${text}%`);
			break;
		}
	}

	return undefined;
}

function buildWhereClause(options: ListSafetyEventsOptions): SQL | undefined {
	const conditions: SQL[] = [];

	const searchCondition = buildSearchCondition(options.search);
	if (searchCondition) conditions.push(searchCondition);

	conditions.push(
		...collectColumnFilterConditions(options.columnFilters, buildColumnFilterCondition)
	);

	return conditions.length ? and(...conditions) : undefined;
}

function safetyEventSelectFields() {
	return {
		id: guardHazardEvents.id,
		roomId: guardHazardEvents.roomId,
		roomName: guardRooms.name,
		cameraId: guardHazardEvents.cameraId,
		cameraName: guardCameras.name,
		cameraAddress: guardCameras.deviceAddress,
		hazardType: guardHazardEvents.hazardType,
		confidence: guardHazardEvents.confidence,
		detections: guardHazardEvents.detections,
		status: guardHazardEvents.status,
		source: guardHazardEvents.source,
		testScenario: guardHazardEvents.testScenario,
		hasSnapshotImage: guardHazardEvents.hasSnapshotImage,
		snapshotPath: guardHazardEvents.snapshotPath,
		snapshotWidth: guardHazardEvents.snapshotWidth,
		snapshotHeight: guardHazardEvents.snapshotHeight,
		snapshotSizeBytes: guardHazardEvents.snapshotSizeBytes,
		occurredAt: guardHazardEvents.occurredAt,
		createdAt: guardHazardEvents.createdAt,
		acknowledgedAt: guardHazardEvents.acknowledgedAt,
		acknowledgedBy: guardHazardEvents.acknowledgedBy,
		acknowledgedByName: acknowledgedByUser.username,
		resolvedAt: guardHazardEvents.resolvedAt,
		resolvedBy: guardHazardEvents.resolvedBy,
		resolvedByName: resolvedByUser.username
	};
}

function selectSafetyEvents() {
	return db
		.select(safetyEventSelectFields())
		.from(guardHazardEvents)
		.innerJoin(guardRooms, eq(guardHazardEvents.roomId, guardRooms.id))
		.leftJoin(guardCameras, eq(guardHazardEvents.cameraId, guardCameras.id))
		.leftJoin(acknowledgedByUser, eq(guardHazardEvents.acknowledgedBy, acknowledgedByUser.id))
		.leftJoin(resolvedByUser, eq(guardHazardEvents.resolvedBy, resolvedByUser.id));
}

function mapSafetyEventRow(row: SafetyEventRow): SafetyEventRecord {
	const cameraLabel = formatCameraDisplayLabel(
		{
			name: row.cameraName ?? '',
			deviceAddress: row.cameraAddress ?? ''
		},
		row.cameraId
	);

	return {
		id: row.id,
		roomId: row.roomId,
		roomName: row.roomName,
		cameraId: row.cameraId,
		cameraName: cameraLabel,
		hazardType: row.hazardType as GuardHazardType,
		confidence: row.confidence,
		detections: row.detections,
		status: row.status as GuardSafetyEventStatus,
		source: row.source as GuardSafetyEventSource,
		testScenario: row.testScenario,
		snapshotUrl:
			row.hasSnapshotImage && safetyEventImagesService.snapshotExists(row.snapshotPath)
				? safetyEventImagesService.buildSnapshotUrl(row.id)
				: null,
		snapshotWidth: row.snapshotWidth,
		snapshotHeight: row.snapshotHeight,
		snapshotSizeBytes: row.snapshotSizeBytes,
		occurredAt: row.occurredAt,
		createdAt: row.createdAt,
		acknowledgedAt: row.acknowledgedAt,
		acknowledgedBy: row.acknowledgedBy,
		acknowledgedByName: row.acknowledgedByName,
		resolvedAt: row.resolvedAt,
		resolvedBy: row.resolvedBy,
		resolvedByName: row.resolvedByName
	};
}

async function findCameraOrThrow(cameraId: string, installationId?: string, roomId?: string) {
	const camera = await guardCamerasService.getById(
		cameraId,
		installationId || roomId ? { installationId, roomId } : undefined
	);

	const [room] = await db
		.select()
		.from(guardRooms)
		.where(eq(guardRooms.id, camera.roomId))
		.limit(1);
	if (!room) throw badRequest('Room not found');

	return { camera, room };
}

async function isWithinCooldown(cameraId: string, hazardType: GuardHazardType): Promise<boolean> {
	const cutoff = new Date(Date.now() - safetyEventCooldownMs());
	const [recent] = await db
		.select({ id: guardHazardEvents.id })
		.from(guardHazardEvents)
		.where(
			and(
				eq(guardHazardEvents.cameraId, cameraId),
				eq(guardHazardEvents.hazardType, hazardType),
				eq(guardHazardEvents.status, 'NEW'),
				gte(guardHazardEvents.occurredAt, cutoff)
			)
		)
		.orderBy(desc(guardHazardEvents.occurredAt))
		.limit(1);

	return Boolean(recent);
}

function hazardStatusForRealtime(status: GuardSafetyEventStatus): string {
	switch (status) {
		case 'NEW':
			return 'active';
		case 'ACKNOWLEDGED':
			return 'acknowledged';
		case 'RESOLVED':
			return 'resolved';
		case 'FALSE_ALARM':
			return 'false_alarm';
	}
}

function publishHazardStatusUpdate(
	record: SafetyEventRecord,
	userId: string,
	updatedAt: Date
): void {
	const wireStatus = hazardStatusForRealtime(record.status);
	realtimeHub.publishHazardUpdated({
		id: record.id,
		eventId: record.id,
		roomId: record.roomId,
		status: wireStatus,
		updatedAt: updatedAt.toISOString(),
		updatedBy: userId
	});
}

export const guardHazardEventsService = {
	safetyEventCooldownMs,

	async listActiveAlerts(): Promise<SafetyEventRecord[]> {
		const cutoff = new Date(Date.now() - ACTIVE_HAZARD_WINDOW_MS);

		const rows = await selectSafetyEvents()
			.where(and(eq(guardHazardEvents.status, 'NEW'), gte(guardHazardEvents.occurredAt, cutoff)))
			.orderBy(desc(guardHazardEvents.occurredAt));

		const latestByRoom = new Map<string, SafetyEventRecord>();

		for (const row of rows) {
			if (latestByRoom.has(row.roomId)) {
				continue;
			}

			latestByRoom.set(row.roomId, mapSafetyEventRow(row));
		}

		return [...latestByRoom.values()];
	},

	async list(options: ListSafetyEventsOptions = {}): Promise<PaginatedSafetyEventsList> {
		const { limit, offset } = clampListPagination(options);
		const sortOrder = options.sortOrder ?? 'desc';
		const whereClause = buildWhereClause(options);

		const countQuery = db
			.select({ count: sql<number>`count(*)` })
			.from(guardHazardEvents)
			.innerJoin(guardRooms, eq(guardHazardEvents.roomId, guardRooms.id))
			.leftJoin(guardCameras, eq(guardHazardEvents.cameraId, guardCameras.id));

		const countResult = whereClause ? await countQuery.where(whereClause) : await countQuery;
		const total = Number(countResult[0]?.count ?? 0);

		const sortColumnMap: Record<SafetyEventsListSortField, SQL> = {
			hazardType: sql`${guardHazardEvents.hazardType}`,
			roomName: sql`${guardRooms.name}`,
			cameraName: cameraNameExpr,
			confidence: sql`${guardHazardEvents.confidence}`,
			status: sql`${guardHazardEvents.status}`,
			occurredAt: sql`${guardHazardEvents.occurredAt}`,
			createdAt: sql`${guardHazardEvents.createdAt}`
		};

		const sortCol = options.sortBy ? sortColumnMap[options.sortBy] : sortColumnMap.occurredAt;
		const sortDirection = sortOrder === 'asc' ? sql`ASC` : sql`DESC`;

		const itemsQuery = selectSafetyEvents()
			.orderBy(sql`${sortCol} ${sortDirection} NULLS LAST`, asc(guardHazardEvents.id))
			.limit(limit)
			.offset(offset);

		const rows = whereClause ? await itemsQuery.where(whereClause) : await itemsQuery;

		return {
			items: rows.map((row) => mapSafetyEventRow(row)),
			pagination: buildPagination({
				total,
				limit,
				offset,
				itemCount: rows.length
			})
		};
	},

	async getById(id: string): Promise<SafetyEventRecord> {
		const [row] = await selectSafetyEvents().where(eq(guardHazardEvents.id, id)).limit(1);

		if (!row) {
			throw notFound('Safety event not found');
		}

		return mapSafetyEventRow(row);
	},

	async readSnapshot(eventId: string): Promise<{ buffer: Buffer; mimeType: string }> {
		const event = await this.getById(eventId);
		if (!event.snapshotUrl) {
			throw notFound('Snapshot not found');
		}

		const [row] = await db
			.select({ snapshotPath: guardHazardEvents.snapshotPath })
			.from(guardHazardEvents)
			.where(eq(guardHazardEvents.id, eventId))
			.limit(1);

		const snapshotPath = row?.snapshotPath?.trim() || null;
		if (!snapshotPath || !safetyEventImagesService.snapshotExists(snapshotPath)) {
			if (snapshotPath) {
				await db
					.update(guardHazardEvents)
					.set({
						hasSnapshotImage: false,
						snapshotPath: null,
						snapshotWidth: null,
						snapshotHeight: null,
						snapshotSizeBytes: null
					})
					.where(eq(guardHazardEvents.id, eventId));
			}

			throw notFound('Snapshot not found');
		}

		const buffer = await safetyEventImagesService.readSnapshot(snapshotPath);
		return { buffer, mimeType: 'image/jpeg' };
	},

	async recordDetected(input: RecordSafetyEventInput): Promise<SafetyEventRecord> {
		const id = input.eventId?.trim() || randomUUID();

		const [duplicate] = await selectSafetyEvents().where(eq(guardHazardEvents.id, id)).limit(1);
		if (duplicate) return { ...mapSafetyEventRow(duplicate), idempotent: true };

		if (await isWithinCooldown(input.cameraId, input.hazardType)) {
			throw badRequest('Safety event cooldown active for this camera and hazard type');
		}

		const { camera, room } = await findCameraOrThrow(
			input.cameraId,
			input.installationId,
			input.roomId
		);
		const occurredAt = input.occurredAt ?? new Date();
		const source = input.source ?? 'GUARD';
		const createdAt = new Date();

		const inserted = await db
			.insert(guardHazardEvents)
			.values({
				id,
				roomId: camera.roomId,
				cameraId: input.cameraId,
				hazardType: input.hazardType,
				confidence: input.confidence ?? null,
				detections: input.detections?.length ? input.detections : null,
				status: 'NEW',
				source,
				testScenario: input.testScenario?.trim() || null,
				hasSnapshotImage: false,
				occurredAt,
				createdAt
			})
			.onConflictDoNothing({ target: guardHazardEvents.id })
			.returning({ id: guardHazardEvents.id });

		if (inserted.length === 0) {
			const [existing] = await selectSafetyEvents().where(eq(guardHazardEvents.id, id)).limit(1);
			if (!existing) throw badRequest('Duplicate hazard event could not be loaded');
			return { ...mapSafetyEventRow(existing), idempotent: true };
		}

		let snapshotPath: string | null = null;
		let snapshotWidth: number | null = null;
		let snapshotHeight: number | null = null;
		let snapshotSizeBytes: number | null = null;
		let hasSnapshotImage = false;

		if (input.snapshotBuffer && input.snapshotMimeType) {
			try {
				const written = await safetyEventImagesService.writeSnapshot({
					eventId: id,
					cameraId: input.cameraId,
					hazardType: input.hazardType,
					occurredAt,
					buffer: input.snapshotBuffer,
					mimeType: input.snapshotMimeType
				});

				snapshotPath = written.relativePath;
				snapshotWidth = written.width;
				snapshotHeight = written.height;
				snapshotSizeBytes = written.sizeBytes;
				hasSnapshotImage = true;
				await db
					.update(guardHazardEvents)
					.set({
						hasSnapshotImage,
						snapshotPath,
						snapshotWidth,
						snapshotHeight,
						snapshotSizeBytes
					})
					.where(eq(guardHazardEvents.id, id));
			} catch (error) {
				logger.error('[guard-hazard-events] invalid snapshot, event stored without image', error);
				if (snapshotPath)
					await safetyEventImagesService.deleteSnapshot(snapshotPath).catch(() => undefined);
				snapshotPath = null;
				snapshotWidth = null;
				snapshotHeight = null;
				snapshotSizeBytes = null;
				hasSnapshotImage = false;
			}
		}

		const event = mapSafetyEventRow({
			id,
			roomId: camera.roomId,
			roomName: room.name,
			cameraId: input.cameraId,
			cameraName: camera.name,
			cameraAddress: camera.deviceAddress,
			hazardType: input.hazardType,
			confidence: input.confidence ?? null,
			detections: input.detections?.length ? input.detections : null,
			status: 'NEW',
			source,
			testScenario: input.testScenario?.trim() || null,
			hasSnapshotImage,
			snapshotPath,
			snapshotWidth,
			snapshotHeight,
			snapshotSizeBytes,
			occurredAt,
			createdAt,
			acknowledgedAt: null,
			acknowledgedBy: null,
			acknowledgedByName: null,
			resolvedAt: null,
			resolvedBy: null,
			resolvedByName: null
		});

		realtimeHub.publishHazardDetected(serializeHazardDetectedEvent(event));
		return event;
	},

	async acknowledge(id: string, userId: string): Promise<SafetyEventRecord> {
		const updatedAt = new Date();
		const [updated] = await db
			.update(guardHazardEvents)
			.set({
				status: 'ACKNOWLEDGED',
				acknowledgedAt: updatedAt,
				acknowledgedBy: userId
			})
			.where(eq(guardHazardEvents.id, id))
			.returning({ id: guardHazardEvents.id });

		if (!updated) {
			throw notFound('Safety event not found');
		}

		const event = await this.getById(id);
		publishHazardStatusUpdate(event, userId, updatedAt);
		return event;
	},

	async resolve(id: string, userId: string): Promise<SafetyEventRecord> {
		const updatedAt = new Date();
		const [updated] = await db
			.update(guardHazardEvents)
			.set({
				status: 'RESOLVED',
				resolvedAt: updatedAt,
				resolvedBy: userId
			})
			.where(eq(guardHazardEvents.id, id))
			.returning({ id: guardHazardEvents.id });

		if (!updated) {
			throw notFound('Safety event not found');
		}

		const event = await this.getById(id);
		publishHazardStatusUpdate(event, userId, updatedAt);
		return event;
	},

	async markFalseAlarm(id: string, userId: string): Promise<SafetyEventRecord> {
		const updatedAt = new Date();
		const [updated] = await db
			.update(guardHazardEvents)
			.set({
				status: 'FALSE_ALARM',
				resolvedAt: updatedAt,
				resolvedBy: userId
			})
			.where(eq(guardHazardEvents.id, id))
			.returning({ id: guardHazardEvents.id });

		if (!updated) {
			throw notFound('Safety event not found');
		}

		const event = await this.getById(id);
		publishHazardStatusUpdate(event, userId, updatedAt);
		return event;
	}
};
