import type { WebSocket } from 'ws';

export type GuardNotificationSettingsUpdatedMessage = {
	type: 'notification_settings.updated';
	version: string;
	changedKeys?: string[];
};

export type GuardFaceRegistryUpdatedMessage = {
	type: 'face_registry.updated';
	version: string;
	scope: string;
	updatedAt: string;
};

export type GuardRealtimeMessage =
	| GuardNotificationSettingsUpdatedMessage
	| GuardFaceRegistryUpdatedMessage;

type GuardClient = {
	ws: WebSocket;
	installationId: string;
	roomId: string;
	connectedAt: Date;
};

class GuardRealtimeHub {
	private readonly clientsBySocket = new Map<WebSocket, GuardClient>();

	addClient(client: { ws: WebSocket; installationId: string; roomId: string }): void {
		this.clientsBySocket.set(client.ws, { ...client, connectedAt: new Date() });
	}

	removeClient(ws: WebSocket): void {
		this.clientsBySocket.delete(ws);
	}

	publishNotificationSettingsUpdated(input: { version: string; changedKeys?: string[] }): number {
		return this.broadcast({
			type: 'notification_settings.updated',
			version: input.version,
			...(input.changedKeys?.length ? { changedKeys: input.changedKeys } : {})
		});
	}

	publishFaceRegistryUpdated(input: {
		version: string;
		scope: string;
		updatedAt: string;
		roomIds?: string[];
	}): number {
		const roomIds = input.roomIds?.length ? new Set(input.roomIds) : undefined;
		return this.broadcast(
			{
				type: 'face_registry.updated',
				version: input.version,
				scope: input.scope,
				updatedAt: input.updatedAt
			},
			(client) => !roomIds || roomIds.has(client.roomId)
		);
	}

	private broadcast(
		message: GuardRealtimeMessage,
		predicate?: (client: GuardClient) => boolean
	): number {
		const payload = JSON.stringify(message);
		let sent = 0;

		for (const client of this.clientsBySocket.values()) {
			if (predicate && !predicate(client)) continue;
			if (client.ws.readyState !== client.ws.OPEN) {
				this.removeClient(client.ws);
				continue;
			}

			try {
				client.ws.send(payload);
				sent++;
			} catch {
				this.removeClient(client.ws);
			}
		}

		return sent;
	}
}

export const guardRealtimeHub = new GuardRealtimeHub();
