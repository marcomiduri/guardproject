export function isPrivilegedGuardOperatorRole(role: string | null | undefined): boolean {
	const normalized = role?.trim().toLowerCase();
	return normalized === 'admin' || normalized === 'staff';
}

export function resolveRecognizedFaceApproval(input: {
	direction: 'in' | 'out';
	userRole: string | null | undefined;
	hasApprovedRoomOrder: boolean;
}): boolean | null {
	if (input.direction === 'out') return null;
	return isPrivilegedGuardOperatorRole(input.userRole) || input.hasApprovedRoomOrder;
}
