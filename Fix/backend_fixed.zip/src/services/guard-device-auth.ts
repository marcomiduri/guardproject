import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { env } from '@/config/env.js';
import { normalizeGuardHardwareId } from '@/services/guard-hardware-id.js';

const ACTIVATION_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function sha256Hex(value: string): string {
	return createHash('sha256').update(value, 'utf8').digest('hex');
}

function hmacHex(secret: string, value: string): string {
	return createHmac('sha256', secret).update(value, 'utf8').digest('hex');
}

export function normalizeActivationCode(value: string): string {
	return value
		.toUpperCase()
		.split('')
		.filter((character) => /[A-Z0-9]/.test(character))
		.join('');
}

export function formatActivationCode(normalized: string): string {
	const parts: string[] = [];
	for (let i = 0; i < normalized.length; i += 4) parts.push(normalized.slice(i, i + 4));
	return parts.join('-');
}

export function generateActivationCode(length = 12): string {
	let normalized = '';
	while (normalized.length < length) {
		const bytes = randomBytes(length);
		for (const byte of bytes) {
			normalized += ACTIVATION_ALPHABET[byte % ACTIVATION_ALPHABET.length];
			if (normalized.length >= length) break;
		}
	}
	return formatActivationCode(normalized);
}

export function hashActivationCode(code: string): string {
	const normalized = normalizeActivationCode(code);
	return hmacHex(env.GUARD_ACTIVATION_CODE_PEPPER, `guard-activation:${normalized}`);
}

const HARDWARE_ID_HASH_V1_PATTERN = /^v1:[a-f0-9]{64}$/;

export function hashHardwareId(hardwareId: string): string {
	const normalized = normalizeGuardHardwareId(hardwareId);
	return `v1:${sha256Hex(normalized)}`;
}

export function legacyHashHardwareId(hardwareId: string): string {
	const normalized = normalizeGuardHardwareId(hardwareId);
	return sha256Hex(`guard-hardware:${normalized}`);
}

export function hardwareIdHashFormatValid(value: string): boolean {
	return HARDWARE_ID_HASH_V1_PATTERN.test(value.trim());
}

export function generateDeviceToken(): string {
	return randomBytes(32).toString('base64url');
}

export function deriveRotatedDeviceToken(
	installationId: string,
	currentDeviceToken: string
): string {
	return createHmac('sha256', env.GUARD_DEVICE_TOKEN_PEPPER)
		.update(`guard-device-rotate:${installationId}:${currentDeviceToken.trim()}`, 'utf8')
		.digest('base64url');
}

export function hashDeviceToken(token: string): string {
	return hmacHex(env.GUARD_DEVICE_TOKEN_PEPPER, `guard-device:${token.trim()}`);
}

export function constantTimeHashEquals(left: string | null | undefined, right: string): boolean {
	if (!left) return false;
	const leftBuffer = Buffer.from(left, 'utf8');
	const rightBuffer = Buffer.from(right, 'utf8');
	if (leftBuffer.length !== rightBuffer.length) return false;
	return timingSafeEqual(leftBuffer, rightBuffer);
}
