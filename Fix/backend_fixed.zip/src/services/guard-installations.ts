import { randomUUID } from 'node:crypto';
import { and, asc, desc, eq, ilike, or, sql } from 'drizzle-orm';
import { db } from '@/db/index.js';
import {
	guardCameras,
	guardInstallations,
	guardInstallationRoomAssignments,
	guardRoomActivationCodes,
	guardRooms,
	type GuardCamera,
	type GuardInstallation
} from '@/db/schema/guard.js';
import {
	constantTimeHashEquals,
	generateDeviceToken,
	generateActivationCode,
	hashActivationCode,
	hashDeviceToken,
	hashHardwareId,
	legacyHashHardwareId
} from '@/services/guard-device-auth.js';
import {
	GUARD_ACCESS_TOKEN_EXPIRES_IN_SECONDS,
	signGuardAccessToken
} from '@/services/guard-jwt.js';
import { badRequest, domainError, forbidden, notFound, unauthorized } from '@/services/errors.js';
import type {
	ActivateGuardInstallationInput,
	ConnectGuardInstallationInput,
	CreateRoomActivationCodeInput,
	ExchangeGuardDeviceTokenInput
} from '@/validators/guard-installations.js';

type GuardRoom = typeof guardRooms.$inferSelect;
type GuardTransaction = Parameters<Parameters<typeof db.transaction>[0]>[0];

const GUARD_SCOPES = [
	'rooms:read',
	'cameras:read',
	'cameras:write',
	'cameras:heartbeat',
	'events:write',
	'faces:read',
	'settings:read',
	'installation:manage'
] as const;

export type GuardTokenResponse = {
	accessToken: string;
	expiresAt: string;
	serverTime: string;
};

export type GuardConnectResponse = {
	installationId: string;
	room: { id: string; name: string };
	deviceCredential?: string;
	cameras: Array<{
		clientCameraId: string;
		backendCameraId: string;
		name: string;
		direction: string;
	}>;
	connectionState: 'connected';
	serverTime: string;
};

export type GuardAvailableRoomsResponse = {
	rooms: Array<{ id: string; name: string }>;
	serverTime: string;
};

export type GuardSessionResponse = {
	installationId: string;
	guardInstanceId: string;
	deviceName: string;
	room: { id: string; name: string };
	deviceToken?: string;
	deviceCredential?: string;
	accessToken: string;
	expiresIn: number;
	expiresAt: string;
	serverTime: string;
	cameras: Array<{
		clientCameraId: string;
		backendCameraId: string;
		cameraId: string;
		id: string;
	}>;
};

export type GuardInstallationAdminRecord = {
	id: string;
	roomId: string;
	currentRoomId: string;
	deviceName: string;
	status: string;
	applicationVersion: string | null;
	registeredAt: Date;
	lastSeenAt: Date;
	revokedAt: Date | null;
	connectedAt: Date;
	disconnectedAt: Date | null;
	isCurrentAssignment: boolean;
};

export type ActivationCodeRecord = {
	id: string;
	roomId: string;
	code?: string;
	expiresAt: Date;
	maxUses: number;
	usedCount: number;
	usedAt: Date | null;
	usedByInstallationId: string | null;
	createdAt: Date;
	revokedAt: Date | null;
};

async function resolveRoom(identifier: string): Promise<GuardRoom> {
	const trimmed = identifier.trim();
	const [byId] = await db.select().from(guardRooms).where(eq(guardRooms.id, trimmed)).limit(1);
	if (byId) return byId;
	const byName = await db.select().from(guardRooms).where(ilike(guardRooms.name, trimmed)).limit(2);
	if (byName.length === 0) throw notFound('Room not found');
	if (byName.length > 1) throw badRequest('Room name is ambiguous; use the room ID');
	return byName[0];
}

async function getRoomById(roomId: string): Promise<GuardRoom> {
	const [room] = await db.select().from(guardRooms).where(eq(guardRooms.id, roomId)).limit(1);
	if (!room) throw notFound('Room not found');
	return room;
}

function revokedInstallationValues(now: Date) {
	return {
		status: 'revoked' as const,
		revokedAt: now,
		previousDeviceTokenHash: null,
		lastSeenAt: now,
		updatedAt: now
	};
}

function disconnectedInstallationValues(now: Date) {
	// A normal room disconnect is not a security revocation. Keep the long-lived
	// credential so the same Guard installation can reconnect without admin
	// recovery. Only explicit revoke/rotate operations invalidate credentials.
	return {
		status: 'disconnected' as const,
		revokedAt: null,
		lastSeenAt: now,
		updatedAt: now
	};
}

function reactivatedInstallationValues(
	input: ActivateGuardInstallationInput,
	roomId: string,
	deviceTokenHash: string,
	now: Date,
	existing?: GuardInstallation
) {
	return {
		roomId,
		deviceName: input.deviceName.trim(),
		status: 'active' as const,
		revokedAt: null,
		applicationVersion: input.applicationVersion?.trim() || existing?.applicationVersion || null,
		deviceTokenHash,
		previousDeviceTokenHash: null,
		deviceTokenIssuedAt: now,
		deviceTokenRotatedAt: null,
		lastSeenAt: now,
		updatedAt: now
	};
}

function mapConnectCameras(cameras: GuardCamera[]) {
	return cameras.map((camera) => ({
		clientCameraId: camera.clientCameraId ?? '',
		backendCameraId: camera.id,
		name: camera.name,
		direction: camera.direction
	}));
}

async function listRoomCameras(tx: GuardTransaction, roomId: string): Promise<GuardCamera[]> {
	return tx
		.select()
		.from(guardCameras)
		.where(eq(guardCameras.roomId, roomId))
		.orderBy(asc(guardCameras.sortOrder), asc(guardCameras.createdAt));
}

/** Bind room cameras (admin-created or reclaimable) to the connecting Guard installation. */
async function claimRoomCamerasForInstallation(
	tx: GuardTransaction,
	installationId: string,
	roomId: string,
	now: Date,
	allowLegacyOwnerReclaim = false
): Promise<void> {
	const roomCameras = await listRoomCameras(tx, roomId);
	for (const camera of roomCameras) {
		if (camera.installationId === installationId) {
			continue;
		}
		if (camera.installationId) {
			const owner = await getInstallationOwnership(tx, camera.installationId);
			if (!canReclaimCameraFromInstallation(owner, allowLegacyOwnerReclaim)) {
				continue;
			}
		}
		await tx
			.update(guardCameras)
			.set({ installationId, updatedAt: now })
			.where(eq(guardCameras.id, camera.id));
	}
}

function buildConnectResponse(
	installation: GuardInstallation,
	room: GuardRoom,
	cameras: GuardCamera[],
	deviceCredential?: string
): GuardConnectResponse {
	const now = new Date();
	return {
		installationId: installation.id,
		room: { id: room.id, name: room.name },
		...(deviceCredential ? { deviceCredential } : {}),
		cameras: mapConnectCameras(cameras),
		connectionState: 'connected',
		serverTime: now.toISOString()
	};
}

type ConnectHardwareHashes = {
	hardwareIdHash: string;
	legacyHardwareIdHash: string;
};

type ResolvedConnectInstallation = {
	installation: GuardInstallation;
	resolvedByHardware: boolean;
	hardwareIdHash?: string;
};

function hardwareHashesForConnect(
	input: ConnectGuardInstallationInput
): ConnectHardwareHashes | undefined {
	if (!input.hardwareId) return undefined;
	return {
		hardwareIdHash: hashHardwareId(input.hardwareId),
		legacyHardwareIdHash: legacyHashHardwareId(input.hardwareId)
	};
}

async function findInstallationByHardwareHash(
	hashes: ConnectHardwareHashes | undefined
): Promise<GuardInstallation | undefined> {
	if (!hashes) return undefined;
	const [installation] = await db
		.select()
		.from(guardInstallations)
		.where(
			or(
				eq(guardInstallations.hardwareIdHash, hashes.hardwareIdHash),
				eq(guardInstallations.hardwareIdHash, hashes.legacyHardwareIdHash)
			)
		)
		.limit(1);
	return installation;
}

async function findLegacyInstallationFromRoomCameras(
	input: ConnectGuardInstallationInput,
	roomId: string
): Promise<GuardInstallation | undefined> {
	if (!input.hardwareId) return undefined;
	for (const camera of input.cameras) {
		const clientCameraId = camera.clientCameraId?.trim();
		if (!clientCameraId) continue;
		const [row] = await db
			.select({ installation: guardInstallations })
			.from(guardCameras)
			.innerJoin(guardInstallations, eq(guardCameras.installationId, guardInstallations.id))
			.where(
				and(
					eq(guardCameras.roomId, roomId),
					eq(guardCameras.clientCameraId, clientCameraId),
					sql`${guardInstallations.hardwareIdHash} is null`,
					sql`${guardInstallations.revokedAt} is null`,
					sql`${guardInstallations.status} <> 'revoked'`
				)
			)
			.limit(1);
		if (row?.installation) return row.installation;
	}
	return undefined;
}

async function findInstallationForConnect(
	input: ConnectGuardInstallationInput,
	roomId: string
): Promise<ResolvedConnectInstallation | undefined> {
	const hashes = hardwareHashesForConnect(input);
	const byHardware = await findInstallationByHardwareHash(hashes);
	if (byHardware) {
		return {
			installation: byHardware,
			resolvedByHardware: true,
			hardwareIdHash: hashes?.hardwareIdHash
		};
	}

	if (input.installationId) {
		const [byId] = await db
			.select()
			.from(guardInstallations)
			.where(eq(guardInstallations.id, input.installationId))
			.limit(1);
		if (byId) {
			return {
				installation: byId,
				resolvedByHardware: !!hashes,
				hardwareIdHash: hashes?.hardwareIdHash
			};
		}
	}

	const legacyFromRoomCameras = await findLegacyInstallationFromRoomCameras(input, roomId);
	if (legacyFromRoomCameras) {
		return {
			installation: legacyFromRoomCameras,
			resolvedByHardware: true,
			hardwareIdHash: hashes?.hardwareIdHash
		};
	}

	if (input.installationId && !hashes) {
		throw domainError('Guard installation not found', 404, 'INSTALLATION_NOT_FOUND');
	}
	return undefined;
}

function verifyReconnectCredential(
	installation: GuardInstallation,
	input: ConnectGuardInstallationInput
): void {
	if (!input.installationId || !input.deviceCredential) {
		throw domainError(
			'This Guard installation must reconnect with its saved device credential',
			409,
			'INSTALLATION_RECONNECT_REQUIRES_CREDENTIAL'
		);
	}
	if (installation.id !== input.installationId) {
		throw domainError(
			'installationId does not match this Guard installation',
			409,
			'INSTALLATION_IDENTITY_CONFLICT'
		);
	}
	const suppliedHash = hashDeviceToken(input.deviceCredential);
	if (!constantTimeHashEquals(installation.deviceTokenHash, suppliedHash)) {
		throw domainError('Invalid device credential', 401, 'INVALID_DEVICE_CREDENTIAL');
	}
}

async function closeActiveRoomAssignment(
	tx: GuardTransaction,
	installationId: string,
	disconnectedAt: Date
): Promise<void> {
	await tx
		.update(guardInstallationRoomAssignments)
		.set({ disconnectedAt })
		.where(
			and(
				eq(guardInstallationRoomAssignments.installationId, installationId),
				sql`${guardInstallationRoomAssignments.disconnectedAt} is null`
			)
		);
}

async function openRoomAssignment(
	tx: GuardTransaction,
	installationId: string,
	roomId: string,
	connectedAt: Date
): Promise<void> {
	await closeActiveRoomAssignment(tx, installationId, connectedAt);
	await tx.insert(guardInstallationRoomAssignments).values({
		id: randomUUID(),
		installationId,
		roomId,
		connectedAt,
		createdAt: connectedAt
	});
}

type InstallationOwnership = {
	status: string | null;
	hardwareIdHash: string | null;
};

async function getInstallationOwnership(
	tx: GuardTransaction,
	installationId: string | null | undefined
): Promise<InstallationOwnership | null> {
	if (!installationId) return null;
	const [row] = await tx
		.select({
			status: guardInstallations.status,
			hardwareIdHash: guardInstallations.hardwareIdHash
		})
		.from(guardInstallations)
		.where(eq(guardInstallations.id, installationId))
		.limit(1);
	return row ?? null;
}

function canReclaimCameraFromInstallation(
	owner: InstallationOwnership | null,
	allowLegacyOwnerReclaim = false
): boolean {
	if (!owner) return true;
	if (owner.status === 'disconnected') return true;
	// Earlier Guard builds could create an installation without hardwareIdHash.
	// Once a hardware-bound Guard reconnects, that legacy owner is safe to
	// normalize/reclaim so a rebuild/reinstall does not strand the room cameras.
	return allowLegacyOwnerReclaim && !owner.hardwareIdHash && owner.status !== 'revoked';
}

function mapCameraIds(cameras: GuardCamera[]) {
	return cameras.map((camera) => ({
		clientCameraId: camera.clientCameraId ?? '',
		backendCameraId: camera.id,
		cameraId: camera.id,
		id: camera.id
	}));
}

async function buildSessionResponse(
	installation: GuardInstallation,
	room: GuardRoom,
	deviceToken?: string
): Promise<GuardSessionResponse> {
	const current = installation;
	const now = new Date();
	const accessToken = await signGuardAccessToken({
		installationId: current.id,
		roomId: current.roomId,
		scope: [...GUARD_SCOPES]
	});
	const expiresAt = new Date(now.getTime() + GUARD_ACCESS_TOKEN_EXPIRES_IN_SECONDS * 1000);
	const cameras = await db
		.select()
		.from(guardCameras)
		.where(eq(guardCameras.roomId, current.roomId))
		.orderBy(asc(guardCameras.sortOrder), asc(guardCameras.createdAt));

	return {
		installationId: current.id,
		guardInstanceId: current.id,
		deviceName: current.deviceName,
		room: { id: room.id, name: room.name },
		...(deviceToken ? { deviceToken, deviceCredential: deviceToken } : {}),
		accessToken,
		expiresIn: GUARD_ACCESS_TOKEN_EXPIRES_IN_SECONDS,
		expiresAt: expiresAt.toISOString(),
		serverTime: now.toISOString(),
		cameras: mapCameraIds(cameras)
	};
}

function cameraValues(
	input: ActivateGuardInstallationInput['cameras'][number],
	installationId: string,
	roomId: string,
	cameraId: string,
	now: Date
) {
	return {
		id: cameraId,
		roomId,
		installationId,
		clientCameraId: input.clientCameraId!.trim(),
		name: input.name?.trim() ?? '',
		type: input.type ?? 'hikvision',
		direction: input.direction,
		deviceAddress: input.deviceAddress.trim(),
		sdkPort: input.sdkPort ?? 8000,
		rtspPort: input.rtspPort ?? 554,
		rtspUrl: input.rtspUrl?.trim() || null,
		username: input.username?.trim() || 'admin',
		password: input.password ?? '',
		channel: input.channel ?? 1,
		streamType: input.streamType ?? 0,
		status: 'unknown',
		sortOrder: input.sortOrder ?? 0,
		createdAt: now,
		updatedAt: now
	};
}

async function upsertActivationCameras(
	tx: GuardTransaction,
	installationId: string,
	roomId: string,
	inputs: ActivateGuardInstallationInput['cameras'],
	now: Date,
	allowLegacyOwnerReclaim = false
): Promise<void> {
	const existingRoomCameras = await tx
		.select()
		.from(guardCameras)
		.where(eq(guardCameras.roomId, roomId));
	let roomCount = existingRoomCameras.length;

	for (const input of inputs) {
		const clientCameraId = input.clientCameraId!.trim();
		let [existing] = await tx
			.select()
			.from(guardCameras)
			.where(
				and(
					eq(guardCameras.installationId, installationId),
					eq(guardCameras.roomId, roomId),
					eq(guardCameras.clientCameraId, clientCameraId)
				)
			)
			.limit(1);

		if (!existing) {
			[existing] = await tx
				.select()
				.from(guardCameras)
				.where(
					and(eq(guardCameras.roomId, roomId), eq(guardCameras.clientCameraId, clientCameraId))
				)
				.limit(1);
			if (existing?.installationId && existing.installationId !== installationId) {
				const owner = await getInstallationOwnership(tx, existing.installationId);
				if (!canReclaimCameraFromInstallation(owner, allowLegacyOwnerReclaim)) {
					throw badRequest('Camera belongs to another Guard installation');
				}
			}
		}

		if (!existing && input.id?.trim()) {
			const [candidate] = await tx
				.select()
				.from(guardCameras)
				.where(eq(guardCameras.id, input.id.trim()))
				.limit(1);
			if (candidate) {
				if (candidate.roomId !== roomId) {
					// Backend camera IDs are room-specific. Guard may still send the
					// previous room's ID from an already-open room dialog, so preserve
					// that historical camera row and create/find a new mapping in the
					// selected room using clientCameraId. Never move event history.
					if (candidate.installationId && candidate.installationId !== installationId) {
						const owner = await getInstallationOwnership(tx, candidate.installationId);
						if (!canReclaimCameraFromInstallation(owner, allowLegacyOwnerReclaim)) {
							throw badRequest('Camera belongs to another Guard installation');
						}
					}
				} else {
					existing = candidate;
					if (existing.installationId && existing.installationId !== installationId) {
						const owner = await getInstallationOwnership(tx, existing.installationId);
						if (!canReclaimCameraFromInstallation(owner, allowLegacyOwnerReclaim)) {
							throw badRequest('Camera belongs to another Guard installation');
						}
					}
				}
			}
		}

		if (existing) {
			const values = cameraValues(input, installationId, roomId, existing.id, now);
			await tx
				.update(guardCameras)
				.set({
					...values,
					createdAt: existing.createdAt,
					status: existing.status,
					lastSeenAt: existing.lastSeenAt
				})
				.where(eq(guardCameras.id, existing.id));
			continue;
		}

		if (roomCount >= 4) throw badRequest('You can add up to 4 cameras per room');
		const values = cameraValues(input, installationId, roomId, randomUUID(), now);
		await tx.insert(guardCameras).values({ ...values, sortOrder: input.sortOrder ?? roomCount });
		roomCount += 1;
	}
}

export const guardInstallationsService = {
	async listAvailableRooms(): Promise<GuardAvailableRoomsResponse> {
		const rows = await db
			.select({ id: guardRooms.id, name: guardRooms.name })
			.from(guardRooms)
			.orderBy(asc(guardRooms.name), asc(guardRooms.id));
		return {
			rooms: rows.map((row) => ({ id: row.id, name: row.name })),
			serverTime: new Date().toISOString()
		};
	},

	async connect(input: ConnectGuardInstallationInput): Promise<GuardConnectResponse> {
		let room: GuardRoom;
		try {
			room = await getRoomById(input.roomId);
		} catch (error) {
			if (error instanceof Error && error.message === 'Room not found') {
				throw domainError('Room not found', 404, 'ROOM_NOT_FOUND');
			}
			throw error;
		}

		const now = new Date();
		const resolved = await findInstallationForConnect(input, room.id);
		const connectHashes = hardwareHashesForConnect(input);

		if (resolved) {
			const existing = resolved.installation;
			// Hardware identity is the canonical recovery key. A rebuild or
			// reinstall may lose the protected credential, but the same physical
			// Guard computer should still resolve to the same installationId.
			if (!resolved.resolvedByHardware) {
				verifyReconnectCredential(existing, input);
			}
			if (existing.status === 'revoked' || existing.revokedAt) {
				throw domainError('This Guard installation has been revoked', 403, 'INSTALLATION_REVOKED');
			}
			if (
				!resolved.resolvedByHardware &&
				existing.status === 'active' &&
				existing.roomId !== room.id
			) {
				throw domainError(
					'Disconnect the Guard installation from its current room before connecting to another room',
					409,
					'INSTALLATION_ALREADY_CONNECTED_TO_ANOTHER_ROOM'
				);
			}

			const suppliedCredentialHash = input.deviceCredential
				? hashDeviceToken(input.deviceCredential)
				: undefined;
			const suppliedCredentialValid = suppliedCredentialHash
				? constantTimeHashEquals(existing.deviceTokenHash, suppliedCredentialHash)
				: false;
			const refreshedDeviceCredential =
				resolved.resolvedByHardware && !suppliedCredentialValid ? generateDeviceToken() : undefined;
			const refreshedDeviceCredentialHash = refreshedDeviceCredential
				? hashDeviceToken(refreshedDeviceCredential)
				: undefined;
			const canonicalHardwareIdHash = resolved.hardwareIdHash ?? connectHashes?.hardwareIdHash;

			const result = await db.transaction(async (tx) => {
				const [installation] = await tx
					.update(guardInstallations)
					.set({
						roomId: room.id,
						...(canonicalHardwareIdHash ? { hardwareIdHash: canonicalHardwareIdHash } : {}),
						deviceName: input.deviceName.trim(),
						status: 'active',
						revokedAt: null,
						applicationVersion: input.applicationVersion?.trim() || existing.applicationVersion,
						...(refreshedDeviceCredentialHash
							? {
									deviceTokenHash: refreshedDeviceCredentialHash,
									previousDeviceTokenHash: null,
									deviceTokenIssuedAt: now,
									deviceTokenRotatedAt: null
								}
							: {}),
						lastSeenAt: now,
						updatedAt: now
					})
					.where(eq(guardInstallations.id, existing.id))
					.returning();
				await openRoomAssignment(tx, installation.id, room.id, now);
				await upsertActivationCameras(
					tx,
					installation.id,
					room.id,
					input.cameras,
					now,
					!!input.hardwareId
				);
				await claimRoomCamerasForInstallation(
					tx,
					installation.id,
					room.id,
					now,
					!!input.hardwareId
				);
				const cameras = await listRoomCameras(tx, room.id);
				return { installation, cameras };
			});

			return buildConnectResponse(
				result.installation,
				room,
				result.cameras,
				refreshedDeviceCredential
			);
		}

		if ((input.installationId || input.deviceCredential) && !input.hardwareId) {
			throw domainError('Guard installation not found', 404, 'INSTALLATION_NOT_FOUND');
		}

		const initialDeviceToken = generateDeviceToken();
		const initialDeviceTokenHash = hashDeviceToken(initialDeviceToken);
		const installationId = randomUUID();

		const result = await db.transaction(async (tx) => {
			const [installation] = await tx
				.insert(guardInstallations)
				.values({
					id: installationId,
					roomId: room.id,
					hardwareIdHash: connectHashes?.hardwareIdHash ?? null,
					deviceName: input.deviceName.trim(),
					status: 'active',
					applicationVersion: input.applicationVersion?.trim() || null,
					deviceTokenHash: initialDeviceTokenHash,
					deviceTokenIssuedAt: now,
					registeredAt: now,
					lastSeenAt: now,
					createdAt: now,
					updatedAt: now
				})
				.returning();
			await openRoomAssignment(tx, installation.id, room.id, now);
			await upsertActivationCameras(
				tx,
				installation.id,
				room.id,
				input.cameras,
				now,
				!!input.hardwareId
			);
			await claimRoomCamerasForInstallation(tx, installation.id, room.id, now, !!input.hardwareId);
			const cameras = await listRoomCameras(tx, room.id);
			return { installation, cameras };
		});

		return buildConnectResponse(result.installation, room, result.cameras, initialDeviceToken);
	},

	async getById(id: string): Promise<GuardInstallation> {
		const [installation] = await db
			.select()
			.from(guardInstallations)
			.where(eq(guardInstallations.id, id))
			.limit(1);
		if (!installation) throw notFound('Guard installation not found');
		return installation;
	},

	async activate(input: ActivateGuardInstallationInput): Promise<GuardSessionResponse> {
		const room = await resolveRoom(input.roomIdentifier);
		const hardwareIdHash = hashHardwareId(input.hardwareId);
		const now = new Date();

		const result = await db.transaction(async (tx) => {
			let [installation] = await tx
				.select()
				.from(guardInstallations)
				.where(
					or(
						eq(guardInstallations.hardwareIdHash, hardwareIdHash),
						eq(guardInstallations.hardwareIdHash, legacyHashHardwareId(input.hardwareId))
					)
				)
				.limit(1);

			const installationId = installation?.id ?? randomUUID();
			const initialDeviceToken = generateDeviceToken();
			const initialDeviceTokenHash = hashDeviceToken(initialDeviceToken);

			if (!installation) {
				[installation] = await tx
					.insert(guardInstallations)
					.values({
						id: installationId,
						roomId: room.id,
						hardwareIdHash,
						deviceName: input.deviceName.trim(),
						status: 'active',
						applicationVersion: input.applicationVersion?.trim() || null,
						deviceTokenHash: initialDeviceTokenHash,
						deviceTokenIssuedAt: now,
						registeredAt: now,
						lastSeenAt: now,
						createdAt: now,
						updatedAt: now
					})
					.returning();
			} else {
				[installation] = await tx
					.update(guardInstallations)
					.set(
						reactivatedInstallationValues(input, room.id, initialDeviceTokenHash, now, installation)
					)
					.where(eq(guardInstallations.id, installation.id))
					.returning();
			}

			await openRoomAssignment(tx, installation.id, room.id, now);
			await upsertActivationCameras(tx, installation.id, room.id, input.cameras, now);
			return { installation, initialDeviceToken };
		});

		return buildSessionResponse(result.installation, room, result.initialDeviceToken);
	},

	async exchangeDeviceToken(input: ExchangeGuardDeviceTokenInput): Promise<GuardTokenResponse> {
		const installation = await this.getById(input.installationId);
		if (installation.status === 'revoked' || installation.revokedAt) {
			throw domainError('This Guard installation has been revoked', 403, 'INSTALLATION_REVOKED');
		}
		if (installation.status === 'disconnected') {
			throw domainError(
				'This Guard installation is not assigned to a room',
				409,
				'INSTALLATION_NOT_CONNECTED'
			);
		}
		if (input.hardwareId) {
			const expectedHash = hashHardwareId(input.hardwareId);
			const legacyHash = legacyHashHardwareId(input.hardwareId);
			if (
				installation.hardwareIdHash !== expectedHash &&
				installation.hardwareIdHash !== legacyHash
			) {
				throw unauthorized('Hardware ID does not match this Guard installation');
			}
		}

		const suppliedHash = hashDeviceToken(input.deviceToken);
		if (!constantTimeHashEquals(installation.deviceTokenHash, suppliedHash)) {
			throw domainError('Invalid device credential', 401, 'INVALID_DEVICE_CREDENTIAL');
		}

		const now = new Date();
		await db
			.update(guardInstallations)
			.set({
				deviceTokenIssuedAt: now,
				applicationVersion: input.applicationVersion?.trim() || installation.applicationVersion,
				lastSeenAt: now,
				updatedAt: now
			})
			.where(eq(guardInstallations.id, installation.id));

		const accessToken = await signGuardAccessToken({
			installationId: installation.id,
			roomId: installation.roomId,
			scope: [...GUARD_SCOPES]
		});
		const expiresAt = new Date(now.getTime() + GUARD_ACCESS_TOKEN_EXPIRES_IN_SECONDS * 1000);
		return {
			accessToken,
			expiresAt: expiresAt.toISOString(),
			serverTime: now.toISOString()
		};
	},

	async current(installationId: string): Promise<GuardSessionResponse> {
		const installation = await this.getById(installationId);
		const room = await getRoomById(installation.roomId);
		const now = new Date();
		await db
			.update(guardInstallations)
			.set({ lastSeenAt: now, updatedAt: now })
			.where(eq(guardInstallations.id, installationId));
		return buildSessionResponse(installation, room);
	},

	async disconnect(installationId: string): Promise<void> {
		const now = new Date();
		await db.transaction(async (tx) => {
			const [installation] = await tx
				.select()
				.from(guardInstallations)
				.where(eq(guardInstallations.id, installationId))
				.limit(1);
			if (!installation) throw notFound('Guard installation not found');
			await closeActiveRoomAssignment(tx, installationId, now);
			await tx
				.update(guardCameras)
				.set({ status: 'offline', updatedAt: now })
				.where(
					and(
						eq(guardCameras.installationId, installationId),
						eq(guardCameras.roomId, installation.roomId)
					)
				);
			await tx
				.update(guardInstallations)
				.set(disconnectedInstallationValues(now))
				.where(eq(guardInstallations.id, installationId));
		});
	},

	async recordHeartbeat(
		installationId: string,
		input?: { guardVersion?: string | null; occurredAt?: Date | null }
	): Promise<{ installationId: string; lastSeenAt: string }> {
		const installation = await this.getById(installationId);
		if (installation.status === 'revoked' || installation.revokedAt) {
			throw forbidden('Guard installation is revoked');
		}

		const now = input?.occurredAt ?? new Date();
		const guardVersion = input?.guardVersion?.trim();
		await db
			.update(guardInstallations)
			.set({
				lastSeenAt: now,
				updatedAt: now,
				...(guardVersion ? { applicationVersion: guardVersion } : {})
			})
			.where(eq(guardInstallations.id, installationId));

		return {
			installationId,
			lastSeenAt: now.toISOString()
		};
	},

	async listByRoom(roomId: string): Promise<GuardInstallationAdminRecord[]> {
		await resolveRoom(roomId);
		const rows = await db
			.select({
				installation: guardInstallations,
				assignmentRoomId: guardInstallationRoomAssignments.roomId,
				connectedAt: guardInstallationRoomAssignments.connectedAt,
				disconnectedAt: guardInstallationRoomAssignments.disconnectedAt
			})
			.from(guardInstallationRoomAssignments)
			.innerJoin(
				guardInstallations,
				eq(guardInstallationRoomAssignments.installationId, guardInstallations.id)
			)
			.where(eq(guardInstallationRoomAssignments.roomId, roomId))
			.orderBy(desc(guardInstallationRoomAssignments.connectedAt));
		return rows.map(({ installation, assignmentRoomId, connectedAt, disconnectedAt }) => ({
			id: installation.id,
			roomId: assignmentRoomId,
			currentRoomId: installation.roomId,
			deviceName: installation.deviceName,
			status: installation.status,
			applicationVersion: installation.applicationVersion,
			registeredAt: installation.registeredAt,
			lastSeenAt: installation.lastSeenAt,
			revokedAt: installation.revokedAt,
			connectedAt,
			disconnectedAt,
			isCurrentAssignment:
				disconnectedAt === null &&
				installation.status === 'active' &&
				installation.roomId === assignmentRoomId
		}));
	},

	async revokeForRoom(roomId: string, installationId: string): Promise<void> {
		const now = new Date();
		const [updated] = await db
			.update(guardInstallations)
			.set(revokedInstallationValues(now))
			.where(and(eq(guardInstallations.id, installationId), eq(guardInstallations.roomId, roomId)))
			.returning({ id: guardInstallations.id });
		if (!updated) throw notFound('Guard installation not found');
	},

	async createActivationCode(
		roomId: string,
		input: CreateRoomActivationCodeInput,
		createdBy: string
	): Promise<ActivationCodeRecord> {
		const [room] = await db.select().from(guardRooms).where(eq(guardRooms.id, roomId)).limit(1);
		if (!room) throw notFound('Room not found');
		const code = generateActivationCode();
		const now = new Date();
		const expiresAt = new Date(now.getTime() + input.expiresInMinutes * 60 * 1000);
		const [row] = await db
			.insert(guardRoomActivationCodes)
			.values({
				id: randomUUID(),
				roomId,
				codeHash: hashActivationCode(code),
				expiresAt,
				maxUses: input.maxUses,
				usedCount: 0,
				createdBy,
				createdAt: now
			})
			.returning();
		return { ...row, code };
	},

	async listActivationCodes(roomId: string): Promise<ActivationCodeRecord[]> {
		return db
			.select({
				id: guardRoomActivationCodes.id,
				roomId: guardRoomActivationCodes.roomId,
				expiresAt: guardRoomActivationCodes.expiresAt,
				maxUses: guardRoomActivationCodes.maxUses,
				usedCount: guardRoomActivationCodes.usedCount,
				usedAt: guardRoomActivationCodes.usedAt,
				usedByInstallationId: guardRoomActivationCodes.usedByInstallationId,
				createdAt: guardRoomActivationCodes.createdAt,
				revokedAt: guardRoomActivationCodes.revokedAt
			})
			.from(guardRoomActivationCodes)
			.where(eq(guardRoomActivationCodes.roomId, roomId))
			.orderBy(sql`${guardRoomActivationCodes.createdAt} desc`);
	},

	async revokeActivationCode(roomId: string, codeId: string): Promise<void> {
		const [updated] = await db
			.update(guardRoomActivationCodes)
			.set({ revokedAt: new Date() })
			.where(
				and(eq(guardRoomActivationCodes.id, codeId), eq(guardRoomActivationCodes.roomId, roomId))
			)
			.returning({ id: guardRoomActivationCodes.id });
		if (!updated) throw notFound('Activation code not found');
	}
};
