import { existsSync } from 'node:fs';
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import { join, sep } from 'node:path';
import { env } from '@/config/env.js';
import { notFound } from '@/services/errors.js';
import { readJpegDimensions } from '@/utils/jpeg-dimensions.js';
import { toSafePathSegment } from '@/utils/safe-path-segment.js';

const MIN_IMAGE_BYTES = 32;
export const MAX_SAFETY_EVENT_IMAGE_BYTES = 5 * 1024 * 1024;

export type WrittenSafetyEventImage = {
	relativePath: string;
	absolutePath: string;
	mimeType: string;
	width: number;
	height: number;
	sizeBytes: number;
};

function absolutePathForRelative(relativePath: string): string {
	const normalized = relativePath.replace(/\\/g, '/');
	if (normalized.includes('..')) {
		throw new Error('Invalid storage path');
	}

	return join(env.UPLOADS_DIR, normalized);
}

function buildRelativeStoragePath(
	eventId: string,
	cameraId: string,
	hazardType: string,
	occurredAt: Date
): string {
	const year = String(occurredAt.getFullYear());
	const month = String(occurredAt.getMonth() + 1).padStart(2, '0');
	const day = String(occurredAt.getDate()).padStart(2, '0');
	const safeCameraId = toSafePathSegment(cameraId, 'camera');
	const safeEventId = toSafePathSegment(eventId, 'event');
	const safeType = toSafePathSegment(hazardType, 'hazard');

	return join('safety-events', year, month, day, safeCameraId, `${safeEventId}_${safeType}.jpg`)
		.split(sep)
		.join('/');
}

function validateImageBuffer(buffer: Buffer, mimeType: string): void {
	if (buffer.length < MIN_IMAGE_BYTES) {
		throw new Error('snapshot image is too small');
	}

	if (buffer.length > MAX_SAFETY_EVENT_IMAGE_BYTES) {
		throw new Error('snapshot image is too large (max 5 MB)');
	}

	const normalizedMime = mimeType.trim().toLowerCase();
	if (normalizedMime === 'image/jpeg' || normalizedMime === 'image/jpg') {
		if (buffer[0] !== 0xff || buffer[1] !== 0xd8) {
			throw new Error('snapshot must be a valid JPEG file');
		}
		return;
	}

	if (normalizedMime === 'image/png') {
		if (
			buffer.length < 8 ||
			buffer[0] !== 0x89 ||
			buffer[1] !== 0x50 ||
			buffer[2] !== 0x4e ||
			buffer[3] !== 0x47
		) {
			throw new Error('snapshot must be a valid PNG file');
		}
		return;
	}

	throw new Error('snapshot must be image/jpeg or image/png');
}

function readImageDimensions(buffer: Buffer, mimeType: string): { width: number; height: number } {
	const normalizedMime = mimeType.trim().toLowerCase();
	if (normalizedMime === 'image/png') {
		if (buffer.length < 24) {
			throw new Error('Unable to read PNG dimensions');
		}

		const width = buffer.readUInt32BE(16);
		const height = buffer.readUInt32BE(20);
		if (width > 0 && height > 0) {
			return { width, height };
		}

		throw new Error('Unable to read PNG dimensions');
	}

	const dimensions = readJpegDimensions(buffer);
	if (!dimensions) {
		throw new Error('Unable to read JPEG dimensions');
	}

	return dimensions;
}

export const safetyEventImagesService = {
	buildSnapshotUrl(eventId: string): string {
		return `/api/safety-events/${encodeURIComponent(eventId)}/snapshot`;
	},

	snapshotExists(relativePath: string | null | undefined): boolean {
		const normalized = relativePath?.trim();
		if (!normalized) {
			return false;
		}

		return existsSync(absolutePathForRelative(normalized));
	},

	async writeSnapshot(input: {
		eventId: string;
		cameraId: string;
		hazardType: string;
		occurredAt: Date;
		buffer: Buffer;
		mimeType: string;
	}): Promise<WrittenSafetyEventImage> {
		validateImageBuffer(input.buffer, input.mimeType);
		const { width, height } = readImageDimensions(input.buffer, input.mimeType);

		const relativePath = buildRelativeStoragePath(
			input.eventId,
			input.cameraId,
			input.hazardType,
			input.occurredAt
		);
		const absolutePath = absolutePathForRelative(relativePath);

		await mkdir(join(absolutePath, '..'), { recursive: true });
		await writeFile(absolutePath, input.buffer);

		return {
			relativePath,
			absolutePath,
			mimeType: input.mimeType.trim().toLowerCase(),
			width,
			height,
			sizeBytes: input.buffer.length
		};
	},

	async readSnapshot(relativePath: string): Promise<Buffer> {
		const absolutePath = absolutePathForRelative(relativePath);
		if (!existsSync(absolutePath)) {
			throw notFound('Snapshot not found');
		}

		return readFile(absolutePath);
	},

	async deleteSnapshot(relativePath: string): Promise<void> {
		const absolutePath = absolutePathForRelative(relativePath);
		await unlink(absolutePath);
	}
};
