import { lt } from 'drizzle-orm';

import { env } from '@/config/env.js';
import { db } from '@/db/index.js';
import { guardFaceAppearances } from '@/db/schema/guard.js';
import { inOutFaceImagesService } from '@/services/in-out-face-images.js';

export function inOutRetentionCutoff(now = new Date()): Date {
	const cutoff = new Date(now);
	cutoff.setDate(cutoff.getDate() - env.IN_OUT_RETENTION_DAYS);
	return cutoff;
}

export async function purgeExpiredInOutRecords(now = new Date()): Promise<number> {
	if (env.IN_OUT_RETENTION_DAYS <= 0) {
		return 0;
	}

	const cutoff = inOutRetentionCutoff(now);

	const expired = await db
		.select({ id: guardFaceAppearances.id })
		.from(guardFaceAppearances)
		.where(lt(guardFaceAppearances.occurredAt, cutoff));

	for (const row of expired) {
		await inOutFaceImagesService.deleteStoredImagesForEvent(row.id);
	}

	const deleted = await db
		.delete(guardFaceAppearances)
		.where(lt(guardFaceAppearances.occurredAt, cutoff))
		.returning({ id: guardFaceAppearances.id });

	return deleted.length;
}
