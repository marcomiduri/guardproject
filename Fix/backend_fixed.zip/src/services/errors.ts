export class AppError extends Error {
	status: number;
	code: string;
	retryable?: boolean;

	constructor(message: string, status = 500, code = 'INTERNAL_ERROR', retryable?: boolean) {
		super(message);
		this.name = 'AppError';
		this.status = status;
		this.code = code;
		this.retryable = retryable;
	}
}

export function notFound(message = 'Not found'): AppError {
	return new AppError(message, 404, 'NOT_FOUND');
}

export function badRequest(message: string): AppError {
	return new AppError(message, 400, 'BAD_REQUEST');
}

export function forbidden(message = 'Forbidden'): AppError {
	return new AppError(message, 403, 'FORBIDDEN');
}

export function unauthorized(message = 'Unauthorized'): AppError {
	return new AppError(message, 401, 'UNAUTHORIZED');
}

export function invalidPassword(message = 'Current password is incorrect'): AppError {
	return new AppError(message, 400, 'INVALID_PASSWORD');
}

export function domainError(
	message: string,
	status: number,
	code: string,
	retryable = false
): AppError {
	return new AppError(message, status, code, retryable);
}
