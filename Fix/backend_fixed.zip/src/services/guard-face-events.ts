import { randomUUID } from 'node:crypto';
import { and, eq, isNotNull } from 'drizzle-orm';
import { db } from '@/db/index.js';
import {
	guardFaceAppearances,
	guardRoomOccupancy,
	guardRoomPresence,
	guardRooms
} from '@/db/schema/guard.js';
import { users } from '@/db/schema/auth.js';
import { guardCamerasService, type GuardCameraAccess } from '@/services/guard-cameras.js';
import { realtimeHub } from '@/services/realtime-hub.js';
import { roomOrdersService } from '@/services/room-orders.js';
import {
	isPrivilegedGuardOperatorRole,
	resolveRecognizedFaceApproval
} from '@/services/guard-face-approval.js';
import {
	inOutFaceImagesService,
	type WrittenInOutFaceImage
} from '@/services/in-out-face-images.js';
import {
	snapshotCameraFields,
	formatCameraDisplayLabel
} from '@/services/guard-camera-snapshot.js';
import { badRequest, notFound } from '@/services/errors.js';
import type { GuardFaceAppearedInput, GuardUnknownFaceAppearedInput } from '@/validators/guard.js';
import { logger } from '@/utils/logger.js';

export type GuardFaceEvent = {
	id: string;
	faceRegistryId: number | null;
	userId: string | null;
	userName: string;
	userRole: string | null;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	direction: 'in' | 'out';
	eventType: 'in' | 'out' | 'unknown';
	similarity: number | null;
	occurredAt: Date;
	currentRoomCount: number | null;
	isNewEntry: boolean;
	approved: boolean | null;
	idempotent?: boolean;
};

export type GuardUnknownFaceEvent = {
	id: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	direction: 'in' | 'out';
	trackId: number | null;
	occurredAt: Date;
	idempotent?: boolean;
};

async function prepareInOutEventImages(input: {
	eventId: string;
	cameraId: string;
	occurredAt: Date;
	faceImage?: Buffer;
	faceImageMimeType?: string;
	frameImage?: Buffer;
	frameImageMimeType?: string;
}): Promise<WrittenInOutFaceImage[]> {
	const pending: WrittenInOutFaceImage[] = [];

	if (input.frameImage && input.frameImage.length >= 32) {
		try {
			pending.push(
				await inOutFaceImagesService.writeFaceImageFile({
					eventId: input.eventId,
					cameraId: input.cameraId,
					occurredAt: input.occurredAt,
					imageBuffer: input.frameImage,
					mimeType: input.frameImageMimeType ?? 'image/jpeg',
					imageType: 'event_frame'
				})
			);
		} catch (error) {
			logger.error('[guard-face-events] invalid event frame snapshot, skipping image', error);
		}
	}

	if (input.faceImage && input.faceImage.length >= 32) {
		try {
			pending.push(
				await inOutFaceImagesService.writeFaceImageFile({
					eventId: input.eventId,
					cameraId: input.cameraId,
					occurredAt: input.occurredAt,
					imageBuffer: input.faceImage,
					mimeType: input.faceImageMimeType ?? 'image/jpeg',
					imageType: 'face_crop'
				})
			);
		} catch (error) {
			logger.error('[guard-face-events] invalid face crop snapshot, skipping image', error);
		}
	}

	return pending;
}

async function persistPreparedImages(
	eventId: string,
	images: WrittenInOutFaceImage[]
): Promise<void> {
	for (const image of images) {
		try {
			await inOutFaceImagesService.insertImageMetadata(db, eventId, image);
		} catch (error) {
			await inOutFaceImagesService.deleteFileAt(image.absolutePath);
			logger.error('[guard-face-events] failed to store image metadata', error);
		}
	}
}

async function currentCount(roomId: string): Promise<number> {
	const [row] = await db
		.select({ count: guardRoomOccupancy.currentCount })
		.from(guardRoomOccupancy)
		.where(eq(guardRoomOccupancy.roomId, roomId))
		.limit(1);
	return row?.count ?? 0;
}

async function findExistingEvent(id: string): Promise<GuardFaceEvent | null> {
	const [row] = await db
		.select({
			id: guardFaceAppearances.id,
			faceRegistryId: guardFaceAppearances.faceRegistryId,
			userId: guardFaceAppearances.userId,
			userName: users.username,
			userRole: users.role,
			roomId: guardFaceAppearances.roomId,
			roomName: guardRooms.name,
			cameraId: guardFaceAppearances.cameraId,
			cameraName: guardFaceAppearances.cameraName,
			cameraAddress: guardFaceAppearances.cameraAddress,
			direction: guardFaceAppearances.direction,
			eventType: guardFaceAppearances.eventType,
			similarity: guardFaceAppearances.similarity,
			approved: guardFaceAppearances.approved,
			occurredAt: guardFaceAppearances.occurredAt
		})
		.from(guardFaceAppearances)
		.innerJoin(guardRooms, eq(guardFaceAppearances.roomId, guardRooms.id))
		.leftJoin(users, eq(guardFaceAppearances.userId, users.id))
		.where(eq(guardFaceAppearances.id, id))
		.limit(1);
	if (!row) return null;

	return {
		id: row.id,
		faceRegistryId: row.faceRegistryId,
		userId: row.userId,
		userName: row.userName ?? 'Unknown',
		userRole: row.userRole,
		roomId: row.roomId,
		roomName: row.roomName,
		cameraId: row.cameraId,
		cameraName: row.cameraName?.trim() || row.cameraAddress?.trim() || row.cameraId,
		direction: row.direction === 'out' ? 'out' : 'in',
		eventType: row.eventType === 'unknown' ? 'unknown' : row.direction === 'out' ? 'out' : 'in',
		similarity: row.similarity,
		occurredAt: row.occurredAt,
		currentRoomCount: await currentCount(row.roomId),
		isNewEntry: false,
		approved: row.approved,
		idempotent: true
	};
}

export const guardFaceEventsService = {
	async recordAppeared(
		input: GuardFaceAppearedInput,
		access?: GuardCameraAccess
	): Promise<GuardFaceEvent> {
		const id = input.eventId?.trim() || randomUUID();
		const duplicate = await findExistingEvent(id);
		if (duplicate) {
			if (duplicate.eventType === 'unknown') {
				throw badRequest('eventId already belongs to an unknown-face event');
			}
			return duplicate;
		}

		const user = await db.query.users.findFirst({
			where: and(eq(users.faceRegistryId, input.faceRegistryId), isNotNull(users.faceEmbedding))
		});
		if (!user || !Array.isArray(user.faceEmbedding) || user.faceEmbedding.length === 0) {
			throw notFound('Face not found');
		}

		const camera = await guardCamerasService.getById(input.cameraId, access);
		const direction = camera.direction === 'out' ? 'out' : 'in';
		const roomId = camera.roomId;
		const isPrivilegedOperator = isPrivilegedGuardOperatorRole(user.role);
		const occurredAt = input.occurredAt ?? new Date();
		const supersededId = input.supersedesEventId?.trim() || null;
		const { cameraName, cameraAddress } = snapshotCameraFields(camera);
		const hasApprovedRoomOrder =
			direction === 'in' && !isPrivilegedOperator
				? await roomOrdersService.hasApprovedAccessAt(user.id, roomId, occurredAt)
				: false;
		const approved = resolveRecognizedFaceApproval({
			direction,
			userRole: user.role,
			hasApprovedRoomOrder
		});

		const transactionResult = await db.transaction(async (tx) => {
			const [room] = await tx.select().from(guardRooms).where(eq(guardRooms.id, roomId)).limit(1);
			if (!room) throw badRequest('Room not found');

			if (supersededId) {
				const [superseded] = await tx
					.select({
						id: guardFaceAppearances.id,
						eventType: guardFaceAppearances.eventType
					})
					.from(guardFaceAppearances)
					.where(eq(guardFaceAppearances.id, supersededId))
					.limit(1);
				if (!superseded || superseded.eventType !== 'unknown') {
					throw badRequest('supersedesEventId does not reference an unknown-face event');
				}
				await tx
					.update(guardFaceAppearances)
					.set({ recognitionStatus: 'SUPERSEDED' })
					.where(eq(guardFaceAppearances.id, supersededId));
			}

			const inserted = await tx
				.insert(guardFaceAppearances)
				.values({
					id,
					faceRegistryId: input.faceRegistryId,
					userId: user.id,
					roomId,
					cameraId: input.cameraId,
					cameraName,
					cameraAddress,
					direction,
					eventType: direction,
					recognitionStatus: 'IDENTIFIED',
					similarity: input.similarity ?? null,
					approved,
					trackId: input.trackId ?? null,
					source: input.source?.trim() || 'GUARD2',
					supersedesEventId: input.supersedesEventId?.trim() || null,
					rectangle: input.rectangle,
					occurredAt
				})
				.onConflictDoNothing({ target: guardFaceAppearances.id })
				.returning({ id: guardFaceAppearances.id });
			if (inserted.length === 0)
				return {
					inserted: false as const,
					room,
					currentCount: 0,
					previousCount: 0,
					isNewEntry: false
				};

			let [occupancy] = await tx
				.select()
				.from(guardRoomOccupancy)
				.where(eq(guardRoomOccupancy.roomId, roomId))
				.limit(1);
			if (!occupancy) {
				[occupancy] = await tx
					.insert(guardRoomOccupancy)
					.values({ roomId, currentCount: 0, updatedAt: occurredAt })
					.returning();
			}

			let nextCount = occupancy.currentCount;
			const previousCount = nextCount;
			let isNewEntry = false;
			if (direction === 'in') {
				const [presence] = await tx
					.select()
					.from(guardRoomPresence)
					.where(and(eq(guardRoomPresence.roomId, roomId), eq(guardRoomPresence.userId, user.id)))
					.limit(1);
				if (!presence) {
					isNewEntry = true;
					await tx
						.insert(guardRoomPresence)
						.values({ roomId, userId: user.id, enteredAt: occurredAt });
					nextCount = Math.min(nextCount + 1, room.maxMembers);
				}
			} else {
				const deleted = await tx
					.delete(guardRoomPresence)
					.where(and(eq(guardRoomPresence.roomId, roomId), eq(guardRoomPresence.userId, user.id)))
					.returning({ userId: guardRoomPresence.userId });
				if (deleted.length > 0) nextCount = Math.max(nextCount - 1, 0);
			}

			await tx
				.update(guardRoomOccupancy)
				.set({ currentCount: nextCount, updatedAt: occurredAt })
				.where(eq(guardRoomOccupancy.roomId, roomId));

			return { inserted: true as const, room, currentCount: nextCount, previousCount, isNewEntry };
		});

		if (!transactionResult.inserted) {
			const existing = await findExistingEvent(id);
			if (!existing) throw badRequest('Duplicate face event could not be loaded');
			return existing;
		}

		const images = await prepareInOutEventImages({
			eventId: id,
			cameraId: input.cameraId,
			occurredAt,
			faceImage: input.faceImage,
			faceImageMimeType: input.faceImageMimeType,
			frameImage: input.frameImage,
			frameImageMimeType: input.frameImageMimeType
		});
		await persistPreparedImages(id, images);

		const cameraLabel = formatCameraDisplayLabel(camera, input.cameraId);
		const event: GuardFaceEvent = {
			id,
			faceRegistryId: input.faceRegistryId,
			userId: user.id,
			userName: user.username,
			userRole: user.role,
			roomId,
			roomName: transactionResult.room.name,
			cameraId: input.cameraId,
			cameraName: cameraLabel,
			direction,
			eventType: direction,
			similarity: input.similarity ?? null,
			occurredAt,
			currentRoomCount: transactionResult.currentCount,
			isNewEntry: transactionResult.isNewEntry,
			approved
		};

		realtimeHub.publishInOutEvent({
			roomId,
			eventId: id,
			userId: user.id,
			currentCount: transactionResult.currentCount,
			maxMembers: transactionResult.room.maxMembers
		});
		if (transactionResult.currentCount !== transactionResult.previousCount) {
			realtimeHub.publishRoomOccupancy({
				roomId,
				currentCount: transactionResult.currentCount,
				maxMembers: transactionResult.room.maxMembers,
				updatedAt: occurredAt.toISOString()
			});
		}
		realtimeHub.publishFaceIdentified({
			id,
			userId: user.id,
			userName: user.username,
			userRole: user.role,
			roomId,
			roomName: transactionResult.room.name,
			cameraId: input.cameraId,
			cameraName: cameraLabel,
			direction,
			approved,
			similarity: input.similarity ?? null,
			occurredAt: occurredAt.toISOString(),
			currentRoomCount: transactionResult.currentCount
		});

		if (supersededId) {
			realtimeHub.publishFaceEventCorrected({
				id,
				eventId: id,
				supersedesEventId: supersededId,
				userId: user.id,
				userName: user.username,
				approved,
				direction,
				occurredAt: occurredAt.toISOString()
			});
		}

		if (direction === 'in' && transactionResult.isNewEntry && !isPrivilegedOperator) {
			realtimeHub.publishRoomEntry({
				id,
				userName: user.username,
				roomId,
				roomName: transactionResult.room.name,
				cameraId: input.cameraId,
				cameraName: cameraLabel,
				currentRoomCount: transactionResult.currentCount,
				maxMembers: transactionResult.room.maxMembers,
				occurredAt: occurredAt.toISOString(),
				approved: approved === true
			});
		}

		return event;
	},

	async recordUnknownAppeared(
		input: GuardUnknownFaceAppearedInput,
		access?: GuardCameraAccess
	): Promise<GuardUnknownFaceEvent> {
		const id = input.eventId?.trim() || randomUUID();
		const duplicate = await findExistingEvent(id);
		if (duplicate) {
			if (duplicate.eventType !== 'unknown') {
				throw badRequest('eventId already belongs to a recognized-face event');
			}
			return {
				id: duplicate.id,
				roomId: duplicate.roomId,
				roomName: duplicate.roomName,
				cameraId: duplicate.cameraId,
				cameraName: duplicate.cameraName,
				direction: duplicate.direction,
				trackId: null,
				occurredAt: duplicate.occurredAt,
				idempotent: true
			};
		}

		const camera = await guardCamerasService.getById(input.cameraId, access);
		const direction = camera.direction === 'out' ? 'out' : 'in';
		const roomId = camera.roomId;
		const occurredAt = input.occurredAt ?? new Date();
		const { cameraName, cameraAddress } = snapshotCameraFields(camera);
		const [room] = await db.select().from(guardRooms).where(eq(guardRooms.id, roomId)).limit(1);
		if (!room) throw badRequest('Room not found');

		const inserted = await db
			.insert(guardFaceAppearances)
			.values({
				id,
				faceRegistryId: null,
				userId: null,
				roomId,
				cameraId: input.cameraId,
				cameraName,
				cameraAddress,
				direction,
				eventType: 'unknown',
				recognitionStatus: 'UNIDENTIFIED',
				similarity: null,
				approved: null,
				trackId: input.trackId ?? null,
				source: input.source?.trim() || 'GUARD2',
				rectangle: input.rectangle,
				occurredAt
			})
			.onConflictDoNothing({ target: guardFaceAppearances.id })
			.returning({ id: guardFaceAppearances.id });
		if (inserted.length === 0) {
			const existing = await findExistingEvent(id);
			if (!existing) throw badRequest('Duplicate unknown-face event could not be loaded');
			return {
				id: existing.id,
				roomId: existing.roomId,
				roomName: existing.roomName,
				cameraId: existing.cameraId,
				cameraName: existing.cameraName,
				direction: existing.direction,
				trackId: input.trackId ?? null,
				occurredAt: existing.occurredAt,
				idempotent: true
			};
		}

		const images = await prepareInOutEventImages({
			eventId: id,
			cameraId: input.cameraId,
			occurredAt,
			faceImage: input.faceImage,
			faceImageMimeType: input.faceImageMimeType,
			frameImage: input.frameImage,
			frameImageMimeType: input.frameImageMimeType
		});
		await persistPreparedImages(id, images);

		const cameraLabel = formatCameraDisplayLabel(camera, input.cameraId);
		const event: GuardUnknownFaceEvent = {
			id,
			roomId,
			roomName: room.name,
			cameraId: input.cameraId,
			cameraName: cameraLabel,
			direction,
			trackId: input.trackId ?? null,
			occurredAt
		};
		const occupancy = await currentCount(roomId);
		realtimeHub.publishInOutEvent({
			roomId,
			eventId: id,
			userId: null,
			currentCount: occupancy,
			maxMembers: room.maxMembers
		});
		if (direction === 'in') {
			realtimeHub.publishUnknownRoomEntry({
				id,
				roomId,
				roomName: room.name,
				cameraId: input.cameraId,
				cameraName: cameraLabel,
				direction,
				trackId: input.trackId ?? null,
				occurredAt: occurredAt.toISOString()
			});
		}
		return event;
	}
};
