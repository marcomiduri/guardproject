import { randomUUID } from 'node:crypto';
import { SignJWT, jwtVerify } from 'jose';
import { env } from '@/config/env.js';

const secretKey = new TextEncoder().encode(env.GUARD_JWT_SECRET);

export type GuardJwtPayload = {
	installationId: string;
	roomId: string;
	scope: string[];
};

export function parseDurationSeconds(value: string): number {
	const trimmed = value.trim().toLowerCase();
	if (/^\d+$/.test(trimmed)) return Math.max(1, Number.parseInt(trimmed, 10));
	const match = /^(\d+)(s|m|h|d)$/.exec(trimmed);
	if (!match) return 900;
	const amount = Number.parseInt(match[1], 10);
	const multiplier = match[2] === 'd' ? 86400 : match[2] === 'h' ? 3600 : match[2] === 'm' ? 60 : 1;
	return Math.max(1, amount * multiplier);
}

export const GUARD_ACCESS_TOKEN_EXPIRES_IN_SECONDS = parseDurationSeconds(env.GUARD_JWT_EXPIRES_IN);

export async function signGuardAccessToken(payload: GuardJwtPayload): Promise<string> {
	return new SignJWT({
		tokenType: 'guard',
		roomId: payload.roomId,
		scope: payload.scope
	})
		.setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
		.setIssuer(env.GUARD_JWT_ISSUER)
		.setAudience(env.GUARD_JWT_AUDIENCE)
		.setSubject(payload.installationId)
		.setJti(randomUUID())
		.setIssuedAt()
		.setExpirationTime(env.GUARD_JWT_EXPIRES_IN)
		.sign(secretKey);
}

export async function verifyGuardAccessToken(token: string): Promise<GuardJwtPayload> {
	const { payload } = await jwtVerify(token, secretKey, {
		algorithms: ['HS256'],
		issuer: env.GUARD_JWT_ISSUER,
		audience: env.GUARD_JWT_AUDIENCE
	});

	if (
		payload.tokenType !== 'guard' ||
		!payload.sub ||
		typeof payload.roomId !== 'string' ||
		!Array.isArray(payload.scope) ||
		!payload.scope.every((item) => typeof item === 'string')
	) {
		throw new Error('Invalid Guard access token payload');
	}

	return {
		installationId: payload.sub,
		roomId: payload.roomId,
		scope: payload.scope as string[]
	};
}
