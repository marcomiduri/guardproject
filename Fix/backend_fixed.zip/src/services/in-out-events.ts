import { alias } from 'drizzle-orm/pg-core';
import { and, asc, eq, gte, ilike, isNotNull, isNull, lte, or, sql, type SQL } from 'drizzle-orm';

import { db } from '@/db/index.js';

import { users } from '@/db/schema/auth.js';

import {
	guardCameras,
	guardFaceAppearances,
	guardRooms,
	inOutEventImages,
	roomOrders,
	ROOM_ORDER_STATUSES
} from '@/db/schema/guard.js';

import { buildPagination, type PaginatedListData } from '@/http/responses.js';
import { collectColumnFilterConditions } from '@/lib/db/column-filters.js';
import { clampListPagination } from '@/lib/db/pagination.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { forbidden, notFound } from '@/services/errors.js';
import { purgeExpiredInOutRecords } from '@/services/in-out-retention.js';
import { inOutFaceImagesService } from '@/services/in-out-face-images.js';
import type {
	InOutColumnFilter,
	InOutListSortField,
	ListInOutOptions
} from '@/types/in-out-list.js';
import type { ColumnFilterComparator } from '@/types/list-query.js';

export type InOutEvent = {
	id: string;

	faceRegistryId: number | null;

	userId: string | null;

	username: string;

	userRole: string | null;

	userEmail: string | null;

	userBirthday: string | null;

	userJob: string | null;

	userPosition: string | null;

	userProfileImageUrl: string | null;

	roomId: string;

	cameraId: string;

	cameraName: string;

	cameraAddress: string;

	direction: string;

	eventType: string;

	recognitionStatus: string;

	isIdentified: boolean;

	similarity: number | null;

	orderStatus: string | null;

	approved: boolean | null;

	roomName: string;

	supersedesEventId: string | null;

	supersededByEventId: string | null;

	relatedOrderId: string | null;

	relatedOrderStatus: string | null;

	relatedOrderStartTime: Date | null;

	relatedOrderEndTime: Date | null;

	faceImageUrl: string | null;

	frameImageUrl: string | null;

	thumbnailUrl: string | null;

	imageWidth: number | null;

	imageHeight: number | null;

	occurredAt: Date;
};

export type PaginatedInOutList = PaginatedListData<InOutEvent>;

function userProfileImageApiPath(userId: string): string {
	return `/api/in-out/users/${encodeURIComponent(userId.trim())}/profile-image`;
}

const EVENT_TYPE_LABELS: Record<string, string> = {
	in: 'In',
	out: 'Out',
	appeared: 'In'
};

const UNKNOWN_ROLE = 'unknown';

const frameEventImages = alias(inOutEventImages, 'frame_event_images');
const cropEventImages = alias(inOutEventImages, 'crop_event_images');

/** Room order active at the time of the in/out event (same user + room + time window). */
const relatedOrderMatchCondition = sql`
	${roomOrders.userId} = ${guardFaceAppearances.userId}
	AND ${roomOrders.roomId} = ${guardFaceAppearances.roomId}
	AND ${roomOrders.startTime} <= ${guardFaceAppearances.occurredAt}
	AND ${roomOrders.endTime} >= ${guardFaceAppearances.occurredAt}
`;

/** Room order status active at the time of the in/out event (same user + room + time window). */
const orderStatusAtEvent = sql<string | null>`(
	SELECT ${roomOrders.status}
	FROM ${roomOrders}
	WHERE ${relatedOrderMatchCondition}
	ORDER BY ${roomOrders.createdAt} DESC
	LIMIT 1
)`;

const relatedOrderIdAtEvent = sql<string | null>`(
	SELECT ${roomOrders.id}
	FROM ${roomOrders}
	WHERE ${relatedOrderMatchCondition}
	ORDER BY ${roomOrders.createdAt} DESC
	LIMIT 1
)`;

const relatedOrderStartTimeAtEvent = sql<Date | null>`(
	SELECT ${roomOrders.startTime}
	FROM ${roomOrders}
	WHERE ${relatedOrderMatchCondition}
	ORDER BY ${roomOrders.createdAt} DESC
	LIMIT 1
)`;

const relatedOrderEndTimeAtEvent = sql<Date | null>`(
	SELECT ${roomOrders.endTime}
	FROM ${roomOrders}
	WHERE ${relatedOrderMatchCondition}
	ORDER BY ${roomOrders.createdAt} DESC
	LIMIT 1
)`;

const supersededByEventId = sql<string | null>`(
	SELECT superseding.id
	FROM guard_face_appearances AS superseding
	WHERE superseding.supersedes_event_id = ${guardFaceAppearances.id}
	LIMIT 1
)`;
const displayEventType = sql<string>`CASE
	WHEN ${guardFaceAppearances.eventType} = 'unknown' THEN ${guardFaceAppearances.direction}
	WHEN ${guardFaceAppearances.eventType} = 'appeared' THEN 'in'
	ELSE ${guardFaceAppearances.eventType}
END`;

/** Role shown in the Role column; unidentified members are "unknown". */
const displayUserRole = sql<string | null>`CASE
	WHEN ${guardFaceAppearances.userId} IS NULL THEN ${UNKNOWN_ROLE}
	ELSE ${users.role}
END`;

function inEventCondition(): SQL {
	return or(
		eq(guardFaceAppearances.eventType, 'in'),
		eq(guardFaceAppearances.eventType, 'appeared'),
		and(eq(guardFaceAppearances.eventType, 'unknown'), eq(guardFaceAppearances.direction, 'in'))
	)!;
}

function outEventCondition(): SQL {
	return or(
		eq(guardFaceAppearances.eventType, 'out'),
		and(eq(guardFaceAppearances.eventType, 'unknown'), eq(guardFaceAppearances.direction, 'out'))
	)!;
}

const ORDER_STATUS_LABELS: Record<(typeof ROOM_ORDER_STATUSES)[number], string> = {
	pending: 'Pending',
	approved: 'Approved',
	cancelled: 'Cancelled',
	rejected: 'Rejected',
	expired: 'Expired'
};

function orderStatusMatchesLabel(status: string, needle: string): boolean {
	const label = ORDER_STATUS_LABELS[status as keyof typeof ORDER_STATUS_LABELS] ?? status;
	return (
		label.toLowerCase().includes(needle.toLowerCase()) ||
		status.toLowerCase().includes(needle.toLowerCase())
	);
}

function eventTypeMatchesLabel(eventType: string, needle: string): boolean {
	const label = EVENT_TYPE_LABELS[eventType] ?? eventType;

	return label.toLowerCase().includes(needle.toLowerCase());
}

const displayUsername = sql<string>`coalesce(${users.username}, 'Unknown')`;

const joinedCameraName = sql<string>`coalesce(nullif(trim(${guardCameras.name}), ''), ${guardCameras.deviceAddress})`;

const joinedCameraAddress = sql<string>`${guardCameras.deviceAddress} || ':' || ${guardCameras.sdkPort}::text`;

const cameraNameExpr = sql<string>`coalesce(nullif(trim(${guardFaceAppearances.cameraName}), ''), ${joinedCameraName}, ${guardFaceAppearances.cameraId})`;

const cameraAddressExpr = sql<string>`coalesce(nullif(trim(${guardFaceAppearances.cameraAddress}), ''), ${joinedCameraAddress}, ${guardFaceAppearances.cameraId})`;

function buildSearchCondition(search: string | undefined): SQL | undefined {
	const trimmed = search?.trim();

	if (!trimmed) return undefined;

	const term = `%${trimmed}%`;

	const parts: SQL[] = [
		ilike(displayUsername, term),

		ilike(guardFaceAppearances.cameraName, term),

		ilike(guardFaceAppearances.cameraAddress, term),

		ilike(guardCameras.name, term),

		ilike(guardCameras.deviceAddress, term),

		ilike(sql`${guardCameras.sdkPort}::text`, term),

		ilike(cameraAddressExpr, term),

		ilike(displayEventType, term),

		ilike(displayUserRole, term),

		ilike(sql`${guardFaceAppearances.similarity}::text`, term),

		ilike(sql`${guardFaceAppearances.occurredAt}::text`, term),

		ilike(sql`coalesce((${orderStatusAtEvent}), '')`, term)
	];

	for (const status of ROOM_ORDER_STATUSES) {
		if (orderStatusMatchesLabel(status, trimmed)) {
			parts.push(sql`${orderStatusAtEvent} = ${status}`);
		}
	}

	if (eventTypeMatchesLabel('in', trimmed)) {
		parts.push(inEventCondition());
	}
	if (eventTypeMatchesLabel('out', trimmed)) {
		parts.push(outEventCondition());
	}
	if (eventTypeMatchesLabel('appeared', trimmed)) {
		parts.push(inEventCondition());
	}
	if (trimmed.toLowerCase() === 'unknown' || trimmed.toLowerCase().includes('unknown')) {
		parts.push(isNull(guardFaceAppearances.userId));
	}

	return or(...parts);
}

function resolveEventTypeFilterValue(value: string): string {
	const trimmed = value.trim();
	const lower = trimmed.toLowerCase();

	if (lower === 'in') return 'in';
	if (lower === 'out') return 'out';

	return trimmed;
}

function resolveOrderStatusFilterValue(value: string): string | null | undefined {
	const trimmed = value.trim().toLowerCase();

	if (trimmed === '' || trimmed === 'n/a' || trimmed === 'na') return null;

	for (const status of ROOM_ORDER_STATUSES) {
		if (trimmed === status) return status;
		if (ORDER_STATUS_LABELS[status].toLowerCase() === trimmed) return status;
	}

	return undefined;
}

function buildOrderStatusFilterCondition(
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const resolved = resolveOrderStatusFilterValue(String(value));

	if (comparator === 'eq') {
		if (resolved === undefined) return undefined;
		if (resolved === null) return isNull(orderStatusAtEvent);
		return sql`${orderStatusAtEvent} = ${resolved}`;
	}

	if (comparator === 'contains') {
		const text = String(value).trim().toLowerCase();
		if (!text) return undefined;

		if (text.includes('n/a') || text === 'na') {
			return isNull(orderStatusAtEvent);
		}

		for (const status of ROOM_ORDER_STATUSES) {
			if (status.includes(text) || ORDER_STATUS_LABELS[status].toLowerCase().includes(text)) {
				return sql`${orderStatusAtEvent} = ${status}`;
			}
		}

		return ilike(sql`coalesce((${orderStatusAtEvent}), '')`, `%${text}%`);
	}

	return undefined;
}

function buildEventTypeFilterCondition(
	comparator: ColumnFilterComparator,

	value: string | number
): SQL | undefined {
	const text = resolveEventTypeFilterValue(String(value));

	if (comparator === 'eq') {
		if (text === 'in') return inEventCondition();
		if (text === 'out') return outEventCondition();
		return eq(displayEventType, text);
	}

	if (comparator === 'contains') {
		const lower = text.toLowerCase();
		if (lower === 'in' || lower === 'appeared') {
			return inEventCondition();
		}
		if (lower === 'out') {
			return outEventCondition();
		}

		return ilike(displayEventType, `%${text}%`);
	}

	return undefined;
}

/** Column filter values are percentages (0–100), matching the UI display. Stored values are 0–1. */
function buildSimilarityFilterCondition(
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const percent = Number(value);
	if (!Number.isFinite(percent)) return undefined;

	const decimal = percent / 100;

	if (comparator === 'eq') {
		const roundedPercent = Math.round(percent * 10) / 10;
		return sql`round((${guardFaceAppearances.similarity} * 100)::numeric, 1) = ${roundedPercent}`;
	}

	if (comparator === 'gte') return gte(guardFaceAppearances.similarity, decimal);
	if (comparator === 'lte') return lte(guardFaceAppearances.similarity, decimal);

	return undefined;
}

function buildColumnFilterCondition(filter: InOutColumnFilter): SQL | undefined {
	const { column, comparator, value } = filter;

	switch (column) {
		case 'username': {
			const text = String(value);

			if (comparator === 'eq') {
				if (text.toLowerCase() === 'unknown') {
					return isNull(guardFaceAppearances.userId);
				}
				return eq(users.username, text);
			}

			if (comparator === 'contains') return ilike(displayUsername, `%${text}%`);

			break;
		}

		case 'role': {
			const text = String(value).trim().toLowerCase();

			if (comparator === 'eq') {
				if (text === UNKNOWN_ROLE) {
					return isNull(guardFaceAppearances.userId);
				}
				if (text === 'admin' || text === 'staff' || text === 'user') {
					return and(isNotNull(guardFaceAppearances.userId), eq(users.role, text));
				}
				return undefined;
			}

			if (comparator === 'contains') {
				if (text.includes(UNKNOWN_ROLE)) {
					return isNull(guardFaceAppearances.userId);
				}
				return ilike(displayUserRole, `%${text}%`);
			}

			break;
		}

		case 'cameraId': {
			const text = String(value);

			if (comparator === 'eq') return eq(guardFaceAppearances.cameraId, text);

			if (comparator === 'contains') return ilike(guardFaceAppearances.cameraId, `%${text}%`);

			break;
		}

		case 'cameraAddress': {
			const text = String(value);

			if (comparator === 'eq') return eq(cameraAddressExpr, text);

			if (comparator === 'contains') {
				return or(
					ilike(guardFaceAppearances.cameraName, `%${text}%`),
					ilike(guardFaceAppearances.cameraAddress, `%${text}%`),
					ilike(guardCameras.name, `%${text}%`),
					ilike(guardCameras.deviceAddress, `%${text}%`),
					ilike(sql`${guardCameras.sdkPort}::text`, `%${text}%`),
					ilike(cameraAddressExpr, `%${text}%`)
				);
			}

			break;
		}

		case 'direction':
		case 'eventType':
			return buildEventTypeFilterCondition(comparator, value);

		case 'recognitionStatus': {
			const text = String(value).trim().toUpperCase();

			if (comparator === 'eq') {
				return eq(guardFaceAppearances.recognitionStatus, text);
			}

			if (comparator === 'contains') {
				return ilike(guardFaceAppearances.recognitionStatus, `%${text}%`);
			}

			break;
		}

		case 'orderStatus':
			return buildOrderStatusFilterCondition(comparator, value);

		case 'similarity': {
			return buildSimilarityFilterCondition(comparator, value);
		}

		case 'occurredAt': {
			const text = String(value);

			const expr = sql`${guardFaceAppearances.occurredAt}::text`;

			if (comparator === 'eq') return sql`${expr} = ${text}`;

			if (comparator === 'contains') return ilike(expr, `%${text}%`);

			break;
		}
	}

	return undefined;
}

function buildWhereClause(options: ListInOutOptions): SQL | undefined {
	const conditions: SQL[] = [];

	const userId = options.userId?.trim();
	if (userId) {
		conditions.push(eq(guardFaceAppearances.userId, userId));
	}

	const roomId = options.roomId?.trim();
	if (roomId) {
		conditions.push(eq(guardFaceAppearances.roomId, roomId));
	}

	const searchCondition = buildSearchCondition(options.search);

	if (searchCondition) conditions.push(searchCondition);

	conditions.push(
		...collectColumnFilterConditions(options.columnFilters, buildColumnFilterCondition)
	);

	return conditions.length ? and(...conditions) : undefined;
}

export const inOutEventsService = {
	async assertUserProfileImageReadable(
		targetUserId: string,
		requestUserId: string,
		role: string
	): Promise<void> {
		if (role !== 'admin' && role !== 'staff' && targetUserId !== requestUserId) {
			throw forbidden('You cannot view this profile photo');
		}

		const status = await faceRegistrationService.getStatus(targetUserId);
		if (!status.registered) {
			throw notFound('Profile photo not found');
		}
	},

	async list(options: ListInOutOptions = {}): Promise<PaginatedInOutList> {
		await purgeExpiredInOutRecords();

		const { limit, offset } = clampListPagination(options);

		const sortOrder = options.sortOrder ?? 'desc';

		const whereClause = buildWhereClause(options);

		const countQuery = db

			.select({ count: sql<number>`count(*)` })

			.from(guardFaceAppearances)

			.leftJoin(users, eq(guardFaceAppearances.userId, users.id))

			.leftJoin(guardCameras, eq(guardFaceAppearances.cameraId, guardCameras.id));

		const countResult = whereClause ? await countQuery.where(whereClause) : await countQuery;

		const total = Number(countResult[0]?.count ?? 0);

		const sortColumnMap: Record<InOutListSortField, SQL> = {
			username: displayUsername,

			role: displayUserRole,

			cameraAddress: cameraAddressExpr,

			direction: sql`${guardFaceAppearances.direction}`,

			eventType: sql`${guardFaceAppearances.direction}`,

			recognitionStatus: sql`${guardFaceAppearances.recognitionStatus}`,

			orderStatus: orderStatusAtEvent,

			similarity: sql`${guardFaceAppearances.similarity}`,

			occurredAt: sql`${guardFaceAppearances.occurredAt}`
		};

		const sortCol = options.sortBy ? sortColumnMap[options.sortBy] : sortColumnMap.occurredAt;

		const sortDirection = sortOrder === 'asc' ? sql`ASC` : sql`DESC`;

		const orderBy =
			options.sortBy === 'cameraAddress'
				? [sql`${sortCol} ${sortDirection} NULLS LAST`, asc(guardFaceAppearances.id)]
				: [sql`${sortCol} ${sortDirection} NULLS LAST`, asc(guardFaceAppearances.id)];

		const itemsQuery = db

			.select({
				id: guardFaceAppearances.id,

				faceRegistryId: guardFaceAppearances.faceRegistryId,

				userId: guardFaceAppearances.userId,

				username: displayUsername,

				userRole: displayUserRole,

				userEmail: users.email,

				userBirthday: users.birthday,

				userJob: users.job,

				userPosition: users.position,

				userFaceRegisteredAt: users.faceRegisteredAt,

				roomId: guardFaceAppearances.roomId,

				roomName: guardRooms.name,

				cameraId: guardFaceAppearances.cameraId,

				cameraName: cameraNameExpr,

				cameraAddress: cameraAddressExpr,

				direction: guardFaceAppearances.direction,

				eventType: guardFaceAppearances.eventType,

				recognitionStatus: guardFaceAppearances.recognitionStatus,

				similarity: guardFaceAppearances.similarity,

				orderStatus: orderStatusAtEvent,

				approved: guardFaceAppearances.approved,

				supersedesEventId: guardFaceAppearances.supersedesEventId,

				supersededByEventId,

				relatedOrderId: relatedOrderIdAtEvent,

				relatedOrderStatus: orderStatusAtEvent,

				relatedOrderStartTime: relatedOrderStartTimeAtEvent,

				relatedOrderEndTime: relatedOrderEndTimeAtEvent,

				hasFaceImage: guardFaceAppearances.hasFaceImage,

				frameImageWidth: frameEventImages.width,

				frameImageHeight: frameEventImages.height,

				frameStoragePath: frameEventImages.storagePath,

				faceCropWidth: cropEventImages.width,

				faceCropHeight: cropEventImages.height,

				cropStoragePath: cropEventImages.storagePath,

				occurredAt: guardFaceAppearances.occurredAt
			})

			.from(guardFaceAppearances)

			.leftJoin(users, eq(guardFaceAppearances.userId, users.id))

			.leftJoin(guardCameras, eq(guardFaceAppearances.cameraId, guardCameras.id))

			.innerJoin(guardRooms, eq(guardFaceAppearances.roomId, guardRooms.id))

			.leftJoin(
				frameEventImages,
				and(
					eq(frameEventImages.eventId, guardFaceAppearances.id),
					eq(frameEventImages.imageType, 'event_frame')
				)
			)

			.leftJoin(
				cropEventImages,
				and(
					eq(cropEventImages.eventId, guardFaceAppearances.id),
					eq(cropEventImages.imageType, 'face_crop')
				)
			)

			.orderBy(...orderBy)

			.limit(limit)

			.offset(offset);

		const items = whereClause ? await itemsQuery.where(whereClause) : await itemsQuery;

		return {
			items: items.map((row) => {
				const hasFrameImage =
					row.frameImageWidth != null &&
					row.frameImageHeight != null &&
					inOutFaceImagesService.imageFileExists(row.frameStoragePath);
				const hasFaceCrop =
					row.faceCropWidth != null &&
					row.faceCropHeight != null &&
					inOutFaceImagesService.imageFileExists(row.cropStoragePath);
				const thumbnailUrl = hasFrameImage
					? inOutFaceImagesService.faceImageApiPath(row.id, 'event_frame')
					: hasFaceCrop
						? inOutFaceImagesService.faceImageApiPath(row.id, 'face_crop')
						: null;
				const faceImageUrl = hasFaceCrop
					? inOutFaceImagesService.faceImageApiPath(row.id, 'face_crop')
					: null;
				const frameImageUrl = hasFrameImage
					? inOutFaceImagesService.faceImageApiPath(row.id, 'event_frame')
					: null;
				const userProfileImageUrl =
					row.userId && row.userFaceRegisteredAt ? userProfileImageApiPath(row.userId) : null;

				return {
					id: row.id,
					faceRegistryId: row.faceRegistryId,
					userId: row.userId,
					username: row.username,
					userRole: row.userRole,
					userEmail: row.userEmail,
					userBirthday: row.userBirthday,
					userJob: row.userJob,
					userPosition: row.userPosition,
					userProfileImageUrl,
					roomId: row.roomId,
					roomName: row.roomName,
					cameraId: row.cameraId,
					cameraName: row.cameraName,
					cameraAddress: row.cameraAddress,
					direction: row.direction,
					eventType: row.eventType,
					recognitionStatus: row.recognitionStatus,
					isIdentified: row.recognitionStatus === 'IDENTIFIED' && row.userId != null,
					similarity: row.similarity,
					orderStatus: row.orderStatus,
					approved: row.approved,
					supersedesEventId: row.supersedesEventId,
					supersededByEventId: row.supersededByEventId,
					relatedOrderId: row.relatedOrderId,
					relatedOrderStatus: row.relatedOrderStatus,
					relatedOrderStartTime: row.relatedOrderStartTime,
					relatedOrderEndTime: row.relatedOrderEndTime,
					faceImageUrl,
					frameImageUrl,
					thumbnailUrl,
					imageWidth: row.frameImageWidth ?? row.faceCropWidth ?? null,
					imageHeight: row.frameImageHeight ?? row.faceCropHeight ?? null,
					occurredAt: row.occurredAt
				};
			}),

			pagination: buildPagination({
				total,

				limit,

				offset,

				itemCount: items.length
			})
		};
	}
};
