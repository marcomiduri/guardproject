import type { WebSocket } from 'ws';
import type { HazardDetectedPayload } from '@/types/guard-events.js';
import { guardHazardEventsService } from '@/services/guard-hazard-events.js';
import { guardRoomsService } from '@/services/guard-rooms.js';
import { roomOrdersService } from '@/services/room-orders.js';
import { logger } from '@/utils/logger.js';

export type RoomOccupancyUpdate = {
	roomId: string;
	currentCount: number;
	maxMembers: number;
	updatedAt: string;
};

export type RoomEntryEvent = {
	type: 'room-entry';
	id: string;
	userName: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	currentRoomCount: number;
	maxMembers: number;
	occurredAt: string;
	approved: boolean;
};

export type FaceIdentifiedEvent = {
	type: 'face-identified';
	id: string;
	userId: string;
	userName: string;
	userRole: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	direction: 'in' | 'out';
	approved: boolean | null;
	similarity: number | null;
	occurredAt: string;
	currentRoomCount: number | null;
};

export type RoomOrderCreatedEvent = {
	type: 'room-order-created';
	id: string;
	userId: string;
	userName: string;
	roomId: string;
	roomName: string;
	startTime: string;
	endTime: string;
	createdAt: string;
};

export type RoomOrderUpdatedEvent = {
	type: 'room-order-updated';
	id: string;
	userId: string;
	userName: string;
	roomId: string;
	roomName: string;
	startTime: string;
	endTime: string;
	updatedAt: string;
};

export type RoomOrderReviewedEvent = {
	type: 'room-order-reviewed';
	id: string;
	userId: string;
	roomId: string;
	roomName: string;
	startTime: string;
	endTime: string;
	status: 'approved' | 'rejected';
	updatedAt: string;
};

export type UnknownRoomEntryEvent = {
	type: 'unknown-room-entry';
	id: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	direction: 'in' | 'out';
	trackId: number | null;
	occurredAt: string;
};

export type HazardDetectedEvent = {
	type: 'hazard-detected';
} & HazardDetectedPayload;

export type HazardUpdatedEvent = {
	type: 'hazard-updated';
	id: string;
	eventId: string;
	roomId: string;
	status: string;
	updatedAt: string;
	updatedBy: string;
};

export type FaceEventCorrectedEvent = {
	type: 'face-event-corrected';
	id: string;
	eventId: string;
	supersedesEventId: string;
	userId: string;
	userName: string;
	approved: boolean | null;
	direction: 'in' | 'out';
	occurredAt: string;
};

export type InOutEventMessage = {
	type: 'in-out-event';
	roomId: string;
	eventId: string;
	userId: string | null;
	currentCount: number;
	maxMembers: number;
};

export type PendingOrdersCountMessage = {
	type: 'pending-orders-count';
	count: number;
};

export type RealtimeMessage =
	| {
			type: 'room-occupancy-snapshot';
			rooms: RoomOccupancyUpdate[];
	  }
	| {
			type: 'hazard-detected-snapshot';
			hazards: Array<Omit<HazardDetectedEvent, 'type'>>;
	  }
	| ({
			type: 'room-occupancy';
	  } & RoomOccupancyUpdate)
	| RoomEntryEvent
	| FaceIdentifiedEvent
	| RoomOrderCreatedEvent
	| RoomOrderUpdatedEvent
	| RoomOrderReviewedEvent
	| UnknownRoomEntryEvent
	| HazardDetectedEvent
	| HazardUpdatedEvent
	| FaceEventCorrectedEvent
	| InOutEventMessage
	| PendingOrdersCountMessage;

type Client = {
	ws: WebSocket;
	userId: string;
	role: string;
};

class RealtimeHub {
	private clients = new Set<Client>();

	addClient(client: Client): void {
		this.clients.add(client);
	}

	removeClient(ws: WebSocket): void {
		for (const client of this.clients) {
			if (client.ws === ws) {
				this.clients.delete(client);
				break;
			}
		}
	}

	async sendOccupancySnapshot(ws: WebSocket): Promise<void> {
		if (ws.readyState !== ws.OPEN) {
			return;
		}

		const rooms = await guardRoomsService.listSummaries();
		const payload: RealtimeMessage = {
			type: 'room-occupancy-snapshot',
			rooms: rooms.map((room) => ({
				roomId: room.id,
				currentCount: room.currentCount,
				maxMembers: room.maxMembers,
				updatedAt: new Date().toISOString()
			}))
		};

		try {
			ws.send(JSON.stringify(payload));
		} catch (err) {
			logger.error('[realtime] failed to send occupancy snapshot', err);
		}
	}

	async sendPendingOrdersCountSnapshot(ws: WebSocket): Promise<void> {
		if (ws.readyState !== ws.OPEN) {
			return;
		}

		try {
			const count = await roomOrdersService.countPending();
			ws.send(
				JSON.stringify({ type: 'pending-orders-count', count } satisfies PendingOrdersCountMessage)
			);
		} catch (err) {
			logger.error('[realtime] failed to send pending orders count snapshot', err);
		}
	}

	async sendHazardSnapshot(ws: WebSocket): Promise<void> {
		if (ws.readyState !== ws.OPEN) {
			return;
		}

		try {
			const hazards = await guardHazardEventsService.listActiveAlerts();
			const payload: RealtimeMessage = {
				type: 'hazard-detected-snapshot',
				hazards: hazards.map((hazard) => serializeHazardPayload(hazard))
			};
			ws.send(JSON.stringify(payload));
		} catch (err) {
			logger.error('[realtime] failed to send hazard snapshot', err);
		}
	}

	async sendInitialSnapshots(ws: WebSocket, role: string): Promise<void> {
		await this.sendOccupancySnapshot(ws);
		if (role === 'admin' || role === 'staff') {
			await this.sendHazardSnapshot(ws);
		}
		if (role === 'admin') {
			await this.sendPendingOrdersCountSnapshot(ws);
		}
	}

	publishRoomOccupancy(update: RoomOccupancyUpdate): void {
		this.broadcast({
			type: 'room-occupancy',
			...update
		});
	}

	publishRoomEntry(event: Omit<RoomEntryEvent, 'type'>): void {
		this.broadcast({
			type: 'room-entry',
			...event
		});
	}

	publishFaceIdentified(event: Omit<FaceIdentifiedEvent, 'type'>): void {
		this.broadcastToStaffAndAdmins({
			type: 'face-identified',
			...event
		});
	}

	publishRoomOrderCreated(event: Omit<RoomOrderCreatedEvent, 'type'>): void {
		this.broadcastToAdmins({
			type: 'room-order-created',
			...event
		});
	}

	publishRoomOrderUpdated(event: Omit<RoomOrderUpdatedEvent, 'type'>): void {
		this.broadcastToAdmins({
			type: 'room-order-updated',
			...event
		});
	}

	publishRoomOrderReviewed(event: Omit<RoomOrderReviewedEvent, 'type'>): void {
		this.broadcastToUser(event.userId, {
			type: 'room-order-reviewed',
			...event
		});
	}

	publishPendingOrdersCount(count: number): void {
		this.broadcastToAdmins({
			type: 'pending-orders-count',
			count
		});
	}

	publishUnknownRoomEntry(event: Omit<UnknownRoomEntryEvent, 'type'>): void {
		this.broadcastToStaffAndAdmins({
			type: 'unknown-room-entry',
			...event
		});
	}

	publishHazardDetected(event: HazardDetectedPayload): void {
		this.broadcastToStaffAndAdmins({
			type: 'hazard-detected',
			...event
		});
	}

	publishHazardUpdated(event: Omit<HazardUpdatedEvent, 'type'>): void {
		this.broadcastToStaffAndAdmins({
			type: 'hazard-updated',
			...event
		});
	}

	publishFaceEventCorrected(event: Omit<FaceEventCorrectedEvent, 'type'>): void {
		this.broadcastToStaffAndAdmins({
			type: 'face-event-corrected',
			...event
		});
	}

	publishInOutEvent(event: Omit<InOutEventMessage, 'type'>): void {
		this.broadcast({
			type: 'in-out-event',
			...event
		});
	}

	private broadcastToStaffAndAdmins(message: RealtimeMessage): void {
		const payload = JSON.stringify(message);

		for (const client of this.clients) {
			if (client.role !== 'admin' && client.role !== 'staff') {
				continue;
			}

			if (client.ws.readyState !== client.ws.OPEN) {
				this.clients.delete(client);
				continue;
			}

			try {
				client.ws.send(payload);
			} catch {
				this.clients.delete(client);
			}
		}
	}

	private broadcastToUser(userId: string, message: RealtimeMessage): void {
		const normalizedUserId = userId.trim();
		if (!normalizedUserId) return;

		const payload = JSON.stringify(message);

		for (const client of this.clients) {
			if (client.userId !== normalizedUserId) {
				continue;
			}

			if (client.ws.readyState !== client.ws.OPEN) {
				this.clients.delete(client);
				continue;
			}

			try {
				client.ws.send(payload);
			} catch {
				this.clients.delete(client);
			}
		}
	}

	private broadcastToAdmins(message: RealtimeMessage): void {
		const payload = JSON.stringify(message);

		for (const client of this.clients) {
			if (client.role !== 'admin') {
				continue;
			}

			if (client.ws.readyState !== client.ws.OPEN) {
				this.clients.delete(client);
				continue;
			}

			try {
				client.ws.send(payload);
			} catch {
				this.clients.delete(client);
			}
		}
	}

	private broadcast(message: RealtimeMessage): void {
		const payload = JSON.stringify(message);

		for (const client of this.clients) {
			if (client.ws.readyState !== client.ws.OPEN) {
				this.clients.delete(client);
				continue;
			}

			try {
				client.ws.send(payload);
			} catch {
				this.clients.delete(client);
			}
		}
	}
}

function serializeHazardPayload(
	hazard: Awaited<ReturnType<typeof guardHazardEventsService.listActiveAlerts>>[number]
): Omit<HazardDetectedEvent, 'type'> {
	return {
		id: hazard.id,
		roomId: hazard.roomId,
		roomName: hazard.roomName,
		cameraId: hazard.cameraId,
		cameraName: hazard.cameraName,
		hazardType: hazard.hazardType,
		confidence: hazard.confidence,
		detections: hazard.detections,
		status: hazard.status,
		source: hazard.source,
		testScenario: hazard.testScenario,
		occurredAt: hazard.occurredAt.toISOString(),
		snapshotUrl: hazard.snapshotUrl
	};
}

export const realtimeHub = new RealtimeHub();
