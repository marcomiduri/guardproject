import bcrypt from 'bcryptjs';
import { randomUUID } from 'node:crypto';
import { count, eq } from 'drizzle-orm';
import { db } from '@/db/index.js';
import { users, type User, type UserRole } from '@/db/schema/auth.js';
import { BCRYPT_SALT_ROUNDS } from '@/constants/auth.js';
import { toAuthUser } from '@/lib/auth/map-user.js';
import type { AuthTokenResponse, AuthUser } from '@/types/auth.js';
import { badRequest, unauthorized } from '@/services/errors.js';
import { signAccessToken } from '@/services/jwt.js';

/** First account is admin; later sign-ups are standard users. */
async function resolveRegistrationRole(): Promise<UserRole> {
	const [row] = await db.select({ total: count() }).from(users);
	return (row?.total ?? 0) === 0 ? 'admin' : 'user';
}

async function buildTokenResponse(user: User): Promise<AuthTokenResponse> {
	const accessToken = await signAccessToken({
		sub: user.id,
		email: user.email,
		role: user.role
	});

	return { accessToken, user: toAuthUser(user) };
}

export const authService = {
	async register(input: {
		username: string;
		email: string;
		password: string;
	}): Promise<AuthTokenResponse> {
		const email = input.email.trim().toLowerCase();
		const username = input.username.trim();

		const existing = await db.query.users.findFirst({
			where: eq(users.email, email),
			columns: { id: true }
		});

		if (existing) {
			throw badRequest('An account with this email already exists');
		}

		const passwordHash = await bcrypt.hash(input.password, BCRYPT_SALT_ROUNDS);
		const role = await resolveRegistrationRole();

		const [user] = await db
			.insert(users)
			.values({
				id: randomUUID(),
				username,
				email,
				passwordHash,
				role
			})
			.returning();

		return buildTokenResponse(user);
	},

	async login(input: { email: string; password: string }): Promise<AuthTokenResponse> {
		const email = input.email.trim().toLowerCase();

		const user = await db.query.users.findFirst({
			where: eq(users.email, email)
		});

		if (!user) {
			throw unauthorized('Invalid email or password');
		}

		const valid = await bcrypt.compare(input.password, user.passwordHash);
		if (!valid) {
			throw unauthorized('Invalid email or password');
		}

		return buildTokenResponse(user);
	},

	async getUserById(id: string): Promise<AuthUser> {
		const user = await db.query.users.findFirst({
			where: eq(users.id, id)
		});

		if (!user) {
			throw unauthorized('Invalid token');
		}

		return toAuthUser(user);
	}
};
