import { randomUUID } from 'node:crypto';
import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join, sep, dirname } from 'node:path';
import { and, eq } from 'drizzle-orm';
import type { NodePgDatabase } from 'drizzle-orm/node-postgres';
import { env } from '@/config/env.js';
import { db } from '@/db/index.js';
import {
	guardFaceAppearances,
	inOutEventImages,
	type InOutEventImageType
} from '@/db/schema/guard.js';
import { notFound } from '@/services/errors.js';
import { readJpegDimensions } from '@/utils/jpeg-dimensions.js';
import { toSafePathSegment } from '@/utils/safe-path-segment.js';

const IN_OUT_FACES_ROOT = join(env.UPLOADS_DIR, 'in-out-faces');
const LEGACY_FLAT_DIR = IN_OUT_FACES_ROOT;
const MIN_IMAGE_BYTES = 32;
export const MAX_IN_OUT_FACE_IMAGE_BYTES = 5 * 1024 * 1024;

export type WrittenInOutFaceImage = {
	id: string;
	relativePath: string;
	absolutePath: string;
	mimeType: string;
	width: number;
	height: number;
	sizeBytes: number;
	imageType: InOutEventImageType;
};

type DbExecutor = Pick<NodePgDatabase, 'insert' | 'update'>;

function legacyFaceImagePath(eventId: string): string {
	return join(LEGACY_FLAT_DIR, `${eventId}.jpg`);
}

function absolutePathForRelative(relativePath: string): string {
	const normalized = relativePath.replace(/\\/g, '/');
	if (normalized.includes('..')) {
		throw new Error('Invalid storage path');
	}

	return join(env.UPLOADS_DIR, normalized);
}

function buildRelativeStoragePath(
	eventId: string,
	cameraId: string,
	occurredAt: Date,
	imageType: InOutEventImageType
): string {
	const year = String(occurredAt.getFullYear());
	const month = String(occurredAt.getMonth() + 1).padStart(2, '0');
	const day = String(occurredAt.getDate()).padStart(2, '0');
	const safeCameraId = toSafePathSegment(cameraId, 'camera');
	const safeEventId = toSafePathSegment(eventId, 'event');
	const suffix =
		imageType === 'face_crop' ? 'face' : imageType === 'event_frame' ? 'frame' : imageType;

	return join('in-out-faces', year, month, day, safeCameraId, `${safeEventId}_${suffix}.jpg`)
		.split(sep)
		.join('/');
}

function validateImageBuffer(buffer: Buffer, mimeType: string): void {
	if (buffer.length < MIN_IMAGE_BYTES) {
		throw new Error('Image data is too small');
	}

	if (buffer.length > MAX_IN_OUT_FACE_IMAGE_BYTES) {
		throw new Error('Image is too large (max 5 MB)');
	}

	const normalizedMime = mimeType.trim().toLowerCase();
	if (normalizedMime === 'image/jpeg' || normalizedMime === 'image/jpg') {
		if (buffer[0] !== 0xff || buffer[1] !== 0xd8) {
			throw new Error('faceImage must be a valid JPEG file');
		}
		return;
	}

	if (normalizedMime === 'image/png') {
		if (
			buffer.length < 8 ||
			buffer[0] !== 0x89 ||
			buffer[1] !== 0x50 ||
			buffer[2] !== 0x4e ||
			buffer[3] !== 0x47
		) {
			throw new Error('faceImage must be a valid PNG file');
		}
		return;
	}

	throw new Error('faceImage must be image/jpeg or image/png');
}

function readImageDimensions(buffer: Buffer, mimeType: string): { width: number; height: number } {
	const normalizedMime = mimeType.trim().toLowerCase();
	if (normalizedMime === 'image/png') {
		if (buffer.length < 24) {
			throw new Error('Unable to read PNG dimensions');
		}

		const width = buffer.readUInt32BE(16);
		const height = buffer.readUInt32BE(20);
		if (width > 0 && height > 0) {
			return { width, height };
		}

		throw new Error('Unable to read PNG dimensions');
	}

	const dimensions = readJpegDimensions(buffer);
	if (!dimensions) {
		throw new Error('Unable to read JPEG dimensions');
	}

	return dimensions;
}

async function ensureParentDir(absolutePath: string): Promise<void> {
	await mkdir(dirname(absolutePath), { recursive: true });
}

export const inOutFaceImagesService = {
	buildRelativeStoragePath,

	faceImageApiPath(eventId: string, imageType: InOutEventImageType = 'face_crop'): string {
		const trimmed = eventId.trim();
		return `/api/in-out-events/${encodeURIComponent(trimmed)}/image?type=${imageType}`;
	},

	legacyFaceImageApiPath(eventId: string): string {
		const trimmed = eventId.trim();
		return `/api/in-out/${encodeURIComponent(trimmed)}/face-image`;
	},

	async writeFaceImageFile(input: {
		eventId: string;
		cameraId: string;
		occurredAt: Date;
		imageBuffer: Buffer;
		mimeType: string;
		imageType?: InOutEventImageType;
	}): Promise<WrittenInOutFaceImage> {
		const imageType = input.imageType ?? 'face_crop';
		validateImageBuffer(input.imageBuffer, input.mimeType);

		const { width, height } = readImageDimensions(input.imageBuffer, input.mimeType);
		const relativePath = buildRelativeStoragePath(
			input.eventId,
			input.cameraId,
			input.occurredAt,
			imageType
		);
		const absolutePath = absolutePathForRelative(relativePath);

		await ensureParentDir(absolutePath);
		await writeFile(absolutePath, input.imageBuffer);

		return {
			id: randomUUID(),
			relativePath,
			absolutePath,
			mimeType:
				input.mimeType.trim().toLowerCase() === 'image/jpg'
					? 'image/jpeg'
					: input.mimeType.trim().toLowerCase(),
			width,
			height,
			sizeBytes: input.imageBuffer.length,
			imageType
		};
	},

	async deleteFileAt(absolutePath: string): Promise<void> {
		try {
			await unlink(absolutePath);
		} catch {
			// Ignore missing files.
		}
	},

	async insertImageMetadata(
		executor: DbExecutor,
		eventId: string,
		written: WrittenInOutFaceImage
	): Promise<void> {
		await executor.insert(inOutEventImages).values({
			id: written.id,
			eventId,
			imageType: written.imageType,
			storagePath: written.relativePath,
			mimeType: written.mimeType,
			width: written.width,
			height: written.height,
			sizeBytes: written.sizeBytes
		});

		await executor
			.update(guardFaceAppearances)
			.set({ hasFaceImage: true })
			.where(eq(guardFaceAppearances.id, eventId));
	},

	/** @deprecated Legacy JSON base64 path — prefer writeFaceImageFile + insertImageMetadata. */
	async save(eventId: string, imageBuffer: Buffer): Promise<void> {
		if (imageBuffer.length < MIN_IMAGE_BYTES) {
			return;
		}

		const [event] = await db
			.select({
				cameraId: guardFaceAppearances.cameraId,
				occurredAt: guardFaceAppearances.occurredAt
			})
			.from(guardFaceAppearances)
			.where(eq(guardFaceAppearances.id, eventId))
			.limit(1);

		if (!event) {
			throw notFound('In/out event not found');
		}

		const written = await this.writeFaceImageFile({
			eventId,
			cameraId: event.cameraId,
			occurredAt: event.occurredAt,
			imageBuffer,
			mimeType: 'image/jpeg'
		});

		await this.insertImageMetadata(db, eventId, written);
	},

	async read(eventId: string, imageType?: InOutEventImageType): Promise<Buffer> {
		if (imageType) {
			const [imageRow] = await db
				.select({
					storagePath: inOutEventImages.storagePath
				})
				.from(inOutEventImages)
				.where(
					and(eq(inOutEventImages.eventId, eventId), eq(inOutEventImages.imageType, imageType))
				)
				.limit(1);

			if (imageRow) {
				const absolutePath = absolutePathForRelative(imageRow.storagePath);
				if (existsSync(absolutePath)) {
					return readFile(absolutePath);
				}
			}

			throw notFound('Face snapshot not found');
		}

		const rows = await db
			.select({
				storagePath: inOutEventImages.storagePath,
				imageType: inOutEventImages.imageType
			})
			.from(inOutEventImages)
			.where(eq(inOutEventImages.eventId, eventId));

		const preferredTypes: InOutEventImageType[] = ['event_frame', 'face_crop'];
		for (const preferredType of preferredTypes) {
			const match = rows.find((row) => row.imageType === preferredType);
			if (!match) {
				continue;
			}

			const absolutePath = absolutePathForRelative(match.storagePath);
			if (existsSync(absolutePath)) {
				return readFile(absolutePath);
			}
		}

		const legacyPath = legacyFaceImagePath(eventId);
		if (existsSync(legacyPath)) {
			return readFile(legacyPath);
		}

		throw notFound('Face snapshot not found');
	},

	async readMimeType(eventId: string, imageType?: InOutEventImageType): Promise<string> {
		if (imageType) {
			const [imageRow] = await db
				.select({ mimeType: inOutEventImages.mimeType })
				.from(inOutEventImages)
				.where(
					and(eq(inOutEventImages.eventId, eventId), eq(inOutEventImages.imageType, imageType))
				)
				.limit(1);

			if (imageRow) {
				return imageRow.mimeType;
			}

			return 'image/jpeg';
		}

		const rows = await db
			.select({
				mimeType: inOutEventImages.mimeType,
				imageType: inOutEventImages.imageType
			})
			.from(inOutEventImages)
			.where(eq(inOutEventImages.eventId, eventId));

		const preferredTypes: InOutEventImageType[] = ['event_frame', 'face_crop'];
		for (const preferredType of preferredTypes) {
			const match = rows.find((row) => row.imageType === preferredType);
			if (match) {
				return match.mimeType;
			}
		}

		return 'image/jpeg';
	},

	async deleteStoredImagesForEvent(eventId: string): Promise<void> {
		const rows = await db
			.select({ storagePath: inOutEventImages.storagePath })
			.from(inOutEventImages)
			.where(eq(inOutEventImages.eventId, eventId));

		for (const row of rows) {
			await this.deleteFileAt(absolutePathForRelative(row.storagePath));
		}

		await this.deleteFileAt(legacyFaceImagePath(eventId));
	},

	async deleteStoredImage(eventId: string): Promise<void> {
		await this.deleteStoredImagesForEvent(eventId);
	},

	imageFileExists(relativePath: string | null | undefined): boolean {
		if (!relativePath?.trim()) return false;
		return existsSync(absolutePathForRelative(relativePath.trim()));
	},

	async assertReadableForUser(
		eventId: string,
		userId: string,
		role: string,
		imageType?: InOutEventImageType
	): Promise<void> {
		const [row] = await db
			.select({
				userId: guardFaceAppearances.userId,
				hasFaceImage: guardFaceAppearances.hasFaceImage
			})
			.from(guardFaceAppearances)
			.where(eq(guardFaceAppearances.id, eventId))
			.limit(1);

		if (!row) {
			throw notFound('Face snapshot not found');
		}

		if (role !== 'admin' && role !== 'staff' && row.userId !== userId) {
			throw notFound('Face snapshot not found');
		}

		if (imageType) {
			const [typedRow] = await db
				.select({ storagePath: inOutEventImages.storagePath })
				.from(inOutEventImages)
				.where(
					and(eq(inOutEventImages.eventId, eventId), eq(inOutEventImages.imageType, imageType))
				)
				.limit(1);

			if (typedRow && this.imageFileExists(typedRow.storagePath)) {
				return;
			}

			if (imageType === 'face_crop' && existsSync(legacyFaceImagePath(eventId))) {
				return;
			}

			if (typedRow) {
				await db
					.delete(inOutEventImages)
					.where(
						and(eq(inOutEventImages.eventId, eventId), eq(inOutEventImages.imageType, imageType))
					);
			}

			await this.syncHasFaceImageFlag(eventId);
			throw notFound('Face snapshot not found');
		}

		const [imageRow] = await db
			.select({ storagePath: inOutEventImages.storagePath })
			.from(inOutEventImages)
			.where(eq(inOutEventImages.eventId, eventId))
			.limit(1);

		if (imageRow && this.imageFileExists(imageRow.storagePath)) {
			return;
		}

		if (existsSync(legacyFaceImagePath(eventId))) {
			return;
		}

		await this.syncHasFaceImageFlag(eventId);
		throw notFound('Face snapshot not found');
	},

	async syncHasFaceImageFlag(eventId: string): Promise<void> {
		const rows = await db
			.select({ storagePath: inOutEventImages.storagePath })
			.from(inOutEventImages)
			.where(eq(inOutEventImages.eventId, eventId));

		const hasStoredImage =
			rows.some((row) => this.imageFileExists(row.storagePath)) ||
			existsSync(legacyFaceImagePath(eventId));

		await db
			.update(guardFaceAppearances)
			.set({ hasFaceImage: hasStoredImage })
			.where(eq(guardFaceAppearances.id, eventId));
	}
};
