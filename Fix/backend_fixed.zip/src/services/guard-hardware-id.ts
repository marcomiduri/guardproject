/**
 * Normalize the stable Guard installation hardware identifier.
 *
 * The backend uses the normalized value only to derive an installation identity
 * hash. Commercial license validation is intentionally owned by Guard itself.
 */
export function normalizeGuardHardwareId(value: string): string {
	let normalized = '';
	for (const character of value.toUpperCase()) {
		if ((character >= '0' && character <= '9') || (character >= 'A' && character <= 'F')) {
			normalized += character;
		}
	}
	return normalized;
}

export function guardHardwareIdFormatValid(normalized: string): boolean {
	return normalized.length === 16;
}
