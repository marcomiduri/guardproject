import type { GuardCamera } from '@/db/schema/guard.js';

export function formatCameraDisplayLabel(
	camera: Pick<GuardCamera, 'name' | 'deviceAddress'>,
	fallbackId?: string
): string {
	const name = camera.name.trim();
	if (name) return name;

	const address = camera.deviceAddress.trim();
	if (address) return address;

	return fallbackId?.trim() ?? '';
}

export function snapshotCameraFields(
	camera: Pick<GuardCamera, 'name' | 'deviceAddress' | 'sdkPort'>
): { cameraName: string; cameraAddress: string } {
	const deviceAddress = camera.deviceAddress.trim();
	const cameraName = formatCameraDisplayLabel(camera);
	const cameraAddress = `${deviceAddress}:${camera.sdkPort}`;

	return { cameraName, cameraAddress };
}
