import { AppError } from '@/services/errors.js';

export type ApiErrorBody = {
	error: {
		code: string;
		message: string;
		retryable: boolean;
	};
};

export function isRetryableHttpStatus(status: number): boolean {
	return status === 408 || status === 429 || status >= 500;
}

export function formatApiErrorBody(
	error: Pick<AppError, 'code' | 'message' | 'status' | 'retryable'>
): ApiErrorBody {
	return {
		error: {
			code: error.code,
			message: error.message,
			retryable: error.retryable ?? isRetryableHttpStatus(error.status)
		}
	};
}

export function formatUnknownErrorBody(
	status: number,
	message: string,
	code = 'INTERNAL_ERROR'
): ApiErrorBody {
	return {
		error: {
			code,
			message,
			retryable: isRetryableHttpStatus(status)
		}
	};
}
