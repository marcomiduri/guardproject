import { randomUUID } from 'node:crypto';
import { and, asc, count, eq, isNull, ne, or, sql } from 'drizzle-orm';
import { db } from '@/db/index.js';
import {
	GUARD_CAMERA_DIRECTIONS,
	GUARD_CAMERA_STATUSES,
	GUARD_CAMERA_TYPES,
	guardCameras,
	guardFaceAppearances,
	guardInstallations,
	type GuardCameraDirection,
	type GuardCameraStatus,
	type GuardCameraType
} from '@/db/schema/guard.js';
import { badRequest, forbidden, notFound } from '@/services/errors.js';
import { snapshotCameraFields } from '@/services/guard-camera-snapshot.js';
import { guardRoomsService } from '@/services/guard-rooms.js';

export const MAX_GUARD_CAMERAS_PER_ROOM = 4;

export type GuardCameraRecord = {
	id: string;
	roomId: string;
	installationId: string | null;
	clientCameraId: string | null;
	name: string;
	type: GuardCameraType;
	direction: GuardCameraDirection;
	deviceAddress: string;
	sdkPort: number;
	rtspPort: number;
	rtspUrl: string | null;
	username: string;
	password: string;
	channel: number;
	streamType: number;
	status: GuardCameraStatus;
	lastSeenAt: Date | null;
	sortOrder: number;
	createdAt: Date;
	updatedAt: Date;
};

export type CreateGuardCameraInput = {
	id?: string;
	roomId: string;
	installationId?: string | null;
	clientCameraId?: string | null;
	name?: string;
	type?: GuardCameraType;
	direction: GuardCameraDirection;
	deviceAddress: string;
	sdkPort?: number;
	rtspPort?: number;
	rtspUrl?: string | null;
	username?: string;
	password?: string;
	channel?: number;
	streamType?: number;
	sortOrder?: number;
};

export type UpdateGuardCameraInput = Partial<
	Omit<CreateGuardCameraInput, 'id' | 'roomId' | 'installationId'>
> & {
	roomId?: string;
	installationId?: string | null;
	status?: GuardCameraStatus;
};

export type GuardCameraSummary = {
	id: string;
	roomId: string;
	name: string;
	type: GuardCameraType;
	direction: GuardCameraDirection;
	status: GuardCameraStatus;
	sortOrder: number;
};

export type GuardCameraAccess = {
	installationId?: string;
	roomId?: string;
};

function mapCamera(row: typeof guardCameras.$inferSelect): GuardCameraRecord {
	return {
		id: row.id,
		roomId: row.roomId,
		installationId: row.installationId,
		clientCameraId: row.clientCameraId,
		name: row.name,
		type: row.type as GuardCameraType,
		direction: row.direction as GuardCameraDirection,
		deviceAddress: row.deviceAddress,
		sdkPort: row.sdkPort,
		rtspPort: row.rtspPort,
		rtspUrl: row.rtspUrl,
		username: row.username,
		password: row.password,
		channel: row.channel,
		streamType: row.streamType,
		status: row.status as GuardCameraStatus,
		lastSeenAt: row.lastSeenAt,
		sortOrder: row.sortOrder,
		createdAt: row.createdAt,
		updatedAt: row.updatedAt
	};
}

function toSummary(record: GuardCameraRecord): GuardCameraSummary {
	return {
		id: record.id,
		roomId: record.roomId,
		name: record.name,
		type: record.type,
		direction: record.direction,
		status: record.status,
		sortOrder: record.sortOrder
	};
}

function assertCameraType(value: string): GuardCameraType {
	if (!GUARD_CAMERA_TYPES.includes(value as GuardCameraType)) {
		throw badRequest(`type must be one of: ${GUARD_CAMERA_TYPES.join(', ')}`);
	}
	return value as GuardCameraType;
}

function assertDirection(value: string): GuardCameraDirection {
	if (!GUARD_CAMERA_DIRECTIONS.includes(value as GuardCameraDirection)) {
		throw badRequest(`direction must be one of: ${GUARD_CAMERA_DIRECTIONS.join(', ')}`);
	}
	return value as GuardCameraDirection;
}

function assertStatus(value: string): GuardCameraStatus {
	if (!GUARD_CAMERA_STATUSES.includes(value as GuardCameraStatus)) {
		throw badRequest(`status must be one of: ${GUARD_CAMERA_STATUSES.join(', ')}`);
	}
	return value as GuardCameraStatus;
}

function assertAccess(camera: GuardCameraRecord, access?: GuardCameraAccess): void {
	if (!access) return;
	// Guard is scoped to its connected room. Admin-created room cameras may have
	// a null installationId until connect claims them — room match is enough.
	if (access.roomId && camera.roomId !== access.roomId) {
		throw forbidden('Camera does not belong to this room');
	}
	if (
		access.installationId &&
		camera.installationId &&
		camera.installationId !== access.installationId &&
		!access.roomId
	) {
		throw forbidden('Camera does not belong to this Guard installation');
	}
}

async function assertInstallationRoom(installationId: string, roomId: string): Promise<void> {
	const installation = await db.query.guardInstallations.findFirst({
		where: eq(guardInstallations.id, installationId)
	});
	if (!installation) throw notFound('Guard installation not found');
	if (installation.roomId !== roomId) {
		throw badRequest('Camera room must match the Guard installation room');
	}
}

async function cameraCount(roomId: string): Promise<number> {
	const [row] = await db
		.select({ total: count() })
		.from(guardCameras)
		.where(eq(guardCameras.roomId, roomId));
	return Number(row?.total ?? 0);
}

function normalizeDeviceAddress(value: string): string {
	return value.trim().toLowerCase();
}

async function assertDeviceAddressAvailable(
	roomId: string,
	deviceAddress: string,
	excludedCameraId?: string
): Promise<void> {
	const normalized = normalizeDeviceAddress(deviceAddress);
	if (!normalized) return;

	const predicates = [
		eq(guardCameras.roomId, roomId),
		sql`lower(trim(${guardCameras.deviceAddress})) = ${normalized}`
	];
	if (excludedCameraId) predicates.push(ne(guardCameras.id, excludedCameraId));

	const [conflict] = await db
		.select({ id: guardCameras.id, name: guardCameras.name })
		.from(guardCameras)
		.where(and(...predicates))
		.limit(1);
	if (conflict) {
		throw badRequest(
			`The IP address is already used by '${conflict.name || conflict.id}'. Enter a different camera IP address.`
		);
	}
}

function insertValues(input: CreateGuardCameraInput, id: string, sortOrder: number, now: Date) {
	return {
		id,
		roomId: input.roomId,
		installationId: input.installationId ?? null,
		clientCameraId: input.clientCameraId?.trim() || null,
		name: input.name?.trim() ?? '',
		type: assertCameraType(input.type ?? 'hikvision'),
		direction: assertDirection(input.direction),
		deviceAddress: input.deviceAddress.trim(),
		sdkPort: input.sdkPort ?? 8000,
		rtspPort: input.rtspPort ?? 554,
		rtspUrl: input.rtspUrl?.trim() || null,
		username: input.username?.trim() || 'admin',
		password: input.password ?? '',
		channel: input.channel ?? 1,
		streamType: input.streamType ?? 0,
		status: 'unknown' as const,
		sortOrder,
		createdAt: now,
		updatedAt: now
	};
}

export const guardCamerasService = {
	async list(roomId?: string, installationId?: string): Promise<GuardCameraRecord[]> {
		const query = db
			.select()
			.from(guardCameras)
			.orderBy(asc(guardCameras.sortOrder), asc(guardCameras.createdAt));

		if (roomId && installationId) {
			return (
				await query.where(
					and(eq(guardCameras.roomId, roomId), eq(guardCameras.installationId, installationId))
				)
			).map(mapCamera);
		}
		if (roomId) return (await query.where(eq(guardCameras.roomId, roomId))).map(mapCamera);
		if (installationId) {
			return (await query.where(eq(guardCameras.installationId, installationId))).map(mapCamera);
		}
		return (await query).map(mapCamera);
	},

	async listSummaries(roomId?: string): Promise<GuardCameraSummary[]> {
		return (await this.list(roomId)).map(toSummary);
	},

	async getById(id: string, access?: GuardCameraAccess): Promise<GuardCameraRecord> {
		const [row] = await db.select().from(guardCameras).where(eq(guardCameras.id, id)).limit(1);
		if (!row) throw notFound('Camera not found');
		const record = mapCamera(row);
		assertAccess(record, access);
		return record;
	},

	async create(input: CreateGuardCameraInput): Promise<GuardCameraRecord> {
		await guardRoomsService.getById(input.roomId);
		if (input.installationId) await assertInstallationRoom(input.installationId, input.roomId);
		await assertDeviceAddressAvailable(input.roomId, input.deviceAddress);

		const total = await cameraCount(input.roomId);
		if (total >= MAX_GUARD_CAMERAS_PER_ROOM) {
			throw badRequest(`You can add up to ${MAX_GUARD_CAMERAS_PER_ROOM} cameras per room`);
		}

		const now = new Date();
		const id = input.id?.trim() || randomUUID();
		const [row] = await db
			.insert(guardCameras)
			.values(insertValues(input, id, input.sortOrder ?? total, now))
			.returning();
		return mapCamera(row);
	},

	async upsertForInstallation(
		installationId: string,
		roomId: string,
		input: Omit<CreateGuardCameraInput, 'installationId' | 'roomId'>
	): Promise<GuardCameraRecord> {
		await assertInstallationRoom(installationId, roomId);
		const clientCameraId = input.clientCameraId?.trim();
		if (!clientCameraId) throw badRequest('clientCameraId is required for installation cameras');

		let existing = await db.query.guardCameras.findFirst({
			where: and(
				eq(guardCameras.installationId, installationId),
				eq(guardCameras.roomId, roomId),
				eq(guardCameras.clientCameraId, clientCameraId)
			)
		});

		if (!existing && input.id?.trim()) {
			const candidate = await db.query.guardCameras.findFirst({
				where: eq(guardCameras.id, input.id.trim())
			});
			if (candidate) {
				if (candidate.roomId !== roomId) {
					// A camera ID from a previous room is a stale room-specific
					// mapping, not a request to move the historical camera record.
					// Create/find the current room mapping by clientCameraId instead.
					if (candidate.installationId && candidate.installationId !== installationId) {
						throw badRequest('Camera belongs to another Guard installation');
					}
				} else {
					if (candidate.installationId && candidate.installationId !== installationId) {
						throw badRequest('Camera belongs to another Guard installation');
					}
					existing = candidate;
				}
			}
		}

		const updateInput: UpdateGuardCameraInput = {
			installationId,
			clientCameraId,
			name: input.name,
			type: input.type,
			direction: input.direction,
			deviceAddress: input.deviceAddress,
			sdkPort: input.sdkPort,
			rtspPort: input.rtspPort,
			rtspUrl: input.rtspUrl,
			username: input.username,
			password: input.password,
			channel: input.channel,
			streamType: input.streamType,
			sortOrder: input.sortOrder
		};

		if (existing) return this.update(existing.id, updateInput);

		return this.create({
			...input,
			id: undefined,
			roomId,
			installationId,
			clientCameraId
		});
	},

	async update(
		id: string,
		input: UpdateGuardCameraInput,
		access?: GuardCameraAccess
	): Promise<GuardCameraRecord> {
		const existing = await this.getById(id, access);

		const targetRoomId = input.roomId ?? existing.roomId;
		const targetDeviceAddress = input.deviceAddress?.trim() ?? existing.deviceAddress;
		await assertDeviceAddressAvailable(targetRoomId, targetDeviceAddress, existing.id);

		const patch: Partial<typeof guardCameras.$inferInsert> = { updatedAt: new Date() };
		if (input.roomId !== undefined) {
			await guardRoomsService.getById(input.roomId);
			if (input.installationId ?? existing.installationId) {
				await assertInstallationRoom(
					input.installationId ?? existing.installationId!,
					input.roomId
				);
			}
			patch.roomId = input.roomId;
		}
		if (input.installationId !== undefined) patch.installationId = input.installationId;
		if (input.clientCameraId !== undefined)
			patch.clientCameraId = input.clientCameraId?.trim() || null;
		if (input.name !== undefined) patch.name = input.name.trim();
		if (input.type !== undefined) patch.type = assertCameraType(input.type);
		if (input.direction !== undefined) patch.direction = assertDirection(input.direction);
		if (input.deviceAddress !== undefined) patch.deviceAddress = input.deviceAddress.trim();
		if (input.sdkPort !== undefined) patch.sdkPort = input.sdkPort;
		if (input.rtspPort !== undefined) patch.rtspPort = input.rtspPort;
		if (input.rtspUrl !== undefined) patch.rtspUrl = input.rtspUrl?.trim() || null;
		if (input.username !== undefined) patch.username = input.username.trim();
		if (input.password !== undefined) patch.password = input.password;
		if (input.channel !== undefined) patch.channel = input.channel;
		if (input.streamType !== undefined) patch.streamType = input.streamType;
		if (input.sortOrder !== undefined) patch.sortOrder = input.sortOrder;
		if (input.status !== undefined) patch.status = assertStatus(input.status);

		const [row] = await db
			.update(guardCameras)
			.set(patch)
			.where(eq(guardCameras.id, id))
			.returning();
		return mapCamera(row);
	},

	async recordHeartbeat(
		id: string,
		status: GuardCameraStatus,
		access?: GuardCameraAccess,
		options?: { occurredAt?: Date }
	): Promise<GuardCameraRecord> {
		await this.getById(id, access);
		const parsedOccurredAt = options?.occurredAt;
		const lastSeenAt =
			parsedOccurredAt && !Number.isNaN(parsedOccurredAt.getTime()) ? parsedOccurredAt : new Date();
		const now = new Date();
		const [row] = await db
			.update(guardCameras)
			.set({ status: assertStatus(status), lastSeenAt, updatedAt: now })
			.where(eq(guardCameras.id, id))
			.returning();
		if (!row) throw notFound('Camera not found');
		if (row.installationId) {
			await db
				.update(guardInstallations)
				.set({ lastSeenAt, updatedAt: now })
				.where(eq(guardInstallations.id, row.installationId));
		}
		return mapCamera(row);
	},

	async remove(id: string, access?: GuardCameraAccess): Promise<void> {
		const camera = await this.getById(id, access);
		const { cameraName, cameraAddress } = snapshotCameraFields(camera);
		await db
			.update(guardFaceAppearances)
			.set({ cameraName, cameraAddress })
			.where(
				and(
					eq(guardFaceAppearances.cameraId, id),
					or(
						isNull(guardFaceAppearances.cameraName),
						sql`trim(${guardFaceAppearances.cameraName}) = ''`
					)
				)
			);
		await db.delete(guardCameras).where(eq(guardCameras.id, id));
	}
};
