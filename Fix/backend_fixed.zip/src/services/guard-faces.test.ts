import { describe, expect, it } from 'vitest';
import {
	buildRegistryVersion,
	collectRegisteredFaceEntries,
	type GuardFaceEntry
} from '@/services/guard-faces.js';

type Row = Parameters<typeof collectRegisteredFaceEntries>[0][number];

function row(overrides: Partial<Row> = {}): Row {
	return {
		faceRegistryId: 1,
		username: 'John Smith',
		faceEmbedding: [0.1, 0.2, 0.3],
		faceModel: 'Pikachu',
		faceRegisteredAt: new Date('2026-07-01T10:00:00.000Z'),
		updatedAt: new Date('2026-07-01T10:00:00.000Z'),
		...overrides
	};
}

describe('Guard face registry collection', () => {
	it('returns the registered user name with a valid embedding', () => {
		const result = collectRegisteredFaceEntries([row()], 'Pikachu');

		expect(result.faces).toEqual([{ id: 1, name: 'John Smith', feature: [0.1, 0.2, 0.3] }]);
		expect(result.featureDimension).toBe(3);
	});

	it('excludes embeddings from another model', () => {
		const result = collectRegisteredFaceEntries([row({ faceModel: 'DifferentModel' })], 'Pikachu');
		expect(result.faces).toEqual([]);
	});

	it('excludes inconsistent and non-finite feature vectors', () => {
		const result = collectRegisteredFaceEntries(
			[
				row({ faceRegistryId: 1 }),
				row({ faceRegistryId: 2, username: 'Wrong Dimension', faceEmbedding: [0.1, 0.2] }),
				row({ faceRegistryId: 3, username: 'Invalid', faceEmbedding: [0.1, Number.NaN, 0.3] })
			],
			'Pikachu'
		);
		expect(result.faces.map((face) => face.id)).toEqual([1]);
	});

	it('changes registry version when the display name changes', () => {
		const changedAt = new Date('2026-07-01T10:00:00.000Z');
		const first: GuardFaceEntry[] = [{ id: 1, name: 'John Smith', feature: [0.1, 0.2] }];
		const second: GuardFaceEntry[] = [{ id: 1, name: 'John A. Smith', feature: [0.1, 0.2] }];

		expect(buildRegistryVersion(first, changedAt, 'Pikachu')).not.toBe(
			buildRegistryVersion(second, changedAt, 'Pikachu')
		);
	});
	it('changes registry version when the embedding changes', () => {
		const changedAt = new Date('2026-07-01T10:00:00.000Z');
		const first: GuardFaceEntry[] = [{ id: 1, name: 'John Smith', feature: [0.1, 0.2] }];
		const second: GuardFaceEntry[] = [{ id: 1, name: 'John Smith', feature: [0.1, 0.25] }];

		expect(buildRegistryVersion(first, changedAt, 'Pikachu')).not.toBe(
			buildRegistryVersion(second, changedAt, 'Pikachu')
		);
	});
});
