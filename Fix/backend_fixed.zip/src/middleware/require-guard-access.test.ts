import type { NextFunction, Request, Response } from 'express';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardOperationalAccess,
	requireGuardScope
} from './require-guard-access.js';
import { signGuardAccessToken } from '@/services/guard-jwt.js';
import { AppError } from '@/services/errors.js';

vi.mock('@/services/guard-installations.js', () => ({
	guardInstallationsService: {
		getById: vi.fn()
	}
}));

import { guardInstallationsService } from '@/services/guard-installations.js';

const installationId = '11111111-1111-1111-1111-111111111111';
const roomId = '22222222-2222-2222-2222-222222222222';

function mockReq(headers: Record<string, string> = {}): Request {
	return { headers } as Request;
}

function mockRes(): Response {
	return {} as Response;
}

function runMiddleware(
	handler: (req: Request, res: Response, next: NextFunction) => unknown,
	req: Request
): Promise<{ error?: unknown; nextCalled: boolean }> {
	return new Promise((resolve) => {
		void handler(req, mockRes(), (error?: unknown) => {
			resolve({ error, nextCalled: error === undefined });
		});
	});
}

describe('requireGuardAccess', () => {
	beforeEach(() => {
		vi.mocked(guardInstallationsService.getById).mockReset();
	});

	it('rejects requests without a bearer token', async () => {
		const result = await runMiddleware(requireGuardAccess, mockReq());

		expect(result.nextCalled).toBe(false);
		expect(result.error).toBeInstanceOf(AppError);
		expect((result.error as AppError).status).toBe(401);
	});

	it('rejects bootstrap API keys on operational routes', async () => {
		const result = await runMiddleware(
			requireGuardAccess,
			mockReq({ 'x-guard-api-key': 'dev-guard-api-key-change-me' })
		);

		expect(result.nextCalled).toBe(false);
		expect((result.error as AppError).status).toBe(401);
	});

	it('accepts a valid Guard installation JWT without commercial entitlement claims', async () => {
		vi.mocked(guardInstallationsService.getById).mockResolvedValue({
			id: installationId,
			roomId,
			status: 'active',
			revokedAt: null
		} as Awaited<ReturnType<typeof guardInstallationsService.getById>>);

		const token = await signGuardAccessToken({
			installationId,
			roomId,
			scope: ['events:write']
		});

		const req = mockReq({ authorization: `Bearer ${token}` });
		const result = await runMiddleware(requireGuardAccess, req);

		expect(result.nextCalled).toBe(true);
		expect(req.guardAccess).toEqual({
			installationId,
			roomId,
			scope: ['events:write']
		});
	});

	it('rejects revoked installations', async () => {
		vi.mocked(guardInstallationsService.getById).mockResolvedValue({
			id: installationId,
			roomId,
			status: 'revoked',
			revokedAt: new Date()
		} as Awaited<ReturnType<typeof guardInstallationsService.getById>>);

		const token = await signGuardAccessToken({ installationId, roomId, scope: [] });
		const result = await runMiddleware(
			requireGuardAccess,
			mockReq({ authorization: `Bearer ${token}` })
		);

		expect(result.nextCalled).toBe(false);
		expect((result.error as AppError).status).toBe(401);
	});

	it('rejects disconnected installations even when an old JWT has not expired yet', async () => {
		vi.mocked(guardInstallationsService.getById).mockResolvedValue({
			id: installationId,
			roomId,
			status: 'disconnected',
			revokedAt: null
		} as Awaited<ReturnType<typeof guardInstallationsService.getById>>);

		const token = await signGuardAccessToken({ installationId, roomId, scope: [] });
		const result = await runMiddleware(
			requireGuardAccess,
			mockReq({ authorization: `Bearer ${token}` })
		);

		expect(result.nextCalled).toBe(false);
		expect((result.error as AppError).status).toBe(401);
	});
});

describe('requireGuardOperationalAccess', () => {
	it('accepts any authenticated, non-revoked Guard installation', async () => {
		const req = mockReq();
		req.guardAccess = {
			installationId,
			roomId,
			scope: ['events:write']
		};

		const result = await runMiddleware(requireGuardOperationalAccess, req);
		expect(result.nextCalled).toBe(true);
	});
});

describe('requireGuardScope', () => {
	it('requires the requested scope', async () => {
		const req = mockReq();
		req.guardAccess = {
			installationId,
			roomId,
			scope: ['faces:read']
		};

		const missing = await runMiddleware(requireGuardScope('events:write'), req);
		expect(missing.nextCalled).toBe(false);
		expect((missing.error as AppError).status).toBe(403);

		const allowed = await runMiddleware(requireGuardScope('faces:read'), req);
		expect(allowed.nextCalled).toBe(true);
	});
});

describe('requireGuardInstallation', () => {
	it('requires guardAccess from JWT auth', async () => {
		const result = await runMiddleware(requireGuardInstallation, mockReq());
		expect(result.nextCalled).toBe(false);
		expect((result.error as AppError).status).toBe(401);
	});
});
