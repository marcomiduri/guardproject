import type { RequestHandler } from 'express';
import { AppError, forbidden, unauthorized } from '@/services/errors.js';
import { guardInstallationsService } from '@/services/guard-installations.js';
import { verifyGuardAccessToken } from '@/services/guard-jwt.js';

export type GuardAccessContext = {
	installationId: string;
	roomId: string;
	scope: string[];
};

declare global {
	namespace Express {
		interface Request {
			guardAccess?: GuardAccessContext;
		}
	}
}

function getBearerToken(value: string | undefined): string | null {
	if (!value?.startsWith('Bearer ')) return null;
	const token = value.slice('Bearer '.length).trim();
	return token || null;
}

export const requireGuardAccess: RequestHandler = async (req, _res, next) => {
	try {
		const bearer = getBearerToken(req.headers.authorization);
		if (!bearer) {
			next(unauthorized());
			return;
		}

		const payload = await verifyGuardAccessToken(bearer);
		const installation = await guardInstallationsService.getById(payload.installationId);
		if (installation.status === 'revoked' || installation.revokedAt) {
			throw unauthorized('Guard installation is revoked');
		}
		if (installation.status !== 'active') {
			throw unauthorized('Guard installation is disconnected');
		}
		if (installation.roomId !== payload.roomId) throw unauthorized('Guard token room mismatch');

		req.guardAccess = {
			installationId: installation.id,
			roomId: installation.roomId,
			scope: payload.scope
		};
		next();
	} catch (error) {
		next(error instanceof AppError ? error : unauthorized());
	}
};

export const requireGuardInstallation: RequestHandler = (req, _res, next) => {
	if (!req.guardAccess?.installationId) {
		next(unauthorized('A registered Guard installation is required'));
		return;
	}
	next();
};

// Retained as a named middleware to avoid changing route composition. Commercial
// entitlement is enforced by Guard locally; backend operational access requires
// only a valid, non-revoked installation session.
export const requireGuardOperationalAccess = requireGuardInstallation;

export function requireGuardScope(scope: string): RequestHandler {
	return (req, _res, next) => {
		const access = req.guardAccess;
		if (!access) {
			next(unauthorized());
			return;
		}
		if (access.scope.includes(scope)) {
			next();
			return;
		}
		next(forbidden(`Missing Guard scope: ${scope}`));
	};
}
