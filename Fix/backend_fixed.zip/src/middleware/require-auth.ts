import type { RequestHandler } from 'express';
import { authService } from '@/services/auth.js';
import { unauthorized } from '@/services/errors.js';
import { verifyAccessToken } from '@/services/jwt.js';
import type { AuthUser } from '@/types/auth.js';

declare global {
	namespace Express {
		interface Request {
			user?: AuthUser;
		}
	}
}

function getBearerToken(authorization: string | undefined): string | null {
	if (!authorization?.startsWith('Bearer ')) {
		return null;
	}

	const token = authorization.slice('Bearer '.length).trim();
	return token.length > 0 ? token : null;
}

/** Requires a valid JWT bearer token; attaches user to req. */
export const requireAuth: RequestHandler = async (req, _res, next) => {
	try {
		const token = getBearerToken(req.headers.authorization);
		if (!token) {
			next(unauthorized());
			return;
		}

		const payload = await verifyAccessToken(token);
		req.user = await authService.getUserById(payload.sub);
		next();
	} catch {
		next(unauthorized());
	}
};
