import { requireAuth } from '@/middleware/require-auth.js';
import { requireRole } from '@/middleware/require-role.js';

/** Any signed-in user (`user` or `admin`). */
export const authenticated = [requireAuth] as const;

/** Standard app features (in-out, rooms list, profile). */
export const appAccess = [requireAuth, requireRole('admin', 'user', 'staff')] as const;

/** Room orders — standard users and admins only (not staff). */
export const ordersAccess = [requireAuth, requireRole('admin', 'user')] as const;

/** Admin-only management APIs (users, orders, etc.). */
export const adminOnly = [requireAuth, requireRole('admin')] as const;

/** Room and camera management — admins and staff. */
export const roomsAdminAccess = [requireAuth, requireRole('admin', 'staff')] as const;

/** Safety hazard alerts — admins and staff. */
export const safetyEventsAccess = [requireAuth, requireRole('admin', 'staff')] as const;

/** Room create/update/delete — admins only. */
export const roomsAdminWriteAccess = [requireAuth, requireRole('admin')] as const;
