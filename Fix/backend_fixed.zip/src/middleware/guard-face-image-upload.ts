import multer from 'multer';
import { MAX_IN_OUT_FACE_IMAGE_BYTES } from '@/services/in-out-face-images.js';

export const guardFaceImageUpload = multer({
	storage: multer.memoryStorage(),
	limits: {
		fileSize: MAX_IN_OUT_FACE_IMAGE_BYTES,
		files: 2,
		fields: 16
	}
});

export function isMultipartRequest(contentType: string | undefined): boolean {
	return (
		typeof contentType === 'string' && contentType.toLowerCase().includes('multipart/form-data')
	);
}
