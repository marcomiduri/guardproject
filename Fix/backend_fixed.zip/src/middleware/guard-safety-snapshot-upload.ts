import { MAX_SAFETY_EVENT_IMAGE_BYTES } from '@/services/safety-event-images.js';
import multer from 'multer';

export const guardSafetySnapshotUpload = multer({
	storage: multer.memoryStorage(),
	limits: {
		fileSize: MAX_SAFETY_EVENT_IMAGE_BYTES,
		files: 1,
		fields: 16
	}
});
