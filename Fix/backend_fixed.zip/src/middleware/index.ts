import cors from 'cors';
import express, { type Express } from 'express';
import { env, resolveCorsOrigin } from '@/config/env.js';

/** Global middleware applied to every request. */
export function applyGlobalMiddleware(app: Express): void {
	app.disable('x-powered-by');

	app.use(
		cors({
			origin: resolveCorsOrigin(env.CORS_ORIGIN),
			credentials: true
		})
	);

	app.use(express.json({ limit: '6mb' }));
}
