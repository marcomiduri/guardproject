import type { RequestHandler } from 'express';
import { formatUnknownErrorBody } from '@/services/api-error.js';

export const notFoundHandler: RequestHandler = (_req, res) => {
	res.status(404).json(formatUnknownErrorBody(404, 'Not found', 'NOT_FOUND'));
};
