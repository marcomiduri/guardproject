import type { RequestHandler } from 'express';

/** Wraps async route handlers so rejected promises reach errorHandler. */
export function asyncHandler(handler: RequestHandler): RequestHandler {
	return (req, res, next) => {
		Promise.resolve(handler(req, res, next)).catch(next);
	};
}
