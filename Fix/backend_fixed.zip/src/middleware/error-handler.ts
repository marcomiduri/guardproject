import type { ErrorRequestHandler } from 'express';
import { formatApiErrorBody, formatUnknownErrorBody } from '@/services/api-error.js';
import { AppError } from '@/services/errors.js';
import { logger } from '@/utils/logger.js';

function logApiError(err: unknown): void {
	if (err instanceof AppError) {
		if (err.status >= 500) {
			logger.error('[api]', err);
			return;
		}

		logger.warn(`[api] ${err.status} ${err.code}: ${err.message}`);
		return;
	}

	logger.error('[api]', err);
}

export const errorHandler: ErrorRequestHandler = (err, _req, res, next) => {
	if (res.headersSent) {
		next(err);
		return;
	}

	logApiError(err);

	if (err instanceof AppError) {
		res.status(err.status).json(formatApiErrorBody(err));
		return;
	}

	const status = typeof err.status === 'number' ? err.status : 500;
	const message = err instanceof Error ? err.message : 'Internal server error';

	res.status(status).json(formatUnknownErrorBody(status, message));
};
