import type { RequestHandler } from 'express';
import { forbidden } from '@/services/errors.js';

/** Requires req.user (run after requireAuth). */
export function requireRole(...roles: string[]): RequestHandler {
	return (req, _res, next) => {
		const role = req.user?.role ?? '';
		if (!roles.includes(role)) {
			next(forbidden('Insufficient permissions'));
			return;
		}
		next();
	};
}
