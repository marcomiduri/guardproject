import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { adminOnly } from '@/middleware/access.js';
import { roomOrdersService } from '@/services/room-orders.js';
import {
	parseListAdminRoomOrdersQuery,
	parseRoomOrderIdParam,
	parseUpdateRoomOrderStatusBody
} from '@/validators/room-orders.js';

export const adminOrdersRouter = Router();

adminOrdersRouter.get(
	'/pending-count',
	...adminOnly,
	asyncHandler(async (_req, res) => {
		const count = await roomOrdersService.countPending();
		res.json(ok({ count }));
	})
);

adminOrdersRouter.get(
	'/',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const options = parseListAdminRoomOrdersQuery(req.query as Record<string, unknown>);
		const result = await roomOrdersService.listAll(options);
		res.json(ok(result));
	})
);

adminOrdersRouter.get(
	'/:id',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const id = parseRoomOrderIdParam(String(req.params.id));
		const order = await roomOrdersService.getByIdForAdmin(id);
		res.json(ok({ order }));
	})
);

adminOrdersRouter.patch(
	'/:id/status',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const id = parseRoomOrderIdParam(String(req.params.id));
		const { status } = parseUpdateRoomOrderStatusBody(req.body);
		const order = await roomOrdersService.updateStatusForAdmin(id, status);
		res.json(ok({ order }));
	})
);
