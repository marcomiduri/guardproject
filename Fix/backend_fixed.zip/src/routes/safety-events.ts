import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { safetyEventsAccess } from '@/middleware/access.js';
import { guardHazardEventsService } from '@/services/guard-hazard-events.js';
import { parseListSafetyEventsQuery } from '@/validators/safety-events.js';

export const safetyEventsRouter = Router();

safetyEventsRouter.get(
	'/',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const result = await guardHazardEventsService.list(parseListSafetyEventsQuery(req.query));
		res.json(ok(result));
	})
);

safetyEventsRouter.get(
	'/:eventId/snapshot',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const eventId = String(req.params.eventId).trim();
		const { buffer, mimeType } = await guardHazardEventsService.readSnapshot(eventId);
		res.setHeader('Content-Type', mimeType);
		res.setHeader('Cache-Control', 'private, max-age=300');
		res.send(buffer);
	})
);

safetyEventsRouter.post(
	'/:eventId/acknowledge',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const eventId = String(req.params.eventId).trim();
		const event = await guardHazardEventsService.acknowledge(eventId, req.user!.id);
		res.json(ok({ event }));
	})
);

safetyEventsRouter.post(
	'/:eventId/resolve',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const eventId = String(req.params.eventId).trim();
		const event = await guardHazardEventsService.resolve(eventId, req.user!.id);
		res.json(ok({ event }));
	})
);

safetyEventsRouter.post(
	'/:eventId/false-alarm',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const eventId = String(req.params.eventId).trim();
		const event = await guardHazardEventsService.markFalseAlarm(eventId, req.user!.id);
		res.json(ok({ event }));
	})
);
