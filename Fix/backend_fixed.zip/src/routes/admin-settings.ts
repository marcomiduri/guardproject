import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { adminOnly, safetyEventsAccess } from '@/middleware/access.js';
import { adminNotificationSettingsService } from '@/services/admin-notification-settings.js';
import { guardRealtimeHub } from '@/services/guard-realtime-hub.js';
import { parseUpdateAdminNotificationSettingsBody } from '@/validators/admin-notification-settings.js';
import { logger } from '@/utils/logger.js';

export const adminSettingsRouter = Router();

adminSettingsRouter.get(
	'/notifications',
	...safetyEventsAccess,
	asyncHandler(async (_req, res) => {
		const settings = await adminNotificationSettingsService.get();
		res.json(ok({ settings }));
	})
);

adminSettingsRouter.patch(
	'/notifications',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const input = parseUpdateAdminNotificationSettingsBody(req.body);
		const settings = await adminNotificationSettingsService.update(input);
		const changedKeys = Object.keys(input);
		const sent = guardRealtimeHub.publishNotificationSettingsUpdated({
			version: new Date().toISOString(),
			changedKeys
		});
		logger.info(`[guard-realtime] notification_settings.updated broadcast to ${sent} client(s)`);
		res.json(ok({ settings }));
	})
);
