import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { appAccess } from '@/middleware/access.js';
import { inOutEventsService } from '@/services/in-out-events.js';
import { inOutFaceImagesService } from '@/services/in-out-face-images.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { parseListInOutQuery } from '@/validators/in-out.js';
import { parseAdminUserIdParam } from '@/validators/admin-users.js';
import { IN_OUT_EVENT_IMAGE_TYPES, type InOutEventImageType } from '@/db/schema/guard.js';
import { badRequest } from '@/services/errors.js';

export const inOutRouter = Router();

function parseInOutImageType(value: unknown): InOutEventImageType | undefined {
	if (value === undefined || value === null || value === '') {
		return undefined;
	}

	const normalized = String(value).trim();
	if ((IN_OUT_EVENT_IMAGE_TYPES as readonly string[]).includes(normalized)) {
		return normalized as InOutEventImageType;
	}

	throw badRequest(`type must be one of: ${IN_OUT_EVENT_IMAGE_TYPES.join(', ')}`);
}

async function streamInOutFaceImage(
	eventId: string,
	userId: string,
	role: string,
	res: import('express').Response,
	imageType?: InOutEventImageType
): Promise<void> {
	await inOutFaceImagesService.assertReadableForUser(eventId, userId, role, imageType);
	const image = await inOutFaceImagesService.read(eventId, imageType);
	const mimeType = await inOutFaceImagesService.readMimeType(eventId, imageType);
	res.type(mimeType).send(image);
}

inOutRouter.get(
	'/users/:userId/profile-image',
	...appAccess,
	asyncHandler(async (req, res) => {
		const targetUserId = parseAdminUserIdParam(String(req.params.userId));
		const user = req.user!;
		await inOutEventsService.assertUserProfileImageReadable(targetUserId, user.id, user.role);
		const image = await faceRegistrationService.readFaceImage(targetUserId);
		res.setHeader('Content-Type', 'image/jpeg');
		res.setHeader('Cache-Control', 'private, max-age=300');
		res.send(image);
	})
);

inOutRouter.get(
	'/:id/face-image',
	...appAccess,
	asyncHandler(async (req, res) => {
		const eventId = String(req.params.id).trim();
		const user = req.user!;
		const imageType = parseInOutImageType(req.query.type);
		await streamInOutFaceImage(eventId, user.id, user.role, res, imageType);
	})
);

inOutRouter.get(
	'/',
	...appAccess,
	asyncHandler(async (req, res) => {
		const options = parseListInOutQuery(req.query as Record<string, unknown>);
		const user = req.user!;
		const result = await inOutEventsService.list({
			...options,
			userId: user.role === 'user' ? user.id : undefined
		});
		res.json(ok(result));
	})
);

export const inOutEventsRouter = Router();

inOutEventsRouter.get(
	'/:eventId/image',
	...appAccess,
	asyncHandler(async (req, res) => {
		const eventId = String(req.params.eventId).trim();
		const user = req.user!;
		const imageType = parseInOutImageType(req.query.type);
		await streamInOutFaceImage(eventId, user.id, user.role, res, imageType);
	})
);
