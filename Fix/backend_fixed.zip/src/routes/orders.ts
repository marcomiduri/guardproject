import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { ordersAccess } from '@/middleware/access.js';
import { roomOrdersService } from '@/services/room-orders.js';
import {
	parseCreateRoomOrderBody,
	parseListRoomOrdersQuery,
	parseRoomOrderIdParam,
	parseUpdateRoomOrderBody
} from '@/validators/room-orders.js';

export const ordersRouter = Router();

ordersRouter.get(
	'/',
	...ordersAccess,
	asyncHandler(async (req, res) => {
		const options = parseListRoomOrdersQuery(req.query as Record<string, unknown>);
		const result = await roomOrdersService.list({
			...options,
			userId: req.user!.id
		});
		res.json(ok(result));
	})
);

ordersRouter.post(
	'/',
	...ordersAccess,
	asyncHandler(async (req, res) => {
		const input = parseCreateRoomOrderBody(req.body);
		const order = await roomOrdersService.create(req.user!.id, input);
		res.status(201).json(ok({ order }));
	})
);

ordersRouter.get(
	'/:id',
	...ordersAccess,
	asyncHandler(async (req, res) => {
		const id = parseRoomOrderIdParam(String(req.params.id));
		const order = await roomOrdersService.getByIdForUser(req.user!.id, id);
		res.json(ok({ order }));
	})
);

ordersRouter.patch(
	'/:id',
	...ordersAccess,
	asyncHandler(async (req, res) => {
		const id = parseRoomOrderIdParam(String(req.params.id));
		const input = parseUpdateRoomOrderBody(req.body);
		const order = await roomOrdersService.updateForUser(req.user!.id, id, input);
		res.json(ok({ order }));
	})
);

ordersRouter.delete(
	'/:id',
	...ordersAccess,
	asyncHandler(async (req, res) => {
		const id = parseRoomOrderIdParam(String(req.params.id));
		await roomOrdersService.deleteForUser(req.user!.id, id);
		res.json(ok({ deleted: true }));
	})
);
