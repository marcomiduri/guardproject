import { Router } from 'express';
import { asyncHandler } from '@/middleware/async-handler.js';
import { authService } from '@/services/auth.js';
import { parseLoginBody, parseRegisterBody } from '@/validators/auth.js';

export const authRouter = Router();

authRouter.post(
	'/register',
	asyncHandler(async (req, res) => {
		const input = parseRegisterBody(req.body);
		const result = await authService.register(input);
		res.status(201).json(result);
	})
);

authRouter.post(
	'/login',
	asyncHandler(async (req, res) => {
		const input = parseLoginBody(req.body);
		const result = await authService.login(input);
		res.json(result);
	})
);
