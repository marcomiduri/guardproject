import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { appAccess } from '@/middleware/access.js';
import { guardRoomsService } from '@/services/guard-rooms.js';
import { parseGuardRoomIdParam } from '@/validators/guard-rooms.js';

export const roomsRouter = Router();

roomsRouter.get(
	'/',
	...appAccess,
	asyncHandler(async (_req, res) => {
		const rooms = await guardRoomsService.listSummaries();
		res.json(ok({ rooms }));
	})
);

roomsRouter.get(
	'/:id',
	...appAccess,
	asyncHandler(async (req, res) => {
		const id = parseGuardRoomIdParam(String(req.params.id));
		const room = await guardRoomsService.getById(id);
		res.json(ok({ room }));
	})
);
