import { Router } from 'express';
import { asyncHandler } from '@/middleware/async-handler.js';
import {
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardScope
} from '@/middleware/require-guard-access.js';
import { guardInstallationsService } from '@/services/guard-installations.js';
import {
	parseActivateGuardInstallationBody,
	parseConnectGuardInstallationBody,
	parseExchangeGuardDeviceTokenBody
} from '@/validators/guard-installations.js';

export const guardAuthRouter = Router();

guardAuthRouter.get(
	'/available-rooms',
	asyncHandler(async (_req, res) => {
		const payload = await guardInstallationsService.listAvailableRooms();
		res.json(payload);
	})
);

guardAuthRouter.post(
	'/installations/connect',
	asyncHandler(async (req, res) => {
		const input = parseConnectGuardInstallationBody(req.body);
		const session = await guardInstallationsService.connect(input);
		res.status(session.deviceCredential ? 201 : 200).json(session);
	})
);

guardAuthRouter.post(
	'/installations/activate',
	asyncHandler(async (req, res) => {
		const input = parseActivateGuardInstallationBody(req.body);
		const session = await guardInstallationsService.activate(input);
		res.status(201).json(session);
	})
);

// The long-lived device credential is the authentication factor for this endpoint.
// An existing access JWT may still be present, but it is intentionally not required.
guardAuthRouter.post(
	'/auth/token',
	asyncHandler(async (req, res) => {
		const input = parseExchangeGuardDeviceTokenBody(req.body);
		const session = await guardInstallationsService.exchangeDeviceToken(input);
		res.json(session);
	})
);

guardAuthRouter.get(
	'/installations/current',
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardScope('installation:manage'),
	asyncHandler(async (req, res) => {
		const session = await guardInstallationsService.current(req.guardAccess!.installationId!);
		res.json(session);
	})
);

guardAuthRouter.post(
	'/installations/disconnect',
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardScope('installation:manage'),
	asyncHandler(async (req, res) => {
		await guardInstallationsService.disconnect(req.guardAccess!.installationId!);
		res.status(204).send();
	})
);
guardAuthRouter.delete(
	'/installations/current',
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardScope('installation:manage'),
	asyncHandler(async (req, res) => {
		await guardInstallationsService.disconnect(req.guardAccess!.installationId!);
		res.status(204).send();
	})
);

guardAuthRouter.post(
	'/installations/heartbeat',
	requireGuardAccess,
	requireGuardInstallation,
	asyncHandler(async (req, res) => {
		const body =
			typeof req.body === 'object' && req.body !== null
				? (req.body as Record<string, unknown>)
				: {};
		const guardVersion = typeof body.guardVersion === 'string' ? body.guardVersion : undefined;
		const occurredAtRaw = typeof body.occurredAt === 'string' ? body.occurredAt.trim() : '';
		const occurredAt = occurredAtRaw ? new Date(occurredAtRaw) : undefined;
		const heartbeat = await guardInstallationsService.recordHeartbeat(
			req.guardAccess!.installationId!,
			{
				guardVersion,
				occurredAt: occurredAt && !Number.isNaN(occurredAt.getTime()) ? occurredAt : undefined
			}
		);
		res.json(heartbeat);
	})
);
