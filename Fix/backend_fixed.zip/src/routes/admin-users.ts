import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { adminOnly } from '@/middleware/access.js';
import { adminUsersService } from '@/services/admin-users.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { deleteUserAccountById } from '@/services/user-account.js';
import { badRequest } from '@/services/errors.js';
import {
	parseAdminUserIdParam,
	parseListAdminUsersQuery,
	parseUpdateAdminUserBody
} from '@/validators/admin-users.js';

export const adminUsersRouter = Router();

adminUsersRouter.get(
	'/',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const options = parseListAdminUsersQuery(req.query as Record<string, unknown>);
		const result = await adminUsersService.list(options);
		res.json(ok(result));
	})
);

adminUsersRouter.get(
	'/:id/face/image',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const id = parseAdminUserIdParam(String(req.params.id));
		await adminUsersService.getById(id);
		const image = await faceRegistrationService.readFaceImage(id);
		res.setHeader('Content-Type', 'image/jpeg');
		res.setHeader('Cache-Control', 'private, max-age=60');
		res.send(image);
	})
);

adminUsersRouter.get(
	'/:id',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const id = parseAdminUserIdParam(String(req.params.id));
		const user = await adminUsersService.getById(id);
		res.json(ok({ user }));
	})
);

adminUsersRouter.patch(
	'/:id',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const id = parseAdminUserIdParam(String(req.params.id));
		const body = parseUpdateAdminUserBody(req.body);
		const user = await adminUsersService.updateRole(id, body.role);
		res.json(ok({ user }));
	})
);

adminUsersRouter.delete(
	'/:id',
	...adminOnly,
	asyncHandler(async (req, res) => {
		const id = parseAdminUserIdParam(String(req.params.id));

		if (id === req.user!.id) {
			throw badRequest('You cannot delete your own account from the admin panel');
		}

		await deleteUserAccountById(id);
		res.status(204).send();
	})
);
