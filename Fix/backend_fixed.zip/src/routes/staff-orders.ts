import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { safetyEventsAccess } from '@/middleware/access.js';
import { roomOrdersService } from '@/services/room-orders.js';
import { parseListAdminRoomOrdersQuery, parseRoomOrderIdParam } from '@/validators/room-orders.js';

export const staffOrdersRouter = Router();

staffOrdersRouter.get(
	'/',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const options = parseListAdminRoomOrdersQuery(req.query as Record<string, unknown>);
		const result = await roomOrdersService.listAll(options);
		res.json(ok(result));
	})
);

staffOrdersRouter.get(
	'/:id',
	...safetyEventsAccess,
	asyncHandler(async (req, res) => {
		const id = parseRoomOrderIdParam(String(req.params.id));
		const order = await roomOrdersService.getByIdForAdmin(id);
		res.json(ok({ order }));
	})
);
