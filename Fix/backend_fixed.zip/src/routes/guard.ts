import { Router, type Request, type Response, type NextFunction } from 'express';
import { asyncHandler } from '@/middleware/async-handler.js';
import {
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardOperationalAccess,
	requireGuardScope
} from '@/middleware/require-guard-access.js';
import { GUARD_CAMERA_STATUSES, type GuardCameraStatus } from '@/db/schema/guard.js';
import { guardCamerasService, type GuardCameraAccess } from '@/services/guard-cameras.js';
import { adminNotificationSettingsService } from '@/services/admin-notification-settings.js';
import { guardFaceEventsService } from '@/services/guard-face-events.js';
import { guardHazardEventsService } from '@/services/guard-hazard-events.js';
import { guardFacesService } from '@/services/guard-faces.js';
import { guardRoomsService } from '@/services/guard-rooms.js';
import { badRequest, forbidden, notFound } from '@/services/errors.js';
import {
	parseCreateGuardCameraBody,
	parseGuardCameraIdParam,
	parseUpdateGuardCameraBody
} from '@/validators/guard-cameras.js';
import { parseGuardRoomIdParam } from '@/validators/guard-rooms.js';
import {
	parseGuardFaceAppearedRequest,
	parseGuardSafetyDetectedRequest,
	parseGuardUnknownFaceAppearedRequest
} from '@/validators/guard.js';
import { guardFaceImageUpload, isMultipartRequest } from '@/middleware/guard-face-image-upload.js';
import { guardSafetySnapshotUpload } from '@/middleware/guard-safety-snapshot-upload.js';

export const guardRouter = Router();

const guardReadAccess = [
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardOperationalAccess
] as const;
const guardEventAccess = [
	requireGuardAccess,
	requireGuardInstallation,
	requireGuardOperationalAccess,
	requireGuardScope('events:write')
] as const;

function currentCameraAccess(req: Request): GuardCameraAccess {
	const access = req.guardAccess!;
	return {
		installationId: access.installationId,
		roomId: access.roomId
	};
}

function assertRoomAccess(req: Request, roomId: string): void {
	const access = req.guardAccess!;
	if (access.roomId !== roomId) throw forbidden('Room does not belong to this Guard installation');
}

function optionalGuardSafetySnapshotUpload(req: Request, res: Response, next: NextFunction): void {
	if (!isMultipartRequest(req.headers['content-type'])) {
		next();
		return;
	}

	guardSafetySnapshotUpload.single('snapshot')(req, res, (error) => {
		if (error) {
			next(badRequest(error instanceof Error ? error.message : 'Invalid multipart upload'));
			return;
		}

		next();
	});
}

async function recordSafetyDetectedFromInput(
	req: Request,
	input: Awaited<ReturnType<typeof parseGuardSafetyDetectedRequest>>
) {
	const access = req.guardAccess!;
	return guardHazardEventsService.recordDetected({
		eventId: input.eventId,
		cameraId: input.cameraId,
		hazardType: input.hazardType,
		confidence: input.confidence,
		detections: input.detections,
		occurredAt: input.occurredAt,
		source: input.source,
		testScenario: input.testScenario,
		snapshotBuffer: input.snapshotImage,
		snapshotMimeType: input.snapshotMimeType,
		installationId: access.installationId,
		roomId: access.roomId
	});
}

function optionalGuardFaceImageUpload(req: Request, res: Response, next: NextFunction): void {
	if (!isMultipartRequest(req.headers['content-type'])) {
		next();
		return;
	}

	guardFaceImageUpload.fields([
		{ name: 'faceImage', maxCount: 1 },
		{ name: 'frameImage', maxCount: 1 }
	])(req, res, (error) => {
		if (error) {
			next(badRequest(error instanceof Error ? error.message : 'Invalid multipart upload'));
			return;
		}

		next();
	});
}

guardRouter.get(
	'/notification-settings',
	...guardReadAccess,
	requireGuardScope('settings:read'),
	asyncHandler(async (_req, res) => {
		const settings = await adminNotificationSettingsService.get();
		res.json({ settings });
	})
);

guardRouter.get(
	'/rooms',
	...guardReadAccess,
	requireGuardScope('rooms:read'),
	asyncHandler(async (req, res) => {
		const room = await guardRoomsService.getById(req.guardAccess!.roomId);
		res.json({ rooms: [room] });
	})
);

guardRouter.get(
	'/rooms/:roomId/cameras',
	...guardReadAccess,
	requireGuardScope('cameras:read'),
	asyncHandler(async (req, res) => {
		const roomId = parseGuardRoomIdParam(String(req.params.roomId));
		assertRoomAccess(req, roomId);
		await guardRoomsService.getById(roomId);
		const cameras = await guardCamerasService.list(roomId);
		res.json({ cameras });
	})
);

guardRouter.get(
	'/cameras',
	...guardReadAccess,
	requireGuardScope('cameras:read'),
	asyncHandler(async (req, res) => {
		const access = req.guardAccess!;
		const requestedRoomId =
			typeof req.query.roomId === 'string' && req.query.roomId.trim()
				? req.query.roomId.trim()
				: undefined;
		if (requestedRoomId) assertRoomAccess(req, requestedRoomId);
		const cameras = await guardCamerasService.list(requestedRoomId ?? access.roomId);
		res.json({ cameras });
	})
);

guardRouter.post(
	'/cameras',
	...guardReadAccess,
	requireGuardScope('cameras:write'),
	asyncHandler(async (req, res) => {
		const parsed = parseCreateGuardCameraBody(req.body);
		const access = req.guardAccess!;
		const camera = await guardCamerasService.upsertForInstallation(
			access.installationId,
			access.roomId,
			parsed
		);
		res.status(201).json({ camera });
	})
);

guardRouter.patch(
	'/cameras/:id',
	...guardReadAccess,
	requireGuardScope('cameras:write'),
	asyncHandler(async (req, res) => {
		const id = parseGuardCameraIdParam(String(req.params.id));
		const parsed = parseUpdateGuardCameraBody(req.body);
		const access = req.guardAccess!;
		const camera = await guardCamerasService.update(
			id,
			{
				...parsed,
				roomId: access.roomId,
				installationId: access.installationId
			},
			currentCameraAccess(req)
		);
		res.json({ camera });
	})
);

guardRouter.post(
	'/cameras/:id/heartbeat',
	...guardReadAccess,
	requireGuardScope('cameras:heartbeat'),
	asyncHandler(async (req, res) => {
		const id = parseGuardCameraIdParam(String(req.params.id));
		const statusRaw =
			typeof req.body === 'object' && req.body !== null
				? (req.body as Record<string, unknown>).status
				: undefined;
		const status = typeof statusRaw === 'string' ? statusRaw.trim() : '';
		if (!GUARD_CAMERA_STATUSES.includes(status as GuardCameraStatus)) {
			throw badRequest(`status must be one of: ${GUARD_CAMERA_STATUSES.join(', ')}`);
		}
		const occurredAtRaw =
			typeof req.body === 'object' && req.body !== null
				? (req.body as Record<string, unknown>).occurredAt
				: undefined;
		const occurredAtText = typeof occurredAtRaw === 'string' ? occurredAtRaw.trim() : '';
		const occurredAt = occurredAtText ? new Date(occurredAtText) : undefined;
		const camera = await guardCamerasService.recordHeartbeat(
			id,
			status as GuardCameraStatus,
			currentCameraAccess(req),
			{
				occurredAt: occurredAt && !Number.isNaN(occurredAt.getTime()) ? occurredAt : undefined
			}
		);
		res.json({ camera });
	})
);

guardRouter.delete(
	'/cameras/:id',
	...guardReadAccess,
	requireGuardScope('cameras:write'),
	asyncHandler(async (req, res) => {
		const id = parseGuardCameraIdParam(String(req.params.id));
		await guardCamerasService.remove(id, currentCameraAccess(req));
		res.status(204).send();
	})
);

guardRouter.get(
	'/faces',
	...guardReadAccess,
	requireGuardScope('faces:read'),
	asyncHandler(async (_req, res) => {
		const registry = await guardFacesService.getRegistry();
		res.json(registry);
	})
);

guardRouter.get(
	'/faces/version',
	...guardReadAccess,
	requireGuardScope('faces:read'),
	asyncHandler(async (_req, res) => {
		const version = await guardFacesService.getRegistryVersion();
		res.json(version);
	})
);

guardRouter.get(
	'/faces/:faceRegistryId',
	...guardReadAccess,
	requireGuardScope('faces:read'),
	asyncHandler(async (req, res) => {
		const faceRegistryId = Number.parseInt(String(req.params.faceRegistryId), 10);
		if (!Number.isInteger(faceRegistryId) || faceRegistryId <= 0) {
			throw notFound('Face not found');
		}

		const user = await guardFacesService.getUserByFaceRegistryId(faceRegistryId);
		if (!user) {
			throw notFound('Face not found');
		}

		res.json(user);
	})
);

guardRouter.post(
	'/events/appeared',
	...guardEventAccess,
	optionalGuardFaceImageUpload,
	asyncHandler(async (req, res) => {
		let input;
		try {
			input = parseGuardFaceAppearedRequest(req);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
		}

		const event = await guardFaceEventsService.recordAppeared(input, currentCameraAccess(req));
		res.status(event.idempotent ? 200 : 201).json(event);
	})
);

guardRouter.post(
	'/events/unknown-appeared',
	...guardEventAccess,
	optionalGuardFaceImageUpload,
	asyncHandler(async (req, res) => {
		let input;
		try {
			input = parseGuardUnknownFaceAppearedRequest(req);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
		}

		const event = await guardFaceEventsService.recordUnknownAppeared(
			input,
			currentCameraAccess(req)
		);
		res.status(event.idempotent ? 200 : 201).json(event);
	})
);

for (const path of ['/events/safety-detected', '/events/hazard-detected']) {
	guardRouter.post(
		path,
		...guardEventAccess,
		optionalGuardSafetySnapshotUpload,
		asyncHandler(async (req, res) => {
			let input;
			try {
				input = parseGuardSafetyDetectedRequest(req);
			} catch (error) {
				throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
			}

			const event = await recordSafetyDetectedFromInput(req, input);
			res.status(event.idempotent ? 200 : 201).json(event);
		})
	);
}
