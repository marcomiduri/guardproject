import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { appAccess } from '@/middleware/access.js';
import { guardCamerasService } from '@/services/guard-cameras.js';

export const camerasRouter = Router();

camerasRouter.get(
	'/',
	...appAccess,
	asyncHandler(async (_req, res) => {
		const cameras = await guardCamerasService.listSummaries();
		res.json(ok({ cameras }));
	})
);
