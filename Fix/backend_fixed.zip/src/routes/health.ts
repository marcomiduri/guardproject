import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Router } from 'express';

export const healthRouter = Router();

function readPackageVersion(): string {
	try {
		const packagePath = resolve(dirname(fileURLToPath(import.meta.url)), '../../package.json');
		const packageJson = JSON.parse(readFileSync(packagePath, 'utf8')) as { version?: string };
		return packageJson.version?.trim() || '0.0.0';
	} catch {
		return '0.0.0';
	}
}

healthRouter.get('/', (_req, res) => {
	const serverTime = new Date().toISOString();
	res.json({
		ok: true,
		status: 'ok',
		service: 'mc-pos-api',
		version: readPackageVersion(),
		serverTime
	});
});
