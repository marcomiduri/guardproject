import { Router } from 'express';
import { asyncHandler } from '@/middleware/async-handler.js';
import { requireAuth } from '@/middleware/require-auth.js';
import { faceRegistrationService } from '@/services/face-registration.js';
import { userProfileService } from '@/services/user-profile.js';
import { badRequest } from '@/services/errors.js';
import { parseFaceImageBody } from '@/validators/face.js';
import {
	parseCloseAccountBody,
	parseUpdateEmailBody,
	parseUpdatePasswordBody
} from '@/validators/account.js';
import { parseUpdateProfileBody } from '@/validators/profile.js';
import { userAccountService } from '@/services/user-account.js';

export const meRouter = Router();

meRouter.get(
	'/',
	requireAuth,
	asyncHandler((req, res) => {
		res.json({ user: req.user });
	})
);

meRouter.patch(
	'/',
	requireAuth,
	asyncHandler(async (req, res) => {
		let input;
		try {
			input = parseUpdateProfileBody(req.body);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
		}

		const user = await userProfileService.update(req.user!.id, input);
		res.json({ user });
	})
);

meRouter.patch(
	'/email',
	requireAuth,
	asyncHandler(async (req, res) => {
		let input;
		try {
			input = parseUpdateEmailBody(req.body);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
		}

		const result = await userAccountService.updateEmail(req.user!.id, input);
		res.json(result);
	})
);

meRouter.patch(
	'/password',
	requireAuth,
	asyncHandler(async (req, res) => {
		let input;
		try {
			input = parseUpdatePasswordBody(req.body);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
		}

		const user = await userAccountService.updatePassword(req.user!.id, input);
		res.json({ user });
	})
);

meRouter.delete(
	'/',
	requireAuth,
	asyncHandler(async (req, res) => {
		let input;
		try {
			input = parseCloseAccountBody(req.body);
		} catch (error) {
			throw badRequest(error instanceof Error ? error.message : 'Invalid request body');
		}

		await userAccountService.closeAccount(req.user!.id, input.currentPassword);
		res.status(204).send();
	})
);

meRouter.get(
	'/face',
	requireAuth,
	asyncHandler(async (req, res) => {
		const status = await faceRegistrationService.getStatus(req.user!.id);
		res.json(status);
	})
);

meRouter.post(
	'/face',
	requireAuth,
	asyncHandler(async (req, res) => {
		let imageBuffer: Buffer;
		try {
			imageBuffer = parseFaceImageBody(req.body);
		} catch (err) {
			throw badRequest(err instanceof Error ? err.message : 'Invalid face image');
		}

		const status = await faceRegistrationService.registerFace(req.user!.id, imageBuffer);
		res.status(201).json(status);
	})
);

meRouter.get(
	'/face/image',
	requireAuth,
	asyncHandler(async (req, res) => {
		const image = await faceRegistrationService.readFaceImage(req.user!.id);
		res.setHeader('Content-Type', 'image/jpeg');
		res.setHeader('Cache-Control', 'private, max-age=60');
		res.send(image);
	})
);
