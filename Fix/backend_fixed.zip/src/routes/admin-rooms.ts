import { Router } from 'express';
import { ok } from '@/http/responses.js';
import { asyncHandler } from '@/middleware/async-handler.js';
import { roomsAdminAccess, roomsAdminWriteAccess } from '@/middleware/access.js';
import { guardCamerasService } from '@/services/guard-cameras.js';
import { guardRoomsService } from '@/services/guard-rooms.js';
import { guardInstallationsService } from '@/services/guard-installations.js';
import { badRequest } from '@/services/errors.js';
import {
	parseCreateGuardCameraBody,
	parseGuardCameraIdParam,
	parseUpdateGuardCameraBody
} from '@/validators/guard-cameras.js';
import {
	parseCreateGuardRoomBody,
	parseGuardRoomIdParam,
	parseListGuardRoomsQuery,
	parseUpdateGuardRoomBody
} from '@/validators/guard-rooms.js';
import { parseCreateRoomActivationCodeBody } from '@/validators/guard-installations.js';

export const adminRoomsRouter = Router();

adminRoomsRouter.get(
	'/',
	...roomsAdminAccess,
	asyncHandler(async (req, res) => {
		const options = parseListGuardRoomsQuery(req.query as Record<string, unknown>);
		const result = await guardRoomsService.listPaginated(options);
		res.json(ok(result));
	})
);

adminRoomsRouter.post(
	'/',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const input = parseCreateGuardRoomBody(req.body);
		const room = await guardRoomsService.create(input);
		res.status(201).json(ok({ room }));
	})
);

adminRoomsRouter.get(
	'/:id',
	...roomsAdminAccess,
	asyncHandler(async (req, res) => {
		const id = parseGuardRoomIdParam(String(req.params.id));
		const room = await guardRoomsService.getById(id);
		const cameras = await guardCamerasService.list(id);
		res.json(ok({ room, cameras }));
	})
);

adminRoomsRouter.patch(
	'/:id',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const id = parseGuardRoomIdParam(String(req.params.id));
		const input = parseUpdateGuardRoomBody(req.body);
		const room = await guardRoomsService.update(id, input);
		res.json(ok({ room }));
	})
);

adminRoomsRouter.delete(
	'/:id',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const id = parseGuardRoomIdParam(String(req.params.id));
		await guardRoomsService.remove(id);
		res.status(204).send();
	})
);

adminRoomsRouter.get(
	'/:id/installations',
	...roomsAdminAccess,
	asyncHandler(async (req, res) => {
		const roomId = parseGuardRoomIdParam(String(req.params.id));
		const installations = await guardInstallationsService.listByRoom(roomId);
		res.json(ok({ installations }));
	})
);

adminRoomsRouter.delete(
	'/:id/installations/:installationId',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const roomId = parseGuardRoomIdParam(String(req.params.id));
		const installationId = String(req.params.installationId).trim();
		if (!installationId) throw badRequest('Guard installation id is required');
		await guardInstallationsService.revokeForRoom(roomId, installationId);
		res.status(204).send();
	})
);

adminRoomsRouter.get(
	'/:id/activation-codes',
	...roomsAdminAccess,
	asyncHandler(async (req, res) => {
		const roomId = parseGuardRoomIdParam(String(req.params.id));
		await guardRoomsService.getById(roomId);
		const activationCodes = await guardInstallationsService.listActivationCodes(roomId);
		res.json(ok({ activationCodes }));
	})
);

adminRoomsRouter.post(
	'/:id/activation-codes',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const roomId = parseGuardRoomIdParam(String(req.params.id));
		const input = parseCreateRoomActivationCodeBody(req.body);
		const activationCode = await guardInstallationsService.createActivationCode(
			roomId,
			input,
			req.user!.id
		);
		res.status(201).json(ok({ activationCode }));
	})
);

adminRoomsRouter.delete(
	'/:id/activation-codes/:codeId',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const roomId = parseGuardRoomIdParam(String(req.params.id));
		const codeId = String(req.params.codeId).trim();
		if (!codeId) throw badRequest('Activation code id is required');
		await guardInstallationsService.revokeActivationCode(roomId, codeId);
		res.status(204).send();
	})
);
adminRoomsRouter.get(
	'/:id/cameras',
	...roomsAdminAccess,
	asyncHandler(async (req, res) => {
		const id = parseGuardRoomIdParam(String(req.params.id));
		await guardRoomsService.getById(id);
		const cameras = await guardCamerasService.list(id);
		res.json(ok({ cameras }));
	})
);

adminRoomsRouter.post(
	'/:id/cameras',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const id = parseGuardRoomIdParam(String(req.params.id));
		const input = parseCreateGuardCameraBody({ ...(req.body as object), roomId: id });
		const camera = await guardCamerasService.create(input);
		res.status(201).json(ok({ camera }));
	})
);

adminRoomsRouter.patch(
	'/cameras/:cameraId',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const cameraId = parseGuardCameraIdParam(String(req.params.cameraId));
		const input = parseUpdateGuardCameraBody(req.body);
		const camera = await guardCamerasService.update(cameraId, input);
		res.json(ok({ camera }));
	})
);

adminRoomsRouter.delete(
	'/cameras/:cameraId',
	...roomsAdminWriteAccess,
	asyncHandler(async (req, res) => {
		const cameraId = parseGuardCameraIdParam(String(req.params.cameraId));
		await guardCamerasService.remove(cameraId);
		res.status(204).send();
	})
);
