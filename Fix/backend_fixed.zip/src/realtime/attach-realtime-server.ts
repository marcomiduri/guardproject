import type { IncomingMessage, Server } from 'node:http';
import { WebSocket, WebSocketServer } from 'ws';
import { authService } from '@/services/auth.js';
import { guardRealtimeHub } from '@/services/guard-realtime-hub.js';
import { verifyAccessToken } from '@/services/jwt.js';
import { verifyGuardAccessToken } from '@/services/guard-jwt.js';
import { guardInstallationsService } from '@/services/guard-installations.js';
import { realtimeHub } from '@/services/realtime-hub.js';
import { logger } from '@/utils/logger.js';

const WS_PATH = '/api/ws';
const GUARD_WS_PATH = '/api/guard/ws';
const KEEPALIVE_MS = 25_000;

function getBearerTokenFromRequest(url: URL): string | null {
	const token = url.searchParams.get('token')?.trim();
	return token && token.length > 0 ? token : null;
}

export type RealtimeServerHandle = {
	close: () => void;
};

function getGuardBearerToken(request: IncomingMessage, url: URL): string | null {
	const authorization = request.headers.authorization;
	if (typeof authorization === 'string' && authorization.startsWith('Bearer ')) {
		const token = authorization.slice('Bearer '.length).trim();
		if (token) return token;
	}

	const queryToken = url.searchParams.get('token')?.trim();
	return queryToken || null;
}

function attachKeepAlive(ws: WebSocket, onClose: () => void): void {
	const keepAlive = setInterval(() => {
		if (ws.readyState !== ws.OPEN) {
			clearInterval(keepAlive);
			return;
		}

		ws.ping();
	}, KEEPALIVE_MS);

	ws.on('close', () => {
		clearInterval(keepAlive);
		onClose();
	});

	ws.on('error', () => {
		clearInterval(keepAlive);
		onClose();
	});
}

export function attachRealtimeServer(server: Server): RealtimeServerHandle {
	const wss = new WebSocketServer({ noServer: true });
	const guardWss = new WebSocketServer({ noServer: true });

	server.on('upgrade', (request, socket, head) => {
		const host = request.headers.host ?? '127.0.0.1';
		const url = new URL(request.url ?? '', `http://${host}`);

		if (url.pathname !== WS_PATH && url.pathname !== GUARD_WS_PATH) {
			return;
		}

		socket.pause();

		void (async () => {
			try {
				if (url.pathname === GUARD_WS_PATH) {
					let guardIdentity: { installationId: string; roomId: string } | null = null;
					const guardToken = getGuardBearerToken(request, url);
					if (guardToken) {
						try {
							const payload = await verifyGuardAccessToken(guardToken);
							const installation = await guardInstallationsService.getById(payload.installationId);
							if (
								installation.status === 'active' &&
								!installation.revokedAt &&
								installation.roomId === payload.roomId
							) {
								guardIdentity = { installationId: payload.installationId, roomId: payload.roomId };
							}
						} catch {
							guardIdentity = null;
						}
					}

					if (!guardIdentity) {
						socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
						socket.destroy();
						return;
					}

					guardWss.handleUpgrade(request, socket, head, (ws) => {
						guardRealtimeHub.addClient({ ws, ...guardIdentity! });
						attachKeepAlive(ws, () => guardRealtimeHub.removeClient(ws));
						logger.info('[guard-realtime] Guard WebSocket connected');
					});
					return;
				}

				const token = getBearerTokenFromRequest(url);
				if (!token) {
					socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
					socket.destroy();
					return;
				}

				let userId = '';
				let role = '';
				try {
					const payload = await verifyAccessToken(token);
					const user = await authService.getUserById(payload.sub);
					userId = user.id;
					role = user.role;
				} catch {
					socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
					socket.destroy();
					return;
				}

				wss.handleUpgrade(request, socket, head, (ws) => {
					realtimeHub.addClient({ ws, userId, role });

					logger.info('[realtime] WebSocket connected', { userId, role });

					void realtimeHub.sendInitialSnapshots(ws, role).catch((err) => {
						logger.error('[realtime] failed to send initial snapshots', err);
					});

					attachKeepAlive(ws, () => realtimeHub.removeClient(ws));
				});
			} catch (err) {
				logger.error('[realtime] websocket upgrade failed', err);
				socket.write('HTTP/1.1 500 Internal Server Error\r\n\r\n');
				socket.destroy();
			}
		})();
	});

	return {
		close: () => {
			wss.close();
			guardWss.close();
		}
	};
}
