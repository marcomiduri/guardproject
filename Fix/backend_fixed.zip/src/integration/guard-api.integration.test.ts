import express from 'express';
import request from 'node:http';
import { describe, expect, it } from 'vitest';
import { healthRouter } from '@/routes/health.js';
import { createApp } from '@/app.js';

function getJson(url: string): Promise<{ status: number; body: Record<string, unknown> }> {
	return new Promise((resolve, reject) => {
		request
			.get(url, (response) => {
				const chunks: Buffer[] = [];
				response.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
				response.on('end', () => {
					const text = Buffer.concat(chunks).toString('utf8');
					resolve({
						status: response.statusCode ?? 0,
						body: JSON.parse(text) as Record<string, unknown>
					});
				});
			})
			.on('error', reject)
			.end();
	});
}

function postJson(
	url: string,
	body: Record<string, unknown>
): Promise<{ status: number; body: Record<string, unknown> }> {
	return new Promise((resolve, reject) => {
		const target = new URL(url);
		const payload = Buffer.from(JSON.stringify(body));
		const req = request.request(
			{
				hostname: target.hostname,
				port: target.port,
				path: target.pathname,
				method: 'POST',
				headers: {
					'content-type': 'application/json',
					'content-length': payload.length
				}
			},
			(response) => {
				const chunks: Buffer[] = [];
				response.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
				response.on('end', () => {
					const text = Buffer.concat(chunks).toString('utf8');
					resolve({
						status: response.statusCode ?? 0,
						body: JSON.parse(text) as Record<string, unknown>
					});
				});
			}
		);
		req.on('error', reject);
		req.end(payload);
	});
}

describe('health endpoint', () => {
	it('returns version and serverTime for Guard', async () => {
		const app = express();
		app.use('/api/health', healthRouter);

		const server = app.listen(0);
		const address = server.address();
		const port = typeof address === 'object' && address ? address.port : 0;

		try {
			const { status, body } = await getJson(`http://127.0.0.1:${port}/api/health`);
			expect(status).toBe(200);
			expect(body.ok).toBe(true);
			expect(body.status).toBe('ok');
			expect(typeof body.version).toBe('string');
			expect(typeof body.serverTime).toBe('string');
		} finally {
			await new Promise<void>((resolve, reject) => {
				server.close((error) => (error ? reject(error) : resolve()));
			});
		}
	});
});

describe('API error envelope', () => {
	it('returns nested error objects for unknown routes', async () => {
		const app = createApp();
		const server = app.listen(0);
		const address = server.address();
		const port = typeof address === 'object' && address ? address.port : 0;

		try {
			const { status, body } = await getJson(`http://127.0.0.1:${port}/api/does-not-exist`);
			expect(status).toBe(404);
			expect(body.error).toEqual({
				code: 'NOT_FOUND',
				message: 'Not found',
				retryable: false
			});
		} finally {
			await new Promise<void>((resolve, reject) => {
				server.close((error) => (error ? reject(error) : resolve()));
			});
		}
	});
});

describe('temporary open Guard registration endpoint', () => {
	it('does not require the removed bootstrap API key or activation code for connect validation', async () => {
		const app = createApp();
		const server = app.listen(0);
		const address = server.address();
		const port = typeof address === 'object' && address ? address.port : 0;

		try {
			const { status, body } = await postJson(
				`http://127.0.0.1:${port}/api/guard/installations/connect`,
				{}
			);
			expect(status).toBe(400);
			expect(status).not.toBe(401);
			expect(body.error).toMatchObject({
				code: 'BAD_REQUEST',
				retryable: false
			});
		} finally {
			await new Promise<void>((resolve, reject) => {
				server.close((error) => (error ? reject(error) : resolve()));
			});
		}
	});
});

describe('removed commercial licensing endpoint', () => {
	it('returns not found for the former product-license activation route', async () => {
		const app = createApp();
		const server = app.listen(0);
		const address = server.address();
		const port = typeof address === 'object' && address ? address.port : 0;

		try {
			const { status, body } = await postJson(
				`http://127.0.0.1:${port}/api/guard/installations/license`,
				{}
			);
			expect(status).toBe(404);
			expect(body.error).toEqual({
				code: 'NOT_FOUND',
				message: 'Not found',
				retryable: false
			});
		} finally {
			await new Promise<void>((resolve, reject) => {
				server.close((error) => (error ? reject(error) : resolve()));
			});
		}
	});
});
