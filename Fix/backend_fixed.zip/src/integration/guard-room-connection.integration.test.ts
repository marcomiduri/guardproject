import { randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { eq } from 'drizzle-orm';
import pg from 'pg';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

function readDatabaseUrlFromEnvFile(): string | undefined {
	try {
		const content = readFileSync('.env', 'utf8');
		const match = content.match(/^DATABASE_URL=(.+)$/m);
		return match?.[1]?.trim();
	} catch {
		return undefined;
	}
}

const databaseUrl = readDatabaseUrlFromEnvFile() ?? process.env.DATABASE_URL;
if (databaseUrl) process.env.DATABASE_URL = databaseUrl;

async function probeDatabase(): Promise<boolean> {
	if (!databaseUrl) return false;
	const pool = new pg.Pool({ connectionString: databaseUrl });
	try {
		await pool.query('select 1');
		const columnCheck = await pool.query(
			"select is_nullable from information_schema.columns where table_name = 'guard_installations' and column_name = 'hardware_id_hash'"
		);
		const assignmentTableCheck = await pool.query(
			"select to_regclass('public.guard_installation_room_assignments') as table_name"
		);
		return (
			columnCheck.rows[0]?.is_nullable === 'YES' &&
			Boolean(assignmentTableCheck.rows[0]?.table_name)
		);
	} catch {
		return false;
	} finally {
		await pool.end();
	}
}

const dbReady = await probeDatabase();

let guardInstallationsService: typeof import('@/services/guard-installations.js').guardInstallationsService;
let guardRoomsService: typeof import('@/services/guard-rooms.js').guardRoomsService;
let db: typeof import('@/db/index.js').db;
let guardInstallations: typeof import('@/db/schema/guard.js').guardInstallations;
let guardRooms: typeof import('@/db/schema/guard.js').guardRooms;
let guardCameras: typeof import('@/db/schema/guard.js').guardCameras;
let guardInstallationRoomAssignments: typeof import('@/db/schema/guard.js').guardInstallationRoomAssignments;

const createdRoomIds: string[] = [];
const createdInstallationIds: string[] = [];

beforeAll(async () => {
	if (!dbReady) return;
	process.env.DATABASE_URL = databaseUrl!;
	const dbModule = await import('@/db/index.js');
	const schemaModule = await import('@/db/schema/guard.js');
	const serviceModule = await import('@/services/guard-installations.js');
	const roomsModule = await import('@/services/guard-rooms.js');
	db = dbModule.db;
	guardInstallations = schemaModule.guardInstallations;
	guardRooms = schemaModule.guardRooms;
	guardCameras = schemaModule.guardCameras;
	guardInstallationRoomAssignments = schemaModule.guardInstallationRoomAssignments;
	guardInstallationsService = serviceModule.guardInstallationsService;
	guardRoomsService = roomsModule.guardRoomsService;
});

afterAll(async () => {
	if (!dbReady) return;
	for (const installationId of createdInstallationIds) {
		await db.delete(guardCameras).where(eq(guardCameras.installationId, installationId));
		await db.delete(guardInstallations).where(eq(guardInstallations.id, installationId));
	}
	for (const roomId of createdRoomIds) {
		try {
			await guardRoomsService.remove(roomId);
		} catch {
			// Best-effort cleanup for local integration databases.
		}
	}
});

function camera(clientCameraId: string) {
	return {
		clientCameraId,
		name: 'Front Entrance',
		direction: 'in' as const,
		deviceAddress: '127.0.0.1'
	};
}

describe.skipIf(!dbReady)('guard room connection service (database)', () => {
	it('lists only safe room fields sorted by name', async () => {
		const alpha = await guardRoomsService.create({
			name: `Connect Alpha ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		const beta = await guardRoomsService.create({
			name: `Connect Beta ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		createdRoomIds.push(alpha.id, beta.id);

		const payload = await guardInstallationsService.listAvailableRooms();
		expect(payload.rooms.find((room) => room.id === alpha.id)).toEqual({
			id: alpha.id,
			name: alpha.name
		});
		expect(payload.rooms.find((room) => room.id === beta.id)).toEqual({
			id: beta.id,
			name: beta.name
		});
		expect(payload.rooms.map((room) => room.name)).toEqual(
			[...payload.rooms.map((room) => room.name)].sort((left, right) => left.localeCompare(right))
		);
	});

	it('connects without hardware identity and is idempotent', async () => {
		const room = await guardRoomsService.create({
			name: `Connect Room ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		createdRoomIds.push(room.id);

		const first = await guardInstallationsService.connect({
			roomId: room.id,
			deviceName: 'Integration Guard PC',
			applicationVersion: '2.0.0',
			cameras: [camera('cam-1')]
		});
		createdInstallationIds.push(first.installationId);

		expect(first.connectionState).toBe('connected');
		expect(first.deviceCredential).toBeTruthy();
		expect(first.cameras).toHaveLength(1);

		const [stored] = await db
			.select()
			.from(guardInstallations)
			.where(eq(guardInstallations.id, first.installationId))
			.limit(1);
		expect(stored?.hardwareIdHash).toBeNull();
		expect(stored?.deviceTokenHash).not.toBe(first.deviceCredential);

		const second = await guardInstallationsService.connect({
			roomId: room.id,
			installationId: first.installationId,
			deviceCredential: first.deviceCredential!,
			deviceName: 'Integration Guard PC',
			applicationVersion: '2.0.0',
			cameras: [camera('cam-1')]
		});
		expect(second.installationId).toBe(first.installationId);
		expect(second.deviceCredential).toBeUndefined();
		expect(second.cameras[0]?.backendCameraId).toBe(first.cameras[0]?.backendCameraId);

		const installations = await db
			.select({ id: guardInstallations.id })
			.from(guardInstallations)
			.where(eq(guardInstallations.id, first.installationId));
		expect(installations).toHaveLength(1);
	});

	it('normal disconnect retains the credential and can move the same installation to another room', async () => {
		const roomA = await guardRoomsService.create({
			name: `Move From Room ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		const roomB = await guardRoomsService.create({
			name: `Move To Room ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		createdRoomIds.push(roomA.id, roomB.id);
		const first = await guardInstallationsService.connect({
			roomId: roomA.id,
			deviceName: 'Movable Guard PC',
			cameras: [camera('movable-cam-1')]
		});
		createdInstallationIds.push(first.installationId);
		const roomACameraId = first.cameras[0]?.backendCameraId;

		const [beforeDisconnect] = await db
			.select()
			.from(guardInstallations)
			.where(eq(guardInstallations.id, first.installationId))
			.limit(1);
		await guardInstallationsService.disconnect(first.installationId);
		const [disconnected] = await db
			.select()
			.from(guardInstallations)
			.where(eq(guardInstallations.id, first.installationId))
			.limit(1);
		expect(disconnected?.status).toBe('disconnected');
		expect(disconnected?.revokedAt).toBeNull();
		expect(disconnected?.deviceTokenHash).toBe(beforeDisconnect?.deviceTokenHash);

		await expect(
			guardInstallationsService.exchangeDeviceToken({
				installationId: first.installationId,
				deviceToken: first.deviceCredential!
			})
		).rejects.toMatchObject({ code: 'INSTALLATION_NOT_CONNECTED', status: 409 });

		// Without installationId, connect creates a new registration (does not reclaim
		// the disconnected installation). Reconnect requires installationId + credential.
		const orphan = await guardInstallationsService.connect({
			roomId: roomB.id,
			deviceName: 'Movable Guard PC',
			cameras: [camera('movable-cam-1')]
		});
		createdInstallationIds.push(orphan.installationId);
		expect(orphan.installationId).not.toBe(first.installationId);

		const moved = await guardInstallationsService.connect({
			roomId: roomB.id,
			installationId: first.installationId,
			deviceCredential: first.deviceCredential!,
			deviceName: 'Movable Guard PC',
			// An already-open Guard dialog may still carry the previous
			// room-specific backend ID. The backend must ignore that stale ID
			// and create/find the room-B mapping by clientCameraId.
			cameras: [{ ...camera('movable-cam-1'), id: roomACameraId }]
		});
		expect(moved.installationId).toBe(first.installationId);
		expect(moved.deviceCredential).toBeUndefined();
		expect(moved.room.id).toBe(roomB.id);
		expect(moved.cameras[0]?.backendCameraId).not.toBe(roomACameraId);

		const token = await guardInstallationsService.exchangeDeviceToken({
			installationId: first.installationId,
			deviceToken: first.deviceCredential!
		});
		expect(token.accessToken).toBeTruthy();

		const [reconnected] = await db
			.select()
			.from(guardInstallations)
			.where(eq(guardInstallations.id, first.installationId))
			.limit(1);
		expect(reconnected?.status).toBe('active');
		expect(reconnected?.roomId).toBe(roomB.id);

		const cameras = await db
			.select({ id: guardCameras.id, roomId: guardCameras.roomId })
			.from(guardCameras)
			.where(eq(guardCameras.installationId, first.installationId));
		expect(cameras).toHaveLength(2);
		expect(cameras).toEqual(
			expect.arrayContaining([
				{ id: roomACameraId, roomId: roomA.id },
				{ id: moved.cameras[0]?.backendCameraId, roomId: roomB.id }
			])
		);

		const assignments = await db
			.select({
				roomId: guardInstallationRoomAssignments.roomId,
				disconnectedAt: guardInstallationRoomAssignments.disconnectedAt
			})
			.from(guardInstallationRoomAssignments)
			.where(eq(guardInstallationRoomAssignments.installationId, first.installationId));
		expect(assignments).toHaveLength(2);
		expect(assignments).toEqual(
			expect.arrayContaining([
				expect.objectContaining({ roomId: roomA.id, disconnectedAt: expect.any(Date) }),
				{ roomId: roomB.id, disconnectedAt: null }
			])
		);
	});

	it('blocks another room and keeps admin revocation separate', async () => {
		const roomA = await guardRoomsService.create({
			name: `Room A ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		const roomB = await guardRoomsService.create({
			name: `Room B ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		createdRoomIds.push(roomA.id, roomB.id);
		const first = await guardInstallationsService.connect({
			roomId: roomA.id,
			deviceName: 'Single Room Guard',
			cameras: []
		});
		createdInstallationIds.push(first.installationId);

		await expect(
			guardInstallationsService.connect({
				roomId: roomB.id,
				installationId: first.installationId,
				deviceCredential: first.deviceCredential!,
				deviceName: 'Single Room Guard',
				cameras: []
			})
		).rejects.toMatchObject({ code: 'INSTALLATION_ALREADY_CONNECTED_TO_ANOTHER_ROOM' });

		await guardInstallationsService.revokeForRoom(roomA.id, first.installationId);
		await expect(
			guardInstallationsService.exchangeDeviceToken({
				installationId: first.installationId,
				deviceToken: first.deviceCredential!
			})
		).rejects.toMatchObject({ code: 'INSTALLATION_REVOKED', status: 403 });
	});

	it('deletes a room and its Guard installations together', async () => {
		const room = await guardRoomsService.create({
			name: `Delete With Installation ${randomUUID().slice(0, 8)}`,
			maxMembers: 4
		});
		const connected = await guardInstallationsService.connect({
			roomId: room.id,
			deviceName: 'Room Delete Guard',
			cameras: [camera('delete-room-cam-1')]
		});

		await guardRoomsService.remove(room.id);

		const remainingRooms = await db
			.select({ id: guardRooms.id })
			.from(guardRooms)
			.where(eq(guardRooms.id, room.id));
		expect(remainingRooms).toHaveLength(0);

		const remainingInstallations = await db
			.select({ id: guardInstallations.id })
			.from(guardInstallations)
			.where(eq(guardInstallations.id, connected.installationId));
		expect(remainingInstallations).toHaveLength(0);

		const remainingAssignments = await db
			.select({ id: guardInstallationRoomAssignments.id })
			.from(guardInstallationRoomAssignments)
			.where(eq(guardInstallationRoomAssignments.roomId, room.id));
		expect(remainingAssignments).toHaveLength(0);

		const remainingCameras = await db
			.select({ id: guardCameras.id })
			.from(guardCameras)
			.where(eq(guardCameras.roomId, room.id));
		expect(remainingCameras).toHaveLength(0);
	});
});
