import type { SQL } from 'drizzle-orm';

export function collectColumnFilterConditions<TFilter>(
	filters: TFilter[] | undefined,
	buildCondition: (filter: TFilter) => SQL | undefined
): SQL[] {
	if (!filters?.length) return [];

	const conditions: SQL[] = [];

	for (const filter of filters) {
		const condition = buildCondition(filter);
		if (condition) conditions.push(condition);
	}

	return conditions;
}
