export const DEFAULT_LIST_LIMIT = 50;
export const MAX_LIST_LIMIT = 100;

export function clampListPagination(options: { limit?: number; offset?: number }): {
	limit: number;
	offset: number;
} {
	return {
		limit: Math.min(Math.max(options.limit ?? DEFAULT_LIST_LIMIT, 1), MAX_LIST_LIMIT),
		offset: Math.max(options.offset ?? 0, 0)
	};
}
