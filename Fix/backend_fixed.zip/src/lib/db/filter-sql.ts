import { eq, gte, ilike, lte, sql, type AnyColumn, type SQL } from 'drizzle-orm';

import type { ColumnFilterComparator } from '@/types/list-query.js';

export function numberColumnFilter(
	expr: SQL,
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const amount = Number(value);
	if (!Number.isFinite(amount)) return undefined;

	if (comparator === 'eq') return sql`${expr} = ${amount}`;
	if (comparator === 'gte') return sql`${expr} >= ${amount}`;
	if (comparator === 'lte') return sql`${expr} <= ${amount}`;

	return undefined;
}

export function textColumnFilter(
	column: AnyColumn,
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const text = String(value);

	if (comparator === 'eq') return eq(column, text);
	if (comparator === 'contains') return ilike(column, `%${text}%`);

	return undefined;
}

export function timestampColumnFilter(
	textExpr: SQL,
	dateColumn: AnyColumn,
	comparator: ColumnFilterComparator,
	value: string | number
): SQL | undefined {
	const text = String(value);

	if (comparator === 'eq') return sql`${textExpr} = ${text}`;
	if (comparator === 'contains') return ilike(textExpr, `%${text}%`);
	if (comparator === 'gte') return gte(dateColumn, new Date(text));
	if (comparator === 'lte') return lte(dateColumn, new Date(text));

	return undefined;
}
