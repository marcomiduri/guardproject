import { assertUserRole, type User } from '@/db/schema/auth.js';
import type { AuthUser } from '@/types/auth.js';

export function toAuthUser(user: User): AuthUser {
	return {
		id: user.id,
		username: user.username,
		email: user.email,
		role: assertUserRole(user.role),
		birthday: user.birthday ?? null,
		job: user.job ?? null,
		position: user.position ?? null
	};
}
