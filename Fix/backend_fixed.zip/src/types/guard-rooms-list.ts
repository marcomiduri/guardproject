import type { BaseListQueryOptions, ColumnFilter } from '@/types/list-query.js';

export const GUARD_ROOMS_FILTER_COLUMNS = [
	'name',
	'currentCount',
	'cameraCount',
	'maxMembers',
	'sortOrder',
	'createdAt'
] as const;

export type GuardRoomsFilterColumn = (typeof GUARD_ROOMS_FILTER_COLUMNS)[number];

export const GUARD_ROOMS_LIST_SORT_FIELDS = [
	'name',
	'currentCount',
	'cameraCount',
	'maxMembers',
	'sortOrder',
	'createdAt'
] as const;

export type GuardRoomsListSortField = (typeof GUARD_ROOMS_LIST_SORT_FIELDS)[number];

export type GuardRoomsColumnFilter = ColumnFilter<GuardRoomsFilterColumn, string | number>;

export type ListGuardRoomsOptions = BaseListQueryOptions<
	GuardRoomsListSortField,
	GuardRoomsColumnFilter
>;
