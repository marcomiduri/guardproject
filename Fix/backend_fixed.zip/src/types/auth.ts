export interface AuthUser {
	id: string;
	username: string;
	email: string;
	role: string;
	birthday: string | null;
	job: string | null;
	position: string | null;
}

export interface JwtPayload {
	sub: string;
	email: string;
	role: string;
}

export interface AuthTokenResponse {
	accessToken: string;
	user: AuthUser;
}
