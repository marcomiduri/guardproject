export type UpdateInput<T> = Partial<Omit<T, 'id'>>;
