import type { BaseListQueryOptions, ColumnFilter } from '@/types/list-query.js';

export const SAFETY_EVENTS_FILTER_COLUMNS = [
	'hazardType',
	'roomName',
	'cameraName',
	'confidence',
	'status',
	'occurredAt'
] as const;

export type SafetyEventsFilterColumn = (typeof SAFETY_EVENTS_FILTER_COLUMNS)[number];

export const SAFETY_EVENTS_LIST_SORT_FIELDS = [
	'hazardType',
	'roomName',
	'cameraName',
	'confidence',
	'status',
	'occurredAt',
	'createdAt'
] as const;

export type SafetyEventsListSortField = (typeof SAFETY_EVENTS_LIST_SORT_FIELDS)[number];

export type SafetyEventsColumnFilter = ColumnFilter<SafetyEventsFilterColumn, string | number>;

export type ListSafetyEventsOptions = BaseListQueryOptions<
	SafetyEventsListSortField,
	SafetyEventsColumnFilter
>;
