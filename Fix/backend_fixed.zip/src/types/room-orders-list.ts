import type { BaseListQueryOptions, ColumnFilter } from '@/types/list-query.js';

export const ROOM_ORDER_FILTER_COLUMNS = [
	'roomName',
	'startTime',
	'endTime',
	'status',
	'createdAt'
] as const;

export type RoomOrderFilterColumn = (typeof ROOM_ORDER_FILTER_COLUMNS)[number];

export const ROOM_ORDER_LIST_SORT_FIELDS = [
	'roomName',
	'startTime',
	'endTime',
	'status',
	'createdAt'
] as const;

export type RoomOrderListSortField = (typeof ROOM_ORDER_LIST_SORT_FIELDS)[number];

export const ADMIN_ROOM_ORDER_FILTER_COLUMNS = [...ROOM_ORDER_FILTER_COLUMNS, 'username'] as const;

export type AdminRoomOrderFilterColumn = (typeof ADMIN_ROOM_ORDER_FILTER_COLUMNS)[number];

export const ADMIN_ROOM_ORDER_LIST_SORT_FIELDS = [
	...ROOM_ORDER_LIST_SORT_FIELDS,
	'username'
] as const;

export type AdminRoomOrderListSortField = (typeof ADMIN_ROOM_ORDER_LIST_SORT_FIELDS)[number];

export type RoomOrderColumnFilter = ColumnFilter<RoomOrderFilterColumn, string>;

export type AdminRoomOrderColumnFilter = ColumnFilter<AdminRoomOrderFilterColumn, string>;

export type ListRoomOrdersOptions = BaseListQueryOptions<
	RoomOrderListSortField,
	RoomOrderColumnFilter
> & {
	userId: string;
};

export type ListAdminRoomOrdersOptions = BaseListQueryOptions<
	AdminRoomOrderListSortField,
	AdminRoomOrderColumnFilter
>;
