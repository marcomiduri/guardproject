import type { BaseListQueryOptions, ColumnFilter } from '@/types/list-query.js';

export const IN_OUT_FILTER_COLUMNS = [
	'username',
	'role',
	'cameraId',
	'cameraAddress',
	'direction',
	'eventType',
	'recognitionStatus',
	'orderStatus',
	'similarity',
	'occurredAt'
] as const;

export type InOutFilterColumn = (typeof IN_OUT_FILTER_COLUMNS)[number];

export const IN_OUT_LIST_SORT_FIELDS = [
	'username',
	'role',
	'cameraAddress',
	'direction',
	'eventType',
	'recognitionStatus',
	'orderStatus',
	'similarity',
	'occurredAt'
] as const;

export type InOutListSortField = (typeof IN_OUT_LIST_SORT_FIELDS)[number];

export type InOutColumnFilter = ColumnFilter<InOutFilterColumn, string | number>;

export type ListInOutOptions = BaseListQueryOptions<InOutListSortField, InOutColumnFilter> & {
	roomId?: string;
	/** When set, results are limited to this user's face appearances. */
	userId?: string;
};
