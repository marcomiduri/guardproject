import type { BaseListQueryOptions, ColumnFilter } from '@/types/list-query.js';

export const ADMIN_USERS_FILTER_COLUMNS = [
	'username',
	'email',
	'birthday',
	'job',
	'position',
	'role',
	'faceRegisteredAt',
	'createdAt'
] as const;

export type AdminUsersFilterColumn = (typeof ADMIN_USERS_FILTER_COLUMNS)[number];

export const ADMIN_USERS_LIST_SORT_FIELDS = [
	'username',
	'email',
	'birthday',
	'job',
	'position',
	'role',
	'faceRegisteredAt',
	'createdAt'
] as const;

export type AdminUsersListSortField = (typeof ADMIN_USERS_LIST_SORT_FIELDS)[number];

export type AdminUsersColumnFilter = ColumnFilter<AdminUsersFilterColumn, string>;

export type ListAdminUsersOptions = BaseListQueryOptions<
	AdminUsersListSortField,
	AdminUsersColumnFilter
>;
