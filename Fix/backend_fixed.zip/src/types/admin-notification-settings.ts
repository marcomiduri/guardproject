export type AdminNotificationSettings = {
	notifyUnapprovedIncoming: boolean;
	notifyUnknownIncoming: boolean;
};

export const DEFAULT_ADMIN_NOTIFICATION_SETTINGS: AdminNotificationSettings = {
	notifyUnapprovedIncoming: true,
	notifyUnknownIncoming: true
};
