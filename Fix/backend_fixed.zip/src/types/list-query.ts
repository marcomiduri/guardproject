export const COLUMN_FILTER_COMPARATORS = ['eq', 'contains', 'gte', 'lte'] as const;

export type ColumnFilterComparator = (typeof COLUMN_FILTER_COMPARATORS)[number];

export type SortOrder = 'asc' | 'desc';

export type ColumnFilter<TColumn extends string, TValue = string | number> = {
	column: TColumn;
	comparator: ColumnFilterComparator;
	value: TValue;
};

export type BaseListQueryOptions<
	TSortField extends string,
	TFilter extends ColumnFilter<string, string | number>
> = {
	limit?: number;
	offset?: number;
	search?: string;
	sortBy?: TSortField;
	sortOrder?: SortOrder;
	columnFilters?: TFilter[];
};
