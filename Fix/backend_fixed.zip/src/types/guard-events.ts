import type { GuardHazardDetection, GuardHazardType } from '@/db/schema/guard.js';
import type { SafetyEventRecord } from '@/services/guard-hazard-events.js';

export type GuardHazardDetectedEvent = {
	id: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	hazardType: GuardHazardType;
	confidence: number | null;
	occurredAt: Date;
};

export type HazardDetectedPayload = {
	id: string;
	roomId: string;
	roomName: string;
	cameraId: string;
	cameraName: string;
	hazardType: GuardHazardType;
	confidence: number | null;
	detections: GuardHazardDetection[] | null;
	status: string;
	source: string;
	testScenario: string | null;
	occurredAt: string;
	snapshotUrl: string | null;
};

export function serializeHazardDetectedEvent(event: SafetyEventRecord): HazardDetectedPayload {
	return {
		id: event.id,
		roomId: event.roomId,
		roomName: event.roomName,
		cameraId: event.cameraId,
		cameraName: event.cameraName,
		hazardType: event.hazardType,
		confidence: event.confidence,
		detections: event.detections,
		status: event.status,
		source: event.source,
		testScenario: event.testScenario,
		occurredAt: event.occurredAt.toISOString(),
		snapshotUrl: event.snapshotUrl
	};
}
