import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadEnvFile } from './loadEnvFile.js';

const envPath = resolve(fileURLToPath(new URL('../../.env', import.meta.url)));
if (existsSync(envPath)) {
	loadEnvFile(envPath);
}

function required(name: string, value: string | undefined): string {
	if (!value) {
		throw new Error(`Missing required environment variable: ${name}`);
	}
	return value;
}

const nodeEnv = process.env.NODE_ENV ?? 'development';
const isProduction = nodeEnv === 'production';

function parseNonNegativeInt(value: string | undefined, fallback: number): number {
	if (value === undefined || value.trim() === '') {
		return fallback;
	}

	const parsed = Number.parseInt(value, 10);
	if (!Number.isFinite(parsed) || parsed < 0) {
		return fallback;
	}

	return parsed;
}

function parsePositiveInt(value: string | undefined, fallback: number): number {
	const parsed = parseNonNegativeInt(value, fallback);
	return parsed > 0 ? parsed : fallback;
}

const jwtSecret =
	process.env.JWT_SECRET ??
	(isProduction ? required('JWT_SECRET', undefined) : 'dev-jwt-secret-change-me-in-production');

export const env = {
	NODE_ENV: nodeEnv,
	HOST: process.env.HOST?.trim() || '127.0.0.1',
	PORT: Number(process.env.PORT ?? 3000),
	DATABASE_URL: required('DATABASE_URL', process.env.DATABASE_URL),
	FRONTEND_URL: process.env.FRONTEND_URL ?? 'http://127.0.0.1:4001',
	UPLOADS_DIR: resolve(
		process.env.UPLOADS_DIR?.trim() || fileURLToPath(new URL('../../uploads', import.meta.url))
	),
	FACE_EXTRACTOR_BIN: process.env.FACE_EXTRACTOR_BIN ?? '',
	IDENTIFY_MODEL_PATH: process.env.IDENTIFY_MODEL_PATH ?? process.env.INSPIREFACE_MODEL_PATH ?? '',
	FACE_MODEL_NAME: process.env.FACE_MODEL_NAME ?? 'Pikachu',
	FACE_RECOGNITION_THRESHOLD: Number(process.env.FACE_RECOGNITION_THRESHOLD ?? 0.48),
	JWT_SECRET: jwtSecret,
	JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN ?? '7d',
	GUARD_JWT_SECRET: process.env.GUARD_JWT_SECRET ?? jwtSecret,
	GUARD_JWT_EXPIRES_IN: process.env.GUARD_JWT_EXPIRES_IN ?? '15m',
	GUARD_JWT_ISSUER: process.env.GUARD_JWT_ISSUER ?? 'guard-backend',
	GUARD_JWT_AUDIENCE: process.env.GUARD_JWT_AUDIENCE ?? 'guard-api',
	GUARD_DEVICE_TOKEN_PEPPER:
		process.env.GUARD_DEVICE_TOKEN_PEPPER ??
		(isProduction ? required('GUARD_DEVICE_TOKEN_PEPPER', undefined) : `${jwtSecret}:device-token`),
	GUARD_ACTIVATION_CODE_PEPPER:
		process.env.GUARD_ACTIVATION_CODE_PEPPER ??
		(isProduction
			? required('GUARD_ACTIVATION_CODE_PEPPER', undefined)
			: `${jwtSecret}:activation-code`),
	GUARD_DEVICE_TOKEN_PREVIOUS_GRACE_SECONDS: parsePositiveInt(
		process.env.GUARD_DEVICE_TOKEN_PREVIOUS_GRACE_SECONDS,
		600
	),
	GUARD_ACTIVATION_CODE_TTL_MINUTES: parsePositiveInt(
		process.env.GUARD_ACTIVATION_CODE_TTL_MINUTES,
		30
	),
	/** Delete in-out records older than this many days. Set to 0 to disable automatic purge. */
	IN_OUT_RETENTION_DAYS: parseNonNegativeInt(process.env.IN_OUT_RETENTION_DAYS, 90),
	/** How often to run in-out retention cleanup while the server is running (ms). */
	IN_OUT_RETENTION_CLEANUP_INTERVAL_MS: parseNonNegativeInt(
		process.env.IN_OUT_RETENTION_CLEANUP_INTERVAL_MS,
		24 * 60 * 60 * 1000
	),
	/** CORS allowed origin(s). Use `*` or `*.*` to allow any origin. Comma-separated for multiple. */
	CORS_ORIGIN: process.env.CORS_ORIGIN ?? '*.*'
};

export type CorsOriginConfig = boolean | string | string[];

export function resolveCorsOrigin(value: string): CorsOriginConfig {
	const trimmed = value.trim();
	if (trimmed === '*' || trimmed === '*.*') {
		return true;
	}

	if (trimmed.includes(',')) {
		return trimmed
			.split(',')
			.map((part) => part.trim())
			.filter(Boolean);
	}

	return trimmed;
}
