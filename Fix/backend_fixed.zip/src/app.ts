import express, { type Express } from 'express';
import { applyGlobalMiddleware } from '@/middleware/index.js';
import { errorHandler } from '@/middleware/error-handler.js';
import { notFoundHandler } from '@/middleware/not-found.js';
import { apiRouter } from '@/routes/index.js';

export function createApp(): Express {
	const app = express();

	applyGlobalMiddleware(app);

	app.use('/api', apiRouter);

	app.use(notFoundHandler);
	app.use(errorHandler);

	return app;
}
