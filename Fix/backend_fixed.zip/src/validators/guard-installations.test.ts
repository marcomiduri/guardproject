import { describe, expect, it } from 'vitest';
import { parseActivateGuardInstallationBody } from './guard-installations.js';

describe('Guard installation activation validation', () => {
	it('accepts room registration without a license or activation code', () => {
		const input = parseActivateGuardInstallationBody({
			roomIdentifier: 'Warehouse',
			hardwareId: 'ABCDEF0123456789',
			deviceName: 'Warehouse Guard PC',
			guardVersion: '2.0.0',
			cameras: []
		});

		expect(input).toEqual({
			roomIdentifier: 'Warehouse',
			hardwareId: 'ABCDEF0123456789',
			deviceName: 'Warehouse Guard PC',
			applicationVersion: '2.0.0',
			cameras: []
		});
		expect(input).not.toHaveProperty('activationCode');
	});
});
