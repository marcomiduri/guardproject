import { badRequest } from '@/services/errors.js';

import {
	IN_OUT_FILTER_COLUMNS,
	IN_OUT_LIST_SORT_FIELDS,
	type InOutColumnFilter,
	type InOutListSortField,
	type ListInOutOptions
} from '@/types/in-out-list.js';
import {
	parseColumnFilterRawValue,
	parseColumnFilters,
	parseTrimmedColumnFilterText,
	validateColumnFilterColumn,
	validateColumnFilterComparator
} from '@/validators/list-query-parsing.js';
import {
	isRecord,
	parseOptionalNonNegativeInt,
	parseOptionalQueryString,
	parseSortBy,
	parseSortOrder
} from '@/validators/parsing.js';

function parseInOutColumnFilterItem(value: unknown, index: number): InOutColumnFilter {
	if (!isRecord(value)) {
		throw badRequest(`columnFilters[${index}] must be an object`);
	}

	const column = validateColumnFilterColumn(value.column, index, IN_OUT_FILTER_COLUMNS);
	const comparator = validateColumnFilterComparator(value.comparator, index);
	const rawValue = parseColumnFilterRawValue(value.value, index);

	if (column === 'similarity') {
		const amount = Number(rawValue);
		if (!Number.isFinite(amount) || amount < 0 || amount > 100) {
			throw badRequest(
				`columnFilters[${index}].value must be a number between 0 and 100 for similarity`
			);
		}
		return { column, comparator, value: amount };
	}

	const text = parseTrimmedColumnFilterText(rawValue, index);

	return { column, comparator, value: text };
}

export function parseListInOutQuery(query: Record<string, unknown>): ListInOutOptions {
	return {
		limit: parseOptionalNonNegativeInt(query.limit, 'limit'),
		offset: parseOptionalNonNegativeInt(query.offset, 'offset'),
		search: parseOptionalQueryString(query.search, 'search', 255),
		roomId: parseOptionalQueryString(query.roomId, 'roomId', 64),
		sortBy: parseSortBy<InOutListSortField>(query.sortBy, IN_OUT_LIST_SORT_FIELDS),
		sortOrder: parseSortOrder(query.sortOrder),
		columnFilters: parseColumnFilters(query.columnFilters, parseInOutColumnFilterItem)
	};
}
