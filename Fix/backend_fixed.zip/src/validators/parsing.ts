import { badRequest } from '@/services/errors.js';

import type { SortOrder } from '@/types/list-query.js';

export function isRecord(value: unknown): value is Record<string, unknown> {
	return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function parseOptionalNonNegativeInt(value: unknown, field: string): number | undefined {
	if (value === undefined || value === null || value === '') return undefined;

	const num = Number(value);

	if (!Number.isInteger(num) || num < 0) {
		throw badRequest(`${field} must be a non-negative integer`);
	}

	return num;
}

export function parseOptionalInt(value: unknown, field: string): number | undefined {
	if (value === undefined || value === null || value === '') return undefined;

	const num = Number(value);

	if (!Number.isInteger(num)) {
		throw badRequest(`${field} must be an integer`);
	}

	return num;
}

export function parseOptionalQueryString(
	value: unknown,
	field: string,
	maxLength: number
): string | undefined {
	if (value === undefined || value === null) return undefined;

	if (typeof value !== 'string') {
		throw badRequest(`${field} must be a string`);
	}

	const trimmed = value.trim();

	if (trimmed.length === 0) return undefined;

	if (trimmed.length > maxLength) {
		throw badRequest(`${field} must be at most ${maxLength} characters`);
	}

	return trimmed;
}

export function parseOptionalString(
	value: unknown,
	field: string,
	maxLength: number
): string | undefined {
	if (value === undefined || value === null) return undefined;

	if (typeof value !== 'string') {
		throw badRequest(`${field} must be a string`);
	}

	const trimmed = value.trim();

	if (trimmed.length > maxLength) {
		throw badRequest(`${field} must be at most ${maxLength} characters`);
	}

	return trimmed;
}

export function parseRequiredString(value: unknown, field: string, maxLength: number): string {
	const trimmed = parseOptionalQueryString(value, field, maxLength);

	if (!trimmed) {
		throw badRequest(`${field} is required`);
	}

	return trimmed;
}

export function parseRequiredTrimmedString(
	value: unknown,
	field: string,
	options: { min?: number; max?: number } = {}
): string {
	const min = options.min ?? 1;
	const max = options.max ?? 255;

	if (typeof value !== 'string') {
		throw badRequest(`${field} must be a string`);
	}

	const trimmed = value.trim();
	if (trimmed.length < min) {
		throw badRequest(`${field} is required`);
	}
	if (trimmed.length > max) {
		throw badRequest(`${field} must be at most ${max} characters`);
	}

	return trimmed;
}

export function parseRequiredIdParam(value: string, entityLabel: string): string {
	const trimmed = value.trim();
	if (!trimmed) {
		throw badRequest(`${entityLabel} is required`);
	}
	return trimmed;
}

export function parseEnumMember<T extends string>(
	value: unknown,
	allowed: readonly T[],
	field: string
): T {
	if (typeof value !== 'string') {
		throw badRequest(`${field} must be a string`);
	}

	const normalized = value.trim().toLowerCase();
	const match = allowed.find((entry) => entry.toLowerCase() === normalized);
	if (!match) {
		throw badRequest(`${field} must be one of: ${allowed.join(', ')}`);
	}

	return match;
}

export function parseSortBy<T extends string>(
	value: unknown,
	allowedFields: readonly T[],
	fieldLabel = 'sortBy'
): T | undefined {
	if (value === undefined || value === null || value === '') return undefined;

	if (typeof value !== 'string') {
		throw badRequest(`${fieldLabel} must be a string`);
	}

	if (!allowedFields.includes(value as T)) {
		throw badRequest(`${fieldLabel} must be one of: ${allowedFields.join(', ')}`);
	}

	return value as T;
}

export function parseSortOrder(value: unknown): SortOrder | undefined {
	if (value === undefined || value === null || value === '') return undefined;

	if (value !== 'asc' && value !== 'desc') {
		throw badRequest('sortOrder must be asc or desc');
	}

	return value;
}
