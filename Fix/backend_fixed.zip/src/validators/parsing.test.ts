import { describe, expect, it } from 'vitest';

import { AppError } from '@/services/errors.js';
import {
	isRecord,
	parseOptionalInt,
	parseOptionalNonNegativeInt,
	parseOptionalQueryString,
	parseOptionalString,
	parseRequiredString,
	parseSortBy,
	parseSortOrder
} from '@/validators/parsing.js';

const SORT_FIELDS = ['name', 'createdAt'] as const;

function expectBadRequest(fn: () => unknown, message: string): void {
	try {
		fn();
		expect.unreachable('Expected badRequest to throw');
	} catch (error) {
		expect(error).toBeInstanceOf(AppError);
		expect((error as AppError).status).toBe(400);
		expect((error as AppError).message).toBe(message);
	}
}

describe('isRecord', () => {
	it('accepts plain objects', () => {
		expect(isRecord({})).toBe(true);
		expect(isRecord({ a: 1 })).toBe(true);
	});

	it('rejects non-objects', () => {
		expect(isRecord(null)).toBe(false);
		expect(isRecord(undefined)).toBe(false);
		expect(isRecord([])).toBe(false);
		expect(isRecord('x')).toBe(false);
	});
});

describe('parseOptionalNonNegativeInt', () => {
	it('returns undefined for empty values', () => {
		expect(parseOptionalNonNegativeInt(undefined, 'limit')).toBeUndefined();
		expect(parseOptionalNonNegativeInt(null, 'limit')).toBeUndefined();
		expect(parseOptionalNonNegativeInt('', 'limit')).toBeUndefined();
	});

	it('parses valid integers', () => {
		expect(parseOptionalNonNegativeInt(0, 'limit')).toBe(0);
		expect(parseOptionalNonNegativeInt('12', 'limit')).toBe(12);
	});

	it('rejects negative and non-integer values', () => {
		expectBadRequest(
			() => parseOptionalNonNegativeInt(-1, 'limit'),
			'limit must be a non-negative integer'
		);
		expectBadRequest(
			() => parseOptionalNonNegativeInt(1.5, 'limit'),
			'limit must be a non-negative integer'
		);
	});
});

describe('parseOptionalInt', () => {
	it('allows negative integers', () => {
		expect(parseOptionalInt('-3', 'offset')).toBe(-3);
	});

	it('rejects non-integers', () => {
		expectBadRequest(() => parseOptionalInt('1.2', 'offset'), 'offset must be an integer');
	});
});

describe('parseOptionalQueryString', () => {
	it('trims and returns non-empty strings', () => {
		expect(parseOptionalQueryString('  hello  ', 'search', 20)).toBe('hello');
	});

	it('returns undefined for blank strings', () => {
		expect(parseOptionalQueryString('   ', 'search', 20)).toBeUndefined();
	});

	it('enforces max length', () => {
		expectBadRequest(
			() => parseOptionalQueryString('abcdef', 'search', 3),
			'search must be at most 3 characters'
		);
	});
});

describe('parseOptionalString', () => {
	it('allows empty trimmed strings', () => {
		expect(parseOptionalString('   ', 'name', 10)).toBe('');
	});
});

describe('parseRequiredString', () => {
	it('requires a non-empty value', () => {
		expect(parseRequiredString(' room ', 'name', 20)).toBe('room');
		expectBadRequest(() => parseRequiredString('   ', 'name', 20), 'name is required');
	});
});

describe('parseSortBy', () => {
	it('returns undefined when omitted', () => {
		expect(parseSortBy(undefined, SORT_FIELDS)).toBeUndefined();
	});

	it('accepts allowed fields', () => {
		expect(parseSortBy('name', SORT_FIELDS)).toBe('name');
	});

	it('rejects unknown fields', () => {
		expectBadRequest(
			() => parseSortBy('unknown', SORT_FIELDS),
			'sortBy must be one of: name, createdAt'
		);
	});
});

describe('parseSortOrder', () => {
	it('accepts asc and desc', () => {
		expect(parseSortOrder('asc')).toBe('asc');
		expect(parseSortOrder('desc')).toBe('desc');
	});

	it('rejects invalid values', () => {
		expectBadRequest(() => parseSortOrder('up'), 'sortOrder must be asc or desc');
	});
});
