import { USER_ROLES, type UserRole } from '@/db/schema/auth.js';
import { badRequest } from '@/services/errors.js';

import {
	ADMIN_USERS_FILTER_COLUMNS,
	ADMIN_USERS_LIST_SORT_FIELDS,
	type AdminUsersFilterColumn,
	type AdminUsersListSortField,
	type ListAdminUsersOptions
} from '@/types/admin-users-list.js';
import {
	createTextColumnFilterParser,
	parseColumnFilters
} from '@/validators/list-query-parsing.js';
import {
	parseOptionalNonNegativeInt,
	parseOptionalQueryString,
	parseRequiredIdParam,
	parseSortBy,
	parseSortOrder
} from '@/validators/parsing.js';

const parseAdminUsersColumnFilterItem = createTextColumnFilterParser<AdminUsersFilterColumn>(
	ADMIN_USERS_FILTER_COLUMNS
);

export function parseUpdateAdminUserBody(body: unknown): { role: UserRole } {
	if (typeof body !== 'object' || body === null || Array.isArray(body)) {
		throw badRequest('Request body must be an object');
	}

	const role = (body as Record<string, unknown>).role;

	if (typeof role !== 'string' || !USER_ROLES.includes(role as UserRole)) {
		throw badRequest(`role must be one of: ${USER_ROLES.join(', ')}`);
	}

	return { role: role as UserRole };
}

export function parseAdminUserIdParam(value: string): string {
	return parseRequiredIdParam(value, 'User id');
}

export function parseListAdminUsersQuery(query: Record<string, unknown>): ListAdminUsersOptions {
	return {
		limit: parseOptionalNonNegativeInt(query.limit, 'limit'),
		offset: parseOptionalNonNegativeInt(query.offset, 'offset'),
		search: parseOptionalQueryString(query.search, 'search', 255),
		sortBy: parseSortBy<AdminUsersListSortField>(query.sortBy, ADMIN_USERS_LIST_SORT_FIELDS),
		sortOrder: parseSortOrder(query.sortOrder),
		columnFilters: parseColumnFilters(query.columnFilters, parseAdminUsersColumnFilterItem)
	};
}
