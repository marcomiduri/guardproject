import { badRequest } from '@/services/errors.js';
import { isRecord, parseRequiredTrimmedString } from '@/validators/parsing.js';

const MIN_PASSWORD_LENGTH = 8;

function parseEmail(value: unknown): string {
	const email = parseRequiredTrimmedString(value, 'email', { min: 3, max: 255 }).toLowerCase();
	if (!email.includes('@')) {
		throw badRequest('Email must be valid');
	}
	return email;
}

function parseCurrentPassword(value: unknown): string {
	return parseRequiredTrimmedString(value, 'currentPassword', { min: 1, max: 128 });
}

function parseNewPassword(value: unknown): string {
	const password = parseRequiredTrimmedString(value, 'newPassword', {
		min: MIN_PASSWORD_LENGTH,
		max: 128
	});
	if (password.length < MIN_PASSWORD_LENGTH) {
		throw badRequest(`newPassword must be at least ${MIN_PASSWORD_LENGTH} characters`);
	}
	return password;
}

export function parseUpdateEmailBody(body: unknown): { email: string; currentPassword: string } {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	return {
		email: parseEmail(body.email),
		currentPassword: parseCurrentPassword(body.currentPassword)
	};
}

export function parseUpdatePasswordBody(body: unknown): {
	currentPassword: string;
	newPassword: string;
} {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	return {
		currentPassword: parseCurrentPassword(body.currentPassword),
		newPassword: parseNewPassword(body.newPassword)
	};
}

export function parseCloseAccountBody(body: unknown): { currentPassword: string } {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	return {
		currentPassword: parseCurrentPassword(body.currentPassword)
	};
}
