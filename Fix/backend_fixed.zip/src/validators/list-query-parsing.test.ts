import { describe, expect, it } from 'vitest';

import { AppError } from '@/services/errors.js';
import {
	createTextColumnFilterParser,
	parseColumnFilters,
	parseTrimmedColumnFilterText,
	validateColumnFilterColumn,
	validateColumnFilterComparator
} from '@/validators/list-query-parsing.js';

const COLUMNS = ['name', 'status'] as const;

function expectBadRequest(fn: () => unknown, message: string): void {
	try {
		fn();
		expect.unreachable('Expected badRequest to throw');
	} catch (error) {
		expect(error).toBeInstanceOf(AppError);
		expect((error as AppError).message).toBe(message);
	}
}

describe('validateColumnFilterColumn', () => {
	it('accepts allowed columns', () => {
		expect(validateColumnFilterColumn('name', 0, COLUMNS)).toBe('name');
	});

	it('rejects unknown columns', () => {
		expectBadRequest(
			() => validateColumnFilterColumn('room', 1, COLUMNS),
			'columnFilters[1].column must be one of: name, status'
		);
	});
});

describe('validateColumnFilterComparator', () => {
	it('accepts supported comparators', () => {
		expect(validateColumnFilterComparator('contains', 0)).toBe('contains');
	});

	it('rejects unsupported comparators', () => {
		expectBadRequest(
			() => validateColumnFilterComparator('like', 0),
			'columnFilters[0].comparator must be one of: eq, contains, gte, lte'
		);
	});
});

describe('parseTrimmedColumnFilterText', () => {
	it('trims and validates text', () => {
		expect(parseTrimmedColumnFilterText('  abc  ', 0)).toBe('abc');
	});

	it('rejects empty values', () => {
		expectBadRequest(
			() => parseTrimmedColumnFilterText('   ', 2),
			'columnFilters[2].value must not be empty'
		);
	});
});

describe('createTextColumnFilterParser', () => {
	const parseFilter = createTextColumnFilterParser(COLUMNS);

	it('parses a valid filter object', () => {
		expect(parseFilter({ column: 'name', comparator: 'eq', value: '  Room A ' }, 0)).toEqual({
			column: 'name',
			comparator: 'eq',
			value: 'Room A'
		});
	});

	it('rejects non-object items', () => {
		expectBadRequest(() => parseFilter('bad', 0), 'columnFilters[0] must be an object');
	});
});

describe('parseColumnFilters', () => {
	const parseFilter = createTextColumnFilterParser(COLUMNS);

	it('returns undefined when omitted', () => {
		expect(parseColumnFilters(undefined, parseFilter)).toBeUndefined();
	});

	it('parses JSON string payloads', () => {
		const filters = parseColumnFilters(
			JSON.stringify([{ column: 'status', comparator: 'contains', value: 'open' }]),
			parseFilter
		);

		expect(filters).toEqual([{ column: 'status', comparator: 'contains', value: 'open' }]);
	});

	it('rejects invalid JSON', () => {
		expectBadRequest(
			() => parseColumnFilters('{', parseFilter),
			'columnFilters must be valid JSON'
		);
	});

	it('rejects non-array payloads', () => {
		expectBadRequest(
			() => parseColumnFilters({ column: 'name' }, parseFilter),
			'columnFilters must be an array'
		);
	});

	it('rejects more than 20 filters', () => {
		const tooMany = Array.from({ length: 21 }, (_, index) => ({
			column: 'name',
			comparator: 'eq',
			value: `v${index}`
		}));

		expectBadRequest(
			() => parseColumnFilters(tooMany, parseFilter),
			'columnFilters must contain at most 20 items'
		);
	});
});
