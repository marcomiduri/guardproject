import { badRequest } from '@/services/errors.js';

import {
	ADMIN_ROOM_ORDER_FILTER_COLUMNS,
	ADMIN_ROOM_ORDER_LIST_SORT_FIELDS,
	ROOM_ORDER_FILTER_COLUMNS,
	ROOM_ORDER_LIST_SORT_FIELDS,
	type AdminRoomOrderFilterColumn,
	type AdminRoomOrderListSortField,
	type ListAdminRoomOrdersOptions,
	type ListRoomOrdersOptions,
	type RoomOrderFilterColumn,
	type RoomOrderListSortField
} from '@/types/room-orders-list.js';
import {
	createTextColumnFilterParser,
	parseColumnFilters
} from '@/validators/list-query-parsing.js';
import {
	isRecord,
	parseOptionalNonNegativeInt,
	parseOptionalQueryString,
	parseRequiredIdParam,
	parseRequiredString,
	parseSortBy,
	parseSortOrder
} from '@/validators/parsing.js';

const parseRoomOrderColumnFilterItem =
	createTextColumnFilterParser<RoomOrderFilterColumn>(ROOM_ORDER_FILTER_COLUMNS);

const parseAdminRoomOrderColumnFilterItem =
	createTextColumnFilterParser<AdminRoomOrderFilterColumn>(ADMIN_ROOM_ORDER_FILTER_COLUMNS);

export function parseListRoomOrdersQuery(
	query: Record<string, unknown>
): Omit<ListRoomOrdersOptions, 'userId'> {
	return {
		limit: parseOptionalNonNegativeInt(query.limit, 'limit'),
		offset: parseOptionalNonNegativeInt(query.offset, 'offset'),
		search: parseOptionalQueryString(query.search, 'search', 255),
		sortBy: parseSortBy<RoomOrderListSortField>(query.sortBy, ROOM_ORDER_LIST_SORT_FIELDS),
		sortOrder: parseSortOrder(query.sortOrder),
		columnFilters: parseColumnFilters(query.columnFilters, parseRoomOrderColumnFilterItem)
	};
}

export function parseListAdminRoomOrdersQuery(
	query: Record<string, unknown>
): ListAdminRoomOrdersOptions {
	return {
		limit: parseOptionalNonNegativeInt(query.limit, 'limit'),
		offset: parseOptionalNonNegativeInt(query.offset, 'offset'),
		search: parseOptionalQueryString(query.search, 'search', 255),
		sortBy: parseSortBy<AdminRoomOrderListSortField>(
			query.sortBy,
			ADMIN_ROOM_ORDER_LIST_SORT_FIELDS
		),
		sortOrder: parseSortOrder(query.sortOrder),
		columnFilters: parseColumnFilters(query.columnFilters, parseAdminRoomOrderColumnFilterItem)
	};
}

function parseRequiredDate(value: unknown, field: string): Date {
	if (typeof value !== 'string' || value.trim().length === 0) {
		throw badRequest(`${field} must be an ISO date string`);
	}

	const date = new Date(value);
	if (Number.isNaN(date.getTime())) {
		throw badRequest(`${field} must be a valid date`);
	}

	return date;
}

function parseRoomOrderFieldsBody(body: unknown): {
	roomId: string;
	startTime: Date;
	endTime: Date;
} {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	return {
		roomId: parseRequiredString(body.roomId, 'roomId', 64),
		startTime: parseRequiredDate(body.startTime, 'startTime'),
		endTime: parseRequiredDate(body.endTime, 'endTime')
	};
}

export function parseCreateRoomOrderBody(body: unknown): {
	roomId: string;
	startTime: Date;
	endTime: Date;
} {
	return parseRoomOrderFieldsBody(body);
}

export function parseUpdateRoomOrderBody(body: unknown): {
	roomId: string;
	startTime: Date;
	endTime: Date;
} {
	return parseRoomOrderFieldsBody(body);
}

export function parseRoomOrderIdParam(value: string): string {
	return parseRequiredIdParam(value, 'Order id');
}

export function parseUpdateRoomOrderStatusBody(body: unknown): {
	status: 'approved' | 'rejected';
} {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	const status = body.status;

	if (status !== 'approved' && status !== 'rejected') {
		throw badRequest('status must be approved or rejected');
	}

	return { status };
}
