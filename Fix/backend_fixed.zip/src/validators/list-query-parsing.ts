import { badRequest } from '@/services/errors.js';

import {
	COLUMN_FILTER_COMPARATORS,
	type ColumnFilter,
	type ColumnFilterComparator
} from '@/types/list-query.js';

import { isRecord } from '@/validators/parsing.js';

export function validateColumnFilterColumn<TColumn extends string>(
	column: unknown,
	index: number,
	allowedColumns: readonly TColumn[]
): TColumn {
	if (typeof column !== 'string' || !allowedColumns.includes(column as TColumn)) {
		throw badRequest(`columnFilters[${index}].column must be one of: ${allowedColumns.join(', ')}`);
	}

	return column as TColumn;
}

export function validateColumnFilterComparator(
	comparator: unknown,
	index: number
): ColumnFilterComparator {
	if (
		typeof comparator !== 'string' ||
		!COLUMN_FILTER_COMPARATORS.includes(comparator as ColumnFilterComparator)
	) {
		throw badRequest(
			`columnFilters[${index}].comparator must be one of: ${COLUMN_FILTER_COMPARATORS.join(', ')}`
		);
	}

	return comparator as ColumnFilterComparator;
}

export function parseColumnFilterRawValue(value: unknown, index: number): string | number {
	if (typeof value !== 'string' && typeof value !== 'number') {
		throw badRequest(`columnFilters[${index}].value must be a string or number`);
	}

	return value;
}

export function parseTrimmedColumnFilterText(
	rawValue: string | number,
	index: number,
	maxLength = 255
): string {
	const text = String(rawValue).trim();

	if (text.length === 0) {
		throw badRequest(`columnFilters[${index}].value must not be empty`);
	}

	if (text.length > maxLength) {
		throw badRequest(`columnFilters[${index}].value must be at most ${maxLength} characters`);
	}

	return text;
}

export function createTextColumnFilterParser<TColumn extends string>(
	allowedColumns: readonly TColumn[]
): (value: unknown, index: number) => ColumnFilter<TColumn, string> {
	return (value, index) => {
		if (!isRecord(value)) {
			throw badRequest(`columnFilters[${index}] must be an object`);
		}

		const column = validateColumnFilterColumn(value.column, index, allowedColumns);
		const comparator = validateColumnFilterComparator(value.comparator, index);
		const rawValue = parseColumnFilterRawValue(value.value, index);
		const text = parseTrimmedColumnFilterText(rawValue, index);

		return { column, comparator, value: text };
	};
}

export function parseColumnFilters<TColumn extends string, TValue extends string | number>(
	value: unknown,
	parseItem: (item: unknown, index: number) => ColumnFilter<TColumn, TValue>
): ColumnFilter<TColumn, TValue>[] | undefined {
	if (value === undefined || value === null || value === '') return undefined;

	let parsed: unknown = value;

	if (typeof value === 'string') {
		try {
			parsed = JSON.parse(value);
		} catch {
			throw badRequest('columnFilters must be valid JSON');
		}
	}

	if (!Array.isArray(parsed)) {
		throw badRequest('columnFilters must be an array');
	}

	if (parsed.length > 20) {
		throw badRequest('columnFilters must contain at most 20 items');
	}

	return parsed.map((item, index) => parseItem(item, index));
}
