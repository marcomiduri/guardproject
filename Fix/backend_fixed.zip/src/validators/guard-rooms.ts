import { badRequest } from '@/services/errors.js';
import type { CreateGuardRoomInput, UpdateGuardRoomInput } from '@/services/guard-rooms.js';
import {
	GUARD_ROOMS_FILTER_COLUMNS,
	GUARD_ROOMS_LIST_SORT_FIELDS,
	type GuardRoomsColumnFilter,
	type GuardRoomsListSortField,
	type ListGuardRoomsOptions
} from '@/types/guard-rooms-list.js';
import {
	parseColumnFilterRawValue,
	parseColumnFilters,
	parseTrimmedColumnFilterText,
	validateColumnFilterColumn,
	validateColumnFilterComparator
} from '@/validators/list-query-parsing.js';
import {
	isRecord,
	parseOptionalInt,
	parseOptionalNonNegativeInt,
	parseOptionalQueryString,
	parseOptionalString,
	parseRequiredIdParam,
	parseRequiredString,
	parseSortBy,
	parseSortOrder
} from '@/validators/parsing.js';

function parseRequiredPositiveInt(value: unknown, field: string): number {
	const num = parseOptionalInt(value, field);
	if (num === undefined || num < 1) {
		throw badRequest(`${field} must be a positive integer`);
	}
	return num;
}

export function parseCreateGuardRoomBody(body: unknown): CreateGuardRoomInput {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	return {
		id: parseOptionalString(body.id, 'id', 64),
		name: parseRequiredString(body.name, 'name', 255),
		maxMembers: parseRequiredPositiveInt(body.maxMembers, 'maxMembers'),
		sortOrder: parseOptionalInt(body.sortOrder, 'sortOrder')
	};
}

export function parseUpdateGuardRoomBody(body: unknown): UpdateGuardRoomInput {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	const maxMembers = parseOptionalInt(body.maxMembers, 'maxMembers');
	if (maxMembers !== undefined && maxMembers < 1) {
		throw badRequest('maxMembers must be a positive integer');
	}

	return {
		name: parseOptionalString(body.name, 'name', 255),
		maxMembers,
		sortOrder: parseOptionalInt(body.sortOrder, 'sortOrder')
	};
}

export function parseGuardRoomIdParam(value: string): string {
	return parseRequiredIdParam(value, 'Room id');
}

function parseGuardRoomsColumnFilterItem(value: unknown, index: number): GuardRoomsColumnFilter {
	if (!isRecord(value)) {
		throw badRequest(`columnFilters[${index}] must be an object`);
	}

	const column = validateColumnFilterColumn(value.column, index, GUARD_ROOMS_FILTER_COLUMNS);
	const comparator = validateColumnFilterComparator(value.comparator, index);
	const rawValue = parseColumnFilterRawValue(value.value, index);

	if (['currentCount', 'cameraCount', 'maxMembers', 'sortOrder'].includes(column)) {
		const amount = Number(rawValue);
		if (!Number.isFinite(amount)) {
			throw badRequest(`columnFilters[${index}].value must be a number for ${column}`);
		}
		return { column, comparator, value: amount };
	}

	const text = parseTrimmedColumnFilterText(rawValue, index);

	return { column, comparator, value: text };
}

export function parseListGuardRoomsQuery(query: Record<string, unknown>): ListGuardRoomsOptions {
	return {
		limit: parseOptionalNonNegativeInt(query.limit, 'limit'),
		offset: parseOptionalNonNegativeInt(query.offset, 'offset'),
		search: parseOptionalQueryString(query.search, 'search', 255),
		sortBy: parseSortBy<GuardRoomsListSortField>(query.sortBy, GUARD_ROOMS_LIST_SORT_FIELDS),
		sortOrder: parseSortOrder(query.sortOrder),
		columnFilters: parseColumnFilters(query.columnFilters, parseGuardRoomsColumnFilterItem)
	};
}
