import type { Request } from 'express';
import {
	GUARD_HAZARD_TYPES,
	GUARD_SAFETY_EVENT_SOURCES,
	type GuardDetectionRectangle,
	type GuardHazardDetection,
	type GuardHazardType,
	type GuardSafetyEventSource
} from '@/db/schema/guard.js';
import { isMultipartRequest } from '@/middleware/guard-face-image-upload.js';
import { parseOptionalImageDataUrl, parseUploadedFaceImage } from '@/validators/face.js';
import { parseEnumMember, parseRequiredTrimmedString } from '@/validators/parsing.js';

export type GuardFaceAppearedInput = {
	eventId?: string;
	faceRegistryId: number;
	cameraId: string;
	trackId?: number;
	similarity?: number;
	occurredAt?: Date;
	source?: string;
	supersedesEventId?: string;
	rectangle?: GuardDetectionRectangle;
	faceImage?: Buffer;
	faceImageMimeType?: string;
	frameImage?: Buffer;
	frameImageMimeType?: string;
};

export type GuardUnknownFaceAppearedInput = {
	eventId?: string;
	cameraId: string;
	trackId?: number;
	occurredAt?: Date;
	source?: string;
	rectangle?: GuardDetectionRectangle;
	faceImage?: Buffer;
	faceImageMimeType?: string;
	frameImage?: Buffer;
	frameImageMimeType?: string;
};

export type GuardHazardDetectedInput = {
	eventId?: string;
	cameraId: string;
	hazardType: GuardHazardType;
	confidence?: number;
	detections?: GuardHazardDetection[];
	occurredAt?: Date;
	source?: GuardSafetyEventSource;
	testScenario?: string;
	snapshotImage?: Buffer;
	snapshotMimeType?: string;
};

function parseOptionalId(value: unknown, field: string): string | undefined {
	if (value === undefined || value === null || String(value).trim() === '') return undefined;
	const text = String(value).trim();
	if (text.length > 128) throw new Error(`${field} must be at most 128 characters`);
	return text;
}

function parseOptionalSourceText(value: unknown): string | undefined {
	if (value === undefined || value === null || String(value).trim() === '') return undefined;
	const text = String(value).trim();
	if (text.length > 32) throw new Error('source must be at most 32 characters');
	return text;
}

function parseSimilarityField(value: unknown): number | undefined {
	if (value === undefined || value === null || value === '') return undefined;
	const similarity = Number(value);
	if (!Number.isFinite(similarity) || similarity < 0 || similarity > 1) {
		throw new Error('similarity must be a number between 0 and 1');
	}
	return similarity;
}

function parseFaceRegistryIdField(value: unknown): number {
	const faceRegistryId = Number(value);
	if (!Number.isInteger(faceRegistryId) || faceRegistryId <= 0) {
		throw new Error('faceRegistryId must be a positive integer');
	}
	return faceRegistryId;
}

function parseTrackIdField(value: unknown): number | undefined {
	if (value === undefined || value === null || value === '') return undefined;
	const trackId = Number(value);
	if (!Number.isInteger(trackId) || trackId <= 0) {
		throw new Error('trackId must be a positive integer');
	}
	return trackId;
}

function parseOptionalEventTime(value: unknown): Date | undefined {
	if (value === undefined || value === null || String(value).trim() === '') return undefined;
	const parsed = new Date(String(value));
	if (Number.isNaN(parsed.getTime())) throw new Error('eventTime must be a valid ISO timestamp');
	return parsed;
}

function parseEventDataObject(eventDataRaw: unknown): Record<string, unknown> {
	if (typeof eventDataRaw !== 'string' || eventDataRaw.trim().length === 0) return {};
	try {
		const parsed: unknown = JSON.parse(eventDataRaw);
		if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
			throw new Error('eventData must be a JSON object');
		}
		return parsed as Record<string, unknown>;
	} catch (error) {
		if (error instanceof Error && error.message === 'eventData must be a JSON object') throw error;
		throw new Error('eventData must be valid JSON');
	}
}

function mergeRecord(
	primary: Record<string, unknown>,
	secondary: Record<string, unknown>
): Record<string, unknown> {
	return { ...secondary, ...primary };
}

function parseUploadedMultipartFaceImages(req: Request): {
	faceImage?: { buffer: Buffer; mimeType: string };
	frameImage?: { buffer: Buffer; mimeType: string };
} {
	const files = req.files as Record<string, Express.Multer.File[]> | undefined;
	const faceFile = files?.faceImage?.[0];
	const frameFile = files?.frameImage?.[0];
	return {
		faceImage: faceFile ? parseUploadedFaceImage(faceFile.buffer, faceFile.mimetype) : undefined,
		frameImage: frameFile ? parseUploadedFaceImage(frameFile.buffer, frameFile.mimetype) : undefined
	};
}

function parseRectangle(value: unknown): GuardDetectionRectangle | undefined {
	if (value === undefined || value === null || value === '') return undefined;
	let parsed = value;
	if (typeof value === 'string') {
		try {
			parsed = JSON.parse(value);
		} catch {
			throw new Error('rectangle must be valid JSON');
		}
	}
	if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
		throw new Error('rectangle must be an object');
	}
	const record = parsed as Record<string, unknown>;
	const numbers = ['x', 'y', 'width', 'height'].map((key) => Number(record[key]));
	if (numbers.some((number) => !Number.isFinite(number))) {
		throw new Error('rectangle x, y, width and height must be numbers');
	}
	const [x, y, width, height] = numbers;
	if (x < 0 || y < 0 || width < 0 || height < 0 || x > 1 || y > 1 || width > 1 || height > 1) {
		throw new Error('rectangle values must be normalized between 0 and 1');
	}
	return {
		x,
		y,
		width,
		height,
		coordinateSpace:
			typeof record.coordinateSpace === 'string' ? record.coordinateSpace.trim() : 'normalized'
	};
}

function parseFaceRecord(record: Record<string, unknown>, identified: boolean) {
	return {
		eventId: parseOptionalId(record.eventId, 'eventId'),
		cameraId: parseRequiredTrimmedString(record.cameraId, 'cameraId'),
		trackId: parseTrackIdField(record.trackId),
		occurredAt: parseOptionalEventTime(record.eventTime),
		source: parseOptionalSourceText(record.source),
		rectangle: parseRectangle(record.rectangle),
		...(identified
			? {
					faceRegistryId: parseFaceRegistryIdField(record.faceRegistryId),
					similarity: parseSimilarityField(record.similarity),
					supersedesEventId: parseOptionalId(record.supersedesEventId, 'supersedesEventId')
				}
			: {})
	};
}

export function parseGuardFaceAppearedBody(body: unknown): GuardFaceAppearedInput {
	if (!body || typeof body !== 'object' || Array.isArray(body)) {
		throw new Error('Request body is required');
	}
	const record = body as Record<string, unknown>;
	return {
		...parseFaceRecord(record, true),
		faceRegistryId: parseFaceRegistryIdField(record.faceRegistryId),
		faceImage: parseOptionalImageDataUrl(record.faceImage)
	};
}

export function parseGuardFaceAppearedMultipart(req: Request): GuardFaceAppearedInput {
	const body = (req.body ?? {}) as Record<string, unknown>;
	const merged = mergeRecord(body, parseEventDataObject(body.eventData));
	const uploaded = parseUploadedMultipartFaceImages(req);
	return {
		...parseFaceRecord(merged, true),
		faceRegistryId: parseFaceRegistryIdField(merged.faceRegistryId),
		faceImage: uploaded.faceImage?.buffer,
		faceImageMimeType: uploaded.faceImage?.mimeType,
		frameImage: uploaded.frameImage?.buffer,
		frameImageMimeType: uploaded.frameImage?.mimeType
	};
}

export function parseGuardFaceAppearedRequest(req: Request): GuardFaceAppearedInput {
	return isMultipartRequest(req.headers['content-type'])
		? parseGuardFaceAppearedMultipart(req)
		: parseGuardFaceAppearedBody(req.body);
}

export function parseGuardUnknownFaceAppearedBody(body: unknown): GuardUnknownFaceAppearedInput {
	if (!body || typeof body !== 'object' || Array.isArray(body)) {
		throw new Error('Request body is required');
	}
	const record = body as Record<string, unknown>;
	return {
		...parseFaceRecord(record, false),
		faceImage: parseOptionalImageDataUrl(record.faceImage)
	};
}

export function parseGuardUnknownFaceAppearedMultipart(
	req: Request
): GuardUnknownFaceAppearedInput {
	const body = (req.body ?? {}) as Record<string, unknown>;
	const merged = mergeRecord(body, parseEventDataObject(body.eventData));
	const uploaded = parseUploadedMultipartFaceImages(req);
	return {
		...parseFaceRecord(merged, false),
		faceImage: uploaded.faceImage?.buffer,
		faceImageMimeType: uploaded.faceImage?.mimeType,
		frameImage: uploaded.frameImage?.buffer,
		frameImageMimeType: uploaded.frameImage?.mimeType
	};
}

export function parseGuardUnknownFaceAppearedRequest(req: Request): GuardUnknownFaceAppearedInput {
	return isMultipartRequest(req.headers['content-type'])
		? parseGuardUnknownFaceAppearedMultipart(req)
		: parseGuardUnknownFaceAppearedBody(req.body);
}

const SAFETY_EVENT_TYPE_MAP: Record<string, GuardHazardType> = {
	FIRE: 'fire',
	SMOKE: 'smoke',
	FLAME: 'flame',
	fire: 'fire',
	smoke: 'smoke',
	flame: 'flame'
};

function parseSafetyEventType(value: unknown): GuardHazardType {
	if (typeof value !== 'string' || value.trim().length === 0) {
		throw new Error('eventType is required');
	}
	const normalized = value.trim();
	const mapped =
		SAFETY_EVENT_TYPE_MAP[normalized] ?? SAFETY_EVENT_TYPE_MAP[normalized.toUpperCase()];
	if (!mapped) throw new Error('eventType must be FIRE, SMOKE or FLAME');
	return mapped;
}

function parseHazardTypeField(value: unknown): GuardHazardType {
	if (typeof value !== 'string' || value.trim().length === 0) {
		throw new Error('hazardType is required');
	}
	return parseEnumMember(value, GUARD_HAZARD_TYPES, 'hazardType');
}

function parseOptionalSource(value: unknown): GuardSafetyEventSource | undefined {
	if (value === undefined || value === null || String(value).trim() === '') return undefined;
	return parseEnumMember(value, GUARD_SAFETY_EVENT_SOURCES, 'source');
}

function parseOptionalTestScenario(value: unknown): string | undefined {
	if (value === undefined || value === null) return undefined;
	const trimmed = String(value).trim();
	return trimmed.length > 0 ? trimmed.slice(0, 255) : undefined;
}

function parseDetections(value: unknown): GuardHazardDetection[] | undefined {
	if (value === undefined || value === null || value === '') return undefined;
	let parsed = value;
	if (typeof value === 'string') {
		try {
			parsed = JSON.parse(value);
		} catch {
			throw new Error('detections must be valid JSON');
		}
	}
	if (!Array.isArray(parsed)) throw new Error('detections must be an array');
	if (parsed.length > 32) throw new Error('detections may contain at most 32 items');
	return parsed.map((item, index) => {
		if (!item || typeof item !== 'object' || Array.isArray(item)) {
			throw new Error(`detections[${index}] must be an object`);
		}
		const record = item as Record<string, unknown>;
		const type = String(record.type ?? '')
			.trim()
			.toLowerCase();
		if (!type) throw new Error(`detections[${index}].type is required`);
		const confidence = parseSimilarityField(record.confidence);
		return {
			type,
			...(confidence === undefined ? {} : { confidence }),
			...(record.rectangle === undefined ? {} : { rectangle: parseRectangle(record.rectangle) })
		};
	});
}

function parseHazardRecord(
	record: Record<string, unknown>
): Omit<GuardHazardDetectedInput, 'snapshotImage' | 'snapshotMimeType'> {
	const hazardType = record.eventType
		? parseSafetyEventType(record.eventType)
		: parseHazardTypeField(record.hazardType);
	return {
		eventId: parseOptionalId(record.eventId, 'eventId'),
		cameraId: parseRequiredTrimmedString(record.cameraId, 'cameraId'),
		hazardType,
		confidence: parseSimilarityField(record.confidence),
		detections: parseDetections(record.detections),
		occurredAt: parseOptionalEventTime(record.eventTime),
		source: parseOptionalSource(record.source),
		testScenario: parseOptionalTestScenario(record.testScenario)
	};
}

export function parseGuardHazardDetectedBody(body: unknown): GuardHazardDetectedInput {
	if (!body || typeof body !== 'object' || Array.isArray(body)) {
		throw new Error('Request body is required');
	}
	const record = body as Record<string, unknown>;
	const snapshotImage = parseOptionalImageDataUrl(record.snapshotImage);
	return {
		...parseHazardRecord(record),
		snapshotImage,
		snapshotMimeType: snapshotImage ? 'image/jpeg' : undefined
	};
}

export function parseGuardSafetyDetectedMultipart(req: Request): GuardHazardDetectedInput {
	const body = (req.body ?? {}) as Record<string, unknown>;
	const eventData = parseEventDataObject(body.eventData);
	const merged = mergeRecord(body, eventData);
	const file = req.file;
	const uploaded = file ? parseUploadedFaceImage(file.buffer, file.mimetype) : undefined;
	return {
		...parseHazardRecord(merged),
		snapshotImage: uploaded?.buffer,
		snapshotMimeType: uploaded?.mimeType
	};
}

export function parseGuardSafetyDetectedRequest(req: Request): GuardHazardDetectedInput {
	return isMultipartRequest(req.headers['content-type'])
		? parseGuardSafetyDetectedMultipart(req)
		: parseGuardHazardDetectedBody(req.body);
}
