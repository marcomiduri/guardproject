import { env } from '@/config/env.js';
import {
	MAX_GUARD_CAMERAS_PER_ROOM,
	type CreateGuardCameraInput
} from '@/services/guard-cameras.js';
import { domainError, badRequest } from '@/services/errors.js';
import {
	guardHardwareIdFormatValid,
	normalizeGuardHardwareId
} from '@/services/guard-hardware-id.js';
import { parseCreateGuardCameraBody } from '@/validators/guard-cameras.js';
import {
	isRecord,
	parseOptionalInt,
	parseOptionalString,
	parseRequiredString
} from '@/validators/parsing.js';

export type ActivateGuardInstallationInput = {
	roomIdentifier: string;
	hardwareId: string;
	deviceName: string;
	applicationVersion?: string;
	cameras: Array<Omit<CreateGuardCameraInput, 'roomId' | 'installationId'>>;
};

export type ConnectGuardInstallationInput = {
	roomId: string;
	hardwareId?: string;
	installationId?: string;
	deviceCredential?: string;
	deviceName: string;
	applicationVersion?: string;
	cameras: Array<Omit<CreateGuardCameraInput, 'roomId' | 'installationId'>>;
};

export type ExchangeGuardDeviceTokenInput = {
	installationId: string;
	deviceToken: string;
	hardwareId?: string;
	applicationVersion?: string;
};

export type CreateRoomActivationCodeInput = {
	expiresInMinutes: number;
	maxUses: number;
};

function parseApplicationVersion(body: Record<string, unknown>): string | undefined {
	return (
		parseOptionalString(body.guardVersion, 'guardVersion', 64) ??
		parseOptionalString(body.applicationVersion, 'applicationVersion', 64)
	);
}

function parseDeviceCredential(body: Record<string, unknown>): string | undefined {
	return parseOptionalString(
		body.deviceCredential ?? body.deviceToken,
		'deviceCredential',
		1024
	)?.trim();
}

function parseHardwareId(value: unknown): string {
	const raw = parseRequiredString(value, 'hardwareId', 64);
	const normalized = normalizeGuardHardwareId(raw);
	if (!guardHardwareIdFormatValid(normalized)) {
		throw badRequest('hardwareId must use the format XXXX-XXXX-XXXX-XXXX');
	}
	return normalized;
}

function parseOptionalHardwareId(body: Record<string, unknown>): string | undefined {
	const raw = parseOptionalString(body.hardwareId, 'hardwareId', 64)?.trim();
	return raw ? parseHardwareId(raw) : undefined;
}

function parseConnectCameras(body: unknown): ConnectGuardInstallationInput['cameras'] {
	const cameraValues = body === undefined ? [] : body;
	if (!Array.isArray(cameraValues)) throw badRequest('cameras must be an array');
	if (cameraValues.length > MAX_GUARD_CAMERAS_PER_ROOM) {
		throw domainError(
			`You can register up to ${MAX_GUARD_CAMERAS_PER_ROOM} cameras`,
			400,
			'CAMERA_LIMIT_EXCEEDED'
		);
	}

	const seenClientCameraIds = new Set<string>();
	const seenDeviceAddresses = new Set<string>();
	const cameras = cameraValues.map((value, index) => {
		if (!isRecord(value)) throw badRequest(`cameras[${index}] must be an object`);
		const clientCameraId = parseRequiredString(
			value.clientCameraId,
			`cameras[${index}].clientCameraId`,
			128
		).trim();
		if (seenClientCameraIds.has(clientCameraId)) {
			throw domainError(
				'clientCameraId values must be unique within the request',
				400,
				'VALIDATION_ERROR'
			);
		}
		seenClientCameraIds.add(clientCameraId);

		const parsed = parseCreateGuardCameraBody({
			...value,
			roomId: 'connect-room',
			clientCameraId,
			deviceAddress:
				typeof value.deviceAddress === 'string' && value.deviceAddress.trim()
					? value.deviceAddress
					: '127.0.0.1'
		});
		const normalizedAddress = parsed.deviceAddress.trim().toLowerCase();
		if (normalizedAddress && seenDeviceAddresses.has(normalizedAddress)) {
			throw domainError(
				'Camera IP addresses must be unique within a room',
				400,
				'CAMERA_IP_CONFLICT'
			);
		}
		if (normalizedAddress) seenDeviceAddresses.add(normalizedAddress);

		const { roomId: _roomId, installationId: _installationId, ...camera } = parsed;
		return camera;
	});

	return cameras;
}

export function parseConnectGuardInstallationBody(body: unknown): ConnectGuardInstallationInput {
	if (!isRecord(body)) throw badRequest('Request body must be a JSON object');

	const roomId = parseRequiredString(body.roomId, 'roomId', 128).trim();
	if (!roomId) throw domainError('roomId is required', 400, 'VALIDATION_ERROR');

	const hardwareId = parseOptionalHardwareId(body);
	const installationId = parseOptionalString(body.installationId, 'installationId', 128)?.trim();
	const deviceCredential = parseDeviceCredential(body);
	if (
		!hardwareId &&
		((installationId && !deviceCredential) || (!installationId && deviceCredential))
	) {
		throw domainError(
			'installationId and deviceCredential must be supplied together when hardwareId is not provided',
			400,
			'INSTALLATION_CREDENTIAL_REQUIRED'
		);
	}

	return {
		roomId,
		...(hardwareId ? { hardwareId } : {}),
		...(installationId ? { installationId } : {}),
		...(deviceCredential ? { deviceCredential } : {}),
		deviceName: parseRequiredString(body.deviceName, 'deviceName', 255),
		applicationVersion: parseApplicationVersion(body),
		cameras: parseConnectCameras(body.cameras)
	};
}

export function parseActivateGuardInstallationBody(body: unknown): ActivateGuardInstallationInput {
	if (!isRecord(body)) throw badRequest('Request body must be a JSON object');

	const roomIdentifier = parseOptionalString(body.roomIdentifier, 'roomIdentifier', 255)?.trim();
	const roomId = parseOptionalString(body.roomId, 'roomId', 128)?.trim();
	const roomName = parseOptionalString(body.roomName, 'roomName', 255)?.trim();
	const resolvedRoomIdentifier = roomIdentifier || roomId || roomName;
	if (!resolvedRoomIdentifier) throw badRequest('roomIdentifier is required');

	const cameraValues = body.cameras === undefined ? [] : body.cameras;
	if (!Array.isArray(cameraValues)) throw badRequest('cameras must be an array');
	if (cameraValues.length > MAX_GUARD_CAMERAS_PER_ROOM) {
		throw badRequest(`You can register up to ${MAX_GUARD_CAMERAS_PER_ROOM} cameras`);
	}

	const seenDeviceAddresses = new Set<string>();
	const cameras = cameraValues.map((value, index) => {
		if (!isRecord(value)) throw badRequest(`cameras[${index}] must be an object`);
		const parsed = parseCreateGuardCameraBody({ ...value, roomId: 'activation-room' });
		if (!parsed.clientCameraId?.trim()) {
			throw badRequest(`cameras[${index}].clientCameraId is required`);
		}
		const normalizedAddress = parsed.deviceAddress.trim().toLowerCase();
		if (normalizedAddress && seenDeviceAddresses.has(normalizedAddress)) {
			throw domainError(
				'Camera IP addresses must be unique within a room',
				400,
				'CAMERA_IP_CONFLICT'
			);
		}
		if (normalizedAddress) seenDeviceAddresses.add(normalizedAddress);
		const { roomId: _roomId, installationId: _installationId, ...camera } = parsed;
		return camera;
	});

	return {
		roomIdentifier: resolvedRoomIdentifier,
		hardwareId: parseHardwareId(body.hardwareId),
		deviceName: parseRequiredString(body.deviceName, 'deviceName', 255),
		applicationVersion: parseApplicationVersion(body),
		cameras
	};
}

export function parseExchangeGuardDeviceTokenBody(body: unknown): ExchangeGuardDeviceTokenInput {
	if (!isRecord(body)) throw badRequest('Request body must be a JSON object');
	const deviceCredential = parseOptionalString(
		body.deviceCredential,
		'deviceCredential',
		1024
	)?.trim();
	const deviceToken = parseOptionalString(body.deviceToken, 'deviceToken', 1024)?.trim();
	const resolvedDeviceToken = deviceCredential || deviceToken;
	if (!resolvedDeviceToken) throw badRequest('deviceCredential is required');
	const hardwareIdRaw = parseOptionalString(body.hardwareId, 'hardwareId', 64)?.trim();
	return {
		installationId: parseRequiredString(body.installationId, 'installationId', 128),
		deviceToken: resolvedDeviceToken,
		hardwareId: hardwareIdRaw ? parseHardwareId(hardwareIdRaw) : undefined,
		applicationVersion: parseApplicationVersion(body)
	};
}

export function parseCreateRoomActivationCodeBody(body: unknown): CreateRoomActivationCodeInput {
	if (body !== undefined && body !== null && !isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}
	const record = isRecord(body) ? body : {};
	const expiresInMinutes =
		parseOptionalInt(record.expiresInMinutes, 'expiresInMinutes') ??
		env.GUARD_ACTIVATION_CODE_TTL_MINUTES;
	const maxUses = parseOptionalInt(record.maxUses, 'maxUses') ?? 1;
	if (expiresInMinutes < 1 || expiresInMinutes > 7 * 24 * 60) {
		throw badRequest('expiresInMinutes must be between 1 and 10080');
	}
	if (maxUses < 1 || maxUses > 100) throw badRequest('maxUses must be between 1 and 100');
	return { expiresInMinutes, maxUses };
}
