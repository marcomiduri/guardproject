import {
	GUARD_CAMERA_DIRECTIONS,
	GUARD_CAMERA_TYPES,
	type GuardCameraDirection,
	type GuardCameraType
} from '@/db/schema/guard.js';
import { badRequest } from '@/services/errors.js';
import type { CreateGuardCameraInput, UpdateGuardCameraInput } from '@/services/guard-cameras.js';
import {
	isRecord,
	parseOptionalInt,
	parseOptionalString,
	parseRequiredIdParam,
	parseRequiredString
} from '@/validators/parsing.js';

function parsePort(value: unknown, field: string, fallback: number): number {
	const num = parseOptionalInt(value, field);
	if (num === undefined) return fallback;
	if (num < 1 || num > 65535) {
		throw badRequest(`${field} must be between 1 and 65535`);
	}
	return num;
}

function parseCameraType(value: unknown, field = 'type'): GuardCameraType | undefined {
	if (value === undefined || value === null || value === '') return undefined;
	if (typeof value !== 'string') throw badRequest(`${field} must be a string`);
	if (!GUARD_CAMERA_TYPES.includes(value as GuardCameraType)) {
		throw badRequest(`${field} must be one of: ${GUARD_CAMERA_TYPES.join(', ')}`);
	}
	return value as GuardCameraType;
}

function parseStreamType(value: unknown): number | undefined {
	const num = parseOptionalInt(value, 'streamType');
	if (num === undefined) return undefined;
	if (num !== 0 && num !== 1) throw badRequest('streamType must be 0 (main) or 1 (sub)');
	return num;
}

function parseDirection(
	value: unknown,
	field = 'direction',
	required = false
): GuardCameraDirection | undefined {
	if (value === undefined || value === null || value === '') {
		if (required) throw badRequest(`${field} is required`);
		return undefined;
	}
	if (typeof value !== 'string') throw badRequest(`${field} must be a string`);
	if (!GUARD_CAMERA_DIRECTIONS.includes(value as GuardCameraDirection)) {
		throw badRequest(`${field} must be one of: ${GUARD_CAMERA_DIRECTIONS.join(', ')}`);
	}
	return value as GuardCameraDirection;
}

function parseRequiredRoomId(value: unknown): string {
	return parseRequiredString(value, 'roomId', 64);
}

export function parseCreateGuardCameraBody(body: unknown): CreateGuardCameraInput {
	if (!isRecord(body)) throw badRequest('Request body must be a JSON object');

	return {
		id: parseOptionalString(body.id, 'id', 64),
		roomId: parseRequiredRoomId(body.roomId),
		clientCameraId:
			body.clientCameraId === null
				? null
				: parseOptionalString(body.clientCameraId, 'clientCameraId', 128),
		name: parseOptionalString(body.name, 'name', 255),
		type: parseCameraType(body.type),
		direction: parseDirection(body.direction, 'direction', true)!,
		deviceAddress: parseRequiredString(body.deviceAddress, 'deviceAddress', 255),
		sdkPort: parsePort(body.sdkPort, 'sdkPort', 8000),
		rtspPort: parsePort(body.rtspPort, 'rtspPort', 554),
		rtspUrl: body.rtspUrl === null ? null : parseOptionalString(body.rtspUrl, 'rtspUrl', 2048),
		username: parseOptionalString(body.username, 'username', 255),
		password: body.password === undefined ? undefined : String(body.password),
		channel: parseOptionalInt(body.channel, 'channel'),
		streamType: parseStreamType(body.streamType),
		sortOrder: parseOptionalInt(body.sortOrder, 'sortOrder')
	};
}

export function parseUpdateGuardCameraBody(body: unknown): UpdateGuardCameraInput {
	if (!isRecord(body)) throw badRequest('Request body must be a JSON object');

	return {
		roomId: parseOptionalString(body.roomId, 'roomId', 64),
		clientCameraId:
			body.clientCameraId === null
				? null
				: parseOptionalString(body.clientCameraId, 'clientCameraId', 128),
		name: parseOptionalString(body.name, 'name', 255),
		type: parseCameraType(body.type),
		direction: parseDirection(body.direction),
		deviceAddress: parseOptionalString(body.deviceAddress, 'deviceAddress', 255),
		sdkPort: body.sdkPort === undefined ? undefined : parsePort(body.sdkPort, 'sdkPort', 8000),
		rtspPort: body.rtspPort === undefined ? undefined : parsePort(body.rtspPort, 'rtspPort', 554),
		rtspUrl: body.rtspUrl === null ? null : parseOptionalString(body.rtspUrl, 'rtspUrl', 2048),
		username: parseOptionalString(body.username, 'username', 255),
		password: body.password === undefined ? undefined : String(body.password),
		channel: parseOptionalInt(body.channel, 'channel'),
		streamType: parseStreamType(body.streamType),
		sortOrder: parseOptionalInt(body.sortOrder, 'sortOrder')
	};
}

export function parseGuardCameraIdParam(value: string): string {
	return parseRequiredIdParam(value, 'Camera id');
}
