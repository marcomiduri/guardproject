import { badRequest } from '@/services/errors.js';
import { isRecord, parseRequiredTrimmedString } from '@/validators/parsing.js';

export function parseRegisterBody(body: unknown): {
	username: string;
	email: string;
	password: string;
} {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	const username = parseRequiredTrimmedString(body.username, 'username', { min: 1, max: 100 });
	const email = parseRequiredTrimmedString(body.email, 'email', { min: 3, max: 255 }).toLowerCase();
	const password = parseRequiredTrimmedString(body.password, 'password', { min: 8, max: 128 });

	if (!email.includes('@')) {
		throw badRequest('Email must be valid');
	}

	return { username, email, password };
}

export function parseLoginBody(body: unknown): { email: string; password: string } {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	const email = parseRequiredTrimmedString(body.email, 'email', { min: 3, max: 255 }).toLowerCase();
	const password = parseRequiredTrimmedString(body.password, 'password', { min: 1, max: 128 });

	return { email, password };
}
