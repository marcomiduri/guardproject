import { describe, expect, it } from 'vitest';
import {
	parseConnectGuardInstallationBody,
	parseExchangeGuardDeviceTokenBody
} from '@/validators/guard-installations.js';

describe('parseConnectGuardInstallationBody', () => {
	it('requires roomId and deviceName', () => {
		expect(() => parseConnectGuardInstallationBody({})).toThrow(/roomId|JSON object/i);
	});

	it('accepts a valid connect payload without activation or license fields', () => {
		const parsed = parseConnectGuardInstallationBody({
			roomId: 'room-1',
			deviceName: 'Warehouse Guard PC',
			guardVersion: '2.0.0',
			cameras: [{ clientCameraId: 'cam-1', name: 'Front', direction: 'in' }]
		});
		expect(parsed.roomId).toBe('room-1');
		expect(parsed.cameras).toHaveLength(1);
		expect(parsed).not.toHaveProperty('clientInstallationId');
		expect(parsed).not.toHaveProperty('hardwareIdHash');
		expect(parsed).not.toHaveProperty('activationCode');
		expect(parsed).not.toHaveProperty('licenseKey');
	});

	it('uses hardwareId but does not copy legacy clientInstallationId or hardwareIdHash fields', () => {
		const parsed = parseConnectGuardInstallationBody({
			roomId: 'room-1',
			clientInstallationId: '11111111-1111-4111-8111-111111111111',
			deviceName: 'Guard PC',
			hardwareId: 'ABCD-EF01-2345-6789',
			hardwareIdHash: 'v1:not-used-by-room-connect',
			cameras: []
		});
		expect(parsed).not.toHaveProperty('clientInstallationId');
		expect(parsed.hardwareId).toBe('ABCD-EF01-2345-6789');
		expect(parsed).not.toHaveProperty('hardwareIdHash');
	});

	it('accepts installation identity and device credential together for room reassignment', () => {
		const parsed = parseConnectGuardInstallationBody({
			roomId: 'room-2',
			installationId: 'installation-1',
			deviceCredential: 'protected-secret',
			deviceName: 'Guard PC',
			cameras: []
		});
		expect(parsed.installationId).toBe('installation-1');
		expect(parsed.deviceCredential).toBe('protected-secret');
	});

	it('requires installation identity and device credential as a pair', () => {
		const common = {
			roomId: 'room-2',
			deviceName: 'Guard PC',
			cameras: []
		};
		expect(() =>
			parseConnectGuardInstallationBody({ ...common, installationId: 'installation-1' })
		).toThrow(/supplied together/i);
		expect(() =>
			parseConnectGuardInstallationBody({ ...common, deviceCredential: 'protected-secret' })
		).toThrow(/supplied together/i);
		expect(
			parseConnectGuardInstallationBody({
				...common,
				installationId: 'installation-1',
				hardwareId: 'ABCD-EF01-2345-6789'
			}).installationId
		).toBe('installation-1');
	});

	it('rejects duplicate camera IP addresses in one room request', () => {
		expect(() =>
			parseConnectGuardInstallationBody({
				roomId: 'room-1',
				deviceName: 'Guard PC',
				cameras: [
					{
						clientCameraId: 'cam-1',
						name: 'Front',
						direction: 'in',
						deviceAddress: '192.168.1.64'
					},
					{
						clientCameraId: 'cam-2',
						name: 'Back',
						direction: 'out',
						deviceAddress: '192.168.1.64'
					}
				]
			})
		).toThrow(/unique|IP/i);
	});

	it('rejects more than four cameras', () => {
		expect(() =>
			parseConnectGuardInstallationBody({
				roomId: 'room-1',
				deviceName: 'Guard PC',
				cameras: Array.from({ length: 5 }, (_value, index) => ({
					clientCameraId: `cam-${index}`,
					name: `Camera ${index}`,
					direction: 'in'
				}))
			})
		).toThrow(/4 cameras/i);
	});
});

describe('parseExchangeGuardDeviceTokenBody', () => {
	it('accepts deviceCredential without hardwareId', () => {
		const parsed = parseExchangeGuardDeviceTokenBody({
			installationId: 'installation-1',
			deviceCredential: 'secret-value'
		});
		expect(parsed.installationId).toBe('installation-1');
		expect(parsed.deviceToken).toBe('secret-value');
		expect(parsed.hardwareId).toBeUndefined();
	});
});
