const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

export function parseImageDataUrl(image: string): Buffer {
	const match = /^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/i.exec(image.trim());
	if (!match) {
		throw new Error('Image must be a JPEG, PNG, or WebP data URL');
	}

	let buffer: Buffer;
	try {
		buffer = Buffer.from(match[2], 'base64');
	} catch {
		throw new Error('Invalid image encoding');
	}

	if (buffer.length === 0) {
		throw new Error('Image data is empty');
	}

	if (buffer.length > MAX_IMAGE_BYTES) {
		throw new Error('Image is too large (max 5 MB)');
	}

	return buffer;
}

export type ParsedUploadedFaceImage = {
	buffer: Buffer;
	mimeType: string;
};

export function parseUploadedFaceImage(buffer: Buffer, mimeType: string): ParsedUploadedFaceImage {
	if (!buffer || buffer.length === 0) {
		throw new Error('faceImage file is empty');
	}

	const normalizedMime = mimeType.trim().toLowerCase();
	if (
		normalizedMime !== 'image/jpeg' &&
		normalizedMime !== 'image/jpg' &&
		normalizedMime !== 'image/png'
	) {
		throw new Error('faceImage must be image/jpeg or image/png');
	}

	if (buffer.length > MAX_IMAGE_BYTES) {
		throw new Error('Image is too large (max 5 MB)');
	}

	if (normalizedMime === 'image/jpeg' || normalizedMime === 'image/jpg') {
		if (buffer[0] !== 0xff || buffer[1] !== 0xd8) {
			throw new Error('faceImage must be a valid JPEG file');
		}
	}

	if (normalizedMime === 'image/png') {
		if (
			buffer.length < 8 ||
			buffer[0] !== 0x89 ||
			buffer[1] !== 0x50 ||
			buffer[2] !== 0x4e ||
			buffer[3] !== 0x47
		) {
			throw new Error('faceImage must be a valid PNG file');
		}
	}

	return {
		buffer,
		mimeType: normalizedMime === 'image/jpg' ? 'image/jpeg' : normalizedMime
	};
}

export function parseOptionalImageDataUrl(value: unknown): Buffer | undefined {
	if (value === undefined || value === null) {
		return undefined;
	}

	if (typeof value !== 'string') {
		throw new Error('faceImage must be a data URL string');
	}

	const trimmed = value.trim();
	if (!trimmed) {
		return undefined;
	}

	return parseImageDataUrl(trimmed);
}

export function parseFaceImageBody(body: unknown): Buffer {
	if (!body || typeof body !== 'object') {
		throw new Error('Request body is required');
	}

	const image = (body as { image?: unknown }).image;
	if (typeof image !== 'string' || image.trim().length === 0) {
		throw new Error('Face image is required');
	}

	return parseImageDataUrl(image);
}
