import { badRequest } from '@/services/errors.js';

import {
	SAFETY_EVENTS_FILTER_COLUMNS,
	SAFETY_EVENTS_LIST_SORT_FIELDS,
	type ListSafetyEventsOptions,
	type SafetyEventsColumnFilter,
	type SafetyEventsListSortField
} from '@/types/safety-events-list.js';
import {
	parseColumnFilterRawValue,
	parseColumnFilters,
	parseTrimmedColumnFilterText,
	validateColumnFilterColumn,
	validateColumnFilterComparator
} from '@/validators/list-query-parsing.js';
import {
	isRecord,
	parseOptionalNonNegativeInt,
	parseOptionalQueryString,
	parseSortBy,
	parseSortOrder
} from '@/validators/parsing.js';

function parseSafetyEventsColumnFilterItem(
	value: unknown,
	index: number
): SafetyEventsColumnFilter {
	if (!isRecord(value)) {
		throw badRequest(`columnFilters[${index}] must be an object`);
	}

	const column = validateColumnFilterColumn(value.column, index, SAFETY_EVENTS_FILTER_COLUMNS);
	const comparator = validateColumnFilterComparator(value.comparator, index);
	const rawValue = parseColumnFilterRawValue(value.value, index);

	if (column === 'confidence') {
		const amount = Number(rawValue);
		if (!Number.isFinite(amount) || amount < 0 || amount > 100) {
			throw badRequest(
				`columnFilters[${index}].value must be a number between 0 and 100 for confidence`
			);
		}
		return { column, comparator, value: amount };
	}

	const text = parseTrimmedColumnFilterText(rawValue, index);

	return { column, comparator, value: text };
}

export function parseListSafetyEventsQuery(
	query: Record<string, unknown>
): ListSafetyEventsOptions {
	return {
		limit: parseOptionalNonNegativeInt(query.limit, 'limit'),
		offset: parseOptionalNonNegativeInt(query.offset, 'offset'),
		search: parseOptionalQueryString(query.search, 'search', 255),
		sortBy: parseSortBy<SafetyEventsListSortField>(query.sortBy, SAFETY_EVENTS_LIST_SORT_FIELDS),
		sortOrder: parseSortOrder(query.sortOrder),
		columnFilters: parseColumnFilters(query.columnFilters, parseSafetyEventsColumnFilterItem)
	};
}
