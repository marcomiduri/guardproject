import { badRequest } from '@/services/errors.js';
import {
	DEFAULT_ADMIN_NOTIFICATION_SETTINGS,
	type AdminNotificationSettings
} from '@/types/admin-notification-settings.js';
import { isRecord } from '@/validators/parsing.js';

function parseBoolean(value: unknown, field: string, fallback: boolean): boolean {
	if (value === undefined) {
		return fallback;
	}

	if (typeof value !== 'boolean') {
		throw badRequest(`${field} must be a boolean`);
	}

	return value;
}

export function parseUpdateAdminNotificationSettingsBody(
	body: unknown
): Partial<AdminNotificationSettings> {
	if (!isRecord(body)) {
		throw badRequest('Request body must be a JSON object');
	}

	const next: Partial<AdminNotificationSettings> = {};

	if ('notifyUnapprovedIncoming' in body) {
		next.notifyUnapprovedIncoming = parseBoolean(
			body.notifyUnapprovedIncoming,
			'notifyUnapprovedIncoming',
			DEFAULT_ADMIN_NOTIFICATION_SETTINGS.notifyUnapprovedIncoming
		);
	}

	if ('notifyUnknownIncoming' in body) {
		next.notifyUnknownIncoming = parseBoolean(
			body.notifyUnknownIncoming,
			'notifyUnknownIncoming',
			DEFAULT_ADMIN_NOTIFICATION_SETTINGS.notifyUnknownIncoming
		);
	}

	if (!('notifyUnapprovedIncoming' in next) && !('notifyUnknownIncoming' in next)) {
		throw badRequest('At least one notification setting must be provided');
	}

	return next;
}
