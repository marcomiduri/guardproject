export type UpdateProfileInput = {
	username?: string;
	birthday?: string | null;
	job?: string | null;
	position?: string | null;
};

const ISO_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function parseOptionalNullableString(
	value: unknown,
	field: string,
	maxLength: number
): string | null | undefined {
	if (value === undefined) {
		return undefined;
	}

	if (value === null) {
		return null;
	}

	if (typeof value !== 'string') {
		throw new Error(`${field} must be a string or null`);
	}

	const trimmed = value.trim();
	if (trimmed.length === 0) {
		return null;
	}

	if (trimmed.length > maxLength) {
		throw new Error(`${field} must be at most ${maxLength} characters`);
	}

	return trimmed;
}

function parseUsername(value: unknown): string {
	if (typeof value !== 'string') {
		throw new Error('username must be a string');
	}

	const trimmed = value.trim();
	if (trimmed.length < 1) {
		throw new Error('username is required');
	}

	if (trimmed.length > 100) {
		throw new Error('username must be at most 100 characters');
	}

	return trimmed;
}

function parseBirthday(value: unknown): string | null | undefined {
	if (value === undefined) {
		return undefined;
	}

	if (value === null || value === '') {
		return null;
	}

	if (typeof value !== 'string') {
		throw new Error('birthday must be an ISO date string (YYYY-MM-DD) or null');
	}

	const trimmed = value.trim();
	if (!ISO_DATE_PATTERN.test(trimmed)) {
		throw new Error('birthday must use YYYY-MM-DD format');
	}

	const parsed = new Date(`${trimmed}T00:00:00.000Z`);
	if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== trimmed) {
		throw new Error('birthday is not a valid date');
	}

	return trimmed;
}

export function parseUpdateProfileBody(body: unknown): UpdateProfileInput {
	if (!body || typeof body !== 'object') {
		throw new Error('Request body is required');
	}

	const record = body as Record<string, unknown>;
	const input: UpdateProfileInput = {};

	if ('username' in record) {
		input.username = parseUsername(record.username);
	}

	if ('birthday' in record) {
		input.birthday = parseBirthday(record.birthday);
	}

	if ('job' in record) {
		input.job = parseOptionalNullableString(record.job, 'job', 120);
	}

	if ('position' in record) {
		input.position = parseOptionalNullableString(record.position, 'position', 120);
	}

	if (
		input.username === undefined &&
		input.birthday === undefined &&
		input.job === undefined &&
		input.position === undefined
	) {
		throw new Error('At least one profile field is required');
	}

	return input;
}
