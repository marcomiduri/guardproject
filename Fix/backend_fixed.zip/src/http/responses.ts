export type ApiPagination = {
	/** Total matching rows across all pages. */
	total: number;
	/** Page size requested for this response. */
	limit: number;
	/** Offset requested for this response. */
	offset: number;
	/** Number of rows in this response page. */
	count: number;
	/** Whether another page exists after this one. */
	hasMore: boolean;
};

export type PaginatedListData<T> = {
	items: T[];
	pagination: ApiPagination;
};

export type ApiSuccessResponse<T> = {
	success: true;
	data: T;
};

export function buildPagination(input: {
	total: number;
	limit: number;
	offset: number;
	itemCount: number;
}): ApiPagination {
	const { total, limit, offset, itemCount } = input;

	return {
		total,
		limit,
		offset,
		count: itemCount,
		hasMore: offset + itemCount < total
	};
}

export function ok<T>(data: T): ApiSuccessResponse<T> {
	return { success: true, data };
}
