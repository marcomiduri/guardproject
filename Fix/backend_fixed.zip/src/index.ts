import { createApp } from '@/app.js';
import { env } from '@/config/env.js';
import { closeDb } from '@/db/index.js';
import { verifyDatabaseConnection } from '@/db/verify-connection.js';
import { attachRealtimeServer } from '@/realtime/attach-realtime-server.js';
import { purgeExpiredInOutRecords } from '@/services/in-out-retention.js';
import { logger } from '@/utils/logger.js';

const SHUTDOWN_TIMEOUT_MS = 300;

async function runInOutRetentionCleanup(reason: string): Promise<void> {
	if (env.IN_OUT_RETENTION_DAYS <= 0) {
		return;
	}

	try {
		const deleted = await purgeExpiredInOutRecords();
		if (deleted > 0) {
			logger.info(`[in-out-retention] purged ${deleted} record(s) (${reason})`);
		}
	} catch (err) {
		logger.error('[in-out-retention] cleanup failed', err);
	}
}

async function main(): Promise<void> {
	try {
		await verifyDatabaseConnection();
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		logger.error(message);
		process.exit(1);
	}

	const app = createApp();
	const server = app.listen(env.PORT, env.HOST, () => {
		logger.info(`mc-pos API listening on http://${env.HOST}:${env.PORT}`);
		logger.info(`Auth: POST /api/auth/login, POST /api/auth/register`);
		logger.info(`Realtime: WS /api/ws?token=<jwt>`);
		logger.info(`CORS origin: ${env.CORS_ORIGIN}`);
		if (env.IN_OUT_RETENTION_DAYS > 0) {
			logger.info(`In-out retention: ${env.IN_OUT_RETENTION_DAYS} day(s)`);
		}

		void runInOutRetentionCleanup('startup');

		if (env.IN_OUT_RETENTION_DAYS > 0 && env.IN_OUT_RETENTION_CLEANUP_INTERVAL_MS > 0) {
			setInterval(() => {
				void runInOutRetentionCleanup('scheduled');
			}, env.IN_OUT_RETENTION_CLEANUP_INTERVAL_MS).unref();
		}
	});

	const wss = attachRealtimeServer(server);

	server.on('error', (err: NodeJS.ErrnoException) => {
		if (err.code === 'EADDRINUSE') {
			logger.error(
				`Port ${env.PORT} is already in use. Stop the other backend process and try again.`
			);
		} else {
			logger.error('[server] failed to start:', err.message);
		}
		process.exit(1);
	});

	let isShuttingDown = false;

	function shutdown(signal: NodeJS.Signals | 'SIGBREAK'): void {
		if (isShuttingDown) {
			process.exit(1);
		}
		isShuttingDown = true;

		logger.info(`\n${signal} received, shutting down...`);

		wss.close();
		const closeAllConnections = (server as { closeAllConnections?: () => void })
			.closeAllConnections;
		if (closeAllConnections) {
			closeAllConnections.call(server);
		}
		server.close();

		let exited = false;
		const exit = (code: 0 | 1) => {
			if (exited) {
				return;
			}
			exited = true;
			process.exit(code);
		};

		void closeDb()
			.catch((err) => {
				logger.error('[shutdown] failed to close database pool', err);
			})
			.finally(() => {
				exit(0);
			});

		setTimeout(() => exit(0), SHUTDOWN_TIMEOUT_MS);
	}

	for (const signal of ['SIGINT', 'SIGTERM', 'SIGBREAK'] as const) {
		process.on(signal, () => {
			shutdown(signal);
		});
	}
}

void main();
