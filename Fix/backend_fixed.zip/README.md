# mc-pos API

Express + TypeScript + Drizzle + JWT auth.

## Structure

```
src/
├── index.ts              # server entry
├── app.ts                # compose middleware + routes
├── config/env.ts
├── db/
│   ├── index.ts          # drizzle client
│   └── schema/
│       ├── index.ts
│       ├── auth.ts       # users table
│       └── guard.ts      # rooms, cameras, face events
├── middleware/
│   ├── index.ts          # global: CORS, JSON
│   ├── require-auth.ts   # JWT bearer verification
│   ├── require-role.ts
│   ├── async-handler.ts
│   ├── error-handler.ts
│   └── not-found.ts
├── routes/
│   ├── index.ts
│   ├── auth.ts           # register, login
│   ├── health.ts
│   ├── me.ts
│   ├── in-out.ts
│   ├── rooms.ts
│   └── admin-rooms.ts
├── services/
│   ├── auth.ts           # register, login, password hashing
│   ├── jwt.ts            # sign/verify tokens
│   ├── errors.ts
│   └── guard-*.ts        # rooms, cameras, face events
└── validators/
    ├── auth.ts
    └── guard-*.ts
```

## Setup

```bash
npm install
cp .env.example .env
# Edit DATABASE_URL for your local Postgres instance
npm run db:migrate
npm run dev
```

Schema is defined in `src/db/schema/` and applied via a single init migration (`drizzle/0000_init.sql`). After schema changes, run `npm run db:generate` then `npm run db:migrate`.

**Fresh database:** create an empty Postgres database, set `DATABASE_URL` in `.env`, then run `npm run db:migrate`.

**Resetting an existing database** (after a migration squash or schema rebuild):

```sql
DROP SCHEMA IF EXISTS drizzle CASCADE;
DROP SCHEMA public CASCADE;
CREATE SCHEMA public;
```

Then run `npm run db:migrate` again.

Set `JWT_SECRET` in `.env` (required in production).

API base: http://127.0.0.1:3000

## Auth

| Method | Path                 | Description                              |
| ------ | -------------------- | ---------------------------------------- |
| POST   | `/api/auth/register` | Create account → `{ accessToken, user }` |
| POST   | `/api/auth/login`    | Sign in → `{ accessToken, user }`        |
| GET    | `/api/me`            | Current user (Bearer token)              |

Protected routes expect `Authorization: Bearer <accessToken>`.

## API

| Method                | Path                                 | Auth              | Description                                            |
| --------------------- | ------------------------------------ | ----------------- | ------------------------------------------------------ |
| GET                   | `/api/health`                        | —                 | Health check                                           |
| GET                   | `/api/me`                            | JWT               | Current user                                           |
| GET/POST              | `/api/me/face`                       | JWT               | Face registration status / save webcam photo           |
| GET                   | `/api/me/face/image`                 | JWT               | Registered face JPEG                                   |
| GET                   | `/api/guard/faces`                   | Guard JWT         | InspireFace feature registry (`id`, `name`, `feature`) |
| GET                   | `/api/guard/faces/version`           | Guard JWT         | Opaque registry version for Guard refresh polling     |
| GET                   | `/api/guard/faces/:faceRegistryId`   | Guard JWT         | Resolve username for a numeric face registry id        |
| GET                   | `/api/guard/notification-settings`   | Guard JWT         | Admin policy flags for Guard access-warning audio     |
| POST                  | `/api/guard/events/appeared`         | Guard JWT         | Recognized face event (JSON or multipart)              |
| POST                  | `/api/guard/events/unknown-appeared` | Guard JWT         | Unknown face event (JSON or multipart)                 |
| POST                  | `/api/guard/events/hazard-detected`  | Guard JWT         | Hazard event with optional annotated snapshot          |
| GET/POST/PATCH/DELETE | `/api/guard/cameras`                 | Guard JWT         | Guard camera sync and CRUD                            |
| POST                  | `/api/guard/cameras/:id/heartbeat`   | Guard JWT         | Camera online/offline/unknown heartbeat                |
| POST                  | `/api/guard/installations/heartbeat` | Guard JWT         | Installation keep-alive                                |
| POST                  | `/api/guard/installations/activate`  | Public bootstrap  | Temporary open room registration for integration tests |
| POST                  | `/api/guard/auth/token`              | device credential | Exchange for Guard JWT                                 |
| GET                   | `/api/in-out`                        | user/admin        | List Guard face in-out events                          |
| GET                   | `/api/cameras`                       | user/admin        | List registered Guard cameras (sanitized)              |
| GET                   | `/api/rooms`                         | user/admin        | List rooms with occupancy                              |
| GET/POST/PATCH/DELETE | `/api/admin/rooms`                   | admin/staff       | Manage rooms and cameras                               |

## Guard installation and device authentication

Guard currently uses a temporary open-registration flow so the complete camera,
face-event and hazard-event integration can be tested before the new licensing and
enrollment model is introduced:

1. Guard submits an existing room ID or room name, its normalized Hardware ID,
   device name and local camera list.
2. The backend creates or restores the installation and returns a newly generated,
   opaque device credential.
3. Guard stores the credential securely and exchanges it for short-lived Guard JWTs.
4. Later requests are authorized by the Guard JWT, installation ownership, room
   ownership, camera ownership and revocation state.

The activation request does not require a product license, room activation code or
shared Guard API key. This intentionally permissive bootstrap is for integration
testing only and must be replaced by the approved enrollment mechanism before a
production release.

Commercial product licensing is intentionally outside this backend. The backend does
not validate product keys, manage product trials, expose commercial entitlement state
or place commercial claims in Guard JWTs. See `docs/GuardBackendIntegration.md` and
`docs/BackendGuardContractVerification.md` for the live contracts.

Before starting the updated backend:

```bash
npm run db:migrate
npm run check
npm test
npm run build
```

For LAN/container access, set `HOST=0.0.0.0` and put the backend behind HTTPS/WSS.
The values `GUARD_JWT_SECRET`, `GUARD_DEVICE_TOKEN_PEPPER` and
`GUARD_ACTIVATION_CODE_PEPPER` must be unique production secrets and must remain
outside source archives.
