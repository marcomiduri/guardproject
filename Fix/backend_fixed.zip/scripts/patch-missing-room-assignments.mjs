import pg from 'pg';

const patchSql = `
CREATE TABLE IF NOT EXISTS "guard_installation_room_assignments" (
  "id" text PRIMARY KEY NOT NULL,
  "installation_id" text NOT NULL REFERENCES "guard_installations"("id") ON DELETE CASCADE,
  "room_id" text NOT NULL REFERENCES "guard_rooms"("id") ON DELETE RESTRICT,
  "connected_at" timestamp DEFAULT now() NOT NULL,
  "disconnected_at" timestamp,
  "created_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "guard_installation_room_assignments_installation_idx"
  ON "guard_installation_room_assignments" ("installation_id");
CREATE INDEX IF NOT EXISTS "guard_installation_room_assignments_room_idx"
  ON "guard_installation_room_assignments" ("room_id");
CREATE UNIQUE INDEX IF NOT EXISTS "guard_installation_room_assignments_active_unique"
  ON "guard_installation_room_assignments" ("installation_id")
  WHERE "disconnected_at" IS NULL;

INSERT INTO "guard_installation_room_assignments"
  ("id", "installation_id", "room_id", "connected_at", "disconnected_at", "created_at")
SELECT
  md5("id" || ':initial-room-assignment'),
  "id",
  "room_id",
  COALESCE("registered_at", "created_at", now()),
  CASE WHEN "status" = 'active' THEN NULL ELSE COALESCE("updated_at", now()) END,
  COALESCE("created_at", now())
FROM "guard_installations"
WHERE NOT EXISTS (
    SELECT 1 FROM "guard_installation_room_assignments" a
    WHERE a."installation_id" = "guard_installations"."id"
  );

DROP INDEX IF EXISTS "guard_installations_room_client_installation_unique";
DROP INDEX IF EXISTS "guard_installations_client_installation_unique";
ALTER TABLE "guard_installations" DROP COLUMN IF EXISTS "client_installation_id";

DROP INDEX IF EXISTS "guard_cameras_installation_client_camera_unique";
CREATE UNIQUE INDEX IF NOT EXISTS "guard_cameras_installation_room_client_camera_unique"
  ON "guard_cameras" ("installation_id", "room_id", "client_camera_id")
  WHERE "installation_id" IS NOT NULL AND "client_camera_id" IS NOT NULL;
`;

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
try {
	await client.query('BEGIN');
	await client.query(patchSql);
	await client.query('COMMIT');
	const check = await client.query(
		"SELECT to_regclass('public.guard_installation_room_assignments') AS tbl"
	);
	console.log('Patch applied. guard_installation_room_assignments:', check.rows[0].tbl);
} catch (error) {
	await client.query('ROLLBACK');
	console.error('Patch failed:', error);
	process.exitCode = 1;
} finally {
	await client.end();
}
