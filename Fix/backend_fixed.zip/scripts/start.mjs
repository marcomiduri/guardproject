import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadEnvFile } from './env.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
loadEnvFile('.env', root);
await import('../dist/index.js');
