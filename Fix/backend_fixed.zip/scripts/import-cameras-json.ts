import { readFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { guardCamerasService } from '../src/services/guard-cameras.js';
import { guardRoomsService } from '../src/services/guard-rooms.js';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const backendRoot = join(scriptDir, '..');
const defaultGuardCamerasPath = resolve(backendRoot, '../../Guard/data/cameras.json');

type LegacyCamera = {
	id?: string;
	name?: string;
	deviceAddress?: string;
	port?: number;
	username?: string;
	password?: string;
	channel?: number;
	streamType?: number;
	type?: string;
	rtspPort?: number;
	rtspUrl?: string | null;
};

const cliArgs = process.argv.slice(2);
const explicitPath = cliArgs.find((arg) => !arg.startsWith('-') && !arg.endsWith('.ts'));
const filePath = resolve(explicitPath ?? defaultGuardCamerasPath);

if (!existsSync(filePath)) {
	console.error(`File not found: ${filePath}`);
	console.error('Usage: npm run db:import:cameras [path-to-cameras.json]');
	console.error(`Default path: ${defaultGuardCamerasPath}`);
	process.exit(1);
}

const parsed = JSON.parse(readFileSync(filePath, 'utf8')) as { cameras?: LegacyCamera[] };
const cameras = parsed.cameras ?? [];

const rooms = await guardRoomsService.list();
const defaultRoom = rooms[0];
if (!defaultRoom) {
	console.error('No rooms configured. Run db:migrate first.');
	process.exit(1);
}

const existingCameras = await guardCamerasService.list();
const existingIds = new Set(existingCameras.map((camera) => camera.id));

let imported = 0;
let skipped = 0;

for (const camera of cameras) {
	if (!camera.deviceAddress?.trim()) {
		continue;
	}

	const id = camera.id?.trim();
	if (id && existingIds.has(id)) {
		skipped += 1;
		console.log(`Skipped ${camera.name || camera.deviceAddress} (${id}) — already exists`);
		continue;
	}

	const created = await guardCamerasService.create({
		id: camera.id,
		roomId: defaultRoom.id,
		name: camera.name,
		type: camera.type === 'generic_rtsp' ? 'generic_rtsp' : 'hikvision',
		direction: 'in',
		deviceAddress: camera.deviceAddress,
		sdkPort: camera.port,
		rtspPort: camera.rtspPort,
		rtspUrl: camera.rtspUrl,
		username: camera.username,
		password: camera.password,
		channel: camera.channel,
		streamType: camera.streamType
	});

	existingIds.add(created.id);
	imported += 1;
	console.log(`Imported ${created.name || created.deviceAddress} (${created.id})`);
}

console.log(`Done: ${imported} imported, ${skipped} skipped from ${filePath}`);
