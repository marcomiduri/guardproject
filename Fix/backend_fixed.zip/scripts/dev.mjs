import { execFile, spawn } from 'node:child_process';
import { existsSync, watch } from 'node:fs';
import { createInterface } from 'node:readline';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadEnvFile } from './env.mjs';
import { buildTsxNodeArgs } from './tsx-runtime.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

loadEnvFile('.env', root);

// Node 16 uses --loader tsx; Node 20.6+ requires --import tsx.
const nodeArgs = buildTsxNodeArgs('src/index.ts');

let child = null;
let restarting = false;
let exiting = false;
let restartTimer = null;

function killChildTree() {
	if (!child?.pid) {
		return;
	}

	if (process.platform === 'win32') {
		execFile('taskkill', ['/PID', String(child.pid), '/T', '/F'], () => {});
		return;
	}

	child.kill('SIGTERM');
}

function runChild() {
	child = spawn(process.execPath, nodeArgs, {
		cwd: root,
		stdio: 'inherit',
		env: process.env,
		windowsHide: false
	});

	child.on('exit', (code) => {
		child = null;

		if (exiting) {
			process.exit(code ?? 0);
		}

		if (restarting) {
			restarting = false;
			runChild();
			return;
		}

		if (code !== 0) {
			process.exit(code ?? 1);
		}
	});
}

function restartChild() {
	if (exiting || !child || restarting) {
		return;
	}

	restarting = true;
	killChildTree();
}

function exitDev() {
	if (exiting) {
		process.exit(1);
	}

	exiting = true;
	console.log('\nStopping dev server...');
	killChildTree();
	setTimeout(() => process.exit(0), 200);
}

process.on('SIGINT', exitDev);
process.on('SIGTERM', exitDev);
if (process.platform === 'win32') {
	process.on('SIGBREAK', exitDev);
}

// Windows terminals (especially via npm/cmd) may not deliver SIGINT reliably.
if (process.stdin.isTTY) {
	const rl = createInterface({ input: process.stdin, output: process.stdout });
	rl.on('SIGINT', exitDev);
}

watch(resolve(root, 'src'), { recursive: true }, () => {
	clearTimeout(restartTimer);
	restartTimer = setTimeout(restartChild, 200);
});

runChild();
