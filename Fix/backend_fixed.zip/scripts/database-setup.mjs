import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const backendRoot = resolve(scriptDir, "..");
const defaultDrizzleDir = join(backendRoot, "drizzle");

function unquoteEnvValue(value) {
  const trimmed = value.trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1).replace(/\\n/g, "\n");
  }
  return trimmed;
}

function loadEnvFileIfPresent(file = ".env", cwd = backendRoot) {
  const path = resolve(cwd, file);
  if (!existsSync(path)) {
    return;
  }

  const text = readFileSync(path, "utf8");
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) {
      continue;
    }

    const index = line.indexOf("=");
    if (index <= 0) {
      continue;
    }

    const key = line.slice(0, index).trim();
    const value = unquoteEnvValue(line.slice(index + 1));
    if (key && process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}
const RESET_STATEMENTS = [
  "DROP SCHEMA IF EXISTS drizzle CASCADE",
  "DROP SCHEMA IF EXISTS public CASCADE",
  "CREATE SCHEMA public",
  "GRANT ALL ON SCHEMA public TO public",
];

/**
 * @param {import('pg').PoolClient} client
 */
export async function databaseHasMcPosSchema(client) {
  const { rows } = await client.query(`
    SELECT EXISTS (
      SELECT 1
      FROM information_schema.tables
      WHERE table_schema = 'public'
        AND table_name = 'users'
    ) AS exists
  `);

  return rows[0]?.exists === true;
}

/** @param {string} sql */
export function splitDrizzleStatements(sql) {
  return sql
    .split(/--> statement-breakpoint\r?\n?/)
    .map((part) => part.trim())
    .filter((part) => part.length > 0);
}

/**
 * @param {import('pg').PoolClient} client
 */
export async function resetMcPosDatabase(client) {
  for (const statement of RESET_STATEMENTS) {
    await client.query(statement);
  }
}

/**
 * @param {import('pg').PoolClient} client
 */
async function ensureDrizzleMigrationsTable(client) {
  await client.query("CREATE SCHEMA IF NOT EXISTS drizzle");
  await client.query(`
    CREATE TABLE IF NOT EXISTS drizzle.__drizzle_migrations (
      id SERIAL PRIMARY KEY,
      hash text NOT NULL,
      created_at bigint
    )
  `);
}

/**
 * @param {import('pg').PoolClient} client
 * @returns {Promise<Set<string>>}
 */
async function getAppliedMigrationHashes(client) {
  await ensureDrizzleMigrationsTable(client);
  const { rows } = await client.query(
    "SELECT hash FROM drizzle.__drizzle_migrations",
  );
  return new Set(rows.map((row) => row.hash));
}

/**
 * @param {import('pg').PoolClient} client
 * @param {string} drizzleDir
 */
export async function runMcPosMigrations(client, drizzleDir) {
  const journalPath = join(drizzleDir, "meta", "_journal.json");
  if (!existsSync(journalPath)) {
    throw new Error(`Missing Drizzle journal at ${journalPath}`);
  }

  const journal = JSON.parse(readFileSync(journalPath, "utf8"));
  const applied = await getAppliedMigrationHashes(client);
  const schemaExists = await databaseHasMcPosSchema(client);

  for (const entry of journal.entries) {
    const sqlPath = join(drizzleDir, `${entry.tag}.sql`);
    if (!existsSync(sqlPath)) {
      throw new Error(`Missing migration file ${sqlPath}`);
    }

    const sql = readFileSync(sqlPath, "utf8");
    const hash = createHash("sha256").update(sql).digest("hex");
    if (applied.has(hash)) {
      continue;
    }

    // Squashed/rewritten 0000_init against an existing DB: record the new hash
    // without re-running CREATE TABLE (avoids "relation already exists").
    if (schemaExists && entry.idx === 0) {
      await client.query(
        "INSERT INTO drizzle.__drizzle_migrations (hash, created_at) VALUES ($1, $2)",
        [hash, entry.when ?? Date.now()],
      );
      applied.add(hash);
      console.log(
        `Baselined migration ${entry.tag} (MC POS schema already present).`,
      );
      continue;
    }

    const statements = splitDrizzleStatements(sql);
    await client.query("BEGIN");
    try {
      for (const statement of statements) {
        await client.query(statement);
      }

      await client.query(
        "INSERT INTO drizzle.__drizzle_migrations (hash, created_at) VALUES ($1, $2)",
        [hash, entry.when ?? Date.now()],
      );
      await client.query("COMMIT");
      applied.add(hash);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  }
}

/**
 * @param {string} connectionString
 * @returns {{ adminConnectionString: string; databaseName: string }}
 */
export function splitPostgresConnectionString(connectionString) {
  const trimmed = connectionString.trim();
  const match = trimmed.match(
    /^(postgres(?:ql)?:\/\/[^/]+)(?:\/([^?]*))?(\?.*)?$/i,
  );

  if (!match) {
    throw new Error(`Invalid DATABASE_URL: ${connectionString}`);
  }

  const databaseName = decodeURIComponent((match[2] ?? "").trim());
  if (!databaseName) {
    throw new Error(
      "DATABASE_URL must include a database name, for example postgresql://postgres:password@127.0.0.1:5432/image",
    );
  }

  const suffix = match[3] ?? "";
  return {
    adminConnectionString: `${match[1]}/postgres${suffix}`,
    databaseName,
  };
}

/**
 * Create the target PostgreSQL database when it does not exist yet.
 *
 * @param {string} connectionString
 */
export async function ensurePostgresDatabaseExists(connectionString) {
  const { adminConnectionString, databaseName } =
    splitPostgresConnectionString(connectionString);

  const pool = new pg.Pool({
    connectionString: adminConnectionString,
    max: 1,
    connectionTimeoutMillis: 15_000,
  });

  const client = await pool.connect();
  try {
    const { rows } = await client.query(
      "SELECT 1 FROM pg_database WHERE datname = $1",
      [databaseName],
    );

    if (rows.length > 0) {
      return { created: false, databaseName };
    }

    const escapedName = databaseName.replace(/"/g, '""');
    await client.query(`CREATE DATABASE "${escapedName}"`);
    return { created: true, databaseName };
  } finally {
    client.release();
    await pool.end();
  }
}

/**
 * Drop and recreate the PostgreSQL database named in DATABASE_URL
 * (for example `image`). Used after a fresh MC POS Setup install.
 *
 * @param {string} connectionString
 */
export async function recreatePostgresDatabase(connectionString) {
  const { adminConnectionString, databaseName } =
    splitPostgresConnectionString(connectionString);

  const pool = new pg.Pool({
    connectionString: adminConnectionString,
    max: 1,
    connectionTimeoutMillis: 15_000,
  });

  const client = await pool.connect();
  try {
    await client.query(
      `
      SELECT pg_terminate_backend(pid)
      FROM pg_stat_activity
      WHERE datname = $1
        AND pid <> pg_backend_pid()
      `,
      [databaseName],
    );

    const escapedName = databaseName.replace(/"/g, '""');
    await client.query(`DROP DATABASE IF EXISTS "${escapedName}"`);
    await client.query(`CREATE DATABASE "${escapedName}"`);
    return { databaseName, recreated: true };
  } finally {
    client.release();
    await pool.end();
  }
}

/**
 * @param {{
 *   connectionString: string;
 *   drizzleDir?: string;
 *   resetIfExists?: boolean;
 * }} options
 */
export async function setupMcPosDatabase({
  connectionString,
  drizzleDir = defaultDrizzleDir,
  resetIfExists = false,
}) {
  let reset = false;

  if (resetIfExists) {
    const { databaseName } = await recreatePostgresDatabase(connectionString);
    console.log(`PostgreSQL database "${databaseName}" dropped and recreated.`);
    reset = true;
  } else {
    await ensurePostgresDatabaseExists(connectionString);
  }

  const pool = new pg.Pool({
    connectionString,
    max: 1,
    connectionTimeoutMillis: 15_000,
  });

  const client = await pool.connect();
  try {
    await runMcPosMigrations(client, drizzleDir);
    return { reset, migrated: true };
  } finally {
    client.release();
    await pool.end();
  }
}

function resolveDrizzleDir() {
  const override = process.env.MC_POS_DRIZZLE_DIR?.trim();
  return override || defaultDrizzleDir;
}

const isMain =
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (isMain) {
  if (!process.env.DATABASE_URL?.trim()) {
    loadEnvFileIfPresent(".env", backendRoot);
  }

  const resetIfExists = process.argv.includes("--reset-if-exists");
  const connectionString = process.env.DATABASE_URL?.trim();

  if (!connectionString) {
    console.error("DATABASE_URL is required");
    process.exit(1);
  }

  try {
    const result = await setupMcPosDatabase({
      connectionString,
      drizzleDir: resolveDrizzleDir(),
      resetIfExists,
    });

    if (result.reset) {
      console.log("PostgreSQL database recreated and migrations applied.");
    } else {
      console.log("MC POS database migrations applied.");
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(message);
    process.exit(1);
  }
}
