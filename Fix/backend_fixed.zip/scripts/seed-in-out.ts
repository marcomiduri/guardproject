import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { eq } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import { users } from '../src/db/schema/auth.js';
import { guardFaceAppearances } from '../src/db/schema/guard.js';

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
	throw new Error('DATABASE_URL is not set');
}

const COUNT = Number(process.env.SEED_IN_OUT_COUNT ?? 80);

const CAMERAS = [
	'entrance-main',
	'exit-side',
	'lobby-01',
	'parking-gate',
	'reception',
	'warehouse-in'
] as const;

const MOCK_USERS = [
	{ username: 'Alice Chen', email: 'alice.inout@example.com' },
	{ username: 'Bob Martinez', email: 'bob.inout@example.com' },
	{ username: 'Carol Nguyen', email: 'carol.inout@example.com' },
	{ username: 'David Kim', email: 'david.inout@example.com' },
	{ username: 'Eva Johansson', email: 'eva.inout@example.com' },
	{ username: 'Frank Okonkwo', email: 'frank.inout@example.com' },
	{ username: 'Grace Patel', email: 'grace.inout@example.com' },
	{ username: 'Henry Wilson', email: 'henry.inout@example.com' }
] as const;

type SeedUser = {
	id: string;
	username: string;
	faceRegistryId: number;
};

function pick<T>(items: readonly T[]): T {
	return items[Math.floor(Math.random() * items.length)]!;
}

function randomSimilarity(): number {
	return Math.round((0.72 + Math.random() * 0.27) * 1000) / 1000;
}

function randomOccurredAt(daysBack = 30): Date {
	const now = Date.now();
	const offsetMs = Math.floor(Math.random() * daysBack * 24 * 60 * 60 * 1000);
	return new Date(now - offsetMs);
}

async function ensureSeedUsers(db: ReturnType<typeof drizzle>): Promise<SeedUser[]> {
	const existing = await db
		.select({
			id: users.id,
			username: users.username,
			faceRegistryId: users.faceRegistryId
		})
		.from(users);

	if (existing.length > 0) {
		let nextRegistryId =
			Math.max(0, ...existing.map((user) => user.faceRegistryId ?? 0)) + 1;

		const seedUsers: SeedUser[] = [];

		for (const user of existing) {
			let faceRegistryId = user.faceRegistryId;
			if (faceRegistryId == null) {
				faceRegistryId = nextRegistryId++;
				await db
					.update(users)
					.set({
						faceRegistryId,
						faceRegisteredAt: new Date(),
						faceEmbedding: [0.1, 0.2, 0.3]
					})
					.where(eq(users.id, user.id));
			}

			seedUsers.push({
				id: user.id,
				username: user.username,
				faceRegistryId
			});
		}

		return seedUsers;
	}

	const passwordHash = await bcrypt.hash('password123', 12);
	const registeredAt = new Date();
	const seedUsers: SeedUser[] = [];

	await db.transaction(async (tx) => {
		for (let i = 0; i < MOCK_USERS.length; i++) {
			const mock = MOCK_USERS[i]!;
			const id = randomUUID();
			const faceRegistryId = i + 1;

			await tx.insert(users).values({
				id,
				username: mock.username,
				email: mock.email,
				passwordHash,
				role: 'user',
				faceRegistryId,
				faceRegisteredAt: registeredAt,
				faceEmbedding: [0.1, 0.2, 0.3],
				faceModel: 'mock'
			});

			seedUsers.push({ id, username: mock.username, faceRegistryId });
		}
	});

	return seedUsers;
}

async function seedInOutEvents(): Promise<void> {
	const pool = new pg.Pool({ connectionString: DATABASE_URL });
	const db = drizzle(pool);

	try {
		const seedUsers = await ensureSeedUsers(db);
		if (seedUsers.length === 0) {
			throw new Error('No users available to attach in-out events to');
		}

		const rows = Array.from({ length: COUNT }, () => {
			const user = pick(seedUsers);
			return {
				id: randomUUID(),
				faceRegistryId: user.faceRegistryId,
				userId: user.id,
				cameraId: pick(CAMERAS),
				eventType: 'appeared' as const,
				similarity: randomSimilarity(),
				occurredAt: randomOccurredAt()
			};
		});

		await db.insert(guardFaceAppearances).values(rows);

		console.log(
			`Seeded ${COUNT} in-out events for ${seedUsers.length} user(s). Login password for mock users: password123`
		);
	} finally {
		await pool.end();
	}
}

await seedInOutEvents();
