import { existsSync } from 'node:fs';
import pg from 'pg';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { loadEnvFile } from './env.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const envPath = resolve(root, '.env');
const placeholderPasswords = new Set(['change-me', 'changeme', 'your_password', 'your-password']);

function helpText() {
	return [
		'Edit backend\\.env and set DATABASE_URL to your PostgreSQL connection string.',
		'Create the database if needed, then run:',
		'  cd backend',
		'  npm run db:migrate',
		'',
		'Example:',
		'  DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/image'
	].join('\n');
}

function fail(message) {
	console.error(`\n${message}\n`);
	process.exit(1);
}

if (!existsSync(envPath)) {
	fail(
		'Missing backend\\.env.\n\nCopy backend\\.env.example to backend\\.env, set DATABASE_URL, then run npm run db:migrate.\n\n' +
			helpText()
	);
}

loadEnvFile('.env', root);

const databaseUrl = process.env.DATABASE_URL?.trim();
if (!databaseUrl) {
	fail(`DATABASE_URL is not set in backend\\.env.\n\n${helpText()}`);
}

let parsed;
try {
	parsed = new URL(databaseUrl);
} catch {
	fail(`DATABASE_URL is not a valid URL.\n\n${helpText()}`);
}

if (parsed.protocol !== 'postgresql:' && parsed.protocol !== 'postgres:') {
	fail(`DATABASE_URL must use the postgresql:// scheme.\n\n${helpText()}`);
}

const password = decodeURIComponent(parsed.password);
if (!password || placeholderPasswords.has(password.toLowerCase())) {
	fail(`DATABASE_URL still uses a placeholder PostgreSQL password.\n\n${helpText()}`);
}

const pool = new pg.Pool({
	connectionString: databaseUrl,
	max: 1,
	connectionTimeoutMillis: 10_000
});

try {
	await pool.query('select 1');
} catch (err) {
	const detail = err instanceof Error ? err.message : String(err);
	fail(`PostgreSQL connection failed: ${detail}\n\n${helpText()}`);
} finally {
	await pool.end();
}
