import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

function resolveTsxSpecifier() {
	const require = createRequire(resolve(root, 'package.json'));

	try {
		require.resolve('tsx');
	} catch {
		throw new Error('tsx is not installed. Run: npm install');
	}

	return 'tsx';
}

function tsxUsesImportFlag() {
	const [major, minor] = process.versions.node.split('.').map(Number);
	return major > 20 || (major === 20 && minor >= 6);
}

/** Build Node args to execute a TypeScript entry through tsx on Node 16 and 20+. */
export function buildTsxNodeArgs(entry, extraArgs = []) {
	const tsx = resolveTsxSpecifier();
	const flag = tsxUsesImportFlag() ? '--import' : '--loader';
	return [flag, tsx, entry, ...extraArgs];
}
