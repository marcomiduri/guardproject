import { execFile } from 'node:child_process';

const port = process.env.PORT ?? '3000';

if (process.platform === 'win32') {
	const command = `Get-NetTCPConnection -LocalPort ${port} -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }`;
	execFile('powershell.exe', ['-NoProfile', '-Command', command], () => {
		console.log(`Stopped process(es) using port ${port}.`);
		process.exit(0);
	});
} else {
	execFile('sh', ['-c', `lsof -ti:${port} | xargs -r kill -9`], () => {
		console.log(`Stopped process(es) using port ${port}.`);
		process.exit(0);
	});
}
