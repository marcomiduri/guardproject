#!/usr/bin/env node
import http from 'node:http';
import https from 'node:https';

/**
 * Smoke-check Guard-facing API contract against a running backend.
 *
 * Usage:
 *   node scripts/verify-guard-staging.mjs
 *   GUARD_VERIFY_BASE_URL=https://staging.example.com node scripts/verify-guard-staging.mjs
 */

const baseUrl = (process.env.GUARD_VERIFY_BASE_URL ?? 'http://127.0.0.1:3000').replace(/\/$/, '');

function fail(message) {
	console.error(`[guard-verify] FAIL: ${message}`);
	process.exitCode = 1;
}

function pass(message) {
	console.log(`[guard-verify] OK: ${message}`);
}

function requestText(path, options = {}) {
	const url = new URL(path, baseUrl);
	const client = url.protocol === 'https:' ? https : http;

	return new Promise((resolve, reject) => {
		const req = client.request(
			url,
			{
				method: options.method ?? 'GET',
				headers: options.headers ?? {}
			},
			(response) => {
				let text = '';
				response.setEncoding('utf8');
				response.on('data', (chunk) => {
					text += chunk;
				});
				response.on('end', () => {
					resolve({ response, text });
				});
			}
		);

		req.on('error', reject);
		req.end();
	});
}

async function fetchJson(path) {
	const { response, text } = await requestText(path, {
		headers: { Accept: 'application/json', 'X-Guard-Client': 'Guard' }
	});

	let body = {};
	if (text) {
		try {
			body = JSON.parse(text);
		} catch {
			body = {};
		}
	}

	return {
		response: {
			ok: response.statusCode != null && response.statusCode >= 200 && response.statusCode < 300,
			status: response.statusCode ?? 0
		},
		body
	};
}

async function main() {
	const health = await fetchJson('/api/health');
	if (!health.response.ok) {
		fail(`/api/health returned HTTP ${health.response.status}`);
	} else {
		const { body } = health;
		if (body.ok !== true && body.status !== 'ok') {
			fail('/api/health missing ok/status marker');
		} else if (typeof body.version !== 'string' || !body.version) {
			fail('/api/health missing version');
		} else if (typeof body.serverTime !== 'string' || !body.serverTime) {
			fail('/api/health missing serverTime');
		} else {
			pass(`/api/health version=${body.version}`);
		}
	}

	const unauthorized = await fetchJson('/api/guard/faces');
	if (unauthorized.response.status !== 401) {
		fail(`/api/guard/faces without JWT should return 401, got ${unauthorized.response.status}`);
	} else {
		const nested = unauthorized.body?.error;
		if (!nested || typeof nested !== 'object') {
			fail('/api/guard/faces 401 response missing nested error object');
		} else if (typeof nested.code !== 'string' || typeof nested.message !== 'string') {
			fail('/api/guard/faces 401 response missing error.code/message');
		} else if (typeof nested.retryable !== 'boolean') {
			fail('/api/guard/faces 401 response missing error.retryable');
		} else {
			pass('/api/guard/faces returns nested 401 error envelope');
		}
	}

	if (process.exitCode) {
		console.error('[guard-verify] Staging verification failed.');
		process.exit(process.exitCode);
	}

	console.log('[guard-verify] Contract checks passed.');
	console.log(
		'[guard-verify] Next: run Guard activation, token exchange, camera sync, face/hazard uploads against this backend.'
	);
}

main().catch((error) => {
	console.error('[guard-verify] Unexpected error', error);
	process.exit(1);
});
