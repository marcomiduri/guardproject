import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

function canResolveTsx() {
	try {
		createRequire(resolve(root, 'package.json')).resolve('tsx');
		return true;
	} catch {
		return false;
	}
}

if (!canResolveTsx()) {
	console.log('Dependencies are missing — running npm install...');
	const result = spawnSync('npm', ['install'], {
		cwd: root,
		stdio: 'inherit',
		env: { ...process.env, CI: 'true' },
		shell: true
	});

	if (result.status !== 0) {
		process.exit(result.status ?? 1);
	}
}
