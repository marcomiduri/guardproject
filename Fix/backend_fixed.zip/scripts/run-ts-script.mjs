import { spawn } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadEnvFile } from './env.mjs';
import { buildTsxNodeArgs } from './tsx-runtime.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const [, , script, ...args] = process.argv;

if (!script) {
	console.error('Usage: node scripts/run-ts-script.mjs <script.ts> [args...]');
	process.exit(1);
}

loadEnvFile('.env', root);

const child = spawn(process.execPath, buildTsxNodeArgs(script, args), {
	cwd: root,
	stdio: 'inherit',
	env: process.env,
	windowsHide: false
});

child.on('exit', (code, signal) => {
	if (signal) {
		process.kill(process.pid, signal);
		return;
	}
	process.exit(code ?? 0);
});
