import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { eq } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import { users } from '../src/db/schema/auth.js';
import { guardRoomOccupancy, guardRooms, roomOrders } from '../src/db/schema/guard.js';

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
	throw new Error('DATABASE_URL is not set');
}

export const TESTING_ROOM_ID = 'testing-room-alpha';

const TESTING_ROOM = {
	id: TESTING_ROOM_ID,
	name: 'Testing Room Alpha',
	maxMembers: 20,
	sortOrder: 0
} as const;

const TESTING_MEMBERS = [
	{
		username: 'Testing Alice',
		email: 'testing.alice@example.com',
		role: 'user' as const,
		faceRegistryId: 9001,
		approved: true,
		birthday: '1992-03-14',
		job: 'Software Engineer',
		position: 'Backend Developer'
	},
	{
		username: 'Testing Bob',
		email: 'testing.bob@example.com',
		role: 'user' as const,
		faceRegistryId: 9002,
		approved: false,
		birthday: '1988-07-22',
		job: 'Product Manager',
		position: 'Room Booking Lead'
	},
	{
		username: 'Testing Carol',
		email: 'testing.carol@example.com',
		role: 'staff' as const,
		faceRegistryId: 9003,
		approved: false,
		birthday: '1990-11-05',
		job: 'Facilities',
		position: 'Front Desk Staff'
	},
	{
		username: 'Testing Dave',
		email: 'testing.dave@example.com',
		role: 'user' as const,
		faceRegistryId: 9004,
		approved: true,
		birthday: '1995-01-30',
		job: 'Designer',
		position: 'UX Designer'
	},
	{
		username: 'Testing Eve',
		email: 'testing.eve@example.com',
		role: 'user' as const,
		faceRegistryId: 9005,
		approved: false,
		birthday: '1993-09-18',
		job: 'Analyst',
		position: 'Operations Analyst'
	},
	{
		username: 'Testing Frank',
		email: 'testing.frank@example.com',
		role: 'admin' as const,
		faceRegistryId: 9006,
		approved: true,
		birthday: '1985-12-02',
		job: 'IT Administration',
		position: 'System Administrator'
	}
] as const;

function mockEmbedding(seed: number): number[] {
	return Array.from({ length: 8 }, (_, index) =>
		Number(((seed + 1) * 0.01 + index * 0.001).toFixed(4))
	);
}

async function seedTestingData(): Promise<void> {
	const pool = new pg.Pool({ connectionString: DATABASE_URL });
	const db = drizzle(pool);

	try {
		const now = new Date();
		const passwordHash = await bcrypt.hash('password123', 12);
		const orderStart = new Date(now.getTime() - 24 * 60 * 60 * 1000);
		const orderEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

		const [existingRoom] = await db
			.select({ id: guardRooms.id })
			.from(guardRooms)
			.where(eq(guardRooms.id, TESTING_ROOM_ID))
			.limit(1);

		if (existingRoom) {
			await db
				.update(guardRooms)
				.set({
					name: TESTING_ROOM.name,
					maxMembers: TESTING_ROOM.maxMembers,
					sortOrder: TESTING_ROOM.sortOrder,
					updatedAt: now
				})
				.where(eq(guardRooms.id, TESTING_ROOM_ID));
		} else {
			await db.insert(guardRooms).values({
				id: TESTING_ROOM_ID,
				name: TESTING_ROOM.name,
				maxMembers: TESTING_ROOM.maxMembers,
				sortOrder: TESTING_ROOM.sortOrder,
				createdAt: now,
				updatedAt: now
			});
		}

		const [existingOccupancy] = await db
			.select({ roomId: guardRoomOccupancy.roomId })
			.from(guardRoomOccupancy)
			.where(eq(guardRoomOccupancy.roomId, TESTING_ROOM_ID))
			.limit(1);

		if (!existingOccupancy) {
			await db.insert(guardRoomOccupancy).values({
				roomId: TESTING_ROOM_ID,
				currentCount: 0,
				updatedAt: now
			});
		}

		const memberIds: string[] = [];

		for (const member of TESTING_MEMBERS) {
			const [existingUser] = await db
				.select({ id: users.id })
				.from(users)
				.where(eq(users.email, member.email))
				.limit(1);

			const userId = existingUser?.id ?? randomUUID();

			if (existingUser) {
				await db
					.update(users)
					.set({
						username: member.username,
						role: member.role,
						birthday: member.birthday,
						job: member.job,
						position: member.position,
						faceRegistryId: member.faceRegistryId,
						faceRegisteredAt: now,
						faceEmbedding: mockEmbedding(member.faceRegistryId),
						faceModel: 'testing-mock'
					})
					.where(eq(users.id, userId));
			} else {
				await db.insert(users).values({
					id: userId,
					username: member.username,
					email: member.email,
					passwordHash,
					role: member.role,
					birthday: member.birthday,
					job: member.job,
					position: member.position,
					faceRegistryId: member.faceRegistryId,
					faceRegisteredAt: now,
					faceEmbedding: mockEmbedding(member.faceRegistryId),
					faceModel: 'testing-mock'
				});
			}

			memberIds.push(userId);

			if (member.approved) {
				const [existingOrder] = await db
					.select({ id: roomOrders.id })
					.from(roomOrders)
					.where(eq(roomOrders.userId, userId))
					.limit(1);

				if (!existingOrder) {
					await db.insert(roomOrders).values({
						id: randomUUID(),
						userId,
						roomId: TESTING_ROOM_ID,
						startTime: orderStart,
						endTime: orderEnd,
						status: 'approved',
						createdAt: now,
						updatedAt: now
					});
				}
			}
		}

		console.log('Testing seed complete.');
		console.log(`Room: ${TESTING_ROOM.name} (${TESTING_ROOM_ID})`);
		console.log(`Members: ${TESTING_MEMBERS.length} virtual users with faceRegistryId 9001–9006`);
		console.log('Password for new accounts: password123');
		console.log('Approved members: Alice, Dave, Frank');
		console.log('Unapproved members: Bob, Eve (staff/admin bypass unapproved alerts)');
	} finally {
		await pool.end();
	}
}

await seedTestingData();
