import { existsSync } from 'node:fs';
import { defineConfig } from 'drizzle-kit';
import { loadEnvFile } from './scripts/env.mjs';

if (existsSync('.env')) {
	loadEnvFile('.env');
}

if (!process.env.DATABASE_URL) {
	throw new Error('DATABASE_URL is not set');
}

export default defineConfig({
	schema: './src/db/schema/index.ts',
	out: './drizzle',
	dialect: 'postgresql',
	dbCredentials: { url: process.env.DATABASE_URL },
	verbose: true,
	strict: true
});
