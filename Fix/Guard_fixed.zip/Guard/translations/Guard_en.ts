<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en_US">
    <context>
        <name>AppSettingsDialog</name>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="151" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="154" />
            <source>Enabled</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="151" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="154" />
            <source>Disabled</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="178" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="595" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="605" />
            <source>Application Settings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="192" />
            <source>Server</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="194" />
            <source>Alerts</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="195" />
            <source>Recording</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="211" />
            <source>Cancel</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="212" />
            <source>Save</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="246" />
            <source>Backend Server</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="256" />
            <source>Base URL</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="260" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="411" />
            <source>Source</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="261" />
            <source>Not tested</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="263" />
            <source>Connection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="264" />
            <source>Unknown</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="266" />
            <source>Backend version</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="267" />
            <source>Test Connection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="291" />
            <source>Status</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="331" />
            <source>Local Hazard Alarm</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="338" />
            <source>Play an alarm on this computer</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="349" />
            <source>Volume</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="350" />
            <source>Repeat until acknowledged</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="352" />
            <source>Test Alarm</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="360" />
            <source>Backend-Controlled Access Warnings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="365" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="367" />
            <source>Loaded after backend authentication</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="369" />
            <source>Unknown incoming</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="370" />
            <source>Unapproved incoming</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="371" />
            <source>These policies are configured by an administrator. Disabling a warning never disables event upload.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="386" />
            <source>Recording Storage</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="398" />
            <source>Leave empty to use the default recording location</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="399" />
            <source>Browse...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="403" />
            <source>Recording root</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="407" />
            <source>Effective path</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="416" />
            <source>Open Folder</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="417" />
            <source>Restore Default</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="483" />
            <source>Expires %1 (%2 day(s) remaining)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="509" />
            <source>Backend client unavailable</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="517" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="595" />
            <source>Enter a valid HTTP or HTTPS backend URL.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="521" />
            <source>Testing...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="531" />
            <source>Connected</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="539" />
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="543" />
            <source>Connected; version not reported</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="567" />
            <source>Available space: %1 GB</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="568" />
            <source>The folder will be validated when settings are saved.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="572" />
            <source>Select Recording Root</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Diagnostics</source>
            <translation>Diagnostics</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Camera Logging</source>
            <translation>Camera Logging</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Write each camera's Logs dialog messages to a file</source>
            <translation>Write each camera's Logs dialog messages to a file</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Log directory</source>
            <translation>Log directory</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>When disabled, camera messages remain available in each Logs dialog for the current session, but no new log files are written. Existing log files are preserved.</source>
            <translation>When disabled, camera messages remain available in each Logs dialog for the current session, but no new log files are written. Existing log files are preserved.</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Log folder</source>
            <translation>Log folder</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Leave empty to use the default camera log folder</source>
            <translation>Leave empty to use the default camera log folder</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Default application log folder</source>
            <translation>Default application log folder</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Environment override active: GUARD_LOG_ROOT</source>
            <translation>Environment override active: GUARD_LOG_ROOT</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>Select Camera Log Folder</source>
            <translation>Select Camera Log Folder</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="0" />
            <source>The camera log folder could not be opened.</source>
            <translation>The camera log folder could not be opened.</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>License</source>
            <translation>License</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>License Information</source>
            <translation>License Information</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>Hardware ID</source>
            <translation>Hardware ID</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>Hardware ID unavailable</source>
            <translation>Hardware ID unavailable</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>License key</source>
            <translation>License key</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>The hardware ID is a protected, hardware-derived identifier. License keys are stored securely on this computer.</source>
            <translation>The hardware ID is a protected, hardware-derived identifier. License keys are stored securely on this computer.</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>Enter the license key in XXXX-XXXX-XXXX-XXXX format.</source>
            <translation>Enter the license key in XXXX-XXXX-XXXX-XXXX format.</translation>
        </message>
        <message>
            <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="1" />
            <source>Camera log folder</source>
            <translation>Camera log folder</translation>
        </message>
    </context>
    <context>
        <name>CameraDialog</name>
        <message>
            <location filename="../ui/CameraDialog.ui" line="14" />
            <source>Camera Settings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="58" />
            <source>Type</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="66" />
            <source>Hikvision</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="71" />
            <source>Generic (RTSP)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="79" />
            <source>Name</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="86" />
            <source>Front door</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="93" />
            <source>Direction</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="101" />
            <source>Incoming — enters the room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="106" />
            <source>Outgoing — leaves the room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="114" />
            <source>IP Address</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="124" />
            <source>SDK Port</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="141" />
            <source>RTSP Port</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="158" />
            <source>Username</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="165" />
            <source>admin</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="172" />
            <source>Password</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="186" />
            <source>Channel</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="203" />
            <source>Stream</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="211" />
            <source>Main Stream</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="216" />
            <source>Sub Stream</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="224" />
            <source>RTSP URL</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraDialog.ui" line="231" />
            <source>Optional override, e.g. rtsp://user:pass@host:554/...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraDialog.cpp" line="68" />
            <source>Add Camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraDialog.cpp" line="213" />
            <source>Cancel</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraDialog.cpp" line="224" />
            <source>OK</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraDialog.cpp" line="256" />
            <location filename="../src/ui/camera/CameraDialog.cpp" line="262" />
            <source>Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraDialog.cpp" line="256" />
            <source>Please enter a camera name.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraDialog.cpp" line="262" />
            <source>Please enter an IP address or RTSP URL.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>CameraGridWidget</name>
        <message>
            <location filename="../ui/CameraGridWidget.ui" line="20" />
            <source>Camera Grid</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraGridWidget.ui" line="74" />
            <source>No cameras</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>CameraRuntimeController</name>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="110" />
            <source>Decoder error: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="122" />
            <source>Source playback completed.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="132" />
            <source>Onboard capabilities updated. Alarm subscription: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="132" />
            <source>active</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="132" />
            <source>inactive</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="160" />
            <source>Onboard candidate rejected: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="167" />
            <source>Motion recording started: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="169" />
            <source>Motion recording finalized: %1 (%2 packets/frames)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="171" />
            <source>Recording error: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="173" />
            <source>Recording warning: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="184" />
            <source>GuardVision error [%1]: %2</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="233" />
            <source>Camera connection settings updated.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="246" />
            <source>The selected test media file does not exist.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="259" />
            <source>The selected test source must be a JPG, JPEG, PNG, or BMP image.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="265" />
            <source>The selected test source must be an MP4, AVI, MOV, or MKV video.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="279" />
            <source>Test source selected: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="286" />
            <source>Camera IP address is required.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="292" />
            <source>Camera username is required.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="311" />
            <source>A valid rtsp:// URL or camera address is required.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="342" />
            <source>GuardVision is not initialized.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="365" />
            <source>GuardVision returned an invalid stream generation.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="372" />
            <source>GuardVision stream registered: %1 (generation %2)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="384" />
            <source>Stream unregister warning: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="397" />
            <source>Invalid source configuration.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="401" />
            <source>Stream registration failed.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="410" />
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="412" />
            <source>The camera source could not be started.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="421" />
            <source>Motion recording enabled. Output: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="423" />
            <source>Encoded recording is waiting for stream information; decoded-frame fallback is available.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="426" />
            <source>Connecting</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="427" />
            <source>Camera source started.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="446" />
            <source>Disconnected</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="535" />
            <source>Detection settings updated: motion=%1, face=%2, hazard=%3, record=%4</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="539" />
            <source>on</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="539" />
            <source>off</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="543" />
            <source>Per-camera test source updated: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="545" />
            <source>Per-camera test source disabled; configured camera source will be used.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="552" />
            <source>Test source changed while running; restarting only this camera.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="560" />
            <source>Dropped stale decoded frame: cameraId=%1 expectedGeneration=%2 receivedGeneration=%3 sourceType=%4 mediaPath=%5</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="590" />
            <source>First frame accepted by GuardVision.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="592" />
            <source>First frame rejected by GuardVision: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="595" />
            <source>Frame submission failed and the camera was stopped: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="628" />
            <source>Dropped stale GuardVision motion event: cameraId=%1 eventGeneration=%2 activeGuardVisionGeneration=%3 eventType=%4</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="641" />
            <source>Motion started.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="646" />
            <source>Motion ended.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="760" />
            <source>Hazard ended.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="765" />
            <source>Smoke ended.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="768" />
            <source>Fire ended.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="788" />
            <source>Fire started.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="790" />
            <source>Smoke started.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="818" />
            <source>Dropped stale GuardVision alarm event: cameraId=%1 eventGeneration=%2 activeGuardVisionGeneration=%3 alarmType=%4 alarmState=%5</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>The previous camera session has not stopped safely.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Face identification is unavailable. Camera monitoring will continue.</source>
            <translation>Face identification is unavailable. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Face identification is unavailable: %1. Camera monitoring will continue.</source>
            <translation>Face identification is unavailable: %1. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Camera log file initialized: %1</source>
            <translation>Camera log file initialized: %1</translation>
        </message>
        <message>
            <source>Camera file logging could not be initialized: %1</source>
            <translation>Camera file logging could not be initialized: %1</translation>
        </message>
        <message>
            <source>Camera renamed from %1 to %2. Previous log file: %3</source>
            <translation>Camera renamed from %1 to %2. Previous log file: %3</translation>
        </message>
        <message>
            <source>Camera log file changed to: %1</source>
            <translation>Camera log file changed to: %1</translation>
        </message>
        <message>
            <source>Camera log file could not be changed after rename: %1</source>
            <translation>Camera log file could not be changed after rename: %1</translation>
        </message>
        <message>
            <source>Camera start requested. Camera: %1; source type: %2</source>
            <translation>Camera start requested. Camera: %1; source type: %2</translation>
        </message>
        <message>
            <source>test media</source>
            <translation>test media</translation>
        </message>
        <message>
            <source>Camera start failed during source configuration: %1</source>
            <translation>Camera start failed during source configuration: %1</translation>
        </message>
        <message>
            <source>Camera start failed during GuardVision stream registration: %1</source>
            <translation>Camera start failed during GuardVision stream registration: %1</translation>
        </message>
        <message>
            <source>Camera source start failed: %1</source>
            <translation>Camera source start failed: %1</translation>
        </message>
        <message>
            <source>Camera stop requested.</source>
            <translation>Camera stop requested.</translation>
        </message>
        <message>
            <source>Camera stopped safely.</source>
            <translation>Camera stopped safely.</translation>
        </message>
        <message>
            <source>Camera log file write failed: %1</source>
            <translation>Camera log file write failed: %1</translation>
        </message>
        <message>
            <source>Camera log session started. Camera ID: %1</source>
            <translation>Camera log session started. Camera ID: %1</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera file logging is disabled in Application Settings.</source>
            <translation>Camera file logging is disabled in Application Settings.</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera renamed from %1 to %2. File logging is disabled.</source>
            <translation>Camera renamed from %1 to %2. File logging is disabled.</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera file logging disabled from Application Settings.</source>
            <translation>Camera file logging disabled from Application Settings.</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera file logging could not be enabled: %1</source>
            <translation>Camera file logging could not be enabled: %1</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera file logging enabled from Application Settings.</source>
            <translation>Camera file logging enabled from Application Settings.</translation>
        </message>
        <message>
            <source>Waiting synchronously for the media source to quiesce.</source>
            <translation>Waiting synchronously for the media source to quiesce.</translation>
        </message>
        <message>
            <source>Camera source teardown timed out; GuardVision remains registered to avoid a decoder/session race.</source>
            <translation>Camera source teardown timed out; GuardVision remains registered to avoid a decoder/session race.</translation>
        </message>
        <message>
            <source>Media source quiesced.</source>
            <translation>Media source quiesced.</translation>
        </message>
        <message>
            <source>Asynchronous camera teardown started.</source>
            <translation>Asynchronous camera teardown started.</translation>
        </message>
        <message>
            <source>Media source was already quiescent; scheduling GuardVision cleanup.</source>
            <translation>Media source was already quiescent; scheduling GuardVision cleanup.</translation>
        </message>
        <message>
            <source>Recording stop requested for source generation %1.</source>
            <translation>Recording stop requested for source generation %1.</translation>
        </message>
        <message>
            <source>Media source stop requested.</source>
            <translation>Media source stop requested.</translation>
        </message>
        <message>
            <source>Camera source is still stopping after 5 seconds; waiting without unregistering GuardVision.</source>
            <translation>Camera source is still stopping after 5 seconds; waiting without unregistering GuardVision.</translation>
        </message>
        <message>
            <source>Media source quiesced; scheduling GuardVision cleanup on the next UI turn.</source>
            <translation>Media source quiesced; scheduling GuardVision cleanup on the next UI turn.</translation>
        </message>
        <message>
            <source>GuardVision stream unregister started.</source>
            <translation>GuardVision stream unregister started.</translation>
        </message>
        <message>
            <source>GuardVision stream unregister completed.</source>
            <translation>GuardVision stream unregister completed.</translation>
        </message>
        <message>
            <source>Media source quiesced during controller destruction.</source>
            <translation>Media source quiesced during controller destruction.</translation>
        </message>
        <message>
            <source>Reusing retained GuardVision stream: %1 (generation %2)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Retained GuardVision stream is no longer available; registering a replacement.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Camera source failed to start; GuardVision stream retained for safe reuse.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Media source was already quiescent; scheduling final camera cleanup.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Media source quiesced; scheduling final camera cleanup on the next UI turn.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>GuardVision stream retained for safe reconnect; per-stream unregister deferred to application shutdown.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>GuardVision stream retained for coordinated application shutdown.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="320" />
            <source>Backend room mapping detached; local camera monitoring remains available.</source>
            <translation>Backend room mapping detached; local camera monitoring remains available.</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="320" />
            <source>Backend room mapping attached.</source>
            <translation>Backend room mapping attached.</translation>
        </message>
    </context>
    <context>
        <name>CameraSettingsDialog</name>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="85" />
            <source>Camera Settings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="99" />
            <source>Detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="117" />
            <source>Motion detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="118" />
            <source>Face detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="119" />
            <source>Hazard detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="121" />
            <source>Record Video for Motion</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="127" />
            <source>Test Source</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="142" />
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="294" />
            <source>Leave empty for configured camera, or select an image/video file</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="145" />
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="295" />
            <source>Browse...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="151" />
            <source>Media file</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="154" />
            <source>The selected file is used only by this camera. Image and video mode are detected from the file extension.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="179" />
            <source>Cancel</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="184" />
            <source>OK</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="237" />
            <source>Camera: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="298" />
            <source>No test file selected. This camera will use its configured camera source.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="300" />
            <source>Image mode selected. The image will repeat continuously for this camera.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="302" />
            <source>Video mode selected. The video will loop through the TestLib-style decoder pipeline.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="304" />
            <source>Unsupported test file type. Select JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="320" />
            <source>Onboard detection becomes available after an HCNetSDK camera connects and its alarm channel is subscribed.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="322" />
            <source>Image and video test files support software detection only. Onboard and hybrid modes are unavailable for file sources.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="333" />
            <source>Onboard alarm route is active.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="336" />
            <source>Software and hybrid hazard detection require models/fire_smoke.onnx beside Guard.exe.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="343" />
            <source>Select Test Media</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="344" />
            <source>Supported Media (*.jpg *.jpeg *.png *.bmp *.mp4 *.avi *.mov *.mkv);;Images (*.jpg *.jpeg *.png *.bmp);;Videos (*.mp4 *.avi *.mov *.mkv);;All Files (*.*)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="369" />
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="388" />
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="395" />
            <source>Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="370" />
            <source>Hazard model not found. Copy models/fire_smoke.onnx beside Guard.exe before enabling hazard detection.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="388" />
            <source>Select an existing test media file for this camera.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="395" />
            <source>The selected test source must be a JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV file.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera log folder could not be applied: %1</source>
            <translation>Camera log folder could not be applied: %1</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>Camera log folder updated from Application Settings.</source>
            <translation>Camera log folder updated from Application Settings.</translation>
        </message>
        <message>
            <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="0" />
            <source>First frame accepted by GuardVision. Source: %1; shared frame pipeline active.</source>
            <translation>First frame accepted by GuardVision. Source: %1; shared frame pipeline active.</translation>
        </message>
    </context>
    <context>
        <name>CameraView</name>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="187" />
            <source>No camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="216" />
            <source>Motion detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="226" />
            <source>Motion %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="226" />
            <source>Motion</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="236" />
            <source>%1 %2</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="236" />
            <source>Fire</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="236" />
            <source>Smoke</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraView.cpp" line="247" />
            <source>UNKNOWN</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>CameraWidget</name>
        <message>
            <location filename="../ui/CameraWidget.ui" line="20" />
            <source>Camera Widget</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="116" />
            <location filename="../ui/CameraWidget.ui" line="119" />
            <source>Camera 1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="160" />
            <source>Edit camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="163" />
            <source>Edit</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="182" />
            <source>Remove camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="185" />
            <source>Remove</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="240" />
            <source>Camera View</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="294" />
            <source>Camera status</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="317" />
            <location filename="../src/ui/camera/CameraWidget.cpp" line="387" />
            <source>DISCONNECTED</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="385" />
            <source>Open camera settings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="388" />
            <source>Settings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="407" />
            <source>Open camera logs</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="410" />
            <source>Logs</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="445" />
            <source>Connect camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="448" />
            <source>Connect</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="470" />
            <source>Disconnect camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/CameraWidget.ui" line="473" />
            <source>Disconnect</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/camera/CameraWidget.cpp" line="387" />
            <source>CONNECTED</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>DetectionModeCombo</name>
        <message>
            <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="15" />
            <source>No detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="16" />
            <source>Software detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="17" />
            <source>Onboard detection</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="18" />
            <source>Hybrid detection</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>GuardBackendClient</name>
        <message>
            <location filename="../src/services/backend/GuardApiError.cpp" line="35" />
            <source>Backend request timed out.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardApiError.cpp" line="37" />
            <source>Backend request failed (%1).</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardApiError.cpp" line="39" />
            <source>Backend request failed.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="35" />
            <source>Backend URL must not contain embedded credentials.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="39" />
            <source>Enter a valid HTTP or HTTPS backend URL.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="135" />
            <source>Environment override: GUARD_API_URL</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="138" />
            <source>Saved application setting</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="140" />
            <source>Development default</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>HazardAlarmIndicator</name>
        <message>
            <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="66" />
            <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="118" />
            <source>Hazard alarm active</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="116" />
            <source>Fire/smoke alarm</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Hazard Ended (no active fire/smoke)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Hazard ended; no active fire or smoke</source>
            <translation type="unfinished" />
        </message>
        <message>
            <source>Dismiss hazard indicator and alarm</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>MainWindow</name>
        <message>
            <location filename="../ui/MainWindow.ui" line="20" />
            <source>Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="99" />
            <source>Change language</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="102" />
            <source>English</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="140" />
            <source>Login to room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="143" />
            <source>Login to Room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="162" />
            <source>Add camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="165" />
            <location filename="../src/app/MainWindow.cpp" line="599" />
            <location filename="../src/app/MainWindow.cpp" line="609" />
            <location filename="../src/app/MainWindow.cpp" line="613" />
            <source>Add Camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="271" />
            <source>Connection state</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="294" />
            <source>Disconnected</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../ui/MainWindow.ui" line="332" />
            <source>Open settings</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="155" />
            <source>GuardVision ready - test mode</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="155" />
            <source>GuardVision ready</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="156" />
            <source>GuardVision unavailable - test mode</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="156" />
            <source>GuardVision unavailable</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="229" />
            <location filename="../src/app/MainWindow.cpp" line="519" />
            <location filename="../src/app/MainWindow.cpp" line="682" />
            <location filename="../src/app/MainWindow.cpp" line="788" />
            <location filename="../src/app/MainWindow.cpp" line="873" />
            <location filename="../src/app/MainWindow.cpp" line="885" />
            <location filename="../src/app/MainWindow.cpp" line="985" />
            <source>Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="229" />
            <source>GuardVision initialization failed: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="255" />
            <source>Backend session authenticated</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="275" />
            <source>Backend session: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="284" />
            <source>%1 event queued: %2</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="288" />
            <source>%1 event rejected: %2</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="346" />
            <source>Backend face registry unavailable: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="355" />
            <source>backend %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="398" />
            <source>Face registry enrollment failed: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="404" />
            <source>Loaded face registry: %1 face(s), %2</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="406" />
            <source>unknown model</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="437" />
            <source>Camera synchronization failed: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="519" />
            <source>You can add up to %1 cameras.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="531" />
            <source>Recording root updated: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="561" />
            <source>Application settings saved</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="613" />
            <location filename="../src/app/MainWindow.cpp" line="721" />
            <source>The backend did not return a camera ID.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="685" />
            <location filename="../src/app/MainWindow.cpp" line="852" />
            <source>%1 camera(s) configured</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="695" />
            <location filename="../src/app/MainWindow.cpp" line="707" />
            <location filename="../src/app/MainWindow.cpp" line="717" />
            <location filename="../src/app/MainWindow.cpp" line="721" />
            <source>Edit Camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="755" />
            <source>Camera reconnect failed: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="788" />
            <source>Camera settings could not be applied: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="805" />
            <source>%1 Logs</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="833" />
            <source>Remove Camera</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="873" />
            <source>GuardVision is not initialized.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="885" />
            <source>The camera could not be started.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="899" />
            <source>Room Registration</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="900" />
            <source>This computer is registered with %1. Unregister this computer?</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="910" />
            <source>Hardware Verification Required</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="911" />
            <source>Guard could not verify both required hardware identifiers. Check Windows hardware-management services and retry before registering this computer.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="920" />
            <source>Camera Direction Required</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="921" />
            <source>The camera '%1' was created by an older Guard version. Edit it and select Incoming or Outgoing before registering this room.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="951" />
            <source>Register Room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="952" />
            <source>Register this computer with a backend room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="957" />
            <source>%1 — Connected</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="958" />
            <source>View or unregister this room registration</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="985" />
            <source>Guard - Test Mode</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="993" />
            <location filename="../src/app/MainWindow.cpp" line="1040" />
            <source>Show Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="995" />
            <location filename="../src/app/MainWindow.cpp" line="1042" />
            <source>Exit</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="1002" />
            <source>Switch to %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Checking backend connection...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Backend unavailable: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Backend connection available</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Face registry version unavailable: %1</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Face registry is up to date.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Loading face registry...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Loaded face registry: %1 face(s)</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Backend unavailable. Opening in offline mode.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Backend connection unavailable</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Backend session unavailable</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Restoring room connection...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Room connection unavailable. Opening in offline mode.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Room session restored.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Checking face registry...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Face registry unavailable. Camera face identification will wait for a successful refresh.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Face registry not loaded</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Camera sync incomplete. Local cameras kept.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Ready.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Guard ready</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Guard ready - face registry pending</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Loading the face registry before starting the camera...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>The camera was not started because the face registry could not be loaded.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>The camera was not started because the face registry response was invalid.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>The camera was not started because the face registry version could not be checked.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>The camera was not started because the face registry version response was invalid.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>The camera was not started because GuardVision rejected the face registry.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>Camera start cancelled.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" />
            <source>Room disconnected. Backend is available.</source>
            <translation>Room disconnected. Backend is available.</translation>
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" />
            <source>Backend available. No saved room session.</source>
            <translation>Backend available. No saved room session.</translation>
        </message>
        <message>
            <source>Face registry downloaded. Waiting for face identification initialization...</source>
            <translation>Face registry downloaded. Waiting for face identification initialization...</translation>
        </message>
        <message>
            <source>Backend face registry unavailable: %1. Camera monitoring will continue.</source>
            <translation>Backend face registry unavailable: %1. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>%1 Camera monitoring will continue.</source>
            <translation>%1 Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Face registry version could not be checked. Camera monitoring will continue.</source>
            <translation>Face registry version could not be checked. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Face registry is ready and waiting for GuardVision initialization.</source>
            <translation>Face registry is ready and waiting for GuardVision initialization.</translation>
        </message>
        <message>
            <source>Face registry enrollment failed: %1. Camera monitoring will continue.</source>
            <translation>Face registry enrollment failed: %1. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Face identification is unavailable. Camera monitoring will continue.</source>
            <translation>Face identification is unavailable. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Face identification is unavailable: %1. Camera monitoring will continue.</source>
            <translation>Face identification is unavailable: %1. Camera monitoring will continue.</translation>
        </message>
        <message>
            <source>Camera is starting while face identification is pending.</source>
            <translation>Camera is starting while face identification is pending.</translation>
        </message>
        <message>
            <source>Log file is unavailable.</source>
            <translation>Log file is unavailable.</translation>
        </message>
        <message>
            <source>Log file: %1</source>
            <translation>Log file: %1</translation>
        </message>
        <message>
            <source>Open Log File</source>
            <translation>Open Log File</translation>
        </message>
        <message>
            <source>Open Log Folder</source>
            <translation>Open Log Folder</translation>
        </message>
        <message>
            <source>Camera Logs</source>
            <translation>Camera Logs</translation>
        </message>
        <message>
            <source>The camera log file is not available.</source>
            <translation>The camera log file is not available.</translation>
        </message>
        <message>
            <source>The camera log file could not be opened.</source>
            <translation>The camera log file could not be opened.</translation>
        </message>
        <message>
            <source>The camera log folder is not available.</source>
            <translation>The camera log folder is not available.</translation>
        </message>
        <message>
            <source>The camera log folder could not be opened.</source>
            <translation>The camera log folder could not be opened.</translation>
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="0" />
            <source>File logging is disabled or the log file is unavailable.</source>
            <translation>File logging is disabled or the log file is unavailable.</translation>
        </message>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="905" />
            <source>Face registry downloaded. Waiting for a camera stream to become active...</source>
            <translation>Face registry downloaded. Waiting for a camera stream to become active...</translation>
        </message>
        <message>
            <source>Camera %1</source>
            <translation>Camera %1</translation>
        </message>
        <message>
            <source>Camera IP Conflict</source>
            <translation>Camera IP Conflict</translation>
        </message>
        <message>
            <source>The IP address is already used by '%1'. Enter a different camera IP address.</source>
            <translation>The IP address is already used by '%1'. Enter a different camera IP address.</translation>
        </message>
        <message>
            <source>Loaded %1 camera(s) for the selected room.</source>
            <translation>Loaded %1 camera(s) for the selected room.</translation>
        </message>
        <message>
            <source>Room cameras disconnected and removed.</source>
            <translation>Room cameras disconnected and removed.</translation>
        </message>

    </context>
    <context>
        <name>QObject</name>
        <message>
            <location filename="../src/app/MainWindow.cpp" line="128" />
            <source>This Guard installation has been revoked. Re-register the room or contact an administrator.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/api/FaceRegistryLoader.cpp" line="18" />
            <source>Face registry response is not valid JSON.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/api/FaceRegistryLoader.cpp" line="63" />
            <source>Face registry version response is not valid JSON.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/api/FaceRegistryLoader.cpp" line="70" />
            <source>Face registry version response is missing version.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="54" />
            <source>Backend response is not a JSON object.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="146" />
            <source>Backend URL is controlled by GUARD_API_URL.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="165" />
            <source>Backend URL could not be saved.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>RoomRegistrationDialog</name>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="55" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="158" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="163" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="168" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="183" />
            <source>Register Room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="66" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="185" />
            <source>Enter the one-time activation code issued for this room. The code is used only during registration and is not stored.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="77" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="197" />
            <source>Room ID or room name</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="83" />
            <source>Guard Computer</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="83" />
            <source>%1 Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="84" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="190" />
            <source>Room</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="85" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="192" />
            <source>Activation code</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="86" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="194" />
            <source>Device name</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="102" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="199" />
            <source>Cancel</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="103" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="148" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="201" />
            <source>Register</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="148" />
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="203" />
            <source>Registering...</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="158" />
            <source>Enter the room ID or room name.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="163" />
            <source>Enter the one-time activation code.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/dialogs/RoomRegistrationDialog.cpp" line="168" />
            <source>Enter a device name.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>SecureCredentialStore</name>
        <message>
            <location filename="../src/platform/security/SecureCredentialStore.cpp" line="52" />
            <source>Credential name is empty.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/platform/security/SecureCredentialStore.cpp" line="66" />
            <source>Windows could not protect the credential (error %1).</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/platform/security/SecureCredentialStore.cpp" line="86" />
            <source>Credential storage failed.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/platform/security/SecureCredentialStore.cpp" line="113" />
            <source>Windows could not read the protected credential (error %1).</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/platform/security/SecureCredentialStore.cpp" line="135" />
            <source>Credential could not be removed.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>WindowTitleBar</name>
        <message>
            <location filename="../src/ui/shell/WindowTitleBar.cpp" line="60" />
            <source>Guard</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/shell/WindowTitleBar.cpp" line="60" />
            <source>Dialog</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/shell/WindowTitleBar.cpp" line="188" />
            <source>Restore</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/ui/shell/WindowTitleBar.cpp" line="188" />
            <source>Maximize</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>guard::alerts::CameraAlarmService</name>
        <message>
            <location filename="../src/services/alerts/CameraAlarmService.cpp" line="20" />
            <location filename="../src/services/alerts/CameraAlarmService.cpp" line="27" />
            <source>This camera does not expose a supported alarm output.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>guard::alerts::LocalAlertService</name>
        <message>
            <location filename="../src/services/alerts/LocalAlertService.cpp" line="101" />
            <source>Access denied. You are not registered in the system.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/alerts/LocalAlertService.cpp" line="105" />
            <source>Access denied. You do not have permission to enter this room at this time.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>guard::backend::GuardBackendClient</name>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="318" />
            <source>Backend request URL is invalid.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="378" />
            <source>Backend request could not be created.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="433" />
            <source>Backend request timed out.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="438" />
            <source>Backend request failed (%1): %2</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardBackendClient.cpp" line="439" />
            <source>Backend request failed: %1</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>guard::backend::GuardSessionManager</name>
        <message>
            <location filename="../src/services/backend/GuardSessionManager.cpp" line="91" />
            <source>Installation state could not be saved.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardSessionManager.cpp" line="100" />
            <source>Backend did not return a device credential.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardSessionManager.cpp" line="130" />
            <source>Backend response is missing installation or room information.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardSessionManager.cpp" line="137" />
            <source>Backend activation response is missing the device credential.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardSessionManager.cpp" line="185" />
            <source>Backend session is unavailable.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/backend/GuardSessionManager.cpp" line="191" />
            <source>The saved device credential is unavailable.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>guard::events::GuardEventCoordinator</name>
        <message>
            <location filename="../src/services/events/GuardEventCoordinator.cpp" line="292" />
            <source>Backend session is unavailable.</source>
            <translation type="unfinished" />
        </message>
    </context>
    <context>
        <name>guard::events::OfflineEventQueue</name>
        <message>
            <location filename="../src/services/events/OfflineEventQueue.cpp" line="50" />
            <source>Pending event is missing an event ID or endpoint.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/events/OfflineEventQueue.cpp" line="57" />
            <source>Pending event folder could not be replaced.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/events/OfflineEventQueue.cpp" line="62" />
            <source>Pending event folder could not be created.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/events/OfflineEventQueue.cpp" line="74" />
            <source>Pending event image could not be saved.</source>
            <translation type="unfinished" />
        </message>
        <message>
            <location filename="../src/services/events/OfflineEventQueue.cpp" line="104" />
            <source>Pending event metadata could not be saved.</source>
            <translation type="unfinished" />
        </message>
    </context>

    <context>
        <name>GuardMessageDialog</name>
        <message>
            <source>No</source>
            <translation>No</translation>
        </message>
        <message>
            <source>Yes</source>
            <translation>Yes</translation>
        </message>
        <message>
            <source>OK</source>
            <translation>OK</translation>
        </message>
    </context>

    <context>
        <name>RoomConnectionDialog</name>
        <message>
            <source>Room disconnected. Select any available room to connect this computer again.</source>
            <translation>Room disconnected. Select any available room to connect this computer again.</translation>
        </message>
    </context>
</TS>