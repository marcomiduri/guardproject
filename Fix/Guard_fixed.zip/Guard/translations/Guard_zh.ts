<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="zh_CN">
<context>
    <name>AppSettingsDialog</name>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="229" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="231" />
        <source>Enabled</source>
        <translation>已启用</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="229" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="231" />
        <source>Disabled</source>
        <translation>已禁用</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="254" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="672" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="701" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="717" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="728" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="736" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="746" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="757" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="786" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="793" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="826" />
        <source>Application Settings</source>
        <translation>应用程序设置</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="268" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="829" />
        <source>Server</source>
        <translation>服务器</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="269" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="833" />
        <source>Alerts</source>
        <translation>警报</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="270" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="835" />
        <source>Recording</source>
        <translation>录像</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="288" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="930" />
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="289" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="932" />
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="318" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="840" />
        <source>Backend Server</source>
        <translation>后端服务器</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="327" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="846" />
        <source>Base URL</source>
        <translation>基础 URL</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="331" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="467" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="515" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="847" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="901" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="915" />
        <source>Source</source>
        <translation>来源</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="332" />
        <source>Not tested</source>
        <translation>未测试</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="334" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="848" />
        <source>Connection</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="335" />
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="337" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="849" />
        <source>Backend version</source>
        <translation>后端版本</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="338" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="852" />
        <source>Test Connection</source>
        <translation>测试连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="355" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="854" />
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="366" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="861" />
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="379" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="863" />
        <source>Activate License</source>
        <translation>激活许可证</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="385" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="866" />
        <source>Copy the Guard hardware ID into LicenseGenerator. Non-activated LicenseGenerator output creates a 7-day Guard license. Activated LicenseGenerator output creates a permanent Guard license.</source>
        <translation>将 Guard 硬件 ID 复制到 LicenseGenerator。未激活的 LicenseGenerator 输出会生成 7 天 Guard 许可证；已激活的输出会生成永久 Guard 许可证。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="398" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="869" />
        <source>Local Hazard Alarm</source>
        <translation>本地危险警报</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="402" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="871" />
        <source>Play an alarm on this computer</source>
        <translation>在此计算机上播放警报</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="413" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="873" />
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="414" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="875" />
        <source>Repeat until acknowledged</source>
        <translation>重复播放直到确认</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="416" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="877" />
        <source>Test Alarm</source>
        <translation>测试警报</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="424" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="879" />
        <source>Backend-Controlled Access Warnings</source>
        <translation>后端控制的访问警告</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="428" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="430" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="892" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="894" />
        <source>Loaded after backend authentication</source>
        <translation>后端认证后加载</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="432" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="881" />
        <source>Unknown incoming</source>
        <translation>未知进入</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="433" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="882" />
        <source>Unapproved incoming</source>
        <translation>未批准进入</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="435" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="886" />
        <source>These policies are configured by an administrator. Disabling a warning never disables event upload.</source>
        <translation>这些策略由管理员配置。禁用警告不会禁用事件上传。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="448" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="897" />
        <source>Recording Storage</source>
        <translation>录像存储</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="458" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="904" />
        <source>Leave empty to use the default recording location</source>
        <translation>留空以使用默认录像位置</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="459" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="506" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="906" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="920" />
        <source>Browse...</source>
        <translation>浏览...</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="463" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="900" />
        <source>Recording root</source>
        <translation>录像根目录</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="793" />
        <source>The Guard license key was activated.</source>
        <translation>已激活 Guard 许可证密钥。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="802" />
        <source> — %1 day(s) remaining</source>
        <translation> — 剩余 %1 天</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="804" />
        <source>; expires %1 UTC</source>
        <translation>；到期时间 %1 UTC</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="472" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="517" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="908" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="922" />
        <source>Open Folder</source>
        <translation>打开文件夹</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="473" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="518" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="910" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="924" />
        <source>Restore Default</source>
        <translation>恢复默认</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="590" />
        <source>Backend client unavailable</source>
        <translation>后端客户端不可用</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="598" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="717" />
        <source>Enter a valid HTTP or HTTPS backend URL.</source>
        <translation>请输入有效的 HTTP 或 HTTPS 后端 URL。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="602" />
        <source>Testing...</source>
        <translation>正在测试...</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="612" />
        <source>Connected</source>
        <translation>已连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="620" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="624" />
        <source>Connected; version not reported</source>
        <translation>已连接；未报告版本</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="635" />
        <source>Available space: %1 GB</source>
        <translation>可用空间：%1 GB</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="636" />
        <source>The folder will be validated when settings are saved.</source>
        <translation>保存设置时将验证该文件夹。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="643" />
        <source>Select Recording Root</source>
        <translation>选择录像根目录</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="271" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="837" />
        <source>Diagnostics</source>
        <translation>诊断</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="61" />
        <source>Environment override active: GUARD_RECORDING_ROOT</source>
        <translation>环境变量覆盖已启用：GUARD_RECORDING_ROOT</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="63" />
        <source>Source: %1</source>
        <translation>来源：%1</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="490" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="844" />
        <source>Camera Logging</source>
        <translation>摄像头日志</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="496" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="912" />
        <source>Write each camera's Logs dialog messages to a file</source>
        <translation>将每个摄像头“日志”对话框中的消息写入文件</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="534" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="927" />
        <source>When disabled, camera messages remain available in each Logs dialog for the current session, but no new log files are written. Existing log files are preserved.</source>
        <translation>禁用后，当前会话中的摄像头消息仍可在各自的“日志”对话框中查看，但不会写入新的日志文件。现有日志文件会保留。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="510" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="914" />
        <source>Log folder</source>
        <translation>日志文件夹</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="670" />
        <source>Default application log folder</source>
        <translation>默认应用程序日志文件夹</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="668" />
        <source>Environment override active: GUARD_LOG_ROOT</source>
        <translation>环境变量覆盖已启用：GUARD_LOG_ROOT</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="681" />
        <source>Select Camera Log Folder</source>
        <translation>选择摄像头日志文件夹</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="701" />
        <source>The camera log folder could not be opened.</source>
        <translation>无法打开摄像头日志文件夹。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="272" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="831" />
        <source>License</source>
        <translation>许可证</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="346" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="842" />
        <source>License Information</source>
        <translation>许可证信息</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="370" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="855" />
        <source>Hardware ID</source>
        <translation>硬件 ID</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="365" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="859" />
        <source>Hardware ID unavailable</source>
        <translation>硬件 ID 不可用</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="377" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="856" />
        <source>License key</source>
        <translation>许可证密钥</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="505" />
        <location filename="../src/ui/dialogs/AppSettingsDialog.cpp" line="918" />
        <source>Camera log folder</source>
        <translation>摄像头日志文件夹</translation>
    </message>
</context>
<context>
    <name>CameraDialog</name>
    <message>
        <location filename="../ui/CameraDialog.ui" line="14" />
        <source>Camera Settings</source>
        <translation>摄像头设置</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="58" />
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="66" />
        <source>Hikvision</source>
        <translation>海康威视</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="71" />
        <source>Generic (RTSP)</source>
        <translation>通用 (RTSP)</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="79" />
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="86" />
        <source>Front door</source>
        <translation>前门</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="93" />
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="101" />
        <source>Incoming — enters the room</source>
        <translation>进入 — 进入房间</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="106" />
        <source>Outgoing — leaves the room</source>
        <translation>离开 — 离开房间</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="114" />
        <source>IP Address</source>
        <translation>IP 地址</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="124" />
        <source>SDK Port</source>
        <translation>SDK 端口</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="141" />
        <source>RTSP Port</source>
        <translation>RTSP 端口</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="158" />
        <source>Username</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="165" />
        <source>admin</source>
        <translation>admin</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="172" />
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="186" />
        <source>Channel</source>
        <translation>通道</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="203" />
        <source>Stream</source>
        <translation>码流</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="211" />
        <source>Main Stream</source>
        <translation>主码流</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="216" />
        <source>Sub Stream</source>
        <translation>子码流</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="224" />
        <source>RTSP URL</source>
        <translation>RTSP 地址</translation>
    </message>
    <message>
        <location filename="../ui/CameraDialog.ui" line="231" />
        <source>Optional override, e.g. rtsp://user:pass@host:554/...</source>
        <translation>可选覆盖，例如 rtsp://user:pass@host:554/...</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraDialog.cpp" line="68" />
        <source>Add Camera</source>
        <translation>添加摄像头</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraDialog.cpp" line="218" />
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraDialog.cpp" line="229" />
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraDialog.cpp" line="261" />
        <location filename="../src/ui/camera/CameraDialog.cpp" line="267" />
        <source>Guard</source>
        <translation>Guard</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraDialog.cpp" line="261" />
        <source>Please enter a camera name.</source>
        <translation>请输入摄像头名称。</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraDialog.cpp" line="267" />
        <source>Please enter an IP address or RTSP URL.</source>
        <translation>请输入 IP 地址或 RTSP URL。</translation>
    </message>
</context>
<context>
    <name>CameraGridWidget</name>
    <message>
        <location filename="../ui/CameraGridWidget.ui" line="20" />
        <source>Camera Grid</source>
        <translation>摄像头网格</translation>
    </message>
    <message>
        <location filename="../ui/CameraGridWidget.ui" line="74" />
        <source>No cameras</source>
        <translation>无摄像头</translation>
    </message>
</context>
<context>
    <name>CameraRuntimeController</name>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="221" />
        <source>Decoder error: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="233" />
        <source>Source playback completed.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="243" />
        <source>Onboard capabilities updated. Alarm subscription: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="243" />
        <source>active</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="243" />
        <source>inactive</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="271" />
        <source>Onboard candidate rejected: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="278" />
        <source>Motion recording started: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="280" />
        <source>Motion recording finalized: %1 (%2 packets/frames)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="282" />
        <source>Recording error: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="284" />
        <source>Recording warning: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="295" />
        <source>GuardVision error [%1]: %2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="389" />
        <source>Camera connection settings updated.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="457" />
        <source>Camera log folder could not be applied: %1</source>
        <translation type="unfinished">无法应用摄像头日志文件夹：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="465" />
        <source>Camera log folder updated from Application Settings.</source>
        <translation type="unfinished">已从应用程序设置更新摄像头日志文件夹。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="477" />
        <source>The selected test media file does not exist.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="490" />
        <source>The selected test source must be a JPG, JPEG, PNG, or BMP image.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="496" />
        <source>The selected test source must be an MP4, AVI, MOV, or MKV video.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="510" />
        <source>Test source selected: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="517" />
        <source>Camera IP address is required.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="523" />
        <source>Camera username is required.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="542" />
        <source>A valid rtsp:// URL or camera address is required.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="573" />
        <source>GuardVision is not initialized.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="603" />
        <source>Retained GuardVision face session is already prepared; native face configuration was not reapplied.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="606" />
        <source>Adopted retained GuardVision stream slot: %1 (generation %2)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="623" />
        <source>Reactivating this camera's GuardVision stream: %1 (generation %2)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="692" />
        <source>GuardVision returned an invalid stream generation.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="694" />
        <source>GuardVision stream registration is pending status visibility; the native slot was retained for retry.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="703" />
        <source>GuardVision stream registered: %1 (generation %2)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="740" />
        <source>Invalid source configuration.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="751" />
        <source>Stream registration failed.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="766" />
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="768" />
        <source>The camera source could not be started.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="779" />
        <source>Motion recording enabled. Output: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="781" />
        <source>Encoded recording is waiting for stream information; decoded-frame fallback is available.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="784" />
        <source>Connecting</source>
        <translation>正在连接</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="785" />
        <source>Camera source started.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="920" />
        <source>Disconnected</source>
        <translation>未连接</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1145" />
        <source>Detection settings updated: motion=%1, face=%2, hazard=%3, record=%4</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1149" />
        <source>on</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1149" />
        <source>off</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1153" />
        <source>Per-camera test source updated: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1155" />
        <source>Per-camera test source disabled; configured camera source will be used.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1324" />
        <source>Dropped stale decoded frame: cameraId=%1 expectedGeneration=%2 receivedGeneration=%3 sourceType=%4 mediaPath=%5</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1387" />
        <source>First frame rejected by GuardVision: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1390" />
        <source>Frame submission failed and the camera was stopped: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1430" />
        <source>Dropped stale GuardVision motion event: cameraId=%1 eventGeneration=%2 activeGuardVisionGeneration=%3 eventType=%4</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1443" />
        <source>Motion started.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1448" />
        <source>Motion ended.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1580" />
        <source>Hazard ended.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1585" />
        <source>Smoke ended.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1588" />
        <source>Fire ended.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1608" />
        <source>Fire started.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1610" />
        <source>Smoke started.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1638" />
        <source>Dropped stale GuardVision alarm event: cameraId=%1 eventGeneration=%2 activeGuardVisionGeneration=%3 alarmType=%4 alarmState=%5</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="732" />
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="733" />
        <source>The previous camera session has not stopped safely.</source>
        <translation>上一个摄像头会话尚未安全停止。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="710" />
        <source>Face identification is unavailable. Camera monitoring will continue.</source>
        <translation>人脸识别不可用。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="711" />
        <source>Face identification is unavailable: %1. Camera monitoring will continue.</source>
        <translation>人脸识别不可用：%1。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="304" />
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="438" />
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="466" />
        <source>Camera log file initialized: %1</source>
        <translation>摄像头日志文件已初始化：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="307" />
        <source>Camera file logging could not be initialized: %1</source>
        <translation>无法初始化摄像头文件日志：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="403" />
        <source>Camera renamed from %1 to %2. Previous log file: %3</source>
        <translation>摄像头已从 %1 重命名为 %2。先前的日志文件：%3</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="405" />
        <source>Camera log file changed to: %1</source>
        <translation>摄像头日志文件已更改为：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="407" />
        <source>Camera log file could not be changed after rename: %1</source>
        <translation>重命名后无法更改摄像头日志文件：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="705" />
        <source>Face identification deferred until a room registry is available; detect-and-track remains active.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="724" />
        <source>Camera start requested. Camera: %1; source type: %2</source>
        <translation>已请求启动摄像头。摄像头：%1；源类型：%2</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="725" />
        <source>test media</source>
        <translation>测试媒体</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="741" />
        <source>Camera start failed during source configuration: %1</source>
        <translation>配置源时摄像头启动失败：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="752" />
        <source>Camera start failed during GuardVision stream registration: %1</source>
        <translation>注册 GuardVision 流时摄像头启动失败：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="769" />
        <source>Camera source start failed: %1</source>
        <translation>摄像头源启动失败：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="799" />
        <source>Camera source did not stop safely</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="843" />
        <source>Camera stop requested.</source>
        <translation>已请求停止摄像头。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="921" />
        <source>Camera stopped safely.</source>
        <translation>摄像头已安全停止。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="952" />
        <source>Media decoder worker threads joined for application shutdown.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="959" />
        <source>Motion recording worker joined for application shutdown.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="967" />
        <source>Camera runtime prepared for coordinated application shutdown.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1102" />
        <source>A camera source replacement is already in progress.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1112" />
        <source>Test source replacement started; stopping the current source before reconfiguration.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1117" />
        <source>The current source could not be stopped safely for replacement.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1123" />
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1124" />
        <source>GuardVision did not become idle before source replacement.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1162" />
        <source>Starting the replacement test source after the previous source quiesced.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1166" />
        <source>Test source replacement completed safely.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1197" />
        <source>Face detection is disabled for this camera.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1230" />
        <source>Face identification engine prepared for the room registry.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1240" />
        <source>Face identification preparation failed; detect-and-track remains active: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1277" />
        <source>Face identification results suspended because no active room registry is available; face tracking remains active.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1367" />
        <source>Still-image analytics submission paused after the stable sample window; preview and recording remain active.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1384" />
        <source>First frame accepted by GuardVision. Source: %1; shared frame pipeline active.</source>
        <translation type="unfinished">GuardVision 已接受第一帧。来源：%1；共享帧处理流程已启用。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1717" />
        <source>Still-image face analytics reconnect uses a fresh GuardVision stream; previous stream %1 is retained until application shutdown.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="1790" />
        <source>Camera log file write failed: %1</source>
        <translation>写入摄像头日志文件失败：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="305" />
        <source>Camera log session started. Camera ID: %1</source>
        <translation>摄像头日志会话已开始。摄像头 ID：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="310" />
        <source>Camera file logging is disabled in Application Settings.</source>
        <translation>已在应用程序设置中禁用摄像头文件日志。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="410" />
        <source>Camera renamed from %1 to %2. File logging is disabled.</source>
        <translation>摄像头已从 %1 重命名为 %2。文件日志已禁用。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="419" />
        <source>Camera file logging disabled from Application Settings.</source>
        <translation>已通过应用程序设置禁用摄像头文件日志。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="430" />
        <source>Camera file logging could not be enabled: %1</source>
        <translation>无法启用摄像头文件日志：%1</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="437" />
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="464" />
        <source>Camera file logging enabled from Application Settings.</source>
        <translation>已通过应用程序设置启用摄像头文件日志。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="795" />
        <source>Waiting synchronously for the media source to quiesce.</source>
        <translation>正在同步等待媒体源停止。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="798" />
        <source>Camera source teardown timed out; GuardVision remains registered to avoid a decoder/session race.</source>
        <translation>摄像头源停止超时；为避免解码器与会话竞争，GuardVision 流保持注册状态。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="804" />
        <source>Media source quiesced.</source>
        <translation>媒体源已完全停止。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="823" />
        <source>Asynchronous camera teardown started.</source>
        <translation>已启动异步摄像头清理。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="854" />
        <source>Recording stop requested for source generation %1.</source>
        <translation>已请求停止源代次 %1 的录像。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="856" />
        <source>Media source stop requested.</source>
        <translation>已请求停止媒体源。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="868" />
        <source>Camera source is still stopping after 5 seconds; waiting without unregistering GuardVision.</source>
        <translation>摄像头源在 5 秒后仍在停止；将继续等待且不会注销 GuardVision。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="982" />
        <source>Media source quiesced during controller destruction.</source>
        <translation>控制器销毁期间媒体源已完全停止。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="630" />
        <source>Retained GuardVision stream is no longer available; registering a replacement.</source>
        <translation>保留的 GuardVision 流已不可用；正在注册替代流。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="764" />
        <source>Camera source failed to start; GuardVision stream retained for safe reuse.</source>
        <translation>摄像机源启动失败；GuardVision 流已保留以便安全复用。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="828" />
        <source>Media source was already quiescent; scheduling final camera cleanup.</source>
        <translation>媒体源已经静止；正在安排最终摄像机清理。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="874" />
        <source>Media source quiesced; scheduling final camera cleanup on the next UI turn.</source>
        <translation>媒体源已静止；将在下一次界面事件处理中安排最终摄像机清理。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="908" />
        <source>GuardVision stream retained for safe reconnect; per-stream unregister deferred to application shutdown.</source>
        <translation>GuardVision 流已保留以便安全重连；逐流注销延迟到应用程序关闭时执行。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="989" />
        <source>GuardVision stream retained for coordinated application shutdown.</source>
        <translation>GuardVision 流已保留，将在应用程序协调关闭时释放。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="395" />
        <source>Backend room mapping detached; local camera monitoring remains available.</source>
        <translation>后端房间映射已分离；本地摄像头监控仍可继续。</translation>
    </message>
    <message>
        <location filename="../src/runtime/camera/CameraRuntimeController.cpp" line="396" />
        <source>Backend room mapping attached.</source>
        <translation>后端房间映射已连接。</translation>
    </message>
</context>
<context>
    <name>CameraSettingsDialog</name>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="86" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="248" />
        <source>Camera Settings</source>
        <translation>摄像头设置</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="252" />
        <source>Detection</source>
        <translation>检测</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="118" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="255" />
        <source>Motion detection</source>
        <translation>运动检测</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="119" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="257" />
        <source>Face detection</source>
        <translation>人脸检测</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="120" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="259" />
        <source>Hazard detection</source>
        <translation>危险检测</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="262" />
        <source>Record Video for Motion</source>
        <translation>运动时录制视频</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="264" />
        <source>Test Source</source>
        <translation>测试源</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="270" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="347" />
        <source>Leave empty for configured camera, or select an image/video file</source>
        <translation>留空以使用已配置的摄像头，或选择图片/视频文件</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="272" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="348" />
        <source>Browse...</source>
        <translation>浏览...</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="151" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="267" />
        <source>Media file</source>
        <translation>媒体文件</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="275" />
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="277" />
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="237" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="250" />
        <source>Camera: %1</source>
        <translation>摄像头：%1</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="351" />
        <source>No test file selected. This camera will use its configured camera source.</source>
        <translation>未选择测试文件。此摄像头将使用已配置的摄像头源。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="353" />
        <source>Image mode selected. The image will repeat continuously for this camera.</source>
        <translation>已选择图片模式。图片将在此摄像头上连续重复播放。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="355" />
        <source>Video mode selected. The video will loop through the TestLib-style decoder pipeline.</source>
        <translation>已选择视频模式。视频将通过 TestLib 风格的解码管线循环播放。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="357" />
        <source>Unsupported test file type. Select JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV.</source>
        <translation>不支持的测试文件类型。请选择 JPG、JPEG、PNG、BMP、MP4、AVI、MOV 或 MKV。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="373" />
        <source>Onboard detection becomes available after an HCNetSDK camera connects and its alarm channel is subscribed.</source>
        <translation>HCNetSDK 摄像头连接并订阅报警通道后，机载检测才可用。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="375" />
        <source>Image and video test files support software detection only. Onboard and hybrid modes are unavailable for file sources.</source>
        <translation>图片和视频测试文件仅支持软件检测。文件源不可使用机载和混合模式。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="386" />
        <source>Onboard alarm route is active.</source>
        <translation>机载报警通道已激活。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="389" />
        <source>Software and hybrid hazard detection require models/fire_smoke.onnx beside Guard.exe.</source>
        <translation>软件和混合危险检测需要在 Guard.exe 旁放置 models/fire_smoke.onnx。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="396" />
        <source>Select Test Media</source>
        <translation>选择测试媒体</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="397" />
        <source>Supported Media (*.jpg *.jpeg *.png *.bmp *.mp4 *.avi *.mov *.mkv);;Images (*.jpg *.jpeg *.png *.bmp);;Videos (*.mp4 *.avi *.mov *.mkv);;All Files (*.*)</source>
        <translation>支持的媒体 (*.jpg *.jpeg *.png *.bmp *.mp4 *.avi *.mov *.mkv);;图片 (*.jpg *.jpeg *.png *.bmp);;视频 (*.mp4 *.avi *.mov *.mkv);;所有文件 (*.*)</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="422" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="441" />
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="448" />
        <source>Guard</source>
        <translation>Guard</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="423" />
        <source>Hazard model not found. Copy models/fire_smoke.onnx beside Guard.exe before enabling hazard detection.</source>
        <translation>未找到危险检测模型。启用危险检测前，请将 models/fire_smoke.onnx 复制到 Guard.exe 旁。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="441" />
        <source>Select an existing test media file for this camera.</source>
        <translation>请为此摄像头选择现有的测试媒体文件。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/CameraSettingsDialog.cpp" line="448" />
        <source>The selected test source must be a JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV file.</source>
        <translation>所选测试源必须是 JPG、JPEG、PNG、BMP、MP4、AVI、MOV 或 MKV 文件。</translation>
    </message>
</context>
<context>
    <name>CameraUiModel</name>
    <message>
        <location filename="../src/model/CameraUiModel.h" line="20" />
        <source>Outgoing — leaves the room</source>
        <translation>离开 — 离开房间</translation>
    </message>
    <message>
        <location filename="../src/model/CameraUiModel.h" line="21" />
        <source>Incoming — enters the room</source>
        <translation>进入 — 进入房间</translation>
    </message>
    <message>
        <location filename="../src/model/CameraUiModel.h" line="25" />
        <source>OUT</source>
        <translation>出</translation>
    </message>
    <message>
        <location filename="../src/model/CameraUiModel.h" line="26" />
        <source>IN</source>
        <translation>进</translation>
    </message>
</context>
<context>
    <name>CameraView</name>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="224" />
        <source>No camera</source>
        <translation>无摄像头</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="253" />
        <source>Motion detection</source>
        <translation>运动检测</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="263" />
        <source>Motion %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="263" />
        <source>Motion</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="273" />
        <source>%1 %2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="273" />
        <source>Fire</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="273" />
        <source>Smoke</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="285" />
        <source>UNKNOWN</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="290" />
        <source>OUT</source>
        <translation>出</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraView.cpp" line="290" />
        <source>IN</source>
        <translation>进</translation>
    </message>
</context>
<context>
    <name>CameraWidget</name>
    <message>
        <location filename="../ui/CameraWidget.ui" line="20" />
        <source>Camera Widget</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="116" />
        <location filename="../ui/CameraWidget.ui" line="119" />
        <source>Camera 1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="160" />
        <source>Edit camera</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="163" />
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="182" />
        <source>Remove camera</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="185" />
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="240" />
        <source>Camera View</source>
        <translation>摄像头画面</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="294" />
        <source>Camera status</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="317" />
        <location filename="../src/ui/camera/CameraWidget.cpp" line="340" />
        <source>DISCONNECTED</source>
        <translation>未连接</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraWidget.cpp" line="333" />
        <source>CONNECTED</source>
        <translation>已连接</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraWidget.cpp" line="331" />
        <source>CONNECTING</source>
        <translation>连接中</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraWidget.cpp" line="335" />
        <source>RECONNECTING</source>
        <translation>重连中</translation>
    </message>
    <message>
        <location filename="../src/ui/camera/CameraWidget.cpp" line="337" />
        <source>ERROR</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="385" />
        <source>Open camera settings</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="388" />
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="407" />
        <source>Open camera logs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="410" />
        <source>Logs</source>
        <translation>日志</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="445" />
        <source>Connect camera</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="448" />
        <source>Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="470" />
        <source>Disconnect camera</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/CameraWidget.ui" line="473" />
        <source>Disconnect</source>
        <translation>断开</translation>
    </message>
</context>
<context>
    <name>DetectionModeCombo</name>
    <message>
        <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="15" />
        <source>No detection</source>
        <translation>无检测</translation>
    </message>
    <message>
        <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="16" />
        <source>Software detection</source>
        <translation>软件检测</translation>
    </message>
    <message>
        <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="17" />
        <source>Onboard detection</source>
        <translation>机载检测</translation>
    </message>
    <message>
        <location filename="../src/runtime/ui/controls/DetectionModeCombo.cpp" line="18" />
        <source>Hybrid detection</source>
        <translation>混合检测</translation>
    </message>
</context>
<context>
    <name>GuardBackendClient</name>
    <message>
        <location filename="../src/services/backend/GuardApiError.cpp" line="34" />
        <source>Backend request timed out.</source>
        <translation>后端请求超时。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardApiError.cpp" line="36" />
        <source>Backend request failed (%1).</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardApiError.cpp" line="38" />
        <source>Backend request failed.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="36" />
        <source>Backend URL must not contain embedded credentials.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="40" />
        <source>Enter a valid HTTP or HTTPS backend URL.</source>
        <translation>请输入有效的 HTTP 或 HTTPS 后端 URL。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="136" />
        <source>Environment override: GUARD_API_URL</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="139" />
        <source>Saved application setting</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="141" />
        <source>Development default</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>GuardBackendModels</name>
    <message>
        <location filename="../src/model/GuardBackendModels.cpp" line="173" />
        <source>Backend response is missing installation information.</source>
        <translation>后端响应缺少安装信息。</translation>
    </message>
    <message>
        <location filename="../src/model/GuardBackendModels.cpp" line="183" />
        <source>Backend response is missing room information.</source>
        <translation>后端响应缺少房间信息。</translation>
    </message>
</context>
<context>
    <name>GuardLicenseManager</name>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="97" />
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="153" />
        <source>Hardware ID is unavailable on this computer.</source>
        <translation>此计算机上无法获取硬件 ID。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="105" />
        <source>No Guard license key has been saved.</source>
        <translation>尚未保存 Guard 许可证密钥。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="113" />
        <source>The saved license key is not valid for this hardware ID.</source>
        <translation>已保存的许可证密钥对此硬件 ID 无效。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="121" />
        <source>Permanent Guard license is active.</source>
        <translation>永久 Guard 许可证已激活。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="141" />
        <source>The 7-day temporary Guard license has expired.</source>
        <translation>7 天临时 Guard 许可证已过期。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="144" />
        <source>Temporary Guard license is active.</source>
        <translation>临时 Guard 许可证已激活。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="161" />
        <source>Enter the license key in XXXX-XXXX-XXXX-XXXX format.</source>
        <translation>请以 XXXX-XXXX-XXXX-XXXX 格式输入许可证密钥。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="169" />
        <source>This license key is not valid for this Guard hardware ID.</source>
        <translation>此许可证密钥对此 Guard 硬件 ID 无效。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="174" />
        <source>The temporary 7-day license has expired. Enter a permanent license key.</source>
        <translation>临时 7 天许可证已过期。请输入永久许可证密钥。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="198" />
        <source>The 7-day temporary Guard license has expired. Enter a permanent license key.</source>
        <translation>7 天临时 Guard 许可证已过期。请输入永久许可证密钥。</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="226" />
        <source>Missing</source>
        <translation>缺失</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="228" />
        <source>Temporary 7-day license</source>
        <translation>临时 7 天许可证</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="230" />
        <source>Temporary license expired</source>
        <translation>临时许可证已过期</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="232" />
        <source>Permanent license</source>
        <translation>永久许可证</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="234" />
        <source>Invalid license</source>
        <translation>无效许可证</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="236" />
        <source>Hardware ID unavailable</source>
        <translation>硬件 ID 不可用</translation>
    </message>
    <message>
        <location filename="../src/platform/license/GuardLicenseManager.cpp" line="238" />
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
</context>
<context>
    <name>GuardMessageDialog</name>
    <message>
        <location filename="../src/platform/ui/GuardMessageDialog.cpp" line="111" />
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../src/platform/ui/GuardMessageDialog.cpp" line="112" />
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../src/platform/ui/GuardMessageDialog.cpp" line="120" />
        <source>OK</source>
        <translation>确定</translation>
    </message>
</context>
<context>
    <name>HazardAlarmIndicator</name>
    <message>
        <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="77" />
        <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="210" />
        <source>Hazard alarm active</source>
        <translation>危险警报已激活</translation>
    </message>
    <message>
        <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="203" />
        <source>Fire/smoke alarm</source>
        <translation>火灾/烟雾警报</translation>
    </message>
    <message>
        <location filename="../src/ui/shell/HazardAlarmIndicator.cpp" line="212" />
        <source>Dismiss hazard indicator and alarm</source>
        <translation>关闭危险指示器和警报</translation>
    </message>
</context>
<context>
    <name>LicenseActivationDialog</name>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="205" />
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="255" />
        <source>Guard License</source>
        <translation>Guard 许可证</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="210" />
        <source>Permanent license required</source>
        <translation>需要永久许可证</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="210" />
        <source>Enter Guard license</source>
        <translation>输入 Guard 许可证</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="214" />
        <source>The temporary 7-day license is missing, invalid, or expired. Enter a permanent license key to continue.</source>
        <translation>临时 7 天许可证缺失、无效或已过期。请输入永久许可证密钥以继续。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="215" />
        <source>Copy this hardware ID to LicenseGenerator, then paste the generated Guard license key below.</source>
        <translation>将此硬件 ID 复制到 LicenseGenerator，然后将生成的 Guard 许可证密钥粘贴到下方。</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="218" />
        <source>Hardware ID</source>
        <translation>硬件 ID</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="219" />
        <source>License key</source>
        <translation>许可证密钥</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="222" />
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="224" />
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="224" />
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/LicenseActivationDialog.cpp" line="226" />
        <source>Activate</source>
        <translation>激活</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ui/MainWindow.ui" line="20" />
        <location filename="../src/app/MainWindow.cpp" line="347" />
        <location filename="../src/app/MainWindow.cpp" line="1440" />
        <location filename="../src/app/MainWindow.cpp" line="1709" />
        <location filename="../src/app/MainWindow.cpp" line="1823" />
        <location filename="../src/app/MainWindow.cpp" line="2020" />
        <location filename="../src/app/MainWindow.cpp" line="2058" />
        <location filename="../src/app/MainWindow.cpp" line="2198" />
        <location filename="../src/app/MainWindow.cpp" line="2283" />
        <source>Guard</source>
        <translation>Guard</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="99" />
        <source>Change language</source>
        <translation>切换语言</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="102" />
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="140" />
        <source>Login to room</source>
        <translation>登录房间</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="143" />
        <source>Login to Room</source>
        <translation>登录房间</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="162" />
        <source>Add camera</source>
        <translation>添加摄像头</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="165" />
        <location filename="../src/app/MainWindow.cpp" line="1597" />
        <location filename="../src/app/MainWindow.cpp" line="1607" />
        <location filename="../src/app/MainWindow.cpp" line="1611" />
        <source>Add Camera</source>
        <translation>添加摄像头</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="271" />
        <source>Connection state</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="294" />
        <source>Disconnected</source>
        <translation>未连接</translation>
    </message>
    <message>
        <location filename="../ui/MainWindow.ui" line="332" />
        <source>Open settings</source>
        <translation>打开设置</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="240" />
        <location filename="../src/app/MainWindow.cpp" line="875" />
        <source>GuardVision ready - test mode</source>
        <translation>GuardVision 就绪 - 测试模式</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="240" />
        <location filename="../src/app/MainWindow.cpp" line="876" />
        <source>GuardVision ready</source>
        <translation>GuardVision 就绪</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="241" />
        <source>GuardVision unavailable - test mode</source>
        <translation>GuardVision 不可用 - 测试模式</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="241" />
        <location filename="../src/app/MainWindow.cpp" line="847" />
        <source>GuardVision unavailable</source>
        <translation>GuardVision 不可用</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="347" />
        <source>GuardVision initialization failed: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="468" />
        <source>Backend session authenticated</source>
        <translation>后端会话已认证</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="536" />
        <location filename="../src/app/MainWindow.cpp" line="692" />
        <source>Backend session: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="571" />
        <source>%1 event queued: %2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="575" />
        <source>%1 event rejected: %2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="762" />
        <source>Backend face registry unavailable: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="790" />
        <location filename="../src/app/MainWindow.cpp" line="1003" />
        <source>backend %1</source>
        <translation>后端 %1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1215" />
        <source>Loaded face registry: %1 face(s), %2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1137" />
        <location filename="../src/app/MainWindow.cpp" line="1217" />
        <source>unknown model</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="215" />
        <source>Loading interface...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="220" />
        <source>Initializing GuardVision...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="567" />
        <source>%1 event delivered to backend</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="819" />
        <source>Synchronizing cameras...</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="846" />
        <source>GuardVision is unavailable. Opening in degraded mode.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="872" />
        <source>Room disconnected</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1136" />
        <source>Loaded face registry: 0 face(s), %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1159" />
        <source>Face identification preparation failed: %1. Detect-and-track remains active.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1274" />
        <source>Reused the cached face registry for the restored room connection.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1316" />
        <source>Camera synchronization failed: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1441" />
        <source>You can add up to %1 cameras.</source>
        <translation>最多可添加 %1 个摄像头。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1465" />
        <source>Recording root updated: %1</source>
        <translation>录像根目录已更新：%1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1495" />
        <source>Application settings saved</source>
        <translation>应用程序设置已保存</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1505" />
        <source>Temporary Guard license: %1 day(s) remaining</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1533" />
        <source>Permanent Guard license activated</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1535" />
        <source>Temporary Guard license activated: %1 day(s) remaining</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1611" />
        <location filename="../src/app/MainWindow.cpp" line="1756" />
        <source>The backend did not return a camera ID.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1712" />
        <location filename="../src/app/MainWindow.cpp" line="1948" />
        <source>%1 camera(s) configured</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1722" />
        <location filename="../src/app/MainWindow.cpp" line="1742" />
        <location filename="../src/app/MainWindow.cpp" line="1752" />
        <location filename="../src/app/MainWindow.cpp" line="1756" />
        <source>Edit Camera</source>
        <translation>编辑摄像头</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1790" />
        <source>Camera reconnect failed: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1823" />
        <source>Camera settings could not be applied: %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1841" />
        <source>%1 Logs</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1915" />
        <source>Remove Camera</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1990" />
        <source>Room cameras, streams, and alarms were cleared.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2020" />
        <source>GuardVision is not initialized.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2058" />
        <source>The camera could not be started.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2080" />
        <source>The camera '%1' was created by an older Guard version. Edit it and select Incoming or Outgoing before connecting to a room.</source>
        <translation>摄像头“%1”由旧版 Guard 创建。请先编辑并选择进入或离开方向，再连接房间。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2096" />
        <source>Connecting</source>
        <translation>正在连接</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="552" />
        <location filename="../src/app/MainWindow.cpp" line="2137" />
        <source>Room Connection</source>
        <translation>房间连接</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2139" />
        <source>Select any available room for this Guard computer</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2140" />
        <source>Connect this computer to a backend room</source>
        <translation>将此计算机连接到后端房间</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2147" />
        <source>View room connection status or disconnect</source>
        <translation>查看房间连接状态或断开连接</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2149" />
        <source>%1 — Disconnected</source>
        <translation>%1 — 未连接</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2150" />
        <source>Backend room connection is unavailable</source>
        <translation>后端房间连接不可用</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2284" />
        <source>Guard is still running in the background. Use the tray icon to restore the window.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2079" />
        <source>Camera Direction Required</source>
        <translation>需要设置摄像头方向</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2146" />
        <source>%1 — Connected</source>
        <translation>%1 — 已连接</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2198" />
        <source>Guard - Test Mode</source>
        <translation>Guard - 测试模式</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2208" />
        <location filename="../src/app/MainWindow.cpp" line="2305" />
        <source>Show Guard</source>
        <translation>显示 Guard</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2210" />
        <location filename="../src/app/MainWindow.cpp" line="2307" />
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2217" />
        <source>Switch to %1</source>
        <translation>切换到 %1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="659" />
        <source>Checking backend connection...</source>
        <translation>正在检查后端连接...</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="667" />
        <source>Backend unavailable: %1</source>
        <translation>后端不可用：%1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="671" />
        <source>Backend connection available</source>
        <translation>后端连接正常</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="722" />
        <source>Face registry version unavailable: %1</source>
        <translation>无法获取人脸注册表版本：%1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="744" />
        <source>Face registry is up to date.</source>
        <translation>人脸注册表已是最新版本。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="751" />
        <source>Loading face registry...</source>
        <translation>正在加载人脸注册表...</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="793" />
        <source>Loaded face registry: %1 face(s)</source>
        <translation>已加载人脸注册表：%1 个人脸</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="863" />
        <source>Backend unavailable. Opening in offline mode.</source>
        <translation>后端不可用。正在以离线模式打开。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="864" />
        <source>Backend connection unavailable</source>
        <translation>后端连接不可用</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="888" />
        <source>Backend session unavailable</source>
        <translation>后端会话不可用</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="684" />
        <source>Restoring room connection...</source>
        <translation>正在恢复房间连接...</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="887" />
        <source>Room connection unavailable. Opening in offline mode.</source>
        <translation>房间连接不可用。正在以离线模式打开。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="894" />
        <source>Room session restored.</source>
        <translation>房间会话已恢复。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="706" />
        <source>Checking face registry...</source>
        <translation>正在检查人脸注册表...</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="900" />
        <source>Face registry unavailable. Camera face identification will wait for a successful refresh.</source>
        <translation>人脸注册表不可用。摄像头人脸识别将等待刷新成功后再启动。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="901" />
        <source>Face registry not loaded</source>
        <translation>人脸注册表未加载</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="908" />
        <source>Camera sync incomplete. Local cameras kept.</source>
        <translation>摄像头同步未完成。已保留本地摄像头。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="914" />
        <source>Ready.</source>
        <translation>已就绪。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="915" />
        <source>Guard ready</source>
        <translation>Guard 已就绪</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="916" />
        <source>Guard ready - face registry pending</source>
        <translation>Guard 已就绪 - 等待人脸注册表</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="871" />
        <source>Room disconnected. Backend is available.</source>
        <translation>房间已断开连接。后端可用。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="874" />
        <source>Backend available. No saved room session.</source>
        <translation>后端可用。没有已保存的房间会话。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="799" />
        <location filename="../src/app/MainWindow.cpp" line="1174" />
        <source>Face registry downloaded. Waiting for face identification initialization...</source>
        <translation>人脸注册表已下载，正在等待人脸识别引擎初始化……</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="967" />
        <source>Backend face registry unavailable: %1. Camera monitoring will continue.</source>
        <translation>后端人脸注册表不可用：%1。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="977" />
        <location filename="../src/app/MainWindow.cpp" line="1038" />
        <source>%1 Camera monitoring will continue.</source>
        <translation>%1 摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1029" />
        <source>Face registry version could not be checked. Camera monitoring will continue.</source>
        <translation>无法检查人脸注册表版本。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1089" />
        <source>Face registry is ready and waiting for GuardVision initialization.</source>
        <translation>人脸注册表已准备就绪，正在等待 GuardVision 初始化。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1188" />
        <source>Face registry enrollment failed: %1. Camera monitoring will continue.</source>
        <translation>人脸注册表加载失败：%1。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1238" />
        <source>Face identification is unavailable. Camera monitoring will continue.</source>
        <translation>人脸识别不可用。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1239" />
        <source>Face identification is unavailable: %1. Camera monitoring will continue.</source>
        <translation>人脸识别不可用：%1。摄像机监控将继续运行。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="2040" />
        <source>Camera is starting while face identification is pending.</source>
        <translation>摄像机正在启动，人脸识别仍在准备中。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1856" />
        <source>Log file: %1</source>
        <translation>日志文件：%1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1852" />
        <source>Open Log File</source>
        <translation>打开日志文件</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1853" />
        <source>Open Log Folder</source>
        <translation>打开日志文件夹</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1872" />
        <location filename="../src/app/MainWindow.cpp" line="1876" />
        <location filename="../src/app/MainWindow.cpp" line="1884" />
        <location filename="../src/app/MainWindow.cpp" line="1888" />
        <source>Camera Logs</source>
        <translation>摄像头日志</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1872" />
        <source>The camera log file is not available.</source>
        <translation>摄像头日志文件不可用。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1876" />
        <source>The camera log file could not be opened.</source>
        <translation>无法打开摄像头日志文件。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1884" />
        <source>The camera log folder is not available.</source>
        <translation>摄像头日志文件夹不可用。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1888" />
        <source>The camera log folder could not be opened.</source>
        <translation>无法打开摄像头日志文件夹。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1857" />
        <source>File logging is disabled or the log file is unavailable.</source>
        <translation>文件日志已禁用或日志文件不可用。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1100" />
        <source>Face registry downloaded. Waiting for a camera stream to become active...</source>
        <translation>人脸注册表已下载。正在等待摄像头流激活…</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1551" />
        <source>Camera %1</source>
        <translation>摄像头 %1</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1453" />
        <location filename="../src/app/MainWindow.cpp" line="1731" />
        <source>Camera IP Conflict</source>
        <translation>摄像头 IP 冲突</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1454" />
        <location filename="../src/app/MainWindow.cpp" line="1732" />
        <source>The IP address is already used by '%1'. Enter a different camera IP address.</source>
        <translation>IP 地址已被“%1”使用。请输入其他摄像头 IP 地址。</translation>
    </message>
    <message>
        <location filename="../src/app/MainWindow.cpp" line="1399" />
        <source>Loaded %1 camera(s) for the selected room.</source>
        <translation>已为所选房间加载 %1 个摄像头。</translation>
    </message>
    <message>
        <location filename="../src/app/Main.cpp" line="59" />
        <source>Starting...</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/services/api/FaceRegistryLoader.cpp" line="63" />
        <source>Face registry response is not valid JSON.</source>
        <translation>人脸注册表响应不是有效的 JSON。</translation>
    </message>
    <message>
        <location filename="../src/services/api/FaceRegistryLoader.cpp" line="102" />
        <source>Face registry version response is not valid JSON.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/api/FaceRegistryLoader.cpp" line="108" />
        <source>Face registry version response is missing version.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="55" />
        <source>Backend response is not a JSON object.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="147" />
        <source>Backend URL is controlled by GUARD_API_URL.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="166" />
        <source>Backend URL could not be saved.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>RoomConnectionDialog</name>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="65" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="367" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="422" />
        <source>Room Connection</source>
        <translation>房间连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="76" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="424" />
        <source>Search rooms...</source>
        <translation>搜索房间...</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="111" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="164" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="426" />
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="114" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="428" />
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="115" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="304" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="430" />
        <source>Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="116" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="432" />
        <source>Disconnect Room</source>
        <translation>断开房间连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="117" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="434" />
        <source>Reconnect</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="118" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="436" />
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="164" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="426" />
        <source>Refresh Status</source>
        <translation>刷新状态</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="169" />
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="170" />
        <source>Connected</source>
        <translation>已连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="170" />
        <source>Disconnected</source>
        <translation>未连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="171" />
        <source>Current room: %1
Room ID: %2
Backend URL: %3
Status: %4
Last successful connection: %5</source>
        <translation>当前房间：%1
房间 ID：%2
后端 URL：%3
状态：%4
上次成功连接：%5</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="197" />
        <source>Loading rooms...</source>
        <translation>正在加载房间...</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="210" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="220" />
        <source>Backend unavailable</source>
        <translation>后端不可用</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="233" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="290" />
        <source>No rooms configured</source>
        <translation>未配置房间</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="235" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="343" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="344" />
        <source>No rooms found</source>
        <translation>未找到房间</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="284" />
        <source>Guard Computer</source>
        <translation>Guard 计算机</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="284" />
        <source>%1 Guard</source>
        <translation>%1 Guard</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="304" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="360" />
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="430" />
        <source>Connecting</source>
        <translation>正在连接</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="368" />
        <source>Disconnect this computer from %1?</source>
        <translation>是否从此计算机断开与 %1 的连接？</translation>
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="377" />
        <source>Reconnecting</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/ui/dialogs/RoomConnectionDialog.cpp" line="327" />
        <source>Room disconnected. Select any available room to connect this computer again.</source>
        <translation>房间连接已断开。请选择任意可用房间重新连接此计算机。</translation>
    </message>
</context>
<context>
    <name>SecureCredentialStore</name>
    <message>
        <location filename="../src/platform/security/SecureCredentialStore.cpp" line="52" />
        <source>Credential name is empty.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/platform/security/SecureCredentialStore.cpp" line="66" />
        <source>Windows could not protect the credential (error %1).</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/platform/security/SecureCredentialStore.cpp" line="86" />
        <source>Credential storage failed.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/platform/security/SecureCredentialStore.cpp" line="113" />
        <source>Windows could not read the protected credential (error %1).</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/platform/security/SecureCredentialStore.cpp" line="135" />
        <source>Credential could not be removed.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>WindowTitleBar</name>
    <message>
        <location filename="../src/ui/shell/WindowTitleBar.cpp" line="61" />
        <source>Guard</source>
        <translation>Guard</translation>
    </message>
    <message>
        <location filename="../src/ui/shell/WindowTitleBar.cpp" line="61" />
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="../src/ui/shell/WindowTitleBar.cpp" line="193" />
        <source>Restore</source>
        <translation>还原</translation>
    </message>
    <message>
        <location filename="../src/ui/shell/WindowTitleBar.cpp" line="193" />
        <source>Maximize</source>
        <translation>最大化</translation>
    </message>
</context>
<context>
    <name>guard::alerts::CameraAlarmService</name>
    <message>
        <location filename="../src/services/alerts/CameraAlarmService.cpp" line="20" />
        <location filename="../src/services/alerts/CameraAlarmService.cpp" line="27" />
        <source>This camera does not expose a supported alarm output.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>guard::alerts::LocalAlertService</name>
    <message>
        <location filename="../src/services/alerts/LocalAlertService.cpp" line="200" />
        <source>Access denied. You are not registered in the system.</source>
        <translation>访问被拒绝。您未在系统中注册。</translation>
    </message>
    <message>
        <location filename="../src/services/alerts/LocalAlertService.cpp" line="204" />
        <source>Access denied. You do not have permission to enter this room at this time.</source>
        <translation>访问被拒绝。您当前无权进入此房间。</translation>
    </message>
</context>
<context>
    <name>guard::backend::GuardBackendClient</name>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="319" />
        <source>Backend request URL is invalid.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="389" />
        <source>Backend request could not be created.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="444" />
        <source>Backend request timed out.</source>
        <translation>后端请求超时。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="449" />
        <source>Backend request failed (%1): %2</source>
        <translation>后端请求失败（%1）：%2</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardBackendClient.cpp" line="450" />
        <source>Backend request failed: %1</source>
        <translation>后端请求失败：%1</translation>
    </message>
</context>
<context>
    <name>guard::backend::GuardSessionManager</name>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="102" />
        <source>Installation state could not be saved.</source>
        <translation>安装状态无法保存。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="111" />
        <source>Backend did not return a device credential.</source>
        <translation>后端未返回设备凭证。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="129" />
        <source>Recovery required. This installation already exists and requires credential recovery.</source>
        <translation>需要恢复。此安装已存在，需要恢复凭证。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="152" />
        <source>Backend token response is missing an access token.</source>
        <translation>后端令牌响应缺少访问令牌。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="185" />
        <source>Select a room to reconnect this Guard computer.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="258" />
        <source>Hardware ID is unavailable. Guard cannot resolve a stable backend installation.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="193" />
        <source>Backend session is unavailable.</source>
        <translation>后端会话不可用。</translation>
    </message>
    <message>
        <location filename="../src/services/backend/GuardSessionManager.cpp" line="199" />
        <source>The saved device credential is unavailable.</source>
        <translation>已保存的设备凭证不可用。</translation>
    </message>
</context>
<context>
    <name>guard::events::GuardEventCoordinator</name>
    <message>
        <location filename="../src/services/events/GuardEventCoordinator.cpp" line="443" />
        <source>Backend session is unavailable.</source>
        <translation>后端会话不可用。</translation>
    </message>
</context>
<context>
    <name>guard::events::OfflineEventQueue</name>
    <message>
        <location filename="../src/services/events/OfflineEventQueue.cpp" line="50" />
        <source>Pending event is missing an event ID or endpoint.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/events/OfflineEventQueue.cpp" line="57" />
        <source>Pending event folder could not be replaced.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/events/OfflineEventQueue.cpp" line="62" />
        <source>Pending event folder could not be created.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/events/OfflineEventQueue.cpp" line="74" />
        <source>Pending event image could not be saved.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../src/services/events/OfflineEventQueue.cpp" line="104" />
        <source>Pending event metadata could not be saved.</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>