QT += core gui widgets svg network

qtHaveModule(websockets) {
    QT += websockets
    DEFINES += GUARD_HAS_QT_WEBSOCKETS
}

CONFIG += c++17
TEMPLATE = app
TARGET = Guard

win32-msvc* {
    QMAKE_CXXFLAGS += /std:c++17
    RC_ICONS = resources/icons/guard.ico
}

GUARD_ROOT = $$clean_path($$PWD)

include($$GUARD_ROOT/build/output.pri)
include($$GUARD_ROOT/build/dependencies.pri)
include($$GUARD_ROOT/build/sources.pri)

INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/app \
    $$GUARD_ROOT/src/model \
    $$GUARD_ROOT/src/ui/camera \
    $$GUARD_ROOT/src/ui/dialogs \
    $$GUARD_ROOT/src/ui/shell \
    $$GUARD_ROOT/src/platform/compat \
    $$GUARD_ROOT/src/platform/diagnostics \
    $$GUARD_ROOT/src/platform/i18n \
    $$GUARD_ROOT/src/platform/ui \
    $$GUARD_ROOT/src/services/api \
    $$GUARD_ROOT/src/platform/identity \
    $$GUARD_ROOT/src/platform/license \
    $$GUARD_ROOT/src/platform/security \
    $$GUARD_ROOT/src/services/backend \
    $$GUARD_ROOT/src/services/alerts \
    $$GUARD_ROOT/src/services/events \
    $$GUARD_ROOT/src/runtime \
    $$GUARD_ROOT/src/runtime/app \
    $$GUARD_ROOT/src/runtime/camera \
    $$GUARD_ROOT/src/runtime/ui/controls \
    $$GUARD_ROOT/src/runtime/integration/guardvision \
    $$GUARD_ROOT/src/runtime/media \
    $$GUARD_ROOT/src/runtime/media/common \
    $$GUARD_ROOT/src/runtime/media/recording \
    $$GUARD_ROOT/src/runtime/media/ffmpeg \
    $$GUARD_ROOT/src/runtime/media/file \
    $$GUARD_ROOT/src/runtime/media/rtsp \
    $$GUARD_ROOT/src/runtime/media/hikvision

RESOURCES += $$GUARD_ROOT/resources/resources.qrc

TRANSLATIONS += \
    $$GUARD_ROOT/translations/Guard_zh.ts

guard_zh_qm.target = $$GUARD_ROOT/resources/translations/Guard_zh.qm
guard_zh_qm.depends = $$GUARD_ROOT/translations/Guard_zh.ts
guard_zh_qm.commands = $$[QT_INSTALL_BINS]/lrelease \"$$GUARD_ROOT/translations/Guard_zh.ts\" -qm \"$$GUARD_ROOT/resources/translations/Guard_zh.qm\"
QMAKE_EXTRA_TARGETS += guard_zh_qm
PRE_TARGETDEPS += $$GUARD_ROOT/resources/translations/Guard_zh.qm

win32-msvc* {
    LIBS += Crypt32.lib Winmm.lib User32.lib
}

win32-g++ {
    LIBS += -lcrypt32 -lwinmm -luser32
}
