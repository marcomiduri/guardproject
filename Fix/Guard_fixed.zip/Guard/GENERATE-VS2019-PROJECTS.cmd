@echo off
setlocal
echo Preparing Guard for Visual Studio 2019...
call "%~dp0scripts\prepare-vs-build.cmd" %*
if errorlevel 1 (
    echo.
    echo Failed. Install Visual Studio 2019 with C++ desktop development and Qt 5.14 MSVC 64-bit, then retry.
    exit /b 1
)
echo.
echo Done. Open Guard.sln in Visual Studio 2019.
exit /b 0
