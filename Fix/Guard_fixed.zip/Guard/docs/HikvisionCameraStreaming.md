# Hikvision Camera Streaming in Guard

Guard uses the TestLib-derived HCNetSDK path behind `MediaSourceController`.

For each Hikvision camera, its `CameraRuntimeController` configures an independent `HcNetSdkFrameSource`. The process-wide HCNetSDK lifecycle is reference-counted by `HcNetSdkManager`, while the alarm service routes events by HCNetSDK user ID so up to four camera sessions can coexist.

The source provides:

- login and preview lifecycle;
- PlayCtrl frame decoding;
- reconnect/watchdog behavior;
- camera-specific capability and alarm-subscription state;
- onboard motion, face, fire, and smoke candidates where supplied by the device;
- encoded H.264/H.265 packet forwarding where usable callback data is available;
- decoded RGB frames for preview, GuardVision, and recorder fallback.

Onboard detection options in the camera Settings dialog remain disabled until the selected camera is connected and its alarm route is active. This state is camera-specific and does not alter other camera dialogs.
