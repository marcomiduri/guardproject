> **Superseded:** Runtime testing with four active cameras showed that the first native `GuardVision::unregisterStream()` call can crash inside vendor face-session teardown even after every producer is quiescent. See `RoomDisconnectFourStreamCrashFix.md` for the safe process-lifetime slot-rebinding design.

# Room Switch: Coordinated GuardVision Stream Recreation

## Decision

Guard no longer transfers retained GuardVision stream slots from removed cameras to newly created cameras.
Each `CameraRuntimeController` owns only the stream derived from its camera ID.

An ordinary camera **Disconnect** keeps that controller's stream registered for a fast reconnect. The stream cannot be adopted by another controller.

A camera **Remove** or room **Switch/Disconnect** performs coordinated stream teardown.

## Room-switch sequence

1. `GuardEventCoordinator::setActiveRoomId()` establishes the new room boundary and clears old-room alert state.
2. Guard stops every old-room camera producer and recorder synchronously.
3. Each controller waits until GuardVision reports its stream idle.
4. Guard unregisters every old-room stream, with bounded retries.
5. Only after every unregister succeeds are the old controllers and widgets destroyed.
6. The selected room's camera models are loaded and new controllers are created.
7. A new stream is registered lazily when a new-room camera is connected.

If any unregister fails, Guard aborts workspace replacement and does not create new-room cameras over leaked stream registrations.

## Explicit single-camera removal

Because native face-session teardown previously crashed when another camera was processing, Guard briefly pauses all producers, unregisters the removed camera's stream, and then restarts the other cameras that had been active.

## Alarm behavior

Changing the active room immediately clears hazard audio, hazard indicator timing, active hazard keys, and face-event state. Delayed callbacks are accepted only when their camera's room ID matches the active room.
