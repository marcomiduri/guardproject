# Face Registry / IdentifyEngine Lifecycle Fix

## Reported behavior

During splash startup Guard downloaded the backend registry and immediately
called `GuardVision::setFaceRegistry()`. GuardVision initializes its process-wide
`IdentifyEngine` lazily when the first face-enabled stream is registered. With
no camera stream registered yet, the registry call returned:

```text
Identify engine is not initialized.
```

Guard then treated that registry-only failure as a camera startup failure and
set pending CameraWidgets to `ERROR`.

## Corrected flow

1. Splash restores the backend session and downloads/validates the registry.
2. If `IdentifyEngine` is not initialized, Guard keeps only the newest complete
   registry payload as pending.
3. Camera Connect is allowed immediately; registry availability is not a source
   prerequisite.
4. `CameraRuntimeController` registers the GuardVision stream first. A
   face-enabled registration initializes `IdentifyEngine`.
5. Before the media producer starts, the controller emits
   `guardVisionStreamRegistered` and MainWindow applies the pending registry.
6. Image/video/RTSP/Hikvision playback then starts with the registry already
   available whenever the engine initialized successfully.
7. If the Identify SDK/model pack is unavailable, stream registration retries
   with face analytics disabled. Motion, hazard, playback, and recording remain
   operational and the UI reports a global face-identification warning rather
   than CameraView `ERROR`.

## State separation

The implementation now keeps separate state for:

- GuardVision core availability;
- face-registry synchronization/application;
- CameraRuntimeController source state.

Network errors, invalid registry responses, and IdentifyEngine readiness no
longer directly change a camera tile to `ERROR`.

## Safety behavior

- Pending registry data is scoped to the current room.
- Old-room callbacks are invalidated by existing request serials and the pending
  registry is cleared when the room changes.
- The active registry is committed only after GuardVision accepts the complete
  replacement.
- A failed refresh leaves the previous valid registry active.
- No nested event loop, `processEvents()`, fixed sleep, or UI-thread blocking was
  introduced.

## Changed files

- `src/app/MainWindow.h`
- `src/app/MainWindow.cpp`
- `src/runtime/camera/CameraRuntimeController.h`
- `src/runtime/camera/CameraRuntimeController.cpp`
- `tests/face-registry-lifecycle/verify_source.py`
- `tests/face-registry-lifecycle/README.md`

## Verification

The source-level regression script verifies the lifecycle ordering and failure
classification. Full compilation and runtime validation require Qt 5.x,
GuardVision, and the proprietary Identify SDK on Windows.
