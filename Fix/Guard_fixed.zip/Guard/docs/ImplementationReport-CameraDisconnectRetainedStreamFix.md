# Implementation report — retained GuardVision stream disconnect fix

## Root cause boundary

The supplied Camera 2 log ended at `GuardVision stream unregister started.`
after the media source had already quiesced. This isolates the process
termination to native per-stream GuardVision teardown rather than media,
recording, or UI shutdown.

## Files changed

- `src/runtime/camera/CameraRuntimeController.h`
- `src/runtime/camera/CameraRuntimeController.cpp`
- `tests/camera-disconnect-lifecycle/verify_source.py`
- `tests/camera-disconnect-lifecycle/README.md`
- `docs/CameraDisconnectCrashFix.md`
- `README.md`

## Implementation

- Added explicit retained-stream state and registered generation tracking.
- Normal CameraWidget Disconnect no longer calls per-stream unregister.
- Reconnect validates and reuses the retained GuardVision stream.
- Stale callbacks remain rejected because the active GuardVision generation is
  zero while disconnected.
- Controller destruction drains media but leaves stream release to the shared
  GuardVision shutdown.
- Camera-source startup failure also retains the registered stream rather than
  invoking unsafe native teardown.
- Existing asynchronous producer quiescence and recording-finalization order
  remain unchanged.

## Verification performed

- Camera disconnect lifecycle source regression checks passed.
- Face-registry lifecycle source checks passed.
- Configurable camera file-logging source checks passed.
- Modified source delimiter/preprocessor checks passed.
- XML validation and ZIP integrity checks are performed before packaging.

## Environment limitation

Qt/qmake, the Windows Identify SDK, and the Windows runtime environment are not
available in this container. The full application could not be compiled or
runtime-tested here.
