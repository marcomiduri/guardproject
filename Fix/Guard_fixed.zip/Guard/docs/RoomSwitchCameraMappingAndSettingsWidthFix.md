# Room switch camera mapping and settings width fix

## Room switching

Backend camera IDs are room-specific. The Room Connection dialog can remain open across a disconnect, so its original camera snapshot previously retained the old room's backend IDs. A connection request to a different room therefore supplied stale IDs and the backend rejected the request with `Camera belongs to another room`.

The connection payload now always identifies cameras by stable `clientCameraId` and omits room-specific backend IDs. The dialog also clears its cached backend/room mappings after a successful room disconnect. The backend independently treats a stale ID from the same installation's previous room as historical and creates or finds the selected room's mapping instead of moving the old record.

Historical camera and event rows remain attached to their original room.

## Application Settings width

The dialog minimum width is now 900 px and its initial width is 920 px. The five tab items expand across the available width and tab scroll controls are disabled.

## Scope

No camera runtime, GuardVision, recording, room-session authentication, event delivery, or shutdown logic was changed.
