# Cold-start room event upload fix

## Problem

After Guard started with a saved room session, the UI could show the room as
connected, but face and hazard events were not delivered to the backend until
the operator changed rooms.

## Cause

`GuardSessionManager` loads the saved installation/room state in its constructor.
During cold-start token restoration, it emits `accessTokenAvailable()`, but it
does not emit `sessionChanged()` for the already-saved room.  `MainWindow` only
updated `GuardEventCoordinator::activeRoomId` from `sessionChanged()`, so the
event coordinator still had an empty active room at launch.

With an empty active room, `GuardEventCoordinator::acceptsCameraRoom()` accepts
only local-only cameras.  Backend-mapped cameras have a non-empty `roomId`, so
face and hazard events were ignored before upload.  Changing rooms later emitted
`sessionChanged()`, which finally set the active room and made uploads work.

## Fix

Added `MainWindow::syncEventCoordinatorRoomAssignment()` and call it:

- immediately after creating the event coordinator;
- whenever an access token becomes available;
- after authenticated session restoration;
- when the session changes;
- when starting the backend operational session.

This keeps the event coordinator's active room and backend-assigned flag aligned
with the saved/restored backend session without changing backend API behavior.
