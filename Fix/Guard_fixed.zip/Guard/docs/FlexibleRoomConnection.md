# Flexible room connection

The Guard installation identity belongs to the PC, while the room assignment is changeable.

## Normal flow

1. Initial connect creates one backend installation and one protected device credential.
2. A normal application restart or temporary network outage restores the current room with the existing credential.
3. **Disconnect Room** closes the active assignment, clears the room-scoped JWT and local backend camera mappings, but retains the installation ID, client installation ID, and protected credential.
4. The room dialog immediately returns to the complete room list. The operator may select the previous room or any other available room.
5. The connect request proves the existing PC identity with `installationId + deviceCredential`; the backend keeps the same installation record and opens a new room-assignment history record.
6. Camera mappings, face registry, and notification settings are reloaded for the selected room. Old room cameras and events remain historical records and are never moved.

Administrative revocation is separate from a normal room disconnect.
