# Room connection reconnect and header indicator

## Final behavior

- Room connection requests contain no `hardwareId` or `hardwareIdHash`.
- Guard keeps one stable `clientInstallationId` in `QSettings`.
- The backend installation ID, room metadata, and protected device credential are retained after a normal user-requested disconnect.
- Normal disconnect clears only the in-memory access token and active session state.
- The header shows the saved room as disconnected and the Room Connection dialog offers **Reconnect**.
- Reconnect uses the saved `installationId + deviceCredential`; it does not call the public connect endpoint and does not require administrator recovery.
- Backend camera mappings and local camera configuration are preserved.
- Explicit backend revocation remains a separate security condition and still clears or blocks the session.

Temporary network loss is different from a user-requested disconnect. When the user did not explicitly disconnect, normal startup/session restoration continues to renew the JWT automatically.
