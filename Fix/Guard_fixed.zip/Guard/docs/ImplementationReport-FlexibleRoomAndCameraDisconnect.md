# Implementation Report — Flexible Room Assignment and Safe Camera Disconnect

Date: 2026-07-02

## Scope

- A Guard installation now represents the Guard PC rather than a permanent room binding.
- Deliberate room disconnect preserves `clientInstallationId`, backend `installationId`, and the protected device credential while clearing the active room assignment and JWT.
- The operator can then select any available room, including the previous room, without administrator recovery.
- Room-specific backend camera mappings are cleared locally on room disconnect and recreated/synchronized for the newly selected room.
- Face-registry and notification-setting synchronization runs for the newly connected room.
- CameraWidget disconnect teardown was reordered to quiesce image/video/RTSP/camera producers before unregistering the GuardVision stream.
- Face display names are painted below face rectangles.

## Camera runtime flow reviewed

The preserved flow is:

1. Configure image, video, RTSP, or HCNetSDK source.
2. Start the source generation.
3. Send decoded frames to the CameraView, recorder, and GuardVision through the same per-camera runtime controller.
4. Still images repeat at the existing test cadence; videos continue looping; motion recording keeps its existing encoded-packet/decoded-frame behavior.
5. On disconnect, reject new frames and GuardVision callbacks, finalize the recorder, stop and drain the source, synchronously unregister the GuardVision stream, then clear overlays and runtime state.

The source generation cancellation token also prevents a queued decoder start from beginning after disconnect.

## Verification

- Static source review completed for the room-session, media-source, decoder, recorder, CameraRuntimeController, GuardVision unregister, and CameraView overlay paths.
- The session-response smoke test was updated for authenticated room reassignment.
- Qt/qmake was not available in the execution environment, so the Guard C++ application and smoke tests could not be compiled here.
- GuardVision was inspected as the native analytics dependency. Its synchronous stream-unregister behavior already waits for analytics teardown, so no GuardVision source change was required.
