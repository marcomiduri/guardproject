# Unknown-face still-photo reconnect crash fix

## Problem

Repeated Connect / Disconnect cycles on a test-mode image source that contains an unknown or unregistered face could terminate Guard after the source was restarted several times.

The logs showed that Camera 2 repeatedly reactivated the same retained GuardVision stream for the same static photo:

- `admin.png` selected as an image-file source.
- GuardVision stream registered once.
- Subsequent reconnects reused the same native stream generation.
- The crash occurred after another reconnect submitted the same image into that retained Identify/tracking session.

## Fix

This update keeps the original features enabled and changes only the unsafe lifetime/reconnect behavior:

1. For test-mode image sources with face analytics enabled, each reconnect now uses a fresh GuardVision stream ID instead of reusing the previous native Identify/tracking stream.
2. The previous native stream is retained until process shutdown; it is not unregistered during normal Disconnect, so the known vendor teardown crash path is still avoided.
3. Still-image analytics keeps a short stable sample window, then pauses additional GuardVision submissions while preview and decoded-frame recording remain active.
4. Face and hazard event frames are deep-copied before delayed unknown-face upload / retry paths store them.
5. Windows alert playback uses cached WAV files with `SND_FILENAME | SND_ASYNC` instead of async memory playback.

## Preserved behavior

- Motion recording remains enabled and unchanged.
- Hazard detection and hazard recording remain enabled.
- Face detection/identification remains enabled.
- Unknown-face backend upload remains enabled.
- Local access-denied voice/audio alerts remain enabled.
