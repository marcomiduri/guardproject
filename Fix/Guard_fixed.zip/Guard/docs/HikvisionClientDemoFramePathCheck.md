# Hikvision ClientDemo frame-path check

ClientDemo's normal preview path starts `NET_DVR_RealPlay_V40` with a native window handle and lets HCNetSDK/PlayCtrl render every decoded frame directly.

Guard cannot fully bypass the decoded-frame callback because the same frames are needed for software motion, GuardVision face/hazard analytics, overlays, and decoded-frame fallback recording. The current Guard HCNetSDK path therefore follows the same capture/decode rules while keeping access to decoded frames:

- `NET_DVR_RealPlay_V40` is used for live camera capture.
- The stream is not forced to keyframe/I-frame-only decoding. There is no `PlayM4_SetDecodeFrameType(..., 1)` call in the active Guard capture path.
- `PlayM4_SetStreamOpenMode(..., STREAME_REALTIME)` is used for live preview.
- `PlayM4_SetDecCallBackMend` is used so Guard receives decoded frames for GuardVision, recording, overlays, and backend events.
- The SDK real-data callback copies compressed chunks into a bounded queue and returns quickly. A worker thread feeds PlayM4, so the HCNetSDK callback thread is not blocked by decode/backpressure.
- The conversion path keeps the newest decoded frame and drops stale pending frames if the UI/analytics side is slower than the camera. This keeps preview realtime instead of accumulating seconds of latency.

Conclusion: the old 2-3 seconds per rendered frame issue caused by I-frame-only decoding is not present in this source package. Guard should decode full frame-rate video like ClientDemo, with the expected extra CPU cost of software analytics and Qt overlay rendering.
