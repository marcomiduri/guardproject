# Task 8 Camera Synchronization Verification

## Scope

Task 8 makes backend camera records authoritative for backend communication while preserving Guard local runtime settings and stable GuardVision stream identity.

## Implemented behavior

| Requirement | Implementation |
|---|---|
| Activation camera submit | `GuardSessionManager::activate()` sends local cameras with `clientCameraId` |
| Idempotent mapping | Backend upserts on `(installationId, clientCameraId)`; Guard applies mappings in `applyActivationCameraMappings()` |
| Post-auth sync | `MainWindow::syncCamerasFromBackend()` calls `GET /api/guard/cameras` |
| Canonical ID parsing | `backendCameraIdFromApiJson()` accepts `id` or `backendCameraId` |
| Partial merge | `cameraFromApiJson()` updates only keys present in the payload; password and connection fields are preserved when omitted |
| Sync matching | `findCameraForBackendRecord()` matches `backendCameraId`, then `clientCameraId`, then legacy `id == backendId` |
| Registered add/edit | Backend create/patch first; local tile created only when a backend ID is returned |
| Registered remove | Backend delete first, then local removal |
| Heartbeats | `POST /api/guard/cameras/{backendCameraId}/heartbeat` with `status` and `occurredAt`; skipped when unmapped |
| Events | Face/hazard uploads use `eventCameraId()` (backend ID only for registered rooms); local overlay dedupe uses `localFaceTrackCameraKey()`; room-registered cameras without a backend ID are skipped |
| Stream safety | `cameraConnectionFieldsEqual()` limits stop/reconnect to connection-field changes; metadata sync keeps active streams running |
| Local-only settings | Detection, recording, and test-source settings remain in `CameraRuntimeController` |
| Four-camera limit | UI grid limit and backend room limit both enforce four cameras |
| Retry-safe create | Backend `POST /api/guard/cameras` uses `upsertForInstallation()` for JWT installations |

## Automated check

```bat
cd Desktop\Guard\tests\camera-sync
mkdir build
cd build
qmake ..\camera-sync-smoke.pro CONFIG+=release
nmake release
release\guard-camera-sync-smoke.exe
```

The smoke test verifies:

- `id` and `backendCameraId` parsing;
- partial JSON merge preserving local connection fields;
- connection vs metadata field detection;
- registered-camera backend ID requirements for events.

## Build regression note

Guard Release was rebuilt after these changes. Synchronizing backend-managed name or direction fields no longer disconnects an active stream unless connection fields changed.
