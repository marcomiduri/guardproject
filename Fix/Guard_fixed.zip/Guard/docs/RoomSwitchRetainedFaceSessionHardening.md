# Room-switch retained face-session hardening

## Confirmed crash boundary

After a room switch, a new camera controller adopted a process-lifetime GuardVision stream slot and reactivated it. The process terminated before motion recording setup or camera-source startup. The configured Hikvision source was therefore not the crash origin.

## Root cause

The controller tracked room-registry intent and native Identify-session readiness with the same boolean. A restored controller could receive registry synchronization before its retained stream became active, incorrectly mark the native session prepared, and then re-enter `setFaceConfig()` during retained-slot adoption. The vendor face-session transition is unsafe when repeated on the process-lifetime slot.

## Changes

- Separate registry intent from confirmed native Identify-session state.
- Never call `setFaceConfig()` while adopting a retained stream slot.
- Synchronize a cached room registry from the direct `guardVisionStreamRegistered` callback, after the stream is active and before media startup.
- Commit `nativeFaceIdentificationPrepared_` only after `setFaceConfig()` succeeds.
- Remove the second rollback/retry `setFaceConfig()` call after preparation failure.
- Preserve camera startup when face identification cannot be prepared; detect-and-track remains available.

## Verification

`tests/retained-face-session-idempotence/verify_source.py` verifies the state separation, zero native face transitions during adoption, single-call preparation, post-success state commit, and active-stream registry synchronization.
