# Guard final diagnostics and camera-pipeline implementation report

## Baseline and scope

This work was applied to the stable Guard baseline that had already passed the field crash tests. The update intentionally leaves the following unchanged:

- GuardVision ownership and retained-stream behavior;
- camera Connect/Disconnect sequencing;
- source-generation and stale-callback protection;
- room disconnect/reconnect behavior;
- face, motion, and hazard event state machines;
- backend event delivery and offline queue behavior;
- recording worker ownership;
- tray and application shutdown behavior.

## 1. Configurable camera log folder

Application Settings -> Diagnostics now provides an editable **Log folder** field with:

- Browse;
- effective-path preview;
- configuration-source display;
- Open Folder;
- Restore Default.

The selected path is stored in `QSettings` as `diagnostics/cameraLogDirectory`. The resolution order is:

1. `GUARD_LOG_ROOT` environment override (`<root>/cameras`);
2. saved Diagnostics log folder;
3. the existing application-local default (`AppLocalDataLocation/logs/cameras`).

Before saving, Guard creates the selected directory when needed and verifies that it is writable. If the environment override is active, the field is read-only.

Existing camera controllers reload only their file-logging destination after settings are accepted. Camera playback, recording, GuardVision processing, and event handling are not stopped or reconfigured. A new file is opened before the old logger is replaced; if the new file cannot be opened, the existing log file remains active.

## 2. Normal-camera and test-media frame-path verification

The source adapters remain independent because their decoder/SDK lifecycles differ, but all decoded frames converge through the same signal and handler:

```text
Image/video file decoder ----\
RTSP decoder -----------------+-> MediaSourceController::frameReadyForSubmission
HCNetSDK camera source -------/             |
                                              v
                              CameraRuntimeController::handleDecodedFrame
                                              |
              +-------------------------------+------------------------------+
              |               |               |                              |
          CameraView     frame cache    decoded recording          GuardVision submission
                                                                          |
                                                        motion / face / hazard events
                                                                          |
                                                         overlays, alarms, backend events
```

The shared handler is not conditional on `--test`. Normal RTSP and HCNetSDK cameras therefore receive the same preview, event-snapshot cache, decoded recording fallback, GuardVision submission, local overlay, alarm, and backend-event processing used by test image/video sources.

HCNetSDK onboard candidates remain optional hints for `OnboardTriggered` and `Hybrid` modes. They supplement decoded-frame submission and do not replace it.

## 3. Conservative cleanup

The cleanup was deliberately limited to behavior-neutral changes:

- replaced an unnecessary forwarding lambda with a direct signal-to-member connection;
- made still-image pacing depend on the actual active media-source type instead of the `--test` flag;
- added one idempotent method for reloading file-logging settings;
- centralized log-directory resolution and validation in `CameraFileLogger`;
- added focused source-regression checks and documentation.

No architecture, ownership model, shutdown sequence, camera lifecycle, analytics state machine, or backend logical flow was redesigned.

## Validation

The complete source-verification suite passed, including:

- camera disconnect/reconnect lifecycle;
- source replacement lifecycle;
- frame-sequence continuity;
- room reconnect and cached face-registry handling;
- startup-restored backend event delivery;
- hazard reconnect incident behavior;
- tray startup and shutdown checks;
- configurable camera-file logging;
- normal camera/test-media common frame pipeline.

The Python verification scripts compile successfully, and both translation TS files parse as valid XML.

A native Qt/qmake build could not be executed in the available environment because the Qt 5 toolchain and proprietary Windows camera/GuardVision dependencies are not installed. Final Windows verification should use a clean qmake build and test both RTSP and HCNetSDK cameras with motion, face, hazard, recording, and backend event delivery enabled.
