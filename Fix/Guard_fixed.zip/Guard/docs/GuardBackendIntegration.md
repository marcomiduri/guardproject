# Guard Backend Integration — Transitional No-Licensing Build

## Scope

Guard keeps camera decoding, GuardVision analytics, recording, overlays, and local
alarms independent from backend availability. Commercial product licensing and
backend trial/entitlement handling are intentionally absent in this build.

The backend remains authoritative for:

- Guard installation and room assignment;
- device credentials, short-lived JWTs, and installation revocation;
- canonical camera IDs and direction;
- face-registry contents and version;
- room orders and incoming access decisions;
- notification-policy settings;
- event persistence, occupancy, and realtime fan-out.

Guard remains authoritative for:

- camera connections and per-camera runtime state;
- GuardVision processing and CameraView overlays;
- motion recording;
- PC alarms and access-warning audio;
- snapshot rendering and persistent offline event delivery.

## Application Settings

The footer Application Settings dialog contains:

1. **Server** — backend URL, source, asynchronous health test, and version.
2. **Alerts** — local hazard alarm and effective backend warning policies.
3. **Recording** — recording-root selection and storage status.

There is no License tab.

## Registration and session

Guard currently sends `roomIdentifier`, `activationCode`, `hardwareId`,
`deviceName`, `guardVersion`, and local camera descriptors to
`POST /api/guard/installations/activate`. The response supplies installation/room
identity, a one-time device credential, and camera mappings. Guard protects the
device credential and exchanges it for short-lived JWTs through
`POST /api/guard/auth/token`.

The activation response and token response contain no commercial entitlement object,
and Guard ignores obsolete entitlement fields if an older backend includes them.
The room activation-code field remains temporarily in the desktop registration flow
until the replacement enrollment model is implemented. The web frontend no longer
contains activation-code administration.

## Hardware identity

The registration Hardware ID is a stable, formatted hash of normalized Windows
MachineGuid and ProcessorId. It is an installation identity, not a product license.
Raw hardware components are not persisted or logged.

## Operational behavior

Once authenticated, Guard synchronizes camera mappings, sends camera and installation
heartbeats, refreshes the face registry and notification settings, uploads face and
hazard events, and retries retryable failures with stable event IDs. Backend failures
never stop local monitoring or local alarms.
