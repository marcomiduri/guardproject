# Room-switch stream recreation and hazard reset fix

## Symptoms

After switching rooms and repeatedly removing/restoring cameras, a newly added camera could fail when starting an image or video source with:

`Maximum stream count reached.`

The visible room could still have fewer than four camera widgets. Hazard sound and the red header indicator from the previous room could also remain after the room workspace changed.

## Superseded retained-slot approach

An earlier patch tried to avoid native per-stream teardown by transferring inactive GuardVision stream slots between removed and replacement camera controllers. Although it prevented some registrations, it introduced cross-controller ownership and slot-pool bookkeeping that could still become inconsistent.

That approach has been removed.

## Current stream lifecycle

Each `CameraRuntimeController` owns only the GuardVision stream derived from its camera ID.

- Ordinary **Disconnect/Connect** may reactivate the same controller-owned stream.
- A stream is never adopted by another camera controller.
- Explicit camera removal briefly stops all active camera producers, releases the removed camera's stream, and restarts the other cameras.
- Room switch/disconnect stops every old-room producer first, waits for GuardVision stream idleness, unregisters every old-room stream, and only then destroys old controllers.
- New-room controllers register new streams lazily on first Connect.
- Unregister is retried with bounded waits.
- If an old-room stream cannot be safely released, Guard aborts workspace replacement instead of creating new cameras over leaked registrations.

The detailed sequence is documented in `RoomSwitchCoordinatedStreamRecreation.md`.

## Hazard/alarm room ownership correction

The event coordinator tracks the active room ID, not only the connected/disconnected boolean.

When the active room changes:

- face-track, hazard-upload, and active-incident state are cleared;
- all local hazard occurrences are removed;
- the repeating PC alarm is stopped immediately;
- any currently playing Windows alarm sound is stopped;
- the one-minute hazard indicator presence is cleared immediately;
- queued face or hazard callbacks from cameras whose `roomId` does not match the active room are rejected.

When Guard is not connected to a room, only local cameras with an empty `roomId` are accepted, so stale callbacks from the previous backend room cannot recreate its alarm.

## Verification

All 21 source-verification suites pass. The revised checks require coordinated old-room unregister, removal of the cross-camera slot pool, camera-derived stream ownership, abort-on-release-failure behavior, and the existing hazard/face room boundary protections.
