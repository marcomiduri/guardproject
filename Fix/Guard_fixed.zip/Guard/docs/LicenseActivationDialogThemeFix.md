# License Activation Dialog Theme Fix

## Summary

Updated the Guard license activation dialog shown when a missing, invalid, or expired license requires user action.

## Changes

- Replaced the plain platform `QDialog` layout with the same frameless midnight modal shell used by Guard dialogs.
- Added the shared `WindowTitleBar` dialog title bar.
- Added the same panel frame, border, rounded mask, footer separator, and drop shadow behavior used by Camera, Room, Message, and Application Settings dialogs.
- Reused Guard theme colors, line-edit styling, and dialog-button styling.
- Kept the existing license behavior unchanged:
  - Hardware ID copy still works.
  - License key format remains `XXXX-XXXX-XXXX-XXXX`.
  - Temporary-expired state still requires a permanent key.
  - Closing the dialog in permanent-required mode still causes the main app to exit through the existing caller logic.

## Files Updated

- `src/ui/dialogs/LicenseActivationDialog.h`
- `src/ui/dialogs/LicenseActivationDialog.cpp`
- `resources/styles/camera-dialog.qss`

## Compatibility

The implementation uses the same Qt 5-compatible widgets and styling patterns already used elsewhere in Guard.
