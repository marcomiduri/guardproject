# Room-Owned Camera Workspace, IP Conflict Validation, and Themed Dialogs

## Scope

This document originally described the room workspace change before coordinated stream recreation was introduced. The current camera and room lifecycle is defined by `RoomSwitchCoordinatedStreamRecreation.md`; IP-conflict and themed-dialog behavior below remains current.

## Room-owned camera workspace

The visible CameraWidget collection now represents the currently connected room only.

- On successful room disconnect, Guard stops all camera producers, unregisters every room stream, and then removes the current camera tiles.
- The Room Connection dialog clears the previous room camera snapshot before another room is selected.
- After authentication, `GET /api/guard/cameras` is treated as the authoritative camera list for the selected room.
- Camera tiles not present in the selected room are removed.
- Existing matching tiles are updated and missing tiles are created.
- Old-room GuardVision streams are not reused by new controllers. New streams are registered lazily when cameras in the selected room are connected.

Example:

- Room A has three cameras: connecting to Room A shows three tiles.
- Switching to Room B removes Room A's tiles and loads Room B's two tiles.
- Switching back removes Room B's tiles and restores Room A's three tiles.

## Camera default name

When adding a camera, the Camera dialog receives:

`Camera {current visible camera count + 1}`

Editing an existing camera does not overwrite its name.

## IP conflict validation

Guard checks the normalized camera IP before local add or edit:

- Direct camera addresses are compared case-insensitively.
- For RTSP-only cameras, the RTSP URL host is used.
- IPv4 and IPv6 literals are normalized with `QHostAddress`.
- Editing excludes the camera currently being edited.

The backend repeats the validation for create, update, room-connect, and activation payloads, preventing duplicate camera IPs within one room even when requests bypass the desktop UI.

## Themed message dialogs

All legacy `QMessageBox` calls were replaced by `GuardMessageDialog`.

The new dialog reuses the Camera dialog's:

- frameless title bar;
- background and border colors;
- content and footer selectors;
- button styling;
- corner radius and drop shadow.

Information, warning, and confirmation variants share the same visual language.

## Compatibility

- Qt 5.7-compatible APIs only.
- Camera workers remain owned by their individual controllers.
- Room changes use the coordinated GuardVision stream-release barrier.
- No recording changes.
- No event-upload changes.
- No frontend production-code changes were required.
