# Room reconnect and disconnected monitoring crash fix

## Symptoms

1. After all camera tiles were disconnected, leaving a room and reconnecting to it could terminate Guard during backend camera/face-registry synchronization.
2. Starting a test image while Guard was intentionally unassigned from a room could terminate the application when the first face or hazard event attempted backend delivery.

## Corrections

- Backend face and hazard events now require a canonical `backendCameraId`; local/client IDs are never sent to backend event endpoints.
- The event coordinator has an explicit room-assignment gate. Deliberately unassigned operation keeps local overlays, alarms, playback, recording, motion, face, and hazard analytics active without issuing backend event requests.
- Event state and old-room callbacks are invalidated on room transitions.
- A downloaded face registry is not applied while every GuardVision stream is retained and inactive. It remains pending and is applied when the next camera stream becomes active, before media playback starts.
- Backend synchronization no longer deletes local camera controllers for missing/stale room mappings. It detaches the backend mapping and preserves the local camera/runtime. This avoids unsafe native per-stream teardown during room reconnect.

The established per-camera Connect/Disconnect flow and coordinated application shutdown are unchanged.
