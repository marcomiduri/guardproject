# Room Switch Debug Heap Hardening

## Problem

Repeated room switches in a Debug build could still trigger the Microsoft CRT
heap assertion:

```
is_block_type_valid(header->_block_use)
```

The latest field logs showed the assertion while all camera tiles were loaded but
no camera source was active. The logs also showed pending face-registry state and
new camera controllers being created shortly after old camera controllers were
stopped and destroyed.

## Root-cause hardening

This pass removes two remaining lifetime risks during room switch:

1. **Fresh controllers no longer use stable GuardVision stream IDs.**
   A new `CameraRuntimeController` now receives a unique stream ID based on the
   camera ID plus a short per-controller UUID suffix. This prevents a newly
   created controller from accidentally adopting a process-lifetime native stream
   left by an older controller with the same camera ID after returning to a room.

2. **Fresh controller stream adoption is gated.**
   `registerStream()` only adopts an existing native stream when the controller
   was explicitly constructed with a retained stream ID. Normal room-load/new-tile
   controllers do not adopt old native slots.

3. **Camera grid animations stay enabled for manual add/remove only.**
   Bulk room teardown and backend camera sync still lay out tiles synchronously.
   This keeps delayed QObject/QPropertyAnimation target deletion out of bulk
   room-camera teardown and reload while preserving resize transitions when the
   user adds or removes a camera.

## Preserved behavior

- UI still limits active camera tiles to 4.
- Normal camera connect/disconnect logic is unchanged.
- Backend room, face, hazard, and event upload logic is unchanged.
- GuardVision streams are still retained for safe same-controller disconnect, but
  a destroyed controller does not donate its stream to a later room-load tile.
