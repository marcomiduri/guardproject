# Hikvision Full-Frame Decode Fix

Removed `PlayM4_SetDecodeFrameType(newPort, 1)` from `HcNetSdkFrameSource::openPlayStream()`.

That call limited decoded output on real Hikvision streams and could make Guard receive only keyframes / I-frames, which appears as roughly one rendered frame every 2-3 seconds depending on camera GOP settings. Guard now lets PlayM4 decode all display frames for the callback pipeline.
