# Stable baseline startup event delivery and room reconnect fix

## Baseline

This change is intentionally based on the uploaded Guard source that already had the proven camera source, CameraWidget disconnect/reconnect, source replacement, and tray-exit crash fixes.

No GuardVision public API or library behavior was changed.

## Issue 1: events missing after a connected cold launch

Cold-start session restoration calls `GuardSessionManager::refreshAccessToken()` with a completion callback. The previous implementation emitted `authenticated()` only when no callback was supplied. As a result, the JWT was restored successfully, but `GuardEventCoordinator` remained in its initial `backendRoomAssigned=false` state. Local detection worked while face and hazard event uploads were skipped until a manual room reconnect changed the state.

### Fix

`GuardSessionManager` now emits `accessTokenAvailable()` after every successful token response, before callback-specific completion handling. `MainWindow` uses this signal to mark backend event delivery ready only when the installation has a room and a live access token.

The existing `authenticated()` signal retains its original responsibility for starting the complete operational backend session when no explicit completion callback is in use.

## Issue 2: crash reconnecting the room while cameras remain active

A normal room disconnect correctly kept camera sources and retained GuardVision streams alive, and Guard masked identified faces as Unknown. However, it also discarded Guard's active face-registry state. Reconnecting to the same room downloaded and enrolled the same registry again while native face processing was active. That re-entry into the vendor registry/session path caused the crash.

### Fix

A normal room disconnect is now treated as a logical authorization boundary:

- invalidate old backend registry requests;
- disable backend event delivery;
- mark the event coordinator registry unavailable;
- mask local identity information;
- preserve the already-enrolled native registry and Guard's cached registry metadata.

When the same room reconnects:

- reuse the cached room registry;
- restore Guard identity-name mapping;
- restore unknown/recognized event decisions;
- do not call `GuardVision::setFaceRegistry()`;
- do not call `setFaceConfig()` again when the camera's native identification mode is already prepared.

The backend version check still runs. When the server reports the same registry version, it confirms and reuses the cached registry without native reconfiguration.

## Files changed

- `src/services/backend/GuardSessionManager.h`
- `src/services/backend/GuardSessionManager.cpp`
- `src/app/MainWindow.h`
- `src/app/MainWindow.cpp`
- `src/runtime/camera/CameraRuntimeController.cpp`
- `tests/startup-event-session/*`
- `tests/room-reconnect-cached-registry/*`
- `tests/room-reconnect-lifecycle/verify_source.py`

## Runtime verification

1. Start Guard while it already has a saved connected room session.
2. Start a CameraWidget with a face/hazard test source.
3. Verify face and hazard records arrive at the backend/frontend without manually reconnecting the room.
4. Keep one or more cameras playing.
5. Disconnect the room. Verify face overlays become Unknown and local monitoring continues.
6. Reconnect the same room. Verify Guard remains running and identified names/backend events resume.
7. Repeat room disconnect/reconnect at least 20 times with multiple active cameras.
