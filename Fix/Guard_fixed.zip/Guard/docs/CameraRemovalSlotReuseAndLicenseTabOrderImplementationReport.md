# Camera Removal Stream-Slot Reuse and License Tab Order

> **Historical note:** The cross-camera retained-stream slot pool described below has been superseded by `RoomSwitchCoordinatedStreamRecreation.md`. Current Guard stops all relevant producers and unregisters removed/old-room streams before creating replacement controllers.


## Baseline

This update is based on the last working Guard source containing the room-switch camera-mapping and Application Settings width fixes.

## Issue 1: replacement cameras reached the GuardVision limit

The stable Guard lifecycle deliberately does not call `GuardVision::unregisterStream()` during ordinary camera disconnect or controller destruction because native per-stream teardown caused Windows crashes while other cameras remained active. Consequently, explicitly removing a configured camera removed the UI tile and controller but left its GuardVision stream registered until application shutdown. Adding replacement cameras then attempted to register additional streams and eventually returned `Maximum stream count reached.`

### Fix

- `MainWindow` keeps a process-local pool of inactive GuardVision stream slots from explicitly removed cameras.
- Camera removal first stops the source synchronously using the existing proven stop path.
- The retained stream ID, native face-identification preparation state, and next frame sequence/timestamp cursor are captured before controller destruction.
- A newly added camera receives one pooled stream slot when available.
- `CameraRuntimeController` probes the retained stream with `getStreamStatus()` and adopts it instead of registering another stream.
- The prior frame cursor is restored so the first replacement-camera frame cannot regress below the stream's previous accepted sequence.
- An already-prepared native Identify session is preserved and is not downgraded or redundantly reconfigured.
- No per-camera `unregisterStream()` call was reintroduced.

The visible configured-camera maximum remains four. Repeated remove/add cycles now recycle those four process-lifetime GuardVision slots rather than consuming new ones.

## Issue 2: License tab order

Application Settings tabs are now ordered:

1. Server
2. Alerts
3. Recording
4. Diagnostics
5. License

The License tab index constants and dynamic retranslation logic were updated consistently.

## Scope protection

No changes were made to:

- GuardVision library code;
- backend camera deletion or room mapping;
- camera source decoding;
- recording ownership;
- face/hazard event flow;
- room connection behavior;
- tray shutdown behavior;
- the proven retained-stream architecture.

## Verification

- All Guard Python source verification scripts passed.
- Added `tests/camera-slot-reuse/verify_source.py` for removed-slot recycling, face readiness, and frame-sequence continuity.
- Updated Application Settings verification to require License as the last tab.
- Python verification scripts compile successfully.
