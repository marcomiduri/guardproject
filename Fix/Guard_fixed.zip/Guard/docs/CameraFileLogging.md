# Per-camera persistent file logging

## Purpose

Each camera already owns an independent in-memory log buffer shown by the **Logs** button in its `CameraWidget`. The same timestamped entries are now appended to a persistent file so camera startup, decoder, GuardVision, recording, and teardown failures can be inspected after an unexpected application crash.

## File location

The default directory is:

```text
QStandardPaths::AppLocalDataLocation/logs/cameras
```

On Windows this resolves below the current user's local application-data directory.

The operator can choose another folder under **Application Settings → Diagnostics → Log folder**. The selected folder is validated and persisted in `QSettings` under:

```text
diagnostics/cameraLogDirectory
```

An empty saved value restores the default application-local folder. The Diagnostics tab also displays the effective path and provides **Open Folder** and **Restore Default** actions.

An optional environment override remains supported:

```text
GUARD_LOG_ROOT=<diagnostic-root>
```

When set, camera logs are written under:

```text
<diagnostic-root>/cameras
```

The environment override has higher priority than the saved setting, and the log-folder field is read-only while the override is active.

## Enable or disable file logging

Open **Application Settings → Diagnostics** and use:

```text
Write each camera's Logs dialog messages to a file
```

The setting is enabled by default to preserve the existing diagnostic behavior. Saving the setting applies it immediately to every existing camera and is also used by cameras created later and after application restart.

When file logging is disabled:

- The per-camera **Logs** dialog and its in-memory messages remain available.
- Existing log files are preserved.
- The current file is flushed and closed.
- No new camera log lines are written to disk.
- Camera playback, GuardVision processing, recording, alarms, and backend communication are unchanged.

Re-enabling the setting opens the file for the camera's current display name and resumes immediate flushing.

Changing the folder applies immediately to existing camera controllers. Each controller opens its new file before closing the previous one; if the new file cannot be opened, the existing file remains active and the error stays visible in the in-memory Logs dialog.

## File naming

The normal filename is the camera display name plus `.log`, for example:

```text
Front Entrance.log
```

Characters that Windows does not permit in filenames are replaced with `_`, trailing spaces and periods are removed, and reserved device names are prefixed with `_`. If two active cameras have the same sanitized name, a short stable camera-ID suffix prevents their entries from being mixed.

When a camera is renamed, the previous file remains untouched for audit purposes and new entries are written to a file matching the new camera name.

## Durability and behavior

- Entries are UTF-8 text with local timestamps matching the Logs dialog.
- Every line is flushed immediately after writing.
- File-I/O failures do not change camera state or stop camera processing.
- A file-I/O failure is added once to the in-memory log so it remains visible in the Logs dialog.
- The existing 1,000-entry in-memory limit remains unchanged; the persistent file is not truncated when the dialog buffer rolls over.
- Camera connect, source-configuration failure, GuardVision stream-registration failure, source-start failure, stop request, and successful stop are explicitly logged.
- The Logs dialog displays the exact path and can open either the file or its containing folder.
- When file logging is disabled, the Logs dialog clearly reports that no active file is available while continuing to show in-memory messages.

## Security

The file logger writes only messages already routed through `CameraRuntimeController::appendLog()`. New logging must not add camera passwords, JWTs, device credentials, license keys, raw face embeddings, or other secrets.

## Logical-flow preservation

File logging is observational only. Failure to create, write, or flush a log file never changes the camera source, GuardVision stream, motion recording, face processing, hazard processing, connect/disconnect ordering, or CameraView status.
