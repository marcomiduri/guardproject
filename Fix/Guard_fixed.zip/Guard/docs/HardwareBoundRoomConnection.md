# Hardware-bound room connection

Guard now sends the stable hardware ID when connecting to a backend room.

## Guard behavior

`GuardSessionManager` includes `hardwareId` in:

- `/api/guard/installations/connect`
- `/api/guard/auth/token`

If a local installation ID exists but the protected device credential was lost by rebuild/reinstall, Guard still connects with `hardwareId`. The backend resolves the same physical computer to the same canonical `installationId` and returns a fresh device credential.

## Why

This removes the fragile local `clientInstallationId` concept and prevents reinstall/rebuild from creating a new backend installation identity for the same PC.

```text
same physical Guard PC
→ same hardwareId
→ same backend installationId
→ same original room/camera mapping
```
