# Implementation report — per-camera persistent logs

## Scope

Implemented persistent file logging for every `CameraRuntimeController` without changing camera connection, media playback, GuardVision, recording, face, hazard, room, or teardown logic.

## Changed files

- `src/platform/diagnostics/CameraFileLogger.h`
- `src/platform/diagnostics/CameraFileLogger.cpp`
- `src/runtime/camera/CameraRuntimeController.h`
- `src/runtime/camera/CameraRuntimeController.cpp`
- `src/app/MainWindow.cpp`
- `build/sources.pri`
- `Guard.pro`
- `README.md`
- `docs/CameraFileLogging.md`
- `translations/Guard_en.ts`
- `translations/Guard_zh.ts`
- `tests/camera-file-logging/*`

## Behavior

- The same timestamped entries retained in the camera's 1,000-entry in-memory buffer are appended to disk.
- Application Settings now contains a **Diagnostics** tab with a persistent camera file-logging checkbox.
- The preference defaults to enabled, applies immediately to current cameras, and is reused by cameras created later and after restart.
- Disabling file logging writes one final diagnostic line, flushes and closes each active file, releases the filename claim, and keeps the in-memory Logs dialog available.
- Re-enabling file logging resumes output without reconnecting or restarting the camera.
- The normal filename is `<camera display name>.log`.
- Windows-invalid filename characters are sanitized.
- Duplicate active names receive a short camera-ID suffix to prevent log mixing.
- A camera rename preserves the old file and switches future entries to a file matching the new name.
- Every entry is flushed immediately.
- Log-file failures are observational and never change camera state.
- The Logs dialog displays the path and provides actions to open the file or folder.
- Camera start stages, failures, state changes, stop requests, and safe stop completion are now explicitly recorded through the existing log channel.

## Default location

`QStandardPaths::AppLocalDataLocation/logs/cameras`

Optional override: `GUARD_LOG_ROOT`; camera files are written under `<GUARD_LOG_ROOT>/cameras`.

## Security

No new logging of passwords, JWTs, device credentials, license keys, or face embeddings was added. The file logger persists only entries already routed through the per-camera log channel plus lifecycle diagnostics that contain no secrets.

## Verification

- XML parsing completed for both translation files.
- Source/build manifests include the new diagnostics implementation.
- Static delimiter and preprocessor checks completed for modified C++/header files.
- The camera-file-logging smoke test source covers preference persistence, filename behavior, immediate flush, duplicate-name isolation, sanitization, rename behavior, and clean logger closure/claim release.
- ZIP integrity was checked after packaging.

A full Qt build was not executed in this environment because Qt/qmake is unavailable.
