# Task 5 — Backend Client Verification

Task 5 is implemented against the original requirements and the shared backend error contract.

## Client foundation

`GuardBackendClient` owns one persistent `QNetworkAccessManager` and exposes asynchronous:

- GET
- POST JSON
- POST multipart
- PATCH
- DELETE

All requests complete through callbacks. Replies are released with `deleteLater()`. No nested `QEventLoop` is used for backend I/O.

## Shared error contract

Backend failures are parsed from the agreed nested structure:

```json
{
  "error": {
    "code": "CAMERA_NOT_FOUND",
    "message": "The camera does not belong to this installation.",
    "retryable": false
  }
}
```

`GuardApiResponse` now exposes:

- `errorCode`
- `errorMessage`
- `retryable`
- `retryableKnown`

Legacy flat `{ "error": "...", "message": "..." }` bodies remain supported for compatibility.

Classification helpers:

- `isRetryableFailure()`
- `isNonRetryableAuthFailure()`
- `shouldAttemptAuthRetry()`

Event upload retry/queue logic consumes `isRetryableFailure()` instead of hard-coded HTTP status lists.

## JWT renewal and one safe retry

When an authenticated request returns a retryable `401`, `GuardBackendClient`:

1. calls the installed token-refresh handler;
2. renews the JWT through `/api/guard/auth/token`;
3. retries the original request once;
4. completes the caller callback only after success or final failure.

Token refresh and auth endpoints skip automatic auth retry to prevent loops.

Non-retryable authorization failures such as revoked installations or invalid device credentials emit `authorizationFailed`. `GuardSessionManager` surfaces the error and clears the local session when the failure is permanent.

## Mock boundary

`GuardBackendClientInterface` provides a minimal virtual boundary for tests and future service extraction. Production code continues to use the concrete `GuardBackendClient`.

## Tests and manual verification

The qmake smoke test at `tests/backend-client/backend-client-smoke.pro` verifies:

- nested error parsing;
- legacy flat error parsing;
- retryable vs non-retryable classification;
- expired-JWT vs invalid-credential auth behavior;
- timeout retryability.

Manual verification:

1. Register Guard with a backend installation.
2. Force a JWT to expire and confirm the next authenticated API call succeeds after one silent refresh/retry.
3. Invalidate the saved device credential and confirm Guard reports a session error and clears local registration instead of looping retries.
4. Trigger a backend error with `"retryable": false` and confirm Guard does not queue it for offline retry.
