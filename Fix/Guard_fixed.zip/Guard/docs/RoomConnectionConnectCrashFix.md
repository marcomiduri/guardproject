# Room Connection Connect-Crash Fix

## Reported symptom

Guard could terminate when the operator selected a room and pressed **Connect** in the modal Room Connection dialog.

## Reviewed flow

The Connect completion previously performed all of the following synchronously while the dialog's nested modal event loop and the network-reply signal stack were still active:

1. Persist the installation and room response.
2. Request and install the access token.
3. Emit `connectionSucceeded`.
4. Apply backend camera mappings.
5. Start the realtime WebSocket.
6. Synchronize cameras from the backend.
7. Refresh notification settings and the GuardVision face registry.
8. Close the dialog from another direct signal handler.

The room-list callbacks also captured a raw sentinel pointer. Destroying the sentinel did not make the captured raw pointer null, so a late network completion could dereference a destroyed dialog.

Backend camera synchronization additionally compared presentation strings literally. A harmless backend normalization such as `Generic RTSP Camera` to `Generic (RTSP)` or `Sub Stream` to `sub` could be treated as a source change, causing an active image/video/camera source and its GuardVision stream to be stopped and restarted during room connection.

## Changes

- Room-list requests now capture `QPointer<RoomConnectionDialog>` plus a request generation.
- Modal-dialog callbacks use the dialog as their Qt connection context and capture a guarded pointer rather than a stack reference.
- Application-level connection completion is deferred with `QTimer::singleShot(0, ...)`, allowing the modal signal stack to unwind before cameras, WebSocket, registry, or notification state is changed.
- Camera source equality now compares effective source semantics rather than normalized UI labels and surrounding whitespace.
- The Connect handler ignores reentrant or duplicate activation while already busy.

## Preserved behavior

- The same room-connect API and device-credential/JWT flow are used.
- Existing camera mappings are still applied.
- Backend camera synchronization still runs after successful authentication.
- A genuine camera source change still follows the existing safe stop/update/restart flow.
- Image test playback, video test playback, RTSP, HCNetSDK, recording, GuardVision processing, and face-registry refresh logic are unchanged.

## Verification limits

The source and smoke-test coverage were updated. A full Windows Qt runtime reproduction still requires the user's Qt/vendor-SDK environment.
