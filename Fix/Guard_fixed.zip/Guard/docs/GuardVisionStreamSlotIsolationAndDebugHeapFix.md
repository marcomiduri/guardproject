# GuardVision stream slot isolation and debug heap fix

## Symptom

After the previous teardown fix, the MSVC Debug CRT assertion could still appear:

```text
Expression: _is_block_type_valid(header->_block_use)
```

The new camera logs showed a different boundary from the animation cleanup issue.
After room switches, new camera controllers were adopting retained GuardVision
stream IDs that originally belonged to other camera IDs, for example:

```text
Adopted retained GuardVision stream slot: guard-<old-camera-id> (...)
Hazard ended.
```

Those immediate `Hazard ended` messages showed that the reused native stream slot
was still carrying state from the previous camera owner.

## Fix

Guard now separates two lifecycles:

1. CameraWidget Connect/Disconnect on the same controller still reuses that
   controller's own GuardVision stream.
2. Removing a camera, disconnecting a room, or switching rooms no longer donates
   a retained stream slot to a new/different camera controller.

Fresh camera controllers always receive a fresh stream ID based on their own
camera ID. Old native stream registrations remain process-owned and inactive
until final process exit.

To support several room switches in a long-running tray session, GuardVision is
initialized with extra process-lifetime stream capacity. The UI limit remains
four active cameras, so active processing behavior is unchanged.

## Final process exit hardening

`ShutdownMode::ProcessExit` already joins GuardVision worker threads and detaches
callbacks. Guard now intentionally releases ownership of the GuardVision wrapper
instead of deleting it during final Qt/widget teardown. This avoids re-entering
vendor/destructor cleanup for retained native stream/session memory, which is the
area implicated by the debug heap assertion.

## Behavior preserved

- Maximum visible/active camera count remains four.
- Normal per-camera Disconnect/Connect still works.
- Room switching still removes old-room widgets and loads new-room widgets.
- Backend event upload logic is unchanged.
- Per-stream native unregister is still avoided during normal operation.
