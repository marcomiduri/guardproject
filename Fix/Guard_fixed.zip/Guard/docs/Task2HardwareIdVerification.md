# Stable Installation Hardware ID Verification

The Hardware ID is now an installation identity rather than a commercial-license
input. Its canonical algorithm remains:

```text
SHA-256("machineGuid=<NORMALIZED_MACHINE_GUID>|processorId=<NORMALIZED_PROCESSOR_ID>")
first 16 hexadecimal characters, displayed as XXXX-XXXX-XXXX-XXXX
```

Properties:

- stable across Qt 5.7, 5.12, and 5.14;
- no hostname, MAC address, or partial-component fallback;
- WMIC query with PowerShell CIM fallback;
- last verified identifier retained during temporary query failure;
- complete hardware replacement produces a new identifier;
- raw MachineGuid and ProcessorId are not persisted or logged.

Legacy stored canonical identity metadata is migrated from `license/` to `identity/`.
The deterministic smoke test is under `tests/hardware-id`.
