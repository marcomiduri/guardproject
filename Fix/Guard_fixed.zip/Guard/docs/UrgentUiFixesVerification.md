# Urgent UI Fixes — Corrective Update and Verification

## Scope

This corrective update addresses the two issues that remained after the first UI-fix package. Camera, GuardVision, recording, and backend architecture and logical flow are unchanged.

## 1. System-tray behavior

### Root causes found

- The bundled `guard-16.png` through `guard-256.png` resources were malformed. Their PNG signature began with UTF-8 replacement bytes instead of the required PNG signature.
- `GuardIcon::trayIcon()` accepted the resulting `QIcon` as non-null before confirming that it contained a loadable image, so the valid ICO fallback was never selected.
- `setupSystemTray()` returned immediately when `QSystemTrayIcon::isSystemTrayAvailable()` temporarily reported false. On some Windows/Qt 5.x startup paths, that prevented the tray object from ever being created.

### Corrective implementation

- Regenerated all Guard PNG application icons from the canonical SVG.
- Regenerated `guard.ico` as a valid multi-size Windows icon.
- `GuardIcon::trayIcon()` now prefers the validated ICO and checks `availableSizes()` before accepting an icon.
- The tray object is created without using `isSystemTrayAvailable()` as an early-return gate.
- Tray visibility is requested immediately and retried after 0 ms, 250 ms, and 1000 ms to tolerate Windows Explorer notification-area startup/restart timing.
- Minimize still calls `showMinimized()`, so Guard remains in the taskbar and also appears in the tray.
- Close still follows `closeEvent()`, hides the main window/taskbar entry, and keeps the tray icon available.

## 2. Application Settings Server-panel styling

### Root cause found

The first fix relied primarily on dynamic-property stylesheet selectors. With some Windows native style engines on older Qt 5.x builds, the Server tab leaked native `QGroupBox` and `QLineEdit` borders, while the License tab retained the intended dark Guard treatment.

### Corrective implementation

- Added shared `GuardTheme::settingsGroupBoxStyleSheet()` and `GuardTheme::settingsLineEditStyleSheet()` helpers.
- Every Application Settings group box receives the same explicit group style directly.
- Settings line edits receive one shared explicit style directly.
- The existing shared Server/License tab construction helper remains in place, so border color, border radius, background, padding, font, and focus treatment are now sourced from exactly the same functions.

## Preserved fixes

- Camera connection-state pill width is calculated from translated text and equal left/right padding.
- Existing camera cards refresh connection-state text immediately after language changes.
- Generated build output remains excluded from the source package.

## Static verification performed

- Confirmed valid PNG signatures for all seven application-icon sizes.
- Confirmed the Windows ICO contains multiple image sizes.
- Confirmed tray construction no longer has an `isSystemTrayAvailable()` early-return gate.
- Confirmed tray visibility retries exist after close/minimize transitions.
- Confirmed minimize uses `showMinimized()` and close uses `hide()`.
- Confirmed Server and License tabs use the same shared settings shell.
- Confirmed settings group boxes and line edits receive explicit shared styles.
- Confirmed the source package contains no generated Makefiles, qmake cache, object files, or executables.

## Manual Windows verification checklist

1. Start Guard and click Minimize. Guard must remain in the taskbar and appear in the Windows notification area (possibly under the Windows overflow arrow depending on OS settings).
2. Restore Guard and click Close. Guard must disappear from the taskbar and remain restorable from the tray icon.
3. Right-click the tray icon and verify `Show Guard` and `Exit`.
4. Open Application Settings and compare the Server and License group borders.
5. Verify the Base URL and recording-root fields use the intended consistent border and focus treatment.

## Verification boundary

Static source and resource checks were completed in this environment. A full Windows Qt build and live notification-area test require the project's Windows Qt 5.x kit and proprietary GuardVision/HCNetSDK/Identify/HazardDetect dependencies, which are not installed here.
