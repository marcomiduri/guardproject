# License Persistence Restart Fix

## Problem
Guard accepted both permanent and temporary Guard license keys during the current session, but after restarting the app it asked for a license key again.

## Cause
`src/app/Main.cpp` called `clearLegacyLicenseState()` on every launch. That function was intended to remove obsolete plaintext legacy license values, but it also removed the current protected credential named `guard-license-key` from `SecureCredentialStore`.

Because `GuardLicenseManager` stores the active license key in that protected credential, the saved key was deleted during startup before the periodic license check ran.

## Fix
The startup cleanup now preserves the current protected Guard license credential and removes only obsolete plaintext legacy QSettings keys.

## Expected behavior
- Entering a permanent Guard license remains permanent after restart.
- Entering a 7-day temporary Guard license remains active after restart until its original expiration time.
- Expired temporary licenses still require a permanent key.
- Closing the permanent-license-required dialog still exits Guard instead of leaving the tray app running.
