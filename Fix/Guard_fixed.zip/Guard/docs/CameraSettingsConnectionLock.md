# Camera Settings Lock During Connection

The per-camera **Settings** button is disabled while an IP camera is connecting or automatically reconnecting. This prevents credentials, source configuration, detection modes, and test-source options from being modified while the camera runtime is establishing a session.

The button is restored automatically when the camera reaches a terminal or stable state:

- Connected
- Disconnected
- Error

The Connect and Disconnect button behavior is unchanged.
