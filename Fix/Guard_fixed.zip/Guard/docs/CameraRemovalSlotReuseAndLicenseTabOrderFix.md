# Camera Removal Slot Reuse and License Tab Order Fix

> **Historical note:** The cross-camera retained-stream slot pool described below has been superseded by `RoomSwitchCoordinatedStreamRecreation.md`. Current Guard stops all relevant producers and unregisters removed/old-room streams before creating replacement controllers.


## Problem

The stable Guard lifecycle intentionally retains a GuardVision stream when a camera disconnects or its controller is destroyed, because per-stream native unregister caused Windows crashes while other streams remained active. Explicitly removing two configured cameras therefore removed their UI/controllers but left two process-lifetime GuardVision streams registered. Adding two replacement cameras attempted to register fifth and sixth streams and GuardVision returned `Maximum stream count reached.`

## Fix

Guard now keeps a small in-memory pool of retained GuardVision stream slots from explicitly removed cameras. A newly added camera receives one of those stream IDs and its new controller adopts the existing inactive GuardVision stream using `getStreamStatus()` rather than registering another stream. The previous native face-identification preparation state and the next frame sequence/timestamp cursor are preserved so the stable vendor-session lifecycle is not downgraded, redundantly reconfigured, or fed a regressed frame sequence. The pool is process-local and contains at most the removed slots from the four-camera UI.

No per-camera `unregisterStream()` call was reintroduced. Camera playback, recording, event delivery, room connection, and application shutdown remain unchanged.

## Settings

The Application Settings order is now: Server, Alerts, Recording, Diagnostics, License. The License tab is last.
