# Task 9 Heartbeats, Session Restore, and Registry Refresh Verification

## Scope

Task 9 keeps backend status, GuardVision face data, and Guard notification settings synchronized during normal Guard operation.

## Live backend contract (canonical for Guard)

Guard intentionally uses the deployed backend routes and payload shapes below. These
match `Web/backend/src/routes/guard.ts`, `Web/backend/docs/backend-tasks.md`, and
`Web/backend/docs/GuardBackendIntegration.md`.

| Area | Canonical endpoint / shape |
|---|---|
| Face registry | `GET /api/guard/faces` with `id`, `name`, `feature` |
| Registry version | `GET /api/guard/faces/version` with string `version` |
| Notification settings | `GET /api/guard/notification-settings` with nested `{ "settings": { … } }` (flat top-level flags also accepted by the parser) |
| Camera heartbeat | `POST /api/guard/cameras/{backendCameraId}/heartbeat` with `status` and `occurredAt` |
| Installation heartbeat | `POST /api/guard/installations/heartbeat` with `occurredAt` and `guardVersion` |

Camera heartbeats also update `installation.lastSeenAt` on the backend when the camera belongs to a registered installation.

## Implemented behavior

| Requirement | Implementation |
|---|---|
| Camera state mapping | `cameraStatusApiValue()` maps Connected/Disconnected/Error/Connecting/Reconnecting to `online`/`offline`/`unknown` |
| Camera heartbeats | On state change, every 30s while running, and offline on shutdown |
| Installation heartbeat | `sendInstallationHeartbeat()` on the same 30s timer and once during graceful shutdown |
| Session restore | `restoreSession()` at startup when registered; scheduled refresh from token `expiresAt` |
| Token renewal retry | `GuardBackendClient` retries the original request once after successful JWT refresh |
| Auth-gated registry/settings | Face registry and notification settings load only after registration (`refreshBackendOperationalData()` on `authenticated`) |
| Registry version polling | 60s timer; full download only when `shouldReloadFaceRegistry()` detects a version change |
| Registry apply | `applyFaceRegistry()` updates the shared GuardVision instance without restarting cameras |
| Empty registry | Zero faces is accepted; footer logs count only |
| Embeddings never logged | Footer logs face count and model name only |
| Notification polling | 60s timer; cached flags applied to `GuardEventCoordinator` |

## Automated check

```bat
cd Desktop\Guard\tests\task9-operations
mkdir build
cd build
qmake ..\task9-operations-smoke.pro CONFIG+=release
nmake release
release\guard-task9-operations-smoke.exe
```

The smoke test verifies nested/flat notification-settings parsing and face-registry reload gating.

## Build regression note

Guard Release and the Web backend were rebuilt after these changes. Registry and notification refresh no longer run before room registration completes.
