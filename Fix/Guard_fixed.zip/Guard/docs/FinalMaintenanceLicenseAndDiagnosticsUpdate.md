# Final Maintenance, License, and Diagnostics Update

This update is intentionally scoped to settings UI and behavior-preserving maintenance.

## Diagnostics

- Removed the separate `Effective path` row from the Diagnostics tab.
- The log-folder input now displays the actual default path when no custom path is stored.
- `Restore Default` writes the default path back into the input while preserving default-path semantics in settings.
- `GUARD_LOG_ROOT` continues to override and lock the field.

## License tab

- Added a read-only hardware-ID field using the existing protected hardware-derived Guard identifier.
- Added a license-key field with `XXXX-XXXX-XXXX-XXXX` uppercase alphanumeric formatting.
- License keys are stored using `SecureCredentialStore` (Windows DPAPI in production).
- No license validation or application-start gating was added in this task.

## Architecture preserved

No camera lifecycle, GuardVision ownership, room connection, event delivery, recording, or shutdown flow was changed.
