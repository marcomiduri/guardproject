# Legacy Licensing Removal

## Purpose

This is a transitional no-licensing build used to verify Guard camera, backend,
event, recording, alarm, and synchronization behavior before the replacement
license-generator model is introduced.

## Removed from Guard

- `GuardAppLicense-v1` parsing and validation.
- Saved product-license migration and protected license-key storage.
- Backend trial/entitlement parsing and local operation gates.
- Permanent-license submission to `/api/guard/installations/license`.
- The Application Settings License tab and activation controls.
- License-specific tests, documentation, translations, and source files.

Existing deprecated saved license-key values are deleted at startup. Device
credentials and camera passwords remain protected through `SecureCredentialStore`.

## Preserved

- Stable installation Hardware ID used by room registration.
- Room registration, device credential, short-lived JWT, revocation, and session
  restoration.
- Camera direction and canonical backend camera IDs.
- Face registry, face and hazard events, heartbeats, notifications, alarms,
  recording, and offline retry.

The Hardware ID implementation was moved from `platform/license` to
`platform/identity` without changing its canonical MachineGuid + ProcessorId output.
Legacy stored canonical identity metadata is migrated to the new `identity/` settings
namespace so upgrades retain the same installation identity.
