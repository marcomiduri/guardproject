# CameraWidget disconnect crash investigation and fix

## Evidence from the latest uploaded logs

Two CameraWidgets were active. Camera 2 recorded the complete producer-stop
boundary:

```text
Camera stop requested.
Recording stop requested for source generation 2.
Media source stop requested.
Asynchronous camera teardown started.
Media source quiesced; scheduling GuardVision cleanup on the next UI turn.
GuardVision stream unregister started.
```

No `GuardVision stream unregister completed.` or `Camera stopped safely.` line
was written. The process terminated inside the per-stream
`GuardVision::unregisterStream()` call.

The media producer had already become quiescent, so the failure was not caused
by a late image/video frame, recording finalization, or source-thread shutdown.
The crash boundary is the native per-stream GuardVision/vendor face-session
teardown while another camera stream remains active.

## Corrected per-camera disconnect strategy

A normal CameraWidget Disconnect no longer performs native per-stream
unregistration.

The corrected flow is:

1. Mark the camera controller as stopping.
2. Invalidate the active media-source generation.
3. Invalidate the active GuardVision callback generation.
4. Stop/finalize the motion recorder.
5. Request media-source shutdown.
6. Return to the Qt event loop.
7. Wait until the image/video/RTSP producer is quiescent.
8. Retain the registered GuardVision stream without accepting callbacks.
9. Clear local face, motion, and hazard state.
10. Set the CameraWidget state to Disconnected.

The retained stream is reused on the next Connect for the same CameraWidget.
No new GuardVision stream is created for a normal disconnect/reconnect cycle.

## Application shutdown

`MainWindow` owns the shared GuardVision instance. During application shutdown:

1. Every CameraRuntimeController drains its media producer.
2. Controllers are destroyed without per-stream GuardVision unregistration.
3. The shared GuardVision instance is shut down once.
4. GuardVision releases all retained streams and process-wide analytics engines
   during this coordinated shutdown.

This keeps vendor teardown out of the per-camera button-click path while still
releasing all native resources before process exit.

## Behavioral preservation

- Image and video test sources still stop immediately from the user's point of
  view.
- CameraView frames and overlays are cleared.
- Recording is finalized before the source is drained.
- Backend camera heartbeat state becomes offline.
- Reconnecting reuses the same stream generation and camera identity.
- Other active cameras continue processing without interruption.
- File logging remains configurable from Application Settings.
- The four-camera UI limit is unchanged.

## Diagnostic markers

A successful disconnect now ends with:

```text
Media source quiesced; scheduling final camera cleanup on the next UI turn.
GuardVision stream retained for safe reconnect; per-stream unregister deferred to application shutdown.
Camera stopped safely.
```

A later reconnect includes:

```text
Reusing retained GuardVision stream: <stream-id> (generation <n>)
```

These markers distinguish producer shutdown, retained-stream state, and
successful reconnect.
