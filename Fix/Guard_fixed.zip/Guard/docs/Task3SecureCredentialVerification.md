# Secure Credential Storage Verification

On Windows, `SecureCredentialStore` protects values with DPAPI and stores only the
protected Base64 blob in QSettings under `secure/<name>`.

Protected values include:

- backend installation device credentials;
- camera passwords.

Short-lived JWT access tokens remain in memory and are never persisted. Commercial
product-license storage and migration are absent.

The smoke test covers protected round trips, removal, invalid names, corrupted data,
and device credentials under `tests/secure-credential`.
