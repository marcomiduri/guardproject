# Final diagnostics and normal-camera pipeline update

## Baseline

This update is based on the stable Guard source that passed the camera/session crash tests. It deliberately does not change GuardVision ownership, retained-stream behavior, room reconnect behavior, camera stop sequencing, source generations, backend event flow, recording ownership, or application shutdown architecture.

## Diagnostic log folder

The Diagnostics tab now allows the operator to:

- enable or disable persistent per-camera log files;
- select a camera log folder;
- view the effective folder;
- open the effective folder;
- restore the default folder.

The saved value is stored under `diagnostics/cameraLogDirectory`. An empty value uses the existing application-local default. `GUARD_LOG_ROOT` remains the highest-priority environment override and keeps the field read-only while active.

When settings are saved, active camera loggers switch to the selected folder without stopping camera playback or changing GuardVision state. If opening the new log file fails, the current log file remains active.

## Normal camera frame path

The source adapters remain separate because they own different SDK/decoder lifecycles:

- image/video test source;
- RTSP source;
- HCNetSDK camera source.

All decoded frames converge at the existing signal:

```text
MediaSourceController::frameReadyForSubmission
    -> CameraRuntimeController::handleDecodedFrame
```

The shared handler performs the same runtime features for test and normal camera sources:

1. generation/stale-frame validation;
2. current-frame storage and CameraView preview;
3. recent-frame tracking for event snapshots;
4. decoded-frame motion recording fallback;
5. GuardVision frame submission;
6. local face/motion/hazard overlays through GuardVision events;
7. face and hazard occurrence delivery to the backend coordinator.

HCNetSDK onboard candidates remain optional hints for OnboardTriggered/Hybrid modes. They do not replace or bypass decoded-frame delivery.

## Conservative cleanup

- Replaced an unnecessary frame-forwarding lambda with a direct signal-to-member connection.
- Made still-image pacing depend on the actual active source type instead of the `--test` flag.
- Added one idempotent runtime method for reloading file-logging preferences.
- Added source-level regression checks for the normal-camera frame path and configurable log folder.

No camera, GuardVision, backend, recording, room, alarm, or shutdown architecture was changed.
