# Guard Tray Exit, Running Source Replacement, Tray Startup, and Event Delivery Fix

## Baseline

This change is based on the user-provided `Guard(1).zip`. The uploaded backend and frontend projects were inspected as the event-contract source of truth.

## 1. System-tray Exit crash

### Evidence

The latest camera logs show that every active image/video producer reached:

- `Media source quiesced during controller destruction.`
- `GuardVision stream retained for coordinated application shutdown.`
- `Camera runtime prepared for coordinated application shutdown.`

The process terminated after those messages. Therefore, the remaining crash was after producer quiescence, in the final destructor/native-runtime phase rather than in file decoding.

### Change

Final application Exit now:

1. Stops backend realtime callbacks, event timers, maintenance, and tray activity.
2. Disables the GuardVision event adapter.
3. Synchronously stops and quiesces every camera producer.
4. Waits for GuardVision frame queues to become idle.
5. Detaches the native listener and removes queued Qt callbacks.
6. Detaches the already-quiescent camera controllers from QObject ownership instead of invoking recorder/member destructors during the final milliseconds of the process.
7. Detaches the event adapter and GuardVision instance from QObject/`unique_ptr` ownership instead of calling the vendor `shutdown()`/destructor path that has repeatedly terminated the Windows process.
8. Exits Qt normally. Windows reclaims the process-lifetime objects immediately.

This intentional process-exit ownership policy does not affect ordinary CameraWidget Disconnect/Connect behavior.

## 2. Crash while replacing a running image/video source

The previous implementation applied GuardVision motion/face/hazard configuration while the old producer could still submit frames, then called `start()`, which stopped the old source too late.

The replacement is now transactional:

1. Detect source change while the camera is running.
2. Block reentrant replacement.
3. Stop and fully quiesce the old source synchronously.
4. Require a continuous GuardVision idle period.
5. Keep the existing native analytics configuration for a pure media-file replacement.
6. Apply native configuration only when detection settings actually changed.
7. Commit and start the replacement source.

Expected camera log markers:

```text
Test source replacement started; stopping the current source before reconfiguration.
Starting the replacement test source after the previous source quiesced.
Test source replacement completed safely.
```

## 3. Tray icon at application launch

Guard now calls `showTrayIcon(false)` during startup. The icon is registered immediately and retried after 0, 250, and 1000 milliseconds for Windows Explorer/Qt 5 reliability. The minimize/background hint balloon is not shown at normal startup.

## 4. Hazard event delivery

Guard sends hazard incidents as multipart POST requests to:

```text
/api/guard/events/hazard-detected
```

Payload:

- `eventId`
- backend `cameraId`
- `hazardType`
- `confidence`
- `eventTime`
- `source=GUARD2`
- JSON `detections`
- annotated JPEG `snapshot`

A hazard incident is now marked as submitted only when the request was actually dispatched or stored in the offline queue. If the room/camera mapping is unavailable on the `Started` event, a later active `Updated` event can submit it instead of permanently suppressing that incident.

The backend route accepts the snapshot, persists the hazard event/image, and broadcasts `hazard-detected` to staff/admin realtime clients. The Svelte frontend applies the room hazard, opens the hazard modal, plays the alarm sound, and displays an error/warning toast.

## 5. Unknown and unapproved face delivery

Guard sends both images for recognized and unknown face events:

- `frameImage`: full frame annotated with the face rectangle and label
- `faceImage`: cropped face image

Endpoints:

```text
/api/guard/events/appeared
/api/guard/events/unknown-appeared
```

The backend accepts and persists both images.

- Unknown incoming face: backend broadcasts `unknown-room-entry`; frontend displays an error toast. Guard also plays the configured local unknown-incoming voice.
- Recognized but unapproved incoming face: backend broadcasts `face-identified` with `approved=false`; frontend displays the unapproved error toast. Guard plays the configured local unapproved-incoming voice after the backend access decision.

## Verification

Source checks added/updated:

- `tests/tray-exit-shutdown/verify_source.py`
- `tests/source-replacement-lifecycle/verify_source.py`
- `tests/tray-startup/verify_source.py`
- `tests/backend-event-delivery/verify_source.py`
- `verification/verify_end_to_end_guard_events.py` in the combined project bundle

The proprietary Windows GuardVision/Identify/Hazard binaries cannot be executed in this Linux environment, so native runtime confirmation still requires the Windows test build.
