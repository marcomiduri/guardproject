# Guard Implementation Status — Transitional No-Licensing Build

## Legacy commercial licensing

**Removed.** `GuardAppLicense-v1`, local product-license state, backend trial and
entitlement parsing, license activation APIs, operation blocking, and the License tab
are absent. See `LegacyLicensingRemoval.md`.

## Stable installation Hardware ID

**Implemented.** The canonical identifier uses normalized Windows MachineGuid and
ProcessorId, survives temporary query failures using the last verified value, and is
used only for installation identity. Stored values migrate from the old `license/`
settings namespace to `identity/`.

## Secure credential storage

**Implemented.** Windows DPAPI protects backend device credentials and camera
passwords. JWTs remain memory-only. No commercial product license is stored.

## Application Settings

**Implemented.** Server, Alerts, and Recording tabs are present. Connection testing is
asynchronous, backend URL validation is preserved, and recording behavior is
unchanged.

## Backend and operational integration

**Implemented in source.** The asynchronous client, room registration, device session,
camera direction/synchronization, heartbeats, face-registry refresh, face overlays and
events, hazard alarms/events, and offline queue remain unchanged except for removal of
commercial entitlement dependencies.

Windows builds and hardware/runtime verification still require the matching Qt kit,
GuardVision, and proprietary SDK dependencies.
