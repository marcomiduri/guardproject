# Task 11 Hazard Events, PC Alarm, Camera Alarm, and Offline Queue Verification

## Scope

Task 11 completes Guard hazard handling from GuardVision detection through local PC
alarm, optional camera alarm, annotated backend upload, and persistent offline retry.

## Live backend contract

| Area | Canonical endpoint / shape |
|---|---|
| Hazard upload | `POST /api/guard/events/hazard-detected` (alias `/events/safety-detected`) |
| Multipart fields | flat JSON fields + `snapshot` JPEG |
| `detections[]` | normalized rectangles with `type`, `confidence`, optional `rectangle` |
| Idempotency | Guard-generated `eventId`; backend returns HTTP 200 when duplicate |

See `Web/backend/docs/GuardBackendIntegration.md` and
`Web/backend/docs/backend-tasks.md` Task 7.

## Architecture note

The task spec lists `src/services/hazard/*` component names. The implemented
equivalents are:

| Spec component | Implementation |
|---|---|
| HazardCoordinator | `GuardEventCoordinator::handleHazardOccurrence()` / `uploadHazard()` |
| HazardAlarmManager | `LocalAlertService` hazard alarm state + timer |
| HazardSnapshotRenderer | `GuardEventCoordinator::annotateHazardFrame()` |
| CameraAlarmService | `services/alerts/CameraAlarmService` (capability-gated scaffold) |
| OfflineEventQueue | `services/events/OfflineEventQueue` |

`CameraRuntimeController` keeps GuardVision overlays and emits
`hazardOccurrenceReady`; backend, audio, and camera-alarm orchestration stay out of
the controller.

## Implemented behavior

| Requirement | Implementation |
|---|---|
| PC alarm before backend | `startHazardAlarm()` runs before `uploadHazard()` on `Started` |
| One occurrence → one upload | Upload only on `Started`; `Updated` is overlay-only; `hazardUploadSent_` dedupes repeated `Started` per camera/type until `Ended` |
| Annotated snapshot | JPEG with fire/smoke boxes, labels, camera name, UTC footer; quality 85, max dimension 1920 |
| Multiple cameras | `LocalAlertService::activeHazards_` keyed by `localFaceTrackCameraKey():hazardType` |
| Acknowledge | Footer **Silence Alarm** → `acknowledgeHazardAlarm()` stops sound, keeps overlays/active keys |
| New hazard after ack | `startHazardAlarm()` clears `acknowledged_` and sounds again |
| Packaged WAV | `:/audio/hazard_alarm.wav` |
| Test alarm | Application Settings → Alerts → **Test Alarm** |
| Camera alarm | Capability interface present; unsupported cameras fail safely without blocking PC alarm/upload |
| Offline queue | `pending-events/<eventId>/` with JSON + binaries; 30-day age cap; ~250 MB total cap; exponential backoff retry |
| Same eventId on retry | Queue persists original `eventId`; backend idempotency prevents duplicates |
| Status logging | Footer shows queued/rejected categories without credentials |

## Not implemented (documented)

- Optional backend lifecycle-end update after `Ended` (future enhancement).
- Verified vendor camera siren/light output (requires HCNetSDK output API wiring).
- Separate `FLAME` hazard type (GuardVision exposes `Fire` and `Smoke` only).

## Automated check

```bat
cd Desktop\Guard\tests\hazard-events
mkdir build
cd build
qmake ..\hazard-events-smoke.pro CONFIG+=release
nmake release
release\guard-hazard-events-smoke.exe
```

The smoke test verifies hazard keys, upload dedupe, ended-state clearing, snapshot
label formatting, and PC alarm gating helpers in `GuardHazardEventHelpers`.

## Build regression note

Rebuild Guard Release after these changes so coordinator dedupe state and helper
refactors are included in the binary.
