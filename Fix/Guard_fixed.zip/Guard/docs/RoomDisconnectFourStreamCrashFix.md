# Room Disconnect Four-Stream Crash Fix

## Symptom

With four camera widgets actively playing, clicking **Disconnect** in the room dialog stopped every media source successfully and then terminated the application.

The camera logs ended after `Camera stopped safely` and before any `GuardVision stream unregistered` message. This isolates the failure to the first runtime call to `GuardVision::unregisterStream()` rather than decoder, recorder, or camera-source shutdown.

## Root cause

`GuardVision::unregisterStream()` tears down native face-analysis sessions. In the current Windows vendor runtime, that teardown is unsafe when several stream/face sessions have existed in the same process, even after all frame producers report idle.

The previous coordinated-room implementation correctly stopped all four producers, but then called per-stream unregister. The first native unregister entered the unstable vendor teardown path and crashed the process.

## Safe lifecycle

Guard now treats the four GuardVision registrations as process-lifetime analytics slots:

1. Stop and fully quiesce all old-room media producers.
2. Invalidate the old controllers' active source and GuardVision generations.
3. Clear room-scoped alarms, incidents, face state, and stale callbacks.
4. Capture each native stream ID, face-session state, next frame sequence, and next timestamp.
5. Delete all old-room camera controllers and widgets without calling per-stream unregister.
6. Recreate the selected room's camera widgets/controllers.
7. Rebind retained analytics slots lazily when the new cameras are connected.
8. Continue the retained stream's sequence/timestamp cursor so GuardVision never receives regressed frames.
9. Release all native workers only during the existing coordinated process-exit shutdown.

## Result

- Room disconnect no longer enters runtime native face-session teardown.
- Old room camera widgets/controllers are still completely removed.
- New room camera widgets/controllers are newly created.
- No fifth GuardVision registration is consumed after repeated room switches.
- Slots assigned to cameras that were never played are returned correctly.
- Frame sequence and timestamp continuity is preserved across slot rebinding.
- Old-room hazard audio/indicator state and queued face/hazard callbacks remain cleared/rejected.
