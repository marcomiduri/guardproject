# Fresh No-Room Unknown-Face Crash Fix

## Reproduction

1. Launch Guard without connecting to a room.
2. Select a still image in a CameraWidget.
3. Click **Connect**.
4. A face rectangle with `Unknown` appears.
5. The process terminates a few seconds later.

## Evidence from the supplied logs

The final run registered Camera 1, accepted its first frame, and emitted face/hazard results. The log then ended without a controlled camera stop or GuardVision error. Earlier runs that had first connected to a room retained a loaded GuardVision face registry and survived the same still-image source.

## Root cause

The configured face processing level was always normalized to `DetectTrackAndIdentify`. On a fresh launch with no room, GuardVision therefore entered identification processing before any room-scoped registry had been accepted. The vendor face session could terminate the process after repeatedly processing an unknown face.

A separate semantic bug allowed delayed unknown-access handling to run before checking whether a room was assigned. Local-only face tracking must not produce an access-denied action.

## Fix

- New camera controllers start with face identification disabled.
- The effective GuardVision face config uses `DetectAndTrack` while no valid room registry is available.
- The user's configured face mode remains unchanged; only the effective runtime processing level is downgraded.
- When a concrete room registry is ready, MainWindow prepares IdentifyEngine and applies the registry before initial media submission.
- Successful non-empty registry application upgrades all streams to `DetectTrackAndIdentify`.
- Room detachment, registry failure, or permanent identification failure immediately masks identity results and clears resolved labels. A native Identify session that was already prepared is retained to avoid the unsafe vendor teardown path; fresh no-room launches still start in `DetectAndTrack`.
- Unknown access events and voice prompts are now gated by an assigned room before any delayed action occurs.

## Expected field log

A fresh no-room image connection should contain:

```text
Face identification deferred until a room registry is available; detect-and-track remains active.
```

The face rectangle should still display `Unknown`, but the application should remain running.

## Verification

Run:

```text
python tests/no-room-face-lifecycle/verify_source.py
```

A Windows runtime test is still required because the proprietary GuardVision/Identify binaries are not available in this environment.
