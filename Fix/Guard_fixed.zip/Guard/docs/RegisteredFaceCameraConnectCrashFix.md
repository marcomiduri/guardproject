# Registered-face camera connect crash fix

## Reported behavior

In test mode, a registered face image was selected for a CameraWidget. Roughly three seconds after pressing **Connect**, Guard could terminate unexpectedly.

## Corrected startup and camera flow

The splash bootstrap is now asynchronous and performs these operations in order:

1. Test `/api/health`.
2. Restore the protected installation session and obtain a short-lived access token.
3. Read `/api/guard/faces/version`.
4. Download `/api/guard/faces` when the registry is missing or stale.
5. Apply the complete registry to GuardVision.
6. Synchronize backend camera mappings.
7. Start realtime updates and refresh notification settings.
8. Finish the splash screen.

The backend health check now runs for both saved-session and first-run/disconnected startup paths while the splash is visible. The old nested network event loops were removed. Timed-out callbacks are ignored, and room/request serial guards reject late responses from a previous session, so a stale registry or camera-synchronization response cannot mutate GuardVision or live camera models after splash bootstrap has completed.

When an authenticated room session exists but the registry has not been applied, CameraWidget Connect requests are held until the authoritative registry is loaded. A failed registry load leaves the camera stopped and reports an error instead of starting face processing with an incomplete registry.

Camera synchronization performed during bootstrap uses a cancellation token and the requested room ID. If the bootstrap step times out or the active room changes, its later response is discarded before it can stop, restart, or remap a CameraWidget that the user has already started.

## Media-source lifetime fixes

File-source open, frame, stream-info, and decoder-error callbacks now carry the source generation. MediaSourceController rejects callbacks from any previous generation.

Camera teardown no longer calls `QCoreApplication::processEvents()` while waiting for decoders to stop. This prevents queued frames and UI callbacks from re-entering stream teardown while GuardVision is unregistering native face-processing state.

The established shutdown order remains:

1. Reject new source and GuardVision callbacks.
2. Finalize motion recording.
3. Stop and drain image/video/RTSP/camera producers.
4. Disable stream analytics.
5. Unregister the GuardVision stream synchronously.
6. Clear overlays, frame state, and alarms.

## Face-event safety

Face rectangles are normalized, clamped to the current frame, and discarded when empty before they are shown or uploaded. Similarity values are limited to finite values in the range 0–1.

Windows asynchronous WAV playback now owns a dedicated immutable buffer for the complete playback. Existing playback is stopped before that buffer is replaced, and playback is stopped during LocalAlertService destruction. This removes a possible asynchronous memory-lifetime failure when an unknown or unapproved access warning starts near the face-decision timeout.

## Preserved behavior

The update does not intentionally change:

- still-image repetition for face, motion, and hazard tests;
- video-file looping;
- RTSP and HCNetSDK reconnect behavior;
- motion recording and pre-buffer behavior;
- GuardVision face, motion, and hazard configuration;
- recognized and unknown event upload rules;
- access-warning policy;
- camera overlays or face-name placement.
