# Room-switch connect crash with no test source

## Symptom

After four old-room cameras were stopped and replaced by two new-room cameras, pressing **Connect** on a new camera without selecting test media terminated Guard. The camera log ended after the retained GuardVision slot was adopted/reactivated and before `Camera source started`.

## Root cause

`guardVisionStreamRegistered` is delivered synchronously so a pending room face registry can be applied before the first media frame. The newly created controller correctly inherited that the retained process-lifetime stream slot already had a native Identify session. However, `prepareFaceIdentification()` still called `GuardVision::setFaceConfig()` again. Re-entering the vendor face-session lifecycle on an already-prepared retained slot could terminate the process.

The apparent Hikvision/no-test-source relationship was incidental: the crash happened before HCNetSDK source startup.

## Fix

`prepareFaceIdentification()` is now idempotent. It updates Guard's threshold state but immediately succeeds when the retained native Identify session is already prepared. MainWindow can still replace the room-scoped face registry and enable identity display without rebuilding the native stream mode.

Fresh streams continue to prepare Identify exactly once. Process-lifetime stream retention, frame cursor continuity, old-room alarm clearing, and the stable four-camera room-disconnect behavior are unchanged.
