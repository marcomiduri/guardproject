# Reconnect analytics delay and tray Exit crash fix

## Symptoms

1. Image/video analytics were immediate on the first CameraWidget connection, but face, hazard, and motion overlays appeared much later after Disconnect followed by Connect.
2. Choosing **Exit** from the system tray could terminate Guard while one or more cameras were playing.

## Root cause: reconnect delay

Normal CameraWidget disconnect intentionally retains the GuardVision stream because per-stream native face-session teardown is unsafe on the target Windows runtime. The retained stream also remembers its last accepted frame sequence.

`MediaSourceController::resetForNewPlayback()` nevertheless reset the next source sequence to zero. GuardVision rejected reconnect frames as regressed/stale until the source sequence eventually exceeded the old accepted sequence. A still image advances at only a few frames per second, making the delay especially visible.

## Reconnect fix

- `nextSequence_` is now monotonic for the complete lifetime of a `MediaSourceController`.
- Reconnect starts file, RTSP, and HCNetSDK sources from the next unused sequence.
- Frame timestamps also remain monotonic and advance to the current wall clock after a real disconnect pause.
- The retained GuardVision stream can therefore accept the first reconnect frame immediately.

## Root cause: tray Exit crash

The old tray action posted `QCoreApplication::quit()` immediately. MainWindow destruction then deleted camera controllers one at a time. While the first controller was being destroyed, other cameras could still submit frames and GuardVision could still invoke native callbacks. This created a producer/callback/destructor race around retained native streams and recording workers.

## Exit fix

Tray Exit now performs an explicit, idempotent two-phase shutdown before quitting the Qt event loop:

1. Stop application timers, realtime callbacks, recording maintenance, and every camera producer.
2. Disconnect each CameraRuntimeController from the GuardVision event adapter and remove already queued camera callback deliveries.
3. Wait up to five seconds for GuardVision pending/processing frames to drain.
4. Detach the native GuardVision listener.
5. Destroy all camera controllers and join their recording/media workers.
6. Shut down the shared GuardVision engine.
7. Quit the application event loop.

The MainWindow destructor reuses the same shutdown routine, so normal process teardown and tray Exit follow one path.

## Verification

```bash
python tests/reconnect-frame-continuity/verify_source.py
python tests/tray-exit-shutdown/verify_source.py
```

Target Windows runtime tests:

- Connect an image or video, wait for all overlays, Disconnect, then Connect repeatedly. The first reconnect frame should be accepted and overlays should return without waiting for the old frame count.
- Play image/video sources in multiple CameraWidgets and select **Exit** from the tray menu. Guard should stop the sources and exit without a crash.
