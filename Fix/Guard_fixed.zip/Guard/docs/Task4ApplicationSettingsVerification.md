# Application Settings Verification

The Application Settings dialog contains four tabs:

- Server
- Alerts
- Recording
- Diagnostics

The removed legacy License tab is not present.

The Server tab preserves backend URL resolution, explicit shared group/input styling,
asynchronous `GET /api/health` testing, source reporting, and backend version display.
The Alerts tab preserves PC hazard-alarm controls and effective backend warning
policies. The Recording tab preserves configured/effective root behavior and active
recording safety.

The Diagnostics tab controls persistent per-camera file logging without disabling the
in-memory Logs dialogs or changing camera runtime behavior. It also supports:

- a user-selected camera log folder;
- effective-path and source display;
- folder browsing and opening;
- restore-default behavior;
- `GUARD_LOG_ROOT` environment precedence;
- immediate, non-disruptive reconfiguration of active camera loggers.
