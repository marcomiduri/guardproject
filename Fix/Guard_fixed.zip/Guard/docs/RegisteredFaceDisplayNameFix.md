# Registered face display-name fix

## Problem

A registered face could be detected and drawn with a green rectangle while the overlay still displayed `UNKNOWN`.

## Root causes fixed

- File/image test sources were forced to `DetectAndTrack`, which disabled registry identification.
- Registry identification synchronization skipped file-based test sources.
- Tracking-only updates could overwrite an already resolved identity with an empty name.
- Guard relied only on the display name emitted by GuardVision instead of retaining an ID-to-name lookup from the downloaded registry.
- The face registry was marked loaded before `GuardVision::setFaceRegistry()` succeeded.
- Camera controllers created after registry loading did not receive the registry threshold/name mapping.
- The unknown decision window was shorter than the identification retry window.
- The unknown warning voice could run for recognized uploads.
- Face rectangles were always green, including genuinely unknown faces.

## Result

- Enabled face detection always uses `DetectTrackAndIdentify`, including image/video test sources.
- Registered face IDs are resolved through the backend registry's display-name mapping.
- Resolved identities survive geometry-only tracking updates for the same track.
- Recognized faces use a green rectangle and their registered name.
- Unknown faces use an amber rectangle and `UNKNOWN`.
- Unknown events wait 3.5 seconds and short-lived tracks are not immediately uploaded as unknown.
- The unknown warning voice runs only for genuine unknown uploads.

## Verification limitations

The source structure, qmake references, resources, XML, and regression guards were checked in this environment. A full Windows runtime build requires the matching Qt, GuardVision, Identify, camera SDK, and model packages.
