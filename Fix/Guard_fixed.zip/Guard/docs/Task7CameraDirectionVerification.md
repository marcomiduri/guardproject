# Task 7 Camera Direction Verification

## Scope

Task 7 requires every camera to declare incoming or outgoing direction relative to the registered room, with stable backend values, persisted settings, migration handling, and visible IN/OUT presentation.

## Implemented behavior

| Requirement | Implementation |
|---|---|
| Model fields | `roomId`, `backendCameraId`, `clientCameraId`, `CameraDirection`, `directionConfigured` in `CameraUiModel.h` |
| Add/Edit dialog | Required two-choice Direction combo in `CameraDialog.ui` |
| API values | `"in"` / `"out"` via `cameraDirectionApiValue()` |
| Persistence | `CameraStore.cpp` writes `direction` only when confirmed |
| Migration | Stored cameras without a `direction` key load with `directionConfigured = false` |
| Registration gate | `MainWindow::showRoomLoginDialog()` blocks room registration until every camera is confirmed |
| Card title | `cameraCardTitleText()` shows plain name until confirmed, then `Name [IN]` / `Name [OUT]` |
| CameraView badge | Compact top-right IN/OUT badge when direction is confirmed |
| Runtime isolation | Direction is not used by `CameraRuntimeController` or media decoding |

## Migration policy

Legacy/local camera records that predate direction storage:

1. Load with `directionConfigured = false`.
2. Do not show `[IN]`/`[OUT]` in the card title.
3. Do not paint the CameraView direction badge.
4. Block backend room registration until the user edits the camera and confirms Incoming or Outgoing.

The internal default enum value remains `Incoming` for API compatibility, but unconfirmed cameras are treated as direction-unknown in UI and registration flows.

## Automated check

```bat
cd Desktop\Guard\tests\camera-direction
mkdir build
cd build
qmake ..\camera-direction-smoke.pro CONFIG+=release
nmake release
release\guard-camera-direction-smoke.exe
```

The smoke test verifies:

- `"in"` / `"out"` API conversion;
- legacy JSON migration detection;
- unconfirmed vs confirmed card title text;
- badge label generation.

## Build regression note

Guard Release was rebuilt after these changes. Direction is consumed only by settings persistence, backend camera sync, event routing, and UI presentation. No GuardVision stream registration, decoding, recording, or alarm code paths read camera direction.
