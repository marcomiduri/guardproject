# Cursor Task — Update Backend, Frontend, and Guard for “Task for Room connection”

## Objective

Update the existing Backend, Frontend, and Guard source projects to implement the finalized Room Connection workflow.

The administrator creates rooms in the existing frontend.

A Guard user must then be able to:

1. Configure the backend URL in Application Settings.
2. Click `Room Connection` in the Guard header.
3. Load all active rooms from the backend.
4. Search the returned rooms by name.
5. Select a room.
6. Connect the current Guard PC to that room.
7. Receive and securely store an installation device credential.
8. Restore the same room connection silently on future launches.

Commercial licensing, trial licensing, product license keys, fake license fields, and room activation codes must not be part of this workflow.

Do not change unrelated architecture, camera behavior, GuardVision processing, recording, alarms, event handling, frontend room administration, or backend business logic.

---

# Projects

Update:

- Backend
- Frontend
- Guard Qt/C++ desktop application

Inspect the existing implementation before editing.

Reuse existing:

- API client infrastructure
- Authentication infrastructure
- Device credential storage
- Camera model
- Room model
- JWT handling
- Translation system
- Guard dialog styling
- Backend validation and error contracts
- Frontend room administration

Do not create parallel or duplicate systems where an appropriate implementation already exists.

---

# Final Identity Model

Use the following responsibilities.

## roomId

Canonical backend room identifier selected by the Guard user.

## clientInstallationId

A stable UUID generated once by Guard.

Requirements:

- Generate with `QUuid`.
- Generate only when no stored value exists.
- Persist in non-sensitive application settings.
- Preserve across upgrades and normal restarts.
- Do not regenerate every launch.
- Do not expose a normal UI action that resets it accidentally.

## hardwareIdHash

A versioned SHA-256 fingerprint derived from the existing normalized Guard Hardware ID.

Required format:

`v1:<lowercase-sha256-hex>`

Requirements:

- Do not send raw MachineGuid, CPU ID, or other raw hardware components.
- Do not log raw hardware values.
- Do not use the hardware hash as a password.
- Use it only as installation identity and copied-installation detection metadata.

## installationId

Canonical backend-generated Guard installation ID.

## deviceCredential

A cryptographically random backend-generated secret.

Requirements:

- Return in plaintext only when initially created or intentionally rotated.
- Store only its secure hash in the backend.
- Store it through Guard’s existing Windows-protected secure credential store.
- Never log it.
- Never store it in plain QSettings.

## accessToken

Short-lived JWT used for authenticated operational APIs.

Requirements:

- Store only in Guard memory.
- Never persist it.
- Renew silently using installationId and deviceCredential.
- Do not include commercial license or entitlement claims.

---

# Part A — Backend Updates

## 1. Public Health Endpoint

Preserve or implement:

`GET /api/health`

Response example:

```json
{
  "status": "ok",
  "version": "1.0.0",
  "serverTime": "2026-07-01T12:00:00Z"
}
```

This endpoint must remain public so Guard can test the configured backend URL before registration.

Use UTC ISO-8601 timestamps.

---

## 2. Available Rooms Endpoint

Implement or preserve:

`GET /api/guard/available-rooms`

The endpoint must not require an installation JWT because an unregistered Guard installation does not yet have a device credential.

Return only safe room-selection information.

Response example:

```json
{
  "rooms": [
    {
      "id": "room-uuid-1",
      "name": "Warehouse"
    },
    {
      "id": "room-uuid-2",
      "name": "Main Office"
    }
  ],
  "serverTime": "2026-07-01T12:00:00Z"
}
```

Requirements:

- Return only active and selectable rooms.
- Exclude deleted, disabled, archived, or otherwise unavailable rooms.
- Sort rooms consistently by name.
- Return only:
  - room ID
  - room name
- Do not expose:
  - users
  - occupants
  - orders
  - cameras
  - event history
  - notification settings
  - private room metadata
  - credentials
- Follow the shared backend error and response conventions.

Reuse an existing safe room-list operation when possible instead of duplicating room-query logic.

---

## 3. Installation Connect Endpoint

Implement or update:

`POST /api/guard/installations/connect`

This endpoint replaces the old manual room registration flow.

It must not require:

- Commercial license
- Fake license
- Product entitlement
- Room activation code
- Legacy Guard API key

Example request:

```json
{
  "roomId": "room-uuid",
  "clientInstallationId": "stable-local-uuid",
  "hardwareIdHash": "v1:lowercase-sha256-value",
  "deviceName": "Warehouse Guard PC",
  "guardVersion": "2.0.0",
  "cameras": [
    {
      "clientCameraId": "local-camera-1",
      "name": "Front Entrance",
      "direction": "in"
    }
  ]
}
```

Validate:

- `roomId` is required and refers to an active room.
- `clientInstallationId` is a valid UUID.
- `hardwareIdHash` matches the frozen `v1:` format.
- `deviceName` is present and length-limited.
- `guardVersion` is valid.
- No more than four cameras are submitted.
- Camera direction is exactly `in` or `out`.
- `clientCameraId` values are unique within the request.
- No raw Hardware ID is accepted or persisted.

The operation must be transactional.

Processing:

1. Validate the room.
2. Validate installation identity.
3. Look for an existing installation using the frozen identity rules.
4. Create a new installation when none exists.
5. Restore the existing installation for an idempotent retry.
6. Reject revoked installations.
7. Associate the installation with the selected room.
8. Create or restore cameras using `clientCameraId`.
9. Generate a cryptographically random device credential for a new installation.
10. Store only the credential hash.
11. Return the plaintext credential only when newly created.
12. Return canonical backend camera IDs.
13. Prevent duplicate installations and duplicate cameras.

Recommended uniqueness:

- `clientInstallationId` must be unique.
- Validate the relationship between `clientInstallationId` and `hardwareIdHash`.
- Camera uniqueness should use:
  - `installationId + clientCameraId`

Example new-installation response:

```json
{
  "installationId": "installation-uuid",
  "room": {
    "id": "room-uuid",
    "name": "Warehouse"
  },
  "deviceCredential": "one-time-returned-secret",
  "cameras": [
    {
      "clientCameraId": "local-camera-1",
      "backendCameraId": "camera-uuid",
      "name": "Front Entrance",
      "direction": "in"
    }
  ],
  "serverTime": "2026-07-01T12:00:00Z"
}
```

Do not return:

- license state
- entitlement state
- trial data
- activation code
- raw Hardware ID

---

## 4. Existing Installation Behavior

An identical retry using the same:

- roomId
- clientInstallationId
- hardwareIdHash

must not create another installation.

When the existing Guard installation still has its credential, it must use the normal token endpoint.

When the backend finds an existing installation but Guard no longer has the credential, do not return the previous plaintext credential because the backend stores only its hash.

Return a structured recovery error such as:

```json
{
  "error": {
    "code": "INSTALLATION_CREDENTIAL_RECOVERY_REQUIRED",
    "message": "The installation already exists and requires credential recovery.",
    "retryable": false
  }
}
```

Do not weaken credential protection to simplify reconnection.

---

## 5. Device Token Endpoint

Preserve:

`POST /api/guard/auth/token`

Request:

```json
{
  "installationId": "installation-uuid",
  "deviceCredential": "opaque-secret"
}
```

Processing:

1. Find the installation.
2. Reject revoked installations.
3. Hash and compare the device credential.
4. Update credential last-used time.
5. Update installation last-seen time.
6. Issue a short-lived JWT.

Response example:

```json
{
  "accessToken": "short-lived-jwt",
  "expiresAt": "2026-07-01T12:15:00Z",
  "serverTime": "2026-07-01T12:00:00Z"
}
```

Do not include license, trial, or entitlement data.

JWT claims must continue to include installation identity, room identity, scopes, issuer, audience, issued time, expiration, and token ID.

---

## 6. Room Disconnect and Reassignment

Implement or preserve a controlled room-disconnection flow.

An already connected installation must not silently move to another room through the connect endpoint.

Required behavior:

1. Guard explicitly requests room disconnection.
2. Backend validates the authenticated installation.
3. Backend preserves historical events.
4. Backend preserves audit records.
5. Existing event records remain associated with the previous room.
6. Device credential is revoked or handled according to the existing security policy.
7. Guard clears the local room association only after backend confirmation.
8. The user may then select another room.

Do not delete historical face events, hazard events, camera history, or installation audit records.

Reuse existing revoke, detach, or installation-management architecture where possible.

---

## 7. Backend Error Handling

Use the existing structured error contract.

Support clear errors such as:

- `ROOM_NOT_FOUND`
- `ROOM_NOT_AVAILABLE`
- `INSTALLATION_REVOKED`
- `INSTALLATION_ALREADY_CONNECTED`
- `INSTALLATION_ROOM_CONFLICT`
- `INSTALLATION_CREDENTIAL_RECOVERY_REQUIRED`
- `INVALID_CLIENT_INSTALLATION_ID`
- `INVALID_HARDWARE_ID_HASH`
- `INVALID_CAMERA_DIRECTION`
- `CAMERA_LIMIT_EXCEEDED`
- `VALIDATION_ERROR`
- `TEMPORARY_BACKEND_FAILURE`

Do not return generic `Unauthorized` for room validation or installation-input errors.

Use HTTP 401 only when authentication is actually missing, invalid, or expired.

---

## 8. Database Migration

Add or verify the migration needed for:

- clientInstallationId
- hardwareIdHash format
- installation-room connection state
- camera uniqueness
- disconnected installation status, if required
- related indexes and constraints

Migration requirements:

- Preserve installation IDs.
- Preserve rooms.
- Preserve camera mappings.
- Preserve device credentials.
- Preserve face and hazard event history.
- Preserve revocation status.
- Work for existing databases.
- Work for fresh databases.

Do not recreate installation records unnecessarily.

---

# Part B — Guard Desktop Updates

## 9. Header Control

Use the exact label:

`Room Connection`

Before room connection:

- Show `Room Connection`.

After room connection:

- Show room name and connection state using the existing header visual language.

Examples:

- `Warehouse — Connected`
- `Warehouse — Disconnected`

Clicking the room connection area must open the Room Connection dialog in both connected and disconnected states.

All text must update immediately when the application language changes.

---

## 10. Replace the Old Registration Dialog

Remove the old room registration UI that requests:

- Room name input
- Room ID input
- Activation code
- Fake license
- Commercial license
- Entitlement details

Create or update a modal Room Connection dialog.

The dialog must match existing Guard dialogs:

- Color palette
- Border style
- Corner radius
- Title bar
- Typography
- Input fields
- Spacing
- Buttons
- Shadows
- Qt 5.7 compatibility

Suggested layout:

```text
Room Connection

[ Search rooms...                              ]

┌──────────────────────────────────────────────┐
│ Warehouse                                    │
│ Main Office                                  │
│ Storage Room                                 │
│ Server Room                                  │
└──────────────────────────────────────────────┘

Status and error message

[Refresh]                     [Cancel] [Connect]
```

When already connected, display:

- Current room name
- Room ID where useful
- Backend URL
- Connection status
- Last successful connection time where available

Connected mode actions:

- Refresh Status
- Disconnect Room
- Close

Do not make a connected installation appear freely reassignable.

---

## 11. Search Box

Add a room-search field above the list.

Placeholder:

`Search rooms...`

Requirements:

- Clear the field whenever the dialog is newly opened.
- Filter locally as the user types.
- Do not request the backend for every keystroke.
- Match case-insensitively.
- Trim leading and trailing spaces.
- Support partial substring matching.
- Keep the current selection when it remains visible.
- Clear the selection when it is filtered out.
- Show `No rooms found` when the filter has no match.
- Show a separate empty state when the backend has no rooms.
- Disable Connect until a room is selected.
- Support keyboard navigation.
- Enter connects the selected room.
- Escape closes the dialog.

Prefer Qt model/view:

- `QStandardItemModel` or a dedicated model
- `QSortFilterProxyModel`
- `QListView`

Avoid rebuilding one QWidget per room after every keystroke.

All implementation must compile with Qt 5.7.

---

## 12. Asynchronous Room Loading

When the dialog opens:

1. Validate the configured backend URL.
2. Call `GET /api/health` asynchronously.
3. Call `GET /api/guard/available-rooms` asynchronously.
4. Display loading state.
5. Populate the room model.
6. Enable Refresh after completion.

Required UI states:

- Loading rooms
- Rooms loaded
- No rooms configured
- No rooms found
- Backend unavailable
- Invalid backend URL
- Request timed out
- Connecting
- Connected
- Connection failed
- Already connected
- Recovery required

Do not use:

- Nested `QEventLoop`
- Blocking network calls
- Synchronous waits on the UI thread

Do not block:

- Camera decoding
- GuardVision processing
- Recording
- Alarms
- Main UI

Protect against callbacks after the dialog or owning QObject is destroyed.

Prevent duplicate concurrent room-list requests.

---

## 13. Stable Local Identity

Generate and store `clientInstallationId`.

Requirements:

- Generate with `QUuid::createUuid()`.
- Store a normalized UUID string.
- Persist in QSettings or the project’s existing non-sensitive settings store.
- Preserve it across upgrades.
- Do not regenerate it after ordinary room disconnection.
- Reset only through an explicit administrative recovery workflow.

Generate the hardware fingerprint using:

```text
v1:<sha256(normalizedHardwareId UTF-8)>
```

Requirements:

- Reuse the existing stable Hardware ID implementation.
- Do not reintroduce old licensing classes.
- Do not transmit raw hardware identifiers.
- Do not log the raw Hardware ID.
- Do not use the fingerprint as an authentication credential.

---

## 14. Connect Request

When the user clicks Connect:

1. Confirm a room is selected.
2. Disable Connect and Refresh.
3. Prevent repeated submission.
4. Display connecting progress.
5. Build the final request contract.
6. Include local cameras with confirmed directions.
7. Send asynchronously.
8. Parse and validate the complete backend response.
9. Store local values only after all required response fields are valid.
10. Store the device credential securely.
11. Save non-sensitive installation and room metadata.
12. Apply backend camera mappings.
13. Request the first JWT.
14. Update the header immediately.
15. Close the dialog after complete success.

Persist as non-sensitive settings:

- Backend URL
- clientInstallationId
- installationId
- roomId
- roomName
- Backend camera mappings
- Last successful connection time

Persist securely:

- deviceCredential

Do not persist:

- JWT
- Raw Hardware ID
- Device credential in QSettings
- Camera passwords in plaintext

If any step fails, do not leave a partially registered local state.

---

## 15. Startup Restoration

On Guard startup:

1. Load backend URL.
2. Load installationId.
3. Load roomId and roomName.
4. Load the secure device credential.
5. Call the token endpoint.
6. Store the access token in memory.
7. Restore the backend session.
8. Fetch canonical camera mappings.
9. Start camera and installation heartbeats.
10. Start registry and notification-settings refresh.
11. Enable face and hazard event delivery.
12. Update the header state.

Do not open the Room Connection dialog when restoration succeeds.

When restoration fails:

- Preserve local camera monitoring.
- Preserve GuardVision processing.
- Preserve recording and local alarms.
- Display a disconnected or recovery-required state.
- Do not continuously display modal errors.
- Do not automatically erase local credentials.
- Allow the user to open Room Connection for diagnostics.

---

## 16. Room Disconnect

When the user clicks Disconnect Room:

1. Show confirmation.
2. Send the authenticated disconnect request.
3. Wait for backend confirmation.
4. Stop backend-specific periodic tasks.
5. Clear the in-memory JWT.
6. Remove the protected device credential.
7. Clear:
   - installationId
   - roomId
   - roomName
   - backend camera mappings
8. Preserve:
   - local cameras
   - local connection settings
   - GuardVision settings
   - recording settings
   - detection settings
9. Return the dialog to room-selection mode.
10. Update the header to `Room Connection`.

Do not delete historical backend events.

---

## 17. Camera Mapping

During connection:

- Use `clientCameraId` for idempotent mapping.
- Store `clientCameraId → backendCameraId`.
- Use backendCameraId for:
  - Camera heartbeats
  - Face events
  - Hazard events
- Preserve camera direction.
- Preserve local-only camera fields.
- Preserve the maximum four-camera rule.
- Do not restart active streams unnecessarily.
- Do not fall back to local camera IDs for backend communication after connection.

Apply synchronization changes carefully so unrelated camera-field updates do not stop active streams.

---

## 18. Translation

Add or update localized text for:

- Room Connection
- Search rooms...
- Loading rooms
- No rooms configured
- No rooms found
- Refresh
- Connect
- Connecting
- Connected
- Disconnected
- Disconnect Room
- Backend unavailable
- Invalid backend URL
- Request timed out
- Connection failed
- Recovery required
- Current room
- Device name
- Confirmation messages

Update all supported translation source files.

Ensure the existing `lrelease` build step regenerates `.qm` files.

Existing camera-status and header text must still refresh when the language changes.

---

# Part C — Frontend Updates

## 19. Preserve Existing Room Administration

The frontend must continue to allow administrators to:

- Create rooms
- Edit rooms
- List rooms
- Disable or delete rooms according to existing behavior

Do not add:

- Commercial licensing
- Product trial management
- Room activation-code administration
- Guard license generation

Confirm that active rooms created from the frontend appear in:

`GET /api/guard/available-rooms`

Update frontend room types only when required to support active/selectable state consistently.

Do not modify unrelated:

- Camera administration
- User administration
- Room orders
- Face events
- Hazard events
- Notification settings
- Realtime behavior

No new frontend Room Connection page is required.

---

# Cleanup and Refactoring

After completing the functional work:

1. Remove obsolete room registration dialog files.
2. Remove activation-code request fields.
3. Remove fake-license request fields.
4. Remove dead registration services and methods.
5. Remove obsolete endpoint constants.
6. Remove unused translations.
7. Remove duplicated room parsing.
8. Centralize room response mapping.
9. Reuse shared structured API error parsing.
10. Reuse the existing secure credential abstraction.
11. Deduplicate connection-state handling.
12. Remove unused includes and imports.
13. Remove stale tests and mocks.
14. Update qmake source lists.
15. Update backend routes and modules.
16. Update documentation.
17. Format code using the existing project tools.

Do not:

- Change unrelated architecture.
- Rewrite camera runtime architecture.
- Change GuardVision logic.
- Change hazard or face event semantics.
- Change recording behavior.
- Introduce new licensing code.
- Add broad speculative abstractions.

---

# Backend Tests

Add or update tests covering:

1. Available rooms returns only safe fields.
2. Active rooms are returned.
3. Disabled or deleted rooms are excluded.
4. Initial room connection succeeds.
5. Invalid room ID returns a clear error.
6. No commercial license is required.
7. No activation code is required.
8. No legacy API key is required.
9. Validation errors do not return generic Unauthorized.
10. New installation receives a device credential.
11. Only the credential hash is stored.
12. Repeated identical requests do not duplicate installations.
13. Repeated camera submissions do not duplicate cameras.
14. Four-camera maximum is enforced.
15. Invalid direction is rejected.
16. Revoked installations cannot reconnect.
17. Valid device credentials obtain JWTs.
18. Invalid credentials are rejected.
19. Disconnect preserves historical events.
20. Raw hardware values are not stored or logged.
21. Migrations work from existing database states.

---

# Guard Verification

Verify:

1. Header displays Room Connection.
2. Clicking the header opens the dialog.
3. Old activation-code and fake-license fields are absent.
4. Room list loads asynchronously.
5. Search is case-insensitive.
6. Search trims spaces.
7. Search supports substring matches.
8. No-match state works.
9. Connect is disabled without selection.
10. Enter connects the selected room.
11. Refresh reloads rooms.
12. Duplicate requests are prevented.
13. clientInstallationId remains stable across restart.
14. Hardware hash format is stable.
15. Device credential uses protected storage.
16. JWT is memory-only.
17. Successful connection updates the header.
18. Startup restores the room session silently.
19. Failed restoration preserves local monitoring.
20. Disconnect returns to selection mode.
21. Canonical camera mappings persist.
22. Qt 5.7, 5.12, and 5.14 compatibility is preserved.

---

# Required Quality Checks

## Backend

Run:

- Database migration checks
- Unit tests
- API tests
- Integration tests
- Authentication tests
- TypeScript checking
- Lint
- Formatting
- Production build

## Frontend

Run:

- TypeScript/Svelte checking
- Unit tests
- Role-permission tests where relevant
- Lint
- Formatting
- Production build

## Guard

Run where available:

- qmake validation
- Translation validation
- Resource validation
- Qt debug build
- Qt release build
- Qt 5.7 compatibility checks
- Qt 5.12 compatibility checks
- Qt 5.14 compatibility checks
- Camera and GuardVision regression checks

Do not claim checks passed when they were not executed.

---

# Acceptance Criteria

The task is complete only when:

- Rooms created by the frontend are available to Guard.
- Guard displays the Room Connection header control.
- The Room Connection dialog lists active backend rooms.
- The dialog contains a local search box.
- Search is immediate and case-insensitive.
- Search does not call the backend for each keystroke.
- User can select and connect to a room.
- No activation code is required.
- No commercial license is required.
- No fake-license field remains.
- Guard sends a stable clientInstallationId.
- Guard sends only a protected hardware fingerprint.
- Backend stores no raw Hardware ID.
- Backend returns a one-time device credential.
- Guard stores the credential securely.
- Backend stores only its hash.
- Later launches authenticate using installationId and deviceCredential.
- Hardware ID is not used as the permanent login secret.
- JWT remains short-lived and memory-only.
- Camera mappings use backend-generated camera IDs.
- Repeated room connection requests are idempotent.
- Duplicate camera records are not created.
- Current room and connection state appear in the header.
- Changing rooms requires explicit disconnection.
- Existing camera monitoring continues during temporary backend failures.
- GuardVision, recording, alarms, face events, and hazard events remain unchanged.
- Frontend room administration remains functional.
- Relevant tests and builds pass.

---

# Final Implementation Report

After implementation, provide:

1. Summary of changes.
2. Backend files added, changed, and removed.
3. Guard files added, changed, and removed.
4. Frontend files changed.
5. Database migration details.
6. Final endpoint list.
7. Final request and response payloads.
8. Installation identity and uniqueness rules.
9. Secure credential behavior.
10. Startup restoration behavior.
11. Disconnect and reassignment behavior.
12. Search implementation details.
13. Camera mapping behavior.
14. Tests run and exact results.
15. Build, lint, formatting, and type-check results.
16. Qt or Windows behavior that could not be tested.
17. Remaining security or recovery concerns.
