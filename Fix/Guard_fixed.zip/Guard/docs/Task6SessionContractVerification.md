# Room Registration and Device Session Verification

## Request contract

| Endpoint | Fields sent by Guard |
|---|---|
| `POST /api/guard/installations/activate` | `roomIdentifier`, `activationCode`, `hardwareId`, `deviceName`, `guardVersion`, `cameras` |
| `POST /api/guard/auth/token` | `installationId`, `deviceCredential` |

There is no product-license endpoint or commercial entitlement payload.

## Session lifecycle

1. Activation validates and persists installation metadata plus the protected device
   credential.
2. Guard exchanges the credential for a short-lived JWT before declaring the session
   authenticated.
3. JWT refresh uses `expiresAt` with the existing `expiresIn` compatibility fallback.
4. Camera mappings prefer `backendCameraId` and preserve stable `clientCameraId`.
5. Revoked/invalid credentials clear the local authenticated session; temporary
   network failures do not stop local monitoring.
