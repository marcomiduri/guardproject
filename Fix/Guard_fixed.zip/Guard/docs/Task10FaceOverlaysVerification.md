# Task 10 Face Overlays, Uploads, and Access Voices Verification

## Scope

Task 10 delivers immediate face overlays in every `CameraView`, one backend event per face appearance, multipart frame/face images, and admin-controlled incoming access-warning audio.

## Live backend contract (canonical for Guard)

Guard uses the deployed backend routes and payload shapes below. These match
`Web/backend/src/routes/guard.ts`, `Web/backend/docs/backend-tasks.md`, and
`Web/backend/docs/GuardBackendIntegration.md`.

| Area | Canonical endpoint / shape |
|---|---|
| Recognized face | `POST /api/guard/events/appeared` with multipart `eventData`, `frameImage`, `faceImage` |
| Unknown face | `POST /api/guard/events/unknown-appeared` with the same multipart fields |
| `faceRegistryId` | Positive integer (matches `users.face_registry_id`) |
| `cameraId` | Backend camera UUID/string from `backendCameraId` |
| Access decision | Recognized response includes `approved` for incoming cameras |
| Notification policy | `GET /api/guard/notification-settings` → `{ "settings": { notifyUnknownIncoming, notifyUnapprovedIncoming } }` |

## Implemented behavior

| Requirement | Implementation |
|---|---|
| Immediate overlays | `CameraRuntimeController::onFaceEvent()` updates `CameraView` before any network I/O |
| Recognized label | `faceOverlayLabel()` → `John Smith 89%` |
| Unknown label | `faceOverlayLabel()` → `UNKNOWN` |
| Track merge/remove | Overlay merge by `trackId`; `TrackLost` clears overlay and coordinator state |
| Local dedupe key | `localFaceTrackCameraKey():trackId` |
| One event per appearance | `recognizedSent` / `unknownSent` flags; unknown delay (1.5s) or track lost |
| Unknown → recognized correction | Recognized upload sends optional `supersedesEventId` |
| Backend camera ID | `eventCameraId()` returns backend ID only; registered cameras without mapping skip upload |
| Multipart images | `annotateFaceFrame()` + `cropFace()` JPEGs attached to both endpoints |
| Approved users silent | Unapproved voice only when backend returns `approved=false` |
| Admin policy gating | `shouldPlayUnknownIncomingVoice()` / `shouldPlayUnapprovedIncomingVoice()` |
| Outgoing cameras | Upload proceeds; incoming-only voice helpers block outgoing warnings |
| Packaged access audio | `:/audio/access_denied_unknown.wav` and `:/audio/access_denied_unapproved.wav` via `PlaySound`; TTS then beep fallback |
| Upload not blocked by sound | Voice policy gates audio only; `submitMultipart()` always runs when upload is allowed |

## Automated check

```bat
cd Desktop\Guard\tests\face-overlays
mkdir build
cd build
qmake ..\face-overlays-smoke.pro CONFIG+=release
nmake release
release\guard-face-overlays-smoke.exe
```

The smoke test verifies overlay labels, face-track keys, upload gating, one-upload-per-track decision helpers, and access-voice policy helpers.

Regenerate packaged access WAV files after message text changes:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File Desktop\Guard\scripts\generate-access-alert-wav.ps1
```

## Build regression note

Guard Release should be rebuilt after these changes so the new qrc audio resources are embedded.
