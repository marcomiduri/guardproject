# Guard Camera Runtime Architecture

## Ownership

`MainWindow` owns one GuardVision facade and one `GuardVisionEventListenerAdapter`. It creates one `CameraRuntimeController` for each accepted `CameraWidget`, up to the grid limit of four.

Each controller owns:

- its immutable GuardVision `streamId`;
- the current `CameraUiModel` connection settings;
- `CameraDetectionSettings`;
- `MediaSourceController`;
- `MotionVideoRecorder`;
- independent GuardVision stream generation, media-source generation, and submission counters;
- camera capability state;
- motion, face, and hazard overlay state;
- a bounded camera log history.

## Frame flow

```text
HCNetSDK or RTSP
  -> MediaSourceController
  -> decoded QImage preview
  -> FrameSubmissionPipeline
  -> GuardVision::submitFrame
  -> software/onboard-assisted analytics
  -> GuardVisionEventListenerAdapter
  -> queued Qt signal
  -> matching CameraRuntimeController
  -> matching CameraView overlay
```

The source generation is checked before frames, packets, capabilities, and onboard candidates are accepted. GuardVision events are checked against the separate GuardVision stream-registration generation. Late callbacks from either an old source or an old GuardVision registration cannot update a restarted camera.

## Detection settings flow

```text
CameraWidget::settingsRequested(cameraId)
  -> MainWindow::openCameraSettings(cameraId)
  -> CameraSettingsDialog edits a temporary copy
  -> Cancel: discard
  -> OK: validate
  -> CameraRuntimeController::applyDetectionSettings
  -> GuardVision setMotionConfig / setFaceConfig / setHazardConfig
  -> MotionVideoRecorder::setEnabled
```

When one GuardVision update fails, the controller rolls back any earlier config changes from the same dialog acceptance. It only commits its local settings after all requested GuardVision updates succeed.

Detection changes do not reconnect the media source.

## Onboard availability

Onboard and hybrid options require all of the following for the selected camera:

1. HCNetSDK source.
2. Camera currently connected.
3. Alarm subscription active.
4. Corresponding capability not marked unsupported.

Motion, face, and hazard availability are evaluated independently. Hazard availability accepts either onboard fire or onboard smoke support.

## Recording isolation

Each controller has its own recorder. Only events matching both the controller stream ID and its active GuardVision registration generation are accepted. The controller then translates that current GuardVision event to the recorder's active media-source generation. Encoded packets and decoded fallback frames remain tagged only with the media-source generation.

`MotionVideoRecorder` keeps its existing worker-thread model. Directory creation, MP4 finalization, metadata writing, stale partial handling, and retention cleanup happen outside decode and GuardVision callback paths.

Recordings use a camera/date layout:

```text
<recording-root>/<sanitized-camera-id>/<yyyy-MM-dd>/<yyyyMMddTHHmmss.zzzZ>_motion_<event-id>.mp4
```

Temporary files remain in the same directory:

```text
*.part.mp4
*.part.json
```

The final `.json` sidecar is written only after video finalization. If a recording is interrupted or cannot be finalized, metadata is marked `complete=false` with a normalized reason such as `application-shutdown`, `camera-disconnected`, `source-generation-changed`, `encoded-packet-drop`, `timestamp-discontinuity`, `writer-error`, or `file-rename-failed`.

The recording root is coordinated by the shared `RecordingStorageManager`. The footer application Settings dialog persists the optional user root with `QSettings` key `recording/rootPath`. Resolution is centralized and follows:

```text
GUARD_RECORDING_ROOT
-> saved user setting
-> GUARD_RECORDING_PORTABLE=1
-> QStandardPaths::AppLocalDataLocation/recordings
-> QStandardPaths::MoviesLocation/Guard/recordings
-> <Guard.exe>/recordings
```

Recorders resolve complete paths once when a recording starts. A root change affects only future recordings; active clips remain in their original root. Maintenance scans run at startup, periodically, after finalization, after root changes, and on low-disk requests. GuardVision motion and alarm events carry the GuardVision registration generation. After that generation is validated, the controller forwards the current media-source generation to its recorder before a clip can start, update, or end.

Removing a camera performs this order:

1. Close its modeless logs dialog.
2. Destroy its controller.
3. Stop recorder/source and unregister its GuardVision stream.
4. Remove its tile and model.

Other camera controllers remain active.


## Test-mode source override

`Guard.exe --test` enables a per-camera media-file override in `CameraSettingsDialog`. Each `CameraRuntimeController` owns its own `CameraTestSourceSettings`, so selecting a file for one camera never changes another camera. An empty media path uses the configured camera; image and video test modes are inferred from the selected file extension.

When the override is `ImageFile` or `VideoFile`, `CameraRuntimeController::configureSource()` sends the selected path through the existing `MediaSourceController` file worker. The frames then follow the normal pipeline:

```text
FileDecoderWorker
    -> MediaSourceController
    -> CameraRuntimeController
    -> FrameSubmissionPipeline
    -> GuardVision
```

Encoded packets from compatible video files continue to flow to that camera's `MotionVideoRecorder`; decoded RGB frames remain the bounded fallback. Images repeat continuously. Videos loop continuously, matching TestLib behavior.

File test sources have no onboard alarm channel. The settings dialog therefore permits software detection but disables onboard and hybrid modes. A source override change restarts only its owning controller when active. Normal launches do not expose or use the override.


## Application-level backend event flow

`CameraRuntimeController` remains responsible for one camera's source, GuardVision stream, overlays, and motion recorder. It does not perform HTTP requests or play application sounds directly.

Face and hazard occurrences are raised to one process-wide coordinator:

```text
CameraRuntimeController
    -> GuardFaceOccurrence / GuardHazardOccurrence
    -> GuardEventCoordinator
       |-> GuardBackendClient
       |-> LocalAlertService
       |-> CameraAlarmService
       `-> OfflineEventQueue
```

This separation keeps camera callbacks fast and gives all four cameras one consistent deduplication, alarm, retry, and authentication policy.

### Event-associated frames

Each controller retains a small bounded recent-frame list tagged with submission sequence and timestamp. An analytics event first resolves an exact matching sequence, then the nearest timestamp, and finally the latest frame. Snapshot rendering operates on a copy and never mutates the frame used by GuardVision or CameraView.

### Face-track isolation

The controller preserves GuardVision's track ID, identity ID, display name, similarity, and bounds. The coordinator uses `backendCameraId + trackId` as the cross-camera key. Camera 1 track 42 and Camera 2 track 42 are therefore independent.

CameraView overlays are updated immediately on the local event path. Backend latency cannot delay or remove a displayed identity label.

### Hazard alarm isolation

The global local alarm manager tracks active keys by camera and hazard type. An Ended event for one camera removes only that key; it cannot silence another active camera. Acknowledgment stops the repeating PC sound without changing the active GuardVision overlay.

### Backend and local IDs

The immutable local `CameraUiModel::id` remains the GuardVision stream identity and controller-map key. `clientCameraId` correlates activation retries. `backendCameraId` is used only for backend camera, heartbeat, face, and hazard records. Synchronizing a backend ID does not recreate the GuardVision stream ID.


## Safe source disconnect order

Camera disconnect follows one ordered teardown for live RTSP, HCNetSDK, video-file, and repeating-image sources:

1. Invalidate the controller source generation so queued frames are rejected.
2. Stop/finalize the recorder for that source generation.
3. Request decoder/camera-source stop and wait for producer-side quiescence without a nested event loop.
4. Unregister the GuardVision stream only after no decoder thread can submit another frame.
5. Clear overlays and the displayed frame, then publish the disconnected state.

This prevents the repeating-image decoder from racing GuardVision face-session destruction. Recording remains source-generation isolated, video files continue to loop while connected, still images continue to repeat at the test cadence, and all source types use the same GuardVision submission path.
