# Room connection and face-registry synchronization implementation

## Room connection

Guard now serializes room connection requests through `roomConnectionRequestToApiJson()`. The payload contains:

- `roomId`
- stable `clientInstallationId`
- `deviceName`
- Guard version
- local camera data

It intentionally contains no Hardware ID, Hardware ID hash, activation code, or license key.

The saved session includes a `userDisconnected` flag. An explicit disconnect:

1. calls `POST /api/guard/installations/disconnect`;
2. retains installation ID, room ID/name, `clientInstallationId`, camera mappings, and the protected device credential;
3. clears the in-memory JWT and stops the refresh timer;
4. exposes a Reconnect action.

Reconnect exchanges the saved credential for a new short-lived JWT and restores the same backend installation without administrator action.

## Face registry synchronization

Guard uses versioned pull plus realtime invalidation:

1. after authentication, room connection, or reconnect, request `/api/guard/faces/version`;
2. download `/api/guard/faces` only when the version or scope changed, or no valid registry is loaded;
3. listen for `face_registry.updated` over `/api/guard/ws` when Qt WebSockets is available;
4. retain the existing 60-second version poll as a reliable fallback;
5. parse and validate the complete replacement before applying it;
6. call GuardVision `setFaceRegistry()` once for the complete registry;
7. commit the local version only after GuardVision accepts the replacement.

A failed or stale download leaves the previous valid registry active. A valid empty registry is applied intentionally. Camera decoding, tracking, recording, and hazard processing are not stopped during refresh.

Qt WebSockets support is optional at build time. Builds without the module continue to synchronize through polling.

## Tests and build status

The face-registry loader and session-response smoke tests were updated to cover version/scope metadata, an empty registry, and omission of hardware fields from room-connect payloads.

A Qt/qmake toolchain was not available in the execution environment, so the Guard C++ smoke tests and full application build were not executed here.
