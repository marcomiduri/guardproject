# Active-source system-tray Exit crash fix

## Field result that isolated the remaining fault

The previous shutdown patch succeeded when every CameraWidget was disconnected before choosing **Exit** from the system tray, but the process still crashed when an image or video source was actively playing.

That difference showed that GuardVision stream retention was no longer the only shutdown concern. The camera log message `Media source quiesced` proved that frame production had stopped, but it did not prove that every asynchronous thread owned by the camera runtime had exited.

## Root cause addressed

Two process-lifetime workers could still be alive after an active source became quiescent:

1. `MediaSourceController` file/RTSP `QThread` event loops.
2. `MotionVideoRecorder`'s `std::thread`, which can still be draining decoded frames or finalizing an MP4.

Calling `QCoreApplication::quit()` while either worker was still active allowed Qt, OpenCV, FFmpeg, or tray UI teardown to race those workers. Manually disconnecting all cameras gave the queues enough time to settle, which explains why that sequence did not crash.

## Implementation

`CameraRuntimeController::prepareForApplicationShutdown()` now performs this final-exit order:

1. Disconnect GuardVision, media-source, and recorder callbacks targeting the controller.
2. Stop the active source and wait for decoder quiescence.
3. Quit and join file/RTSP decoder `QThread` event loops.
4. Shut down and join the motion recorder worker thread.
5. Remove stale queued Qt `MetaCall` deliveries.
6. Mark the camera runtime prepared for final process shutdown.

The shared GuardVision/vendor runtime remains intentionally process-lifetime and is not destructed from tray Exit, preserving the earlier native-runtime crash workaround.

`MainWindow::quitApplication()` now schedules `QCoreApplication::quit()` on the next event-loop turn after coordinated shutdown. This lets the system-tray `QAction::triggered` call stack unwind before Qt destroys the tray menu and top-level widgets.

## Expected camera log tail

For each camera that had created an image/video decoder, final Exit should now include:

```text
Media source quiesced during controller destruction.
GuardVision stream retained for coordinated application shutdown.
Media decoder worker threads joined for application shutdown.
Motion recording worker joined for application shutdown.
Camera runtime prepared for coordinated application shutdown.
```

## Scope

- Normal CameraWidget Disconnect/Connect behavior is unchanged.
- Safe source replacement is unchanged.
- GuardVision retained-stream reconnect behavior is unchanged.
- Backend hazard and face event delivery is unchanged.
