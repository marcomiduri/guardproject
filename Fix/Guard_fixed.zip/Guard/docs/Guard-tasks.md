# Guard Transitional Integration Scope

This document supersedes the old eleven-task plan for the temporary no-licensing test
build. Commercial licensing will be redesigned separately.

## Global requirements

- Qt/qmake/C++ Windows application compatible with Qt 5.7, 5.12, and 5.14.
- Maximum four cameras using the existing shared GuardVision architecture.
- Asynchronous backend traffic must never block camera processing, recording, alarms,
  or the UI.
- Backend failure must not stop local monitoring.
- Credentials, camera passwords, Hardware ID components, and face embeddings must
  never be logged.
- UTC ISO-8601 timestamps and backend camera IDs remain canonical for backend events.

## Current work areas

1. Stable installation Hardware ID and protected device credentials.
2. Application Settings: Server, Alerts, and Recording.
3. Asynchronous backend client and device session.
4. Room registration and installation revocation.
5. Camera direction, synchronization, and heartbeats.
6. Face-registry refresh, overlays, face events, and access warnings.
7. Hazard events, local alarms, camera capabilities, and offline retry.

## Explicitly absent

- `GuardAppLicense-v1`.
- Product trial or entitlement state.
- Product-license key entry, activation, storage, or backend submission.
- License-dependent camera/event operation gates.

The room activation-code field is retained temporarily in Guard registration while a
replacement enrollment model is designed. The web frontend does not administer those
codes in this transitional build.
