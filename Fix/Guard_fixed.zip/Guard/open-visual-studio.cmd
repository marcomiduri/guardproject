@echo off
setlocal
set "SLN=%~dp0Guard.sln"
if not exist "%SLN%" (
    echo Guard.sln not found.
    exit /b 1
)
if not exist "%~dp0_build\guard-debug\moc\mocinclude.opt" (
    echo Guard Qt build folders are missing. Running prepare script...
    call "%~dp0scripts\prepare-vs-build.cmd" -Configuration all || exit /b 1
)
start "" "%SLN%"
