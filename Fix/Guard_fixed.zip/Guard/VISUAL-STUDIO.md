# Guard — Visual Studio 2019

Guard is a Qt project. The installer ships `Guard.sln` and `Guard.vcxproj`, but Qt moc/uic/rcc folders under `_build\` must be generated once on your PC after install.

## After DABoard setup (recommended)

If you left **"Generate Visual Studio 2019 projects"** checked during install, Guard should already be prepared.

If not, run either:

```bat
cd Desktop\scripts
configure-installed-sources.cmd
```

or from this folder:

```bat
GENERATE-VS2019-PROJECTS.cmd
```

## Open in Visual Studio 2019

```
Desktop\Guard\Guard.sln
```

Select **Debug | x64** or **Release | x64**, then build.

Double-click `open-visual-studio.cmd` to prepare Qt folders if needed and open Visual Studio.

## Requirements

- Visual Studio 2019 with **Desktop development with C++**
- Qt 5.14.x MSVC 64-bit (for example `C:\Qt\Qt5.14.2\5.14.2\msvc2017_64`)
- GuardVision built first (`Desktop\GuardVision\bin\Debug\guardvision.lib` and Release)

## PowerShell on offline PCs

If Windows blocks `.ps1` files ("running scripts is disabled"), use the **`.cmd` wrappers** in each `scripts` folder (for example `build-debug.cmd`, `prepare-vs-build.cmd`). They launch PowerShell with `-ExecutionPolicy Bypass`.

Optional one-time setup: `Desktop\scripts\enable-ps1-scripts.cmd`

Install to any writable folder (default: `Documents\DABoard`). You choose the location during setup.

Run `configure-installed-sources.cmd` or `GENERATE-VS2019-PROJECTS.cmd` once after install so Qt build folders match your path. Paths with spaces are handled automatically. Avoid `Program Files` if you lack write permission there.
