# Guard

Guard is the four-camera Qt Widgets application built on the completed GuardVision library. Its per-camera runtime mirrors the proven TestLib camera flow while preserving the Guard multi-camera UI.

## Runtime model

- One process-wide `guardvision::GuardVision` instance.
- `GuardVisionConfig::maxStreams = 4`.
- Up to four `CameraWidget` tiles.
- One independent `CameraRuntimeController` per camera.
- One independent media source, media-source generation, GuardVision registration generation, detection configuration, overlay cache, log buffer, and motion recorder per camera.
- GuardVision callbacks enter one Qt adapter and are routed to the matching controller by `streamId` using queued Qt signals.

Disconnecting, editing, or changing detection settings for one camera does not stop the other cameras. Explicitly removing a camera briefly pauses all active producers so GuardVision can safely unregister that camera's native stream, then Guard automatically restarts the peer cameras that were active.

Guard keeps two generation domains per camera: GuardVision event generations identify a GuardVision stream registration, while media-source generations identify decoded frames and recorder packets. They are validated independently and are never compared as if they were the same counter.

### Stream ownership and room switching

A GuardVision stream belongs to exactly one `CameraRuntimeController` and is derived from that camera's stable local ID. Streams are never transferred or recycled between controllers.

- Ordinary camera **Disconnect/Connect** may retain and reactivate the same controller-owned stream.
- Explicit camera removal pauses all producers, waits for GuardVision idleness, unregisters the removed stream, and restarts previously active peers.
- Room switch/disconnect stops every old-room producer, unregisters all old-room streams, destroys the old controllers, and then loads the new room.
- New-room streams are created lazily on the first Connect for each new controller.
- If any old stream fails to unregister after bounded retries, Guard aborts workspace replacement instead of consuming additional stream slots.

Room changes also clear old-room hazard audio, indicator state, face tracks, and active incidents before new-room callbacks are accepted. See `docs/RoomSwitchCoordinatedStreamRecreation.md`.

## Backend and room integration

This transitional build contains no commercial product licensing, product trial,
entitlement parsing, or License tab. Application Settings contains **Server**,
**Alerts**, **Recording**, and **Diagnostics** tabs.

The header **Register Room** action opens the existing modal registration dialog. It
uses the stable installation Hardware ID, exchanges the current registration fields
for a protected per-installation device credential, and obtains short-lived JWTs
silently. The activation-code field remains temporarily while the replacement
enrollment model is designed.

Each camera has a required **Incoming** or **Outgoing** direction. Guard keeps a
local/client camera ID for retry-safe correlation and a canonical backend camera ID
for events and heartbeats. Camera passwords and the device credential are never
stored as plaintext settings.

Guard refreshes the backend face registry, displays identified names locally, sends
face and hazard events, applies backend access decisions, plays local warning audio,
and persists retryable events to a bounded offline queue.

See `docs/GuardBackendIntegration.md`, `docs/LegacyLicensingRemoval.md`,
`docs/GuardImplementationStatus.md`, `docs/RegisteredFaceCameraConnectCrashFix.md`,
`docs/CameraFileLogging.md`, and `docs/RoomReconnectAndDisconnectedMonitoringCrashFix.md`.

## Per-camera persistent logs

Every `CameraRuntimeController` keeps the same recent in-memory log shown by the camera tile's **Logs** dialog and also appends every entry immediately to a persistent UTF-8 text file. The current file uses the camera display name:

```text
%LOCALAPPDATA%/<organization>/<application>/logs/cameras/<camera-name>.log
```

On Qt this location is resolved with `QStandardPaths::AppLocalDataLocation`. Set `GUARD_LOG_ROOT` to override the root; camera files are then written under `<GUARD_LOG_ROOT>/cameras`. Windows-invalid filename characters are replaced with `_`. If two configured cameras have the same display name, the second file receives a short camera-ID suffix so their diagnostics are never mixed.

Each line is flushed after it is written so the latest connect, decoder, GuardVision, recording, and teardown messages remain available after an unexpected process crash. Renaming a camera starts a new log file that matches the new name and preserves the previous file. The Logs dialog shows the exact file path and provides **Open Log File** and **Open Log Folder** actions. No camera password, JWT, device credential, face embedding, or license key is written by this feature.

File logging can be enabled or disabled in **Application Settings → Diagnostics**. It is enabled by default. Disabling it immediately flushes and closes active camera log files while preserving both existing files and the in-memory Logs dialogs. Re-enabling it resumes file output for every current camera without changing camera connection or analytics state.

## Camera sources

Guard supports the camera types exposed by `CameraDialog`:

- Hikvision through HCNetSDK and PlayCtrl.
- Generic RTSP through FFmpeg.

Both paths decode frames for preview and GuardVision submission. RTSP and HCNetSDK forward encoded packets to the camera's recorder when usable packets are available. The recorder uses decoded-frame fallback when encoded remuxing is unavailable.

## Per-camera Detection settings

The **Settings** button in each `CameraWidget` footer opens a modal `CameraSettingsDialog`. The dialog contains the TestLib Detection group:

- Motion detection
- Face detection
- Hazard detection
- Record Video for Motion

Each detection combo contains:

- No detection
- Software detection
- Onboard detection
- Hybrid detection

The settings are stored independently for each camera. Pressing **Cancel** makes no change. Pressing **OK** validates and applies detection-only changes to the matching GuardVision stream without reconnecting the camera. When the camera is disconnected, settings are retained and used at its next stream registration. In `--test` mode, changing the selected test source restarts only that camera when it is already running.

Onboard and hybrid entries are available only for a connected HCNetSDK camera whose alarm subscription is active and whose corresponding capability is not unsupported. Availability is evaluated separately for every camera.

Hazard detection follows TestLib behavior: any non-disabled hazard mode requires `models/fire_smoke.onnx` to be resolvable at runtime.


## Per-camera test mode

Launch Guard with:

```powershell
.\Guard.exe --test
```

In test mode, each camera card's **Settings** dialog adds a **Test Source** group with a per-camera media file field. Leave the field empty to use the configured camera, or select a supported media file. Guard detects the test source mode from the selected file extension:

- Image file (`.jpg`, `.jpeg`, `.png`, `.bmp`)
- Video file (`.mp4`, `.avi`, `.mov`, `.mkv`)

Test images repeat continuously so GuardVision can exercise face and hazard detection. Test videos loop using the same file-decoding and encoded-packet path as TestLib, so they can exercise software motion detection and `Record Video for Motion` with encoded remuxing or decoded-frame fallback.

A file source supports software detection only. The dialog disables onboard and hybrid selections while an image or video test source is selected. Changing the test source while that camera is running restarts only that camera; the other camera pipelines continue unchanged.

Because the source setting is held by each `CameraRuntimeController`, four cameras may run different inputs simultaneously—for example, one motion-recording video, one face image, one fire image, and one smoke image.

Without `--test`, the Test Source group is hidden and Guard uses the configured HCNetSDK or RTSP camera source exactly as before.

## Motion recording

`Record Video for Motion` controls the selected camera's own `MotionVideoRecorder`.

- Two-second pre-roll
- Five-second post-roll
- Bounded worker queues
- Encoded packet remuxing preferred
- Decoded-frame fallback
- `.part.mp4` finalization
- Source-generation protection

New recordings are stored in a camera-first UTC date tree:

```text
<recording-root>/
├─ <camera-id>/
│  └─ 2026-06-29/
│     ├─ 20260629T153045.123Z_motion_a82f31c0d4e5.part.mp4
│     ├─ 20260629T153045.123Z_motion_a82f31c0d4e5.mp4
│     └─ 20260629T153045.123Z_motion_a82f31c0d4e5.json
└─ <camera-id-2>/
```

The camera folder uses the stable internal camera ID, sanitized to `A-Z`, `a-z`, `0-9`, `-`, and `_`.
The filename uses a UTC timestamp plus a unique event ID. The editable camera name is stored only in metadata.

The footer gear button opens the modal **Application Settings** dialog. Its **Recording** tab controls the global recording root used by all cameras. **Browse...** selects a folder but does not apply it until **Save**. **Open Folder** opens the current effective root. **Restore Default** clears the saved user setting on **Save** and does not delete old recordings.

The saved user setting is stored with `QSettings` under:

```text
recording/rootPath
```

Recording root precedence:

1. `GUARD_RECORDING_ROOT` environment override
2. Saved footer Settings dialog root
3. `GUARD_RECORDING_PORTABLE=1` portable mode: `<Guard.exe>/recordings`
4. `QStandardPaths::AppLocalDataLocation/recordings`
5. `QStandardPaths::MoviesLocation/Guard/recordings`
6. `<Guard.exe>/recordings` executable fallback

The dialog shows both configured and effective behavior. When `GUARD_RECORDING_ROOT` is active, it clearly reports that the environment override wins; saving a user path only changes the stored setting for a future launch without the override.

Each recording gets a JSON sidecar with schema version, event ID, camera ID/name, UTC start/end time, completion status, backend, codec/size when known, source generation, detection mode, pre-roll/post-roll, relative video filename, and file size. Metadata is first written as `.part.json` and finalized to `.json` only after the MP4 has been finalized. UTC metadata timestamps use `yyyy-MM-dd'T'HH:mm:ss.zzz'Z'`; filenames use `yyyyMMdd'T'HHmmss.zzz'Z'`.

Changing the root does not reconnect cameras, restart GuardVision, move existing files, or move active `.part.mp4` files. Active recordings finish in the directory assigned when they started. New recordings use the new effective root.

Guard runs recording maintenance at startup, periodically, after a recording completes, after a root change, and when low disk space is detected. Empty stale `.part.mp4` files are removed; non-empty stale partials are preserved and marked incomplete. Orphan or missing `.part.json` metadata is marked incomplete where possible. Retention cleanup removes expired finalized recordings first, then deletes the oldest finalized recordings if configured size or free-space limits require it. Existing flat recordings from older builds are left in place.

## SDK layout

The source package intentionally does not contain proprietary SDK files. Before building, populate:

```text
Desktop/
├─ GuardVision/
│  └─ bin/
│     ├─ Debug/guardvision.lib
│     └─ Release/guardvision.lib
└─ sdk/
   ├─ OpenCV/
   ├─ Identify/
   ├─ HazardDetect/
   ├─ HCNetSDK/
   └─ FFmpeg/
```

Guard does not keep a local `sdk/` folder. The build scripts use `Desktop/sdk` for third-party SDKs and link GuardVision from `Desktop/GuardVision`.

Runtime model lookup is executable-relative:

```text
Guard.exe
Pikachu/
models/fire_smoke.onnx
```

Optional environment overrides:

```text
GUARD_IDENTIFY_RESOURCE
GUARD_HAZARD_MODEL
```

## Build

Build Debug:

```powershell
.\scripts\build-debug.ps1 -QtRoot C:\Qt\Qt5.14.2\5.14.2\msvc2017_64
```

Build Release:

```powershell
.\scripts\build-release.ps1 -QtRoot C:\Qt\Qt5.14.2\5.14.2\msvc2017_64
```

Build both:

```powershell
.\scripts\build-all.ps1 -QtRoot C:\Qt\Qt5.14.2\5.14.2\msvc2017_64
```

The scripts use strict dependency flags because the completed Guard deployment expects GuardVision, OpenCV, Identify, HazardDetect, HCNetSDK, and FFmpeg. qmake itself still reports a clear feature summary.

The project avoids Qt APIs newer than Qt 5.7 in the Guard code. Verification with Qt 5.7, 5.12, and 5.14 still requires the corresponding Windows Qt kits and proprietary SDK binaries.

## Main implementation files

```text
src/app/MainWindow.*
src/platform/identity/
src/platform/security/
src/services/backend/
src/services/events/
src/services/alerts/
src/runtime/camera/CameraRuntimeController.*
src/ui/dialogs/AppSettingsDialog.*
src/ui/dialogs/RoomRegistrationDialog.*
src/ui/dialogs/CameraSettingsDialog.*
src/model/CameraDetectionSettings.h
src/model/CameraTestSourceSettings.h
src/runtime/integration/guardvision/
src/runtime/media/
src/ui/camera/CameraView.*
```

See `docs/CameraRuntimeArchitecture.md` for ownership and event-flow details, `docs/GuardBackendIntegration.md` for API behavior, and `docs/GuardImplementationStatus.md` for the current implementation status.

## Camera disconnect diagnostics and teardown

Per-camera Disconnect uses deferred teardown for image, video, and RTSP
sources. Guard first invalidates source and GuardVision callback generations,
requests recorder/source shutdown, and waits for the producer to become
quiescent without a nested event loop.

Runtime logs showed the Windows process terminating inside native per-stream
`GuardVision::unregisterStream()` while another camera remained active. Normal
CameraWidget Disconnect therefore retains the registered GuardVision stream
and reuses it on the next Connect. All retained streams are released together
by the shared GuardVision shutdown after every camera producer has drained.
HCNetSDK retains its vendor-specific join-based producer shutdown path.

See `docs/CameraDisconnectCrashFix.md` and
`tests/camera-disconnect-lifecycle/`.
