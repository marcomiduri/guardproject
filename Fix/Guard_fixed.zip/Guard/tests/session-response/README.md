# Session-response smoke test

Verifies device-credential aliases, activation camera mappings, and access-token
refresh timing. Commercial entitlement parsing is intentionally absent.
