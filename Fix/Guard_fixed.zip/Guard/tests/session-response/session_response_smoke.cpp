#include "model/GuardBackendModels.h"

#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectEqual(int actual, int expected, const char* label) {
    if (actual == expected)
        return true;
    std::fprintf(stderr, "Unexpected %s: got %d expected %d\n", label, actual, expected);
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;

    guard::backend::RoomConnectionRequest connectRequest;
    connectRequest.roomId = QStringLiteral("room-1");
    connectRequest.installationId = QStringLiteral("installation-1");
    connectRequest.deviceCredential = QStringLiteral("protected-secret");
    connectRequest.deviceName = QStringLiteral("Guard PC");
    connectRequest.applicationVersion = QStringLiteral("2.0.0");
    const QJsonObject connectJson = guard::backend::roomConnectionRequestToApiJson(connectRequest);
    ok = expectTrue(connectJson.value(QStringLiteral("roomId")).toString() == QStringLiteral("room-1"), "connect room id") && ok;
    ok = expectTrue(!connectJson.contains(QStringLiteral("clientInstallationId")), "connect omits clientInstallationId") && ok;
    ok =
      expectTrue(connectJson.value(QStringLiteral("installationId")).toString() == QStringLiteral("installation-1"), "connect installation id") && ok;
    ok = expectTrue(connectJson.value(QStringLiteral("deviceCredential")).toString() == QStringLiteral("protected-secret"),
                    "connect device credential") &&
         ok;
    ok = expectTrue(!connectJson.contains(QStringLiteral("hardwareId")), "connect omits hardwareId") && ok;
    ok = expectTrue(!connectJson.contains(QStringLiteral("hardwareIdHash")), "connect omits hardwareIdHash") && ok;
    ok = expectTrue(!connectJson.contains(QStringLiteral("activationCode")), "connect omits activationCode") && ok;

    const QJsonObject credentialObject = QJsonDocument::fromJson(QByteArrayLiteral(R"({"deviceCredential":"secret-token"})")).object();
    ok =
      expectTrue(guard::backend::deviceCredentialFromSessionJson(credentialObject) == QStringLiteral("secret-token"), "deviceCredential field") && ok;

    const QJsonObject legacyCredentialObject = QJsonDocument::fromJson(QByteArrayLiteral(R"({"deviceToken":"legacy-token"})")).object();
    ok = expectTrue(guard::backend::deviceCredentialFromSessionJson(legacyCredentialObject) == QStringLiteral("legacy-token"),
                    "legacy deviceToken field") &&
         ok;

    QVector<CameraUiModel> mappings;
    const QJsonArray cameras = QJsonDocument::fromJson(QByteArrayLiteral(R"([{"clientCameraId":"local-1","backendCameraId":"backend-1"}])")).array();
    guard::backend::parseActivationCameraMappings(cameras, QStringLiteral("room-1"), &mappings);
    ok = expectTrue(mappings.size() == 1, "camera mapping count") && ok;
    ok = expectTrue(mappings.first().backendCameraId == QStringLiteral("backend-1"), "backendCameraId mapping") && ok;

    const QJsonObject expiresAtObject = QJsonDocument::fromJson(QByteArrayLiteral(R"({"expiresAt":"2026-06-30T12:15:00Z"})")).object();
    const QDateTime now = QDateTime::fromString(QStringLiteral("2026-06-30T12:00:00Z"), Qt::ISODate).toUTC();
    ok = expectEqual(guard::backend::tokenRefreshDelaySeconds(expiresAtObject, now), 840, "expiresAt refresh delay") && ok;

    const QJsonObject expiresInObject = QJsonDocument::fromJson(QByteArrayLiteral(R"({"expiresIn":900})")).object();
    ok = expectEqual(guard::backend::tokenRefreshDelaySeconds(expiresInObject), 840, "expiresIn refresh delay") && ok;

    return ok ? 0 : 1;
}
