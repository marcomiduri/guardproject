# Guard camera sync smoke test

Verifies Task 8 API ID parsing, partial JSON merge, and connection-field detection. It also verifies that backend label/whitespace normalization does not falsely trigger an active camera source restart during room connection.

```bat
mkdir build
cd build
qmake ..\camera-sync-smoke.pro CONFIG+=release
nmake release
release\guard-camera-sync-smoke.exe
```

Exit code `0` means success.
