#include "model/CameraUiModel.h"
#include "model/GuardBackendModels.h"

#include <QCoreApplication>
#include <QJsonObject>
#include <cstring>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectEqual(const char* actual, const char* expected, const char* label) {
    if (actual == expected || (actual && expected && std::strcmp(actual, expected) == 0))
        return true;
    std::fprintf(stderr, "Unexpected %s: got %s expected %s\n", label, actual ? actual : "(null)", expected ? expected : "(null)");
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;

    QJsonObject idOnly;
    idOnly.insert(QStringLiteral("id"), QStringLiteral("backend-1"));
    ok = expectEqual(guard::backend::backendCameraIdFromApiJson(idOnly).toUtf8().constData(), "backend-1", "id field") && ok;

    QJsonObject canonical;
    canonical.insert(QStringLiteral("backendCameraId"), QStringLiteral("backend-2"));
    canonical.insert(QStringLiteral("id"), QStringLiteral("ignored"));
    ok = expectEqual(guard::backend::backendCameraIdFromApiJson(canonical).toUtf8().constData(), "backend-2", "backendCameraId field") && ok;

    CameraUiModel local;
    local.id = QStringLiteral("local-1");
    local.clientCameraId = QStringLiteral("local-1");
    local.name = QStringLiteral("Lobby");
    local.address = QStringLiteral("192.168.1.10");
    local.password = QStringLiteral("secret");
    local.sdkPort = 8000;
    local.directionConfigured = true;
    local.direction = CameraDirection::Incoming;

    QJsonObject partial;
    partial.insert(QStringLiteral("id"), QStringLiteral("backend-1"));
    partial.insert(QStringLiteral("name"), QStringLiteral("Lobby Updated"));
    CameraUiModel merged = local;
    ok = expectTrue(guard::backend::cameraFromApiJson(partial, &merged, nullptr), "partial merge") && ok;
    ok = expectEqual(merged.backendCameraId.toUtf8().constData(), "backend-1", "merged backend id") && ok;
    ok = expectEqual(merged.address.toUtf8().constData(), "192.168.1.10", "preserved address") && ok;
    ok = expectEqual(merged.password.toUtf8().constData(), "secret", "preserved password") && ok;
    ok = expectEqual(merged.name.toUtf8().constData(), "Lobby Updated", "updated name") && ok;

    CameraUiModel left = local;
    CameraUiModel right = local;
    right.name = QStringLiteral("Different Name");
    ok = expectTrue(cameraConnectionFieldsEqual(left, right), "metadata change is not connection change") && ok;
    right.address = QStringLiteral("192.168.1.20");
    ok = expectTrue(!cameraConnectionFieldsEqual(left, right), "address change is connection change") && ok;

    CameraUiModel normalizedLeft = local;
    normalizedLeft.type = QStringLiteral("Generic RTSP Camera");
    normalizedLeft.address = QStringLiteral(" Camera.Example.COM ");
    normalizedLeft.username = QStringLiteral(" admin ");
    normalizedLeft.stream = QStringLiteral("Main Stream");
    normalizedLeft.rtspUrl = QStringLiteral(" rtsp://camera.example.com/live ");

    CameraUiModel normalizedRight = normalizedLeft;
    normalizedRight.type = QStringLiteral("Generic (RTSP)");
    normalizedRight.address = QStringLiteral("camera.example.com");
    normalizedRight.username = QStringLiteral("admin");
    normalizedRight.stream = QStringLiteral("main");
    normalizedRight.rtspUrl = QStringLiteral("rtsp://camera.example.com/live");
    ok = expectTrue(cameraConnectionFieldsEqual(normalizedLeft, normalizedRight), "backend label normalization does not restart source") && ok;

    normalizedLeft.type = QStringLiteral("Hikvision Camera");
    normalizedRight.type = QStringLiteral("Hikvision");
    normalizedLeft.stream = QStringLiteral("Sub Stream");
    normalizedRight.stream = QStringLiteral("sub");
    ok = expectTrue(cameraConnectionFieldsEqual(normalizedLeft, normalizedRight), "hikvision and stream labels compare semantically") && ok;

    normalizedRight.type = QStringLiteral("Generic (RTSP)");
    ok = expectTrue(!cameraConnectionFieldsEqual(normalizedLeft, normalizedRight), "effective source type change restarts source") && ok;

    local.roomId = QStringLiteral("room-1");
    local.backendCameraId.clear();
    ok = expectTrue(local.requiresBackendCameraId(), "registered camera requires backend id") && ok;
    ok = expectTrue(local.eventCameraId().isEmpty(), "registered camera without backend id has no event id") && ok;
    ok = expectEqual(local.localFaceTrackCameraKey().toUtf8().constData(), "local-1", "local track key fallback") && ok;
    local.backendCameraId = QStringLiteral("backend-1");
    ok = expectEqual(local.eventCameraId().toUtf8().constData(), "backend-1", "mapped event id") && ok;

    return ok ? 0 : 1;
}
