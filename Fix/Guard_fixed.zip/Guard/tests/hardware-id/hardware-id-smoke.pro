QT += core
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-hardware-id-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/platform/identity

SOURCES += \
    $$PWD/hardware_id_smoke.cpp \
    $$GUARD_ROOT/src/platform/identity/GuardHardwareId.cpp

HEADERS += \
    $$GUARD_ROOT/src/platform/identity/GuardHardwareId.h \
    $$GUARD_ROOT/src/platform/identity/GuardHardwareIdPrivate.h
