# Hardware-ID smoke test

This console target verifies the stable installation Hardware ID independently of
commercial licensing. It covers canonical hashing, case/whitespace normalization,
first-run query failure, temporary query failure, partial hardware-change safety,
and complete hardware replacement.

Build with a supported Windows Qt qmake kit. Exit code `0` means all vectors passed.
