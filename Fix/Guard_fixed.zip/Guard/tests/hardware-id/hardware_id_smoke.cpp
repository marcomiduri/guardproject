#include "GuardHardwareId.h"
#include "GuardHardwareIdPrivate.h"

#include <QCoreApplication>
#include <QString>
#include <cstdio>

namespace {

bool expectEqual(const QString& actual, const QString& expected, const char* label) {
    if (actual == expected)
        return true;
    std::fprintf(stderr, "Unexpected %s: got %s expected %s\n", label, actual.toLocal8Bit().constData(), expected.toLocal8Bit().constData());
    return false;
}

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectFalse(bool value, const char* label) {
    if (!value)
        return true;
    std::fprintf(stderr, "Expected false: %s\n", label);
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    const QString machineGuid = QStringLiteral("00112233-4455-6677-8899-AABBCCDDEEFF");
    const QString processorId = QStringLiteral("BFEBFBFF000906EA");

    bool ok = true;
    ok = expectEqual(GuardHardwareId::canonicalIdentifierForComponents(machineGuid, processorId), QStringLiteral("1C7D7EBD9E043660"),
                     "canonical hardware ID") &&
         ok;
    ok = expectEqual(GuardHardwareId::formatDisplayText(QStringLiteral("1c7d7ebd9e043660")), QStringLiteral("1C7D-7EBD-9E04-3660"),
                     "formatted hardware ID") &&
         ok;
    ok = expectEqual(GuardHardwareId::canonicalIdentifierForComponents(QStringLiteral("  00112233-4455-6677-8899-aabbccddeeff  "),
                                                                       QStringLiteral("  bfebfbff000906ea  ")),
                     QStringLiteral("1C7D7EBD9E043660"), "normalized canonical hardware ID") &&
         ok;
    ok =
      expectTrue(GuardHardwareId::canonicalIdentifierForComponents(QString(), processorId).isEmpty(), "missing MachineGuid does not create an ID") &&
      ok;
    ok =
      expectTrue(GuardHardwareId::canonicalIdentifierForComponents(machineGuid, QString()).isEmpty(), "missing ProcessorId does not create an ID") &&
      ok;

    GuardHardwareIdPrivate::StoredIdentity emptyStored;
    const GuardHardwareIdPrivate::Resolution unavailable = GuardHardwareIdPrivate::resolveIdentity(QString(), QString(), emptyStored);
    ok = expectTrue(unavailable.identifier.isEmpty(), "first-run query failure is unavailable") && ok;
    ok = expectFalse(unavailable.shouldPersist, "first-run query failure is not persisted") && ok;
    ok = expectFalse(unavailable.usingStoredFallback, "first-run query failure has no stored fallback") && ok;

    GuardHardwareIdPrivate::StoredIdentity stored;
    stored.canonicalId = QStringLiteral("1C7D7EBD9E043660");
    stored.machineGuidDigest = GuardHardwareIdPrivate::componentDigest(GuardHardwareIdPrivate::normalizeMachineGuid(machineGuid));
    stored.processorIdDigest = GuardHardwareIdPrivate::componentDigest(GuardHardwareIdPrivate::normalizeProcessorId(processorId));

    const GuardHardwareIdPrivate::Resolution temporaryFailure = GuardHardwareIdPrivate::resolveIdentity(machineGuid, QString(), stored);
    ok = expectEqual(temporaryFailure.identifier, stored.canonicalId, "stored ID retained during temporary query failure") && ok;
    ok = expectTrue(temporaryFailure.usingStoredFallback, "stored fallback is reported") && ok;
    ok = expectFalse(temporaryFailure.verified, "partial query is not reported as verified") && ok;
    ok = expectFalse(temporaryFailure.shouldPersist, "partial query never overwrites identity") && ok;

    const GuardHardwareIdPrivate::Resolution changedButIncomplete =
      GuardHardwareIdPrivate::resolveIdentity(QStringLiteral("FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF"), QString(), stored);
    ok = expectEqual(changedButIncomplete.identifier, stored.canonicalId, "partial hardware change does not replace stored ID") && ok;
    ok = expectFalse(changedButIncomplete.shouldPersist, "partial hardware change is not persisted") && ok;

    const GuardHardwareIdPrivate::Resolution verifiedChange =
      GuardHardwareIdPrivate::resolveIdentity(QStringLiteral("FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF"), QStringLiteral("AAAAAAAAAAAAAAAA"), stored);
    ok = expectTrue(verifiedChange.verified, "complete changed hardware is verified") && ok;
    ok = expectTrue(verifiedChange.shouldPersist, "complete changed hardware is persisted") && ok;
    ok = expectTrue(!verifiedChange.identifier.isEmpty() && verifiedChange.identifier != stored.canonicalId,
                    "complete changed hardware produces a new canonical ID") &&
         ok;

    return ok ? 0 : 1;
}
