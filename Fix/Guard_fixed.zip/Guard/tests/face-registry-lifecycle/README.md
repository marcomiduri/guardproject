# Face registry lifecycle regression check

Run from any Python 3 environment:

```bash
python tests/face-registry-lifecycle/verify_source.py
```

The test verifies that registry download/application is decoupled from camera
startup, that `IdentifyEngine` lazy initialization is handled after stream
registration, and that a missing face engine degrades only face identification
instead of failing motion, hazard, playback, or recording.

A Windows Qt runtime test with the proprietary Identify SDK is still required.
