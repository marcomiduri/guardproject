#!/usr/bin/env python3
"""Source-level regression checks for Guard face-registry startup ordering.

These checks do not replace a Qt/Windows runtime test. They protect the
lifecycle invariants that caused the registered-face CameraWidget Connect
failure.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
main_cpp = (ROOT / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
controller_cpp = (ROOT / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
controller_h = (ROOT / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")

checks = []

def check(condition: bool, message: str) -> None:
    checks.append((condition, message))

check("failPendingCameraStarts" not in main_cpp,
      "registry failures are not coupled to CameraView ERROR")
check("The camera was not started because GuardVision rejected the face registry." not in main_cpp,
      "obsolete registry-blocking message was removed")
check("Camera is starting while face identification is pending." in main_cpp,
      "camera startup explicitly supports degraded face-identification mode")
check("result.error.code == guardvision::GuardVisionErrorCode::NotInitialized" in main_cpp,
      "early registry enrollment is retained as pending")
check("guardVisionStreamRegistered" in controller_h and "guardVisionStreamRegistered" in main_cpp,
      "stream registration notifies the registry coordinator")
check("faceIdentificationUnavailable" in controller_h and "faceIdentificationUnavailable" in main_cpp,
      "permanent face-engine availability failure is separated from camera state")
check("degradedConfig.face.processingLevel = guardvision::FaceProcessingLevel::Disabled" in controller_cpp,
      "camera stream retries without face analytics when IdentifyEngine cannot initialize")

signal_pos = controller_cpp.find("emit guardVisionStreamRegistered")
media_start_pos = controller_cpp.find("mediaController_.start", signal_pos)
check(signal_pos >= 0 and media_start_pos > signal_pos,
      "pending registry is applied after stream registration and before media playback")

failed = [message for ok, message in checks if not ok]
for ok, message in checks:
    print(("PASS" if ok else "FAIL") + ": " + message)

if failed:
    sys.exit(1)
