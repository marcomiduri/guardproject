#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
main = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
controller = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")

helper_start = main.find("bool MainWindow::reactivateCachedFaceRegistryForCurrentRoom()")
helper_end = main.find("void MainWindow::refreshNotificationSettings()", helper_start)
helper = main[helper_start:helper_end] if helper_start >= 0 and helper_end > helper_start else ""

disconnect_marker = "if (!state.isRegistered()) {"
same_room_marker = "m_faceRegistryLoaded && roomId == m_faceRegistryRoomId"

checks = {
    "room disconnect preserves enrolled registry": disconnect_marker in main and
        "Keep the already-enrolled native registry alive" in main,
    "room disconnect masks identities": "suspendFaceIdentificationForAllCameras();" in main,
    "same-room reconnect uses cached registry": same_room_marker in main and
        "reactivateCachedFaceRegistryForCurrentRoom();" in main,
    "cached reactivation never enrolls native registry": helper and "m_guardVision->setFaceRegistry" not in helper,
    "cached reactivation restores coordinator registry readiness": "m_eventCoordinator->setFaceRegistryLoaded(true);" in helper,
    "prepared camera avoids redundant native face config": "if (!nativeFaceIdentificationPrepared_)" in controller,
    "periodic unchanged-version refresh reuses cached registry": "m_faceRegistryState = FaceRegistryState::Ready;\n            reactivateCachedFaceRegistryForCurrentRoom();" in main,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} cached-registry reconnect check(s) failed")
