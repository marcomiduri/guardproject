# Same-room reconnect cached-registry verification

Verifies that an ordinary room disconnect masks identity results without clearing the previously enrolled native registry, and that reconnecting to the same room re-enables the cached mapping without calling GuardVision registry enrollment or redundant native face reconfiguration while cameras are active.
