#!/usr/bin/env python3
"""Source-level regression checks for no-room face processing safety."""
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
controller_h = (root / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")
controller_cpp = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
main_cpp = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
events_cpp = (root / "src/services/events/GuardEventCoordinator.cpp").read_text(encoding="utf-8")

ok = True

def check(condition: bool, message: str) -> None:
    global ok
    if condition:
        print(f"PASS: {message}")
    else:
        print(f"FAIL: {message}")
        ok = False

check("bool faceIdentificationEnabled_ = false;" in controller_h and
      "bool nativeFaceIdentificationPrepared_ = false;" in controller_h,
      "fresh controllers do not identify before a room registry exists")
check("effective.processingLevel = guardvision::FaceProcessingLevel::DetectAndTrack;" in controller_cpp,
      "no-room face runtime uses detect-and-track")
check("config.face = effectiveFaceConfig(settings_.face);" in controller_cpp,
      "stream registration applies the safe effective face config")
check("controller->prepareFaceIdentification" in main_cpp and
      main_cpp.find("controller->prepareFaceIdentification") < main_cpp.find("m_guardVision->setFaceRegistry"),
      "IdentifyEngine is prepared only when a concrete registry is ready")
check("suspendFaceIdentificationForAllCameras();" in main_cpp and
      "Do not downgrade a prepared native stream here" in controller_cpp,
      "room transitions mask stale identities without unsafe native teardown")
room_guard = events_cpp.find("if (!backendRoomAssigned_ || !guard::events::canUploadFaceEvent")
voice_call = events_cpp.find("localAlerts_->speakUnknownIncoming()")
check(room_guard != -1 and voice_call != -1 and room_guard < voice_call,
      "no-room unknown overlays cannot trigger delayed access-denied audio")
check("Face identification deferred until a room registry is available" in controller_cpp,
      "camera logs expose the safe no-room mode for field verification")

sys.exit(0 if ok else 1)
