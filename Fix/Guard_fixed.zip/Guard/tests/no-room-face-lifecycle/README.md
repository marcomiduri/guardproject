# No-room face lifecycle regression

Run `python tests/no-room-face-lifecycle/verify_source.py`.

The checks ensure that a fresh local-only camera session uses face detection and tracking without starting identification against an unavailable room registry. They also verify that delayed unknown-access actions are room-gated.
