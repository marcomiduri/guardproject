from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
header = (root / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")
main_window = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")

prepare_begin = source.index("bool CameraRuntimeController::prepareFaceIdentification")
prepare_end = source.index("void CameraRuntimeController::suspendFaceIdentification", prepare_begin)
prepare_body = source[prepare_begin:prepare_end]

adopt_begin = source.index("if (!streamRegistered_)")
adopt_end = source.index("// Normal CameraWidget Disconnect", adopt_begin)
adopt_body = source[adopt_begin:adopt_end]

prepared_guard = "if (nativeFaceIdentificationPrepared_)"
set_config = "guardVision_->setFaceConfig(streamId_.toStdString(), identifyConfig)"

assert "faceIdentificationRequested_" in header, "registry intent must be separate from native preparation state"
assert prepared_guard in prepare_body, "prepared native Identify sessions must be handled idempotently"
assert set_config in prepare_body, "unprepared active streams still need one native Identify initialization"
assert prepare_body.index(prepared_guard) < prepare_body.index(set_config), "idempotence guard must run before native setFaceConfig"
assert prepare_body.count("guardVision_->setFaceConfig(") == 1, "face preparation must never issue a second rollback/retry transition"
assert prepare_body.index("nativeFaceIdentificationPrepared_ = true;") > prepare_body.index(set_config), (
    "native state must be committed only after setFaceConfig succeeds"
)
assert "isGuardVisionStreamActive()" in prepare_body, "inactive restored controllers must not be marked natively prepared"
assert "setFaceConfig(" not in adopt_body, "retained-slot adoption must never rebuild the vendor face session"

insert_pos = main_window.index("m_controllersByCameraId.insert(camera.id, controller);")
connect_pos = main_window.index("connect(cameraWidget", insert_pos)
pre_connect_body = main_window[insert_pos:connect_pos]
assert "syncFaceIdentificationFromRegistry" not in pre_connect_body, (
    "cached registry synchronization must not run before the retained stream is active"
)

registered_connect = main_window.index("&CameraRuntimeController::guardVisionStreamRegistered")
registered_connect_end = main_window.index("Qt::DirectConnection", registered_connect)
registered_body = main_window[registered_connect:registered_connect_end]
assert "syncFaceIdentificationFromRegistry" in registered_body, (
    "cached registry synchronization must run from the active stream callback before media startup"
)
assert "tryApplyPendingFaceRegistry" in registered_body, "pending registry application path must remain present"

print("retained face-session state separation and idempotence verification passed")
