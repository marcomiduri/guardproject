# Retained face-session state separation regression

Verifies that room-registry intent is not confused with actual vendor Identify-session state.

The regression requires:

- no native `setFaceConfig()` call during retained-slot adoption;
- only one native transition when an active, genuinely unprepared stream needs Identify mode;
- native prepared state committed only after that call succeeds;
- no rollback/retry `setFaceConfig()` call after failure;
- cached room registry synchronization deferred until `guardVisionStreamRegistered`, before media startup.
