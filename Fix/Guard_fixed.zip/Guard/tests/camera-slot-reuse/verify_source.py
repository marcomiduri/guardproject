from pathlib import Path

root = Path(__file__).resolve().parents[2]
main_h = (root / 'src/app/MainWindow.h').read_text(encoding='utf-8')
main_cpp = (root / 'src/app/MainWindow.cpp').read_text(encoding='utf-8')
ctrl_h = (root / 'src/runtime/camera/CameraRuntimeController.h').read_text(encoding='utf-8')
ctrl_cpp = (root / 'src/runtime/camera/CameraRuntimeController.cpp').read_text(encoding='utf-8')
media_h = (root / 'src/runtime/media/MediaSourceController.h').read_text(encoding='utf-8')

remove_start = main_cpp.find('void MainWindow::removeCameraTileLocally')
remove_end = main_cpp.find('bool MainWindow::removeAllCameraTilesLocally', remove_start)
remove_body = main_cpp[remove_start:remove_end]
room_start = main_cpp.find('bool MainWindow::removeAllCameraTilesLocally')
room_end = main_cpp.find('bool MainWindow::ensureCameraWorkspaceRoom', room_start)
room_body = main_cpp[room_start:room_end]

checks = {
    'process-lifetime reusable stream pool exists':
        'ReusableGuardVisionStreamSlot' in main_h
        and 'm_reusableGuardVisionStreamSlots' in main_h,
    'controller accepts retained stream ownership and cursor':
        'retainedStreamId' in ctrl_h
        and 'retainedNextSubmissionSequence' in ctrl_h
        and 'retainedNextSubmissionTimestampMs' in ctrl_h,
    'fresh cameras still create camera-derived stream ids':
        'retainedStreamId.trimmed().isEmpty() ? makeStreamId(camera.id)' in ctrl_cpp,
    'ordinary reconnect remains controller-local':
        "Reactivating this camera's GuardVision stream" in ctrl_cpp
        and 'getStreamStatus(streamId_.toStdString(), retainedStatus)' in ctrl_cpp,
    'camera removal returns owned slot without native unregister':
        'controller->ownsReusableGuardVisionStreamSlot()' in remove_body
        and 'm_reusableGuardVisionStreamSlots.append(reusableStreamSlot);' in remove_body
        and 'releaseGuardVisionStream' not in remove_body,
    'room teardown stops and joins all producers before slot collection':
        room_body.find('controller->stop();') >= 0
        and room_body.find('controller->prepareForApplicationShutdown();') > room_body.find('controller->stop();')
        and room_body.find('controller->prepareForApplicationShutdown();') < room_body.find('controller->ownsReusableGuardVisionStreamSlot()'),
    'room teardown never calls unsafe per-stream unregister':
        'releaseGuardVisionStream' not in room_body
        and 'unregisterStream' not in room_body,
    'production controller has no native per-stream unregister call':
        'guardVision_->unregisterStream' not in ctrl_cpp,
    'rebound streams preserve monotonic frame cursor':
        'setSubmissionCursor(retainedNextSubmissionSequence, retainedNextSubmissionTimestampMs);' in ctrl_cpp
        and 'nextSubmissionSequence() const' in media_h
        and 'nextSubmissionTimestampMs() const' in media_h,
    'assigned-but-never-played slots remain owned':
        'ownsReusableGuardVisionStreamSlot_(!retainedStreamId.trimmed().isEmpty())' in ctrl_cpp,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit('FAILED: ' + ', '.join(failed))
print('Safe process-lifetime GuardVision slot reuse verification passed.')
