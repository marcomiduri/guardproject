# Process-lifetime GuardVision slot reuse verification

This test directory keeps its historical name so existing test runners continue to discover it.

The source check verifies that:

- Guard keeps a bounded pool of native GuardVision registrations for the process lifetime;
- old room camera controllers are deleted without calling unsafe per-stream native unregister;
- a newly created controller can adopt a retained stream slot;
- slots assigned to cameras that were never played are still returned during removal;
- frame sequence and timestamp cursors continue monotonically when a slot is rebound;
- normal Disconnect/Connect reactivates the same controller-owned stream.
