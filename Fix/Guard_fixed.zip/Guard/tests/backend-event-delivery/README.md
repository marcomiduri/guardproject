# Guard backend event-delivery contract

Protects the desktop multipart fields and endpoints for:

- hazard detection with annotated `snapshot`;
- recognized face with `frameImage` and `faceImage`;
- unknown face with `frameImage` and `faceImage`;
- unknown/unapproved incoming local alarms.
