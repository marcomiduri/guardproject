#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
coordinator = (root / "src/services/events/GuardEventCoordinator.cpp").read_text(encoding="utf-8")

# Hazard: snapshot + backend endpoint + Guard source + only mark after submission.
assert 'QStringLiteral("/api/guard/events/hazard-detected")' in coordinator
assert 'QStringLiteral("snapshot")' in coordinator
assert 'QStringLiteral("source"), QStringLiteral("GUARD2")' in coordinator
assert 'bool GuardEventCoordinator::uploadHazard' in coordinator
assert 'uploadHazard(occurrence))' in coordinator

# Face: full annotated frame and cropped face are both sent for known/unknown events.
assert 'QStringLiteral("/api/guard/events/appeared")' in coordinator
assert 'QStringLiteral("/api/guard/events/unknown-appeared")' in coordinator
assert 'QStringLiteral("frameImage")' in coordinator
assert 'QStringLiteral("faceImage")' in coordinator
assert 'annotateFaceFrame(occurrence)' in coordinator
assert 'cropFace(occurrence)' in coordinator
assert 'shouldPlayUnknownIncomingVoice' in coordinator
assert 'shouldPlayUnapprovedIncomingVoice' in coordinator

print("Guard hazard and face multipart delivery contract verification passed.")
