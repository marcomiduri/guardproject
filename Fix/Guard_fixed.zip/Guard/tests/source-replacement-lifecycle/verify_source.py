#!/usr/bin/env python3
from pathlib import Path
import re

root = Path(__file__).resolve().parents[2]
cpp = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
h = (root / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")

assert "bool sourceReplacementInProgress_ = false;" in h
assert "bool waitForGuardVisionStreamIdle(int timeoutMs, int quietPeriodMs = 150) const;" in h
assert "sameDetectionSettings" in cpp

method = re.search(
    r"bool CameraRuntimeController::applyCameraSettings\(.*?\) \{(?P<body>.*?)\n\}",
    cpp,
    re.S,
)
assert method, "applyCameraSettings() was not found"
body = method.group("body")

stop_pos = body.find("stop();")
idle_pos = body.find("waitForGuardVisionStreamIdle(5000)")
config_pos = body.find("applyConfigsToRegisteredStream")
assign_pos = body.find("testSourceSettings_ = normalizedTestSettings")
start_pos = body.find("const bool started = start(errorMessage)")
assert -1 not in (stop_pos, idle_pos, config_pos, assign_pos, start_pos), "Safe source-replacement step is missing"
assert stop_pos < idle_pos < config_pos < assign_pos < start_pos, \
    "Replacement source/configuration order can race the old producer"
assert "if (detectionSettingsChanged && !applyConfigsToRegisteredStream" in body, \
    "Pure media replacement still reconfigures native analytics sessions"
assert "Test source replacement completed safely." in body

print("Running source replacement lifecycle verification passed.")
