# Running test-source replacement verification

This source check protects the image/video replacement sequence:

1. Stop and synchronously quiesce the old producer.
2. Wait for a continuous GuardVision idle period.
3. Reconfigure analytics only when detection settings actually changed.
4. Commit the new source and start it after the old source is gone.
