# Reconnect frame continuity verification

Run:

```bash
python tests/reconnect-frame-continuity/verify_source.py
```

The check prevents a retained GuardVision stream from receiving a new camera session whose frame sequence restarts at zero.
