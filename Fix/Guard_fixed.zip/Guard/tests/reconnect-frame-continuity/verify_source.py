#!/usr/bin/env python3
from pathlib import Path
import re

root = Path(__file__).resolve().parents[2]
source = (root / "src/runtime/media/MediaSourceController.cpp").read_text(encoding="utf-8")

match = re.search(
    r"void MediaSourceController::resetForNewPlayback\(\) \{(?P<body>.*?)\n\}",
    source,
    re.S,
)
assert match, "resetForNewPlayback() was not found"
body = match.group("body")

assert "nextSequence_ = 0" not in body, "Reconnect still resets frame sequence to zero"
assert "qMax(nextTimestampMs_ + 1, nowMs)" in body, "Reconnect timestamp continuity is not preserved"

start_match = re.search(
    r"bool MediaSourceController::start\(.*?\) \{(?P<body>.*?)\n\}",
    source,
    re.S,
)
assert start_match, "MediaSourceController::start() was not found"
start_body = start_match.group("body")
assert start_body.count("Q_ARG(quint64, nextSequence_)") >= 2, "File/RTSP sources do not resume from nextSequence_"
assert "startCapture(config_.hcNetSdk, activeGeneration_, activeStreamId_, nextSequence_, nextTimestampMs_)" in start_body, \
    "HCNetSDK source does not resume from the monotonic sequence"

print("Reconnect frame continuity source verification passed.")
