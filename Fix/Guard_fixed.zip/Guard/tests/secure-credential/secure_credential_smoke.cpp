#include "platform/security/SecureCredentialStore.h"

#include <QByteArray>
#include <QCoreApplication>
#include <QSettings>
#include <cstdio>

namespace {

const char kDeviceCredentialName[] = "guard-backend-device-credential";

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectFalse(bool value, const char* label) {
    if (!value)
        return true;
    std::fprintf(stderr, "Expected false: %s\n", label);
    return false;
}

bool expectEqualBytes(const QByteArray& actual, const QByteArray& expected, const char* label) {
    if (actual == expected)
        return true;
    std::fprintf(stderr, "Unexpected %s\n", label);
    return false;
}

void resetSettings() {
    QSettings current;
    current.clear();
    current.sync();
}

bool testWriteReadRemoveRoundTrip() {
    const QString name = QStringLiteral("guard-secure-roundtrip");
    const QByteArray payload = QByteArrayLiteral("protected-value");

    QByteArray readBack;
    QString error;
    bool ok = true;
    ok = expectTrue(guard::security::SecureCredentialStore::write(name, payload, &error), "write round-trip") && ok;
    ok = expectTrue(guard::security::SecureCredentialStore::contains(name), "contains after write") && ok;
    ok = expectTrue(guard::security::SecureCredentialStore::read(name, &readBack, &error), "read round-trip") && ok;
    ok = expectEqualBytes(readBack, payload, "round-trip payload") && ok;
    ok = expectTrue(guard::security::SecureCredentialStore::remove(name, &error), "remove round-trip") && ok;
    ok = expectFalse(guard::security::SecureCredentialStore::contains(name), "contains after remove") && ok;
    return ok;
}

bool testFailedWriteValidation() {
    QString error;
    const bool rejected = !guard::security::SecureCredentialStore::write(QString(), QByteArrayLiteral("x"), &error);
    return expectTrue(rejected, "empty credential name rejected") && expectFalse(error.isEmpty(), "empty credential name reports error");
}

bool testCorruptedProtectedDataFailsSafely() {
    const QString name = QStringLiteral("guard-corrupt-credential");
    QSettings settings;
    settings.setValue(QStringLiteral("secure/guard-corrupt-credential"), QByteArrayLiteral("AAA="));
    settings.sync();

    QByteArray value;
    QString error;
    bool ok = true;
    ok = expectTrue(guard::security::SecureCredentialStore::contains(name), "corrupt credential entry exists") && ok;
    ok = expectFalse(guard::security::SecureCredentialStore::read(name, &value, &error), "corrupt credential read fails") && ok;
#ifdef Q_OS_WIN
    ok = expectFalse(error.isEmpty(), "corrupt credential reports error") && ok;
#endif
    return ok;
}

bool testDeviceCredentialRoundTrip() {
    const QByteArray token = QByteArrayLiteral("device-credential-smoke");
    QByteArray readBack;
    QString error;
    bool ok = true;

    ok = expectTrue(guard::security::SecureCredentialStore::write(QString::fromLatin1(kDeviceCredentialName), token, &error),
                    "device credential write") &&
         ok;
    ok = expectTrue(guard::security::SecureCredentialStore::read(QString::fromLatin1(kDeviceCredentialName), &readBack, &error),
                    "device credential read") &&
         ok;
    ok = expectEqualBytes(readBack, token, "device credential payload") && ok;
    return ok;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    QCoreApplication::setOrganizationName(QStringLiteral("GuardSecureCredentialTest"));
    QCoreApplication::setApplicationName(QStringLiteral("GuardSecureCredentialTest"));

    resetSettings();

    bool ok = true;
    ok = testWriteReadRemoveRoundTrip() && ok;
    ok = testFailedWriteValidation() && ok;
    ok = testCorruptedProtectedDataFailsSafely() && ok;
    ok = testDeviceCredentialRoundTrip() && ok;

    resetSettings();
    return ok ? 0 : 1;
}
