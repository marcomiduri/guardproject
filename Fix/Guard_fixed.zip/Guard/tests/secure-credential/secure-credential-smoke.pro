QT += core
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-secure-credential-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
INCLUDEPATH += $$GUARD_ROOT/src

SOURCES += \
    $$PWD/secure_credential_smoke.cpp \
    $$GUARD_ROOT/src/platform/security/SecureCredentialStore.cpp

HEADERS += $$GUARD_ROOT/src/platform/security/SecureCredentialStore.h

win32-msvc*:LIBS += Crypt32.lib
win32-g++:LIBS += -lcrypt32
