# Secure credential smoke test

This console target verifies protected credential write/read/remove behavior,
validation of empty names, safe failure for corrupted protected data, and the backend
device-credential round trip. Commercial license storage is intentionally absent.
