#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
session_h = (root / "src/services/backend/GuardSessionManager.h").read_text(encoding="utf-8")
session_cpp = (root / "src/services/backend/GuardSessionManager.cpp").read_text(encoding="utf-8")
main = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")

checks = {
    "token-ready signal is public": "void accessTokenAvailable();" in session_h,
    "every successful token response emits readiness": "emit accessTokenAvailable();" in session_cpp,
    "readiness is emitted before callback-specific branching": session_cpp.find("emit accessTokenAvailable();") < session_cpp.find("if (done)\n            reportResult(done, true);"),
    "main window listens for token readiness": "GuardSessionManager::accessTokenAvailable" in main,
    "event delivery requires registered room and live token": "m_sessionManager->isRegistered() &&\n                                   m_sessionManager->hasLiveAccessToken()" in main,
    "cold-start restoration still uses callback": "m_sessionManager->refreshAccessToken([self, finish, operationFinished]" in main,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} startup event-session check(s) failed")
