# Startup backend event-session verification

Verifies that a callback-driven cold-start JWT restoration still marks the Guard event coordinator as room-assigned, allowing face and hazard events to be uploaded immediately after launch.
