#include "model/CameraUiModel.h"
#include "model/GuardFaceEventHelpers.h"

#include <QCoreApplication>
#include <cstring>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectFalse(bool value, const char* label) {
    if (!value)
        return true;
    std::fprintf(stderr, "Expected false: %s\n", label);
    return false;
}

bool expectEqual(const char* actual, const char* expected, const char* label) {
    if (actual == expected || (actual && expected && std::strcmp(actual, expected) == 0))
        return true;
    std::fprintf(stderr, "Unexpected %s: got %s expected %s\n", label, actual ? actual : "(null)", expected ? expected : "(null)");
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;

    ok = expectEqual(guard::events::faceTrackKey(QStringLiteral("camera-a"), 12).toUtf8().constData(), "camera-a:12", "face track key") && ok;

    ok = expectEqual(guard::events::faceOverlayLabel(true, QStringLiteral("John Smith"), 0.89).toUtf8().constData(), "John Smith 89%",
                     "recognized overlay label") &&
         ok;
    ok = expectEqual(guard::events::faceOverlayLabel(false, QString(), 0.0).toUtf8().constData(), "UNKNOWN", "unknown overlay label") && ok;
    ok = expectEqual(guard::events::faceOverlayLabel(true, QString(), 0.89).toUtf8().constData(), "UNKNOWN",
                     "identified flag without resolved name remains unknown") &&
         ok;

    CameraUiModel registered;
    registered.id = QStringLiteral("local-1");
    registered.clientCameraId = QStringLiteral("local-1");
    registered.roomId = QStringLiteral("room-1");
    ok = expectTrue(registered.requiresBackendCameraId(), "registered camera requires backend id") && ok;
    ok = expectTrue(registered.eventCameraId().isEmpty(), "registered camera without backend id has no event id") && ok;
    ok = expectFalse(guard::events::canUploadFaceEvent(registered), "registered camera blocks upload without backend id") && ok;
    ok = expectEqual(registered.localFaceTrackCameraKey().toUtf8().constData(), "local-1", "local track key fallback") && ok;

    registered.backendCameraId = QStringLiteral("backend-1");
    ok = expectEqual(registered.eventCameraId().toUtf8().constData(), "backend-1", "mapped event id") && ok;
    ok = expectTrue(guard::events::canUploadFaceEvent(registered), "registered camera uploads with backend id") && ok;

    CameraUiModel offline = registered;
    offline.roomId.clear();
    offline.backendCameraId.clear();
    ok = expectEqual(offline.eventCameraId().toUtf8().constData(), "local-1", "offline camera event id fallback") && ok;
    ok = expectFalse(guard::events::canUploadFaceEvent(offline), "offline camera does not upload with local id") && ok;

    ok = expectTrue(guard::events::shouldSendRecognizedFaceEvent(false, true, 42), "recognized event once") && ok;
    ok = expectFalse(guard::events::shouldSendRecognizedFaceEvent(true, true, 42), "recognized event deduped") && ok;
    ok = expectFalse(guard::events::shouldSendRecognizedFaceEvent(false, true, 0), "recognized requires registry id") && ok;

    ok = expectTrue(guard::events::shouldSendUnknownFaceOnTrackLost(false, false, false), "unknown on track lost") && ok;
    ok = expectFalse(guard::events::shouldSendUnknownFaceOnTrackLost(true, false, false), "unknown track lost deduped") && ok;
    ok = expectFalse(guard::events::shouldSendUnknownFaceOnTrackLost(false, true, false), "recognized suppresses unknown on lost") && ok;

    ok = expectTrue(guard::events::shouldSendUnknownFaceAfterDelay(false, false, false, 1500, 1500, true), "unknown after delay") && ok;
    ok = expectFalse(guard::events::shouldSendUnknownFaceAfterDelay(false, false, false, 500, 1500, true), "unknown before delay") && ok;
    ok =
      expectFalse(guard::events::shouldSendUnknownFaceAfterDelay(false, true, false, 5000, 1500, true), "recognized suppresses unknown delay") && ok;
    ok =
      expectFalse(guard::events::shouldSendUnknownFaceAfterDelay(false, false, false, 5000, 1500, false), "unknown blocked until registry loads") &&
      ok;

    ok = expectTrue(guard::events::shouldPlayUnknownIncomingVoice(true, true), "unknown voice incoming enabled") && ok;
    ok = expectFalse(guard::events::shouldPlayUnknownIncomingVoice(false, true), "unknown voice outgoing blocked") && ok;
    ok = expectFalse(guard::events::shouldPlayUnknownIncomingVoice(true, false), "unknown voice policy disabled") && ok;

    ok = expectTrue(guard::events::shouldPlayUnapprovedIncomingVoice(true, false, true), "unapproved voice when denied") && ok;
    ok = expectFalse(guard::events::shouldPlayUnapprovedIncomingVoice(true, true, true), "approved user silent") && ok;
    ok = expectFalse(guard::events::shouldPlayUnapprovedIncomingVoice(false, false, true), "outgoing camera silent") && ok;

    return ok ? 0 : 1;
}
