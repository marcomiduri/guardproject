QT += core
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-face-overlays-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/model

SOURCES += \
    $$PWD/face_overlays_smoke.cpp \
    $$GUARD_ROOT/src/model/GuardFaceEventHelpers.cpp

HEADERS += \
    $$GUARD_ROOT/src/model/CameraUiModel.h \
    $$GUARD_ROOT/src/model/GuardFaceEventHelpers.h
