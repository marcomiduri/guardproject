# Face overlay smoke test

Verifies Task 10 helper logic:

- overlay label formatting
- face track keys
- backend camera ID gating
- one-upload-per-track decision helpers
- access-voice policy helpers

Build and run:

```bat
cd Desktop\Guard\tests\face-overlays
mkdir build
cd build
qmake ..\face-overlays-smoke.pro CONFIG+=release
nmake release
release\guard-face-overlays-smoke.exe
```

Exit code `0` means success.
