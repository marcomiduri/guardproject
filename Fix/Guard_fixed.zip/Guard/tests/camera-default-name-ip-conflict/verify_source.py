from pathlib import Path

root = Path(__file__).resolve().parents[2]
main_h = (root / 'src/app/MainWindow.h').read_text(encoding='utf-8')
main = (root / 'src/app/MainWindow.cpp').read_text(encoding='utf-8')
dialog_h = (root / 'src/ui/camera/CameraDialog.h').read_text(encoding='utf-8')
dialog = (root / 'src/ui/camera/CameraDialog.cpp').read_text(encoding='utf-8')

checks = {
    'camera dialog exposes default name setter': 'setDefaultCameraName' in dialog_h and 'void CameraDialog::setDefaultCameraName' in dialog,
    'default name uses current camera count plus one': 'cameraCount()' in main and 'tr("Camera %1").arg(nextNumber)' in main,
    'add camera applies generated default name': 'dialog.setDefaultCameraName(nextDefaultCameraName());' in main,
    'ip conflict helper exists': 'hasCameraIpConflict' in main_h and 'bool MainWindow::hasCameraIpConflict' in main,
    'add camera rejects duplicate ip': 'Camera IP Conflict' in main and 'hasCameraIpConflict(camera, QString()' in main,
    'edit camera ignores itself and rejects duplicate ip': 'hasCameraIpConflict(updated, cameraId' in main,
    'rtsp host participates in conflict check': 'url.host().trimmed()' in main,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(f'{len(failed)} camera naming/IP check(s) failed')
