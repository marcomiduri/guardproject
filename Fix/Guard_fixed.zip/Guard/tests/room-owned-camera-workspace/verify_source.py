from pathlib import Path

root = Path(__file__).resolve().parents[2]
main = (root / 'src/app/MainWindow.cpp').read_text(encoding='utf-8')
dialog = (root / 'src/ui/dialogs/RoomConnectionDialog.cpp').read_text(encoding='utf-8')

checks = {
    'room disconnect invokes coordinated full workspace teardown':
        'removeAllCameraTilesLocally(&teardownError)' in main,
    'room teardown stops all controllers before collecting reusable slots':
        main.find('controller->stop();', main.find('bool MainWindow::removeAllCameraTilesLocally'))
        < main.find('controller->ownsReusableGuardVisionStreamSlot()', main.find('bool MainWindow::removeAllCameraTilesLocally')),
    'room teardown retains native slots before controller deletion':
        main.find('m_reusableGuardVisionStreamSlots.append(slot);', main.find('bool MainWindow::removeAllCameraTilesLocally'))
        < main.find('delete controller;', main.find('bool MainWindow::removeAllCameraTilesLocally')),
    'room dialog clears previous room camera snapshot': 'cameras_.clear();' in dialog,
    'room sync treats backend list as authoritative': 'The visible camera workspace belongs to exactly one room' in main,
    'room sync removes stale camera tiles': 'staleCameraIds' in main and 'removeCameraTileLocally(cameraId);' in main,
    'room sync adds selected room cameras': 'addCameraTile(target);' in main,
    'first-room unassigned cameras remain eligible for enrollment':
        'containsDifferentRoom' in main and 'return !cameraRoomId.isEmpty() && cameraRoomId != normalizedRoomId;' in main,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(f'{len(failed)} room-owned workspace check(s) failed')
