# Room reconnect lifecycle regression check

Run:

```bash
python tests/room-reconnect-lifecycle/verify_source.py
```

The check protects the deliberate-room-disconnect event gate, canonical backend camera identity, deferred face-registry application for retained inactive streams, and non-destructive backend camera synchronization.
