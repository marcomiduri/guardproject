#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
main = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
controller_h = (root / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")
controller_cpp = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
coordinator_h = (root / "src/services/events/GuardEventCoordinator.h").read_text(encoding="utf-8")
coordinator_cpp = (root / "src/services/events/GuardEventCoordinator.cpp").read_text(encoding="utf-8")
helpers = (root / "src/model/GuardFaceEventHelpers.cpp").read_text(encoding="utf-8")

checks = {
    "canonical backend camera id required": "return !camera.backendCameraId.trimmed().isEmpty();" in helpers,
    "room assignment gates event uploads": "!backendRoomAssigned_" in coordinator_cpp,
    "room transition clears transient event state": "void GuardEventCoordinator::resetForRoomTransition()" in coordinator_cpp
        and "faceTracks_.clear();" in coordinator_cpp and "hazardUploadSent_.clear();" in coordinator_cpp,
    "old room callbacks are generation guarded": "requestRoomGeneration != backendRoomGeneration_" in coordinator_cpp,
    "main window updates event room assignment": "setBackendRoomAssigned(state.isRegistered() && m_sessionManager->hasLiveAccessToken())" in main,
    "controller exposes active native stream": "isGuardVisionStreamActive() const" in controller_h
        and "!streamRetainedForReuse_ && activeGuardVisionGeneration_ != 0" in controller_cpp,
    "registry waits for active stream": "if (!hasActiveGuardVisionStream())" in main,
    "room sync safely removes cameras outside selected room": "removeCameraTileLocally(cameraId);" in main
        and "The visible camera workspace belongs to exactly one room" in main,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} room reconnect lifecycle check(s) failed")
