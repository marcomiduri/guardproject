# Task 11 hazard smoke test

Build and run:

```bat
cd Desktop\Guard\tests\hazard-events
mkdir build
cd build
qmake ..\hazard-events-smoke.pro CONFIG+=release
nmake release
release\guard-hazard-events-smoke.exe
```

Exit code `0` means success.
