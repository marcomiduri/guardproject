QT += core
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-hazard-events-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
GUARDVISION_ROOT = $$clean_path($$GUARD_ROOT/../GuardVision)
INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/model \
    $$GUARDVISION_ROOT/include

SOURCES += \
    $$PWD/hazard_events_smoke.cpp \
    $$GUARD_ROOT/src/model/GuardHazardEventHelpers.cpp

HEADERS += \
    $$GUARD_ROOT/src/model/CameraUiModel.h \
    $$GUARD_ROOT/src/model/GuardEventModels.h \
    $$GUARD_ROOT/src/model/GuardHazardEventHelpers.h
