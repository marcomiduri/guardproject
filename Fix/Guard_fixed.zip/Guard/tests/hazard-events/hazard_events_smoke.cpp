#include "model/GuardHazardEventHelpers.h"
#include "model/GuardEventModels.h"

#include <hazard/HazardTypes.h>

#include <QCoreApplication>
#include <QSet>
#include <cstring>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectFalse(bool value, const char* label) {
    if (!value)
        return true;
    std::fprintf(stderr, "Expected false: %s\n", label);
    return false;
}

bool expectEqual(const char* actual, const char* expected, const char* label) {
    if (actual == expected || (actual && expected && std::strcmp(actual, expected) == 0))
        return true;
    std::fprintf(stderr, "Unexpected %s: got %s expected %s\n", label, actual ? actual : "(null)", expected ? expected : "(null)");
    return false;
}

GuardHazardDetection detection(int hazardType, double confidence = 0.93) {
    GuardHazardDetection item;
    item.hazardType = hazardType;
    item.confidence = confidence;
    item.bounds = QRect(10, 10, 40, 40);
    return item;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;
    ok = expectEqual(
           guard::events::hazardOccurrenceKey(QStringLiteral("camera-a"), static_cast<int>(guardvision::HazardType::Fire)).toUtf8().constData(),
           "camera-a:0", "fire hazard key") &&
         ok;
    ok = expectEqual(guard::events::hazardSnapshotLabel(static_cast<int>(guardvision::HazardType::Smoke), 0.87).toUtf8().constData(), "SMOKE 87%",
                     "smoke snapshot label") &&
         ok;

    ok = expectTrue(guard::events::shouldHandleHazardStarted(static_cast<int>(guardvision::HazardEventType::Started)), "started event") && ok;
    ok = expectFalse(guard::events::shouldHandleHazardStarted(static_cast<int>(guardvision::HazardEventType::Updated)),
                     "updated event skips upload handling") &&
         ok;
    ok =
      expectTrue(guard::events::shouldMaintainHazardAlarm(static_cast<int>(guardvision::HazardEventType::Started)), "started maintains alarm") && ok;
    ok =
      expectTrue(guard::events::shouldMaintainHazardAlarm(static_cast<int>(guardvision::HazardEventType::Updated)), "updated maintains alarm") && ok;
    ok =
      expectFalse(guard::events::shouldMaintainHazardAlarm(static_cast<int>(guardvision::HazardEventType::Ended)), "ended does not maintain alarm") &&
      ok;
    ok = expectTrue(guard::events::shouldHandleHazardEnded(static_cast<int>(guardvision::HazardEventType::Ended)), "ended event") && ok;

    QSet<QString> uploaded;
    QVector<GuardHazardDetection> detections;
    detections.append(detection(static_cast<int>(guardvision::HazardType::Fire)));
    ok = expectTrue(guard::events::shouldUploadHazardOnStarted(uploaded, QStringLiteral("camera-a"), detections), "first started upload") && ok;
    uploaded.insert(guard::events::hazardOccurrenceKey(QStringLiteral("camera-a"), static_cast<int>(guardvision::HazardType::Fire)));
    ok =
      expectFalse(guard::events::shouldUploadHazardOnStarted(uploaded, QStringLiteral("camera-a"), detections), "duplicate started upload blocked") &&
      ok;

    detections.append(detection(static_cast<int>(guardvision::HazardType::Smoke)));
    ok =
      expectTrue(guard::events::shouldUploadHazardOnStarted(uploaded, QStringLiteral("camera-a"), detections), "new hazard type uploads once") && ok;

    const QStringList cleared = guard::events::hazardUploadKeysToClearOnEnded(QStringLiteral("camera-a"), QVector<GuardHazardDetection>(), true);
    ok = expectTrue(cleared.size() == 2, "ended-all clears fire and smoke keys") && ok;

    ok = expectTrue(guard::events::shouldSoundPcHazardAlarm(true, 2, false, true), "alarm sounds when active") && ok;
    ok = expectFalse(guard::events::shouldSoundPcHazardAlarm(true, 2, true, true), "acknowledged alarm silent") && ok;
    ok = expectTrue(guard::events::shouldSoundPcHazardAlarm(true, 1, true, false), "repeat-disabled alarm still sounds") && ok;
    ok = expectFalse(guard::events::shouldSoundPcHazardAlarm(false, 3, false, true), "disabled alarm silent") && ok;

    return ok ? 0 : 1;
}
