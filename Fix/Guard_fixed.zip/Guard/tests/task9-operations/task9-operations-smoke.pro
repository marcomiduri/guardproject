QT += core
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-task9-operations-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/model

SOURCES += \
    $$PWD/task9_operations_smoke.cpp \
    $$GUARD_ROOT/src/model/GuardBackendModels.cpp

HEADERS += \
    $$GUARD_ROOT/src/model/GuardBackendModels.h \
    $$GUARD_ROOT/src/model/CameraUiModel.h
