#include "model/GuardBackendModels.h"

#include <QCoreApplication>
#include <QJsonObject>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectFalse(bool value, const char* label) {
    if (!value)
        return true;
    std::fprintf(stderr, "Expected false: %s\n", label);
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;

    guard::backend::NotificationSettings nested;
    QJsonObject nestedRoot;
    QJsonObject settings;
    settings.insert(QStringLiteral("notifyUnknownIncoming"), false);
    settings.insert(QStringLiteral("notifyUnapprovedIncoming"), true);
    nestedRoot.insert(QStringLiteral("settings"), settings);
    ok = expectTrue(guard::backend::parseNotificationSettingsFromJson(nestedRoot, &nested), "parse nested settings") && ok;
    ok = expectFalse(nested.notifyUnknownIncoming, "nested unknown flag") && ok;
    ok = expectTrue(nested.notifyUnapprovedIncoming, "nested unapproved flag") && ok;

    guard::backend::NotificationSettings topLevel;
    QJsonObject flatRoot;
    flatRoot.insert(QStringLiteral("notifyUnknownIncoming"), true);
    flatRoot.insert(QStringLiteral("notifyUnapprovedIncoming"), false);
    ok = expectTrue(guard::backend::parseNotificationSettingsFromJson(flatRoot, &topLevel), "parse flat settings") && ok;
    ok = expectTrue(topLevel.notifyUnknownIncoming, "flat unknown flag") && ok;
    ok = expectFalse(topLevel.notifyUnapprovedIncoming, "flat unapproved flag") && ok;

    ok =
      expectFalse(guard::backend::shouldReloadFaceRegistry(QStringLiteral("v1"), true, QStringLiteral("v1")), "unchanged version skips reload") && ok;
    ok = expectTrue(guard::backend::shouldReloadFaceRegistry(QStringLiteral("v1"), true, QStringLiteral("v2")), "changed version reloads") && ok;
    ok = expectTrue(guard::backend::shouldReloadFaceRegistry(QString(), false, QStringLiteral("v1")), "initial load reloads") && ok;

    return ok ? 0 : 1;
}
