# Guard Task 9 operations smoke test

Verifies notification-settings parsing, face-registry reload gating, and related Task 9 helpers.

```bat
mkdir build
cd build
qmake ..\task9-operations-smoke.pro CONFIG+=release
nmake release
release\guard-task9-operations-smoke.exe
```

Exit code `0` means success.
