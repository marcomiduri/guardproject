# Tray Exit shutdown source verification

Run:

```bash
python tests/tray-exit-shutdown/verify_source.py
```

The verification checks that final system-tray Exit:

- stops event delivery and camera producers before native detachment;
- retains the process-lifetime GuardVision runtime rather than invoking the unsafe vendor teardown path;
- disconnects active decoder and recorder callbacks;
- quits and joins file/RTSP worker `QThread` event loops;
- shuts down and joins the motion recorder `std::thread`;
- discards stale queued `MetaCall` deliveries only after producers are joined; and
- schedules the final `QCoreApplication::quit()` after the tray action call stack can unwind.
