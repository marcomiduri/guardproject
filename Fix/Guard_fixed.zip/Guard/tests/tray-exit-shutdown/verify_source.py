#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
main_cpp = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
main_h = (root / "src/app/MainWindow.h").read_text(encoding="utf-8")
controller_cpp = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
controller_h = (root / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")
adapter_cpp = (root / "src/runtime/integration/guardvision/GuardVisionEventListenerAdapter.cpp").read_text(encoding="utf-8")
adapter_h = (root / "src/runtime/integration/guardvision/GuardVisionEventListenerAdapter.h").read_text(encoding="utf-8")
coordinator_cpp = (root / "src/services/events/GuardEventCoordinator.cpp").read_text(encoding="utf-8")
coordinator_h = (root / "src/services/events/GuardEventCoordinator.h").read_text(encoding="utf-8")
media_cpp = (root / "src/runtime/media/MediaSourceController.cpp").read_text(encoding="utf-8")
media_h = (root / "src/runtime/media/MediaSourceController.h").read_text(encoding="utf-8")
recorder_cpp = (root / "src/runtime/media/recording/MotionVideoRecorder.cpp").read_text(encoding="utf-8")

assert "void performApplicationShutdown();" in main_h
assert "void detachNativeRuntimeForProcessExit();" in main_h
assert "void prepareForApplicationShutdown();" in controller_h
assert "void shutdownWorkerThreadsForApplicationExit();" in media_h
assert "void beginApplicationShutdown();" in coordinator_h

start = main_cpp.index("void MainWindow::performApplicationShutdown()")
end = main_cpp.index("void MainWindow::initializeBackendIntegration()", start)
body = main_cpp[start:end]

required = [
    "m_eventCoordinator->beginApplicationShutdown()",
    "m_eventAdapter->disable()",
    "controller->prepareForApplicationShutdown()",
    "detachNativeRuntimeForProcessExit()",
    "delete controller",
]
for needle in required:
    assert needle in body, f"Missing shutdown step: {needle}"

assert body.index("m_eventCoordinator->beginApplicationShutdown()") < body.index("controller->prepareForApplicationShutdown()")
assert body.index("controller->prepareForApplicationShutdown()") < body.index("detachNativeRuntimeForProcessExit()")
assert body.index("detachNativeRuntimeForProcessExit()") < body.index("delete controller")
assert "waitForGuardVisionIdle" not in body
assert "controller->setParent(nullptr)" not in body

start = main_cpp.index("void MainWindow::detachNativeRuntimeForProcessExit()")
end = main_cpp.index("void MainWindow::performApplicationShutdown()", start)
abandon_body = main_cpp[start:end]
assert "m_eventAdapter->disable()" in abandon_body
assert "ShutdownMode::ProcessExit" in abandon_body
assert "m_guardVision.reset()" in abandon_body
assert "m_guardVision.release()" not in abandon_body
assert "setParent(nullptr)" not in abandon_body

start = main_cpp.index("void MainWindow::quitApplication()")
quit_body = main_cpp[start:]
assert quit_body.index("performApplicationShutdown()") < quit_body.index("QTimer::singleShot")
assert "QTimer::singleShot(0, qApp" in quit_body
assert "QCoreApplication::quit()" in quit_body

start = controller_cpp.index("void CameraRuntimeController::prepareForApplicationShutdown()")
end = controller_cpp.index("void CameraRuntimeController::stopSynchronouslyForDestruction()", start)
prepare_body = controller_cpp[start:end]
assert "QObject::disconnect(eventAdapter_, nullptr, this, nullptr)" in prepare_body
assert "QObject::disconnect(&mediaController_, nullptr, this, nullptr)" in prepare_body
assert "QObject::disconnect(&recorder_, nullptr, this, nullptr)" in prepare_body
assert "stopSynchronouslyForDestruction()" in prepare_body
assert "mediaController_.shutdownWorkerThreadsForApplicationExit()" in prepare_body
assert "recorder_.shutdown()" in prepare_body
assert prepare_body.index("stopSynchronouslyForDestruction()") < prepare_body.index("mediaController_.shutdownWorkerThreadsForApplicationExit()") < prepare_body.index("recorder_.shutdown()")
assert "QCoreApplication::removePostedEvents(this, QEvent::MetaCall)" in prepare_body

assert "void disable() noexcept;" in adapter_h
assert "std::atomic<bool> callbacksEnabled_{true};" in adapter_h
assert "callbacksEnabled_.store(false, std::memory_order_release)" in adapter_cpp
assert "unknownTrackTimer_.stop()" in coordinator_cpp
assert "retryTimer_.stop()" in coordinator_cpp

start = media_cpp.index("void MediaSourceController::shutdownWorkerThreadsForApplicationExit()")
media_body = media_cpp[start:]
assert "stopAndWaitForQuiescence(0)" in media_body
assert "fileThread_->quit()" in media_body
assert "fileThread_->wait()" in media_body
assert "rtspThread_->quit()" in media_body
assert "rtspThread_->wait" in media_body
assert "QCoreApplication::removePostedEvents(this, QEvent::MetaCall)" in media_body
assert "worker_.join()" in recorder_cpp

print("Tray Exit now joins Guard workers and GuardVision process-exit workers before Qt teardown.")
