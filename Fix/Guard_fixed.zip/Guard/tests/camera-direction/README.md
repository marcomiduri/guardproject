# Guard camera direction smoke test

Verifies Task 7 API conversion, migration detection, and card title behavior.

```bat
mkdir build
cd build
qmake ..\camera-direction-smoke.pro CONFIG+=release
nmake release
release\guard-camera-direction-smoke.exe
```

Exit code `0` means success.
