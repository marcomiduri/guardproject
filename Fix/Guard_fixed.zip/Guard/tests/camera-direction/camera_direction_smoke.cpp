#include "model/CameraUiModel.h"

#include <QCoreApplication>
#include <QJsonObject>
#include <cstring>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectEqual(const char* actual, const char* expected, const char* label) {
    if (actual == expected || (actual && expected && std::strcmp(actual, expected) == 0))
        return true;
    std::fprintf(stderr, "Unexpected %s: got %s expected %s\n", label, actual ? actual : "(null)", expected ? expected : "(null)");
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;
    ok = expectEqual(cameraDirectionApiValue(CameraDirection::Incoming).toUtf8().constData(), "in", "incoming api value") && ok;
    ok = expectEqual(cameraDirectionApiValue(CameraDirection::Outgoing).toUtf8().constData(), "out", "outgoing api value") && ok;
    ok = expectTrue(cameraDirectionFromApiValue(QStringLiteral("in")) == CameraDirection::Incoming, "parse in") && ok;
    ok = expectTrue(cameraDirectionFromApiValue(QStringLiteral("OUT")) == CameraDirection::Outgoing, "parse out") && ok;

    QJsonObject legacyCamera;
    legacyCamera.insert(QStringLiteral("id"), QStringLiteral("camera-1"));
    ok = expectTrue(!cameraDirectionConfiguredFromStoredJson(legacyCamera), "legacy camera unconfirmed") && ok;

    QJsonObject configuredCamera;
    configuredCamera.insert(QStringLiteral("direction"), QStringLiteral("out"));
    ok = expectTrue(cameraDirectionConfiguredFromStoredJson(configuredCamera), "configured camera confirmed") && ok;

    CameraUiModel unconfirmed;
    unconfirmed.name = QStringLiteral("Lobby");
    unconfirmed.directionConfigured = false;
    unconfirmed.direction = CameraDirection::Incoming;
    ok = expectEqual(cameraCardTitleText(unconfirmed).toUtf8().constData(), "Lobby", "unconfirmed title") && ok;

    CameraUiModel incoming;
    incoming.name = QStringLiteral("Lobby");
    incoming.direction = CameraDirection::Incoming;
    incoming.directionConfigured = true;
    ok = expectEqual(cameraCardTitleText(incoming).toUtf8().constData(), "Lobby [IN]", "incoming title") && ok;

    CameraUiModel outgoing;
    outgoing.name = QStringLiteral("Exit");
    outgoing.direction = CameraDirection::Outgoing;
    outgoing.directionConfigured = true;
    ok = expectEqual(cameraCardTitleText(outgoing).toUtf8().constData(), "Exit [OUT]", "outgoing title") && ok;
    ok = expectEqual(cameraDirectionBadgeLabel(CameraDirection::Outgoing).toUtf8().constData(), "OUT", "badge label") && ok;

    return ok ? 0 : 1;
}
