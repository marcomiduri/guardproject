from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = (ROOT / "src/ui/camera/CameraWidget.cpp").read_text(encoding="utf-8")
FUNCTION = SOURCE.split("void CameraWidget::updateConnectionButtons()", 1)[1].split(
    "void CameraWidget::updateStatusIndicator()", 1
)[0]

assert "bool settingsEnabled = true;" in FUNCTION

connecting = FUNCTION.split("case CameraStatus::Connecting:", 1)[1].split("case CameraStatus::Connected:", 1)[0]
assert "settingsEnabled = false;" in connecting

reconnecting = FUNCTION.split("case CameraStatus::Reconnecting:", 1)[1].split("case CameraStatus::Error:", 1)[0]
assert "settingsEnabled = false;" in reconnecting

assert "ui->settingsButton->setEnabled(settingsEnabled);" in FUNCTION

# Terminal states leave the default true value intact so the button is restored
# after success, failure, cancellation, or a completed disconnect.
for state, next_state in [
    ("Disconnected", "Connecting"),
    ("Connected", "Reconnecting"),
    ("Error", None),
]:
    section = FUNCTION.split(f"case CameraStatus::{state}:", 1)[1]
    if next_state:
        section = section.split(f"case CameraStatus::{next_state}:", 1)[0]
    else:
        section = section.split("ui->connectButton->setEnabled", 1)[0]
    assert "settingsEnabled = false;" not in section

print("camera settings connection lock source verification passed")
