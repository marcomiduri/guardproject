# Camera Settings Connection Lock Verification

Verifies that each camera tile disables its **Settings** button while the camera is in `Connecting` or `Reconnecting`, and restores the button automatically when the state becomes `Connected`, `Disconnected`, or `Error`.
