# Room-switch slot rebinding and hazard reset verification

This regression check verifies the safe room lifecycle:

1. All old-room media producers are stopped and quiesced.
2. Native GuardVision registrations are transferred into a process-lifetime slot pool before controllers are deleted.
3. Room disconnect/switch never calls per-stream `GuardVision::unregisterStream()`.
4. New-room controllers are newly created and lazily adopt retained native slots with continuous frame sequence/timestamp cursors.
5. Slots owned by never-played controllers are not lost.
6. The room transition immediately clears hazard audio/indicator state and rejects delayed old-room face/hazard callbacks.
