#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
main_cpp = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
main_h = (root / "src/app/MainWindow.h").read_text(encoding="utf-8")
controller_h = (root / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")
controller_cpp = (root / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
alerts_h = (root / "src/services/alerts/LocalAlertService.h").read_text(encoding="utf-8")
alerts_cpp = (root / "src/services/alerts/LocalAlertService.cpp").read_text(encoding="utf-8")
coordinator_h = (root / "src/services/events/GuardEventCoordinator.h").read_text(encoding="utf-8")
coordinator_cpp = (root / "src/services/events/GuardEventCoordinator.cpp").read_text(encoding="utf-8")

room_teardown_start = main_cpp.find("bool MainWindow::removeAllCameraTilesLocally")
room_teardown_end = main_cpp.find("bool MainWindow::ensureCameraWorkspaceRoom", room_teardown_start)
room_teardown = main_cpp[room_teardown_start:room_teardown_end]

checks = {
    "process-lifetime retained slot pool is present":
        "ReusableGuardVisionStreamSlot" in main_h
        and "m_reusableGuardVisionStreamSlots" in main_h,
    "room teardown quiesces every old producer before slot transfer":
        room_teardown.find("controller->stop();") >= 0
        and room_teardown.find("controller->stop();") < room_teardown.find("controller->ownsReusableGuardVisionStreamSlot()"),
    "room teardown transfers every owned native slot before deletion":
        room_teardown.find("m_reusableGuardVisionStreamSlots.append(slot);") >= 0
        and room_teardown.find("m_reusableGuardVisionStreamSlots.append(slot);") < room_teardown.find("delete controller;"),
    "room teardown avoids unstable native unregister":
        "releaseGuardVisionStream" not in room_teardown
        and "unregisterStream" not in room_teardown,
    "new controllers can adopt retained streams with cursor continuity":
        "retainedStreamId" in controller_h
        and "setSubmissionCursor(retainedNextSubmissionSequence, retainedNextSubmissionTimestampMs);" in controller_cpp,
    "room identity is propagated to event coordinator":
        "setActiveRoomId(state.isRegistered() ? roomId : QString())" in main_cpp,
    "room transition hard-resets hazard service":
        "void resetHazardState();" in alerts_h
        and "activeHazards_.clear();" in alerts_cpp
        and "hazardIndicatorVisibleUntilMs_ = 0;" in alerts_cpp,
    "coordinator clears local hazard state on room transition":
        "localAlerts_->resetHazardState();" in coordinator_cpp,
    "stale old-room face and hazard events are rejected":
        "bool acceptsCameraRoom(const CameraUiModel& camera) const;" in coordinator_h
        and "!acceptsCameraRoom(occurrence.camera)" in coordinator_cpp
        and "return cameraRoomId == activeRoomId_;" in coordinator_cpp,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit(f"{len(failed)} room-switch check(s) failed: " + ", ".join(failed))
