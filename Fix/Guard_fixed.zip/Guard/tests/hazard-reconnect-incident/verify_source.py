#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
coordinator_h = (root / 'src/services/events/GuardEventCoordinator.h').read_text(encoding='utf-8')
coordinator = (root / 'src/services/events/GuardEventCoordinator.cpp').read_text(encoding='utf-8')
alerts = (root / 'src/services/alerts/LocalAlertService.cpp').read_text(encoding='utf-8')

assert 'QSet<QString> activeHazardIncidentKeys_;' in coordinator_h
assert 'beginsNewLocalIncident' in coordinator
assert 'HazardEventType::Started' in coordinator
assert 'hazardUploadSent_.remove(fireKey)' in coordinator
assert 'hazardUploadSent_.remove(smokeKey)' in coordinator
assert 'activeHazardIncidentKeys_.remove(fireKey)' in coordinator
assert 'activeHazardIncidentKeys_.remove(smokeKey)' in coordinator
assert 'const bool isNewOccurrence = !activeHazards_.contains(occurrenceKey);' in alerts
assert 'if (isNewOccurrence)\n        acknowledged_ = false;' in alerts
print('Hazard reconnect incident boundary verification passed.')
