from pathlib import Path

root = Path(__file__).resolve().parents[2]
message_h = (root / 'src/platform/ui/GuardMessageDialog.h').read_text(encoding='utf-8')
message_cpp = (root / 'src/platform/ui/GuardMessageDialog.cpp').read_text(encoding='utf-8')
sources = (root / 'build/sources.pri').read_text(encoding='utf-8')
all_cpp = '\n'.join(p.read_text(encoding='utf-8') for p in (root / 'src').rglob('*.cpp'))

checks = {
    'themed message dialog API exists': 'class GuardMessageDialog' in message_h,
    'message dialog reuses camera dialog stylesheet': 'GuardTheme::cameraDialogStyleSheet()' in message_cpp,
    'message dialog uses matching title bar': 'WindowTitleBar::Style::Dialog' in message_cpp,
    'message dialog uses matching frame/content/footer object names': all(token in message_cpp for token in ['dialogFrame', 'dialogContent', 'dialogFooter']),
    'message dialog is included in qmake sources': 'GuardMessageDialog.cpp' in sources and 'GuardMessageDialog.h' in sources,
    'legacy QMessageBox calls are removed': 'QMessageBox::' not in all_cpp,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit(f'{len(failed)} themed-message check(s) failed')
