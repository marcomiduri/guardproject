# Room-switch camera mapping verification

Verifies that room connection uses stable `clientCameraId` values and never sends a backend camera ID from the previously connected room. It also verifies that an already-open Room Connection dialog clears its cached room-specific mappings after disconnect.
