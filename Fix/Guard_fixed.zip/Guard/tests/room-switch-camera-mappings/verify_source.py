from pathlib import Path

root = Path(__file__).resolve().parents[2]
models = (root / 'src/model/GuardBackendModels.cpp').read_text(encoding='utf-8')
dialog = (root / 'src/ui/dialogs/RoomConnectionDialog.cpp').read_text(encoding='utf-8')

checks = {
    'connect payload uses target room': 'cameraToApiJson(camera, request.roomId)' in models,
    'connect payload omits stale backend id': 'cameraObject.remove(QStringLiteral(\"id\"));' in models,
    'dialog clears previous room camera snapshot': 'cameras_.clear();' in dialog,
    'disconnect removes all current camera widgets': 'removeAllCameraTilesLocally(&teardownError)' in (root / 'src/app/MainWindow.cpp').read_text(encoding='utf-8'),
    'room sync loads authoritative backend cameras': 'Loaded %1 camera(s) for the selected room.' in (root / 'src/app/MainWindow.cpp').read_text(encoding='utf-8'),
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit('FAILED: ' + ', '.join(failed))
print('Room-switch camera mapping source verification passed.')
