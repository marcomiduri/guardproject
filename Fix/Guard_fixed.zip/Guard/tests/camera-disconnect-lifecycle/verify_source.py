#!/usr/bin/env python3
"""Source-level regression checks for safe per-camera disconnect teardown."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
controller_cpp = (ROOT / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
controller_h = (ROOT / "src/runtime/camera/CameraRuntimeController.h").read_text(encoding="utf-8")
main_cpp = (ROOT / "src/app/MainWindow.cpp").read_text(encoding="utf-8")

finalize_start = controller_cpp.find("void CameraRuntimeController::finalizeStop")
finalize_end = controller_cpp.find("void CameraRuntimeController::stopSynchronouslyForDestruction", finalize_start)
finalize_body = controller_cpp[finalize_start:finalize_end]

destruction_start = controller_cpp.find("void CameraRuntimeController::stopSynchronouslyForDestruction")
destruction_end = controller_cpp.find("bool CameraRuntimeController::applyConfigsToRegisteredStream", destruction_start)
destruction_body = controller_cpp[destruction_start:destruction_end]

checks = {
    "camera widget disconnect uses asynchronous teardown": "controller->requestStop();" in main_cpp,
    "asynchronous teardown API is declared": "void requestStop();" in controller_h,
    "source generation is invalidated before source stop": controller_cpp.find("activeSourceGeneration_ = 0;")
    < controller_cpp.find("mediaController_.stop();", controller_cpp.find("void CameraRuntimeController::beginStop")),
    "GuardVision callback generation is invalidated before source stop": controller_cpp.find("activeGuardVisionGeneration_ = 0;")
    < controller_cpp.find("mediaController_.stop();", controller_cpp.find("void CameraRuntimeController::beginStop")),
    "disconnect waits without processing UI events": "continueAsynchronousStop" in controller_cpp
    and "stopPollTimer_" in controller_cpp,
    "final cleanup is deferred to a later UI turn": 'QTimer::singleShot(0, this' in controller_cpp,
    "normal disconnect does not call unsafe per-stream unregister": "unregisterStream();" not in finalize_body,
    "normal disconnect retains stream for safe reconnect": "streamRetainedForReuse_ = streamRegistered_;" in finalize_body,
    "reconnect reuses the same controller-owned stream": "Reactivating this camera's GuardVision stream" in controller_cpp
    and "getStreamStatus(streamId_.toStdString(), retainedStatus)" in controller_cpp,
    "stale preview frames require exact active generation": "activeSourceGeneration_ != 0 && generation == activeSourceGeneration_" in controller_cpp,
    "destructor drains producers without per-stream unregister": "stopAndWaitForQuiescence(0)" in destruction_body
    and "unregisterStream();" not in destruction_body,
    "final exit stops GuardVision before deleting prepared controllers": main_cpp.find("detachNativeRuntimeForProcessExit();", main_cpp.find("void MainWindow::performApplicationShutdown"))
    < main_cpp.find("delete controller;", main_cpp.find("void MainWindow::performApplicationShutdown")),
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")

if failed:
    raise SystemExit(f"{len(failed)} disconnect lifecycle check(s) failed")
