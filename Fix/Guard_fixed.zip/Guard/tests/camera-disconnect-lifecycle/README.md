# Camera disconnect lifecycle regression check

Run:

```bash
python tests/camera-disconnect-lifecycle/verify_source.py
```

The check verifies that CameraWidget Disconnect uses the deferred teardown path,
invalidates source and GuardVision callback generations before stopping the
producer, waits for media quiescence without nested event loops, and does not
invoke the crash-prone per-stream GuardVision unregister path.

A disconnected camera retains its GuardVision stream for reuse. The shared
GuardVision instance releases retained streams during coordinated application
shutdown, after all camera media producers have drained.
