#include "GuardApiError.h"

#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectFalse(bool value, const char* label) {
    if (!value)
        return true;
    std::fprintf(stderr, "Expected false: %s\n", label);
    return false;
}

bool expectEqual(const QString& actual, const QString& expected, const char* label) {
    if (actual == expected)
        return true;
    std::fprintf(stderr, "Unexpected %s: got %s expected %s\n", label, actual.toLocal8Bit().constData(), expected.toLocal8Bit().constData());
    return false;
}

guard::backend::GuardApiResponse makeResponse(int httpStatus, const QByteArray& body, bool timedOut = false) {
    guard::backend::GuardApiResponse response;
    response.httpStatus = httpStatus;
    response.body = body;
    response.timedOut = timedOut;
    guard::backend::GuardApiErrorParser::applyToResponse(httpStatus, timedOut, body, &response);
    return response;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    bool ok = true;

    guard::backend::GuardApiError nested;
    const QByteArray nestedBody =
      QByteArrayLiteral(R"({"error":{"code":"CAMERA_NOT_FOUND","message":"The camera does not belong to this installation.","retryable":false}})");
    ok = guard::backend::GuardApiErrorParser::parseFromBody(nestedBody, &nested) && ok;
    ok = expectEqual(nested.code, QStringLiteral("CAMERA_NOT_FOUND"), "nested error code") && ok;
    ok = expectEqual(nested.message, QStringLiteral("The camera does not belong to this installation."), "nested error message") && ok;
    ok = expectTrue(nested.retryableKnown, "nested retryable known") && ok;
    ok = expectFalse(nested.retryable, "nested retryable false") && ok;

    guard::backend::GuardApiResponse parsed = makeResponse(404, nestedBody);
    ok = expectEqual(parsed.errorCode, QStringLiteral("CAMERA_NOT_FOUND"), "response error code") && ok;
    ok = expectFalse(guard::backend::guardApiResponseIsRetryableFailure(parsed), "404 non-retryable failure") && ok;
    ok = expectFalse(guard::backend::guardApiResponseShouldAttemptAuthRetry(parsed), "404 no auth retry") && ok;

    const QByteArray revokedBody =
      QByteArrayLiteral(R"({"error":{"code":"INSTALLATION_REVOKED","message":"Installation revoked.","retryable":false}})");
    guard::backend::GuardApiResponse revoked = makeResponse(403, revokedBody);
    ok = expectTrue(guard::backend::guardApiResponseIsNonRetryableAuthFailure(revoked), "403 revoked auth failure") && ok;
    ok = expectFalse(guard::backend::guardApiResponseIsRetryableFailure(revoked), "403 not retryable") && ok;

    const QByteArray expiredBody = QByteArrayLiteral(R"({"error":{"code":"TOKEN_EXPIRED","message":"JWT expired.","retryable":true}})");
    guard::backend::GuardApiResponse expired = makeResponse(401, expiredBody);
    ok = expectTrue(guard::backend::guardApiResponseShouldAttemptAuthRetry(expired), "expired jwt auth retry") && ok;
    ok = expectFalse(guard::backend::guardApiResponseIsNonRetryableAuthFailure(expired), "expired jwt not permanent auth failure") && ok;
    ok = expectTrue(guard::backend::guardApiResponseIsRetryableFailure(expired), "expired jwt retryable for queue") && ok;

    const QByteArray invalidCredentialBody =
      QByteArrayLiteral(R"({"error":{"code":"DEVICE_CREDENTIAL_INVALID","message":"Invalid device credential.","retryable":false}})");
    guard::backend::GuardApiResponse invalidCredential = makeResponse(401, invalidCredentialBody);
    ok = expectTrue(guard::backend::guardApiResponseIsNonRetryableAuthFailure(invalidCredential), "invalid credential auth failure") && ok;
    ok = expectFalse(guard::backend::guardApiResponseShouldAttemptAuthRetry(invalidCredential), "invalid credential no auth retry") && ok;
    ok = expectTrue(guard::backend::guardApiResponseShouldClearGuardSession(invalidCredential), "invalid credential clears session") && ok;

    const QByteArray installationMissingBody =
      QByteArrayLiteral(R"({"error":{"code":"NOT_FOUND","message":"Guard installation not found","retryable":false}})");
    guard::backend::GuardApiResponse installationMissing = makeResponse(404, installationMissingBody);
    ok = expectTrue(guard::backend::guardApiResponseShouldClearGuardSession(installationMissing), "missing installation clears session") && ok;
    ok = expectFalse(guard::backend::guardApiResponseIsNonRetryableAuthFailure(installationMissing), "404 not generic auth failure") && ok;

    const QByteArray legacyBody = QByteArrayLiteral(R"({"error":"Legacy message","message":"Top-level message"})");
    guard::backend::GuardApiError legacy;
    ok = guard::backend::GuardApiErrorParser::parseFromBody(legacyBody, &legacy) && ok;
    ok = expectEqual(legacy.message, QStringLiteral("Legacy message"), "legacy flat error message") && ok;

    guard::backend::GuardApiResponse timeout;
    timeout.timedOut = true;
    timeout.httpStatus = 0;
    guard::backend::GuardApiErrorParser::applyToResponse(0, true, QByteArray(), &timeout);
    ok = expectTrue(guard::backend::guardApiResponseIsRetryableFailure(timeout), "timeout retryable") && ok;

    return ok ? 0 : 1;
}
