# Task 5 backend client smoke test

This console target verifies the shared backend error contract and retry classification without requiring a live backend.

Build with any supported Windows Qt qmake kit:

```powershell
cd tests\backend-client
qmake backend-client-smoke.pro
nmake
.\release\guard-backend-client-smoke.exe
```

Use the build tool appropriate for the selected Qt kit. Exit code `0` means all checks passed.
