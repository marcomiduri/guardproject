QT += core network
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-backend-client-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/services/backend

SOURCES += \
    $$PWD/backend_client_smoke.cpp \
    $$GUARD_ROOT/src/services/backend/GuardApiError.cpp

HEADERS += \
    $$GUARD_ROOT/src/services/backend/GuardApiError.h
