#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
media = (ROOT / "src/runtime/media/MediaSourceController.cpp").read_text(encoding="utf-8")
controller = (ROOT / "src/runtime/camera/CameraRuntimeController.cpp").read_text(encoding="utf-8")
header = (ROOT / "src/runtime/media/MediaSourceController.h").read_text(encoding="utf-8")

assert "void frameReadyForSubmission(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation);" in header

for method in ("onFileFrameDecoded", "onRtspFrameAvailable", "onHcFrameAvailable"):
    match = re.search(rf"void MediaSourceController::{method}\(.*?\) \{{(?P<body>.*?)\n\}}", media, re.S)
    assert match, f"{method} was not found"
    assert "emit frameReadyForSubmission" in match.group("body"), \
        f"{method} bypasses the common decoded-frame signal"

assert "&CameraRuntimeController::handleDecodedFrame" in controller, \
    "CameraRuntimeController does not connect every media source to the common frame handler"

handler = re.search(
    r"void CameraRuntimeController::handleDecodedFrame\(.*?\) \{(?P<body>.*?)\n\}",
    controller,
    re.S,
)
assert handler, "handleDecodedFrame() was not found"
body = handler.group("body")
for needle in (
    "view_->setFrame(frame)",
    "recorder_.submitDecodedFrame(frame, timestampMs, generation)",
    "FrameSubmissionPipeline::submitDecodedFrame",
    "latestFrame_ = frame",
):
    assert needle in body, f"Common camera frame pipeline is missing {needle!r}"

assert "if (testMode_)" not in body, \
    "Normal camera frames are conditionally bypassed by the test-mode flag"
assert "mediaController_.activeType() == FrameSourceType::ImageFile" in body, \
    "Still-image pacing is not based on the actual source type"

# Onboard candidates are optional hints. They must not replace decoded-frame
# delivery from the camera into the common GuardVision pipeline.
assert "onboardCandidateReady" in controller
assert controller.count("&MediaSourceController::frameReadyForSubmission") == 1

print("normal camera frame pipeline source verification passed")
