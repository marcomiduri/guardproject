# Normal camera frame pipeline verification

This source-level regression test verifies that all decoded frame providers use one shared runtime path:

- test image/video files;
- RTSP cameras;
- HCNetSDK cameras.

All three providers must emit `MediaSourceController::frameReadyForSubmission()`, and `CameraRuntimeController::handleDecodedFrame()` must perform the common preview, decoded-frame recording, GuardVision submission, overlay, and event path without a `--test`-only branch.

Run:

```bash
python tests/normal-camera-frame-pipeline/verify_source.py
```
