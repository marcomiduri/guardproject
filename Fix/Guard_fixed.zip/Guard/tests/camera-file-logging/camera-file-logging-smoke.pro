QT += core
CONFIG += console c++17
CONFIG -= app_bundle
TEMPLATE = app
TARGET = camera-file-logging-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)

INCLUDEPATH += \
    $$GUARD_ROOT/src \
    $$GUARD_ROOT/src/platform/diagnostics

SOURCES += \
    $$PWD/camera_file_logging_smoke.cpp \
    $$GUARD_ROOT/src/platform/diagnostics/CameraFileLogger.cpp

HEADERS += \
    $$GUARD_ROOT/src/platform/diagnostics/CameraFileLogger.h
