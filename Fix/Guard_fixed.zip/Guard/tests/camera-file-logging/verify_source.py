#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

checks = {
    "src/platform/diagnostics/CameraFileLogger.cpp": [
        "QStandardPaths::AppLocalDataLocation",
        'qgetenv("GUARD_LOG_ROOT")',
        'QStringLiteral(".log")',
        "file_->flush()",
        "sanitizedFileStem",
        "persistentLoggingEnabled",
        "setPersistentLoggingEnabled",
        "configuredDirectoryPath",
        "effectiveDirectoryPath",
        "setConfiguredDirectoryPath",
        "diagnostics/cameraLogDirectory",
        "CameraFileLogger::close",
    ],
    "src/runtime/camera/CameraRuntimeController.cpp": [
        "fileLogger_.appendLine(entry",
        "Camera log file initialized: %1",
        "Camera log session started. Camera ID: %1",
        "setFileLoggingEnabled",
        "reloadFileLoggingSettings",
        "Camera file logging disabled from Application Settings.",
        "Camera file logging enabled from Application Settings.",
        "Camera start requested. Camera: %1; source type: %2",
        "Camera stop requested.",
        "Camera stopped safely.",
    ],
    "src/app/MainWindow.cpp": [
        "Open Log File",
        "Open Log Folder",
        "controller->logFilePath()",
        "controllerGuard->logDirectoryPath()",
        "controller->reloadFileLoggingSettings()",
        "File logging is disabled or the log file is unavailable.",
    ],
    "src/ui/dialogs/AppSettingsDialog.cpp": [
        "buildDiagnosticsTab",
        "cameraFileLoggingCheckBox_",
        "CameraFileLogger::persistentLoggingEnabled",
        "CameraFileLogger::setPersistentLoggingEnabled",
        "CameraFileLogger::setConfiguredDirectoryPath",
        "cameraLogDirectoryEdit_",
        "Select Camera Log Folder",
    ],
    "build/sources.pri": [
        "src/platform/diagnostics/CameraFileLogger.cpp",
        "src/platform/diagnostics/CameraFileLogger.h",
    ],
}

for relative, needles in checks.items():
    text = (ROOT / relative).read_text(encoding="utf-8")
    for needle in needles:
        if needle not in text:
            raise SystemExit(f"Missing {needle!r} in {relative}")

print("camera file logging source verification passed")
