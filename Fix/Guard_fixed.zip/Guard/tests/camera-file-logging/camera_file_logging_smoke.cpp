#include "CameraFileLogger.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSettings>
#include <QTemporaryDir>
#include <QTextStream>

namespace {

bool require(bool condition, const QString& message) {
    if (condition)
        return true;
    QTextStream(stderr) << message << Qt::endl;
    return false;
}

QString readFile(const QString& path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return QString();
    return QString::fromUtf8(file.readAll());
}

}  // namespace

int main(int argc, char* argv[]) {
    QCoreApplication app(argc, argv);
    QCoreApplication::setOrganizationName(QStringLiteral("Apex Image"));
    QCoreApplication::setApplicationName(QStringLiteral("GuardLogSmoke"));
    QSettings().clear();

    if (!require(guard::diagnostics::CameraFileLogger::persistentLoggingEnabled(), QStringLiteral("Camera file logging must default to enabled.")))
        return 1;
    guard::diagnostics::CameraFileLogger::setPersistentLoggingEnabled(false);
    if (!require(!guard::diagnostics::CameraFileLogger::persistentLoggingEnabled(),
                 QStringLiteral("The disabled camera file logging preference was not persisted.")))
        return 2;
    guard::diagnostics::CameraFileLogger::setPersistentLoggingEnabled(true);

    QTemporaryDir configuredDirectory;
    if (!require(configuredDirectory.isValid(), QStringLiteral("Configured directory creation failed.")))
        return 3;
    qunsetenv("GUARD_LOG_ROOT");
    QString directoryError;
    if (!require(guard::diagnostics::CameraFileLogger::setConfiguredDirectoryPath(configuredDirectory.path(), &directoryError), directoryError))
        return 4;
    if (!require(guard::diagnostics::CameraFileLogger::configuredDirectoryPath() == QDir::cleanPath(configuredDirectory.path()),
                 QStringLiteral("Configured camera log directory was not persisted.")))
        return 5;
    if (!require(guard::diagnostics::CameraFileLogger::effectiveDirectoryPath() == QDir::cleanPath(configuredDirectory.path()),
                 QStringLiteral("Configured camera log directory is not effective.")))
        return 6;

    QTemporaryDir temporary;
    if (!require(temporary.isValid(), QStringLiteral("Temporary directory creation failed.")))
        return 7;
    qputenv("GUARD_LOG_ROOT", temporary.path().toLocal8Bit());
    if (!require(guard::diagnostics::CameraFileLogger::isDirectoryLockedByEnvironment(),
                 QStringLiteral("GUARD_LOG_ROOT must lock the effective log directory.")))
        return 8;
    if (!require(guard::diagnostics::CameraFileLogger::effectiveDirectoryPath() == QDir(temporary.path()).filePath(QStringLiteral("cameras")),
                 QStringLiteral("GUARD_LOG_ROOT did not override the configured directory.")))
        return 9;

    guard::diagnostics::CameraFileLogger first;
    QString error;
    if (!require(first.configure(QStringLiteral("Front Door"), QStringLiteral("camera-11111111"), &error), error))
        return 10;
    if (!require(QFileInfo(first.filePath()).fileName() == QStringLiteral("Front Door.log"),
                 QStringLiteral("The primary log filename does not match the camera name.")))
        return 11;
    if (!require(first.appendLine(QStringLiteral("2026-07-02 10:00:00.000  Camera source started."), &error), error))
        return 12;
    if (!require(readFile(first.filePath()).contains(QStringLiteral("Camera source started.")), QStringLiteral("Flushed log entry is missing.")))
        return 13;

    guard::diagnostics::CameraFileLogger duplicate;
    if (!require(duplicate.configure(QStringLiteral("Front Door"), QStringLiteral("camera-22222222"), &error), error))
        return 14;
    if (!require(duplicate.filePath() != first.filePath(), QStringLiteral("Duplicate camera names must not share one log file.")))
        return 15;

    guard::diagnostics::CameraFileLogger sanitized;
    if (!require(sanitized.configure(QStringLiteral("Door:A/B?*"), QStringLiteral("camera-33333333"), &error), error))
        return 16;
    if (!require(QFileInfo(sanitized.filePath()).fileName() == QStringLiteral("Door_A_B__.log"),
                 QStringLiteral("Windows-invalid filename characters were not sanitized.")))
        return 17;

    const QString oldPath = first.filePath();
    if (!require(first.configure(QStringLiteral("Lobby Camera"), QStringLiteral("camera-11111111"), &error), error))
        return 18;
    if (!require(QFileInfo(first.filePath()).fileName() == QStringLiteral("Lobby Camera.log"),
                 QStringLiteral("Renamed camera did not receive a matching log filename.")))
        return 19;
    if (!require(first.appendLine(QStringLiteral("2026-07-02 10:01:00.000  Camera renamed."), &error), error))
        return 20;
    if (!require(QFileInfo::exists(oldPath) && QFileInfo::exists(first.filePath()),
                 QStringLiteral("Camera rename should preserve the previous log and create the new log.")))
        return 21;

    const QString renamedPath = first.filePath();
    first.close();
    if (!require(!first.isReady() && first.filePath().isEmpty(), QStringLiteral("Closing a camera logger must release its file.")))
        return 22;

    guard::diagnostics::CameraFileLogger reclaimed;
    if (!require(reclaimed.configure(QStringLiteral("Lobby Camera"), QStringLiteral("camera-44444444"), &error), error))
        return 23;
    if (!require(reclaimed.filePath() == renamedPath, QStringLiteral("Closing a logger must release its filename claim.")))
        return 24;

    return 0;
}
