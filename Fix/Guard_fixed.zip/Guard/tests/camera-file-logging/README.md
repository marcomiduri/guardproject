# Camera file logging smoke test

This Qt Core smoke test verifies:

- the persisted enable/disable preference;
- a user-selected camera log folder stored in `QSettings`;
- `GUARD_LOG_ROOT` precedence over the saved folder;
- immediate log flushing;
- camera-name filenames and Windows filename sanitization;
- duplicate-name isolation;
- rename behavior;
- clean file and filename-claim release.

Build with an available Qt 5.7/5.12/5.14 qmake environment:

```powershell
qmake camera-file-logging-smoke.pro
nmake
.\release\camera-file-logging-smoke.exe
```
