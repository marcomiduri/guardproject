# Face registry loader smoke test

This console smoke test validates the Guard versioned registry contract:

- full registry version, scope, timestamp, model, threshold, and face parsing;
- invalid entries and inconsistent feature dimensions are ignored;
- the version endpoint contract is parsed separately;
- a valid empty registry is accepted.

Build with an available Qt qmake environment:

```text
qmake face-registry-loader-smoke.pro
make
```
