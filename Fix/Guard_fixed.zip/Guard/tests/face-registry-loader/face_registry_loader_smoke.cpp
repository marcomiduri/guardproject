#include "services/api/FaceRegistryLoader.h"

#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>

namespace {

bool expectTrue(bool value, const char* label) {
    if (value)
        return true;
    std::fprintf(stderr, "Expected true: %s\n", label);
    return false;
}

bool expectEqual(int actual, int expected, const char* label) {
    if (actual == expected)
        return true;
    std::fprintf(stderr, "Unexpected %s: got %d expected %d\n", label, actual, expected);
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);

    QJsonObject valid;
    valid.insert(QStringLiteral("id"), 7);
    valid.insert(QStringLiteral("name"), QStringLiteral("  John Smith  "));
    valid.insert(QStringLiteral("feature"), QJsonArray{0.1, 0.2, 0.3});

    QJsonObject missingName;
    missingName.insert(QStringLiteral("id"), 8);
    missingName.insert(QStringLiteral("name"), QString());
    missingName.insert(QStringLiteral("feature"), QJsonArray{0.1, 0.2, 0.3});

    QJsonObject wrongDimension;
    wrongDimension.insert(QStringLiteral("id"), 9);
    wrongDimension.insert(QStringLiteral("name"), QStringLiteral("Wrong Dimension"));
    wrongDimension.insert(QStringLiteral("feature"), QJsonArray{0.1, 0.2});

    QJsonObject root;
    root.insert(QStringLiteral("version"), QStringLiteral("v2:registry-version"));
    root.insert(QStringLiteral("scope"), QStringLiteral("global"));
    root.insert(QStringLiteral("updatedAt"), QStringLiteral("2026-07-01T12:00:00.000Z"));
    root.insert(QStringLiteral("threshold"), 0.48);
    root.insert(QStringLiteral("model"), QStringLiteral("Pikachu"));
    root.insert(QStringLiteral("faces"), QJsonArray{valid, missingName, wrongDimension});

    guard::api::FaceRegistryData registry;
    QString error;
    bool ok = expectTrue(guard::api::FaceRegistryLoader::parseRegistryPayload(QJsonDocument(root).toJson(QJsonDocument::Compact), registry, &error),
                         "parse valid registry payload");
    ok = expectTrue(registry.version == QStringLiteral("v2:registry-version"), "registry version") && ok;
    ok = expectTrue(registry.scope == QStringLiteral("global"), "registry scope") && ok;
    ok = expectTrue(registry.updatedAtUtc.isValid(), "registry updated time") && ok;
    ok = expectEqual(registry.faces.size(), 1, "accepted face count") && ok;
    ok = expectTrue(registry.faces.at(0).name == QStringLiteral("John Smith"), "trimmed display name") && ok;
    ok = expectEqual(static_cast<int>(registry.faces.at(0).feature.size()), 3, "feature dimension") && ok;

    QJsonObject versionRoot;
    versionRoot.insert(QStringLiteral("version"), QStringLiteral("v2:registry-version"));
    versionRoot.insert(QStringLiteral("scope"), QStringLiteral("global"));
    versionRoot.insert(QStringLiteral("updatedAt"), QStringLiteral("2026-07-01T12:00:00.000Z"));
    versionRoot.insert(QStringLiteral("count"), 1);
    versionRoot.insert(QStringLiteral("model"), QStringLiteral("Pikachu"));
    versionRoot.insert(QStringLiteral("threshold"), 0.48);

    guard::api::FaceRegistryVersionInfo version;
    ok = expectTrue(guard::api::FaceRegistryLoader::parseVersionPayload(QJsonDocument(versionRoot).toJson(QJsonDocument::Compact), version, &error),
                    "parse registry version payload") &&
         ok;
    ok = expectTrue(version.version == QStringLiteral("v2:registry-version"), "version response version") && ok;
    ok = expectTrue(version.scope == QStringLiteral("global"), "version response scope") && ok;
    ok = expectEqual(version.count, 1, "version response count") && ok;

    QJsonObject emptyRoot = root;
    emptyRoot.insert(QStringLiteral("version"), QStringLiteral("v2:empty"));
    emptyRoot.insert(QStringLiteral("faces"), QJsonArray{});
    guard::api::FaceRegistryData emptyRegistry;
    ok =
      expectTrue(guard::api::FaceRegistryLoader::parseRegistryPayload(QJsonDocument(emptyRoot).toJson(QJsonDocument::Compact), emptyRegistry, &error),
                 "parse valid empty registry") &&
      ok;
    ok = expectEqual(emptyRegistry.faces.size(), 0, "empty registry face count") && ok;

    return ok ? 0 : 1;
}
