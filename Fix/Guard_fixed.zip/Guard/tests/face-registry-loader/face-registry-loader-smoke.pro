QT += core
CONFIG += console c++11
CONFIG -= app_bundle
TEMPLATE = app
TARGET = guard-face-registry-loader-smoke

GUARD_ROOT = $$clean_path($$PWD/../..)
INCLUDEPATH += \
    $$GUARD_ROOT/src

SOURCES += \
    $$PWD/face_registry_loader_smoke.cpp \
    $$GUARD_ROOT/src/services/api/FaceRegistryLoader.cpp

HEADERS += \
    $$GUARD_ROOT/src/services/api/FaceRegistryLoader.h
