from pathlib import Path

root = Path(__file__).resolve().parents[2]
cpp = (root / 'src/ui/dialogs/AppSettingsDialog.cpp').read_text(encoding='utf-8')
hdr = (root / 'src/ui/dialogs/AppSettingsDialog.h').read_text(encoding='utf-8')
identity = (root / 'src/platform/identity/GuardHardwareId.cpp').read_text(encoding='utf-8')
secure = (root / 'src/platform/security/SecureCredentialStore.cpp').read_text(encoding='utf-8')

checks = {
    'license tab': 'tabs_->addTab(buildLicenseTab(), tr("License"));' in cpp,
    'license tab is last': cpp.index('tabs_->addTab(buildDiagnosticsTab(), tr("Diagnostics"));') < cpp.index('tabs_->addTab(buildLicenseTab(), tr("License"));') and 'constexpr int kLicenseTabIndex = 4;' in cpp,
    'hardware id field': 'GuardHardwareId::displayText()' in cpp and 'hardwareIdEdit_' in hdr,
    'license mask': '>NNNN-NNNN-NNNN-NNNN;_' in cpp,
    'secure license storage': 'SecureCredentialStore::write' in cpp and 'CryptProtectData' in secure,
    'hardware id format': 'QStringLiteral("%1-%2-%3-%4")' in identity,
    'diagnostics effective row removed': 'effectiveCameraLogDirectoryLabel_' not in cpp and 'effectiveCameraLogDirectoryLabel_' not in hdr,
    'recording effective row removed': 'effectiveRecordingRootLabel_' not in cpp and 'effectiveRecordingRootLabel_' not in hdr,
    'recording effective shown in input': 'previewRecordingRoot(settings_.recordingRoot)' in cpp and 'recordingResolution.effectiveRoot' in cpp,
    'recording restore default shows path': 'restoreDefaultRoot()' in cpp and 'previewRecordingRoot(QString())' in cpp,
    'diagnostics default shown in input': 'CameraFileLogger::defaultDirectoryPath()' in cpp and 'displayedLogDirectory' in cpp,
    'restore default shows path': 'restoreDefaultCameraLogDirectory()' in cpp and 'cameraLogDirectoryEdit_->setText' in cpp,
    'wide dialog': 'setMinimumWidth(900);' in cpp and 'resize(920, 540);' in cpp,
    'tabs fit without scroll controls': 'tabBar->setExpanding(true);' in cpp and 'tabBar->setUsesScrollButtons(false);' in cpp,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit('FAILED: ' + ', '.join(failed))
print('Application Settings final source verification passed.')
