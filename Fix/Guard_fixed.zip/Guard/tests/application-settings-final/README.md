# Final Application Settings verification

Checks the behavior-preserving final settings update:

- Diagnostics displays the default camera-log directory directly in the editable path field.
- The redundant Diagnostics `Effective path` row is absent.
- Recording displays the effective recording directory directly in the editable path field.
- The redundant Recording `Effective path` row is absent.
- A License tab exposes the protected hardware ID and masked license-key input.
- License keys are stored through `SecureCredentialStore`, not plain QSettings.

Run:

```bash
python tests/application-settings-final/verify_source.py
```
