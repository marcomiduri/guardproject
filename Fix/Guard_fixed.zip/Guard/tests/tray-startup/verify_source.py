#!/usr/bin/env python3
from pathlib import Path
import re

root = Path(__file__).resolve().parents[2]
cpp = (root / "src/app/MainWindow.cpp").read_text(encoding="utf-8")
h = (root / "src/app/MainWindow.h").read_text(encoding="utf-8")

assert "void showTrayIcon(bool showHint = true);" in h
ctor = re.search(r"MainWindow::MainWindow\(.*?\)\s*:\s*QMainWindow\(parent\).*?\{(?P<body>.*?)\n\}", cpp, re.S)
assert ctor, "MainWindow constructor was not found"
body = ctor.group("body")
assert "setupSystemTray();" in body
assert "showTrayIcon(false);" in body
assert body.find("setupSystemTray();") < body.find("showTrayIcon(false);")
show = re.search(r"void MainWindow::showTrayIcon\(bool showHint\) \{(?P<body>.*?)\n\}", cpp, re.S)
assert show
assert "m_trayIcon->setVisible(true);" in show.group("body")
assert "if (showHint && !m_trayHintShown" in show.group("body")

print("System tray startup registration verification passed.")
