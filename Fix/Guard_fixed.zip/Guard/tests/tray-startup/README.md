# System tray startup verification

Confirms that Guard registers its tray icon on launch without displaying the background/minimize hint balloon.
