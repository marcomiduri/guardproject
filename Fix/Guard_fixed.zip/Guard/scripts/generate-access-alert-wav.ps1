$ErrorActionPreference = 'Stop'
$dir = Join-Path $PSScriptRoot '..\resources\audio'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$synth.Rate = 0
$synth.Volume = 100
$unknownPath = Join-Path $dir 'access_denied_unknown.wav'
$unapprovedPath = Join-Path $dir 'access_denied_unapproved.wav'
$synth.SetOutputToWaveFile($unknownPath)
$synth.Speak('Access denied. You are not registered in the system.')
$synth.SetOutputToWaveFile($unapprovedPath)
$synth.Speak('Access denied. You do not have permission to enter this room at this time.')
$synth.SetOutputToNull()
$synth.Dispose()
Get-ChildItem $dir -Filter 'access_denied_*.wav' | Format-Table Name, Length -AutoSize
