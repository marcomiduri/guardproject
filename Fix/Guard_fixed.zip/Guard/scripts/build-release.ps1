param(
    [string]$QtRoot = '',
    [string]$VsVarsPath = 'C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvars64.bat',
    [ValidateSet('en', 'zh')]
    [string]$DefaultLocale = 'zh'
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

& "$PSScriptRoot\build-common.ps1" -Configuration Release -QtRoot $QtRoot -VsVarsPath $VsVarsPath -DefaultLocale $DefaultLocale

# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBIi8N5El707pKx
# 2TCmKsT6SDijrivaZAS2nkchvHuFd6CCAxIwggMOMIIB9qADAgECAhBxvAE/BCP+
# kE9BycqcYWCXMA0GCSqGSIb3DQEBCwUAMB8xHTAbBgNVBAMMFEd1YXJkMiBCdWls
# ZCBTY3JpcHRzMB4XDTI2MDcwMTA4MTQ1NVoXDTI3MDcwMTA4MzQ1NVowHzEdMBsG
# A1UEAwwUR3VhcmQyIEJ1aWxkIFNjcmlwdHMwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDCTn3z/xRXcuES5iN7qYcxOuQtcP61KbDUix5ldo/+UOivwQU8
# bWQ11Y3crjQ6lZ5M5aIo4wbghq7j3i0tiH+/svKXILaUtiIQPa6UbPfJl5BADDcL
# UT6f8gFrh9Lfnet4sB5qtC9UNp1tesDE8Azc3+t4zCDvQZybkFrWtQbMSTXNULo5
# YiqUW4jGPPYNfbtyw1DvrgV2vYvXcbIWUNEoIu0QGXjnR2GYEf55DX3v7C4MlNCw
# NHgXiVdGcqg8AqBIx6VIMsg72joTrqBGJhrF36Z0m/5h9d2cQ7oXwEfX3BxpK+1Z
# 9Brh4Llz5yZnl1H0Hup+U5SG82itoXbPbg/1AgMBAAGjRjBEMA4GA1UdDwEB/wQE
# AwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU/F+br9cdR2cgzmfy
# 4OdyZEhIP0gwDQYJKoZIhvcNAQELBQADggEBAB0wCvIRP+7/pq6rb7xNkLDZXX0B
# nDuJakQUD6y+fQkbWEJdG2bs8vvLyLrxFPS5d5MKV93Tfod65LH1Jhe27Y0bBaJO
# iPeVsOMHxkSfO+SG24DHJDfXKO1inPrAoWDqgdmijoLUIs34c9mMwvG8MZbH9gRL
# AQ1rEMAqHynozVyQLawlkitCOu1XNl1auYefghxX6p8jpIZo8+hdMHLdVQnyvPVY
# nYx2TyT9EGjsfXmzg0XrlUwLR7+oc1/YG5eh0w01KBRW+aLOPL26eUwdkNRjBo69
# Nbask86Wwovzf8icXYl1cNnOk5GtVqGQvLUq6T6ZJzU715J27fLEB+iw4rYxggHl
# MIIB4QIBATAzMB8xHTAbBgNVBAMMFEd1YXJkMiBCdWlsZCBTY3JpcHRzAhBxvAE/
# BCP+kE9BycqcYWCXMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJoq7JB0xu6StA+HlYd7
# Lsa34+796XSrw4f6qecuJNqSMA0GCSqGSIb3DQEBAQUABIIBAI+PSLS9Y1KpFXpv
# TexrKqUav+O3GgHE/eg1ORf9iKUyQMquAARrEciOP5QOTIJWVMMtZR7RsadmwyZG
# dvsAa/AybrY3PmEZRikFlWRM40CYSXmYl5vCsoQBRNdAQ+WA6JerIGDwuq0nMsMm
# 7Pk93rWv6cQ5DYZa9TWfDGIjieg8tGJhJZSJV6wHvxW3G/84Km1z4TuypskbZkUj
# 4ErA1P82YRfkbyXGnBnkyQZyQYCiv3/EtR+INRPDlK1mIWw+UDZb7nW+Qf3/wlsV
# 9YATCKtADFtPOCaqHezkPOeGHW7jggheIRnDC78NXtPiAcWIHWS7EHMiJR7Df30W
# BOYqSRg=
# SIG # End signature block
