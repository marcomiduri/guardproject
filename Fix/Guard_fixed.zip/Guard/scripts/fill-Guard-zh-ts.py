#!/usr/bin/env python3
"""Fill Guard_zh.ts unfinished entries from existing catalog plus Guard-specific strings."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TS_PATH = ROOT / "translations" / "Guard_zh.ts"

GUARD_TRANSLATIONS = {
    "Guard": "Guard",
    "Guard - Test Mode": "Guard - 测试模式",
    "Guard Computer": "Guard 计算机",
    "Guard License": "Guard 许可证",
    "Show Guard": "显示 Guard",
    "Switch to %1": "切换到 %1",
    "Register Room": "注册房间",
    "Login to Room": "登录房间",
    "Register this computer with a backend room": "将此计算机注册到后端房间",
    "View or unregister this room registration": "查看或注销此房间注册",
    "%1 — Connected": "%1 — 已连接",
    "Enter the one-time activation code issued for this room. The code is used only during registration and is not stored.": "输入为此房间签发的一次性激活码。激活码仅在注册时使用，不会保存在本地。",
    "Room ID or room name": "房间 ID 或房间名称",
    "Activation code": "激活码",
    "Device name": "设备名称",
    "Registering...": "正在注册...",
    "Register": "注册",
    "Enter the one-time activation code.": "请输入一次性激活码。",
    "Silence Alarm": "静音警报",
    "Hazard alarm active": "危险警报已激活",
    "Application settings saved": "应用程序设置已保存",
    "You can add up to %1 cameras.": "最多可添加 %1 个摄像头。",
    "Recording root updated: %1": "录像根目录已更新：%1",
    "Backend session authenticated": "后端会话已认证",
    "GuardVision ready - test mode": "GuardVision 就绪 - 测试模式",
    "GuardVision ready": "GuardVision 就绪",
    "GuardVision unavailable - test mode": "GuardVision 不可用 - 测试模式",
    "GuardVision unavailable": "GuardVision 不可用",
    "This Guard installation has been revoked. Re-register the room or contact an administrator.": "此 Guard 安装已被吊销。请重新注册房间或联系管理员。",
    "The backend entitlement has expired. Enter a valid license in Application Settings.": "后端授权已过期。请在应用程序设置中输入有效许可证。",
    "The free trial has expired. Enter a valid license in Application Settings.": "免费试用已过期。请在应用程序设置中输入有效许可证。",
    "Guard could not verify both required hardware identifiers. Check Windows hardware-management services and retry before registering this computer.": "Guard 无法验证所需的两项硬件标识。请检查 Windows 硬件管理服务，然后重试注册。",
    "Hardware Verification Required": "需要硬件验证",
    "Camera Direction Required": "需要设置摄像头方向",
    "The camera '%1' was created by an older Guard version. Edit it and select Incoming or Outgoing before registering this room.": "摄像头“%1”由旧版 Guard 创建。请先编辑并选择进入或离开方向，再注册此房间。",
    "Room Registration": "房间注册",
    "This computer is registered with %1. Unregister this computer?": "此计算机已注册到 %1。是否注销此计算机？",
    "Alerts": "警报",
    "Recording": "录像",
    "Backend Server": "后端服务器",
    "Base URL": "基础 URL",
    "Not tested": "未测试",
    "Connection": "连接",
    "Backend version": "后端版本",
    "Unknown": "未知",
    "Test Connection": "测试连接",
    "Local Hazard Alarm": "本地危险警报",
    "Play an alarm on this computer": "在此计算机上播放警报",
    "Volume": "音量",
    "Repeat until acknowledged": "重复播放直到确认",
    "Test Alarm": "测试警报",
    "Backend-Controlled Access Warnings": "后端控制的访问警告",
    "Loaded after backend authentication": "后端认证后加载",
    "Unknown incoming": "未知进入",
    "Unapproved incoming": "未批准进入",
    "These policies are configured by an administrator. Disabling a warning never disables event upload.": "这些策略由管理员配置。禁用警告不会禁用事件上传。",
    "Recording Storage": "录像存储",
    "Recording root": "录像根目录",
    "Leave empty to use the default recording location": "留空以使用默认录像位置",
    "Browse...": "浏览...",
    "Effective path": "有效路径",
    "Open Folder": "打开文件夹",
    "Restore Default": "恢复默认",
    "Available space: %1 GB": "可用空间：%1 GB",
    "The folder will be validated when settings are saved.": "保存设置时将验证该文件夹。",
    "Environment override active: GUARD_RECORDING_ROOT": "环境变量覆盖已启用：GUARD_RECORDING_ROOT",
    "Source: %1": "来源：%1",
    "Access denied. You are not registered in the system.": "访问被拒绝。您未在系统中注册。",
    "Access denied. You do not have permission to enter this room at this time.": "访问被拒绝。您当前无权进入此房间。",
    "Disconnected": "未连接",
    "Change language": "切换语言",
    "Open settings": "打开设置",
    "Add Camera": "添加摄像头",
    "Login to room": "登录房间",
    "Application Settings": "应用程序设置",
    "Server": "服务器",
    "License": "许可证",
    "Save": "保存",
    "Source": "来源",
    "Status": "状态",
    "Trial": "试用",
    "Algorithm": "算法",
    "Copy": "复制",
    "Copy Hardware ID": "复制硬件 ID",
    "Activate": "激活",
    "Activate License": "激活许可证",
    "Retry Hardware Detection": "重试硬件检测",
    "Not applicable": "不适用",
    "Free Trial": "免费试用",
    "Trial Expired": "试用已过期",
    "Enter a permanent license key.": "请输入永久许可证密钥。",
    "Invalid License": "无效许可证",
    "Not Licensed": "未授权",
    "Backend client unavailable": "后端客户端不可用",
    "Enter a valid HTTP or HTTPS backend URL.": "请输入有效的 HTTP 或 HTTPS 后端 URL。",
    "Testing...": "正在测试...",
    "Connected": "已连接",
    "Connected; version not reported": "已连接；未报告版本",
    "The license was activated for this computer.": "已在此计算机上激活许可证。",
    "The Guard license key was activated.": "已激活 Guard 许可证密钥。",
    "Select Recording Root": "选择录像根目录",
    "Please enter a camera name.": "请输入摄像头名称。",
    "Please enter an IP address or RTSP URL.": "请输入 IP 地址或 RTSP URL。",
    "Camera Grid": "摄像头网格",
    "No cameras": "无摄像头",
    "Enabled": "已启用",
    "Disabled": "已禁用",
    "Room": "房间",
    "Cancel": "取消",
    "OK": "确定",
    "Close": "关闭",
    "Exit": "退出",
    "Settings": "设置",
    "Add camera": "添加摄像头",
    "English": "English",
    "Permanent license required": "需要永久许可证",
    "Enter Guard license": "输入 Guard 许可证",
    "The temporary 7-day license is missing, invalid, or expired. Enter a permanent license key to continue.": "临时 7 天许可证缺失、无效或已过期。请输入永久许可证密钥以继续。",
    "Copy this hardware ID to LicenseGenerator, then paste the generated Guard license key below.": "将此硬件 ID 复制到 LicenseGenerator，然后将生成的 Guard 许可证密钥粘贴到下方。",
    "Hardware ID": "硬件 ID",
    "License key": "许可证密钥",
    "Hardware ID unavailable": "硬件 ID 不可用",
    "License Information": "许可证信息",
    "Copy the Guard hardware ID into LicenseGenerator. Non-activated LicenseGenerator output creates a 7-day Guard license. Activated LicenseGenerator output creates a permanent Guard license.": "将 Guard 硬件 ID 复制到 LicenseGenerator。未激活的 LicenseGenerator 输出会生成 7 天 Guard 许可证；已激活的输出会生成永久 Guard 许可证。",
    " — %1 day(s) remaining": " — 剩余 %1 天",
    "; expires %1 UTC": "；到期时间 %1 UTC",
    "Hardware ID is unavailable on this computer.": "此计算机上无法获取硬件 ID。",
    "No Guard license key has been saved.": "尚未保存 Guard 许可证密钥。",
    "The saved license key is not valid for this hardware ID.": "已保存的许可证密钥对此硬件 ID 无效。",
    "Permanent Guard license is active.": "永久 Guard 许可证已激活。",
    "The 7-day temporary Guard license has expired.": "7 天临时 Guard 许可证已过期。",
    "Temporary Guard license is active.": "临时 Guard 许可证已激活。",
    "Enter the license key in XXXX-XXXX-XXXX-XXXX format.": "请以 XXXX-XXXX-XXXX-XXXX 格式输入许可证密钥。",
    "This license key is not valid for this Guard hardware ID.": "此许可证密钥对此 Guard 硬件 ID 无效。",
    "The temporary 7-day license has expired. Enter a permanent license key.": "临时 7 天许可证已过期。请输入永久许可证密钥。",
    "The 7-day temporary Guard license has expired. Enter a permanent license key.": "7 天临时 Guard 许可证已过期。请输入永久许可证密钥。",
    "Missing": "缺失",
    "Temporary 7-day license": "临时 7 天许可证",
    "Temporary license expired": "临时许可证已过期",
    "Permanent license": "永久许可证",
    "Invalid license": "无效许可证",
    "Detection": "检测",
    "Motion detection": "运动检测",
    "Face detection": "人脸检测",
    "Hazard detection": "危险检测",
    "Record Video for Motion": "运动时录制视频",
    "Test Source": "测试源",
    "Leave empty for configured camera, or select an image/video file": "留空以使用已配置的摄像头，或选择图片/视频文件",
    "Media file": "媒体文件",
    "The selected file is used only by this camera. Image and video mode are detected from the file extension.": "所选文件仅用于此摄像头。图片和视频模式根据文件扩展名自动识别。",
    "Camera: %1": "摄像头：%1",
    "No test file selected. This camera will use its configured camera source.": "未选择测试文件。此摄像头将使用已配置的摄像头源。",
    "Image mode selected. The image will repeat continuously for this camera.": "已选择图片模式。图片将在此摄像头上连续重复播放。",
    "Video mode selected. The video will loop through the TestLib-style decoder pipeline.": "已选择视频模式。视频将通过 TestLib 风格的解码管线循环播放。",
    "Unsupported test file type. Select JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV.": "不支持的测试文件类型。请选择 JPG、JPEG、PNG、BMP、MP4、AVI、MOV 或 MKV。",
    "Onboard detection becomes available after an HCNetSDK camera connects and its alarm channel is subscribed.": "HCNetSDK 摄像头连接并订阅报警通道后，机载检测才可用。",
    "Image and video test files support software detection only. Onboard and hybrid modes are unavailable for file sources.": "图片和视频测试文件仅支持软件检测。文件源不可使用机载和混合模式。",
    "Onboard alarm route is active.": "机载报警通道已激活。",
    "Software and hybrid hazard detection require models/fire_smoke.onnx beside Guard.exe.": "软件和混合危险检测需要在 Guard.exe 旁放置 models/fire_smoke.onnx。",
    "Select Test Media": "选择测试媒体",
    "Supported Media (*.jpg *.jpeg *.png *.bmp *.mp4 *.avi *.mov *.mkv);;Images (*.jpg *.jpeg *.png *.bmp);;Videos (*.mp4 *.avi *.mov *.mkv);;All Files (*.*)": "支持的媒体 (*.jpg *.jpeg *.png *.bmp *.mp4 *.avi *.mov *.mkv);;图片 (*.jpg *.jpeg *.png *.bmp);;视频 (*.mp4 *.avi *.mov *.mkv);;所有文件 (*.*)",
    "Hazard model not found. Copy models/fire_smoke.onnx beside Guard.exe before enabling hazard detection.": "未找到危险检测模型。启用危险检测前，请将 models/fire_smoke.onnx 复制到 Guard.exe 旁。",
    "Select an existing test media file for this camera.": "请为此摄像头选择现有的测试媒体文件。",
    "The selected test source must be a JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV file.": "所选测试源必须是 JPG、JPEG、PNG、BMP、MP4、AVI、MOV 或 MKV 文件。",
    "No detection": "无检测",
    "Software detection": "软件检测",
    "Onboard detection": "机载检测",
    "Hybrid detection": "混合检测",
    "Camera Settings": "摄像头设置",
    "Incoming — enters the room": "进入 — 进入房间",
    "Outgoing — leaves the room": "离开 — 离开房间",
    "IN": "进",
    "OUT": "出",
}


def load_guard_catalog() -> dict[str, str]:
    catalog: dict[str, str] = {}
    if not TS_PATH.exists():
        return catalog

    tree = ET.parse(TS_PATH)
    for message in tree.getroot().iter("message"):
        source = message.find("source")
        translation = message.find("translation")
        if source is None or translation is None or not source.text or not translation.text:
            continue
        if translation.attrib.get("type") == "unfinished":
            continue
        catalog[source.text] = translation.text
    return catalog


def main() -> int:
    catalog = load_guard_catalog()
    catalog.update(GUARD_TRANSLATIONS)

    tree = ET.parse(TS_PATH)
    root = tree.getroot()
    missing: list[str] = []
    updated = 0

    for message in root.iter("message"):
        source = message.find("source")
        translation = message.find("translation")
        if source is None or translation is None or source.text is None:
            continue

        text = source.text
        zh = catalog.get(text)
        if not zh:
            missing.append(text)
            continue

        translation.text = zh
        translation.attrib.pop("type", None)
        updated += 1

    tree.write(TS_PATH, encoding="utf-8", xml_declaration=True)
    print(f"Updated {updated} translations in {TS_PATH}")
    if missing:
        print(f"Missing {len(missing)} translations:")
        for item in missing[:40]:
            print(f"  - {item!r}")
        if len(missing) > 40:
            print(f"  ... and {len(missing) - 40} more")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
