[CmdletBinding()]
param(
    [string]$QtRoot = '',
    [string]$VsVarsPath = 'C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvars64.bat',
    [switch]$SkipDeploy
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

Write-Host 'Building Guard Debug and Release...' -ForegroundColor Cyan

& "$PSScriptRoot\build-common.ps1" -Configuration Debug -QtRoot $QtRoot -VsVarsPath $VsVarsPath -SkipDeploy:$SkipDeploy
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

& "$PSScriptRoot\build-common.ps1" -Configuration Release -QtRoot $QtRoot -VsVarsPath $VsVarsPath -SkipDeploy:$SkipDeploy
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAXRveloKnZPL60
# wH9+Pmb9tb9uOTZ61hhL6rD6nolVWaCCAxIwggMOMIIB9qADAgECAhBxvAE/BCP+
# kE9BycqcYWCXMA0GCSqGSIb3DQEBCwUAMB8xHTAbBgNVBAMMFEd1YXJkMiBCdWls
# ZCBTY3JpcHRzMB4XDTI2MDcwMTA4MTQ1NVoXDTI3MDcwMTA4MzQ1NVowHzEdMBsG
# A1UEAwwUR3VhcmQyIEJ1aWxkIFNjcmlwdHMwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDCTn3z/xRXcuES5iN7qYcxOuQtcP61KbDUix5ldo/+UOivwQU8
# bWQ11Y3crjQ6lZ5M5aIo4wbghq7j3i0tiH+/svKXILaUtiIQPa6UbPfJl5BADDcL
# UT6f8gFrh9Lfnet4sB5qtC9UNp1tesDE8Azc3+t4zCDvQZybkFrWtQbMSTXNULo5
# YiqUW4jGPPYNfbtyw1DvrgV2vYvXcbIWUNEoIu0QGXjnR2GYEf55DX3v7C4MlNCw
# NHgXiVdGcqg8AqBIx6VIMsg72joTrqBGJhrF36Z0m/5h9d2cQ7oXwEfX3BxpK+1Z
# 9Brh4Llz5yZnl1H0Hup+U5SG82itoXbPbg/1AgMBAAGjRjBEMA4GA1UdDwEB/wQE
# AwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU/F+br9cdR2cgzmfy
# 4OdyZEhIP0gwDQYJKoZIhvcNAQELBQADggEBAB0wCvIRP+7/pq6rb7xNkLDZXX0B
# nDuJakQUD6y+fQkbWEJdG2bs8vvLyLrxFPS5d5MKV93Tfod65LH1Jhe27Y0bBaJO
# iPeVsOMHxkSfO+SG24DHJDfXKO1inPrAoWDqgdmijoLUIs34c9mMwvG8MZbH9gRL
# AQ1rEMAqHynozVyQLawlkitCOu1XNl1auYefghxX6p8jpIZo8+hdMHLdVQnyvPVY
# nYx2TyT9EGjsfXmzg0XrlUwLR7+oc1/YG5eh0w01KBRW+aLOPL26eUwdkNRjBo69
# Nbask86Wwovzf8icXYl1cNnOk5GtVqGQvLUq6T6ZJzU715J27fLEB+iw4rYxggHl
# MIIB4QIBATAzMB8xHTAbBgNVBAMMFEd1YXJkMiBCdWlsZCBTY3JpcHRzAhBxvAE/
# BCP+kE9BycqcYWCXMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICp+dzdf8HHIbb/uPXEE
# astpmrMjf4ihQ2MJ9HucqmihMA0GCSqGSIb3DQEBAQUABIIBAAdHgaAhWDV8k8CO
# ujOdSw1vzCOjymR400Kq/foc+lLIWVZUxENxN6aNdeNf70uR7+J4yTwIDSQ00wrK
# ikBHXr/x4czLm1lzgpWzp0fh+Jz7giFlGagsrbb/jqigwq7EVwgCyjaST61J2dkM
# eaNglm0Gbb8QeMDbpCxQbV624uJ0KmGV7QhuMeIcbrsDIE927iVyBYkp4WTAoGyG
# rV1jMUIkjZaWgCaXv4OIRrIQZtog86AZotfdQKEY4fT9sTtFqrc8ROuObAJc6s+Z
# jgMW9u7pUvI8dQiZdRV/EM0Ydzs11e3O+hdku56nRSaeGjONbvjpJIE2VmmGE3G7
# pZaF2xw=
# SIG # End signature block
