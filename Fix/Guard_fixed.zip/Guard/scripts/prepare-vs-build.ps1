param(
    [ValidateSet('Debug', 'Release', 'all')]
    [string]$Configuration = 'all',
    [string]$QtRoot = $env:QT514
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\win-path-utils.ps1')

function Get-VsDevBatch {
    $candidates = @(
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvars64.bat',
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvars64.bat',
        'C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat'
    )
    foreach ($path in $candidates) {
        if (Test-Path -LiteralPath $path) {
            return $path
        }
    }

    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $vswhere)) {
        throw 'Visual Studio 2019 not found. Install VS 2019 with the C++ desktop workload.'
    }

    $install = & $vswhere -version '[16.0,17.0)' -latest -products * -property installationPath
    if (-not $install) {
        throw 'Visual Studio 2019 not found. Install VS 2019 with the C++ desktop workload.'
    }

    $vcvars = Join-Path $install 'VC\Auxiliary\Build\vcvars64.bat'
    if (-not (Test-Path -LiteralPath $vcvars)) {
        throw "vcvars64.bat not found under VS 2019 install: $install"
    }
    return $vcvars
}

function Invoke-VcVarsCommand {
    param(
        [Parameter(Mandatory = $true)][string[]]$CommandLines
    )

    $vcvars = Get-VsDevBatch
    $command = @(
        '@echo off',
        "call $(Quote-CmdArg $vcvars) >nul",
        'if errorlevel 1 exit /b 1'
    ) + $CommandLines

    $commandFile = Join-Path $env:TEMP "guard-prepare-$PID.cmd"
    Set-Content -LiteralPath $commandFile -Value ($command -join "`r`n") -Encoding ASCII
    try {
        $previousErrorAction = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            cmd.exe /c $(Quote-CmdArg $commandFile)
            if ($LASTEXITCODE -ne 0) {
                throw "Command failed (exit $LASTEXITCODE)."
            }
        } finally {
            $ErrorActionPreference = $previousErrorAction
        }
    } finally {
        Remove-Item -LiteralPath $commandFile -Force -ErrorAction SilentlyContinue
    }
}

$guardRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$guardRootQmake = Resolve-QMakePath $guardRoot
$guardPro = Join-Path $guardRootQmake 'Guard.pro'
$qtRoot = $QtRoot
if ([string]::IsNullOrWhiteSpace($qtRoot) -or -not (Test-Path (Join-Path $qtRoot 'bin\qmake.exe'))) {
    $qtRoot = 'C:\Qt\Qt5.14.2\5.14.2\msvc2017_64'
}

$qmakeExe = Join-Path $qtRoot 'bin\qmake.exe'
if (-not (Test-Path -LiteralPath $qmakeExe)) {
    throw 'Qt qmake not found. Set -QtRoot or env:QT514 to your Qt 5.14 MSVC 64-bit kit.'
}

$configs = if ($Configuration -eq 'all') { @('Debug', 'Release') } else { @($Configuration) }
$qmakeSdkRoot = (Resolve-QMakePath (Join-Path (Join-Path $guardRoot '..') 'sdk')).Replace('\', '/')
$qmakeGuardVisionRoot = (Resolve-QMakePath (Join-Path (Join-Path $guardRoot '..') 'GuardVision')).Replace('\', '/')

foreach ($config in $configs) {
    $buildName = if ($config -eq 'Debug') { 'guard-debug' } else { 'guard-release' }
    $buildDir = Join-Path $guardRoot ("_build\{0}" -f $buildName)
    $buildDirQmake = Resolve-QMakePath $buildDir
    $outputConfigDir = Join-Path $guardRoot ("bin\{0}" -f $config.ToLowerInvariant())
    $mocDir = Join-Path $buildDir 'moc'
    $uiDir = Join-Path $buildDir 'ui'
    $rccDir = Join-Path $buildDir 'rcc'
    $objDir = Join-Path $buildDir 'obj'
    $generatedDir = Join-Path $buildDir 'generated'

    New-Item -ItemType Directory -Force -Path $mocDir, $uiDir, $rccDir, $objDir, $generatedDir, $outputConfigDir | Out-Null

    $cbtPath = Join-Path $mocDir 'moc_predefs.h.cbt'
    if (-not (Test-Path -LiteralPath $cbtPath)) {
        Set-Content -LiteralPath $cbtPath -Value '# Qt moc predefs trigger file' -Encoding ASCII
    }

    $qmakeConfig = if ($config -eq 'Debug') {
        'CONFIG-=debug_and_release CONFIG+=debug CONFIG-=release'
    } else {
        'CONFIG-=debug_and_release CONFIG+=release CONFIG-=debug'
    }
    $qmakeArgs = @(
        (Quote-CmdArg $guardPro),
        $qmakeConfig,
        (Format-QMakeAssignment -Name 'GUARD_BUILD_ROOT' -Value $buildDir),
        (Format-QMakeAssignment -Name 'GUARD_OUTPUT_ROOT' -Value (Join-Path $guardRoot 'bin')),
        (Format-QMakeAssignment -Name 'GUARDVISION_ROOT' -Value $qmakeGuardVisionRoot),
        (Format-QMakeAssignment -Name 'OPENCV_ROOT' -Value (Join-Path $qmakeSdkRoot 'OpenCV')),
        (Format-QMakeAssignment -Name 'IDENTIFY_ROOT' -Value (Join-Path $qmakeSdkRoot 'Identify')),
        (Format-QMakeAssignment -Name 'HAZARDDETECT_ROOT' -Value (Join-Path $qmakeSdkRoot 'HazardDetect')),
        (Format-QMakeAssignment -Name 'HCNETSDK_ROOT' -Value (Join-Path $qmakeSdkRoot 'HCNetSDK')),
        (Format-QMakeAssignment -Name 'FFMPEG_ROOT' -Value (Join-Path $qmakeSdkRoot 'FFmpeg')),
        'GUARD_REQUIRE_HCNETSDK=1',
        'GUARD_REQUIRE_FFMPEG=0',
        'GUARD_REQUIRE_IDENTIFY=1',
        'GUARD_REQUIRE_HAZARD=1'
    )

    Write-Host "Refreshing Guard Qt/VS build files for $config..."
    $qmakeCommand = @(
        "cd /d $(Quote-CmdArg $buildDirQmake)",
        "set PATH=$(Quote-CmdArg (Join-Path $qtRoot 'bin'));%PATH%",
        "$(Quote-CmdArg $qmakeExe) $($qmakeArgs -join ' ')",
        'if errorlevel 1 exit /b 1'
    )
    Invoke-VcVarsCommand -CommandLines $qmakeCommand

    $requiredFiles = @(
        (Join-Path $mocDir 'mocinclude.opt'),
        (Join-Path $mocDir 'moc_predefs.h.cbt')
    )
    $missing = $requiredFiles | Where-Object { -not (Test-Path -LiteralPath $_) }
    if ($missing.Count -gt 0) {
        throw @(
            "Guard $config Qt prepare did not create required build files.",
            'Missing:',
            ($missing | ForEach-Object { "  - $_" })
        ) -join "`n"
    }
}

Write-Host 'Guard Visual Studio/Qt build folders are ready under Desktop\Guard\_build.'
Write-Host 'Open Desktop\Guard\Guard.sln in Visual Studio 2019 (Debug|x64 or Release|x64).'
