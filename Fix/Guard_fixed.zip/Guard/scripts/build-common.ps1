[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release')]
    [string]$Configuration = 'Debug',
    [string]$QtRoot = '',
    [string]$VsVarsPath = 'C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvars64.bat',
    [ValidateSet('en', 'zh')]
    [string]$DefaultLocale = 'zh',
    [switch]$SkipDeploy
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\ps-bypass.ps1')
Ensure-ExecutionPolicyBypass -BoundParameters $PSBoundParameters
Unblock-ScriptSiblings

. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\win-path-utils.ps1')
. (Join-Path (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path 'scripts\qt-kit-utils.ps1')

if ([string]::IsNullOrWhiteSpace($QtRoot) -or -not (Test-QtKitRoot -Path $QtRoot)) {
    $QtRoot = Resolve-QtKitRoot -PreferredRoot $QtRoot
    if (-not $QtRoot) {
        throw (Get-QtKitDiscoveryHelp)
    }
}

$projectRoot = Resolve-QMakePath (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$newRoot = Resolve-QMakePath (Resolve-Path (Join-Path $projectRoot '..')).Path
$sdkRoot = Join-Path $newRoot 'sdk'
$guardVisionSourceRoot = Join-Path $newRoot 'GuardVision'

function Resolve-SdkDependencyRoot([string]$name) {
    return (Join-Path $sdkRoot $name)
}

$guardVisionRoot = Resolve-QMakePath (Resolve-Path -LiteralPath $guardVisionSourceRoot).Path
$opencvRoot = Resolve-QMakePath (Resolve-SdkDependencyRoot 'OpenCV')
$identifyRoot = Resolve-QMakePath (Resolve-SdkDependencyRoot 'Identify')
$hazardDetectRoot = Resolve-QMakePath (Resolve-SdkDependencyRoot 'HazardDetect')
$hcNetSdkRoot = Resolve-QMakePath (Resolve-SdkDependencyRoot 'HCNetSDK')
$ffmpegRoot = Resolve-QMakePath (Resolve-SdkDependencyRoot 'FFmpeg')
$configLower = $Configuration.ToLowerInvariant()
$qtBin = Join-Path $QtRoot 'bin'
$qmake = Join-Path $qtBin 'qmake.exe'
$lrelease = Join-Path $qtBin 'lrelease.exe'
$windeployqt = Join-Path $qtBin 'windeployqt.exe'
$buildDir = Join-Path $projectRoot "_build/guard-$configLower"
$outputDir = Join-Path $projectRoot "bin/$configLower"
$outputExe = Join-Path $outputDir 'Guard.exe'

foreach ($required in @($VsVarsPath, $qmake, $lrelease, $windeployqt)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Required build tool not found: $required"
    }
}

function Copy-Dlls([string]$source, [string]$destination) {
    if (Test-Path -LiteralPath $source) {
        Get-ChildItem -LiteralPath $source -Filter '*.dll' -File -ErrorAction SilentlyContinue |
            ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $destination -Force }
    }
}

function Copy-MatchingDlls([string]$source, [string[]]$patterns, [string]$destination) {
    $copied = @()
    if (Test-Path -LiteralPath $source) {
        foreach ($pattern in $patterns) {
            Get-ChildItem -LiteralPath $source -Filter $pattern -File -ErrorAction SilentlyContinue |
                ForEach-Object {
                    Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
                    $copied += $_.Name
                }
        }
    }
    return $copied
}

function ConvertTo-CmdArgument([string]$value) {
    return '"' + ($value -replace '"', '\"') + '"'
}

function Remove-StaleMediaPipelineObjects([string]$buildDir) {
    $objDir = Join-Path $buildDir 'obj'
    if (-not (Test-Path -LiteralPath $objDir)) {
        return
    }

    $mediaControllerObj = Join-Path $objDir 'MediaSourceController.obj'
    $cameraRuntimeObj = Join-Path $objDir 'CameraRuntimeController.obj'
    $decoderObjs = @(
        (Join-Path $objDir 'FileDecoderWorker.obj'),
        (Join-Path $objDir 'RtspDecoderWorker.obj')
    )

    if (-not (Test-Path -LiteralPath $mediaControllerObj)) {
        return
    }

    $mediaControllerTime = (Get-Item -LiteralPath $mediaControllerObj).LastWriteTime
    foreach ($decoderObj in $decoderObjs) {
        if (-not (Test-Path -LiteralPath $decoderObj)) {
            continue
        }
        if ((Get-Item -LiteralPath $decoderObj).LastWriteTime -lt $mediaControllerTime) {
            Write-Host "Removing stale $(Split-Path -Leaf $decoderObj) (older than MediaSourceController.obj)" -ForegroundColor Yellow
            Remove-Item -LiteralPath $decoderObj -Force
        }
    }

    if (Test-Path -LiteralPath $cameraRuntimeObj) {
        $cameraRuntimeTime = (Get-Item -LiteralPath $cameraRuntimeObj).LastWriteTime
        if ($cameraRuntimeTime -gt $mediaControllerTime) {
            Write-Host 'Removing stale MediaSourceController.obj (older than CameraRuntimeController.obj)' -ForegroundColor Yellow
            Remove-Item -LiteralPath $mediaControllerObj -Force
        }
    }
}

function Remove-StaleObjectIfConsumersNewer([string]$buildDir, [string]$objName, [string[]]$consumerObjNames) {
    $objDir = Join-Path $buildDir 'obj'
    $targetObj = Join-Path $objDir $objName
    if (-not (Test-Path -LiteralPath $targetObj)) {
        return
    }

    $targetTime = (Get-Item -LiteralPath $targetObj).LastWriteTime
    foreach ($consumerName in $consumerObjNames) {
        $consumerObj = Join-Path $objDir $consumerName
        if (-not (Test-Path -LiteralPath $consumerObj)) {
            continue
        }
        if ((Get-Item -LiteralPath $consumerObj).LastWriteTime -gt $targetTime) {
            Write-Host "Removing stale $objName (consumer $consumerName is newer)" -ForegroundColor Yellow
            Remove-Item -LiteralPath $targetObj -Force
            return
        }
    }
}

function Remove-StaleObjectIfNewerThanSource([string]$buildDir, [string]$objName, [string]$sourceRelativePath) {
    $objDir = Join-Path $buildDir 'obj'
    $targetObj = Join-Path $objDir $objName
    $sourcePath = Join-Path $projectRoot $sourceRelativePath
    if (-not (Test-Path -LiteralPath $targetObj) -or -not (Test-Path -LiteralPath $sourcePath)) {
        return
    }

    $objTime = (Get-Item -LiteralPath $targetObj).LastWriteTime
    $sourceTime = (Get-Item -LiteralPath $sourcePath).LastWriteTime
    if ($objTime -gt $sourceTime) {
        Write-Host "Removing stale $objName (object newer than $sourceRelativePath)" -ForegroundColor Yellow
        Remove-Item -LiteralPath $targetObj -Force
    }
}

function Remove-StaleFileLoggingObjects([string]$buildDir) {
    Remove-StaleObjectIfNewerThanSource -buildDir $buildDir -objName 'CameraFileLogger.obj' -sourceRelativePath 'src\platform\diagnostics\CameraFileLogger.cpp'
    Remove-StaleObjectIfNewerThanSource -buildDir $buildDir -objName 'CameraRuntimeController.obj' -sourceRelativePath 'src\runtime\camera\CameraRuntimeController.cpp'
    Remove-StaleObjectIfConsumersNewer -buildDir $buildDir -objName 'CameraFileLogger.obj' -consumerObjNames @(
        'AppSettingsDialog.obj',
        'MainWindow.obj'
    )
    Remove-StaleObjectIfConsumersNewer -buildDir $buildDir -objName 'CameraRuntimeController.obj' -consumerObjNames @(
        'AppSettingsDialog.obj',
        'MainWindow.obj'
    )
}

function Remove-StaleQtMultimediaDeployment([string]$directory) {
    $staleItems = @(
        'Qt5Multimedia.dll',
        'Qt5Multimediad.dll',
        'Qt5Network.dll',
        'Qt5Networkd.dll',
        'audio',
        'bearer',
        'mediaservice',
        'playlistformats'
    )
    foreach ($item in $staleItems) {
        $path = Join-Path $directory $item
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Recurse -Force
        }
    }
}

function Copy-DirectoryIfPresent([string]$source, [string]$destination) {
    if (Test-Path -LiteralPath $source) {
        if (Test-Path -LiteralPath $destination) {
            Remove-Item -LiteralPath $destination -Recurse -Force
        }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force
    }
}

New-Item -ItemType Directory -Force -Path $buildDir, $outputDir | Out-Null

$qtMarker = Join-Path $projectRoot '_build\.guard-qt-root'
$expectedQtRoot = ((Resolve-Path -LiteralPath $QtRoot).Path -replace '/', '\').TrimEnd('\').ToLowerInvariant()
$markedQtRoot = ''
if (Test-Path -LiteralPath $qtMarker) {
    $markedQtRoot = ((Get-Content -LiteralPath $qtMarker -Raw).Trim() -replace '/', '\').TrimEnd('\').ToLowerInvariant()
}
if (($markedQtRoot) -and $markedQtRoot -ne $expectedQtRoot) {
    Write-Host "Qt kit changed ($markedQtRoot -> $expectedQtRoot). Clearing Guard qmake build cache..."
    Get-ChildItem -LiteralPath (Join-Path $projectRoot '_build') -Directory -Filter 'guard-*' -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force
}

Get-ChildItem -LiteralPath $buildDir -Filter 'Makefile*' -File -ErrorAction SilentlyContinue |
    Remove-Item -Force
Remove-Item -LiteralPath (Join-Path $buildDir '.qmake.stash') -Force -ErrorAction SilentlyContinue
Remove-StaleMediaPipelineObjects -buildDir $buildDir
Remove-StaleFileLoggingObjects -buildDir $buildDir
$qmakeConfig = if ($Configuration -eq 'Debug') {
    'CONFIG-=debug_and_release CONFIG+=debug CONFIG-=release'
} else {
    'CONFIG-=debug_and_release CONFIG+=release CONFIG-=debug'
}
$qmakeBuildDir = $buildDir.Replace('\', '/')
$qmakeOutputRoot = (Join-Path $projectRoot 'bin').Replace('\', '/')
$qmakeGuardVisionRoot = $guardVisionRoot.Replace('\', '/')
$qmakeOpenCvRoot = $opencvRoot.Replace('\', '/')
$qmakeIdentifyRoot = $identifyRoot.Replace('\', '/')
$qmakeHazardDetectRoot = $hazardDetectRoot.Replace('\', '/')
$qmakeHcNetSdkRoot = $hcNetSdkRoot.Replace('\', '/')
$qmakeFfmpegRoot = $ffmpegRoot.Replace('\', '/')
$guardPro = Join-Path $projectRoot 'Guard.pro'
$guardZhTs = Join-Path $projectRoot 'translations\Guard_zh.ts'
$guardZhQm = Join-Path $projectRoot 'resources\translations\Guard_zh.qm'
$qmakeArgs = @(
    $qmakeConfig,
    (Format-QMakeAssignment -Name 'GUARD_BUILD_ROOT' -Value $qmakeBuildDir),
    (Format-QMakeAssignment -Name 'GUARD_OUTPUT_ROOT' -Value $qmakeOutputRoot),
    (Format-QMakeAssignment -Name 'GUARDVISION_ROOT' -Value $qmakeGuardVisionRoot),
    (Format-QMakeAssignment -Name 'OPENCV_ROOT' -Value $qmakeOpenCvRoot),
    (Format-QMakeAssignment -Name 'IDENTIFY_ROOT' -Value $qmakeIdentifyRoot),
    (Format-QMakeAssignment -Name 'HAZARDDETECT_ROOT' -Value $qmakeHazardDetectRoot),
    (Format-QMakeAssignment -Name 'HCNETSDK_ROOT' -Value $qmakeHcNetSdkRoot),
    (Format-QMakeAssignment -Name 'FFMPEG_ROOT' -Value $qmakeFfmpegRoot),
    'GUARD_REQUIRE_HCNETSDK=1',
    'GUARD_REQUIRE_FFMPEG=0',
    'GUARD_REQUIRE_IDENTIFY=1',
    'GUARD_REQUIRE_HAZARD=1'
)
if ($DefaultLocale -eq 'en') {
    $qmakeArgs += 'DEFINES+=GUARD_DEFAULT_LOCALE_EN'
}
$qmakeArgsLine = $qmakeArgs -join ' '

$command = @"
@echo off
call $(ConvertTo-CmdArgument $VsVarsPath) >nul
set "PATH=$qtBin;%PATH%"
$(ConvertTo-CmdArgument $lrelease) $(ConvertTo-CmdArgument $guardZhTs) -qm $(ConvertTo-CmdArgument $guardZhQm)
if errorlevel 1 exit /b 1
cd /d $(ConvertTo-CmdArgument $buildDir)
$(ConvertTo-CmdArgument $qmake) $(ConvertTo-CmdArgument $guardPro) $qmakeArgsLine
if errorlevel 1 exit /b 1
if exist Makefile.Debug (
  set MAKEFILE=Makefile.Debug
) else if exist Makefile.Release (
  set MAKEFILE=Makefile.Release
) else if exist Makefile (
  set MAKEFILE=Makefile
) else (
  echo qmake did not generate a Makefile
  exit /b 1
)
nmake -f %MAKEFILE%
"@

$commandFile = Join-Path $env:TEMP "guard-build-$configLower-$PID.cmd"
Set-Content -LiteralPath $commandFile -Value $command -Encoding ASCII
try {
    Invoke-CmdFile -CommandFile $commandFile -FailureMessage "Guard $Configuration build failed with exit code {0}."
} finally {
    Remove-Item -LiteralPath $commandFile -Force -ErrorAction SilentlyContinue
}

Set-Content -LiteralPath $qtMarker -Value (Resolve-Path -LiteralPath $QtRoot).Path -Encoding ASCII

if (-not (Test-Path -LiteralPath $outputExe)) {
    throw "Build completed but Guard.exe was not found: $outputExe"
}

if (-not $SkipDeploy) {
    Remove-StaleQtMultimediaDeployment $outputDir
    Remove-QtKitDeployArtifacts -TargetDir $outputDir

    $deployArgs = @('--no-translations', '--compiler-runtime')
    if ($Configuration -eq 'Debug') { $deployArgs += '--debug' } else { $deployArgs += '--release' }
    $deployArgs += $outputExe
    $windeployHelp = & cmd /c "set `"PATH=$qtBin;%PATH%`" && $(ConvertTo-CmdArgument $windeployqt) --help" 2>&1
    $supportsNoPatchQt = $windeployHelp | Select-String -Pattern '--no-patchqt' -Quiet
    if ($supportsNoPatchQt) {
        $deployArgs = @('--no-patchqt') + $deployArgs
    }
    $deployCommand = @"
@echo off
call $(ConvertTo-CmdArgument $VsVarsPath) >nul
set "PATH=$qtBin;%PATH%"
$(ConvertTo-CmdArgument $windeployqt) $(($deployArgs | ForEach-Object { ConvertTo-CmdArgument $_ }) -join ' ')
"@
    $deployCommandFile = Join-Path $env:TEMP "guard-deploy-$configLower-$PID.cmd"
    Set-Content -LiteralPath $deployCommandFile -Value $deployCommand -Encoding ASCII
    try {
        Invoke-CmdFile -CommandFile $deployCommandFile -FailureMessage "windeployqt failed with exit code {0}."
    } catch {
        if (-not $supportsNoPatchQt -and (Test-Path -LiteralPath (Join-Path $outputDir 'Qt5Core.dll'))) {
            Write-Warning "windeployqt patch step failed on Qt 5.7; continuing because Qt runtime DLLs were deployed to $outputDir."
        } else {
            throw
        }
    } finally {
        Remove-Item -LiteralPath $deployCommandFile -Force -ErrorAction SilentlyContinue
    }

    Assert-QtKitDeployConsistent -TargetDir $outputDir -QtRoot $QtRoot -Configuration $Configuration `
        -RequiredDlls @('Qt5Core.dll', 'Qt5Gui.dll', 'Qt5Widgets.dll', 'Qt5Svg.dll', 'Qt5WebSockets.dll', 'Qt5Network.dll')

    $opencvRuntimeCandidates = @(
        (Join-Path $opencvRoot "runtime/$Configuration"),
        (Join-Path $opencvRoot 'bin')
    )
    $opencvWorldPattern = if ($Configuration -eq 'Debug') { 'opencv_world*d.dll' } else { 'opencv_world*.dll' }
    $opencvCopied = @()
    foreach ($opencvRuntime in $opencvRuntimeCandidates) {
        $opencvCopied += Copy-MatchingDlls $opencvRuntime @($opencvWorldPattern, 'opencv_videoio_ffmpeg*_64.dll') $outputDir
    }
    if (-not ($opencvCopied | Where-Object { $_ -like 'opencv_world*.dll' })) {
        throw "OpenCV runtime missing. Expected $opencvWorldPattern in one of: $($opencvRuntimeCandidates -join ', ')"
    }
    if (-not ($opencvCopied | Where-Object { $_ -like 'opencv_videoio_ffmpeg*_64.dll' })) {
        Write-Warning "OpenCV FFmpeg videoio plugin was not found. Local MP4 fallback may fail when FFmpeg is disabled."
    }

    Copy-Dlls (Join-Path $identifyRoot "runtime/$Configuration") $outputDir
    Copy-Dlls (Join-Path $hazardDetectRoot "runtime/$Configuration") $outputDir
    Copy-Dlls (Join-Path $hcNetSdkRoot 'runtime/x64') $outputDir
    $ffmpegRuntime = Join-Path $ffmpegRoot 'runtime/x64'
    if (Test-Path -LiteralPath $ffmpegRuntime) {
        Get-ChildItem -LiteralPath $ffmpegRuntime -Filter '*.dll' -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^(avcodec|avformat|avutil|swscale|swresample)-.*\.dll$'
        } | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $outputDir -Force
        }
    }

    Copy-DirectoryIfPresent (Join-Path $identifyRoot 'models/Pikachu') (Join-Path $outputDir 'Pikachu')
    $hazardModel = Join-Path $hazardDetectRoot 'models/fire_smoke.onnx'
    if (Test-Path -LiteralPath $hazardModel) {
        New-Item -ItemType Directory -Force -Path (Join-Path $outputDir 'models') | Out-Null
        Copy-Item -LiteralPath $hazardModel -Destination (Join-Path $outputDir 'models/fire_smoke.onnx') -Force
    }
    Copy-DirectoryIfPresent (Join-Path $hcNetSdkRoot 'runtime/x64/HCNetSDKCom') (Join-Path $outputDir 'HCNetSDKCom')
}

if (-not (Test-Path -LiteralPath $outputExe)) {
    throw "Build output missing: Guard.exe"
}

if (-not $SkipDeploy) {
    $platformDll = if ($Configuration -eq 'Debug') { 'platforms/qwindowsd.dll' } else { 'platforms/qwindows.dll' }
    $requiredRuntimeItems = @(
        $platformDll,
        'Identify.dll',
        'HazardDetect.dll',
        'HCNetSDK.dll',
        'PlayCtrl.dll',
        'Pikachu',
        'models/fire_smoke.onnx'
    )
    foreach ($relative in $requiredRuntimeItems) {
        if (-not (Test-Path -LiteralPath (Join-Path $outputDir $relative))) {
            throw "Standalone output missing: $relative"
        }
    }
}

Write-Host "Guard $Configuration output: $outputExe" -ForegroundColor Green

# SIG # Begin signature block
# MIIFoQYJKoZIhvcNAQcCoIIFkjCCBY4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAXbThJCtQBx3KK
# tBcNA8eQlnaWDEmatoZYi+9HX0Sm66CCAxIwggMOMIIB9qADAgECAhBxvAE/BCP+
# kE9BycqcYWCXMA0GCSqGSIb3DQEBCwUAMB8xHTAbBgNVBAMMFEd1YXJkMiBCdWls
# ZCBTY3JpcHRzMB4XDTI2MDcwMTA4MTQ1NVoXDTI3MDcwMTA4MzQ1NVowHzEdMBsG
# A1UEAwwUR3VhcmQyIEJ1aWxkIFNjcmlwdHMwggEiMA0GCSqGSIb3DQEBAQUAA4IB
# DwAwggEKAoIBAQDCTn3z/xRXcuES5iN7qYcxOuQtcP61KbDUix5ldo/+UOivwQU8
# bWQ11Y3crjQ6lZ5M5aIo4wbghq7j3i0tiH+/svKXILaUtiIQPa6UbPfJl5BADDcL
# UT6f8gFrh9Lfnet4sB5qtC9UNp1tesDE8Azc3+t4zCDvQZybkFrWtQbMSTXNULo5
# YiqUW4jGPPYNfbtyw1DvrgV2vYvXcbIWUNEoIu0QGXjnR2GYEf55DX3v7C4MlNCw
# NHgXiVdGcqg8AqBIx6VIMsg72joTrqBGJhrF36Z0m/5h9d2cQ7oXwEfX3BxpK+1Z
# 9Brh4Llz5yZnl1H0Hup+U5SG82itoXbPbg/1AgMBAAGjRjBEMA4GA1UdDwEB/wQE
# AwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzAdBgNVHQ4EFgQU/F+br9cdR2cgzmfy
# 4OdyZEhIP0gwDQYJKoZIhvcNAQELBQADggEBAB0wCvIRP+7/pq6rb7xNkLDZXX0B
# nDuJakQUD6y+fQkbWEJdG2bs8vvLyLrxFPS5d5MKV93Tfod65LH1Jhe27Y0bBaJO
# iPeVsOMHxkSfO+SG24DHJDfXKO1inPrAoWDqgdmijoLUIs34c9mMwvG8MZbH9gRL
# AQ1rEMAqHynozVyQLawlkitCOu1XNl1auYefghxX6p8jpIZo8+hdMHLdVQnyvPVY
# nYx2TyT9EGjsfXmzg0XrlUwLR7+oc1/YG5eh0w01KBRW+aLOPL26eUwdkNRjBo69
# Nbask86Wwovzf8icXYl1cNnOk5GtVqGQvLUq6T6ZJzU715J27fLEB+iw4rYxggHl
# MIIB4QIBATAzMB8xHTAbBgNVBAMMFEd1YXJkMiBCdWlsZCBTY3JpcHRzAhBxvAE/
# BCP+kE9BycqcYWCXMA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFqIPmSqf6NoHAW1agZj
# 5SymH37ym9kJ6dFdqk7UXfOXMA0GCSqGSIb3DQEBAQUABIIBAGhDTKHxKTVw9LOs
# twfjVsJ0q3Pq3MH8a3Lbh2FCx+no5mBYBOK6WoZdEmDigD+GXuymkipX/7XNLRht
# F9yNnrV18W8g6Uv+0dCrYCsYpcW2X0vxEGpQFJxgRgRZ1olKBmRWVz5KIiv4zIIT
# i31Poxi8nWsHMEpMlpFdH6zyZxASzTEIZwQ0ob3uqu+BIR9LBSIAlxHVemLDT6cG
# /vL/TjzULz4BeBAohoiEaohyoi9qU4qFAzKtwQSJsc3PcEuJCfnOy6zEo//iJxx1
# kgEhDZutuxPQodwJYoISi/Gz0vIpR/wuxJ46x5iOpmx/xlGweszfSG25OcwvJ7XR
# yS7UucE=
# SIG # End signature block
