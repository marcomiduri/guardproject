@echo off
setlocal
echo Building Guard (Debug and Release)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-all.ps1" %*
exit /b %ERRORLEVEL%
