# Run once if .\build-all.ps1 is blocked by execution policy:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\enable-ps1-scripts.ps1

$ErrorActionPreference = 'Stop'

try {
    Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop
} catch {
    Write-Warning "Could not change CurrentUser execution policy (often overridden by group policy). Continuing with script signing."
}

Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1' -ErrorAction SilentlyContinue |
    Unblock-File -ErrorAction SilentlyContinue

$certSubject = 'CN=Guard Build Scripts'
$cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert -ErrorAction SilentlyContinue |
    Where-Object { $_.Subject -eq $certSubject } |
    Select-Object -First 1

if (-not $cert) {
    $cert = New-SelfSignedCertificate `
        -Type CodeSigningCert `
        -Subject $certSubject `
        -CertStoreLocation Cert:\CurrentUser\My `
        -HashAlgorithm SHA256 `
        -KeyExportPolicy Exportable
}

$trustedPublisher = New-Object System.Security.Cryptography.X509Certificates.X509Store('TrustedPublisher', 'CurrentUser')
$trustedPublisher.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
if (-not ($trustedPublisher.Certificates | Where-Object { $_.Thumbprint -eq $cert.Thumbprint })) {
    $trustedPublisher.Add($cert)
}
$trustedPublisher.Close()

$rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store('Root', 'CurrentUser')
$rootStore.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
if (-not ($rootStore.Certificates | Where-Object { $_.Thumbprint -eq $cert.Thumbprint })) {
    $rootStore.Add($cert)
}
$rootStore.Close()

$buildScripts = @(
    'build-all.ps1',
    'build-common.ps1',
    'build-debug.ps1',
    'build-release.ps1'
)

foreach ($scriptName in $buildScripts) {
    $scriptPath = Join-Path $PSScriptRoot $scriptName
    if (Test-Path -LiteralPath $scriptPath) {
        Set-AuthenticodeSignature -FilePath $scriptPath -Certificate $cert -HashAlgorithm SHA256 | Out-Null
    }
}

Write-Host 'Guard build scripts are enabled for direct .\build-all.ps1 usage.' -ForegroundColor Green
Write-Host "Execution policy (CurrentUser): $(Get-ExecutionPolicy -Scope CurrentUser)" -ForegroundColor Green
