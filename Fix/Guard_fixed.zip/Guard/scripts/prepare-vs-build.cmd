@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-vs-build.ps1" %*
exit /b %ERRORLEVEL%
