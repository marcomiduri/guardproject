#include "guardlocale.h"

#include <QApplication>
#include <QEvent>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLibraryInfo>
#include <QLocale>
#include <QSettings>
#include <QTranslator>
#include <QWidget>

namespace {

QTranslator g_appTranslator;
QTranslator g_qtTranslator;
QVector<GuardLocaleOption> g_localeCatalog;

const QVector<GuardLocaleOption>& localeCatalog() {
    if (!g_localeCatalog.isEmpty())
        return g_localeCatalog;

    QFile file(QStringLiteral(":/i18n/locale-names.json"));
    if (!file.open(QIODevice::ReadOnly)) {
        g_localeCatalog = {{QStringLiteral("en"), QStringLiteral("English")},
                           {QStringLiteral("zh"), QStringLiteral("中文")}};
        return g_localeCatalog;
    }

    const QJsonDocument document = QJsonDocument::fromJson(file.readAll());
    for (const QJsonValue& value : document.array()) {
        if (!value.isObject())
            continue;
        const QJsonObject entry = value.toObject();
        const QString code = entry.value(QStringLiteral("code")).toString().trimmed().toLower();
        const QString name = entry.value(QStringLiteral("name")).toString().trimmed();
        if (!code.isEmpty() && !name.isEmpty())
            g_localeCatalog.append({code, name});
    }

    if (g_localeCatalog.isEmpty()) {
        g_localeCatalog = {{QStringLiteral("en"), QStringLiteral("English")},
                           {QStringLiteral("zh"), QStringLiteral("中文")}};
    }
    return g_localeCatalog;
}

QSettings localeSettings() {
    return QSettings(QStringLiteral("Apex Image"), QStringLiteral("Guard"));
}

QString normalizeLocaleCode(const QString& code) {
    const QString trimmed = code.trimmed().toLower();
    if (trimmed.startsWith(QStringLiteral("zh")))
        return QStringLiteral("zh");
    if (trimmed.startsWith(QStringLiteral("en")))
        return QStringLiteral("en");
    return QStringLiteral("en");
}

void migrateLegacyLocaleSetting(QSettings& settings) {
    if (settings.contains(QString::fromLatin1(GuardLocale::kStorageKey)))
        return;
    QSettings legacy(QStringLiteral("Guard"), QStringLiteral("ApexImage"));
    const QVariant stored = legacy.value(QString::fromLatin1(GuardLocale::kStorageKey));
    if (stored.isValid())
        settings.setValue(QString::fromLatin1(GuardLocale::kStorageKey), stored);
}

bool loadQtBaseTranslator(QApplication* app, const QString& localeCode) {
    app->removeTranslator(&g_qtTranslator);
    if (localeCode == QString::fromLatin1(GuardLocale::kSourceLocale))
        return true;

    const QString qtLocale = localeCode == QStringLiteral("zh") ? QStringLiteral("zh_CN") : localeCode;
    if (!g_qtTranslator.load(QStringLiteral("qtbase_%1").arg(qtLocale), QLibraryInfo::location(QLibraryInfo::TranslationsPath)))
        g_qtTranslator.load(QStringLiteral("qt_%1").arg(qtLocale), QLibraryInfo::location(QLibraryInfo::TranslationsPath));

    if (g_qtTranslator.isEmpty())
        return false;

    app->installTranslator(&g_qtTranslator);
    return true;
}

bool loadAppTranslator(QApplication* app, const QString& localeCode) {
    app->removeTranslator(&g_appTranslator);
    if (localeCode == QString::fromLatin1(GuardLocale::kSourceLocale))
        return true;

    if (!g_appTranslator.load(QStringLiteral("Guard_%1").arg(localeCode), QStringLiteral(":/translations")))
        return false;

    app->installTranslator(&g_appTranslator);
    return true;
}

void applyQtLocale(const QString& localeCode) {
    if (localeCode == QStringLiteral("zh"))
        QLocale::setDefault(QLocale(QLocale::Chinese, QLocale::China));
    else
        QLocale::setDefault(QLocale(QLocale::English, QLocale::UnitedStates));
}

void broadcastLanguageChange() {
    for (QWidget* widget : QApplication::allWidgets()) {
        QEvent event(QEvent::LanguageChange);
        QApplication::sendEvent(widget, &event);
    }
}

}  // namespace

namespace GuardLocale {

QVector<GuardLocaleOption> localeOptions() {
    return localeCatalog();
}

QString currentLocaleCode() {
    QSettings settings = localeSettings();
    migrateLegacyLocaleSetting(settings);
    const QString stored = settings.value(QString::fromLatin1(kStorageKey), QString::fromLatin1(kDefaultLocale)).toString();
    return isSupportedLocale(stored) ? normalizeLocaleCode(stored) : QString::fromLatin1(kDefaultLocale);
}

QString displayNameForLocale(const QString& code) {
    const QString normalized = normalizeLocaleCode(code);
    for (const GuardLocaleOption& option : localeCatalog()) {
        if (option.code == normalized)
            return option.label;
    }
    return normalized;
}

QString nextLocaleCode(const QString& currentCode) {
    const QVector<GuardLocaleOption> options = localeCatalog();
    if (options.size() < 2)
        return QString::fromLatin1(kDefaultLocale);

    const QString normalized = normalizeLocaleCode(currentCode);
    for (int i = 0; i < options.size(); ++i) {
        if (options.at(i).code == normalized)
            return options.at((i + 1) % options.size()).code;
    }

    return options.first().code == normalized ? options.at(1).code : options.first().code;
}

bool isSupportedLocale(const QString& code) {
    const QString normalized = normalizeLocaleCode(code);
    for (const GuardLocaleOption& option : localeCatalog()) {
        if (option.code == normalized)
            return true;
    }
    return false;
}

void install(QApplication* app) {
    const QString localeCode = currentLocaleCode();
    applyQtLocale(localeCode);
    loadQtBaseTranslator(app, localeCode);
    loadAppTranslator(app, localeCode);
}

bool setLocale(const QString& code, QApplication* app) {
    const QString normalized = normalizeLocaleCode(code);
    if (!isSupportedLocale(normalized))
        return false;

    if (normalized == currentLocaleCode())
        return false;

    localeSettings().setValue(QString::fromLatin1(kStorageKey), normalized);
    applyQtLocale(normalized);
    loadQtBaseTranslator(app, normalized);
    loadAppTranslator(app, normalized);
    broadcastLanguageChange();
    return true;
}

}  // namespace GuardLocale
