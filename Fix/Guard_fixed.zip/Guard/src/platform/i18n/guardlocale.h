#ifndef GUARDLOCALE_H
#define GUARDLOCALE_H

#include <QString>
#include <QVector>

class QApplication;

struct GuardLocaleOption {
    QString code;
    QString label;
};

namespace GuardLocale {

inline constexpr char kStorageKey[] = "pos-locale";
inline constexpr char kSourceLocale[] = "en";
#if defined(GUARD_DEFAULT_LOCALE_EN)
inline constexpr char kDefaultLocale[] = "en";
#else
inline constexpr char kDefaultLocale[] = "zh";
#endif

QVector<GuardLocaleOption> localeOptions();
QString currentLocaleCode();
QString nextLocaleCode(const QString& currentCode);
QString displayNameForLocale(const QString& code);
bool isSupportedLocale(const QString& code);

void install(QApplication* app);
bool setLocale(const QString& code, QApplication* app);

}  // namespace GuardLocale

#endif  // GUARDLOCALE_H
