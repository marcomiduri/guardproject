#pragma once

#include <QByteArray>
#include <QString>

namespace guard {
namespace security {

class SecureCredentialStore {
public:
    static bool write(const QString& name, const QByteArray& value, QString* errorMessage = nullptr);
    static bool read(const QString& name, QByteArray* value, QString* errorMessage = nullptr);
    static bool remove(const QString& name, QString* errorMessage = nullptr);
    static bool contains(const QString& name);

private:
    static QString settingsKey(const QString& name);
};

}  // namespace security
}  // namespace guard
