#include "SecureCredentialStore.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QSettings>
#include <QSysInfo>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wincrypt.h>
#endif

namespace guard {
namespace security {

namespace {

#ifndef Q_OS_WIN
QByteArray fallbackKey() {
    QByteArray material = QSysInfo::machineHostName().toUtf8();
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
    material += QSysInfo::machineUniqueId();
#endif
    material += QByteArrayLiteral("Guard-SecureCredentialStore-fallback-v1");
    return QCryptographicHash::hash(material, QCryptographicHash::Sha256);
}

QByteArray xorTransform(const QByteArray& input) {
    const QByteArray key = fallbackKey();
    QByteArray output = input;
    for (int i = 0; i < output.size(); ++i) {
        output[i] = static_cast<char>(static_cast<unsigned char>(output.at(i)) ^ static_cast<unsigned char>(key.at(i % key.size())));
    }
    return output;
}
#endif

}  // namespace

QString SecureCredentialStore::settingsKey(const QString& name) {
    QString safe = name.trimmed();
    safe.replace(QLatin1Char('/'), QLatin1Char('_'));
    return QStringLiteral("secure/%1").arg(safe);
}

bool SecureCredentialStore::write(const QString& name, const QByteArray& value, QString* errorMessage) {
    if (name.trimmed().isEmpty()) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("SecureCredentialStore", "Credential name is empty.");
        return false;
    }

#ifdef Q_OS_WIN
    DATA_BLOB input;
    input.pbData = reinterpret_cast<BYTE*>(const_cast<char*>(value.constData()));
    input.cbData = static_cast<DWORD>(value.size());
    DATA_BLOB output;
    output.pbData = nullptr;
    output.cbData = 0;

    if (!CryptProtectData(&input, L"Guard protected credential", nullptr, nullptr, nullptr, CRYPTPROTECT_UI_FORBIDDEN, &output)) {
        if (errorMessage) {
            *errorMessage = QCoreApplication::translate("SecureCredentialStore", "Windows could not protect the credential (error %1).")
                              .arg(static_cast<qulonglong>(GetLastError()));
        }
        return false;
    }

    const QByteArray protectedBytes(reinterpret_cast<const char*>(output.pbData), static_cast<int>(output.cbData));
    LocalFree(output.pbData);
    QSettings target;
    target.setValue(settingsKey(name), protectedBytes.toBase64());
    target.sync();
    return target.status() == QSettings::NoError;
#else
    // Guard production is Windows-focused. This encrypted/obfuscated fallback
    // keeps Linux developer builds functional without persisting plaintext.
    QSettings target;
    target.setValue(settingsKey(name), xorTransform(value).toBase64());
    target.sync();
    if (target.status() != QSettings::NoError) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("SecureCredentialStore", "Credential storage failed.");
        return false;
    }
    return true;
#endif
}

bool SecureCredentialStore::read(const QString& name, QByteArray* value, QString* errorMessage) {
    if (!value)
        return false;
    value->clear();
    QSettings source;
    const QByteArray encoded = source.value(settingsKey(name)).toByteArray();
    if (encoded.isEmpty())
        return false;
    const QByteArray stored = QByteArray::fromBase64(encoded);

#ifdef Q_OS_WIN
    DATA_BLOB input;
    input.pbData = reinterpret_cast<BYTE*>(const_cast<char*>(stored.constData()));
    input.cbData = static_cast<DWORD>(stored.size());
    DATA_BLOB output;
    output.pbData = nullptr;
    output.cbData = 0;

    if (!CryptUnprotectData(&input, nullptr, nullptr, nullptr, nullptr, CRYPTPROTECT_UI_FORBIDDEN, &output)) {
        if (errorMessage) {
            *errorMessage = QCoreApplication::translate("SecureCredentialStore", "Windows could not read the protected credential (error %1).")
                              .arg(static_cast<qulonglong>(GetLastError()));
        }
        return false;
    }

    *value = QByteArray(reinterpret_cast<const char*>(output.pbData), static_cast<int>(output.cbData));
    LocalFree(output.pbData);
    return true;
#else
    *value = xorTransform(stored);
    Q_UNUSED(errorMessage);
    return true;
#endif
}

bool SecureCredentialStore::remove(const QString& name, QString* errorMessage) {
    QSettings target;
    target.remove(settingsKey(name));
    target.sync();
    if (target.status() != QSettings::NoError) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("SecureCredentialStore", "Credential could not be removed.");
        return false;
    }
    return true;
}

bool SecureCredentialStore::contains(const QString& name) {
    QSettings source;
    return source.contains(settingsKey(name));
}

}  // namespace security
}  // namespace guard
