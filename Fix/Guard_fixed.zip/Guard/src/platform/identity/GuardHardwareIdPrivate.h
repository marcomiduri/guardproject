#ifndef GUARDHARDWAREIDPRIVATE_H
#define GUARDHARDWAREIDPRIVATE_H

#include <QString>

// Deterministic identity helpers shared by the runtime implementation and the
// standalone hardware-ID smoke test. Raw hardware values are never persisted.
namespace GuardHardwareIdPrivate {

struct StoredIdentity {
    QString canonicalId;
    QString machineGuidDigest;
    QString processorIdDigest;
};

struct Resolution {
    QString identifier;
    QString machineGuidDigest;
    QString processorIdDigest;
    bool verified = false;
    bool usingStoredFallback = false;
    bool shouldPersist = false;
};

QString normalizeMachineGuid(const QString& value);
QString normalizeProcessorId(const QString& value);
QString componentDigest(const QString& normalizedValue);

Resolution resolveIdentity(const QString& machineGuid, const QString& processorId, const StoredIdentity& stored);

}  // namespace GuardHardwareIdPrivate

#endif  // GUARDHARDWAREIDPRIVATE_H
