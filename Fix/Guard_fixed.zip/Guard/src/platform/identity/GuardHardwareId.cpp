#include "GuardHardwareId.h"

#include "GuardHardwareIdPrivate.h"

#include <QCryptographicHash>
#include <QProcess>
#include <QRegExp>
#include <QSettings>
#include <QStringList>

namespace {

const char kStoredCanonicalIdKey[] = "identity/canonicalHardwareId";
const char kStoredMachineGuidDigestKey[] = "identity/canonicalMachineGuidDigest";
const char kStoredProcessorDigestKey[] = "identity/canonicalProcessorDigest";
const char kStoredIdentityVersionKey[] = "identity/hardwareIdentityVersion";

// Early builds stored the same canonical identity under the removed license
// namespace. Read it once so upgrades do not change the installation identity.
const char kLegacyCanonicalIdKey[] = "license/canonicalHardwareId";
const char kLegacyMachineGuidDigestKey[] = "license/canonicalMachineGuidDigest";
const char kLegacyProcessorDigestKey[] = "license/canonicalProcessorDigest";
const char kLegacyValidationCandidatesKey[] = "license/hardwareValidationCandidates";
const char kLegacyIdentityVersionKey[] = "license/hardwareIdentityVersion";

const int kIdentityVersion = 2;

QString splitProcessorOutput(const QString& output) {
    const QStringList lines = output.split(QRegExp(QStringLiteral("[\\r\\n]+")), QString::SkipEmptyParts);
    for (const QString& line : lines) {
        const QString trimmed = line.trimmed();
        if (trimmed.startsWith(QStringLiteral("ProcessorId="), Qt::CaseInsensitive))
            return trimmed.mid(QStringLiteral("ProcessorId=").size()).trimmed();
        if (trimmed.size() >= 8 && !trimmed.contains(QLatin1Char(' ')) && trimmed.compare(QStringLiteral("ProcessorId"), Qt::CaseInsensitive) != 0)
            return trimmed;
    }
    return QString();
}

QString readWindowsMachineGuid() {
#ifdef Q_OS_WIN
    const QSettings registry(QStringLiteral("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography"), QSettings::NativeFormat);
    return registry.value(QStringLiteral("MachineGuid")).toString();
#else
    return QString();
#endif
}

QString runAndRead(const QString& program, const QStringList& arguments, int timeoutMs) {
    QProcess process;
    process.start(program, arguments, QIODevice::ReadOnly);
    if (!process.waitForStarted(1500) || !process.waitForFinished(timeoutMs)) {
        process.kill();
        process.waitForFinished(500);
        return QString();
    }
    if (process.exitStatus() != QProcess::NormalExit || process.exitCode() != 0)
        return QString();
    return QString::fromLocal8Bit(process.readAllStandardOutput());
}

QString readWindowsProcessorId() {
#ifdef Q_OS_WIN
    QString value = splitProcessorOutput(
      runAndRead(QStringLiteral("wmic"),
                 QStringList() << QStringLiteral("cpu") << QStringLiteral("get") << QStringLiteral("ProcessorId") << QStringLiteral("/value"), 4000));
    if (!value.isEmpty())
        return value;

    const QString script = QStringLiteral("(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty ProcessorId)");
    value =
      runAndRead(QStringLiteral("powershell.exe"),
                 QStringList() << QStringLiteral("-NoProfile") << QStringLiteral("-NonInteractive") << QStringLiteral("-Command") << script, 5000);
    return value.trimmed();
#else
    return QString();
#endif
}

QString hash16(const QString& raw) {
    return QString::fromLatin1(QCryptographicHash::hash(raw.toUtf8(), QCryptographicHash::Sha256).toHex().left(16)).toUpper();
}

QString normalizedIdentifier(const QString& value) {
    QString normalized = value.trimmed().toUpper();
    normalized.remove(QLatin1Char('-'));
    return QRegExp(QStringLiteral("^[0-9A-F]{16}$")).exactMatch(normalized) ? normalized : QString();
}

QString normalizedFingerprint(const QString& machineGuid, const QString& processorId) {
    if (machineGuid.isEmpty() || processorId.isEmpty())
        return QString();
    return QStringLiteral("machineGuid=%1|processorId=%2").arg(machineGuid).arg(processorId);
}

QString formatDisplay(const QString& identifier) {
    const QString normalized = normalizedIdentifier(identifier);
    if (normalized.isEmpty())
        return QString();
    return QStringLiteral("%1-%2-%3-%4").arg(normalized.mid(0, 4), normalized.mid(4, 4), normalized.mid(8, 4), normalized.mid(12, 4));
}

struct RuntimeIdentity {
    QString identifier;
    GuardHardwareIdStatus status = GuardHardwareIdStatus::Unavailable;
};

RuntimeIdentity& cachedRuntimeIdentity() {
    static RuntimeIdentity identity;
    return identity;
}

bool& runtimeIdentityInitialized() {
    static bool initialized = false;
    return initialized;
}

GuardHardwareIdPrivate::StoredIdentity loadStoredIdentity() {
    QSettings settings;
    GuardHardwareIdPrivate::StoredIdentity stored;
    stored.canonicalId = settings.value(QString::fromLatin1(kStoredCanonicalIdKey)).toString();
    stored.machineGuidDigest = settings.value(QString::fromLatin1(kStoredMachineGuidDigestKey)).toString();
    stored.processorIdDigest = settings.value(QString::fromLatin1(kStoredProcessorDigestKey)).toString();

    if (!normalizedIdentifier(stored.canonicalId).isEmpty())
        return stored;

    stored.canonicalId = settings.value(QString::fromLatin1(kLegacyCanonicalIdKey)).toString();
    stored.machineGuidDigest = settings.value(QString::fromLatin1(kLegacyMachineGuidDigestKey)).toString();
    stored.processorIdDigest = settings.value(QString::fromLatin1(kLegacyProcessorDigestKey)).toString();

    if (!normalizedIdentifier(stored.canonicalId).isEmpty()) {
        settings.setValue(QString::fromLatin1(kStoredCanonicalIdKey), normalizedIdentifier(stored.canonicalId));
        settings.setValue(QString::fromLatin1(kStoredMachineGuidDigestKey), stored.machineGuidDigest);
        settings.setValue(QString::fromLatin1(kStoredProcessorDigestKey), stored.processorIdDigest);
        settings.setValue(QString::fromLatin1(kStoredIdentityVersionKey), kIdentityVersion);
        settings.remove(QString::fromLatin1(kLegacyCanonicalIdKey));
        settings.remove(QString::fromLatin1(kLegacyMachineGuidDigestKey));
        settings.remove(QString::fromLatin1(kLegacyProcessorDigestKey));
        settings.remove(QString::fromLatin1(kLegacyValidationCandidatesKey));
        settings.remove(QString::fromLatin1(kLegacyIdentityVersionKey));
        settings.sync();
    }

    return stored;
}

void persistResolution(const GuardHardwareIdPrivate::Resolution& resolution) {
    if (!resolution.shouldPersist || resolution.identifier.isEmpty() || !resolution.verified)
        return;
    QSettings settings;
    settings.setValue(QString::fromLatin1(kStoredCanonicalIdKey), resolution.identifier);
    settings.setValue(QString::fromLatin1(kStoredMachineGuidDigestKey), resolution.machineGuidDigest);
    settings.setValue(QString::fromLatin1(kStoredProcessorDigestKey), resolution.processorIdDigest);
    settings.setValue(QString::fromLatin1(kStoredIdentityVersionKey), kIdentityVersion);
    settings.sync();
}

RuntimeIdentity evaluateRuntimeIdentity() {
    const GuardHardwareIdPrivate::Resolution resolution =
      GuardHardwareIdPrivate::resolveIdentity(readWindowsMachineGuid(), readWindowsProcessorId(), loadStoredIdentity());
    persistResolution(resolution);

    RuntimeIdentity runtime;
    runtime.identifier = resolution.identifier;
    if (resolution.verified)
        runtime.status = GuardHardwareIdStatus::Verified;
    else if (resolution.usingStoredFallback && !resolution.identifier.isEmpty())
        runtime.status = GuardHardwareIdStatus::StoredFallback;
    return runtime;
}

const RuntimeIdentity& runtimeIdentity() {
    if (!runtimeIdentityInitialized()) {
        cachedRuntimeIdentity() = evaluateRuntimeIdentity();
        runtimeIdentityInitialized() = true;
    }
    return cachedRuntimeIdentity();
}

}  // namespace

namespace GuardHardwareIdPrivate {

QString normalizeMachineGuid(const QString& value) {
    return value.trimmed().toUpper();
}

QString normalizeProcessorId(const QString& value) {
    return value.trimmed().toUpper();
}

QString componentDigest(const QString& normalizedValue) {
    if (normalizedValue.isEmpty())
        return QString();
    return QString::fromLatin1(QCryptographicHash::hash(normalizedValue.toUtf8(), QCryptographicHash::Sha256).toHex());
}

Resolution resolveIdentity(const QString& machineGuid, const QString& processorId, const StoredIdentity& stored) {
    Resolution result;
    const QString normalizedMachineGuid = normalizeMachineGuid(machineGuid);
    const QString normalizedProcessorId = normalizeProcessorId(processorId);
    const QString storedId = normalizedIdentifier(stored.canonicalId);

    if (normalizedMachineGuid.isEmpty() || normalizedProcessorId.isEmpty()) {
        if (!storedId.isEmpty()) {
            result.identifier = storedId;
            result.usingStoredFallback = true;
        }
        return result;
    }

    result.identifier = GuardHardwareId::canonicalIdentifierForComponents(normalizedMachineGuid, normalizedProcessorId);
    result.machineGuidDigest = componentDigest(normalizedMachineGuid);
    result.processorIdDigest = componentDigest(normalizedProcessorId);
    result.verified = !result.identifier.isEmpty();
    result.shouldPersist = result.verified && (storedId != result.identifier || stored.machineGuidDigest != result.machineGuidDigest ||
                                               stored.processorIdDigest != result.processorIdDigest);
    return result;
}

}  // namespace GuardHardwareIdPrivate

namespace GuardHardwareId {

QString canonicalIdentifierForComponents(const QString& machineGuid, const QString& processorId) {
    const QString normalizedMachineGuid = GuardHardwareIdPrivate::normalizeMachineGuid(machineGuid);
    const QString normalizedProcessorId = GuardHardwareIdPrivate::normalizeProcessorId(processorId);
    const QString fingerprint = normalizedFingerprint(normalizedMachineGuid, normalizedProcessorId);
    return fingerprint.isEmpty() ? QString() : hash16(fingerprint);
}

QString formatDisplayText(const QString& identifier) {
    return formatDisplay(identifier);
}

QString identifier() {
    return runtimeIdentity().identifier;
}

QString displayText() {
    return formatDisplayText(identifier());
}

QString hardwareIdHash() {
    const QString normalized = identifier();
    if (normalized.isEmpty())
        return QString();
    return QStringLiteral("v1:") + QString::fromLatin1(QCryptographicHash::hash(normalized.toUtf8(), QCryptographicHash::Sha256).toHex().toLower());
}

GuardHardwareIdStatus status() {
    return runtimeIdentity().status;
}

bool isAvailable() {
    return !identifier().isEmpty();
}

void refresh() {
    cachedRuntimeIdentity() = evaluateRuntimeIdentity();
    runtimeIdentityInitialized() = true;
}

}  // namespace GuardHardwareId
