#ifndef GUARDHARDWAREID_H
#define GUARDHARDWAREID_H

#include <QString>

enum class GuardHardwareIdStatus { Verified, StoredFallback, Unavailable };

namespace GuardHardwareId {

QString identifier();
QString displayText();
QString hardwareIdHash();
GuardHardwareIdStatus status();
bool isAvailable();

// Re-run the Windows hardware queries. A temporary query failure never
// replaces the last fully verified identifier.
void refresh();

QString canonicalIdentifierForComponents(const QString& machineGuid, const QString& processorId);
QString formatDisplayText(const QString& identifier);

}  // namespace GuardHardwareId

#endif  // GUARDHARDWAREID_H
