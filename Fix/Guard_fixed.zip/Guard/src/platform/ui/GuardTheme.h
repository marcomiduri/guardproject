#ifndef GUARDTHEME_H
#define GUARDTHEME_H

#include <QColor>
#include <QLatin1String>
#include <QString>

namespace GuardTheme {

// Matches Web frontend `data-theme="midnight"` tokens (theme.css).

inline constexpr const char *kSurfaceCanvas = "#0b1220";
inline constexpr const char *kSurfacePanel = "#121b2e";
inline constexpr const char *kSurfaceMuted = "#0c1628";
inline constexpr const char *kChromeBg = "#070d18";
inline constexpr const char *kChromeBorder = "#243552";
inline constexpr const char *kChromeFg = "#e2e8f0";
inline constexpr const char *kChromeFgMuted = "#94a3b8";
// Web `--color-data-table-header-bg`: color-mix(border-default 72%, surface-panel 28%) @ midnight
inline constexpr const char *kDataTableHeaderBg = "#1f2e48";
inline constexpr const char *kTextPrimary = "#f1f5f9";
inline constexpr const char *kTextMuted = "#94a3b8";
inline constexpr const char *kTextPlaceholder = "#64748b";
inline constexpr const char *kPrimary = "#22d3ee";
inline constexpr const char *kTextSubtle = "#adbbcc";
inline constexpr const char *kTextHeading = "#d5dce6";
inline constexpr const char *kPrimaryHover = "#67e8f9";
inline constexpr const char *kButtonOnSolid = "#0f172a";
inline constexpr const char *kSecondary = "#152238";
inline constexpr const char *kSecondaryHover = "#1e3a5f";
inline constexpr const char *kSecondaryBorder = "#334e68";
inline constexpr const char *kBorderStrong = "#334e68";
inline constexpr const char *kBorderSoft = "#1a2740";
inline constexpr const char *kDanger = "#fb7185";
inline constexpr const char *kSuccess = "#34d399";

inline QColor colorFromHex(const char *hex) {
    return QColor(QLatin1String(hex));
}

inline QColor surfaceCanvasColor() {
    return colorFromHex(kSurfaceCanvas);
}

inline QColor surfaceMutedColor() {
    return colorFromHex(kSurfaceMuted);
}

inline QColor textPlaceholderColor() {
    return colorFromHex(kTextPlaceholder);
}

inline QColor successColor() {
    return colorFromHex(kSuccess);
}

inline QColor dangerColor() {
    return colorFromHex(kDanger);
}

QString applicationStyleSheet();
QString standardPushButtonStyleSheet();
QString cameraDialogStyleSheet();
QString roomDialogStyleSheet();
QString confirmDialogStyleSheet();
QString dialogButtonStyleSheet();
QString settingsGroupBoxStyleSheet();
QString settingsLineEditStyleSheet();
QString cameraDialogComboBoxStyleSheet();
QString cameraDialogComboBoxPopupStyleSheet();
QString cameraDialogComboBoxPopupFrameStyleSheet();

}  // namespace GuardTheme

#endif  // GUARDTHEME_H
