#ifndef GUARDCOMBOBOX_H
#define GUARDCOMBOBOX_H

#include <QComboBox>

class GuardComboBox : public QComboBox {
public:
    explicit GuardComboBox(QWidget *parent = nullptr);

    void applyDialogTheme();

protected:
    void showPopup() override;

private:
    void stylePopupContainer(QWidget *popup);
    void stylePopupList();
    void repositionPopup();

    bool m_themeApplied = false;
};

#endif  // GUARDCOMBOBOX_H
