#include "GuardTheme.h"

#include <QFile>

namespace {

QString loadStyleTemplate(const char *resourcePath) {
    QFile file(QString::fromLatin1(resourcePath));
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return QString();
    }
    return QString::fromUtf8(file.readAll());
}

QString applyThemeTokens(QString stylesheet) {
    struct Token {
        const char *placeholder;
        const char *value;
    };

    static const Token tokens[] = {
      {"@surface-canvas@", GuardTheme::kSurfaceCanvas},
      {"@surface-panel@", GuardTheme::kSurfacePanel},
      {"@surface-muted@", GuardTheme::kSurfaceMuted},
      {"@chrome-bg@", GuardTheme::kChromeBg},
      {"@chrome-border@", GuardTheme::kChromeBorder},
      {"@chrome-fg@", GuardTheme::kChromeFg},
      {"@data-table-header-bg@", GuardTheme::kDataTableHeaderBg},
      {"@text-primary@", GuardTheme::kTextPrimary},
      {"@text-muted@", GuardTheme::kTextMuted},
      {"@text-subtle@", GuardTheme::kTextSubtle},
      {"@text-heading@", GuardTheme::kTextHeading},
      {"@primary@", GuardTheme::kPrimary},
      {"@primary-hover@", GuardTheme::kPrimaryHover},
      {"@button-on-solid@", GuardTheme::kButtonOnSolid},
      {"@secondary@", GuardTheme::kSecondary},
      {"@secondary-hover@", GuardTheme::kSecondaryHover},
      {"@secondary-border@", GuardTheme::kSecondaryBorder},
      {"@border-default@", GuardTheme::kChromeBorder},
      {"@border-soft@", GuardTheme::kBorderSoft},
      {"@border-strong@", GuardTheme::kBorderStrong},
      {"@dialog-frame-border@", GuardTheme::kChromeBorder},
      {"@danger@", GuardTheme::kDanger},
    };

    for (const Token &token : tokens) {
        stylesheet.replace(QString::fromLatin1(token.placeholder), QString::fromLatin1(token.value));
    }

    return stylesheet;
}

QString loadThemedStyleSheet(const char *resourcePath) {
    const QString templateStylesheet = loadStyleTemplate(resourcePath);
    if (templateStylesheet.isEmpty()) {
        return QString();
    }
    return applyThemeTokens(templateStylesheet);
}

}  // namespace

namespace GuardTheme {

QString standardPushButtonStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QPushButton {"
                     "  background-color: @surface-panel@;"
                     "  color: @text-primary@;"
                     "  border: 1px solid @chrome-border@;"
                     "  border-radius: 4px;"
                     "  padding: 6px 12px;"
                     "}"
                     "QPushButton:hover {"
                     "  background-color: @secondary-hover@;"
                     "  border-color: @border-strong@;"
                     "}"
                     "QPushButton:pressed {"
                     "  background-color: @surface-muted@;"
                     "  border-color: @chrome-border@;"
                     "}"
                     "QPushButton:disabled {"
                     "  color: @text-muted@;"
                     "  background-color: @surface-muted@;"
                     "}"
                     "QPushButton:focus {"
                     "  outline: none;"
                     "}"));
}

QString applicationStyleSheet() {
    return loadThemedStyleSheet(":/styles/application.qss");
}

QString cameraDialogStyleSheet() {
    return loadThemedStyleSheet(":/styles/camera-dialog.qss");
}

QString roomDialogStyleSheet() {
    return loadThemedStyleSheet(":/styles/room-dialog.qss");
}

QString confirmDialogStyleSheet() {
    return loadThemedStyleSheet(":/styles/confirm-dialog.qss");
}

QString dialogButtonStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QPushButton {"
                     "  background-color: @surface-panel@;"
                     "  color: @text-primary@;"
                     "  border: 1px solid @chrome-border@;"
                     "  border-radius: 4px;"
                     "  padding: 4px 10px;"
                     "  min-width: 64px;"
                     "  min-height: 22px;"
                     "  font-size: 12px;"
                     "  margin-right: 8px;"
                     "}"
                     "QPushButton:hover {"
                     "  background-color: @secondary-hover@;"
                     "  border-color: @border-strong@;"
                     "}"
                     "QPushButton:pressed {"
                     "  background-color: @surface-muted@;"
                     "  border-color: @chrome-border@;"
                     "}"
                     "QPushButton:disabled {"
                     "  color: @text-muted@;"
                     "  background-color: @surface-muted@;"
                     "}"
                     "QPushButton:focus {"
                     "  outline: none;"
                     "}"));
}

QString settingsGroupBoxStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QGroupBox {"
                     "  background-color: transparent;"
                     "  color: @text-primary@;"
                     "  border: 1px solid @border-soft@;"
                     "  border-radius: 6px;"
                     "  margin-top: 12px;"
                     "  padding: 12px 12px 8px 12px;"
                     "  font-size: 12px;"
                     "  font-weight: 600;"
                     "}"
                     "QGroupBox::title {"
                     "  subcontrol-origin: margin;"
                     "  subcontrol-position: top left;"
                     "  left: 10px;"
                     "  padding: 0 6px;"
                     "  color: @text-heading@;"
                     "}"));
}

QString settingsLineEditStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QLineEdit {"
                     "  background-color: @surface-muted@;"
                     "  color: @text-primary@;"
                     "  border: 1px solid @border-default@;"
                     "  border-radius: 6px;"
                     "  padding: 4px 10px;"
                     "  min-height: 22px;"
                     "  max-height: 28px;"
                     "  font-size: 13px;"
                     "  selection-background-color: #164e63;"
                     "  selection-color: @text-primary@;"
                     "}"
                     "QLineEdit:focus {"
                     "  border-color: @primary-hover@;"
                     "}"
                     "QLineEdit:read-only {"
                     "  background-color: @surface-muted@;"
                     "  color: @text-muted@;"
                     "  border: 1px solid @border-default@;"
                     "}"));
}

QString cameraDialogComboBoxStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QComboBox {"
                     "  background-color: @surface-muted@;"
                     "  color: @text-primary@;"
                     "  border: 1px solid @border-default@;"
                     "  border-radius: 6px;"
                     "  padding: 4px 10px;"
                     "  padding-right: 28px;"
                     "  min-height: 22px;"
                     "  max-height: 28px;"
                     "  font-size: 13px;"
                     "  selection-background-color: #164e63;"
                     "  selection-color: @text-primary@;"
                     "}"
                     "QComboBox:focus,"
                     "QComboBox:on {"
                     "  border-color: @primary-hover@;"
                     "}"
                     "QComboBox::drop-down {"
                     "  subcontrol-origin: padding;"
                     "  subcontrol-position: top right;"
                     "  border: none;"
                     "  width: 28px;"
                     "}"
                     "QComboBox::down-arrow {"
                     "  image: url(:/icons/chevron-down.svg);"
                     "  width: 12px;"
                     "  height: 12px;"
                     "}"));
}

QString cameraDialogComboBoxPopupStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QAbstractItemView,"
                     "QListView {"
                     "  background-color: transparent;"
                     "  color: @text-primary@;"
                     "  border: none;"
                     "  outline: none;"
                     "  padding: 4px;"
                     "  show-decoration-selected: 1;"
                     "}"
                     "QListView::viewport {"
                     "  background-color: @surface-panel@;"
                     "  border: none;"
                     "}"
                     "QAbstractItemView::item,"
                     "QListView::item {"
                     "  min-height: 24px;"
                     "  padding: 4px 8px;"
                     "  border-radius: 4px;"
                     "}"
                     "QAbstractItemView::item:hover,"
                     "QListView::item:hover {"
                     "  background-color: @secondary-hover@;"
                     "  color: @text-primary@;"
                     "}"
                     "QAbstractItemView::item:selected,"
                     "QListView::item:selected {"
                     "  background-color: #164e63;"
                     "  color: @text-primary@;"
                     "}"
                     "QAbstractItemView::item:selected:hover,"
                     "QListView::item:selected:hover {"
                     "  background-color: #1e5a73;"
                     "  color: @text-primary@;"
                     "}"));
}

QString cameraDialogComboBoxPopupFrameStyleSheet() {
    return applyThemeTokens(
      QStringLiteral("QFrame,"
                     "QWidget {"
                     "  background-color: @surface-panel@;"
                     "  border: 1px solid @border-default@;"
                     "  border-radius: 6px;"
                     "}"));
}

}  // namespace GuardTheme
