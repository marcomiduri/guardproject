#ifndef GUARDICON_H
#define GUARDICON_H

#include <QColor>
#include <QIcon>

namespace GuardIcon {

QIcon applicationIcon();
QIcon trayIcon();
QIcon themedSvgIcon(const char *resourcePath, int logicalSize, const QColor &color);

}  // namespace GuardIcon

#endif  // GUARDICON_H
