#include "GuardComboBox.h"

#include "GuardScreen.h"
#include "GuardTheme.h"

#include <QAbstractItemView>
#include <QFrame>
#include <QTimer>

GuardComboBox::GuardComboBox(QWidget *parent) : QComboBox(parent) {
    setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
}

void GuardComboBox::applyDialogTheme() {
    if (m_themeApplied) {
        return;
    }

    setStyleSheet(GuardTheme::cameraDialogComboBoxStyleSheet());
    setCursor(Qt::PointingHandCursor);
    m_themeApplied = true;
}

void GuardComboBox::stylePopupContainer(QWidget *popup) {
    if (!popup) {
        return;
    }

    popup->setAttribute(Qt::WA_StyledBackground, true);
    if (auto *frame = qobject_cast<QFrame *>(popup)) {
        frame->setFrameShape(QFrame::NoFrame);
    }
    popup->setStyleSheet(GuardTheme::cameraDialogComboBoxPopupFrameStyleSheet() + GuardTheme::cameraDialogComboBoxPopupStyleSheet());
}

void GuardComboBox::stylePopupList() {
    if (!view()) {
        return;
    }

    view()->setAttribute(Qt::WA_StyledBackground, true);
    view()->setMouseTracking(true);
    view()->setStyleSheet(GuardTheme::cameraDialogComboBoxPopupStyleSheet());
    if (QWidget *viewport = view()->viewport()) {
        viewport->setAttribute(Qt::WA_Hover, true);
        viewport->setMouseTracking(true);
    }
}

void GuardComboBox::showPopup() {
    QComboBox::showPopup();
    repositionPopup();
    QTimer::singleShot(0, this, [this]() { repositionPopup(); });
}

void GuardComboBox::repositionPopup() {
    if (!view()) {
        return;
    }

    QWidget *popup = view()->window();
    if (!popup || !(popup->windowFlags() & Qt::Popup)) {
        return;
    }

    const QRect anchor = QRect(mapToGlobal(QPoint(0, 0)), size());
    const int popupWidth = qMax(width(), popup->width());
    const int popupHeight = qMax(popup->height(), popup->sizeHint().height());

    const QRect available = guardAvailableGeometryAt(anchor.center());
    const int spaceBelow = available.bottom() - anchor.bottom();
    const int spaceAbove = anchor.top() - available.top();
    const bool openUpward = popupHeight > spaceBelow && spaceAbove >= popupHeight;

    const int y = openUpward ? anchor.top() - popupHeight : anchor.bottom();
    popup->setGeometry(anchor.left(), y, popupWidth, popupHeight);

    stylePopupContainer(popup);
    stylePopupList();
}
