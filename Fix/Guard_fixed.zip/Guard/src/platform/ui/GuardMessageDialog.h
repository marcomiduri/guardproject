#ifndef GUARDMESSAGEDIALOG_H
#define GUARDMESSAGEDIALOG_H

#include <QDialog>
#include <QString>

class QResizeEvent;
class QShowEvent;
class QWidget;
class WindowTitleBar;

class GuardMessageDialog final : public QDialog {
public:
    enum class Kind { Information, Warning, Question };

    explicit GuardMessageDialog(QWidget* parent, const QString& title, const QString& message, Kind kind, bool question = false,
                                bool defaultToNo = false);

    static void information(QWidget* parent, const QString& title, const QString& message);
    static void warning(QWidget* parent, const QString& title, const QString& message);
    static bool question(QWidget* parent, const QString& title, const QString& message, bool defaultToNo = true);

protected:
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private:
    void updateDialogFrameMask();

    QWidget* dialogFrame_ = nullptr;
    WindowTitleBar* titleBar_ = nullptr;
};

#endif  // GUARDMESSAGEDIALOG_H
