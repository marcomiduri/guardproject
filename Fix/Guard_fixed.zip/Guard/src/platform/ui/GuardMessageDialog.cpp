#include "GuardMessageDialog.h"

#include "GuardTheme.h"
#include "WindowTitleBar.h"

#include <QColor>
#include <QDialogButtonBox>
#include <QGraphicsDropShadowEffect>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainterPath>
#include <QPushButton>
#include <QRegion>
#include <QResizeEvent>
#include <QShowEvent>
#include <QSizePolicy>
#include <QStyle>
#include <QVBoxLayout>

namespace {
constexpr int kDialogCornerRadius = 4;

QStyle::StandardPixmap iconForKind(GuardMessageDialog::Kind kind) {
    switch (kind) {
        case GuardMessageDialog::Kind::Warning:
            return QStyle::SP_MessageBoxWarning;
        case GuardMessageDialog::Kind::Question:
            return QStyle::SP_MessageBoxQuestion;
        case GuardMessageDialog::Kind::Information:
        default:
            return QStyle::SP_MessageBoxInformation;
    }
}

void styleButton(QPushButton* button, const QString& objectName, bool isDefault) {
    if (!button)
        return;
    button->setObjectName(objectName);
    button->setAutoDefault(isDefault);
    button->setDefault(isDefault);
    button->setFlat(false);
    button->setCursor(Qt::PointingHandCursor);
    button->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
}
}  // namespace

GuardMessageDialog::GuardMessageDialog(QWidget* parent, const QString& title, const QString& message, Kind kind, bool question, bool defaultToNo)
: QDialog(parent) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setWindowModality(Qt::WindowModal);
    setAttribute(Qt::WA_TranslucentBackground);

    // Reuse the exact CameraDialog selectors from camera-dialog.qss.
    setObjectName(QStringLiteral("CameraDialog"));
    setWindowTitle(title);

    QVBoxLayout* outerLayout = new QVBoxLayout(this);
    outerLayout->setContentsMargins(20, 20, 20, 20);
    outerLayout->setSpacing(0);

    QWidget* shadowHost = new QWidget(this);
    shadowHost->setAttribute(Qt::WA_TranslucentBackground);
    QVBoxLayout* shadowLayout = new QVBoxLayout(shadowHost);
    shadowLayout->setContentsMargins(0, 0, 0, 0);
    shadowLayout->setSpacing(0);

    dialogFrame_ = new QWidget(shadowHost);
    dialogFrame_->setObjectName(QStringLiteral("dialogFrame"));
    dialogFrame_->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* frameLayout = new QVBoxLayout(dialogFrame_);
    frameLayout->setContentsMargins(0, 0, 0, 0);
    frameLayout->setSpacing(0);

    titleBar_ = new WindowTitleBar(dialogFrame_, WindowTitleBar::Style::Dialog);
    titleBar_->setObjectName(QStringLiteral("titleBar"));
    titleBar_->setTitle(title);
    frameLayout->addWidget(titleBar_);
    connect(titleBar_, &WindowTitleBar::closeRequested, this, &QDialog::reject);

    QWidget* content = new QWidget(dialogFrame_);
    content->setObjectName(QStringLiteral("dialogContent"));
    content->setAttribute(Qt::WA_StyledBackground, true);
    QHBoxLayout* contentLayout = new QHBoxLayout(content);
    contentLayout->setContentsMargins(24, 22, 24, 22);
    contentLayout->setSpacing(16);

    QLabel* iconLabel = new QLabel(content);
    iconLabel->setFixedSize(36, 36);
    iconLabel->setAlignment(Qt::AlignCenter);
    iconLabel->setPixmap(style()->standardIcon(iconForKind(kind)).pixmap(28, 28));
    contentLayout->addWidget(iconLabel, 0, Qt::AlignTop);

    QLabel* messageLabel = new QLabel(message, content);
    messageLabel->setObjectName(QStringLiteral("messageLabel"));
    messageLabel->setWordWrap(true);
    messageLabel->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
    messageLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    contentLayout->addWidget(messageLabel, 1);
    frameLayout->addWidget(content, 1);

    QWidget* footer = new QWidget(dialogFrame_);
    footer->setObjectName(QStringLiteral("dialogFooter"));
    footer->setAttribute(Qt::WA_StyledBackground, true);
    QHBoxLayout* footerLayout = new QHBoxLayout(footer);
    footerLayout->setContentsMargins(16, 14, 8, 20);
    footerLayout->setSpacing(0);
    footerLayout->addStretch(1);

    if (question) {
        QPushButton* noButton = new QPushButton(tr("No"), footer);
        QPushButton* yesButton = new QPushButton(tr("Yes"), footer);
        styleButton(noButton, QStringLiteral("cancelButton"), defaultToNo);
        styleButton(yesButton, QStringLiteral("okButton"), !defaultToNo);
        footerLayout->addWidget(noButton);
        footerLayout->addWidget(yesButton);
        connect(noButton, &QPushButton::clicked, this, &QDialog::reject);
        connect(yesButton, &QPushButton::clicked, this, &QDialog::accept);
    } else {
        QPushButton* okButton = new QPushButton(tr("OK"), footer);
        styleButton(okButton, QStringLiteral("okButton"), true);
        footerLayout->addWidget(okButton);
        connect(okButton, &QPushButton::clicked, this, &QDialog::accept);
    }
    frameLayout->addWidget(footer);

    shadowLayout->addWidget(dialogFrame_);
    outerLayout->addWidget(shadowHost);

    QGraphicsDropShadowEffect* shadow = new QGraphicsDropShadowEffect(shadowHost);
    shadow->setBlurRadius(48);
    shadow->setOffset(0, 16);
    shadow->setColor(QColor(2, 6, 23, 140));
    shadowHost->setGraphicsEffect(shadow);

    setStyleSheet(GuardTheme::cameraDialogStyleSheet());
    setMinimumWidth(460);
    resize(520, sizeHint().height());
}

void GuardMessageDialog::information(QWidget* parent, const QString& title, const QString& message) {
    GuardMessageDialog dialog(parent, title, message, Kind::Information, false);
    dialog.exec();
}

void GuardMessageDialog::warning(QWidget* parent, const QString& title, const QString& message) {
    GuardMessageDialog dialog(parent, title, message, Kind::Warning, false);
    dialog.exec();
}

bool GuardMessageDialog::question(QWidget* parent, const QString& title, const QString& message, bool defaultToNo) {
    GuardMessageDialog dialog(parent, title, message, Kind::Question, true, defaultToNo);
    return dialog.exec() == QDialog::Accepted;
}

void GuardMessageDialog::showEvent(QShowEvent* event) {
    QDialog::showEvent(event);
    updateDialogFrameMask();
}

void GuardMessageDialog::resizeEvent(QResizeEvent* event) {
    QDialog::resizeEvent(event);
    updateDialogFrameMask();
}

void GuardMessageDialog::updateDialogFrameMask() {
    if (!dialogFrame_)
        return;
    QPainterPath clipPath;
    clipPath.addRoundedRect(QRectF(dialogFrame_->rect()).adjusted(0.5, 0.5, -0.5, -0.5), kDialogCornerRadius, kDialogCornerRadius);
    dialogFrame_->setMask(QRegion(clipPath.toFillPolygon().toPolygon()));
}
