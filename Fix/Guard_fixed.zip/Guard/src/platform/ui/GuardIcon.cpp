#include "GuardIcon.h"

#include <QFile>
#include <QGuiApplication>
#include <QPainter>
#include <QPixmap>
#include <QScreen>
#include <QSvgRenderer>

namespace GuardIcon {

QIcon themedSvgIcon(const char *resourcePath, int logicalSize, const QColor &color) {
    QFile file(QString::fromLatin1(resourcePath));
    if (!file.open(QIODevice::ReadOnly)) {
        return QIcon(QString::fromLatin1(resourcePath));
    }

    QByteArray svgData = file.readAll();
    const QByteArray colorName = color.name(QColor::HexRgb).toLatin1();
    svgData.replace("currentColor", colorName);

    QSvgRenderer renderer(svgData);
    if (!renderer.isValid()) {
        return QIcon(QString::fromLatin1(resourcePath));
    }

    const qreal deviceRatio = QGuiApplication::primaryScreen() ? QGuiApplication::primaryScreen()->devicePixelRatio() : 1.0;
    const qreal renderRatio = qMax<qreal>(2.0, deviceRatio);
    const int pixelSize = qMax(1, qRound(logicalSize * renderRatio));

    QPixmap pixmap(pixelSize, pixelSize);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing, true);
    renderer.render(&painter, QRectF(0, 0, pixelSize, pixelSize));
    painter.end();

    pixmap.setDevicePixelRatio(renderRatio);
    return QIcon(pixmap);
}

QIcon applicationIcon() {
    static const QIcon icon = []() {
        QIcon result(QStringLiteral(":/icons/guard.ico"));
        const QList<int> sizes = {16, 24, 32, 48, 64, 128, 256};
        for (int size : sizes) {
            const QString path = QStringLiteral(":/icons/guard-%1.png").arg(size);
            result.addFile(path, QSize(size, size));
        }
        if (result.isNull())
            result = themedSvgIcon(":/icons/guard.svg", 64, QColor(QStringLiteral("#22d3ee")));
        return result;
    }();

    return icon;
}

QIcon trayIcon() {
    // Prefer the Windows ICO resource for the notification area. The original
    // PNG resources in older Guard archives were malformed, and a QIcon can
    // still report non-null after addFile() even when its image cannot load.
    // Starting with the validated ICO avoids a silent/invisible tray icon.
    QIcon icon(QStringLiteral(":/icons/guard.ico"));
    if (!icon.availableSizes().isEmpty())
        return icon;

    icon = applicationIcon();
    if (!icon.availableSizes().isEmpty())
        return icon;

    return themedSvgIcon(":/icons/guard.svg", 32, QColor(QStringLiteral("#22d3ee")));
}

}  // namespace GuardIcon
