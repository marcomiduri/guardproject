#ifndef GUARDFONTMETRICS_H
#define GUARDFONTMETRICS_H

#include <QFontMetrics>
#include <QString>
#include <QtGlobal>

inline int guardTextWidth(const QFontMetrics &metrics, const QString &text) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
    return metrics.horizontalAdvance(text);
#else
    return metrics.width(text);
#endif
}

#endif  // GUARDFONTMETRICS_H
