#ifndef GUARDUUID_H
#define GUARDUUID_H

#include <QString>
#include <QUuid>
#include <QtGlobal>

inline QString guardUuidToString(const QUuid &uuid) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 11, 0)
    return uuid.toString(QUuid::WithoutBraces);
#else
    const QString withBraces = uuid.toString();
    return withBraces.mid(1, withBraces.size() - 2);
#endif
}

inline QString guardCreateUuidString() {
    return guardUuidToString(QUuid::createUuid());
}

#endif  // GUARDUUID_H
