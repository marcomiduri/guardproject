#ifndef GUARDPALETTE_H
#define GUARDPALETTE_H

#include <QColor>
#include <QPalette>
#include <QtGlobal>

inline void guardSetPlaceholderTextColor(QPalette &palette, const QColor &color) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
    palette.setColor(QPalette::PlaceholderText, color);
#else
    Q_UNUSED(palette);
    Q_UNUSED(color);
#endif
}

#endif  // GUARDPALETTE_H
