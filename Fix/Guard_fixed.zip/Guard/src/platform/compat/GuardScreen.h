#ifndef GUARDSCREEN_H
#define GUARDSCREEN_H

#include <QGuiApplication>
#include <QPoint>
#include <QRect>
#include <QScreen>
#include <QtGlobal>

#if QT_VERSION < QT_VERSION_CHECK(5, 10, 0)
#include <QApplication>
#include <QDesktopWidget>
#endif

inline QRect guardAvailableGeometryAt(const QPoint &globalPoint) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 10, 0)
    if (QScreen *screen = QGuiApplication::screenAt(globalPoint)) {
        return screen->availableGeometry();
    }
    return QRect(globalPoint, QSize(0, 0));
#else
    if (QApplication::desktop()) {
        return QApplication::desktop()->availableGeometry(QApplication::desktop()->screenNumber(globalPoint));
    }
    return QRect(globalPoint, QSize(0, 0));
#endif
}

#endif  // GUARDSCREEN_H
