#ifndef GUARDLICENSEALGO_H
#define GUARDLICENSEALGO_H

#include <QString>

namespace guard {
namespace license {

class GuardLicenseAlgo {
public:
    enum class GuardLicenseKind { Invalid, Temporary, Permanent };

    static QString normalizeToken(const QString& value);
    static QString formatToken(const QString& normalizedToken);
    static bool isValidTokenText(const QString& value);

    static QString temporaryGuardLicenseForHardwareId(const QString& guardHardwareId);
    static QString permanentGuardLicenseForHardwareId(const QString& guardHardwareId);
    static GuardLicenseKind classifyGuardLicense(const QString& guardHardwareId, const QString& licenseKey);

    static QString licenseGeneratorActivationCodeForHardwareId(const QString& generatorHardwareId);
    static bool validateLicenseGeneratorActivationCode(const QString& generatorHardwareId, const QString& activationCode);

private:
    static QString tokenFromPurposeAndHardwareId(const QString& purpose, const QString& hardwareId);
};

}  // namespace license
}  // namespace guard

#endif  // GUARDLICENSEALGO_H
