#include "GuardLicenseManager.h"

#include "GuardHardwareId.h"
#include "SecureCredentialStore.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QSettings>

namespace {
const char kLicenseCredentialName[] = "guard-license-key";
const char kLicenseKindKey[] = "license2/kind";
const char kLicenseKeyDigestKey[] = "license2/keyDigest";
const char kLicenseAcceptedAtKey[] = "license2/acceptedAtUtc";
const char kLicenseExpiresAtKey[] = "license2/expiresAtUtc";
const char kLicenseHardwareIdKey[] = "license2/hardwareId";
const int kTemporaryLicenseDays = 7;

QString isoDate(const QDateTime& value) {
    return value.toUTC().toString(Qt::ISODate);
}

QDateTime fromIsoDate(const QString& value) {
    QDateTime parsed = QDateTime::fromString(value, Qt::ISODate);
    if (parsed.isValid())
        parsed = parsed.toUTC();
    return parsed;
}

int remainingDaysCeil(const QDateTime& nowUtc, const QDateTime& expiresAtUtc) {
    if (!nowUtc.isValid() || !expiresAtUtc.isValid() || nowUtc >= expiresAtUtc)
        return 0;
    const qint64 dayMs = 24LL * 60LL * 60LL * 1000LL;
    return static_cast<int>((nowUtc.msecsTo(expiresAtUtc) + dayMs - 1) / dayMs);
}
}  // namespace

namespace guard {
namespace license {

QString GuardLicenseManager::currentHardwareId() {
    return GuardHardwareId::identifier();
}

QString GuardLicenseManager::savedLicenseKey() {
    QByteArray protectedLicenseKey;
    if (!guard::security::SecureCredentialStore::read(QString::fromLatin1(kLicenseCredentialName), &protectedLicenseKey))
        return QString();
    return GuardLicenseAlgo::formatToken(QString::fromLatin1(protectedLicenseKey).trimmed());
}

bool GuardLicenseManager::writeSavedLicenseKey(const QString& formattedLicenseKey, QString* errorMessage) {
    return guard::security::SecureCredentialStore::write(QString::fromLatin1(kLicenseCredentialName), formattedLicenseKey.toLatin1(), errorMessage);
}

QString GuardLicenseManager::keyDigest(const QString& normalizedLicenseKey) {
    return QString::fromLatin1(QCryptographicHash::hash(normalizedLicenseKey.toUtf8(), QCryptographicHash::Sha256).toHex());
}

void GuardLicenseManager::savePermanentMetadata(const QString& normalizedLicenseKey) {
    QSettings settings;
    settings.setValue(QString::fromLatin1(kLicenseKindKey), QStringLiteral("permanent"));
    settings.setValue(QString::fromLatin1(kLicenseKeyDigestKey), keyDigest(normalizedLicenseKey));
    settings.setValue(QString::fromLatin1(kLicenseHardwareIdKey), currentHardwareId());
    settings.remove(QString::fromLatin1(kLicenseAcceptedAtKey));
    settings.remove(QString::fromLatin1(kLicenseExpiresAtKey));
    settings.sync();
}

void GuardLicenseManager::saveTemporaryMetadata(const QString& normalizedLicenseKey, const QDateTime& acceptedAtUtc, const QDateTime& expiresAtUtc) {
    QSettings settings;
    settings.setValue(QString::fromLatin1(kLicenseKindKey), QStringLiteral("temporary"));
    settings.setValue(QString::fromLatin1(kLicenseKeyDigestKey), keyDigest(normalizedLicenseKey));
    settings.setValue(QString::fromLatin1(kLicenseHardwareIdKey), currentHardwareId());
    settings.setValue(QString::fromLatin1(kLicenseAcceptedAtKey), isoDate(acceptedAtUtc));
    settings.setValue(QString::fromLatin1(kLicenseExpiresAtKey), isoDate(expiresAtUtc));
    settings.sync();
}

void GuardLicenseManager::clearMetadata() {
    QSettings settings;
    settings.remove(QString::fromLatin1(kLicenseKindKey));
    settings.remove(QString::fromLatin1(kLicenseKeyDigestKey));
    settings.remove(QString::fromLatin1(kLicenseAcceptedAtKey));
    settings.remove(QString::fromLatin1(kLicenseExpiresAtKey));
    settings.remove(QString::fromLatin1(kLicenseHardwareIdKey));
    settings.sync();
}

GuardLicenseManager::Status GuardLicenseManager::status() {
    Status result;
    const QString hardwareId = currentHardwareId();
    if (hardwareId.isEmpty()) {
        result.state = State::HardwareUnavailable;
        result.message = QCoreApplication::translate("GuardLicenseManager", "Hardware ID is unavailable on this computer.");
        return result;
    }

    const QString key = savedLicenseKey();
    result.savedLicenseKey = key;
    if (key.isEmpty()) {
        result.state = State::Missing;
        result.message = QCoreApplication::translate("GuardLicenseManager", "No Guard license key has been saved.");
        return result;
    }

    const GuardLicenseAlgo::GuardLicenseKind kind = GuardLicenseAlgo::classifyGuardLicense(hardwareId, key);
    if (kind == GuardLicenseAlgo::GuardLicenseKind::Invalid) {
        result.state = State::Invalid;
        result.message = QCoreApplication::translate("GuardLicenseManager", "The saved license key is not valid for this hardware ID.");
        return result;
    }

    const QString normalizedKey = GuardLicenseAlgo::normalizeToken(key);
    if (kind == GuardLicenseAlgo::GuardLicenseKind::Permanent) {
        savePermanentMetadata(normalizedKey);
        result.state = State::PermanentValid;
        result.message = QCoreApplication::translate("GuardLicenseManager", "Permanent Guard license is active.");
        return result;
    }

    QSettings settings;
    const QString storedDigest = settings.value(QString::fromLatin1(kLicenseKeyDigestKey)).toString();
    QDateTime acceptedAt = fromIsoDate(settings.value(QString::fromLatin1(kLicenseAcceptedAtKey)).toString());
    QDateTime expiresAt = fromIsoDate(settings.value(QString::fromLatin1(kLicenseExpiresAtKey)).toString());
    const QDateTime nowUtc = QDateTime::currentDateTimeUtc();
    if (storedDigest != keyDigest(normalizedKey) || !acceptedAt.isValid() || !expiresAt.isValid()) {
        acceptedAt = nowUtc;
        expiresAt = acceptedAt.addDays(kTemporaryLicenseDays);
        saveTemporaryMetadata(normalizedKey, acceptedAt, expiresAt);
    }

    result.acceptedAtUtc = acceptedAt;
    result.expiresAtUtc = expiresAt;
    result.daysRemaining = remainingDaysCeil(nowUtc, expiresAt);
    if (nowUtc >= expiresAt) {
        result.state = State::TemporaryExpired;
        result.message = QCoreApplication::translate("GuardLicenseManager", "The 7-day temporary Guard license has expired.");
    } else {
        result.state = State::TemporaryValid;
        result.message = QCoreApplication::translate("GuardLicenseManager", "Temporary Guard license is active.");
    }
    return result;
}

bool GuardLicenseManager::activateLicenseKey(const QString& licenseKey, bool permanentOnly, QString* errorMessage) {
    const QString hardwareId = currentHardwareId();
    if (hardwareId.isEmpty()) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("GuardLicenseManager", "Hardware ID is unavailable on this computer.");
        return false;
    }

    const QString normalizedKey = GuardLicenseAlgo::normalizeToken(licenseKey);
    if (normalizedKey.isEmpty()) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("GuardLicenseManager", "Enter the license key in XXXX-XXXX-XXXX-XXXX format.");
        return false;
    }

    const GuardLicenseAlgo::GuardLicenseKind kind = GuardLicenseAlgo::classifyGuardLicense(hardwareId, normalizedKey);
    if (kind == GuardLicenseAlgo::GuardLicenseKind::Invalid) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("GuardLicenseManager", "This license key is not valid for this Guard hardware ID.");
        return false;
    }
    if (permanentOnly && kind != GuardLicenseAlgo::GuardLicenseKind::Permanent) {
        if (errorMessage)
            *errorMessage =
              QCoreApplication::translate("GuardLicenseManager", "The temporary 7-day license has expired. Enter a permanent license key.");
        return false;
    }

    const QString formatted = GuardLicenseAlgo::formatToken(normalizedKey);
    QString credentialError;
    if (!writeSavedLicenseKey(formatted, &credentialError)) {
        if (errorMessage)
            *errorMessage = credentialError;
        return false;
    }

    if (kind == GuardLicenseAlgo::GuardLicenseKind::Permanent) {
        savePermanentMetadata(normalizedKey);
    } else {
        QSettings settings;
        const QString digest = keyDigest(normalizedKey);
        QDateTime acceptedAt = fromIsoDate(settings.value(QString::fromLatin1(kLicenseAcceptedAtKey)).toString());
        QDateTime expiresAt = fromIsoDate(settings.value(QString::fromLatin1(kLicenseExpiresAtKey)).toString());
        const QString storedDigest = settings.value(QString::fromLatin1(kLicenseKeyDigestKey)).toString();
        const QDateTime nowUtc = QDateTime::currentDateTimeUtc();
        if (storedDigest == digest && expiresAt.isValid() && nowUtc >= expiresAt) {
            if (errorMessage)
                *errorMessage =
                  QCoreApplication::translate("GuardLicenseManager", "The 7-day temporary Guard license has expired. Enter a permanent license key.");
            return false;
        }
        if (storedDigest != digest || !acceptedAt.isValid() || !expiresAt.isValid()) {
            acceptedAt = nowUtc;
            expiresAt = acceptedAt.addDays(kTemporaryLicenseDays);
        }
        saveTemporaryMetadata(normalizedKey, acceptedAt, expiresAt);
    }
    return true;
}

bool GuardLicenseManager::clearSavedLicense(QString* errorMessage) {
    QString credentialError;
    if (!guard::security::SecureCredentialStore::remove(QString::fromLatin1(kLicenseCredentialName), &credentialError)) {
        if (errorMessage)
            *errorMessage = credentialError;
        return false;
    }
    clearMetadata();
    return true;
}

QString GuardLicenseManager::stateDisplayText(State state) {
    switch (state) {
        case State::Missing:
            return QCoreApplication::translate("GuardLicenseManager", "Missing");
        case State::TemporaryValid:
            return QCoreApplication::translate("GuardLicenseManager", "Temporary 7-day license");
        case State::TemporaryExpired:
            return QCoreApplication::translate("GuardLicenseManager", "Temporary license expired");
        case State::PermanentValid:
            return QCoreApplication::translate("GuardLicenseManager", "Permanent license");
        case State::Invalid:
            return QCoreApplication::translate("GuardLicenseManager", "Invalid license");
        case State::HardwareUnavailable:
            return QCoreApplication::translate("GuardLicenseManager", "Hardware ID unavailable");
    }
    return QCoreApplication::translate("GuardLicenseManager", "Unknown");
}

bool GuardLicenseManager::requiresPermanentLicense(const Status& status) {
    return status.state == State::Missing || status.state == State::TemporaryExpired || status.state == State::Invalid ||
           status.state == State::HardwareUnavailable;
}

}  // namespace license
}  // namespace guard
