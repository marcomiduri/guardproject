#include "GuardLicenseAlgo.h"

#include <QCryptographicHash>
#include <QRegExp>

namespace {
const char kGuardTemporaryPurpose[] = "GUARD2-TEMPORARY-7-DAY-LICENSE";
const char kGuardPermanentPurpose[] = "GUARD2-PERMANENT-HARDWARE-LICENSE";
const char kLicenseGeneratorActivationPurpose[] = "GUARD2-LICENSE-GENERATOR-ACTIVATION";

// Keep this value identical in Guard, LicenseGenerator, and LicenseAuthority.
// It separates Guard license keys from unrelated 16-character hashes while
// keeping the displayed key in the required XXXX-XXXX-XXXX-XXXX format.
const char kLicenseSecret[] = "Guard-LicenseFlow-v2-MSVC2019-Qt5";

QString normalizedHardwareId(const QString& value) {
    QString normalized = value.trimmed().toUpper();
    normalized.remove(QLatin1Char('-'));
    normalized.remove(QLatin1Char('_'));
    normalized.remove(QLatin1Char(' '));
    return QRegExp(QStringLiteral("^[0-9A-Z]{16}$")).exactMatch(normalized) ? normalized : QString();
}
}  // namespace

namespace guard {
namespace license {

QString GuardLicenseAlgo::normalizeToken(const QString& value) {
    QString normalized = value.trimmed().toUpper();
    normalized.remove(QLatin1Char('-'));
    normalized.remove(QLatin1Char('_'));
    normalized.remove(QLatin1Char(' '));
    return QRegExp(QStringLiteral("^[0-9A-Z]{16}$")).exactMatch(normalized) ? normalized : QString();
}

QString GuardLicenseAlgo::formatToken(const QString& normalizedToken) {
    const QString normalized = normalizeToken(normalizedToken);
    if (normalized.isEmpty())
        return QString();
    return QStringLiteral("%1-%2-%3-%4").arg(normalized.mid(0, 4), normalized.mid(4, 4), normalized.mid(8, 4), normalized.mid(12, 4));
}

bool GuardLicenseAlgo::isValidTokenText(const QString& value) {
    return !normalizeToken(value).isEmpty();
}

QString GuardLicenseAlgo::tokenFromPurposeAndHardwareId(const QString& purpose, const QString& hardwareId) {
    const QString normalized = normalizedHardwareId(hardwareId);
    if (normalized.isEmpty())
        return QString();
    const QByteArray payload = purpose.toUtf8() + "|" + normalized.toLatin1() + "|" + QByteArray(kLicenseSecret);
    return QString::fromLatin1(QCryptographicHash::hash(payload, QCryptographicHash::Sha256).toHex().left(16)).toUpper();
}

QString GuardLicenseAlgo::temporaryGuardLicenseForHardwareId(const QString& guardHardwareId) {
    return formatToken(tokenFromPurposeAndHardwareId(QString::fromLatin1(kGuardTemporaryPurpose), guardHardwareId));
}

QString GuardLicenseAlgo::permanentGuardLicenseForHardwareId(const QString& guardHardwareId) {
    return formatToken(tokenFromPurposeAndHardwareId(QString::fromLatin1(kGuardPermanentPurpose), guardHardwareId));
}

GuardLicenseAlgo::GuardLicenseKind GuardLicenseAlgo::classifyGuardLicense(const QString& guardHardwareId, const QString& licenseKey) {
    const QString normalizedKey = normalizeToken(licenseKey);
    const QString temporaryKey = normalizeToken(temporaryGuardLicenseForHardwareId(guardHardwareId));
    const QString permanentKey = normalizeToken(permanentGuardLicenseForHardwareId(guardHardwareId));
    if (normalizedKey.isEmpty() || temporaryKey.isEmpty() || permanentKey.isEmpty())
        return GuardLicenseKind::Invalid;
    if (normalizedKey == permanentKey)
        return GuardLicenseKind::Permanent;
    if (normalizedKey == temporaryKey)
        return GuardLicenseKind::Temporary;
    return GuardLicenseKind::Invalid;
}

QString GuardLicenseAlgo::licenseGeneratorActivationCodeForHardwareId(const QString& generatorHardwareId) {
    return formatToken(tokenFromPurposeAndHardwareId(QString::fromLatin1(kLicenseGeneratorActivationPurpose), generatorHardwareId));
}

bool GuardLicenseAlgo::validateLicenseGeneratorActivationCode(const QString& generatorHardwareId, const QString& activationCode) {
    const QString expected = normalizeToken(licenseGeneratorActivationCodeForHardwareId(generatorHardwareId));
    const QString actual = normalizeToken(activationCode);
    return !expected.isEmpty() && expected == actual;
}

}  // namespace license
}  // namespace guard
