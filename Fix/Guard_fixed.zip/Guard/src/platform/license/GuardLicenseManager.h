#ifndef GUARDLICENSEMANAGER_H
#define GUARDLICENSEMANAGER_H

#include "GuardLicenseAlgo.h"

#include <QDateTime>
#include <QString>

namespace guard {
namespace license {

class GuardLicenseManager {
public:
    enum class State { Missing, TemporaryValid, TemporaryExpired, PermanentValid, Invalid, HardwareUnavailable };

    struct Status {
        State state = State::Missing;
        QString savedLicenseKey;
        QString message;
        QDateTime acceptedAtUtc;
        QDateTime expiresAtUtc;
        int daysRemaining = 0;
    };

    static Status status();
    static bool activateLicenseKey(const QString& licenseKey, bool permanentOnly, QString* errorMessage = nullptr);
    static bool clearSavedLicense(QString* errorMessage = nullptr);
    static QString stateDisplayText(State state);
    static bool requiresPermanentLicense(const Status& status);

private:
    static QString currentHardwareId();
    static QString savedLicenseKey();
    static bool writeSavedLicenseKey(const QString& formattedLicenseKey, QString* errorMessage);
    static QString keyDigest(const QString& normalizedLicenseKey);
    static void savePermanentMetadata(const QString& normalizedLicenseKey);
    static void saveTemporaryMetadata(const QString& normalizedLicenseKey, const QDateTime& acceptedAtUtc, const QDateTime& expiresAtUtc);
    static void clearMetadata();
};

}  // namespace license
}  // namespace guard

#endif  // GUARDLICENSEMANAGER_H
