#ifndef CAMERAFILELOGGER_H
#define CAMERAFILELOGGER_H

#include <QFile>
#include <QMutex>
#include <QString>

#include <memory>

namespace guard {
namespace diagnostics {

class CameraFileLogger {
public:
    CameraFileLogger();
    ~CameraFileLogger();

    Q_DISABLE_COPY(CameraFileLogger)

    bool configure(const QString& cameraName, const QString& cameraId, QString* errorMessage = nullptr);
    bool appendLine(const QString& line, QString* errorMessage = nullptr);
    void close();

    QString filePath() const;
    QString directoryPath() const;
    bool isReady() const;

    static QString defaultDirectoryPath();
    static QString configuredDirectoryPath();
    static QString effectiveDirectoryPath();
    static bool isDirectoryLockedByEnvironment();
    static bool setConfiguredDirectoryPath(const QString& directoryPath, QString* errorMessage = nullptr);
    static QString sanitizedFileStem(const QString& cameraName);
    static bool persistentLoggingEnabled();
    static void setPersistentLoggingEnabled(bool enabled);

private:
    static QString claimPath(const QString& directoryPath, const QString& fileStem, const QString& cameraId);
    static void releasePath(const QString& filePath, const QString& cameraId);

    mutable QMutex mutex_;
    std::unique_ptr<QFile> file_;
    QString filePath_;
    QString cameraId_;
};

}  // namespace diagnostics
}  // namespace guard

#endif  // CAMERAFILELOGGER_H
