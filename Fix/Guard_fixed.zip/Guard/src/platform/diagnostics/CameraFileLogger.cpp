#include "CameraFileLogger.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QHash>
#include <QMutexLocker>
#include <QSettings>
#include <QStandardPaths>

namespace {

const char kCameraFileLoggingEnabledKey[] = "diagnostics/cameraFileLoggingEnabled";
const char kCameraLogDirectoryKey[] = "diagnostics/cameraLogDirectory";

QMutex& claimMutex() {
    static QMutex mutex;
    return mutex;
}

QHash<QString, QString>& claimedPaths() {
    static QHash<QString, QString> paths;
    return paths;
}

QString normalizedClaimKey(const QString& path) {
    QString key = QDir::cleanPath(QFileInfo(path).absoluteFilePath());
#ifdef Q_OS_WIN
    key = key.toLower();
#endif
    return key;
}

QString compactCameraId(QString cameraId) {
    cameraId.remove(QLatin1Char('{'));
    cameraId.remove(QLatin1Char('}'));
    cameraId.remove(QLatin1Char('-'));
    cameraId = cameraId.trimmed();
    if (cameraId.isEmpty()) {
        cameraId = QString::number(QDateTime::currentMSecsSinceEpoch());
    }
    return cameraId.left(8);
}

bool isWindowsReservedName(const QString& stem) {
    const QString upper = stem.section(QLatin1Char('.'), 0, 0).toUpper();
    if (upper == QStringLiteral("CON") || upper == QStringLiteral("PRN") || upper == QStringLiteral("AUX") || upper == QStringLiteral("NUL")) {
        return true;
    }
    if (upper.size() == 4 && (upper.startsWith(QStringLiteral("COM")) || upper.startsWith(QStringLiteral("LPT")))) {
        const QChar suffix = upper.at(3);
        return suffix >= QLatin1Char('1') && suffix <= QLatin1Char('9');
    }
    return false;
}

QString environmentDirectoryPath() {
    const QString environmentRoot = QString::fromLocal8Bit(qgetenv("GUARD_LOG_ROOT")).trimmed();
    return environmentRoot.isEmpty() ? QString() : QDir(environmentRoot).filePath(QStringLiteral("cameras"));
}

QString normalizedDirectoryPath(const QString& path) {
    const QString trimmed = path.trimmed();
    if (trimmed.isEmpty()) {
        return QString();
    }
    return QDir::cleanPath(QFileInfo(trimmed).absoluteFilePath());
}

bool ensureWritableDirectory(const QString& directoryPath, QString* errorMessage) {
    const QFileInfo existing(directoryPath);
    if (existing.exists() && !existing.isDir()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("The camera log path is not a folder: %1").arg(directoryPath);
        }
        return false;
    }
    if (!QDir().mkpath(directoryPath)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Could not create camera log folder: %1").arg(directoryPath);
        }
        return false;
    }

    const QString probePath =
      QDir(directoryPath)
        .filePath(QStringLiteral(".guard-log-write-test-%1-%2.tmp").arg(QCoreApplication::applicationPid()).arg(QDateTime::currentMSecsSinceEpoch()));
    QFile probe(probePath);
    if (!probe.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("The camera log folder is not writable: %1 (%2)").arg(directoryPath, probe.errorString());
        }
        return false;
    }
    probe.write("Guard");
    probe.close();
    probe.remove();
    return true;
}

}  // namespace

namespace guard {
namespace diagnostics {

CameraFileLogger::CameraFileLogger() = default;

CameraFileLogger::~CameraFileLogger() {
    close();
}

void CameraFileLogger::close() {
    QString oldPath;
    QString oldCameraId;
    {
        QMutexLocker locker(&mutex_);
        if (file_) {
            file_->flush();
            file_->close();
        }
        oldPath = filePath_;
        oldCameraId = cameraId_;
        file_.reset();
        filePath_.clear();
        cameraId_.clear();
    }
    releasePath(oldPath, oldCameraId);
}

bool CameraFileLogger::persistentLoggingEnabled() {
    QSettings settings;
    return settings.value(QString::fromLatin1(kCameraFileLoggingEnabledKey), true).toBool();
}

void CameraFileLogger::setPersistentLoggingEnabled(bool enabled) {
    QSettings settings;
    settings.setValue(QString::fromLatin1(kCameraFileLoggingEnabledKey), enabled);
}

QString CameraFileLogger::defaultDirectoryPath() {
    QString base = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (base.trimmed().isEmpty()) {
        base = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("data"));
    }
    return QDir(base).filePath(QStringLiteral("logs/cameras"));
}

QString CameraFileLogger::configuredDirectoryPath() {
    QSettings settings;
    return normalizedDirectoryPath(settings.value(QString::fromLatin1(kCameraLogDirectoryKey)).toString());
}

QString CameraFileLogger::effectiveDirectoryPath() {
    const QString environmentPath = normalizedDirectoryPath(environmentDirectoryPath());
    if (!environmentPath.isEmpty()) {
        return environmentPath;
    }
    const QString configuredPath = configuredDirectoryPath();
    return configuredPath.isEmpty() ? defaultDirectoryPath() : configuredPath;
}

bool CameraFileLogger::isDirectoryLockedByEnvironment() {
    return !environmentDirectoryPath().trimmed().isEmpty();
}

bool CameraFileLogger::setConfiguredDirectoryPath(const QString& directoryPath, QString* errorMessage) {
    if (isDirectoryLockedByEnvironment()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("GUARD_LOG_ROOT controls the camera log folder for this process.");
        }
        return false;
    }

    const QString normalized = normalizedDirectoryPath(directoryPath);
    QSettings settings;
    if (normalized.isEmpty()) {
        settings.remove(QString::fromLatin1(kCameraLogDirectoryKey));
        return true;
    }
    if (!ensureWritableDirectory(normalized, errorMessage)) {
        return false;
    }
    settings.setValue(QString::fromLatin1(kCameraLogDirectoryKey), normalized);
    return true;
}

QString CameraFileLogger::sanitizedFileStem(const QString& cameraName) {
    QString stem = cameraName.trimmed();
    if (stem.isEmpty()) {
        stem = QStringLiteral("Camera");
    }

    for (int index = 0; index < stem.size(); ++index) {
        const QChar ch = stem.at(index);
        if (ch.unicode() < 32 || ch == QLatin1Char('<') || ch == QLatin1Char('>') || ch == QLatin1Char(':') || ch == QLatin1Char('"') ||
            ch == QLatin1Char('/') || ch == QLatin1Char('\\') || ch == QLatin1Char('|') || ch == QLatin1Char('?') || ch == QLatin1Char('*')) {
            stem[index] = QLatin1Char('_');
        }
    }

    while (stem.endsWith(QLatin1Char('.')) || stem.endsWith(QLatin1Char(' '))) {
        stem.chop(1);
    }
    if (stem.isEmpty() || stem == QStringLiteral(".") || stem == QStringLiteral("..")) {
        stem = QStringLiteral("Camera");
    }
    if (isWindowsReservedName(stem)) {
        stem.prepend(QLatin1Char('_'));
    }

    constexpr int kMaximumStemLength = 120;
    if (stem.size() > kMaximumStemLength) {
        stem = stem.left(kMaximumStemLength).trimmed();
        while (stem.endsWith(QLatin1Char('.')) || stem.endsWith(QLatin1Char(' '))) {
            stem.chop(1);
        }
    }
    return stem.isEmpty() ? QStringLiteral("Camera") : stem;
}

QString CameraFileLogger::claimPath(const QString& directoryPath, const QString& fileStem, const QString& cameraId) {
    QMutexLocker locker(&claimMutex());

    QString candidate = QDir(directoryPath).filePath(fileStem + QStringLiteral(".log"));
    QString key = normalizedClaimKey(candidate);
    QString existingOwner = claimedPaths().value(key);
    if (!existingOwner.isEmpty() && existingOwner != cameraId) {
        const QString suffixedStem = QStringLiteral("%1-%2").arg(fileStem, compactCameraId(cameraId));
        int counter = 1;
        do {
            const QString suffix = counter == 1 ? QString() : QStringLiteral("-%1").arg(counter);
            candidate = QDir(directoryPath).filePath(suffixedStem + suffix + QStringLiteral(".log"));
            key = normalizedClaimKey(candidate);
            existingOwner = claimedPaths().value(key);
            ++counter;
        } while (!existingOwner.isEmpty() && existingOwner != cameraId);
    }
    claimedPaths().insert(key, cameraId);
    return candidate;
}

void CameraFileLogger::releasePath(const QString& filePath, const QString& cameraId) {
    if (filePath.isEmpty()) {
        return;
    }
    QMutexLocker locker(&claimMutex());
    const QString key = normalizedClaimKey(filePath);
    if (claimedPaths().value(key) == cameraId) {
        claimedPaths().remove(key);
    }
}

bool CameraFileLogger::configure(const QString& cameraName, const QString& cameraId, QString* errorMessage) {
    const QString directory = effectiveDirectoryPath();
    if (!QDir().mkpath(directory)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Could not create camera log directory: %1").arg(directory);
        }
        return false;
    }

    QString newCameraId = cameraId.trimmed();
    if (newCameraId.isEmpty()) {
        newCameraId = QStringLiteral("runtime-%1").arg(static_cast<qulonglong>(reinterpret_cast<quintptr>(this)), 0, 16);
    }
    const QString candidate = claimPath(directory, sanitizedFileStem(cameraName), newCameraId);
    std::unique_ptr<QFile> candidateFile(new QFile(candidate));
    if (!candidateFile->open(QIODevice::WriteOnly | QIODevice::Append)) {
        const QString openError = candidateFile->errorString();
        releasePath(candidate, newCameraId);
        if (errorMessage) {
            *errorMessage = QStringLiteral("Could not open camera log file %1: %2").arg(candidate, openError);
        }
        return false;
    }

    QString oldPath;
    QString oldCameraId;
    {
        QMutexLocker locker(&mutex_);
        oldPath = filePath_;
        oldCameraId = cameraId_;
        if (file_) {
            file_->flush();
            file_->close();
        }
        file_ = std::move(candidateFile);
        filePath_ = candidate;
        cameraId_ = newCameraId;
    }
    if (normalizedClaimKey(oldPath) != normalizedClaimKey(candidate) || oldCameraId != newCameraId) {
        releasePath(oldPath, oldCameraId);
    }
    return true;
}

bool CameraFileLogger::appendLine(const QString& line, QString* errorMessage) {
    if (line.isEmpty()) {
        return true;
    }

    QMutexLocker locker(&mutex_);
    if (!file_ || !file_->isOpen()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Camera log file is not open.");
        }
        return false;
    }

    QByteArray bytes = line.toUtf8();
    bytes.append("\r\n");
    if (file_->write(bytes) != bytes.size()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Could not write camera log file %1: %2").arg(filePath_, file_->errorString());
        }
        return false;
    }
    if (!file_->flush()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Could not flush camera log file %1: %2").arg(filePath_, file_->errorString());
        }
        return false;
    }
    return true;
}

QString CameraFileLogger::filePath() const {
    QMutexLocker locker(&mutex_);
    return filePath_;
}

QString CameraFileLogger::directoryPath() const {
    QMutexLocker locker(&mutex_);
    return filePath_.isEmpty() ? effectiveDirectoryPath() : QFileInfo(filePath_).absolutePath();
}

bool CameraFileLogger::isReady() const {
    QMutexLocker locker(&mutex_);
    return file_ && file_->isOpen();
}

}  // namespace diagnostics
}  // namespace guard
