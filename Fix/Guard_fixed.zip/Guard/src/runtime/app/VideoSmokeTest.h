#pragma once

#include <QString>

namespace guard {
namespace runtime {

int runVideoSmokeTest(const QString& videoPath, int timeoutMs = 10000, int minimumFrames = 5);

}  // namespace runtime
}  // namespace guard
