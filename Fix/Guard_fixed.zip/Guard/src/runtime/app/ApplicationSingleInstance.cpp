#include "ApplicationSingleInstance.h"

#include <QLocalServer>
#include <QLocalSocket>

namespace guard {
namespace runtime {

namespace {

const char kActivateMessage[] = "activate";
const char kServerName[] = "apex-image-guard-single-instance-v1";
constexpr int kConnectTimeoutMs = 1500;
constexpr int kWriteTimeoutMs = 1500;

bool sendActivationRequest(const QString& serverName) {
    QLocalSocket socket;
    socket.connectToServer(serverName);
    if (!socket.waitForConnected(kConnectTimeoutMs))
        return false;
    socket.write(kActivateMessage);
    socket.flush();
    socket.waitForBytesWritten(kWriteTimeoutMs);
    socket.disconnectFromServer();
    return true;
}

}  // namespace

ApplicationSingleInstance::ApplicationSingleInstance(QObject* parent) : QObject(parent) {}

ApplicationSingleInstance::~ApplicationSingleInstance() {
    if (!server_)
        return;
    server_->close();
    QLocalServer::removeServer(serverName());
}

QString ApplicationSingleInstance::serverName() const {
    return QString::fromLatin1(kServerName);
}

bool ApplicationSingleInstance::notifyPrimaryInstance() {
    return sendActivationRequest(serverName());
}

bool ApplicationSingleInstance::startListening() {
    server_ = new QLocalServer(this);
    connect(server_, &QLocalServer::newConnection, this, [this]() {
        QLocalSocket* client = server_->nextPendingConnection();
        if (!client)
            return;
        connect(client, &QLocalSocket::readyRead, this, [this, client]() {
            if (client->readAll().contains(QByteArray(kActivateMessage)))
                emit activationRequested();
        });
        connect(client, &QLocalSocket::disconnected, client, &QObject::deleteLater);
    });

    if (server_->listen(serverName()))
        return true;

    if (server_->serverError() != QAbstractSocket::AddressInUseError)
        return false;

    QLocalServer::removeServer(serverName());
    return server_->listen(serverName());
}

bool ApplicationSingleInstance::tryBecomePrimary() {
    if (notifyPrimaryInstance())
        return false;

    if (startListening())
        return true;

    if (notifyPrimaryInstance())
        return false;

    return startListening();
}

}  // namespace runtime
}  // namespace guard
