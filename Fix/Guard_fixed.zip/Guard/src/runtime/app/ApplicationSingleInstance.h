#pragma once

#include <QObject>

class QLocalServer;

namespace guard {
namespace runtime {

class ApplicationSingleInstance : public QObject {
    Q_OBJECT

public:
    explicit ApplicationSingleInstance(QObject* parent = nullptr);
    ~ApplicationSingleInstance() override;

    // Returns true when this process should continue startup as the primary instance.
    // Returns false when an existing instance was notified to open instead.
    bool tryBecomePrimary();

signals:
    void activationRequested();

private:
    QString serverName() const;
    bool notifyPrimaryInstance();
    bool startListening();

    QLocalServer* server_ = nullptr;
};

}  // namespace runtime
}  // namespace guard
