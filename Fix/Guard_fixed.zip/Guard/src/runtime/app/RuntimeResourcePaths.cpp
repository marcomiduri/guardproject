#include "runtime/app/RuntimeResourcePaths.h"

#include <QByteArray>
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QStringList>

namespace guard {
namespace runtime {
namespace {

QString firstExistingPath(const QStringList& candidates) {
    for (const QString& candidate : candidates) {
        if (candidate.trimmed().isEmpty()) {
            continue;
        }
        const QString resolved = QFileInfo(candidate).absoluteFilePath();
        if (QFile::exists(resolved)) {
            return resolved;
        }
    }
    return QString();
}

}  // namespace

QString resolveIdentifyResourcePath() {
    const QString appDir = QCoreApplication::applicationDirPath();
    const QByteArray overridePath = qgetenv("GUARD_IDENTIFY_RESOURCE");
    return firstExistingPath(QStringList() << QString::fromLocal8Bit(overridePath) << QDir(appDir).filePath(QStringLiteral("Pikachu"))
                                           << QDir(appDir).filePath(QStringLiteral("models/Pikachu")));
}

QString resolveHazardModelPath() {
    const QString appDir = QCoreApplication::applicationDirPath();
    const QByteArray overridePath = qgetenv("GUARD_HAZARD_MODEL");
    return firstExistingPath(QStringList() << QString::fromLocal8Bit(overridePath) << QDir(appDir).filePath(QStringLiteral("models/fire_smoke.onnx"))
                                           << QDir(appDir).filePath(QStringLiteral("fire_smoke.onnx")));
}

}  // namespace runtime
}  // namespace guard
