#pragma once

#include <QString>

namespace guard {
namespace runtime {

QString resolveIdentifyResourcePath();
QString resolveHazardModelPath();

}  // namespace runtime
}  // namespace guard
