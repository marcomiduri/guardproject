#include "runtime/app/VideoSmokeTest.h"

#include "CameraDetectionSettings.h"
#include "integration/guardvision/FrameSubmissionPipeline.h"
#include "media/MediaSourceController.h"
#include "runtime/app/RuntimeResourcePaths.h"

#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <core/StreamConfig.h>

#include <QEventLoop>
#include <QFileInfo>
#include <QImage>
#include <QObject>
#include <QTimer>

#include <cstdint>
#include <cstdio>

namespace guard {
namespace runtime {
namespace {

void printDiagnostic(const QString& message) {
    const QByteArray text = message.toLocal8Bit();
    std::fprintf(stderr, "%s\n", text.constData());
}

void printInfo(const QString& message) {
    const QByteArray text = message.toLocal8Bit();
    std::fprintf(stdout, "%s\n", text.constData());
}

}  // namespace

int runVideoSmokeTest(const QString& videoPath, int timeoutMs, int minimumFrames) {
    const QFileInfo fileInfo(videoPath);
    if (!fileInfo.exists() || !fileInfo.isFile() || !fileInfo.isReadable()) {
        printDiagnostic(QStringLiteral("Video smoke test failed: file is missing or unreadable: %1").arg(fileInfo.absoluteFilePath()));
        return 2;
    }

    guardvision::GuardVision guardVision;
    guardvision::GuardVisionConfig config;
    config.maxStreams = 1;
    config.frameWorkerCount = 1;
    config.faceWorkerCount = 1;
    config.hazardWorkerCount = 1;

    const QString identifyPath = resolveIdentifyResourcePath();
    const QString hazardPath = resolveHazardModelPath();
    if (!identifyPath.isEmpty()) {
        config.identifyResourcePath = identifyPath.toStdString();
    }
    if (!hazardPath.isEmpty()) {
        config.hazardResourcePath = hazardPath.toStdString();
    }

    guardvision::Result result = guardVision.initialize(config);
    if (!result.ok) {
        printDiagnostic(
          QStringLiteral("Video smoke test failed: GuardVision initialization failed: %1").arg(QString::fromStdString(result.error.message)));
        return 3;
    }

    const QString streamId = QStringLiteral("guard-video-smoke");
    CameraDetectionSettings settings;
    guardvision::StreamConfig streamConfig;
    streamConfig.streamId = streamId.toStdString();
    streamConfig.displayName = "Guard video smoke";
    streamConfig.motion = settings.motion;
    streamConfig.face = settings.face;
    streamConfig.hazard = settings.hazard;

    result = guardVision.registerStream(streamConfig);
    if (!result.ok) {
        printDiagnostic(QStringLiteral("Video smoke test failed: stream registration failed: %1").arg(QString::fromStdString(result.error.message)));
        guardVision.shutdown();
        return 4;
    }

    MediaSourceController media;
    SubmissionState submissionState;
    QString failure;
    int decodedFrames = 0;
    int previewFrames = 0;
    int submittedFrames = 0;
    int acceptedFrames = 0;
    bool sourceStarted = false;

    QEventLoop loop;
    QTimer timeout;
    timeout.setSingleShot(true);
    QObject::connect(&timeout, &QTimer::timeout, &loop, [&]() {
        failure = QStringLiteral("Timed out after %1 ms while waiting for %2 decoded frames. decoded=%3 preview=%4 submitted=%5 accepted=%6")
                    .arg(timeoutMs)
                    .arg(minimumFrames)
                    .arg(decodedFrames)
                    .arg(previewFrames)
                    .arg(submittedFrames)
                    .arg(acceptedFrames);
        loop.quit();
    });

    QObject::connect(&media, &MediaSourceController::statusChanged, &loop, [&](int, const QString& message) {
        if (!message.isEmpty()) {
            printInfo(QStringLiteral("Video smoke source status: %1").arg(message));
        }
    });
    QObject::connect(&media, &MediaSourceController::previewFrameReady, &loop, [&](const QImage&, quint64) { ++previewFrames; });
    QObject::connect(&media, &MediaSourceController::decoderError, &loop, [&](const QString& message) {
        failure = message;
        loop.quit();
    });
    QObject::connect(&media, &MediaSourceController::frameReadyForSubmission, &loop,
                     [&](const QImage& frame, quint64 sequence, qint64 timestampMs, quint64 generation) {
                         ++decodedFrames;
                         bool shouldStop = false;
                         const guardvision::SubmitResult submitResult = FrameSubmissionPipeline::submitDecodedFrame(
                           guardVision, streamId, true, FrameSubmissionPipeline::fromRgbImage(frame, sequence, timestampMs, generation), generation,
                           submissionState, &shouldStop);
                         ++submittedFrames;
                         if (submitResult.accepted) {
                             ++acceptedFrames;
                         } else {
                             printInfo(QStringLiteral("Video smoke frame rejected: %1").arg(QString::fromStdString(submitResult.error.message)));
                         }
                         if (shouldStop) {
                             failure =
                               QStringLiteral("GuardVision rejected frame submission: %1").arg(QString::fromStdString(submitResult.error.message));
                             loop.quit();
                             return;
                         }
                         if (decodedFrames >= minimumFrames && previewFrames > 0 &&
                             submissionState.counters.submitted >= static_cast<std::uint64_t>(minimumFrames)) {
                             loop.quit();
                         }
                     });

    media.configureFile(fileInfo.absoluteFilePath());
    sourceStarted = media.start(streamId);
    if (!sourceStarted) {
        printDiagnostic(QStringLiteral("Video smoke test failed: media source did not start."));
        guardVision.unregisterStream(streamId.toStdString());
        guardVision.shutdown();
        return 5;
    }

    timeout.start(timeoutMs);
    loop.exec();
    media.stop();
    guardVision.unregisterStream(streamId.toStdString());
    guardVision.shutdown();

    if (!failure.isEmpty()) {
        printDiagnostic(QStringLiteral("Video smoke test failed.\n%1").arg(failure));
        return 6;
    }

    printInfo(QStringLiteral("Video smoke test passed: decoded=%1 preview=%2 submitted=%3 accepted=%4 file=%5")
                .arg(decodedFrames)
                .arg(previewFrames)
                .arg(submittedFrames)
                .arg(acceptedFrames)
                .arg(fileInfo.absoluteFilePath()));
    return 0;
}

}  // namespace runtime
}  // namespace guard
