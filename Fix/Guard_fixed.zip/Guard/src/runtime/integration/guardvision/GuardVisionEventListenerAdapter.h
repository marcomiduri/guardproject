#pragma once

#include <QObject>
#include <QRect>
#include <QString>
#include <QVector>

#include <atomic>

#include <events/AlarmEvent.h>
#include <events/EventListener.h>
#include <face/FaceEvent.h>
#include <face/FaceTypes.h>
#include <events/FrameProcessedEvent.h>
#include <hazard/HazardEvent.h>
#include <hazard/HazardTypes.h>
#include <motion/MotionEvent.h>
#include <core/StreamStatus.h>

class GuardVisionEventListenerAdapter : public QObject, public guardvision::IGuardVisionEventListener {
    Q_OBJECT

public:
    explicit GuardVisionEventListenerAdapter(QObject* parent = nullptr);

    void disable() noexcept;

    void onStreamStatus(const guardvision::StreamStatus& status) override;
    void onFrameProcessed(const guardvision::FrameProcessedEvent& event) override;
    void onMotion(const guardvision::MotionEvent& event) override;
    void onFace(const guardvision::FaceEvent& event) override;
    void onHazard(const guardvision::HazardEvent& event) override;
    void onAlarm(const guardvision::AlarmEvent& event) override;
    void onError(const guardvision::GuardVisionError& error) override;

signals:
    void streamStatusReceived(QString streamId, int state, bool acceptingFrames, bool hasPendingFrame, bool processingFrame, quint64 generation,
                              quint64 lastAcceptedSequence, qint64 lastAcceptedTimestampMs);
    void frameProcessedReceived(QString streamId, quint64 generation, quint64 sequence, qint64 timestampMs, qint64 submittedAtMs,
                                qint64 processedAtMs, qint64 queueDelayMs);
    void motionReceived(QString streamId, int eventType, int motionState, quint64 generation, quint64 sequence, qint64 timestampMs, double score,
                        double changedAreaRatio, int regionCount, int analysisX, int analysisY, int analysisWidth, int analysisHeight,
                        QVector<QRect> regions, QVector<double> regionScores, QVector<double> regionAreaRatios);
    void faceReceived(QString streamId, int eventType, quint64 generation, quint64 sequence, qint64 timestampMs, QVector<QRect> bounds,
                      QVector<quint64> trackIds, QVector<quint64> identityIds, QVector<QString> displayNames, QVector<double> identityConfidences,
                      QVector<bool> identifiedFlags);
    void hazardReceived(QString streamId, int eventType, quint64 generation, quint64 sequence, qint64 timestampMs, QVector<QRect> bounds,
                        QVector<int> hazardTypes, QVector<double> confidences);
    void alarmReceived(QString streamId, quint64 generation, int alarmType, int alarmState, int alarmSource, qint64 timestampMs, double confidence,
                       QVector<QRect> regions, QString onboardTargetId, quint64 softwareTrackId);
    void errorReceived(int code, QString message, QString component, QString streamId);

private:
    std::atomic<bool> callbacksEnabled_{true};
};
