#pragma once

#include <QImage>

#include <cstdint>

#include <GuardVision.h>
#include <core/SubmitResult.h>

#include "integration/guardvision/DecodedFrame.h"
#include "integration/guardvision/FrameSubmissionHelper.h"

struct SubmissionCounters {
    std::uint64_t decoded = 0;
    std::uint64_t submitted = 0;
    std::uint64_t accepted = 0;
    std::uint64_t rejected = 0;
    std::uint64_t replaced = 0;
};

struct SubmissionState {
    SubmissionCounters counters;
    guardvision::SubmitResult lastResult{};
    FrameBuildInfo lastBuildInfo{};
    int consecutiveRejections = 0;
};

class FrameSubmissionPipeline {
public:
    static QImage normalizedRgbImage(const QImage& frame);
    static DecodedFrame fromRgbImage(const QImage& image, quint64 sequence, qint64 timestampMs, quint64 generation);

    static guardvision::SubmitResult submitDecodedFrame(guardvision::GuardVision& guardVision, const QString& streamId, bool streamRegistered,
                                                        const DecodedFrame& frame, quint64 activeGeneration, SubmissionState& state,
                                                        bool* shouldStopPlayback);
};
