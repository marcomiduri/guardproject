#pragma once

#include <QImage>

#include <cstddef>
#include <cstdint>
#include <QString>

#include <core/SubmitResult.h>
#include <frame/VideoFrame.h>

struct FrameBuildInfo {
    guardvision::VideoFrame frame;
    bool videoFrameValid = false;
    std::size_t bufferSize = 0;
};

class FrameSubmissionHelper {
public:
    static FrameBuildInfo buildFrame(const QImage& image, const QString& streamId, guardvision::PixelFormat format, std::uint64_t sequence,
                                     std::int64_t timestampMs);
};

QString submitStatusToString(guardvision::SubmitStatus status);
