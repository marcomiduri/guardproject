#include "integration/guardvision/FrameSubmissionPipeline.h"

#include <core/Error.h>

#include <utility>

QImage FrameSubmissionPipeline::normalizedRgbImage(const QImage& frame) {
    if (frame.isNull()) {
        return frame;
    }
    return frame.format() == QImage::Format_RGB888 ? frame : frame.convertToFormat(QImage::Format_RGB888);
}

DecodedFrame FrameSubmissionPipeline::fromRgbImage(const QImage& image, quint64 sequence, qint64 timestampMs, quint64 generation) {
    DecodedFrame frame;
    frame.previewImage = normalizedRgbImage(image);
    frame.width = frame.previewImage.width();
    frame.height = frame.previewImage.height();
    frame.stride = static_cast<int>(frame.previewImage.bytesPerLine());
    frame.pixelFormat = guardvision::PixelFormat::RGB24;
    frame.timestampMs = timestampMs;
    frame.sequence = sequence;
    frame.sourceGeneration = generation;
    return frame;
}

guardvision::SubmitResult FrameSubmissionPipeline::submitDecodedFrame(guardvision::GuardVision& guardVision, const QString& streamId,
                                                                      bool streamRegistered, const DecodedFrame& frame, quint64 activeGeneration,
                                                                      SubmissionState& state, bool* shouldStopPlayback) {
    if (shouldStopPlayback) {
        *shouldStopPlayback = false;
    }

    guardvision::SubmitResult result;
    if (frame.sourceGeneration != activeGeneration) {
        return result;
    }

    ++state.counters.decoded;

    if (!guardVision.isInitialized() || !streamRegistered) {
        return result;
    }

    FrameBuildInfo info;
    if (frame.pixelFormat == guardvision::PixelFormat::BGR24 && !frame.data.isEmpty()) {
        info.frame.streamId = streamId.toStdString();
        info.frame.sequence = frame.sequence;
        info.frame.timestampMs = frame.timestampMs;
        info.frame.width = frame.width;
        info.frame.height = frame.height;
        info.frame.stride = frame.stride;
        info.frame.pixelFormat = guardvision::PixelFormat::BGR24;
        info.frame.buffer = guardvision::FrameBuffer::copyFrom(reinterpret_cast<const std::uint8_t*>(frame.data.constData()),
                                                               static_cast<std::size_t>(frame.data.size()));
        info.videoFrameValid = info.frame.isValid();
    } else {
        info = FrameSubmissionHelper::buildFrame(frame.previewImage, streamId, guardvision::PixelFormat::RGB24, frame.sequence, frame.timestampMs);
    }

    ++state.counters.submitted;
    state.lastBuildInfo = info;
    if (!info.videoFrameValid) {
        result.status = guardvision::SubmitStatus::InvalidFrame;
        result.accepted = false;
        result.error.code = guardvision::GuardVisionErrorCode::InvalidFrame;
        result.error.message = "Built VideoFrame is invalid.";
    } else {
        result = guardVision.submitFrame(std::move(info.frame));
    }

    state.lastResult = result;

    if (result.accepted) {
        ++state.counters.accepted;
        if (result.status == guardvision::SubmitStatus::ReplacedOlderPendingFrame) {
            ++state.counters.replaced;
        }
        state.consecutiveRejections = 0;
    } else {
        ++state.counters.rejected;
        ++state.consecutiveRejections;
        if (shouldStopPlayback &&
            (result.status == guardvision::SubmitStatus::NotInitialized || result.status == guardvision::SubmitStatus::StreamNotRegistered ||
             result.status == guardvision::SubmitStatus::InternalError)) {
            *shouldStopPlayback = true;
        }
    }

    return result;
}
