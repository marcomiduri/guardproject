#include "integration/guardvision/FrameSubmissionHelper.h"

#include <frame/FrameBuffer.h>

FrameBuildInfo FrameSubmissionHelper::buildFrame(const QImage& image, const QString& streamId, guardvision::PixelFormat format,
                                                 std::uint64_t sequence, std::int64_t timestampMs) {
    FrameBuildInfo info;
    info.frame.streamId = streamId.toStdString();
    info.frame.sequence = sequence;
    info.frame.timestampMs = timestampMs;
    info.frame.pixelFormat = format;

    if (!image.isNull()) {
        info.frame.width = image.width();
        info.frame.height = image.height();
        info.frame.stride = static_cast<int>(image.bytesPerLine());
        const std::size_t sizeBytes = static_cast<std::size_t>(info.frame.stride) * static_cast<std::size_t>(info.frame.height);
        info.bufferSize = sizeBytes;
        info.frame.buffer = guardvision::FrameBuffer::copyFrom(image.constBits(), sizeBytes);
    }

    info.videoFrameValid = info.frame.isValid();
    if (info.frame.buffer) {
        info.bufferSize = info.frame.buffer->sizeBytes();
    }
    return info;
}

QString submitStatusToString(guardvision::SubmitStatus status) {
    return QString::fromLatin1(guardvision::toString(status));
}
