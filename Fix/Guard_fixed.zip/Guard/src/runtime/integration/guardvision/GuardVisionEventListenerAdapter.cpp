#include "integration/guardvision/GuardVisionEventListenerAdapter.h"

#include <QRect>
#include <QVector>

#include <core/Error.h>
#include <face/FaceTypes.h>
#include <motion/MotionTypes.h>
#include <core/StreamState.h>

GuardVisionEventListenerAdapter::GuardVisionEventListenerAdapter(QObject* parent) : QObject(parent) {}

void GuardVisionEventListenerAdapter::disable() noexcept {
    callbacksEnabled_.store(false, std::memory_order_release);
}

void GuardVisionEventListenerAdapter::onStreamStatus(const guardvision::StreamStatus& status) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    emit streamStatusReceived(QString::fromStdString(status.streamId), static_cast<int>(status.state), status.acceptingFrames, status.hasPendingFrame,
                              status.processingFrame, static_cast<quint64>(status.generation), static_cast<quint64>(status.lastAcceptedSequence),
                              static_cast<qint64>(status.lastAcceptedTimestampMs));
}

void GuardVisionEventListenerAdapter::onFrameProcessed(const guardvision::FrameProcessedEvent& event) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    emit frameProcessedReceived(QString::fromStdString(event.streamId), static_cast<quint64>(event.generation), static_cast<quint64>(event.sequence),
                                static_cast<qint64>(event.timestampMs), static_cast<qint64>(event.submittedAtMs),
                                static_cast<qint64>(event.processedAtMs), static_cast<qint64>(event.queueDelayMs));
}

void GuardVisionEventListenerAdapter::onMotion(const guardvision::MotionEvent& event) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    QVector<QRect> regions;
    QVector<double> regionScores;
    QVector<double> regionAreaRatios;
    regions.reserve(static_cast<int>(event.regions.size()));
    regionScores.reserve(static_cast<int>(event.regions.size()));
    regionAreaRatios.reserve(static_cast<int>(event.regions.size()));
    for (const guardvision::MotionRegion& region : event.regions) {
        regions.append(QRect(region.bounds.x, region.bounds.y, region.bounds.width, region.bounds.height));
        regionScores.append(region.score);
        regionAreaRatios.append(region.changedAreaRatio);
    }
    emit motionReceived(QString::fromStdString(event.streamId), static_cast<int>(event.type), static_cast<int>(event.state),
                        static_cast<quint64>(event.generation), static_cast<quint64>(event.sequence), static_cast<qint64>(event.timestampMs),
                        event.score, event.changedAreaRatio, static_cast<int>(event.regions.size()), event.analysisArea.x, event.analysisArea.y,
                        event.analysisArea.width, event.analysisArea.height, regions, regionScores, regionAreaRatios);
}

void GuardVisionEventListenerAdapter::onFace(const guardvision::FaceEvent& event) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    QVector<QRect> bounds;
    QVector<quint64> trackIds;
    QVector<quint64> identityIds;
    QVector<QString> displayNames;
    QVector<double> identityConfidences;
    QVector<bool> identifiedFlags;
    bounds.reserve(static_cast<int>(event.tracks.size()));
    trackIds.reserve(static_cast<int>(event.tracks.size()));
    identityIds.reserve(static_cast<int>(event.tracks.size()));
    displayNames.reserve(static_cast<int>(event.tracks.size()));
    identityConfidences.reserve(static_cast<int>(event.tracks.size()));
    identifiedFlags.reserve(static_cast<int>(event.tracks.size()));

    for (const guardvision::FaceTrack& track : event.tracks) {
        bounds.append(QRect(track.bounds.x, track.bounds.y, track.bounds.width, track.bounds.height));
        trackIds.append(static_cast<quint64>(track.trackId));
        identityIds.append(static_cast<quint64>(track.identity.identityId));
        displayNames.append(QString::fromStdString(track.identity.displayName));
        identityConfidences.append(track.identity.confidence);
        identifiedFlags.append(track.identity.identified);
    }

    emit faceReceived(QString::fromStdString(event.streamId), static_cast<int>(event.type), static_cast<quint64>(event.generation),
                      static_cast<quint64>(event.sequence), static_cast<qint64>(event.timestampMs), bounds, trackIds, identityIds, displayNames,
                      identityConfidences, identifiedFlags);
}

void GuardVisionEventListenerAdapter::onHazard(const guardvision::HazardEvent& event) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    QVector<QRect> bounds;
    QVector<int> hazardTypes;
    QVector<double> confidences;
    bounds.reserve(static_cast<int>(event.regions.size()));
    hazardTypes.reserve(static_cast<int>(event.regions.size()));
    confidences.reserve(static_cast<int>(event.regions.size()));

    for (const guardvision::HazardRegion& region : event.regions) {
        bounds.append(QRect(region.bounds.x, region.bounds.y, region.bounds.width, region.bounds.height));
        hazardTypes.append(static_cast<int>(region.type));
        confidences.append(region.confidence);
    }

    emit hazardReceived(QString::fromStdString(event.streamId), static_cast<int>(event.type), static_cast<quint64>(event.generation),
                        static_cast<quint64>(event.sequence), static_cast<qint64>(event.timestampMs), bounds, hazardTypes, confidences);
}

void GuardVisionEventListenerAdapter::onAlarm(const guardvision::AlarmEvent& event) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    QVector<QRect> regions;
    regions.reserve(static_cast<int>(event.regions.size()));
    for (const guardvision::Rect& region : event.regions) {
        regions.append(QRect(region.x, region.y, region.width, region.height));
    }
    emit alarmReceived(QString::fromStdString(event.streamId), static_cast<quint64>(event.generation), static_cast<int>(event.type),
                       static_cast<int>(event.state), static_cast<int>(event.source), static_cast<qint64>(event.timestampMs), event.confidence,
                       regions, QString::fromStdString(event.onboardTargetId), static_cast<quint64>(event.softwareTrackId));
}

void GuardVisionEventListenerAdapter::onError(const guardvision::GuardVisionError& error) {
    if (!callbacksEnabled_.load(std::memory_order_acquire)) {
        return;
    }
    emit errorReceived(static_cast<int>(error.code), QString::fromStdString(error.message), QString::fromStdString(error.component),
                       QString::fromStdString(error.streamId));
}
