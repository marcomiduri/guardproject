#pragma once

#include <QByteArray>
#include <QImage>

#include <frame/VideoFrame.h>

struct DecodedFrame {
    QImage previewImage;
    QByteArray data;
    int width = 0;
    int height = 0;
    int stride = 0;
    guardvision::PixelFormat pixelFormat = guardvision::PixelFormat::RGB24;
    qint64 timestampMs = 0;
    quint64 sequence = 0;
    quint64 sourceGeneration = 0;
};
