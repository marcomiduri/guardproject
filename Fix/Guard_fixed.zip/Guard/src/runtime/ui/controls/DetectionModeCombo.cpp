#include "ui/controls/DetectionModeCombo.h"

#include <QComboBox>
#include <QCoreApplication>
#include <QStandardItemModel>

namespace {

struct ModeEntry {
    guardvision::DetectionMode mode;
    const char* label;
};

constexpr ModeEntry kModes[] = {
  {guardvision::DetectionMode::Disabled, QT_TRANSLATE_NOOP("DetectionModeCombo", "No detection")},
  {guardvision::DetectionMode::Software, QT_TRANSLATE_NOOP("DetectionModeCombo", "Software detection")},
  {guardvision::DetectionMode::OnboardTriggered, QT_TRANSLATE_NOOP("DetectionModeCombo", "Onboard detection")},
  {guardvision::DetectionMode::Hybrid, QT_TRANSLATE_NOOP("DetectionModeCombo", "Hybrid detection")},
};

}  // namespace

void DetectionModeCombo::populate(QComboBox* combo) {
    if (!combo) {
        return;
    }
    combo->clear();
    for (const ModeEntry& entry : kModes) {
        combo->addItem(QCoreApplication::translate("DetectionModeCombo", entry.label), static_cast<int>(entry.mode));
    }
}

void DetectionModeCombo::setMode(QComboBox* combo, guardvision::DetectionMode mode) {
    if (!combo) {
        return;
    }
    const int index = combo->findData(static_cast<int>(mode));
    if (index >= 0) {
        combo->setCurrentIndex(index);
    }
}

guardvision::DetectionMode DetectionModeCombo::currentMode(const QComboBox* combo) {
    if (!combo) {
        return guardvision::DetectionMode::Disabled;
    }
    return static_cast<guardvision::DetectionMode>(combo->currentData().toInt());
}

QString DetectionModeCombo::labelForMode(guardvision::DetectionMode mode) {
    for (const ModeEntry& entry : kModes) {
        if (entry.mode == mode) {
            return QCoreApplication::translate("DetectionModeCombo", entry.label);
        }
    }
    return QStringLiteral("Unknown");
}

void DetectionModeCombo::setOnboardAvailability(QComboBox* combo, bool onboardAvailable, const QString& unavailableReason) {
    if (!combo) {
        return;
    }
    for (int i = 0; i < combo->count(); ++i) {
        const auto mode = static_cast<guardvision::DetectionMode>(combo->itemData(i).toInt());
        if (mode == guardvision::DetectionMode::OnboardTriggered || mode == guardvision::DetectionMode::Hybrid) {
            combo->setItemData(i, onboardAvailable ? QVariant() : unavailableReason, Qt::ToolTipRole);
            const QStandardItemModel* model = qobject_cast<const QStandardItemModel*>(combo->model());
            if (model) {
                QStandardItem* item = const_cast<QStandardItemModel*>(model)->item(i);
                if (item) {
                    item->setEnabled(onboardAvailable);
                }
            }
        }
    }
    if (!onboardAvailable) {
        const guardvision::DetectionMode current = currentMode(combo);
        if (current == guardvision::DetectionMode::OnboardTriggered || current == guardvision::DetectionMode::Hybrid) {
            setMode(combo, guardvision::DetectionMode::Software);
        }
    }
}
