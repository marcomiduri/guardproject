#pragma once

#include <QComboBox>
#include <QString>

#include <core/DetectionMode.h>

class DetectionModeCombo {
public:
    static void populate(QComboBox* combo);
    static void setMode(QComboBox* combo, guardvision::DetectionMode mode);
    static guardvision::DetectionMode currentMode(const QComboBox* combo);
    static QString labelForMode(guardvision::DetectionMode mode);
    static void setOnboardAvailability(QComboBox* combo, bool onboardAvailable, const QString& unavailableReason);
};
