#pragma once

#include <QImage>
#include <QObject>
#include <QString>

#include "media/common/FrameSourceType.h"
#include "media/common/SourceConfig.h"
#include "media/common/SourceStatus.h"
#include "media/hikvision/CameraOnboardTypes.h"
#include "media/hikvision/HcNetSdkAlarmService.h"
#include "media/recording/EncodedVideoTypes.h"

class FileDecoderWorker;
class HcNetSdkFrameSource;
class QThread;
class QTimer;
class RtspDecoderWorker;

class MediaSourceController : public QObject {
    Q_OBJECT

public:
    explicit MediaSourceController(QObject* parent = nullptr);
    ~MediaSourceController() override;

    SourceConfig config() const {
        return config_;
    }
    FrameSourceType activeType() const {
        return config_.type;
    }
    SourceStatus status() const {
        return status_;
    }
    quint64 sourceGeneration() const {
        return sourceGeneration_;
    }
    quint64 nextSubmissionSequence() const {
        return nextSequence_;
    }
    qint64 nextSubmissionTimestampMs() const {
        return nextTimestampMs_;
    }
    void setSubmissionCursor(quint64 nextSequence, qint64 nextTimestampMs) {
        if (isRunning())
            return;
        nextSequence_ = nextSequence;
        nextTimestampMs_ = nextTimestampMs;
    }

    int sourceWidth() const {
        return sourceWidth_;
    }
    int sourceHeight() const {
        return sourceHeight_;
    }
    double sourceFps() const {
        return sourceFps_;
    }
    qint64 frameCount() const {
        return frameCount_;
    }
    QString sourcePath() const {
        return config_.filePath;
    }
    bool isMovie() const {
        return config_.type == FrameSourceType::VideoFile;
    }
    bool isImage() const {
        return config_.type == FrameSourceType::ImageFile;
    }
    guard::recording::EncodedStreamInfo encodedStreamInfo() const {
        return encodedStreamInfo_;
    }

    void configureFile(const QString& path);
    void configureHcNetSdk(const HcNetSdkSourceConfig& config);
    void configureRtsp(const RtspSourceConfig& config);

    void probeFile();
    void loadSource(const QString& path);
    void startPlayback();
    void stopPlayback();
    void testHcNetSdkConnection(const HcNetSdkSourceConfig& config);
    void testRtspConnection(const RtspSourceConfig& config);

    bool start(const QString& streamId, quint64* outGeneration = nullptr);
    void stop();
    bool stopAndWaitForQuiescence(int timeoutMs = 5000);
    // Final application Exit must join decoder event-loop threads before
    // QApplication begins destroying Qt globals. This deliberately does not
    // destroy the worker objects; CameraRuntimeController is retained until
    // process termination to avoid unsafe native GuardVision teardown.
    void shutdownWorkerThreadsForApplicationExit();
    bool isQuiescent() const;
    void resetForNewPlayback();
    bool isRunning() const;

signals:
    void statusChanged(int status, QString message);
    void previewFrameReady(QImage frame, quint64 generation);
    void frameReadyForSubmission(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation);
    void encodedPacketReady(guard::recording::EncodedVideoPacket packet);
    void encodedStreamInfoChanged(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void onboardCapabilitiesChanged(guard::CameraOnboardCapabilities capabilities, quint64 generation);
    void onboardCandidateReady(guard::ParsedOnboardEvent event, quint64 generation);
    void sourceMessage(QString message);
    void playbackFinished(quint64 generation);
    void decoderError(QString message);
    void connectionTestResult(bool ok, QString message);

private slots:
    void onFileSourceOpened(bool isMovie, int width, int height, double fps, qint64 frameCount, QImage firstFrame, quint64 generation);
    void onFileFrameDecoded(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation);
    void onFileEncodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void onFileEncodedPacketDecoded(guard::recording::EncodedVideoPacket packet);
    void onFilePlaybackFinished();
    void onFileDecoderError(QString message, quint64 generation);

    void onRtspStreamOpened(int width, int height, double fps, quint64 generation);
    void onRtspReconnecting(QString message, int attempt, int delayMs, quint64 generation);
    void onRtspFrameAvailable(quint64 generation);
    void onRtspEncodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void onRtspEncodedPacketReady(guard::recording::EncodedVideoPacket packet);
    void onRtspPlaybackFinished(quint64 generation);
    void onRtspDecoderError(QString message, quint64 generation);
    void onRtspConnectionTestFinished(bool ok, QString message, quint64 generation);

    void onHcCaptureStarted(quint64 generation);
    void onHcFrameAvailable(quint64 generation);
    void onHcCaptureFinished(quint64 generation);
    void onHcCaptureError(QString message, quint64 generation, bool recoverable);
    void onHcCaptureWarning(QString message, quint64 generation);
    void onHcStatusMessage(QString message);
    void onHcCapabilitiesReady(guard::CameraOnboardCapabilities capabilities, quint64 generation);
    void onHcOnboardEvent(guard::ParsedOnboardEvent event, quint64 generation);
    void onHcEncodedStreamInfo(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void onHcEncodedPacket(guard::recording::EncodedVideoPacket packet);
    void onHcConnectionSuccess(QString message, quint64 generation);
    void onHcConnectionFailure(QString message, quint64 generation);
    void checkHcWatchdog();
    void restartHcAfterBackoff();

private:
    void setStatus(SourceStatus status, const QString& message = QString());
    void ensureFileWorker();
    void ensureRtspWorker();
    void ensureHcSource();
    void shutdownWorkers();
    void invalidateGeneration();
    quint64 nextGeneration();
    QString buildRtspUrl(const RtspSourceConfig& config) const;
    int rtspShutdownWaitMs() const;
    void scheduleHcReconnect(const QString& reason);
    void resetHcReconnectState();
    int nextHcReconnectDelayMs();

    SourceConfig config_;
    SourceStatus status_ = SourceStatus::NoSource;
    quint64 sourceGeneration_ = 0;
    quint64 activeGeneration_ = 0;
    quint64 nextSequence_ = 0;
    qint64 nextTimestampMs_ = 0;
    bool playbackActive_ = false;
    bool userStopRequested_ = false;
    bool startFileAfterProbe_ = false;
    QString activeStreamId_;

    int sourceWidth_ = 0;
    int sourceHeight_ = 0;
    double sourceFps_ = 0.0;
    qint64 frameCount_ = -1;
    guard::recording::EncodedStreamInfo encodedStreamInfo_;

    QThread* fileThread_ = nullptr;
    FileDecoderWorker* fileWorker_ = nullptr;

    QThread* rtspThread_ = nullptr;
    RtspDecoderWorker* rtspWorker_ = nullptr;

    HcNetSdkFrameSource* hcSource_ = nullptr;
    QTimer* hcReconnectTimer_ = nullptr;
    QTimer* hcWatchdogTimer_ = nullptr;
    int hcReconnectAttempt_ = 0;
    qint64 lastHcFrameWallMs_ = 0;
    quint64 pendingTestGeneration_ = 0;
};
