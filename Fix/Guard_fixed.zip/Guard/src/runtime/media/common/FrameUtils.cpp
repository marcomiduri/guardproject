#include "media/common/FrameUtils.h"

#include <QRgb>

namespace GuardFrameUtils {

qint64 expectedDecodedFrameBytes(int width, int height, long frameType) {
    if (width <= 0 || height <= 0) {
        return 0;
    }

    const qint64 pixels = static_cast<qint64>(width) * static_cast<qint64>(height);
    if (frameType == 7) {
        return pixels * 4;
    }
    if (frameType == 1) {
        return pixels * 2;
    }
    if (frameType == 3 && (width % 2) == 0 && (height % 2) == 0) {
        return pixels + pixels / 2;
    }
    return 0;
}

QImage decodedFrameToQImage(const unsigned char* data, int width, int height, long frameType) {
    if (!data || width <= 0 || height <= 0) {
        return {};
    }

    if (frameType == 7) {
        QImage image(data, width, height, width * 4, QImage::Format_RGB32);
        return image.copy().convertToFormat(QImage::Format_RGB888);
    }

    if (frameType == 1) {
        QImage image(width, height, QImage::Format_RGB32);
        for (int row = 0; row < height; ++row) {
            auto* dst = reinterpret_cast<QRgb*>(image.scanLine(row));
            for (int col = 0; col < width; col += 2) {
                const int uyvyIndex = row * width * 2 + col * 2;
                const int u = data[uyvyIndex] - 128;
                const int y0 = data[uyvyIndex + 1];
                const int v = data[uyvyIndex + 2] - 128;
                const int y1 = data[uyvyIndex + 3];

                const auto toRgb = [](int y, int uValue, int vValue) {
                    const int r = qBound(0, y + ((359 * vValue) >> 8), 255);
                    const int g = qBound(0, y - ((88 * uValue + 183 * vValue) >> 8), 255);
                    const int b = qBound(0, y + ((454 * uValue) >> 8), 255);
                    return qRgb(r, g, b);
                };

                dst[col] = toRgb(y0, u, v);
                if (col + 1 < width) {
                    dst[col + 1] = toRgb(y1, u, v);
                }
            }
        }
        return image.convertToFormat(QImage::Format_RGB888);
    }

    if (frameType == 3) {
        return yv12ToQImage(data, width, height);
    }

    return {};
}

QImage yv12ToQImage(const unsigned char* data, int width, int height) {
    if (!data || width <= 0 || height <= 0) {
        return {};
    }

    QImage image(width, height, QImage::Format_RGB32);
    const uchar* yPlane = data;
    const uchar* vPlane = yPlane + width * height;
    const uchar* uPlane = vPlane + (width * height / 4);

    for (int row = 0; row < height; ++row) {
        auto* dst = reinterpret_cast<QRgb*>(image.scanLine(row));
        for (int col = 0; col < width; ++col) {
            const int y = yPlane[row * width + col];
            const int u = uPlane[(row / 2) * (width / 2) + (col / 2)] - 128;
            const int v = vPlane[(row / 2) * (width / 2) + (col / 2)] - 128;
            const int r = qBound(0, y + ((359 * v) >> 8), 255);
            const int g = qBound(0, y - ((88 * u + 183 * v) >> 8), 255);
            const int b = qBound(0, y + ((454 * u) >> 8), 255);
            dst[col] = qRgb(r, g, b);
        }
    }

    return image.convertToFormat(QImage::Format_RGB888);
}

}  // namespace GuardFrameUtils
