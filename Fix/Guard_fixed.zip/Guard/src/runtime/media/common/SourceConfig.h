#pragma once

#include <QString>

#include "media/common/FrameSourceType.h"

struct HcNetSdkSourceConfig {
    QString ip;
    int port = 8000;
    QString username;
    QString password;
    int channel = 1;
    int streamType = 0;  // 0 main, 1 sub
    int connectTimeoutMs = 5000;
    int noFrameTimeoutMs = 10000;
    int reconnectInitialDelayMs = 1000;
    int reconnectMaximumDelayMs = 30000;
};

struct RtspSourceConfig {
    QString url;
    QString username;
    QString password;
    int timeoutMs = 5000;
    int reconnectInitialDelayMs = 1000;
    int reconnectMaximumDelayMs = 30000;
};

struct SourceConfig {
    FrameSourceType type = FrameSourceType::None;
    QString filePath;
    QString safeDisplayName;
    HcNetSdkSourceConfig hcNetSdk;
    RtspSourceConfig rtsp;
};

inline QString maskRtspUrl(const QString& url) {
    const int atIndex = url.indexOf('@');
    if (atIndex <= 0) {
        return url;
    }
    const int schemeEnd = url.indexOf(QStringLiteral("://"));
    if (schemeEnd < 0) {
        return QStringLiteral("rtsp://***@") + url.mid(atIndex + 1);
    }
    return url.left(schemeEnd + 3) + QStringLiteral("***@") + url.mid(atIndex + 1);
}
