#pragma once

#include <QImage>

namespace cv {
class Mat;
}

namespace guard::media {

QImage bgrMatToRgbImage(const cv::Mat& bgr);

}  // namespace guard::media
