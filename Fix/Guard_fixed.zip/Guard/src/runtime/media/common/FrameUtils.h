#pragma once

#include <QImage>

namespace GuardFrameUtils {

qint64 expectedDecodedFrameBytes(int width, int height, long frameType);
QImage decodedFrameToQImage(const unsigned char* data, int width, int height, long frameType);
QImage yv12ToQImage(const unsigned char* data, int width, int height);

}  // namespace GuardFrameUtils
