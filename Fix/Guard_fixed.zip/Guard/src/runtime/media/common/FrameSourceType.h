#pragma once

enum class FrameSourceType { None, HcNetSdkCamera, RtspStream, VideoFile, ImageFile };

inline QString frameSourceTypeLabel(FrameSourceType type) {
    switch (type) {
        case FrameSourceType::HcNetSdkCamera:
            return QStringLiteral("HCNetSDK");
        case FrameSourceType::RtspStream:
            return QStringLiteral("RTSP");
        case FrameSourceType::VideoFile:
            return QStringLiteral("Video File");
        case FrameSourceType::ImageFile:
            return QStringLiteral("Image File");
        case FrameSourceType::None:
        default:
            return QStringLiteral("-");
    }
}
