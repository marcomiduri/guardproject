#pragma once

#include <QString>

enum class SourceStatus { NoSource, Loading, Ready, Connecting, Reconnecting, Playing, Completed, Stopped, Error };

inline QString sourceStatusLabel(SourceStatus status) {
    switch (status) {
        case SourceStatus::NoSource:
            return QStringLiteral("No source");
        case SourceStatus::Loading:
            return QStringLiteral("Loading");
        case SourceStatus::Ready:
            return QStringLiteral("Ready");
        case SourceStatus::Connecting:
            return QStringLiteral("Connecting");
        case SourceStatus::Reconnecting:
            return QStringLiteral("Reconnecting");
        case SourceStatus::Playing:
            return QStringLiteral("Playing");
        case SourceStatus::Completed:
            return QStringLiteral("Completed");
        case SourceStatus::Stopped:
            return QStringLiteral("Stopped");
        case SourceStatus::Error:
            return QStringLiteral("Error");
    }
    return QStringLiteral("Unknown");
}
