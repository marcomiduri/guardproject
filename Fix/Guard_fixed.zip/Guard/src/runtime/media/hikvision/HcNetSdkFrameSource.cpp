#include "media/hikvision/HcNetSdkFrameSource.h"

#include "media/common/FrameUtils.h"
#include "media/hikvision/HcNetSdkManager.h"

#ifdef GUARD_ENABLE_HCNETSDK
#include "media/hikvision/HikvisionSdk.h"
#endif

#include <QByteArray>
#include <QDateTime>
#include <QHash>
#include <QMetaObject>
#include <QMutex>
#include <QMutexLocker>
#include <QPointer>
#include <QSet>
#include <QThread>

#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <utility>
#include <vector>

#ifdef GUARD_ENABLE_HCNETSDK
namespace {

constexpr std::size_t kMaximumInputQueueBytes = 8u * 1024u * 1024u;
constexpr std::size_t kMaximumInputQueueChunks = 512u;
constexpr int kMaximumInputRetries = 5;
constexpr int kInputRetryDelayMs = 2;
constexpr int kInputFailuresBeforeReconnect = 100;

class ConnectionTestThread : public QThread {
public:
    HcNetSdkSourceConfig config;
    quint64 generation = 0;
    QPointer<QObject> context;
    const char* successSlot = nullptr;
    const char* failureSlot = nullptr;

    void invokeResult(const char* slot, const QString& message) {
        QObject* receiver = context.data();
        if (!receiver || !slot) {
            return;
        }
        QMetaObject::invokeMethod(receiver, slot, Qt::QueuedConnection, Q_ARG(QString, message), Q_ARG(quint64, generation));
    }

    void run() override {
        QString errorMessage;
        if (!HcNetSdkManager::acquire(&errorMessage, config.connectTimeoutMs, config.reconnectInitialDelayMs)) {
            invokeResult(failureSlot, errorMessage);
            return;
        }

        NET_DVR_USER_LOGIN_INFO loginInfo{};
        NET_DVR_DEVICEINFO_V40 deviceInfo{};
        const QByteArray ip = config.ip.toLocal8Bit();
        const QByteArray username = config.username.toLocal8Bit();
        const QByteArray password = config.password.toLocal8Bit();
        std::strncpy(loginInfo.sDeviceAddress, ip.constData(), sizeof(loginInfo.sDeviceAddress) - 1);
        std::strncpy(loginInfo.sUserName, username.constData(), sizeof(loginInfo.sUserName) - 1);
        std::strncpy(loginInfo.sPassword, password.constData(), sizeof(loginInfo.sPassword) - 1);
        loginInfo.wPort = static_cast<WORD>(config.port);
        loginInfo.bUseAsynLogin = FALSE;

        const LONG userId = NET_DVR_Login_V40(&loginInfo, &deviceInfo);
        if (userId < 0) {
            const QString message = QStringLiteral("Login failed (error %1)").arg(NET_DVR_GetLastError());
            HcNetSdkManager::release();
            invokeResult(failureSlot, message);
            return;
        }

        const QString serial = QString::fromLatin1(reinterpret_cast<const char*>(deviceInfo.struDeviceV30.sSerialNumber), 48).trimmed();
        NET_DVR_Logout(userId);
        HcNetSdkManager::release();

        const QString success = QStringLiteral("Connection OK. Device serial: %1").arg(serial.isEmpty() ? QStringLiteral("unknown") : serial);
        invokeResult(successSlot, success);
    }
};

QMutex g_playPortMapMutex;
QHash<LONG, HcNetSdkFrameSource*> g_playPortMap;

bool isRecoverableHcNetSdkError(unsigned long errorCode) {
#ifdef NET_DVR_PASSWORD_ERROR
    if (errorCode == NET_DVR_PASSWORD_ERROR) {
        return false;
    }
#endif
#ifdef NET_DVR_USERNOTEXIST
    if (errorCode == NET_DVR_USERNOTEXIST) {
        return false;
    }
#endif
#ifdef NET_DVR_PARAMETER_ERROR
    if (errorCode == NET_DVR_PARAMETER_ERROR) {
        return false;
    }
#endif
#ifdef NET_DVR_CHANNEL_ERROR
    if (errorCode == NET_DVR_CHANNEL_ERROR) {
        return false;
    }
#endif
    return true;
}

void CALLBACK decodeCallback(LONG port, char* buffer, LONG size, FRAME_INFO* frameInfo, LONG, LONG) {
    HcNetSdkFrameSource* self = nullptr;
    {
        // Acquire the decode-callback lease while the port map is locked. Once
        // closePlayStream() removes the port, no new callback can acquire a lease.
        QMutexLocker locker(&g_playPortMapMutex);
        self = g_playPortMap.value(port, nullptr);
        if (!self || !self->beginDecodeCallback()) {
            return;
        }
    }
    self->handleDecodedFrame(buffer, size, frameInfo);
    self->endDecodeCallback();
}

void CALLBACK realDataCallback(LONG, DWORD dataType, BYTE* buffer, DWORD bufferSize, void* user) {
    auto* self = static_cast<HcNetSdkFrameSource*>(user);
    if (!self || !self->beginSdkCallback()) {
        return;
    }
    self->handleRealData(dataType, buffer, bufferSize);
    self->endSdkCallback();
}

struct AnnexBInspection {
    guard::recording::VideoCodec codec = guard::recording::VideoCodec::Unknown;
    bool keyFrame = false;
    QByteArray codecConfiguration;
};

std::vector<int> startCodeOffsets(const QByteArray& data) {
    std::vector<int> offsets;
    const auto* bytes = reinterpret_cast<const unsigned char*>(data.constData());
    const int size = data.size();
    for (int index = 0; index + 3 < size; ++index) {
        if (bytes[index] == 0 && bytes[index + 1] == 0 && bytes[index + 2] == 1) {
            offsets.push_back(index);
            index += 2;
        } else if (index + 4 < size && bytes[index] == 0 && bytes[index + 1] == 0 && bytes[index + 2] == 0 && bytes[index + 3] == 1) {
            offsets.push_back(index);
            index += 3;
        }
    }
    return offsets;
}

int startCodeLength(const QByteArray& data, int offset) {
    if (offset + 3 < data.size() && static_cast<unsigned char>(data[offset + 2]) == 1) {
        return 3;
    }
    return 4;
}

AnnexBInspection inspectAnnexB(const QByteArray& data) {
    AnnexBInspection result;
    const std::vector<int> offsets = startCodeOffsets(data);
    if (offsets.empty()) {
        return result;
    }

    bool sawH264 = false;
    bool sawH265 = false;
    for (std::size_t index = 0; index < offsets.size(); ++index) {
        const int begin = offsets[index];
        const int end = index + 1 < offsets.size() ? offsets[index + 1] : data.size();
        const int payload = begin + startCodeLength(data, begin);
        if (payload >= end) {
            continue;
        }
        const unsigned char first = static_cast<unsigned char>(data[payload]);
        const int h264Type = first & 0x1f;
        const int h265Type = (first >> 1) & 0x3f;

        if (h265Type == 32 || h265Type == 33 || h265Type == 34 || h265Type == 19 || h265Type == 20 || h265Type == 21) {
            sawH265 = true;
            if (h265Type == 19 || h265Type == 20 || h265Type == 21) {
                result.keyFrame = true;
            }
            if (h265Type == 32 || h265Type == 33 || h265Type == 34) {
                result.codecConfiguration.append(data.constData() + begin, end - begin);
            }
        } else if (h264Type == 7 || h264Type == 8 || h264Type == 5 || (h264Type >= 1 && h264Type <= 12)) {
            sawH264 = true;
            if (h264Type == 5) {
                result.keyFrame = true;
            }
            if (h264Type == 7 || h264Type == 8) {
                result.codecConfiguration.append(data.constData() + begin, end - begin);
            }
        }
    }

    if (sawH265) {
        result.codec = guard::recording::VideoCodec::H265;
    } else if (sawH264) {
        result.codec = guard::recording::VideoCodec::H264;
    }
    return result;
}

}  // namespace

struct HcNetSdkFrameSource::RuntimeState {
    struct RawFrame {
        QByteArray data;
        int width = 0;
        int height = 0;
        long frameType = 0;
        quint64 sequence = 0;
        qint64 timestampMs = 0;
        quint64 generation = 0;
    };

    struct StreamChunk {
        QByteArray data;
        quint64 generation = 0;
        qint64 timestampMs = 0;
        bool systemHeader = false;
        bool standardVideo = false;
    };

    mutable QMutex sessionMutex;
    HcNetSdkSourceConfig config;
    QString streamId;
    quint64 generation = 0;
    quint64 requestedGeneration = 0;
    bool startRequestActive = false;
    quint64 sequence = 0;
    qint64 wallClockEpochMs = 0;
    qint64 lastTimestampMs = 0;
    std::chrono::steady_clock::time_point steadyEpoch;
    bool running = false;
    bool sdkAcquired = false;
    long userId = -1;
    long realHandle = -1;
    long playPort = -1;
    int decodedWidth = 0;
    int decodedHeight = 0;
    QSet<long> reportedUnsupportedFrameTypes;
    bool reportedSmallBuffer = false;
    bool routeRegistered = false;
    guard::CameraOnboardCapabilities capabilities;
    std::unique_ptr<std::thread> startupThread;
    std::unique_ptr<std::thread> teardownThread;

    std::mutex callbackMutex;
    std::condition_variable callbackCondition;
    bool acceptingCallbacks = false;
    int activeCallbacks = 0;
    int activeDecodeCallbacks = 0;

    std::mutex playApiMutex;

    std::mutex inputMutex;
    std::condition_variable inputCondition;
    std::deque<StreamChunk> inputQueue;
    std::size_t inputQueueBytes = 0;
    bool stopInput = false;
    bool inputOverflowReported = false;
    int consecutiveInputFailures = 0;
    bool reconnectSignaledForInput = false;
    std::thread inputThread;

    std::mutex conversionMutex;
    std::condition_variable conversionCondition;
    RawFrame pendingFrame;
    bool hasPendingFrame = false;
    bool stopConversion = false;
    std::thread conversionThread;

    std::mutex outputMutex;
    QImage latestImage;
    quint64 latestSequence = 0;
    qint64 latestTimestampMs = 0;
    quint64 latestGeneration = 0;
    bool outputNotificationPending = false;

    std::mutex encodedMutex;
    guard::recording::VideoCodec encodedCodec = guard::recording::VideoCodec::Unknown;
    QByteArray encodedCodecConfiguration;
    quint64 encodedPacketSequence = 0;
    bool encodedInfoPublished = false;
};
#endif

HcNetSdkFrameSource::HcNetSdkFrameSource(QObject* parent) : QObject(parent) {
#ifdef GUARD_ENABLE_HCNETSDK
    qRegisterMetaType<guard::CameraOnboardCapabilities>("guard::CameraOnboardCapabilities");
    qRegisterMetaType<guard::ParsedOnboardEvent>("guard::ParsedOnboardEvent");
    qRegisterMetaType<guard::recording::EncodedStreamInfo>("guard::recording::EncodedStreamInfo");
    qRegisterMetaType<guard::recording::EncodedVideoPacket>("guard::recording::EncodedVideoPacket");

    runtime_ = std::make_unique<RuntimeState>();
    runtime_->conversionThread = std::thread([this]() { conversionLoop(); });
    runtime_->inputThread = std::thread([this]() { playInputLoop(); });

    connect(
      &guard::HcNetSdkAlarmService::instance(), &guard::HcNetSdkAlarmService::onboardEventReceived, this,
      [this](const guard::ParsedOnboardEvent& event, long userId) { handleParsedOnboardEvent(event, userId); }, Qt::QueuedConnection);
#endif
}

HcNetSdkFrameSource::~HcNetSdkFrameSource() {
    stopCapture();
    waitForTeardown(0);
#ifdef GUARD_ENABLE_HCNETSDK
    {
        std::lock_guard<std::mutex> lock(runtime_->inputMutex);
        runtime_->stopInput = true;
        runtime_->inputQueue.clear();
        runtime_->inputQueueBytes = 0;
    }
    runtime_->inputCondition.notify_all();
    if (runtime_->inputThread.joinable()) {
        runtime_->inputThread.join();
    }

    {
        std::lock_guard<std::mutex> lock(runtime_->conversionMutex);
        runtime_->stopConversion = true;
        runtime_->hasPendingFrame = false;
    }
    runtime_->conversionCondition.notify_all();
    if (runtime_->conversionThread.joinable()) {
        runtime_->conversionThread.join();
    }
#endif
}

void HcNetSdkFrameSource::testConnection(const HcNetSdkSourceConfig& config, quint64 generation, const QObject* context, const char* successSlot,
                                         const char* failureSlot) {
#ifdef GUARD_ENABLE_HCNETSDK
    auto* thread = new ConnectionTestThread;
    thread->config = config;
    thread->generation = generation;
    thread->context = const_cast<QObject*>(context);
    thread->successSlot = successSlot;
    thread->failureSlot = failureSlot;
    connect(thread, &QThread::finished, thread, &QObject::deleteLater);
    thread->start();
#else
    Q_UNUSED(config);
    QMetaObject::invokeMethod(const_cast<QObject*>(context), failureSlot, Qt::QueuedConnection,
                              Q_ARG(QString, QStringLiteral("HCNetSDK support was not built into Guard.")), Q_ARG(quint64, generation));
#endif
}

bool HcNetSdkFrameSource::startCapture(const HcNetSdkSourceConfig& config, quint64 generation, const QString& streamId, quint64 startSequence,
                                       qint64 startTimestampMs) {
#ifdef GUARD_ENABLE_HCNETSDK
    stopCapture();
    clearPendingFrames();

    std::unique_ptr<std::thread> previousTeardown;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        previousTeardown = std::move(runtime_->teardownThread);
        runtime_->requestedGeneration = generation;
        runtime_->startRequestActive = true;
    }

    auto startup = std::make_unique<std::thread>(
      [this, config, generation, streamId, startSequence, startTimestampMs, previous = std::move(previousTeardown)]() mutable {
          performStartCapture(config, generation, streamId, startSequence, startTimestampMs, std::move(previous));
      });
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        runtime_->startupThread = std::move(startup);
    }
    return true;
#else
    Q_UNUSED(config);
    Q_UNUSED(streamId);
    Q_UNUSED(startSequence);
    Q_UNUSED(startTimestampMs);
    emit captureError(QStringLiteral("HCNetSDK support was not built into Guard."), generation, false);
    return false;
#endif
}

#ifdef GUARD_ENABLE_HCNETSDK
void HcNetSdkFrameSource::performStartCapture(HcNetSdkSourceConfig config, quint64 generation, QString streamId, quint64 startSequence,
                                              qint64 startTimestampMs, std::unique_ptr<std::thread> previousTeardown) {
    if (previousTeardown && previousTeardown->joinable()) {
        previousTeardown->join();
    }

    {
        QMutexLocker locker(&runtime_->sessionMutex);
        if (!runtime_->startRequestActive || runtime_->requestedGeneration != generation) {
            return;
        }
        runtime_->config = config;
        runtime_->streamId = streamId;
        runtime_->generation = generation;
        runtime_->sequence = startSequence;
        runtime_->wallClockEpochMs = std::max<qint64>(QDateTime::currentMSecsSinceEpoch(), startTimestampMs);
        runtime_->lastTimestampMs = runtime_->wallClockEpochMs - 1;
        runtime_->steadyEpoch = std::chrono::steady_clock::now();
        runtime_->reportedUnsupportedFrameTypes.clear();
        runtime_->reportedSmallBuffer = false;
        runtime_->decodedWidth = 0;
        runtime_->decodedHeight = 0;
        runtime_->capabilities = guard::CameraOnboardCapabilities{};
        runtime_->running = true;
        runtime_->sdkAcquired = false;
        runtime_->userId = -1;
        runtime_->realHandle = -1;
        runtime_->playPort = -1;
        runtime_->routeRegistered = false;
    }
    {
        std::lock_guard<std::mutex> lock(runtime_->callbackMutex);
        runtime_->acceptingCallbacks = true;
    }
    {
        std::lock_guard<std::mutex> lock(runtime_->inputMutex);
        runtime_->inputQueue.clear();
        runtime_->inputQueueBytes = 0;
        runtime_->inputOverflowReported = false;
        runtime_->consecutiveInputFailures = 0;
        runtime_->reconnectSignaledForInput = false;
    }
    {
        std::lock_guard<std::mutex> lock(runtime_->encodedMutex);
        runtime_->encodedCodec = guard::recording::VideoCodec::Unknown;
        runtime_->encodedCodecConfiguration.clear();
        runtime_->encodedPacketSequence = 0;
        runtime_->encodedInfoPublished = false;
    }

    QString errorMessage;
    if (!HcNetSdkManager::acquire(&errorMessage, config.connectTimeoutMs, config.reconnectInitialDelayMs)) {
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            if (runtime_->generation == generation) {
                runtime_->running = false;
            }
        }
        emit captureError(errorMessage, generation, true);
        return;
    }

    NET_DVR_USER_LOGIN_INFO loginInfo{};
    NET_DVR_DEVICEINFO_V40 deviceInfo{};
    const QByteArray ip = config.ip.toLocal8Bit();
    const QByteArray username = config.username.toLocal8Bit();
    const QByteArray password = config.password.toLocal8Bit();
    std::strncpy(loginInfo.sDeviceAddress, ip.constData(), sizeof(loginInfo.sDeviceAddress) - 1);
    std::strncpy(loginInfo.sUserName, username.constData(), sizeof(loginInfo.sUserName) - 1);
    std::strncpy(loginInfo.sPassword, password.constData(), sizeof(loginInfo.sPassword) - 1);
    loginInfo.wPort = static_cast<WORD>(config.port);
    loginInfo.bUseAsynLogin = FALSE;

    emit statusMessage(QStringLiteral("Logging in to %1:%2").arg(config.ip).arg(config.port));
    const long userId = NET_DVR_Login_V40(&loginInfo, &deviceInfo);
    if (userId < 0) {
        const unsigned long code = NET_DVR_GetLastError();
        HcNetSdkManager::release();
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            if (runtime_->generation == generation) {
                runtime_->running = false;
            }
        }
        emit captureError(sdkErrorMessage(QStringLiteral("Login failed"), code), generation, isRecoverableHcNetSdkError(code));
        return;
    }

    if (!isGenerationActive(generation)) {
        NET_DVR_Logout(userId);
        HcNetSdkManager::release();
        return;
    }

    {
        QMutexLocker locker(&runtime_->sessionMutex);
        runtime_->sdkAcquired = true;
        runtime_->userId = userId;
    }

    QString capabilityWarning;
    guard::CameraOnboardCapabilities capabilities = guard::HcNetSdkCapabilityDiscovery::discover(userId, config.channel, &capabilityWarning);
    guard::HcNetSdkAlarmService::instance().registerRoute(userId, this, streamId, generation, 0, 0);
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        runtime_->routeRegistered = true;
    }
    QString alarmError;
    const bool alarmSubscribed = guard::HcNetSdkAlarmService::instance().subscribe(userId, config.channel, &alarmError);
    capabilities.alarmSubscriptionActive = alarmSubscribed;
    capabilities.alarmSubscriptionAvailable = capabilities.alarmSubscriptionAvailable || alarmSubscribed;
    if (alarmSubscribed) {
        auto markSubscribed = [](guard::OnboardFeatureCapability& feature) {
            if (feature.state == guard::CameraCapabilityState::Unknown) {
                feature.state = guard::CameraCapabilityState::Subscribed;
            }
        };
        markSubscribed(capabilities.motion);
        markSubscribed(capabilities.face);
        markSubscribed(capabilities.fire);
        markSubscribed(capabilities.smoke);
    }
    if (!alarmSubscribed && !alarmError.isEmpty()) {
        emit captureWarning(QStringLiteral("Onboard alarm subscription is unavailable; software detection remains active. %1").arg(alarmError),
                            generation);
    }
    if (!capabilityWarning.isEmpty()) {
        emit captureWarning(capabilityWarning, generation);
    }
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        runtime_->capabilities = capabilities;
    }
    emit onboardCapabilitiesReady(capabilities, generation);

    NET_DVR_PREVIEWINFO previewInfo{};
    previewInfo.lChannel = config.channel;
    previewInfo.dwStreamType = config.streamType;
    previewInfo.hPlayWnd = nullptr;
    previewInfo.bBlocked = FALSE;

    const long realHandle = NET_DVR_RealPlay_V40(userId, &previewInfo, realDataCallback, this);
    if (realHandle < 0) {
        const unsigned long code = NET_DVR_GetLastError();
        guard::HcNetSdkAlarmService::instance().unregisterRoute(userId);
        guard::HcNetSdkAlarmService::instance().unsubscribe(userId);
        NET_DVR_Logout(userId);
        HcNetSdkManager::release();
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            if (runtime_->generation == generation) {
                runtime_->running = false;
                runtime_->sdkAcquired = false;
                runtime_->userId = -1;
                runtime_->routeRegistered = false;
            }
        }
        emit captureError(sdkErrorMessage(QStringLiteral("RealPlay failed"), code), generation, isRecoverableHcNetSdkError(code));
        return;
    }

    bool accepted = false;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        accepted = runtime_->running && runtime_->generation == generation;
        if (accepted) {
            runtime_->realHandle = realHandle;
        }
    }
    if (!accepted) {
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            if (runtime_->userId == userId) {
                runtime_->userId = -1;
                runtime_->realHandle = -1;
                runtime_->sdkAcquired = false;
                runtime_->routeRegistered = false;
            }
        }
        NET_DVR_StopRealPlay(realHandle);
        guard::HcNetSdkAlarmService::instance().unregisterRoute(userId);
        guard::HcNetSdkAlarmService::instance().unsubscribe(userId);
        NET_DVR_Logout(userId);
        HcNetSdkManager::release();
        return;
    }

    emit statusMessage(QStringLiteral("HCNetSDK preview started"));
    emit captureStarted(generation);
}
#endif

void HcNetSdkFrameSource::stopCapture() {
#ifdef GUARD_ENABLE_HCNETSDK
    quint64 generation = 0;
    std::unique_ptr<std::thread> startupThread;
    std::unique_ptr<std::thread> previousTeardown;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        generation = runtime_->generation;
        runtime_->startRequestActive = false;
        runtime_->running = false;
        startupThread = std::move(runtime_->startupThread);
        previousTeardown = std::move(runtime_->teardownThread);
    }

    {
        std::lock_guard<std::mutex> lock(runtime_->callbackMutex);
        runtime_->acceptingCallbacks = false;
    }
    {
        std::lock_guard<std::mutex> lock(runtime_->inputMutex);
        runtime_->inputQueue.clear();
        runtime_->inputQueueBytes = 0;
    }
    runtime_->inputCondition.notify_all();
    clearPendingFrames();

    if (!startupThread && !previousTeardown) {
        QMutexLocker locker(&runtime_->sessionMutex);
        if (!runtime_->sdkAcquired && runtime_->userId < 0 && runtime_->realHandle < 0 && runtime_->playPort < 0) {
            return;
        }
    }

    auto teardown =
      std::make_unique<std::thread>([this, generation, startup = std::move(startupThread), previous = std::move(previousTeardown)]() mutable {
          if (startup && startup->joinable()) {
              startup->join();
          }
          if (previous && previous->joinable()) {
              previous->join();
          }

          long userId = -1;
          long realHandle = -1;
          long playPort = -1;
          bool sdkAcquired = false;
          bool routeRegistered = false;
          {
              QMutexLocker locker(&runtime_->sessionMutex);
              userId = runtime_->userId;
              realHandle = runtime_->realHandle;
              playPort = runtime_->playPort;
              sdkAcquired = runtime_->sdkAcquired;
              routeRegistered = runtime_->routeRegistered;
              runtime_->userId = -1;
              runtime_->realHandle = -1;
              runtime_->playPort = -1;
              runtime_->sdkAcquired = false;
              runtime_->routeRegistered = false;
          }

          if (routeRegistered && userId >= 0) {
              guard::HcNetSdkAlarmService::instance().unregisterRoute(userId);
              guard::HcNetSdkAlarmService::instance().unsubscribe(userId);
          }
          if (realHandle >= 0) {
              NET_DVR_StopRealPlay(realHandle);
          }
          if (playPort >= 0) {
              {
                  QMutexLocker locker(&g_playPortMapMutex);
                  g_playPortMap.remove(playPort);
              }
              {
                  std::unique_lock<std::mutex> lock(runtime_->callbackMutex);
                  runtime_->callbackCondition.wait(lock, [this]() { return runtime_->activeCallbacks == 0 && runtime_->activeDecodeCallbacks == 0; });
              }
              std::lock_guard<std::mutex> apiLock(runtime_->playApiMutex);
              PlayM4_SetDecCallBackMend(playPort, nullptr, 0);
              PlayM4_Stop(playPort);
              PlayM4_CloseStream(playPort);
              PlayM4_FreePort(playPort);
          }
          if (userId >= 0) {
              NET_DVR_Logout(userId);
          }
          if (sdkAcquired) {
              HcNetSdkManager::release();
          }
          emit captureFinished(generation);
      });
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        runtime_->teardownThread = std::move(teardown);
    }
#endif
}

bool HcNetSdkFrameSource::waitForTeardown(int timeoutMs) {
#ifdef GUARD_ENABLE_HCNETSDK
    Q_UNUSED(timeoutMs);
    std::unique_ptr<std::thread> startup;
    std::unique_ptr<std::thread> teardown;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        startup = std::move(runtime_->startupThread);
        teardown = std::move(runtime_->teardownThread);
    }
    if (startup && startup->joinable()) {
        startup->join();
    }
    if (teardown && teardown->joinable()) {
        teardown->join();
    }
    return true;
#else
    Q_UNUSED(timeoutMs);
    return true;
#endif
}

bool HcNetSdkFrameSource::takeLatestFrame(QImage* frame, quint64* sequence, qint64* timestampMs, quint64* generation) {
#ifdef GUARD_ENABLE_HCNETSDK
    if (!frame || !sequence || !timestampMs || !generation) {
        return false;
    }

    std::lock_guard<std::mutex> lock(runtime_->outputMutex);
    if (runtime_->latestImage.isNull()) {
        runtime_->outputNotificationPending = false;
        return false;
    }

    *frame = runtime_->latestImage;
    *sequence = runtime_->latestSequence;
    *timestampMs = runtime_->latestTimestampMs;
    *generation = runtime_->latestGeneration;
    runtime_->latestImage = QImage();
    runtime_->outputNotificationPending = false;
    return true;
#else
    Q_UNUSED(frame);
    Q_UNUSED(sequence);
    Q_UNUSED(timestampMs);
    Q_UNUSED(generation);
    return false;
#endif
}

bool HcNetSdkFrameSource::beginSdkCallback() {
#ifdef GUARD_ENABLE_HCNETSDK
    std::lock_guard<std::mutex> lock(runtime_->callbackMutex);
    if (!runtime_->acceptingCallbacks) {
        return false;
    }
    ++runtime_->activeCallbacks;
    return true;
#else
    return false;
#endif
}

void HcNetSdkFrameSource::endSdkCallback() {
#ifdef GUARD_ENABLE_HCNETSDK
    std::lock_guard<std::mutex> lock(runtime_->callbackMutex);
    if (runtime_->activeCallbacks > 0) {
        --runtime_->activeCallbacks;
    }
    if (runtime_->activeCallbacks == 0 && runtime_->activeDecodeCallbacks == 0) {
        runtime_->callbackCondition.notify_all();
    }
#endif
}

bool HcNetSdkFrameSource::beginDecodeCallback() {
#ifdef GUARD_ENABLE_HCNETSDK
    std::lock_guard<std::mutex> lock(runtime_->callbackMutex);
    if (!runtime_->acceptingCallbacks) {
        return false;
    }
    ++runtime_->activeDecodeCallbacks;
    return true;
#else
    return false;
#endif
}

void HcNetSdkFrameSource::endDecodeCallback() {
#ifdef GUARD_ENABLE_HCNETSDK
    std::lock_guard<std::mutex> lock(runtime_->callbackMutex);
    if (runtime_->activeDecodeCallbacks > 0) {
        --runtime_->activeDecodeCallbacks;
    }
    if (runtime_->activeCallbacks == 0 && runtime_->activeDecodeCallbacks == 0) {
        runtime_->callbackCondition.notify_all();
    }
#endif
}

#ifdef GUARD_ENABLE_HCNETSDK
void HcNetSdkFrameSource::handleRealData(unsigned dataType, unsigned char* buffer, unsigned bufferSize) {
    if (!buffer || bufferSize == 0) {
        return;
    }

    const bool systemHeader = dataType == NET_DVR_SYSHEAD;
    bool standardVideo = false;
    if (!systemHeader && dataType != NET_DVR_STREAMDATA) {
#ifdef NET_DVR_STD_VIDEODATA
        if (dataType == NET_DVR_STD_VIDEODATA) {
            standardVideo = true;
        } else {
            return;
        }
#else
        return;
#endif
    }

    quint64 generation = 0;
    qint64 timestampMs = 0;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        if (!runtime_->running) {
            return;
        }
        generation = runtime_->generation;
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - runtime_->steadyEpoch).count();
        timestampMs = runtime_->wallClockEpochMs + static_cast<qint64>(elapsed);
    }

    QByteArray copy(reinterpret_cast<const char*>(buffer), static_cast<int>(bufferSize));

    bool overflow = false;
    {
        std::lock_guard<std::mutex> lock(runtime_->inputMutex);
        if (systemHeader) {
            // A new stream header defines the decoder session. Discard stale
            // compressed chunks so the header cannot be lost behind queue pressure.
            runtime_->inputQueue.clear();
            runtime_->inputQueueBytes = 0;
            runtime_->inputOverflowReported = false;
        }
        if (!systemHeader && (runtime_->inputQueue.size() >= kMaximumInputQueueChunks ||
                              runtime_->inputQueueBytes + static_cast<std::size_t>(copy.size()) > kMaximumInputQueueBytes)) {
            overflow = !runtime_->inputOverflowReported;
            runtime_->inputOverflowReported = true;
        } else {
            RuntimeState::StreamChunk chunk;
            chunk.data = std::move(copy);
            chunk.generation = generation;
            chunk.timestampMs = timestampMs;
            chunk.systemHeader = systemHeader;
            chunk.standardVideo = standardVideo;
            runtime_->inputQueueBytes += static_cast<std::size_t>(chunk.data.size());
            runtime_->inputQueue.push_back(std::move(chunk));
        }
    }
    if (overflow) {
        emit captureWarning(
          QStringLiteral("HCNetSDK decoder input queue overflowed; incoming stream data was dropped and reconnect may be required."), generation);
    }
    runtime_->inputCondition.notify_one();
}

bool HcNetSdkFrameSource::openPlayStream(unsigned char* sysHead, unsigned sysHeadSize) {
    if (!sysHead || sysHeadSize == 0) {
        return false;
    }

    closePlayStream();

    quint64 generation = 0;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        generation = runtime_->generation;
    }

    long newPort = -1;
    if (!PlayM4_GetPort(&newPort)) {
        emit captureError(QStringLiteral("PlayM4_GetPort failed (PlayM4 error %1)").arg(PlayM4_GetLastError(newPort)), generation, true);
        return false;
    }

    std::lock_guard<std::mutex> apiLock(runtime_->playApiMutex);
    PlayM4_SetStreamOpenMode(newPort, STREAME_REALTIME);
    if (!PlayM4_OpenStream(newPort, sysHead, sysHeadSize, 2 * 1024 * 1024)) {
        const unsigned long code = PlayM4_GetLastError(newPort);
        PlayM4_FreePort(newPort);
        emit captureError(QStringLiteral("PlayM4_OpenStream failed (PlayM4 error %1)").arg(code), generation, true);
        return false;
    }

    {
        QMutexLocker locker(&g_playPortMapMutex);
        g_playPortMap.insert(newPort, this);
    }

    PlayM4_SetDecCallBackMend(newPort, decodeCallback, 0);
    PlayM4_SetDisplayBuf(newPort, 3);
    PlayM4_SetOverlayMode(newPort, FALSE, 0);
    if (!PlayM4_Play(newPort, nullptr)) {
        const unsigned long code = PlayM4_GetLastError(newPort);
        {
            QMutexLocker locker(&g_playPortMapMutex);
            g_playPortMap.remove(newPort);
        }
        PlayM4_SetDecCallBackMend(newPort, nullptr, 0);
        PlayM4_CloseStream(newPort);
        PlayM4_FreePort(newPort);
        emit captureError(QStringLiteral("PlayM4_Play failed (PlayM4 error %1)").arg(code), generation, true);
        return false;
    }

    bool accepted = false;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        generation = runtime_->generation;
        accepted = runtime_->running;
        if (accepted) {
            runtime_->playPort = newPort;
        }
    }

    if (!accepted) {
        {
            QMutexLocker locker(&g_playPortMapMutex);
            g_playPortMap.remove(newPort);
        }
        PlayM4_SetDecCallBackMend(newPort, nullptr, 0);
        PlayM4_Stop(newPort);
        PlayM4_CloseStream(newPort);
        PlayM4_FreePort(newPort);
        return false;
    }

    runtime_->inputCondition.notify_all();
    return true;
}

void HcNetSdkFrameSource::handleDecodedFrame(char* buffer, long size, void* frameInfoPtr) {
    auto* frameInfo = static_cast<FRAME_INFO*>(frameInfoPtr);
    if (!buffer || !frameInfo || frameInfo->nWidth <= 0 || frameInfo->nHeight <= 0) {
        return;
    }

    const qint64 expectedBytes = GuardFrameUtils::expectedDecodedFrameBytes(frameInfo->nWidth, frameInfo->nHeight, frameInfo->nType);
    if (expectedBytes <= 0) {
        bool shouldReport = false;
        quint64 generation = 0;
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            generation = runtime_->generation;
            if (!runtime_->reportedUnsupportedFrameTypes.contains(frameInfo->nType)) {
                runtime_->reportedUnsupportedFrameTypes.insert(frameInfo->nType);
                shouldReport = true;
            }
        }
        if (shouldReport) {
            emit captureWarning(QStringLiteral("Unsupported PlayM4 decoded frame type: %1").arg(frameInfo->nType), generation);
        }
        return;
    }
    if (size < expectedBytes) {
        bool shouldReport = false;
        quint64 generation = 0;
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            generation = runtime_->generation;
            if (!runtime_->reportedSmallBuffer) {
                runtime_->reportedSmallBuffer = true;
                shouldReport = true;
            }
        }
        if (shouldReport) {
            emit captureWarning(QStringLiteral("PlayM4 decoded frame buffer is smaller than expected (%1 < %2 bytes).").arg(size).arg(expectedBytes),
                                generation);
        }
        return;
    }

    RuntimeState::RawFrame rawFrame;
    bool dimensionsChanged = false;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        if (!runtime_->running) {
            return;
        }
        rawFrame.width = frameInfo->nWidth;
        rawFrame.height = frameInfo->nHeight;
        rawFrame.frameType = frameInfo->nType;
        rawFrame.sequence = runtime_->sequence++;
        rawFrame.generation = runtime_->generation;
        const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - runtime_->steadyEpoch).count();
        const qint64 measuredTimestampMs = runtime_->wallClockEpochMs + static_cast<qint64>(elapsed);
        rawFrame.timestampMs = measuredTimestampMs > runtime_->lastTimestampMs ? measuredTimestampMs : runtime_->lastTimestampMs + 1;
        runtime_->lastTimestampMs = rawFrame.timestampMs;
        dimensionsChanged = runtime_->decodedWidth != frameInfo->nWidth || runtime_->decodedHeight != frameInfo->nHeight;
        runtime_->decodedWidth = frameInfo->nWidth;
        runtime_->decodedHeight = frameInfo->nHeight;
    }

    if (dimensionsChanged) {
        updateAlarmRouteFrameSize(frameInfo->nWidth, frameInfo->nHeight, rawFrame.generation);
        std::lock_guard<std::mutex> lock(runtime_->encodedMutex);
        runtime_->encodedInfoPublished = false;
    }

    rawFrame.data = QByteArray(buffer, static_cast<int>(expectedBytes));
    {
        std::lock_guard<std::mutex> lock(runtime_->conversionMutex);
        runtime_->pendingFrame = std::move(rawFrame);
        runtime_->hasPendingFrame = true;
    }
    runtime_->conversionCondition.notify_one();
}

void HcNetSdkFrameSource::playInputLoop() {
    for (;;) {
        RuntimeState::StreamChunk chunk;
        {
            std::unique_lock<std::mutex> lock(runtime_->inputMutex);
            runtime_->inputCondition.wait(lock, [this]() { return runtime_->stopInput || !runtime_->inputQueue.empty(); });
            if (runtime_->stopInput) {
                return;
            }
            chunk = std::move(runtime_->inputQueue.front());
            runtime_->inputQueue.pop_front();
            runtime_->inputQueueBytes -= (std::min)(runtime_->inputQueueBytes, static_cast<std::size_t>(chunk.data.size()));
            if (runtime_->inputQueue.size() < kMaximumInputQueueChunks / 2 && runtime_->inputQueueBytes < kMaximumInputQueueBytes / 2) {
                runtime_->inputOverflowReported = false;
            }
        }

        if (chunk.systemHeader) {
            if (isGenerationActive(chunk.generation)) {
                openPlayStream(reinterpret_cast<unsigned char*>(chunk.data.data()), static_cast<unsigned>(chunk.data.size()));
            }
            continue;
        }

        if (chunk.standardVideo) {
            handleStandardEncodedData(chunk.data, chunk.generation, chunk.timestampMs);
        }

        long playPort = -1;
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            if (!runtime_->running || runtime_->generation != chunk.generation || runtime_->playPort < 0) {
                continue;
            }
            playPort = runtime_->playPort;
        }

        bool accepted = false;
        unsigned long playError = 0;
        for (int attempt = 0; attempt < kMaximumInputRetries; ++attempt) {
            {
                std::lock_guard<std::mutex> apiLock(runtime_->playApiMutex);
                QMutexLocker locker(&runtime_->sessionMutex);
                if (!runtime_->running || runtime_->generation != chunk.generation || runtime_->playPort != playPort) {
                    break;
                }
                locker.unlock();
                accepted = PlayM4_InputData(playPort, reinterpret_cast<BYTE*>(chunk.data.data()), static_cast<DWORD>(chunk.data.size())) != FALSE;
                if (!accepted) {
                    playError = PlayM4_GetLastError(playPort);
                }
            }
            if (accepted) {
                break;
            }
            QThread::msleep(kInputRetryDelayMs);
        }

        if (accepted) {
            std::lock_guard<std::mutex> lock(runtime_->inputMutex);
            runtime_->consecutiveInputFailures = 0;
            runtime_->reconnectSignaledForInput = false;
            continue;
        }

        bool shouldWarn = false;
        bool shouldReconnect = false;
        {
            std::lock_guard<std::mutex> lock(runtime_->inputMutex);
            ++runtime_->consecutiveInputFailures;
            shouldWarn = runtime_->consecutiveInputFailures == 1 || runtime_->consecutiveInputFailures % 25 == 0;
            if (runtime_->consecutiveInputFailures >= kInputFailuresBeforeReconnect && !runtime_->reconnectSignaledForInput) {
                runtime_->reconnectSignaledForInput = true;
                shouldReconnect = true;
            }
        }
        if (shouldWarn) {
            emit captureWarning(QStringLiteral("PlayM4_InputData is rejecting stream data (error %1).").arg(playError), chunk.generation);
        }
        if (shouldReconnect) {
            emit captureError(QStringLiteral("PlayM4 input remained blocked; reconnecting the camera stream."), chunk.generation, true);
        }
    }
}

void HcNetSdkFrameSource::closePlayStream() {
    long playPort = -1;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        playPort = runtime_->playPort;
        runtime_->playPort = -1;
    }
    if (playPort < 0) {
        return;
    }
    {
        QMutexLocker locker(&g_playPortMapMutex);
        g_playPortMap.remove(playPort);
    }
    {
        std::unique_lock<std::mutex> lock(runtime_->callbackMutex);
        runtime_->callbackCondition.wait(lock, [this]() { return runtime_->activeDecodeCallbacks == 0; });
    }
    std::lock_guard<std::mutex> apiLock(runtime_->playApiMutex);
    PlayM4_SetDecCallBackMend(playPort, nullptr, 0);
    PlayM4_Stop(playPort);
    PlayM4_CloseStream(playPort);
    PlayM4_FreePort(playPort);
}

QString HcNetSdkFrameSource::sdkErrorMessage(const QString& prefix, unsigned long errorCode) const {
    return QStringLiteral("%1 (HCNetSDK error %2)").arg(prefix).arg(errorCode);
}

void HcNetSdkFrameSource::conversionLoop() {
    for (;;) {
        RuntimeState::RawFrame rawFrame;
        {
            std::unique_lock<std::mutex> lock(runtime_->conversionMutex);
            runtime_->conversionCondition.wait(lock, [this]() { return runtime_->stopConversion || runtime_->hasPendingFrame; });
            if (runtime_->stopConversion) {
                return;
            }
            rawFrame = std::move(runtime_->pendingFrame);
            runtime_->hasPendingFrame = false;
        }

        QImage image = GuardFrameUtils::decodedFrameToQImage(reinterpret_cast<const unsigned char*>(rawFrame.data.constData()), rawFrame.width,
                                                             rawFrame.height, rawFrame.frameType);
        if (image.isNull() || !isGenerationActive(rawFrame.generation)) {
            continue;
        }

        bool shouldNotify = false;
        {
            std::lock_guard<std::mutex> lock(runtime_->outputMutex);
            runtime_->latestImage = std::move(image);
            runtime_->latestSequence = rawFrame.sequence;
            runtime_->latestTimestampMs = rawFrame.timestampMs;
            runtime_->latestGeneration = rawFrame.generation;
            if (!runtime_->outputNotificationPending) {
                runtime_->outputNotificationPending = true;
                shouldNotify = true;
            }
        }
        if (shouldNotify) {
            emit frameAvailable(rawFrame.generation);
        }
    }
}

void HcNetSdkFrameSource::clearPendingFrames() {
    {
        std::lock_guard<std::mutex> lock(runtime_->conversionMutex);
        runtime_->pendingFrame = RuntimeState::RawFrame{};
        runtime_->hasPendingFrame = false;
    }
    {
        std::lock_guard<std::mutex> lock(runtime_->outputMutex);
        runtime_->latestImage = QImage();
        runtime_->latestSequence = 0;
        runtime_->latestTimestampMs = 0;
        runtime_->latestGeneration = 0;
        runtime_->outputNotificationPending = false;
    }
}

bool HcNetSdkFrameSource::isGenerationActive(quint64 generation) const {
    QMutexLocker locker(&runtime_->sessionMutex);
    return runtime_->running && runtime_->generation == generation;
}

void HcNetSdkFrameSource::handleStandardEncodedData(const QByteArray& data, quint64 generation, qint64 timestampMs) {
    const AnnexBInspection inspection = inspectAnnexB(data);
    guard::recording::EncodedStreamInfo streamInfo;
    guard::recording::EncodedVideoPacket packet;
    bool emitInfo = false;
    bool emitPacket = false;
    {
        std::lock_guard<std::mutex> lock(runtime_->encodedMutex);
        if (inspection.codec != guard::recording::VideoCodec::Unknown) {
            runtime_->encodedCodec = inspection.codec;
        }
        if (!inspection.codecConfiguration.isEmpty()) {
            runtime_->encodedCodecConfiguration = inspection.codecConfiguration;
            runtime_->encodedInfoPublished = false;
        }

        int width = 0;
        int height = 0;
        {
            QMutexLocker locker(&runtime_->sessionMutex);
            width = runtime_->decodedWidth;
            height = runtime_->decodedHeight;
        }
        if (!runtime_->encodedInfoPublished && runtime_->encodedCodec != guard::recording::VideoCodec::Unknown && width > 0 && height > 0 &&
            !runtime_->encodedCodecConfiguration.isEmpty()) {
            streamInfo.codec = runtime_->encodedCodec;
            streamInfo.width = width;
            streamInfo.height = height;
            streamInfo.timeBaseNumerator = 1;
            streamInfo.timeBaseDenominator = 1000;
            streamInfo.codecExtraData = runtime_->encodedCodecConfiguration;
            streamInfo.mp4RemuxCompatible = true;
            runtime_->encodedInfoPublished = true;
            emitInfo = true;
        }

        if (runtime_->encodedCodec != guard::recording::VideoCodec::Unknown) {
            packet.generation = generation;
            packet.packetSequence = runtime_->encodedPacketSequence++;
            packet.data = data;
            packet.pts = timestampMs;
            packet.dts = timestampMs;
            packet.duration = 0;
            packet.timeBaseNumerator = 1;
            packet.timeBaseDenominator = 1000;
            packet.playbackTimestampMs = timestampMs;
            packet.hasPts = true;
            packet.hasDts = true;
            packet.keyFrame = inspection.keyFrame;
            emitPacket = packet.isValid();
        }
    }
    if (emitInfo) {
        emit encodedStreamInfoReady(streamInfo, generation);
    }
    if (emitPacket) {
        emit encodedPacketReady(std::move(packet));
    }
}

void HcNetSdkFrameSource::updateAlarmRouteFrameSize(int width, int height, quint64 generation) {
    long userId = -1;
    QString streamId;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        if (!runtime_->running || runtime_->generation != generation || !runtime_->routeRegistered) {
            return;
        }
        userId = runtime_->userId;
        streamId = runtime_->streamId;
    }
    if (userId >= 0) {
        guard::HcNetSdkAlarmService::instance().registerRoute(userId, this, streamId, generation, width, height);
    }
}

void HcNetSdkFrameSource::handleParsedOnboardEvent(const guard::ParsedOnboardEvent& event, long userId) {
    quint64 generation = 0;
    bool capabilityChanged = false;
    guard::CameraOnboardCapabilities capabilities;
    {
        QMutexLocker locker(&runtime_->sessionMutex);
        if (!runtime_->running || runtime_->userId != userId || runtime_->generation != event.candidate.generation) {
            return;
        }
        generation = runtime_->generation;
        capabilities = runtime_->capabilities;

        guard::OnboardFeatureCapability* feature = nullptr;
        switch (event.candidate.type) {
            case guardvision::CandidateType::Motion:
                feature = &capabilities.motion;
                break;
            case guardvision::CandidateType::Face:
                feature = &capabilities.face;
                break;
            case guardvision::CandidateType::Fire:
                feature = &capabilities.fire;
                break;
            case guardvision::CandidateType::Smoke:
                feature = &capabilities.smoke;
                break;
        }
        if (feature && feature->state != guard::CameraCapabilityState::Verified) {
            feature->state = guard::CameraCapabilityState::Verified;
            runtime_->capabilities = capabilities;
            capabilityChanged = true;
        }
    }
    if (capabilityChanged) {
        emit onboardCapabilitiesReady(capabilities, generation);
    }
    emit onboardEventReady(event, generation);
}
#endif
