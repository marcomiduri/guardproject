#pragma once

#include <QByteArray>
#include <QMetaType>
#include <QObject>
#include <QString>

#include <cstdint>

#include <onboard/OnboardTypes.h>

#include "media/hikvision/CameraOnboardTypes.h"

namespace guard {

struct ParsedOnboardEvent {
    guardvision::OnboardCandidate candidate;
    QString logMessage;
    bool verifiedFeature = false;
};

class OnboardCandidateParser {
public:
    static bool parseAlarmCommand(int command, const QByteArray& alarmData, const QString& streamId, std::uint64_t generation,
                                  std::int64_t timestampMs, int mainStreamWidth, int mainStreamHeight, ParsedOnboardEvent& output);
};

class HcNetSdkCapabilityDiscovery {
public:
    static CameraOnboardCapabilities discover(long userId, int channel, QString* errorMessage);
    static QString formatSummary(const CameraOnboardCapabilities& capabilities);
};

class HcNetSdkAlarmService : public QObject {
    Q_OBJECT

public:
    static HcNetSdkAlarmService& instance();

    bool ensureCallbackInstalled(QString* errorMessage);
    bool subscribe(long userId, int channel, QString* errorMessage);
    void unsubscribe(long userId);
    void shutdown();

    void registerRoute(long userId, QObject* owner, const QString& streamId, std::uint64_t generation, int mainStreamWidth, int mainStreamHeight);
    void unregisterRoute(long userId);

public slots:
    void handleAlarmMessage(int command, long userId, QByteArray alarmCopy);

signals:
    void onboardEventReceived(guard::ParsedOnboardEvent event, long userId);

private:
    explicit HcNetSdkAlarmService(QObject* parent = nullptr);
};

}  // namespace guard

Q_DECLARE_METATYPE(guard::ParsedOnboardEvent)
