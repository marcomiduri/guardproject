#pragma once

#include <QString>

class HcNetSdkManager {
public:
    static bool acquire(QString* errorMessage = nullptr, int connectTimeoutMs = 2000, int reconnectIntervalMs = 10000);
    static void release();
    static bool isInitialized();

private:
    static int refCount_;
};
