#pragma once

#include <string>
#include <QMetaType>

namespace guard {

enum class CameraCapabilityState { Unknown, Unsupported, SupportedDisabled, SupportedEnabled, Subscribed, Verified };

struct OnboardFeatureCapability {
    CameraCapabilityState state = CameraCapabilityState::Unknown;
    bool providesRegion = false;
    bool providesConfidence = false;
    bool providesTargetId = false;
    bool providesTimestamp = false;
    bool normalizedCoordinates = false;
    bool referencePixelCoordinates = false;
    int referenceWidth = 0;
    int referenceHeight = 0;
    std::string detail;
};

struct CameraOnboardCapabilities {
    OnboardFeatureCapability motion;
    OnboardFeatureCapability face;
    OnboardFeatureCapability fire;
    OnboardFeatureCapability smoke;
    bool alarmSubscriptionAvailable = false;
    bool alarmSubscriptionActive = false;
};

const char* toString(CameraCapabilityState state) noexcept;

}  // namespace guard

Q_DECLARE_METATYPE(guard::CameraOnboardCapabilities)
