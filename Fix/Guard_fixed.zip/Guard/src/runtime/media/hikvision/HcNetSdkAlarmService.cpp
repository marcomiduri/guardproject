#include "media/hikvision/HcNetSdkAlarmService.h"

#include <QDateTime>
#include <QHash>
#include <QMetaObject>
#include <QMutex>
#include <QMutexLocker>
#include <QPointer>

#ifdef GUARD_ENABLE_HCNETSDK
#include "media/hikvision/HikvisionSdk.h"
#endif

namespace guard {

struct AlarmRoute {
    QPointer<QObject> owner;
    QString streamId;
    std::uint64_t generation = 0;
    int mainStreamWidth = 0;
    int mainStreamHeight = 0;
};

}  // namespace guard

#ifdef GUARD_ENABLE_HCNETSDK
namespace {

constexpr DWORD kMaxAlarmCopyBytes = 64 * 1024;

QMutex g_alarmMutex;
QHash<LONG, guard::AlarmRoute> g_routesByUserId;
QHash<LONG, LONG> g_alarmHandlesByUserId;
bool g_callbackInstalled = false;

BOOL CALLBACK alarmMessageCallback_V31(LONG command, NET_DVR_ALARMER* alarmer, char* alarmInfo, DWORD alarmInfoSize, void*) {
    if (!alarmer || !alarmInfo || alarmInfoSize == 0) {
        return TRUE;
    }

    {
        QMutexLocker locker(&g_alarmMutex);
        if (!g_routesByUserId.contains(alarmer->lUserID)) {
            return TRUE;
        }
    }

    const DWORD copySize = qMin(alarmInfoSize, kMaxAlarmCopyBytes);
    const QByteArray alarmCopy(alarmInfo, static_cast<int>(copySize));
    QMetaObject::invokeMethod(&guard::HcNetSdkAlarmService::instance(), "handleAlarmMessage", Qt::QueuedConnection,
                              Q_ARG(int, static_cast<int>(command)), Q_ARG(long, alarmer->lUserID), Q_ARG(QByteArray, alarmCopy));
    return TRUE;
}

guardvision::NormalizedRect rectFromVca(float x, float y, float width, float height) {
    guardvision::NormalizedRect rect;
    rect.x = static_cast<double>(x);
    rect.y = static_cast<double>(y);
    rect.width = static_cast<double>(width);
    rect.height = static_cast<double>(height);
    if (!rect.isValid()) {
        return {};
    }
    return rect;
}

}  // namespace
#endif

namespace guard {

bool OnboardCandidateParser::parseAlarmCommand(int command, const QByteArray& alarmData, const QString& streamId, std::uint64_t generation,
                                               std::int64_t timestampMs, int mainStreamWidth, int mainStreamHeight, ParsedOnboardEvent& output) {
#ifdef GUARD_ENABLE_HCNETSDK
    output = ParsedOnboardEvent{};
    output.candidate.streamId = streamId.toStdString();
    output.candidate.generation = generation;
    output.candidate.timestampMs = timestampMs;

    switch (command) {
#ifdef COMM_ALARM_FACE_DETECTION
        case COMM_ALARM_FACE_DETECTION: {
            if (alarmData.size() < static_cast<int>(sizeof(NET_DVR_FACE_DETECTION))) {
                return false;
            }
            const auto* detection = reinterpret_cast<const NET_DVR_FACE_DETECTION*>(alarmData.constData());
            if (detection->byFacePicNum == 0) {
                return false;
            }
            output.candidate.type = guardvision::CandidateType::Face;
            guardvision::OnboardCandidateRegion region;
            region.coordinateSpace = guardvision::CandidateCoordinateSpace::Normalized;
            region.normalizedBounds = rectFromVca(detection->struFacePic[0].fX, detection->struFacePic[0].fY, detection->struFacePic[0].fWidth,
                                                  detection->struFacePic[0].fHeight);
            if (!region.normalizedBounds.isValid()) {
                return false;
            }
            output.candidate.regions.push_back(region);
            output.candidate.targetId = QString::number(detection->struDevInfo.byChannel).toStdString();
            output.logMessage = QStringLiteral("Onboard face candidate received");
            output.verifiedFeature = true;
            return true;
        }
#endif
#ifdef COMM_UPLOAD_FACESNAP_RESULT
        case COMM_UPLOAD_FACESNAP_RESULT: {
            if (alarmData.size() < static_cast<int>(sizeof(NET_VCA_FACESNAP_RESULT))) {
                return false;
            }
            const auto* result = reinterpret_cast<const NET_VCA_FACESNAP_RESULT*>(alarmData.constData());
            output.candidate.type = guardvision::CandidateType::Face;
            guardvision::OnboardCandidateRegion region;
            region.coordinateSpace = guardvision::CandidateCoordinateSpace::Normalized;
            region.normalizedBounds = rectFromVca(result->struRect.fX, result->struRect.fY, result->struRect.fWidth, result->struRect.fHeight);
            if (!region.normalizedBounds.isValid()) {
                region.normalizedBounds = rectFromVca(result->struTargetInfo.struRect.fX, result->struTargetInfo.struRect.fY,
                                                      result->struTargetInfo.struRect.fWidth, result->struTargetInfo.struRect.fHeight);
            }
            if (!region.normalizedBounds.isValid()) {
                return false;
            }
            output.candidate.regions.push_back(region);
            output.candidate.targetId = QString::number(result->struTargetInfo.dwID).toStdString();
            output.logMessage = QStringLiteral("Onboard face candidate received");
            output.verifiedFeature = true;
            return true;
        }
#endif
#ifdef COMM_FIREDETECTION_ALARM
        case COMM_FIREDETECTION_ALARM: {
            if (alarmData.size() < static_cast<int>(sizeof(NET_DVR_FIREDETECTION_ALARM))) {
                return false;
            }
            const auto* alarm = reinterpret_cast<const NET_DVR_FIREDETECTION_ALARM*>(alarmData.constData());
            output.candidate.type = alarm->byAlarmSubType == 1 ? guardvision::CandidateType::Smoke : guardvision::CandidateType::Fire;
            guardvision::OnboardCandidateRegion region;
            region.coordinateSpace = guardvision::CandidateCoordinateSpace::Normalized;
            region.normalizedBounds = rectFromVca(alarm->struRect.fX, alarm->struRect.fY, alarm->struRect.fWidth, alarm->struRect.fHeight);
            if (!region.normalizedBounds.isValid()) {
                return false;
            }
            if (mainStreamWidth > 0 && mainStreamHeight > 0) {
                region.referenceWidth = mainStreamWidth;
                region.referenceHeight = mainStreamHeight;
            }
            output.candidate.regions.push_back(region);
            output.candidate.confidence = 1.0;
            output.logMessage = output.candidate.type == guardvision::CandidateType::Smoke ? QStringLiteral("Onboard smoke candidate received")
                                                                                           : QStringLiteral("Onboard fire candidate received");
            output.verifiedFeature = true;
            return true;
        }
#endif
#ifdef COMM_ALARM_V30
        case COMM_ALARM_V30: {
            if (alarmData.size() < static_cast<int>(sizeof(NET_DVR_ALARMINFO_V30))) {
                return false;
            }
            const auto* alarm = reinterpret_cast<const NET_DVR_ALARMINFO_V30*>(alarmData.constData());
            // HCNetSDK legacy alarm type 3 is motion detection. Other V30
            // alarm types (video loss, disk, tamper, input alarm, etc.) must
            // not be misclassified as motion.
            if (alarm->dwAlarmType != 3) {
                return false;
            }
            output.candidate.type = guardvision::CandidateType::Motion;
            guardvision::OnboardCandidateRegion region;
            region.coordinateSpace = guardvision::CandidateCoordinateSpace::Normalized;
            // Legacy motion alarms do not carry an object rectangle. Use the
            // full decoded frame only as the software-confirmation search ROI;
            // GuardVision emits the confirmed software motion regions.
            region.normalizedBounds = guardvision::NormalizedRect{0.0, 0.0, 1.0, 1.0};
            output.candidate.regions.push_back(region);
            output.logMessage = QStringLiteral("Onboard motion candidate received");
            output.verifiedFeature = true;
            return true;
        }
#endif
        default:
            break;
    }
#else
    Q_UNUSED(command);
    Q_UNUSED(alarmData);
    Q_UNUSED(streamId);
    Q_UNUSED(generation);
    Q_UNUSED(timestampMs);
    Q_UNUSED(mainStreamWidth);
    Q_UNUSED(mainStreamHeight);
#endif
    return false;
}

CameraOnboardCapabilities HcNetSdkCapabilityDiscovery::discover(long userId, int channel, QString* errorMessage) {
    Q_UNUSED(userId);
    Q_UNUSED(channel);
    CameraOnboardCapabilities capabilities;
#ifdef GUARD_ENABLE_HCNETSDK
    capabilities.alarmSubscriptionAvailable = true;
    capabilities.motion.state = CameraCapabilityState::Unknown;
    capabilities.motion.providesRegion = false;
    capabilities.motion.normalizedCoordinates = true;
    capabilities.face.state = CameraCapabilityState::Unknown;
    capabilities.face.providesRegion = true;
    capabilities.face.providesTargetId = true;
    capabilities.face.normalizedCoordinates = true;
    capabilities.fire.state = CameraCapabilityState::Unknown;
    capabilities.fire.providesRegion = true;
    capabilities.fire.normalizedCoordinates = true;
    capabilities.smoke.state = CameraCapabilityState::Unknown;
    capabilities.smoke.providesRegion = true;
    capabilities.smoke.normalizedCoordinates = true;
    if (errorMessage) {
        *errorMessage = QStringLiteral("HCNetSDK alarm capability details will be verified from subscribed events for this device/channel.");
    }
#else
    if (errorMessage) {
        *errorMessage = QStringLiteral("HCNetSDK support was not built into Guard.");
    }
#endif
    return capabilities;
}

QString HcNetSdkCapabilityDiscovery::formatSummary(const CameraOnboardCapabilities& capabilities) {
    return QStringLiteral("Alarm channel: %1\nMotion event: %2\nFace event: %3\nFire event: %4\nSmoke event: %5")
      .arg(capabilities.alarmSubscriptionActive
             ? QStringLiteral("Subscribed")
             : (capabilities.alarmSubscriptionAvailable ? QStringLiteral("Available") : QStringLiteral("Unsupported")))
      .arg(QString::fromUtf8(toString(capabilities.motion.state)))
      .arg(QString::fromUtf8(toString(capabilities.face.state)))
      .arg(QString::fromUtf8(toString(capabilities.fire.state)))
      .arg(QString::fromUtf8(toString(capabilities.smoke.state)));
}

HcNetSdkAlarmService& HcNetSdkAlarmService::instance() {
    static HcNetSdkAlarmService service;
    return service;
}

HcNetSdkAlarmService::HcNetSdkAlarmService(QObject* parent) : QObject(parent) {}

bool HcNetSdkAlarmService::ensureCallbackInstalled(QString* errorMessage) {
#ifdef GUARD_ENABLE_HCNETSDK
    QMutexLocker locker(&g_alarmMutex);
    // HCNetSDK clears process-global callbacks when NET_DVR_Cleanup is called.
    // Reinstalling here is cheap and makes reconnect/reinitialization reliable.
    if (!NET_DVR_SetDVRMessageCallBack_V31(alarmMessageCallback_V31, nullptr)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NET_DVR_SetDVRMessageCallBack_V31 failed (%1)").arg(NET_DVR_GetLastError());
        }
        g_callbackInstalled = false;
        return false;
    }
    g_callbackInstalled = true;
    return true;
#else
    if (errorMessage) {
        *errorMessage = QStringLiteral("HCNetSDK support was not built into Guard.");
    }
    return false;
#endif
}

bool HcNetSdkAlarmService::subscribe(long userId, int channel, QString* errorMessage) {
#ifdef GUARD_ENABLE_HCNETSDK
    if (!ensureCallbackInstalled(errorMessage)) {
        return false;
    }
    unsubscribe(userId);
    NET_DVR_SETUPALARM_PARAM param{};
    param.dwSize = sizeof(param);
    param.byLevel = 1;
    param.byAlarmInfoType = 1;
    const LONG handle = NET_DVR_SetupAlarmChan_V41(userId, &param);
    if (handle < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NET_DVR_SetupAlarmChan_V41 failed (%1)").arg(NET_DVR_GetLastError());
        }
        return false;
    }
    {
        QMutexLocker locker(&g_alarmMutex);
        g_alarmHandlesByUserId.insert(userId, handle);
    }
    Q_UNUSED(channel);
    if (errorMessage) {
        errorMessage->clear();
    }
    return true;
#else
    Q_UNUSED(userId);
    Q_UNUSED(channel);
    if (errorMessage) {
        *errorMessage = QStringLiteral("HCNetSDK support was not built into Guard.");
    }
    return false;
#endif
}

void HcNetSdkAlarmService::unsubscribe(long userId) {
#ifdef GUARD_ENABLE_HCNETSDK
    LONG handle = -1;
    {
        QMutexLocker locker(&g_alarmMutex);
        handle = g_alarmHandlesByUserId.take(userId);
    }
    if (handle >= 0) {
        NET_DVR_CloseAlarmChan_V30(handle);
    }
#else
    Q_UNUSED(userId);
#endif
}

void HcNetSdkAlarmService::shutdown() {
#ifdef GUARD_ENABLE_HCNETSDK
    QList<LONG> handles;
    {
        QMutexLocker locker(&g_alarmMutex);
        handles = g_alarmHandlesByUserId.values();
        g_alarmHandlesByUserId.clear();
        g_routesByUserId.clear();
    }
    for (LONG handle : handles) {
        if (handle >= 0) {
            NET_DVR_CloseAlarmChan_V30(handle);
        }
    }
#endif
}

void HcNetSdkAlarmService::registerRoute(long userId, QObject* owner, const QString& streamId, std::uint64_t generation, int mainStreamWidth,
                                         int mainStreamHeight) {
#ifdef GUARD_ENABLE_HCNETSDK
    QMutexLocker locker(&g_alarmMutex);
    AlarmRoute route;
    route.owner = owner;
    route.streamId = streamId;
    route.generation = generation;
    route.mainStreamWidth = mainStreamWidth;
    route.mainStreamHeight = mainStreamHeight;
    g_routesByUserId.insert(userId, route);
#else
    Q_UNUSED(userId);
    Q_UNUSED(owner);
    Q_UNUSED(streamId);
    Q_UNUSED(generation);
    Q_UNUSED(mainStreamWidth);
    Q_UNUSED(mainStreamHeight);
#endif
}

void HcNetSdkAlarmService::unregisterRoute(long userId) {
#ifdef GUARD_ENABLE_HCNETSDK
    QMutexLocker locker(&g_alarmMutex);
    g_routesByUserId.remove(userId);
#else
    Q_UNUSED(userId);
#endif
}

void HcNetSdkAlarmService::handleAlarmMessage(int command, long userId, QByteArray alarmCopy) {
#ifdef GUARD_ENABLE_HCNETSDK
    AlarmRoute route;
    {
        QMutexLocker locker(&g_alarmMutex);
        route = g_routesByUserId.value(userId);
    }
    if (!route.owner) {
        return;
    }

    ParsedOnboardEvent parsed;
    const std::int64_t timestampMs = QDateTime::currentMSecsSinceEpoch();
    if (!OnboardCandidateParser::parseAlarmCommand(command, alarmCopy, route.streamId, route.generation, timestampMs, route.mainStreamWidth,
                                                   route.mainStreamHeight, parsed)) {
        return;
    }
    emit onboardEventReceived(parsed, userId);
#else
    Q_UNUSED(command);
    Q_UNUSED(userId);
    Q_UNUSED(alarmCopy);
#endif
}

}  // namespace guard
