#include "media/hikvision/HcNetSdkManager.h"

#include <QMutex>
#include <QMutexLocker>

#include <algorithm>

#ifdef GUARD_ENABLE_HCNETSDK
#include "media/hikvision/HikvisionSdk.h"
#endif

namespace {
QMutex g_hcNetSdkLifecycleMutex;
}

int HcNetSdkManager::refCount_ = 0;

bool HcNetSdkManager::acquire(QString* errorMessage, int connectTimeoutMs, int reconnectIntervalMs) {
    QMutexLocker lifecycleLock(&g_hcNetSdkLifecycleMutex);
#ifdef GUARD_ENABLE_HCNETSDK
    const int boundedConnectTimeoutMs = (std::max)(500, (std::min)(connectTimeoutMs, 60000));
    const int boundedReconnectIntervalMs = (std::max)(1000, (std::min)(reconnectIntervalMs, 60000));
    if (refCount_ > 0) {
        NET_DVR_SetConnectTime(static_cast<DWORD>(boundedConnectTimeoutMs), 1);
        NET_DVR_SetReconnect(static_cast<DWORD>(boundedReconnectIntervalMs), TRUE);
        ++refCount_;
        return true;
    }
    if (!NET_DVR_Init()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NET_DVR_Init failed (error %1)").arg(NET_DVR_GetLastError());
        }
        return false;
    }
    NET_DVR_SetConnectTime(static_cast<DWORD>(boundedConnectTimeoutMs), 1);
    NET_DVR_SetReconnect(static_cast<DWORD>(boundedReconnectIntervalMs), TRUE);
    ++refCount_;
    return true;
#else
    if (errorMessage) {
        *errorMessage = QStringLiteral("HCNetSDK support was not built into Guard.");
    }
    return false;
#endif
}

void HcNetSdkManager::release() {
    QMutexLocker lifecycleLock(&g_hcNetSdkLifecycleMutex);
#ifdef GUARD_ENABLE_HCNETSDK
    if (refCount_ <= 0) {
        return;
    }
    --refCount_;
    if (refCount_ == 0) {
        NET_DVR_Cleanup();
    }
#endif
}

bool HcNetSdkManager::isInitialized() {
    QMutexLocker lifecycleLock(&g_hcNetSdkLifecycleMutex);
    return refCount_ > 0;
}
