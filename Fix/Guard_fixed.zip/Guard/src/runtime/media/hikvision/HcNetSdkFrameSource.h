#pragma once

#include <QImage>
#include <QObject>
#include <QString>

#include <memory>
#include <thread>

#include "media/common/SourceConfig.h"
#include "media/hikvision/CameraOnboardTypes.h"
#include "media/hikvision/HcNetSdkAlarmService.h"
#include "media/recording/EncodedVideoTypes.h"

class HcNetSdkFrameSource : public QObject {
    Q_OBJECT

public:
    explicit HcNetSdkFrameSource(QObject* parent = nullptr);
    ~HcNetSdkFrameSource() override;

    static void testConnection(const HcNetSdkSourceConfig& config, quint64 generation, const QObject* context, const char* successSlot,
                               const char* failureSlot);

    bool waitForTeardown(int timeoutMs = 10000);
    bool takeLatestFrame(QImage* frame, quint64* sequence, qint64* timestampMs, quint64* generation);

    // Called only by HCNetSDK/PlayM4 callbacks. The callback lease protects the
    // object while SDK-managed threads are inside these methods.
    bool beginSdkCallback();
    void endSdkCallback();
    bool beginDecodeCallback();
    void endDecodeCallback();
    void handleRealData(unsigned dataType, unsigned char* buffer, unsigned bufferSize);
    void handleDecodedFrame(char* buffer, long size, void* frameInfo);

public slots:
    bool startCapture(const HcNetSdkSourceConfig& config, quint64 generation, const QString& streamId, quint64 startSequence = 0,
                      qint64 startTimestampMs = 0);
    void stopCapture();

signals:
    void captureStarted(quint64 generation);
    void frameAvailable(quint64 generation);
    void captureFinished(quint64 generation);
    void captureError(QString message, quint64 generation, bool recoverable);
    void captureWarning(QString message, quint64 generation);
    void statusMessage(QString message);
    void onboardCapabilitiesReady(guard::CameraOnboardCapabilities capabilities, quint64 generation);
    void onboardEventReady(guard::ParsedOnboardEvent event, quint64 generation);
    void encodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void encodedPacketReady(guard::recording::EncodedVideoPacket packet);

private:
#ifdef GUARD_ENABLE_HCNETSDK
    struct RuntimeState;

    void performStartCapture(HcNetSdkSourceConfig config, quint64 generation, QString streamId, quint64 startSequence, qint64 startTimestampMs,
                             std::unique_ptr<std::thread> previousTeardown);
    bool openPlayStream(unsigned char* sysHead, unsigned sysHeadSize);
    void closePlayStream();
    QString sdkErrorMessage(const QString& prefix, unsigned long errorCode) const;
    void conversionLoop();
    void playInputLoop();
    void clearPendingFrames();
    bool isGenerationActive(quint64 generation) const;
    void handleStandardEncodedData(const QByteArray& data, quint64 generation, qint64 timestampMs);
    void updateAlarmRouteFrameSize(int width, int height, quint64 generation);
    void handleParsedOnboardEvent(const guard::ParsedOnboardEvent& event, long userId);

    std::unique_ptr<RuntimeState> runtime_;
#endif
};
