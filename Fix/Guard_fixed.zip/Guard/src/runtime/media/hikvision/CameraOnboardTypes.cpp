#include "media/hikvision/CameraOnboardTypes.h"

namespace guard {

const char* toString(CameraCapabilityState state) noexcept {
    switch (state) {
        case CameraCapabilityState::Unknown:
            return "Unknown";
        case CameraCapabilityState::Unsupported:
            return "Unsupported";
        case CameraCapabilityState::SupportedDisabled:
            return "Supported, camera feature disabled";
        case CameraCapabilityState::SupportedEnabled:
            return "Supported";
        case CameraCapabilityState::Subscribed:
            return "Subscribed";
        case CameraCapabilityState::Verified:
            return "Verified";
    }
    return "Unknown";
}

}  // namespace guard
