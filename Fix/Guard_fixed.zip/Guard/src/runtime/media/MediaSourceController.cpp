#include "media/MediaSourceController.h"

#include "media/file/FileDecoderWorker.h"
#include "media/hikvision/HcNetSdkFrameSource.h"
#include "media/rtsp/RtspDecoderWorker.h"

#include <QCoreApplication>
#include <QDateTime>
#include <QEvent>
#include <QFileInfo>
#include <QElapsedTimer>
#include <QMetaObject>
#include <QThread>
#include <QTimer>
#include <QUrl>

#include <algorithm>
#include <utility>

MediaSourceController::MediaSourceController(QObject* parent) : QObject(parent) {
    qRegisterMetaType<guard::recording::EncodedStreamInfo>("guard::recording::EncodedStreamInfo");
    qRegisterMetaType<guard::recording::EncodedVideoPacket>("guard::recording::EncodedVideoPacket");
    qRegisterMetaType<guard::CameraOnboardCapabilities>("guard::CameraOnboardCapabilities");
    qRegisterMetaType<guard::ParsedOnboardEvent>("guard::ParsedOnboardEvent");

    hcReconnectTimer_ = new QTimer(this);
    hcReconnectTimer_->setSingleShot(true);
    connect(hcReconnectTimer_, &QTimer::timeout, this, &MediaSourceController::restartHcAfterBackoff);

    hcWatchdogTimer_ = new QTimer(this);
    hcWatchdogTimer_->setInterval(1000);
    connect(hcWatchdogTimer_, &QTimer::timeout, this, &MediaSourceController::checkHcWatchdog);
}

MediaSourceController::~MediaSourceController() {
    stop();
    shutdownWorkers();
}

quint64 MediaSourceController::nextGeneration() {
    return ++sourceGeneration_;
}

void MediaSourceController::invalidateGeneration() {
    activeGeneration_ = nextGeneration();
}

void MediaSourceController::setStatus(SourceStatus status, const QString& message) {
    status_ = status;
    emit statusChanged(static_cast<int>(status), message);
}

void MediaSourceController::ensureFileWorker() {
    if (fileThread_) {
        return;
    }
    fileThread_ = new QThread(this);
    fileWorker_ = new FileDecoderWorker();
    fileWorker_->moveToThread(fileThread_);

    connect(fileWorker_, &FileDecoderWorker::sourceOpened, this, &MediaSourceController::onFileSourceOpened, Qt::QueuedConnection);
    connect(fileWorker_, &FileDecoderWorker::frameDecoded, this, &MediaSourceController::onFileFrameDecoded, Qt::QueuedConnection);
    connect(fileWorker_, &FileDecoderWorker::encodedStreamInfoReady, this, &MediaSourceController::onFileEncodedStreamInfoReady,
            Qt::QueuedConnection);
    connect(fileWorker_, &FileDecoderWorker::encodedPacketDecoded, this, &MediaSourceController::onFileEncodedPacketDecoded, Qt::QueuedConnection);
    connect(fileWorker_, &FileDecoderWorker::playbackFinished, this, &MediaSourceController::onFilePlaybackFinished, Qt::QueuedConnection);
    connect(fileWorker_, &FileDecoderWorker::decoderError, this, &MediaSourceController::onFileDecoderError, Qt::QueuedConnection);
    fileThread_->start();
}

void MediaSourceController::ensureRtspWorker() {
    if (rtspThread_) {
        return;
    }
    rtspThread_ = new QThread(this);
    rtspWorker_ = new RtspDecoderWorker();
    rtspWorker_->moveToThread(rtspThread_);

    connect(rtspWorker_, &RtspDecoderWorker::streamOpened, this, &MediaSourceController::onRtspStreamOpened, Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::streamReconnecting, this, &MediaSourceController::onRtspReconnecting, Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::frameAvailable, this, &MediaSourceController::onRtspFrameAvailable, Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::encodedStreamInfoReady, this, &MediaSourceController::onRtspEncodedStreamInfoReady,
            Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::encodedPacketReady, this, &MediaSourceController::onRtspEncodedPacketReady, Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::playbackFinished, this, &MediaSourceController::onRtspPlaybackFinished, Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::decoderError, this, &MediaSourceController::onRtspDecoderError, Qt::QueuedConnection);
    connect(rtspWorker_, &RtspDecoderWorker::connectionTestFinished, this, &MediaSourceController::onRtspConnectionTestFinished,
            Qt::QueuedConnection);
    rtspThread_->start();
}

void MediaSourceController::ensureHcSource() {
    if (hcSource_) {
        return;
    }

    hcSource_ = new HcNetSdkFrameSource(this);
    connect(hcSource_, &HcNetSdkFrameSource::captureStarted, this, &MediaSourceController::onHcCaptureStarted, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::frameAvailable, this, &MediaSourceController::onHcFrameAvailable, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::captureFinished, this, &MediaSourceController::onHcCaptureFinished, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::captureError, this, &MediaSourceController::onHcCaptureError, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::captureWarning, this, &MediaSourceController::onHcCaptureWarning, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::statusMessage, this, &MediaSourceController::onHcStatusMessage, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::onboardCapabilitiesReady, this, &MediaSourceController::onHcCapabilitiesReady, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::onboardEventReady, this, &MediaSourceController::onHcOnboardEvent, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::encodedStreamInfoReady, this, &MediaSourceController::onHcEncodedStreamInfo, Qt::QueuedConnection);
    connect(hcSource_, &HcNetSdkFrameSource::encodedPacketReady, this, &MediaSourceController::onHcEncodedPacket, Qt::QueuedConnection);
}

void MediaSourceController::shutdownWorkers() {
    shutdownWorkerThreadsForApplicationExit();

    if (fileWorker_) {
        delete fileWorker_;
        fileWorker_ = nullptr;
    }
    if (fileThread_) {
        fileThread_ = nullptr;
    }

    if (rtspWorker_) {
        delete rtspWorker_;
        rtspWorker_ = nullptr;
    }
    if (rtspThread_) {
        rtspThread_ = nullptr;
    }
}

QString MediaSourceController::buildRtspUrl(const RtspSourceConfig& config) const {
    if (!config.username.isEmpty()) {
        QUrl url(config.url);
        if (url.userName().isEmpty()) {
            url.setUserName(config.username);
            url.setPassword(config.password);
            return url.toString();
        }
    }
    return config.url;
}

int MediaSourceController::rtspShutdownWaitMs() const {
    return std::max(2000, config_.rtsp.timeoutMs + 1500);
}

void MediaSourceController::configureFile(const QString& path) {
    stop();
    invalidateGeneration();
    startFileAfterProbe_ = false;
    config_.type = FrameSourceType::None;
    config_.filePath = path;
    config_.safeDisplayName = QFileInfo(path).fileName();
    encodedStreamInfo_ = guard::recording::EncodedStreamInfo{};
}

void MediaSourceController::loadSource(const QString& path) {
    configureFile(path);
    probeFile();
}

void MediaSourceController::startPlayback() {
    start(QStringLiteral("guard-source"), nullptr);
}

void MediaSourceController::stopPlayback() {
    stop();
}

void MediaSourceController::configureHcNetSdk(const HcNetSdkSourceConfig& config) {
    stop();
    config_.type = FrameSourceType::HcNetSdkCamera;
    config_.hcNetSdk = config;
    config_.safeDisplayName = QStringLiteral("%1:%2").arg(config.ip).arg(config.port);
    encodedStreamInfo_ = guard::recording::EncodedStreamInfo{};
}

void MediaSourceController::configureRtsp(const RtspSourceConfig& config) {
    stop();
    config_.type = FrameSourceType::RtspStream;
    config_.rtsp = config;
    config_.safeDisplayName = maskRtspUrl(buildRtspUrl(config));
    encodedStreamInfo_ = guard::recording::EncodedStreamInfo{};
}

void MediaSourceController::probeFile() {
    startFileAfterProbe_ = false;
    if (config_.filePath.isEmpty()) {
        setStatus(SourceStatus::NoSource, QStringLiteral("No source"));
        return;
    }

    config_.type = FrameSourceType::None;
    sourceWidth_ = 0;
    sourceHeight_ = 0;
    sourceFps_ = 0.0;
    frameCount_ = -1;

    ensureFileWorker();
    setStatus(SourceStatus::Loading, QStringLiteral("Loading..."));
    QMetaObject::invokeMethod(fileWorker_, "openSource", Qt::QueuedConnection, Q_ARG(QString, config_.filePath), Q_ARG(quint64, activeGeneration_));
}

void MediaSourceController::testHcNetSdkConnection(const HcNetSdkSourceConfig& config) {
    pendingTestGeneration_ = nextGeneration();
    setStatus(SourceStatus::Connecting, QStringLiteral("Testing HCNetSDK connection..."));
    ensureHcSource();
    HcNetSdkFrameSource::testConnection(config, pendingTestGeneration_, this, "onHcConnectionSuccess", "onHcConnectionFailure");
}

void MediaSourceController::testRtspConnection(const RtspSourceConfig& config) {
    pendingTestGeneration_ = nextGeneration();
    setStatus(SourceStatus::Connecting, QStringLiteral("Testing RTSP connection..."));
    ensureRtspWorker();
    const QString url = buildRtspUrl(config);
    QMetaObject::invokeMethod(rtspWorker_, "testConnection", Qt::QueuedConnection, Q_ARG(QString, url), Q_ARG(int, config.timeoutMs),
                              Q_ARG(quint64, pendingTestGeneration_));
}

bool MediaSourceController::start(const QString& streamId, quint64* outGeneration) {
    invalidateGeneration();
    if (outGeneration) {
        *outGeneration = activeGeneration_;
    }

    resetForNewPlayback();
    playbackActive_ = true;
    userStopRequested_ = false;
    activeStreamId_ = streamId;
    encodedStreamInfo_ = guard::recording::EncodedStreamInfo{};
    resetHcReconnectState();
    startFileAfterProbe_ = false;

    switch (config_.type) {
        case FrameSourceType::ImageFile:
        case FrameSourceType::VideoFile:
            if (config_.filePath.isEmpty() || !fileWorker_) {
                setStatus(SourceStatus::Error, QStringLiteral("No file source loaded"));
                playbackActive_ = false;
                return false;
            }
            setStatus(SourceStatus::Playing, QStringLiteral("Playing"));
            QMetaObject::invokeMethod(fileWorker_, "startDecoding", Qt::QueuedConnection, Q_ARG(quint64, nextSequence_),
                                      Q_ARG(qint64, nextTimestampMs_), Q_ARG(quint64, activeGeneration_));
            return true;

        case FrameSourceType::RtspStream: {
            ensureRtspWorker();
            const QString url = buildRtspUrl(config_.rtsp);
            setStatus(SourceStatus::Connecting, QStringLiteral("Connecting RTSP..."));
            QMetaObject::invokeMethod(rtspWorker_, "startDecoding", Qt::QueuedConnection, Q_ARG(QString, url), Q_ARG(int, config_.rtsp.timeoutMs),
                                      Q_ARG(int, config_.rtsp.reconnectInitialDelayMs), Q_ARG(int, config_.rtsp.reconnectMaximumDelayMs),
                                      Q_ARG(quint64, nextSequence_), Q_ARG(qint64, nextTimestampMs_), Q_ARG(quint64, activeGeneration_));
            return true;
        }

        case FrameSourceType::HcNetSdkCamera:
            ensureHcSource();
            lastHcFrameWallMs_ = QDateTime::currentMSecsSinceEpoch();
            setStatus(SourceStatus::Connecting, QStringLiteral("Connecting camera..."));
            if (!hcSource_->startCapture(config_.hcNetSdk, activeGeneration_, activeStreamId_, nextSequence_, nextTimestampMs_)) {
                playbackActive_ = false;
                return false;
            }
            hcWatchdogTimer_->start();
            return true;

        case FrameSourceType::None:
            if (!config_.filePath.isEmpty()) {
                ensureFileWorker();
                startFileAfterProbe_ = true;
                setStatus(SourceStatus::Loading, QStringLiteral("Loading test media..."));
                QMetaObject::invokeMethod(fileWorker_, "openSource", Qt::QueuedConnection, Q_ARG(QString, config_.filePath),
                                          Q_ARG(quint64, activeGeneration_));
                return true;
            }
            setStatus(SourceStatus::Error, QStringLiteral("No source configured"));
            playbackActive_ = false;
            return false;

        default:
            setStatus(SourceStatus::Error, QStringLiteral("Unsupported source configuration"));
            playbackActive_ = false;
            return false;
    }
}

void MediaSourceController::stop() {
    userStopRequested_ = true;
    playbackActive_ = false;
    startFileAfterProbe_ = false;
    if (hcReconnectTimer_) {
        hcReconnectTimer_->stop();
    }
    if (hcWatchdogTimer_) {
        hcWatchdogTimer_->stop();
    }
    if (fileWorker_) {
        fileWorker_->cancelGeneration(activeGeneration_);
        QMetaObject::invokeMethod(fileWorker_, "stopDecoding", Qt::QueuedConnection);
    }
    if (rtspWorker_) {
        rtspWorker_->cancelGeneration(activeGeneration_);
    }
    if (hcSource_) {
        hcSource_->stopCapture();
    }
    if (status_ == SourceStatus::Playing || status_ == SourceStatus::Connecting || status_ == SourceStatus::Reconnecting ||
        status_ == SourceStatus::Loading) {
        setStatus(SourceStatus::Stopped, QStringLiteral("Stopped"));
    }
}

bool MediaSourceController::isQuiescent() const {
    const bool fileStopped = !fileWorker_ || !fileWorker_->isDecoding();
    const bool rtspStopped = !rtspWorker_ || !rtspWorker_->isDecoding();
    return fileStopped && rtspStopped;
}

void MediaSourceController::shutdownWorkerThreadsForApplicationExit() {
    // No new decoder callbacks may target this controller after this point.
    // Disconnect first, then stop and join the event-loop threads while Qt is
    // still fully alive. Merely observing isDecoding()==false is insufficient:
    // the QThread event loop itself can remain alive and race QApplication
    // teardown when Exit is selected during active playback.
    if (fileWorker_) {
        disconnect(fileWorker_, nullptr, this, nullptr);
    }
    if (rtspWorker_) {
        disconnect(rtspWorker_, nullptr, this, nullptr);
    }

    stopAndWaitForQuiescence(0);

    if (fileThread_ && fileThread_->isRunning()) {
        fileThread_->requestInterruption();
        fileThread_->quit();
        fileThread_->wait();
    }

    if (rtspThread_ && rtspThread_->isRunning()) {
        if (rtspWorker_) {
            rtspWorker_->requestStop();
        }
        rtspThread_->requestInterruption();
        rtspThread_->quit();
        if (!rtspThread_->wait(static_cast<unsigned long>(rtspShutdownWaitMs()))) {
            rtspThread_->wait();
        }
    }

    // Worker-to-controller deliveries posted before disconnect() are not
    // cancelled automatically. The workers are now joined, so no new ones can
    // appear and the stale deliveries can be safely discarded.
    QCoreApplication::removePostedEvents(this, QEvent::MetaCall);
}

bool MediaSourceController::stopAndWaitForQuiescence(int timeoutMs) {
    stop();

    QElapsedTimer elapsed;
    elapsed.start();
    const auto hasTimeRemaining = [&]() { return timeoutMs <= 0 || elapsed.elapsed() < timeoutMs; };

    // File and RTSP workers expose atomic decoding state. Their stop requests are
    // lock-free. Do not process GUI events while waiting: dispatching a queued
    // frame or callback here can re-enter camera teardown while GuardVision's
    // native per-stream state is still being destroyed.
    while (!isQuiescent() && hasTimeRemaining()) {
        QThread::msleep(2);
    }

    if (hcSource_) {
        int remaining = 0;
        if (timeoutMs > 0) {
            remaining = qMax(1, timeoutMs - static_cast<int>(elapsed.elapsed()));
        }
        if (!hcSource_->waitForTeardown(remaining)) {
            return false;
        }
    }
    return isQuiescent();
}

void MediaSourceController::resetForNewPlayback() {
    // A normal CameraWidget disconnect retains the GuardVision stream so the
    // vendor face session does not need to be torn down. GuardVision therefore
    // also retains the last accepted frame sequence. Restarting a file or camera
    // source at sequence zero makes every reconnect frame look stale until the
    // source counts back up to the old value, which delays all analytics.
    //
    // Keep nextSequence_ monotonic for the complete MediaSourceController
    // lifetime. Also keep timestamps monotonic while allowing a real disconnect
    // pause to advance them to the current wall clock.
    const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
    nextTimestampMs_ = nextTimestampMs_ > 0 ? qMax(nextTimestampMs_ + 1, nowMs) : nowMs;
}

bool MediaSourceController::isRunning() const {
    return playbackActive_ && (status_ == SourceStatus::Playing || status_ == SourceStatus::Connecting || status_ == SourceStatus::Reconnecting);
}

void MediaSourceController::onFileSourceOpened(bool isMovie, int width, int height, double fps, qint64 frameCount, QImage firstFrame,
                                               quint64 generation) {
    if (generation != activeGeneration_ || (!playbackActive_ && status_ == SourceStatus::Stopped)) {
        return;
    }

    config_.type = isMovie ? FrameSourceType::VideoFile : FrameSourceType::ImageFile;
    sourceWidth_ = width;
    sourceHeight_ = height;
    sourceFps_ = fps;
    frameCount_ = frameCount;

    if (!firstFrame.isNull()) {
        emit previewFrameReady(firstFrame, activeGeneration_);
    }

    if (startFileAfterProbe_ && playbackActive_) {
        startFileAfterProbe_ = false;
        setStatus(SourceStatus::Playing, QStringLiteral("Playing"));
        QMetaObject::invokeMethod(fileWorker_, "startDecoding", Qt::QueuedConnection, Q_ARG(quint64, nextSequence_), Q_ARG(qint64, nextTimestampMs_),
                                  Q_ARG(quint64, activeGeneration_));
        return;
    }

    setStatus(SourceStatus::Ready, QStringLiteral("Ready"));
}

void MediaSourceController::onFileFrameDecoded(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    nextSequence_ = sequence + 1;
    nextTimestampMs_ = timestampMs + (sourceFps_ > 0.0 ? static_cast<qint64>(1000.0 / sourceFps_) : 0);
    emit frameReadyForSubmission(std::move(frame), sequence, timestampMs, generation);
}

void MediaSourceController::onFileEncodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation) {
    if (generation != activeGeneration_)
        return;
    encodedStreamInfo_ = streamInfo;
    emit encodedStreamInfoChanged(std::move(streamInfo), playbackActive_ ? generation : 0);
}

void MediaSourceController::onFileEncodedPacketDecoded(guard::recording::EncodedVideoPacket packet) {
    if (!playbackActive_ || packet.generation != activeGeneration_) {
        return;
    }
    emit encodedPacketReady(std::move(packet));
}

void MediaSourceController::onFilePlaybackFinished() {
    playbackActive_ = false;
    setStatus(SourceStatus::Completed, QStringLiteral("Completed"));
    emit playbackFinished(activeGeneration_);
}

void MediaSourceController::onFileDecoderError(QString message, quint64 generation) {
    if (generation != activeGeneration_)
        return;
    startFileAfterProbe_ = false;
    playbackActive_ = false;
    setStatus(SourceStatus::Error, message);
    emit decoderError(message);
}

void MediaSourceController::onRtspStreamOpened(int width, int height, double fps, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    sourceWidth_ = width;
    sourceHeight_ = height;
    sourceFps_ = fps;
    setStatus(SourceStatus::Playing, QStringLiteral("Playing"));
}

void MediaSourceController::onRtspReconnecting(QString message, int attempt, int delayMs, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    setStatus(SourceStatus::Reconnecting, QStringLiteral("Reconnecting"));
    emit sourceMessage(QStringLiteral("RTSP reconnect attempt %1 in %2 ms: %3").arg(attempt).arg(delayMs).arg(message));
}

void MediaSourceController::onRtspFrameAvailable(quint64 generation) {
    if (!rtspWorker_) {
        return;
    }

    QImage frame;
    quint64 sequence = 0;
    qint64 timestampMs = 0;
    quint64 frameGeneration = 0;
    if (!rtspWorker_->takeLatestFrame(&frame, &sequence, &timestampMs, &frameGeneration)) {
        return;
    }
    if (!playbackActive_ || generation != activeGeneration_ || frameGeneration != activeGeneration_) {
        return;
    }

    nextSequence_ = sequence + 1;
    nextTimestampMs_ = timestampMs;
    emit frameReadyForSubmission(std::move(frame), sequence, timestampMs, frameGeneration);
}

void MediaSourceController::onRtspEncodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    encodedStreamInfo_ = streamInfo;
    emit encodedStreamInfoChanged(std::move(streamInfo), generation);
}

void MediaSourceController::onRtspEncodedPacketReady(guard::recording::EncodedVideoPacket packet) {
    if (!playbackActive_ || packet.generation != activeGeneration_) {
        return;
    }
    emit encodedPacketReady(std::move(packet));
}

void MediaSourceController::onRtspPlaybackFinished(quint64 generation) {
    if (generation != activeGeneration_) {
        return;
    }
    if (!playbackActive_ || userStopRequested_) {
        return;
    }
    playbackActive_ = false;
    setStatus(SourceStatus::Error, QStringLiteral("RTSP worker stopped unexpectedly."));
    emit decoderError(QStringLiteral("RTSP worker stopped unexpectedly."));
}

void MediaSourceController::onRtspDecoderError(QString message, quint64 generation) {
    if (generation != activeGeneration_ && generation != pendingTestGeneration_) {
        return;
    }
    if (generation == pendingTestGeneration_) {
        setStatus(SourceStatus::Error, message);
        emit decoderError(message);
        return;
    }
    playbackActive_ = false;
    setStatus(SourceStatus::Error, message);
    emit decoderError(message);
}

void MediaSourceController::onRtspConnectionTestFinished(bool ok, QString message, quint64 generation) {
    if (generation != pendingTestGeneration_) {
        return;
    }
    setStatus(ok ? SourceStatus::Ready : SourceStatus::Error, message);
    emit connectionTestResult(ok, message);
}

void MediaSourceController::onHcCaptureStarted(quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    // RealPlay can succeed before the camera delivers decoded frames. Keep the
    // reconnect backoff until the first valid frame proves the stream healthy.
    lastHcFrameWallMs_ = QDateTime::currentMSecsSinceEpoch();
    setStatus(SourceStatus::Connecting, QStringLiteral("Connected; waiting for video..."));
    emit sourceMessage(QStringLiteral("HCNetSDK preview started; waiting for the first decoded frame."));
}

void MediaSourceController::onHcFrameAvailable(quint64 generation) {
    if (!hcSource_) {
        return;
    }

    QImage frame;
    quint64 sequence = 0;
    qint64 timestampMs = 0;
    quint64 frameGeneration = 0;
    if (!hcSource_->takeLatestFrame(&frame, &sequence, &timestampMs, &frameGeneration)) {
        return;
    }
    if (!playbackActive_ || generation != activeGeneration_ || frameGeneration != activeGeneration_) {
        return;
    }

    lastHcFrameWallMs_ = QDateTime::currentMSecsSinceEpoch();
    if (status_ == SourceStatus::Reconnecting || status_ == SourceStatus::Connecting) {
        resetHcReconnectState();
        setStatus(SourceStatus::Playing, QStringLiteral("Playing"));
    }
    nextSequence_ = sequence + 1;
    nextTimestampMs_ = timestampMs;
    emit frameReadyForSubmission(std::move(frame), sequence, timestampMs, frameGeneration);
}

void MediaSourceController::onHcCaptureFinished(quint64 generation) {
    if (generation != activeGeneration_ || userStopRequested_) {
        return;
    }

    // captureFinished is emitted after the source completes an explicit teardown.
    // Reconnects are initiated by captureError() or the no-frame watchdog. Starting
    // another reconnect here would race the reconnect startup and could cancel it.
    if (playbackActive_ && status_ == SourceStatus::Reconnecting) {
        emit sourceMessage(QStringLiteral("HCNetSDK previous session teardown completed."));
    }
}

void MediaSourceController::onHcCaptureError(QString message, quint64 generation, bool recoverable) {
    if (generation != activeGeneration_ && generation != pendingTestGeneration_) {
        return;
    }
    if (generation == pendingTestGeneration_) {
        setStatus(SourceStatus::Error, message);
        emit decoderError(message);
        return;
    }
    if (recoverable && playbackActive_ && !userStopRequested_) {
        scheduleHcReconnect(message);
        return;
    }
    playbackActive_ = false;
    hcWatchdogTimer_->stop();
    setStatus(SourceStatus::Error, message);
    emit decoderError(message);
}

void MediaSourceController::onHcCaptureWarning(QString message, quint64 generation) {
    if (generation == activeGeneration_) {
        emit sourceMessage(message);
    }
}

void MediaSourceController::onHcStatusMessage(QString message) {
    if (!message.isEmpty()) {
        emit sourceMessage(message);
    }
}

void MediaSourceController::onHcCapabilitiesReady(guard::CameraOnboardCapabilities capabilities, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    emit onboardCapabilitiesChanged(capabilities, generation);
}

void MediaSourceController::onHcOnboardEvent(guard::ParsedOnboardEvent event, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    emit onboardCandidateReady(std::move(event), generation);
}

void MediaSourceController::onHcEncodedStreamInfo(guard::recording::EncodedStreamInfo streamInfo, quint64 generation) {
    if (!playbackActive_ || generation != activeGeneration_) {
        return;
    }
    encodedStreamInfo_ = streamInfo;
    emit encodedStreamInfoChanged(std::move(streamInfo), generation);
}

void MediaSourceController::onHcEncodedPacket(guard::recording::EncodedVideoPacket packet) {
    if (!playbackActive_ || packet.generation != activeGeneration_) {
        return;
    }
    emit encodedPacketReady(std::move(packet));
}

void MediaSourceController::onHcConnectionSuccess(QString message, quint64 generation) {
    if (generation != pendingTestGeneration_) {
        return;
    }
    setStatus(SourceStatus::Ready, message);
    emit connectionTestResult(true, message);
}

void MediaSourceController::onHcConnectionFailure(QString message, quint64 generation) {
    if (generation != pendingTestGeneration_) {
        return;
    }
    setStatus(SourceStatus::Error, message);
    emit connectionTestResult(false, message);
}

void MediaSourceController::scheduleHcReconnect(const QString& reason) {
    if (!playbackActive_ || userStopRequested_ || config_.type != FrameSourceType::HcNetSdkCamera) {
        return;
    }
    if (hcReconnectTimer_->isActive()) {
        return;
    }
    setStatus(SourceStatus::Reconnecting, QStringLiteral("Reconnecting"));
    const int delayMs = nextHcReconnectDelayMs();
    emit sourceMessage(QStringLiteral("HCNetSDK reconnect attempt %1 in %2 ms: %3").arg(hcReconnectAttempt_).arg(delayMs).arg(reason));
    if (hcSource_) {
        hcSource_->stopCapture();
    }
    hcReconnectTimer_->start(delayMs);
}

void MediaSourceController::restartHcAfterBackoff() {
    if (!playbackActive_ || userStopRequested_ || config_.type != FrameSourceType::HcNetSdkCamera || !hcSource_) {
        return;
    }
    lastHcFrameWallMs_ = QDateTime::currentMSecsSinceEpoch();
    setStatus(SourceStatus::Reconnecting, QStringLiteral("Reconnecting"));
    if (!hcSource_->startCapture(config_.hcNetSdk, activeGeneration_, activeStreamId_, nextSequence_, nextTimestampMs_)) {
        scheduleHcReconnect(QStringLiteral("Unable to schedule HCNetSDK reconnect."));
    }
}

void MediaSourceController::checkHcWatchdog() {
    if (!playbackActive_ || userStopRequested_ || config_.type != FrameSourceType::HcNetSdkCamera) {
        return;
    }
    if (status_ != SourceStatus::Playing && status_ != SourceStatus::Connecting && status_ != SourceStatus::Reconnecting) {
        return;
    }
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    const int timeoutMs = std::max(3000, config_.hcNetSdk.noFrameTimeoutMs);
    if (lastHcFrameWallMs_ > 0 && now - lastHcFrameWallMs_ >= timeoutMs && !hcReconnectTimer_->isActive()) {
        scheduleHcReconnect(QStringLiteral("No decoded camera frame was received for %1 ms.").arg(timeoutMs));
    }
}

void MediaSourceController::resetHcReconnectState() {
    hcReconnectAttempt_ = 0;
    if (hcReconnectTimer_) {
        hcReconnectTimer_->stop();
    }
}

int MediaSourceController::nextHcReconnectDelayMs() {
    ++hcReconnectAttempt_;
    const int initial = std::max(250, config_.hcNetSdk.reconnectInitialDelayMs);
    const int maximum = std::max(initial, config_.hcNetSdk.reconnectMaximumDelayMs);
    qint64 delay = initial;
    for (int index = 1; index < hcReconnectAttempt_ && delay < maximum; ++index) {
        delay = std::min<qint64>(maximum, delay * 2);
    }
    return static_cast<int>(delay);
}
