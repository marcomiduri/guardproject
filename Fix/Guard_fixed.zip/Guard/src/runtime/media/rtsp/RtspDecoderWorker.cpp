#include "media/rtsp/RtspDecoderWorker.h"

#include "media/common/OpenCvFrameConverter.h"

#include <QDateTime>
#include <QElapsedTimer>
#include <QMutexLocker>
#include <QThread>

#include <opencv2/videoio.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <limits>
#include <memory>
#include <utility>
#include <vector>

#ifdef GUARD_ENABLE_FFMPEG
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/error.h>
#include <libswscale/swscale.h>
}
#endif

namespace {

constexpr double kFallbackFps = 25.0;
constexpr int kMinimumTimeoutMs = 250;
constexpr int kMaximumReconnectAttemptsBeforeNotice = 1000000;

int normalizedTimeoutMs(int timeoutMs) {
    return std::max(timeoutMs, kMinimumTimeoutMs);
}

int normalizedReconnectDelay(int value, int fallback) {
    return value > 0 ? value : fallback;
}

int reconnectDelayForAttempt(int attempt, int initialDelayMs, int maximumDelayMs) {
    const int initial = normalizedReconnectDelay(initialDelayMs, 1000);
    const int maximum = std::max(initial, normalizedReconnectDelay(maximumDelayMs, 30000));
    qint64 delay = initial;
    for (int index = 1; index < attempt && delay < maximum; ++index) {
        delay = std::min<qint64>(maximum, delay * 2);
    }
    return static_cast<int>(delay);
}

bool openCapture(cv::VideoCapture& capture, const QString& url, int timeoutMs) {
    const QByteArray nativeUrl = url.toLocal8Bit();
    const int boundedTimeoutMs = normalizedTimeoutMs(timeoutMs);
    const std::vector<int> parameters = {
      cv::CAP_PROP_OPEN_TIMEOUT_MSEC,
      boundedTimeoutMs,
      cv::CAP_PROP_READ_TIMEOUT_MSEC,
      boundedTimeoutMs,
    };

    if (capture.open(nativeUrl.constData(), cv::CAP_FFMPEG, parameters)) {
        return true;
    }

    capture.release();
    return capture.open(nativeUrl.constData(), cv::CAP_ANY, parameters);
}

qint64 nextMonotonicWallTimestamp(qint64 previousTimestampMs) {
    const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
    return previousTimestampMs < nowMs ? nowMs : previousTimestampMs + 1;
}

bool validFps(double fps) {
    return std::isfinite(fps) && fps > 1.0 && fps <= 240.0;
}

#ifdef GUARD_ENABLE_FFMPEG

QString ffmpegError(int code) {
    char buffer[AV_ERROR_MAX_STRING_SIZE] = {};
    av_strerror(code, buffer, sizeof(buffer));
    return QString::fromLocal8Bit(buffer);
}

qint64 steadyNowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

struct InterruptState {
    std::atomic_bool* stopRequested = nullptr;
    std::atomic<qint64> deadlineMs{0};
};

int ffmpegInterrupt(void* opaque) {
    auto* state = static_cast<InterruptState*>(opaque);
    if (!state) {
        return 0;
    }
    if (state->stopRequested && state->stopRequested->load(std::memory_order_acquire)) {
        return 1;
    }
    const qint64 deadline = state->deadlineMs.load(std::memory_order_acquire);
    return deadline > 0 && steadyNowMs() >= deadline ? 1 : 0;
}

struct RtspSession {
    AVFormatContext* format = nullptr;
    AVCodecContext* decoder = nullptr;
    SwsContext* scaler = nullptr;
    AVStream* videoStream = nullptr;
    int videoStreamIndex = -1;
    InterruptState interrupt;

    ~RtspSession() {
        if (scaler) {
            sws_freeContext(scaler);
        }
        if (decoder) {
            avcodec_free_context(&decoder);
        }
        if (format) {
            avformat_close_input(&format);
        }
    }
};

qint64 timestampToMs(qint64 timestamp, AVRational timeBase) {
    if (timestamp == AV_NOPTS_VALUE || timeBase.num <= 0 || timeBase.den <= 0) {
        return std::numeric_limits<qint64>::min();
    }
    return static_cast<qint64>(av_rescale_q(timestamp, timeBase, AVRational{1, 1000}));
}

guard::recording::VideoCodec toVideoCodec(AVCodecID codecId) {
    switch (codecId) {
        case AV_CODEC_ID_H264:
            return guard::recording::VideoCodec::H264;
        case AV_CODEC_ID_HEVC:
            return guard::recording::VideoCodec::H265;
        case AV_CODEC_ID_MPEG4:
            return guard::recording::VideoCodec::Mpeg4Part2;
        default:
            return guard::recording::VideoCodec::Unknown;
    }
}

guard::recording::EncodedStreamInfo makeStreamInfo(const RtspSession& session) {
    guard::recording::EncodedStreamInfo info;
    if (!session.videoStream || !session.videoStream->codecpar) {
        return info;
    }
    const AVCodecParameters* parameters = session.videoStream->codecpar;
    info.codec = toVideoCodec(parameters->codec_id);
    info.width = parameters->width;
    info.height = parameters->height;
    info.timeBaseNumerator = session.videoStream->time_base.num;
    info.timeBaseDenominator = session.videoStream->time_base.den;
    info.mp4RemuxCompatible = info.codec == guard::recording::VideoCodec::H264 || info.codec == guard::recording::VideoCodec::H265 ||
                              info.codec == guard::recording::VideoCodec::Mpeg4Part2;
    if (parameters->extradata && parameters->extradata_size > 0) {
        info.codecExtraData = QByteArray(reinterpret_cast<const char*>(parameters->extradata), parameters->extradata_size);
    }
    return info;
}

double streamFps(const AVStream* stream) {
    if (!stream) {
        return kFallbackFps;
    }
    AVRational rate = stream->avg_frame_rate;
    if (rate.num <= 0 || rate.den <= 0) {
        rate = stream->r_frame_rate;
    }
    const double fps = rate.num > 0 && rate.den > 0 ? av_q2d(rate) : kFallbackFps;
    return validFps(fps) ? fps : kFallbackFps;
}

bool openRtspSession(const QString& url, int timeoutMs, std::atomic_bool& stopRequested, RtspSession* session, QString* errorMessage) {
    if (!session) {
        return false;
    }

    session->format = avformat_alloc_context();
    if (!session->format) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to allocate the FFmpeg RTSP context.");
        }
        return false;
    }

    session->interrupt.stopRequested = &stopRequested;
    session->interrupt.deadlineMs.store(steadyNowMs() + normalizedTimeoutMs(timeoutMs), std::memory_order_release);
    session->format->interrupt_callback.callback = ffmpegInterrupt;
    session->format->interrupt_callback.opaque = &session->interrupt;

    AVDictionary* options = nullptr;
    const qint64 timeoutUs = static_cast<qint64>(normalizedTimeoutMs(timeoutMs)) * 1000;
    av_dict_set(&options, "rtsp_transport", "tcp", 0);
    av_dict_set_int(&options, "stimeout", timeoutUs, 0);
    av_dict_set_int(&options, "rw_timeout", timeoutUs, 0);
    av_dict_set(&options, "fflags", "nobuffer", 0);
    av_dict_set(&options, "flags", "low_delay", 0);

    const QByteArray nativeUrl = url.toUtf8();
    int result = avformat_open_input(&session->format, nativeUrl.constData(), nullptr, &options);
    av_dict_free(&options);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to open RTSP stream: %1").arg(ffmpegError(result));
        }
        return false;
    }

    session->interrupt.deadlineMs.store(steadyNowMs() + normalizedTimeoutMs(timeoutMs), std::memory_order_release);
    result = avformat_find_stream_info(session->format, nullptr);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to read RTSP stream information: %1").arg(ffmpegError(result));
        }
        return false;
    }

    result = av_find_best_stream(session->format, AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("The RTSP source does not contain a decodable video stream.");
        }
        return false;
    }

    session->videoStreamIndex = result;
    session->videoStream = session->format->streams[result];
    const AVCodec* codec = avcodec_find_decoder(session->videoStream->codecpar->codec_id);
    if (!codec) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("No FFmpeg decoder is available for the RTSP video codec.");
        }
        return false;
    }

    session->decoder = avcodec_alloc_context3(codec);
    if (!session->decoder) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to allocate the FFmpeg RTSP decoder.");
        }
        return false;
    }
    result = avcodec_parameters_to_context(session->decoder, session->videoStream->codecpar);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to configure the RTSP decoder: %1").arg(ffmpegError(result));
        }
        return false;
    }
    session->decoder->pkt_timebase = session->videoStream->time_base;
    session->decoder->flags |= AV_CODEC_FLAG_LOW_DELAY;
    result = avcodec_open2(session->decoder, codec, nullptr);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to start the RTSP decoder: %1").arg(ffmpegError(result));
        }
        return false;
    }
    return true;
}

QImage convertFrame(RtspSession& session, const AVFrame* frame, QString* errorMessage) {
    if (!frame || frame->width <= 0 || frame->height <= 0) {
        return QImage();
    }
    QImage image(frame->width, frame->height, QImage::Format_RGB888);
    if (image.isNull()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to allocate an RGB RTSP frame.");
        }
        return QImage();
    }
    session.scaler = sws_getCachedContext(session.scaler, frame->width, frame->height, static_cast<AVPixelFormat>(frame->format), frame->width,
                                          frame->height, AV_PIX_FMT_RGB24, SWS_BILINEAR, nullptr, nullptr, nullptr);
    if (!session.scaler) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to create the FFmpeg RTSP color converter.");
        }
        return QImage();
    }
    uint8_t* destinationData[4] = {image.bits(), nullptr, nullptr, nullptr};
    int destinationLinesize[4] = {image.bytesPerLine(), 0, 0, 0};
    const int rows = sws_scale(session.scaler, frame->data, frame->linesize, 0, frame->height, destinationData, destinationLinesize);
    if (rows != frame->height) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("FFmpeg did not convert the complete RTSP frame.");
        }
        return QImage();
    }
    return image;
}

#endif

}  // namespace

RtspDecoderWorker::RtspDecoderWorker(QObject* parent) : QObject(parent) {}

void RtspDecoderWorker::requestStop() noexcept {
    stopRequested_.store(true, std::memory_order_release);
}

void RtspDecoderWorker::cancelGeneration(quint64 generation) noexcept {
    quint64 current = cancelledThroughGeneration_.load(std::memory_order_acquire);
    while (current < generation &&
           !cancelledThroughGeneration_.compare_exchange_weak(current, generation, std::memory_order_release, std::memory_order_acquire)) {
    }
    stopRequested_.store(true, std::memory_order_release);
}

bool RtspDecoderWorker::isDecoding() const noexcept {
    return decoding_.load(std::memory_order_acquire);
}

bool RtspDecoderWorker::takeLatestFrame(QImage* frame, quint64* sequence, qint64* timestampMs, quint64* generation) {
    if (!frame || !sequence || !timestampMs || !generation) {
        return false;
    }

    QMutexLocker locker(&latestFrameMutex_);
    if (latestFrame_.isNull()) {
        frameNotificationPending_ = false;
        return false;
    }

    *frame = latestFrame_;
    *sequence = latestSequence_;
    *timestampMs = latestTimestampMs_;
    *generation = latestGeneration_;
    latestFrame_ = QImage();
    frameNotificationPending_ = false;
    return true;
}

void RtspDecoderWorker::testConnection(const QString& url, int timeoutMs, quint64 generation) {
#ifdef GUARD_ENABLE_FFMPEG
    std::atomic_bool localStop{false};
    RtspSession session;
    QString errorMessage;
    if (!openRtspSession(url, timeoutMs, localStop, &session, &errorMessage)) {
        emit connectionTestFinished(false, errorMessage, generation);
        return;
    }

    AVPacket* packet = av_packet_alloc();
    AVFrame* frame = av_frame_alloc();
    bool decoded = false;
    if (packet && frame) {
        for (int packetCount = 0; packetCount < 128 && !decoded; ++packetCount) {
            session.interrupt.deadlineMs.store(steadyNowMs() + normalizedTimeoutMs(timeoutMs), std::memory_order_release);
            if (av_read_frame(session.format, packet) < 0) {
                break;
            }
            if (packet->stream_index == session.videoStreamIndex && avcodec_send_packet(session.decoder, packet) >= 0) {
                while (avcodec_receive_frame(session.decoder, frame) >= 0) {
                    decoded = true;
                    break;
                }
            }
            av_packet_unref(packet);
        }
    }
    av_packet_free(&packet);
    av_frame_free(&frame);
    if (!decoded) {
        emit connectionTestFinished(false, QStringLiteral("RTSP opened but no frame was decoded."), generation);
        return;
    }
    emit connectionTestFinished(true,
                                QStringLiteral("RTSP OK (%1x%2 @ %3 FPS)")
                                  .arg(session.decoder->width)
                                  .arg(session.decoder->height)
                                  .arg(streamFps(session.videoStream), 0, 'f', 2),
                                generation);
#else
    cv::VideoCapture capture;
    if (!openCapture(capture, url, timeoutMs)) {
        emit connectionTestFinished(false, QStringLiteral("Unable to open RTSP stream."), generation);
        return;
    }

    int width = static_cast<int>(capture.get(cv::CAP_PROP_FRAME_WIDTH));
    int height = static_cast<int>(capture.get(cv::CAP_PROP_FRAME_HEIGHT));
    double fps = capture.get(cv::CAP_PROP_FPS);
    if (!validFps(fps)) {
        fps = kFallbackFps;
    }

    cv::Mat frame;
    if (!capture.read(frame) || frame.empty()) {
        emit connectionTestFinished(false, QStringLiteral("RTSP opened but no frame was decoded."), generation);
        return;
    }

    if (width <= 0 || height <= 0) {
        width = frame.cols;
        height = frame.rows;
    }

    emit connectionTestFinished(true, QStringLiteral("RTSP OK (%1x%2 @ %3 FPS)").arg(width).arg(height).arg(fps, 0, 'f', 2), generation);
#endif
}

void RtspDecoderWorker::startDecoding(const QString& url, int timeoutMs, int reconnectInitialDelayMs, int reconnectMaximumDelayMs,
                                      quint64 startSequence, qint64 startTimestampMs, quint64 generation) {
    // Clear only a previous generation's stop flag. A concurrent stop also
    // advances cancelledThroughGeneration_, so it cannot be lost here.
    stopRequested_.store(false, std::memory_order_release);
    if (generation <= cancelledThroughGeneration_.load(std::memory_order_acquire)) {
        stopRequested_.store(true, std::memory_order_release);
        emit playbackFinished(generation);
        return;
    }

    decoding_.store(true, std::memory_order_release);
    struct DecodingScope {
        std::atomic_bool* decoding;
        ~DecodingScope() {
            decoding->store(false, std::memory_order_release);
        }
    } decodingScope{&decoding_};

    // Recheck after publishing decoding_ because stopAndWaitForQuiescence()
    // may observe the worker between the queued-call entry and this point.
    if (generation <= cancelledThroughGeneration_.load(std::memory_order_acquire) || stopRequested_.load(std::memory_order_acquire)) {
        emit playbackFinished(generation);
        return;
    }
    clearLatestFrame();

    if (url.isEmpty()) {
        emit decoderError(QStringLiteral("No RTSP URL configured."), generation);
        return;
    }

    quint64 sequence = startSequence;
    qint64 lastFrameTimestampMs = startTimestampMs > 0 ? startTimestampMs - 1 : QDateTime::currentMSecsSinceEpoch() - 1;
    int reconnectAttempt = 0;

    while (!stopRequested_.load(std::memory_order_acquire)) {
#ifdef GUARD_ENABLE_FFMPEG
        RtspSession session;
        QString openError;
        if (!openRtspSession(url, timeoutMs, stopRequested_, &session, &openError)) {
            if (stopRequested_.load(std::memory_order_acquire)) {
                break;
            }
            reconnectAttempt = std::min(reconnectAttempt + 1, kMaximumReconnectAttemptsBeforeNotice);
            const int delayMs = reconnectDelayForAttempt(reconnectAttempt, reconnectInitialDelayMs, reconnectMaximumDelayMs);
            emit streamReconnecting(openError, reconnectAttempt, delayMs, generation);
            if (!waitForReconnectDelay(delayMs)) {
                break;
            }
            continue;
        }

        reconnectAttempt = 0;
        const double fps = streamFps(session.videoStream);
        emit encodedStreamInfoReady(makeStreamInfo(session), generation);
        emit streamOpened(session.decoder->width > 0 ? session.decoder->width : session.videoStream->codecpar->width,
                          session.decoder->height > 0 ? session.decoder->height : session.videoStream->codecpar->height, fps, generation);

        AVPacket* packet = av_packet_alloc();
        AVFrame* frame = av_frame_alloc();
        if (!packet || !frame) {
            av_packet_free(&packet);
            av_frame_free(&frame);
            emit decoderError(QStringLiteral("Unable to allocate FFmpeg RTSP buffers."), generation);
            return;
        }

        quint64 packetSequence = 0;
        qint64 sourceTimestampBaseMs = std::numeric_limits<qint64>::min();
        qint64 wallTimestampBaseMs = nextMonotonicWallTimestamp(lastFrameTimestampMs);
        QString sessionFailure;

        while (!stopRequested_.load(std::memory_order_acquire)) {
            session.interrupt.deadlineMs.store(steadyNowMs() + normalizedTimeoutMs(timeoutMs), std::memory_order_release);
            const int readResult = av_read_frame(session.format, packet);
            if (readResult < 0) {
                if (!stopRequested_.load(std::memory_order_acquire)) {
                    sessionFailure = QStringLiteral("RTSP read interrupted: %1").arg(ffmpegError(readResult));
                }
                break;
            }
            if (packet->stream_index != session.videoStreamIndex) {
                av_packet_unref(packet);
                continue;
            }

            const qint64 packetClock = packet->dts != AV_NOPTS_VALUE ? packet->dts : packet->pts;
            const qint64 packetSourceMs = timestampToMs(packetClock, session.videoStream->time_base);
            if (sourceTimestampBaseMs == std::numeric_limits<qint64>::min() && packetSourceMs != std::numeric_limits<qint64>::min()) {
                sourceTimestampBaseMs = packetSourceMs;
                wallTimestampBaseMs = nextMonotonicWallTimestamp(lastFrameTimestampMs);
            }
            qint64 packetPlaybackTimestampMs = nextMonotonicWallTimestamp(lastFrameTimestampMs);
            if (packetSourceMs != std::numeric_limits<qint64>::min() && sourceTimestampBaseMs != std::numeric_limits<qint64>::min()) {
                packetPlaybackTimestampMs = wallTimestampBaseMs + std::max<qint64>(0, packetSourceMs - sourceTimestampBaseMs);
            }

            if (packet->data && packet->size > 0) {
                guard::recording::EncodedVideoPacket encoded;
                encoded.generation = generation;
                encoded.packetSequence = packetSequence++;
                encoded.data = QByteArray(reinterpret_cast<const char*>(packet->data), packet->size);
                encoded.pts = packet->pts == AV_NOPTS_VALUE ? 0 : packet->pts;
                encoded.dts = packet->dts == AV_NOPTS_VALUE ? 0 : packet->dts;
                encoded.duration = std::max<qint64>(0, packet->duration);
                encoded.timeBaseNumerator = session.videoStream->time_base.num;
                encoded.timeBaseDenominator = session.videoStream->time_base.den;
                encoded.playbackTimestampMs = packetPlaybackTimestampMs;
                encoded.hasPts = packet->pts != AV_NOPTS_VALUE;
                encoded.hasDts = packet->dts != AV_NOPTS_VALUE;
                encoded.keyFrame = (packet->flags & AV_PKT_FLAG_KEY) != 0;
                emit encodedPacketReady(std::move(encoded));
            }

            const int sendResult = avcodec_send_packet(session.decoder, packet);
            av_packet_unref(packet);
            if (sendResult < 0 && sendResult != AVERROR(EAGAIN)) {
                sessionFailure = QStringLiteral("RTSP decoder rejected a packet: %1").arg(ffmpegError(sendResult));
                break;
            }

            for (;;) {
                const int receiveResult = avcodec_receive_frame(session.decoder, frame);
                if (receiveResult == AVERROR(EAGAIN) || receiveResult == AVERROR_EOF) {
                    break;
                }
                if (receiveResult < 0) {
                    sessionFailure = QStringLiteral("RTSP frame decoding failed: %1").arg(ffmpegError(receiveResult));
                    break;
                }

                const qint64 frameSourceMs = timestampToMs(frame->best_effort_timestamp, session.videoStream->time_base);
                qint64 frameTimestampMs = nextMonotonicWallTimestamp(lastFrameTimestampMs);
                if (frameSourceMs != std::numeric_limits<qint64>::min() && sourceTimestampBaseMs != std::numeric_limits<qint64>::min()) {
                    frameTimestampMs = wallTimestampBaseMs + std::max<qint64>(0, frameSourceMs - sourceTimestampBaseMs);
                    if (frameTimestampMs <= lastFrameTimestampMs) {
                        frameTimestampMs = lastFrameTimestampMs + 1;
                    }
                }

                QString conversionError;
                QImage image = convertFrame(session, frame, &conversionError);
                av_frame_unref(frame);
                if (image.isNull()) {
                    sessionFailure = conversionError;
                    break;
                }
                lastFrameTimestampMs = frameTimestampMs;
                publishFrame(std::move(image), sequence++, frameTimestampMs, generation);
            }
            if (!sessionFailure.isEmpty()) {
                break;
            }
        }

        av_packet_free(&packet);
        av_frame_free(&frame);

        if (stopRequested_.load(std::memory_order_acquire)) {
            break;
        }
        reconnectAttempt = std::min(reconnectAttempt + 1, kMaximumReconnectAttemptsBeforeNotice);
        const int delayMs = reconnectDelayForAttempt(reconnectAttempt, reconnectInitialDelayMs, reconnectMaximumDelayMs);
        emit streamReconnecting(sessionFailure.isEmpty() ? QStringLiteral("RTSP stream ended unexpectedly.") : sessionFailure, reconnectAttempt,
                                delayMs, generation);
        if (!waitForReconnectDelay(delayMs)) {
            break;
        }
#else
        cv::VideoCapture capture;
        if (!openCapture(capture, url, timeoutMs) || !capture.isOpened()) {
            reconnectAttempt = std::min(reconnectAttempt + 1, kMaximumReconnectAttemptsBeforeNotice);
            const int delayMs = reconnectDelayForAttempt(reconnectAttempt, reconnectInitialDelayMs, reconnectMaximumDelayMs);
            emit streamReconnecting(QStringLiteral("Unable to open RTSP stream."), reconnectAttempt, delayMs, generation);
            if (!waitForReconnectDelay(delayMs)) {
                break;
            }
            continue;
        }

        double fps = capture.get(cv::CAP_PROP_FPS);
        if (!validFps(fps)) {
            fps = kFallbackFps;
        }
        bool metadataPublished = false;
        bool receivedFrame = false;
        cv::Mat frame;
        while (!stopRequested_.load(std::memory_order_acquire)) {
            if (!capture.read(frame) || frame.empty()) {
                break;
            }
            receivedFrame = true;
            if (!metadataPublished) {
                emit streamOpened(frame.cols, frame.rows, fps, generation);
                metadataPublished = true;
                reconnectAttempt = 0;
            }
            lastFrameTimestampMs = nextMonotonicWallTimestamp(lastFrameTimestampMs);
            publishFrame(guard::media::bgrMatToRgbImage(frame), sequence++, lastFrameTimestampMs, generation);
        }
        capture.release();
        if (stopRequested_.load(std::memory_order_acquire)) {
            break;
        }
        reconnectAttempt = std::min(reconnectAttempt + 1, kMaximumReconnectAttemptsBeforeNotice);
        const int delayMs = reconnectDelayForAttempt(reconnectAttempt, reconnectInitialDelayMs, reconnectMaximumDelayMs);
        emit streamReconnecting(
          receivedFrame ? QStringLiteral("RTSP frame delivery stopped.") : QStringLiteral("RTSP connected but no frame arrived."), reconnectAttempt,
          delayMs, generation);
        if (!waitForReconnectDelay(delayMs)) {
            break;
        }
#endif
    }

    emit playbackFinished(generation);
}

void RtspDecoderWorker::stopDecoding() {
    requestStop();
}

void RtspDecoderWorker::publishFrame(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation) {
    if (frame.isNull()) {
        return;
    }

    bool shouldNotify = false;
    {
        QMutexLocker locker(&latestFrameMutex_);
        latestFrame_ = std::move(frame);
        latestSequence_ = sequence;
        latestTimestampMs_ = timestampMs;
        latestGeneration_ = generation;
        if (!frameNotificationPending_) {
            frameNotificationPending_ = true;
            shouldNotify = true;
        }
    }

    if (shouldNotify) {
        emit frameAvailable(generation);
    }
}

void RtspDecoderWorker::clearLatestFrame() {
    QMutexLocker locker(&latestFrameMutex_);
    latestFrame_ = QImage();
    latestSequence_ = 0;
    latestTimestampMs_ = 0;
    latestGeneration_ = 0;
    frameNotificationPending_ = false;
}

bool RtspDecoderWorker::waitForReconnectDelay(int delayMs) {
    int remainingMs = std::max(0, delayMs);
    while (remainingMs > 0 && !stopRequested_.load(std::memory_order_acquire)) {
        const int sleepMs = std::min(remainingMs, 50);
        QThread::msleep(static_cast<unsigned long>(sleepMs));
        remainingMs -= sleepMs;
    }
    return !stopRequested_.load(std::memory_order_acquire);
}
