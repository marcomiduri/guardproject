#pragma once

#include <QImage>
#include <QMutex>
#include <QObject>
#include <QString>

#include <atomic>

#include "media/recording/EncodedVideoTypes.h"

class RtspDecoderWorker : public QObject {
    Q_OBJECT

public:
    explicit RtspDecoderWorker(QObject* parent = nullptr);

    void requestStop() noexcept;
    void cancelGeneration(quint64 generation) noexcept;
    bool isDecoding() const noexcept;
    bool takeLatestFrame(QImage* frame, quint64* sequence, qint64* timestampMs, quint64* generation);

public slots:
    void testConnection(const QString& url, int timeoutMs, quint64 generation);
    void startDecoding(const QString& url, int timeoutMs, int reconnectInitialDelayMs, int reconnectMaximumDelayMs, quint64 startSequence,
                       qint64 startTimestampMs, quint64 generation);
    void stopDecoding();

signals:
    void connectionTestFinished(bool ok, QString message, quint64 generation);
    void streamOpened(int width, int height, double fps, quint64 generation);
    void streamReconnecting(QString message, int attempt, int delayMs, quint64 generation);
    void frameAvailable(quint64 generation);
    void encodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void encodedPacketReady(guard::recording::EncodedVideoPacket packet);
    void playbackFinished(quint64 generation);
    void decoderError(QString message, quint64 generation);

private:
    void publishFrame(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation);
    void clearLatestFrame();
    bool waitForReconnectDelay(int delayMs);

    std::atomic_bool stopRequested_{false};
    std::atomic_bool decoding_{false};
    std::atomic<quint64> cancelledThroughGeneration_{0};

    QMutex latestFrameMutex_;
    QImage latestFrame_;
    quint64 latestSequence_ = 0;
    qint64 latestTimestampMs_ = 0;
    quint64 latestGeneration_ = 0;
    bool frameNotificationPending_ = false;
};
