#pragma once

#include <QImage>
#include <QDateTime>
#include <QObject>
#include <QString>

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>

#include "media/recording/EncodedVideoTypes.h"
#include "media/recording/FfmpegMp4Muxer.h"
#include "media/recording/RecordingStorageManager.h"

namespace guard {
namespace recording {

class MotionVideoRecorder final : public QObject {
    Q_OBJECT

public:
    explicit MotionVideoRecorder(RecordingStorageManager* storageManager = nullptr, QObject* parent = nullptr);
    ~MotionVideoRecorder() override;

    MotionVideoRecorder(const MotionVideoRecorder&) = delete;
    MotionVideoRecorder& operator=(const MotionVideoRecorder&) = delete;

    void setEnabled(bool enabled);
    bool isEnabled() const noexcept;

    void startSource(const QString& cameraId, const QString& cameraName, const QString& streamId, quint64 generation,
                     const EncodedStreamInfo& streamInfo, const QString& detectionMode);
    void updateStreamInfo(quint64 generation, const EncodedStreamInfo& streamInfo);
    void stopSource(quint64 generation);
    void submitPacket(const EncodedVideoPacket& packet);
    void submitDecodedFrame(const QImage& frame, qint64 timestampMs, quint64 generation);

    void notifyMotionStarted(qint64 timestampMs, quint64 generation);
    void notifyMotionUpdated(qint64 timestampMs, quint64 generation);
    void notifyMotionEnded(qint64 timestampMs, quint64 generation);

    void shutdown();
    QString outputDirectory() const;

signals:
    void recordingStarted(QString path);
    void recordingFinished(QString path, quint64 writtenPackets);
    void recordingError(QString message);
    void recordingWarning(QString message);

private:
    enum class CommandType {
        SetEnabled,
        StartSource,
        UpdateStreamInfo,
        StopSource,
        Packet,
        DecodedFrame,
        MotionStarted,
        MotionUpdated,
        MotionEnded,
        Shutdown
    };

    enum class RecordingBackend { None, EncodedPackets, DecodedFrames };

    struct PacketItem {
        EncodedVideoPacket packet;
        std::size_t byteSize = 0;
    };

    struct FrameItem {
        QImage frame;
        qint64 timestampMs = 0;
        quint64 generation = 0;
        std::size_t byteSize = 0;
    };

    struct Command {
        CommandType type = CommandType::Packet;
        bool enabled = false;
        QString cameraId;
        QString cameraName;
        QString streamId;
        QString detectionMode;
        quint64 generation = 0;
        EncodedStreamInfo streamInfo;
        qint64 timestampMs = 0;
        PacketItem packet;
        FrameItem frame;
    };

    struct DecodedWriterState;

    void enqueue(Command command);
    void workerLoop();
    void processCommand(Command& command);
    void processTimerTick();

    void processSetEnabled(bool enabled);
    void processStartSource(const Command& command);
    void processUpdateStreamInfo(const Command& command);
    void processStopSource(quint64 generation);
    void processPacket(PacketItem packet);
    void processDecodedFrame(FrameItem frame);
    void processMotionStarted(qint64 timestampMs, quint64 generation);
    void processMotionEnded(qint64 timestampMs, quint64 generation);

    void cachePrePacket(PacketItem packet);
    void trimPreBuffer(qint64 newestTimestampMs);
    bool startEncodedRecordingFromBuffer(qint64 triggerTimestampMs);

    void cachePreFrame(FrameItem frame);
    void trimDecodedPreBuffer(qint64 newestTimestampMs);
    bool startDecodedRecordingFromBuffer(qint64 triggerTimestampMs);

    bool openEncodedMuxer();
    bool openDecodedWriter(const QImage& firstFrame);
    bool ensureOutputDirectory();
    bool writeEncodedPacket(const PacketItem& packet);
    bool writeDecodedFrame(const FrameItem& frame);
    void finalizeRecording(const QString& incompleteReason = QString());
    void abortRecording(const QString& message, bool preserveMotionState = false, const QString& incompleteReason = QStringLiteral("writer-error"));
    void resetSourceState();
    void writeRecordingMetadata(bool complete, const QString& incompleteReason, const QString& metadataPath, const QString& videoFileName,
                                qint64 fileSizeBytes);
    bool finalizeMetadata(bool complete, const QString& incompleteReason, const QString& videoFileName, qint64 fileSizeBytes);

    static std::size_t imageByteSize(const QImage& image) noexcept;

    static constexpr int kPreRecordMs = 2000;
    static constexpr int kPostRecordMs = 5000;
    static constexpr int kDecodedFallbackFrameIntervalMs = 67;  // approximately 15 FPS
    static constexpr double kDecodedFallbackFps = 15.0;

    static constexpr std::size_t kMaximumPreBufferBytes = 64u * 1024u * 1024u;
    static constexpr std::size_t kMaximumPreBufferPackets = 4096u;
    static constexpr std::size_t kMaximumPendingPacketBytes = 64u * 1024u * 1024u;
    static constexpr std::size_t kMaximumPendingPackets = 2048u;

    static constexpr std::size_t kMaximumDecodedPreBufferBytes = 192u * 1024u * 1024u;
    static constexpr std::size_t kMaximumDecodedPreBufferFrames = 60u;
    static constexpr std::size_t kMaximumPendingDecodedFrames = 8u;
    static constexpr std::size_t kMaximumPendingDecodedBytes = 64u * 1024u * 1024u;

    std::atomic<bool> enabledRequested_{false};
    std::atomic<bool> decodedFallbackRequested_{false};
    std::atomic<bool> shutdownRequested_{false};

    std::mutex queueMutex_;
    std::condition_variable queueCondition_;
    std::deque<Command> commands_;
    std::size_t pendingPacketCommands_ = 0;
    std::size_t pendingPacketBytes_ = 0;
    std::size_t pendingDecodedFrameCommands_ = 0;
    std::size_t pendingDecodedFrameBytes_ = 0;
    std::thread worker_;

    bool enabled_ = false;
    QString cameraId_;
    QString cameraName_;
    QString streamId_;
    QString detectionMode_;
    quint64 generation_ = 0;
    EncodedStreamInfo streamInfo_;

    std::deque<PacketItem> preBuffer_;
    std::size_t preBufferBytes_ = 0;

    std::deque<FrameItem> decodedPreBuffer_;
    std::size_t decodedPreBufferBytes_ = 0;
    qint64 lastAcceptedDecodedFrameTimestampMs_ = 0;

    bool motionActive_ = false;
    bool recording_ = false;
    RecordingBackend backend_ = RecordingBackend::None;
    bool encodedPacketObserved_ = false;
    bool encodedBackendFailed_ = false;
    qint64 pendingTriggerTimestampMs_ = 0;
    qint64 postRecordDeadlineMs_ = 0;
    qint64 lastPacketTimestampMs_ = 0;
    qint64 lastDecodedFrameTimestampMs_ = 0;
    quint64 lastPacketSequence_ = 0;
    bool hasLastPacketSequence_ = false;

    FfmpegMp4Muxer muxer_;
    std::unique_ptr<DecodedWriterState> decodedWriter_;
    RecordingStorageManager* storage_ = nullptr;
    RecordingPaths recordingPaths_;
    QDateTime recordingStartedAtUtc_;
    QString temporaryPath_;
    QString finalPath_;
    quint64 writtenPackets_ = 0;
    QString outputRoot_;
};

}  // namespace recording
}  // namespace guard
