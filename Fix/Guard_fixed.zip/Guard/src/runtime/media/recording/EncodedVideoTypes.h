#pragma once

#include <QByteArray>
#include <QMetaType>
#include <QString>
#include <QtGlobal>

namespace guard {
namespace recording {

enum class VideoCodec : int { Unknown = 0, H264, H265, Mpeg4Part2 };

struct EncodedStreamInfo {
    VideoCodec codec = VideoCodec::Unknown;
    int width = 0;
    int height = 0;
    int timeBaseNumerator = 0;
    int timeBaseDenominator = 0;
    QByteArray codecExtraData;
    bool mp4RemuxCompatible = false;

    bool isValid() const noexcept {
        return (codec == VideoCodec::H264 || codec == VideoCodec::H265 || codec == VideoCodec::Mpeg4Part2) && width > 0 && height > 0 &&
               timeBaseNumerator > 0 && timeBaseDenominator > 0 && mp4RemuxCompatible;
    }

    QString codecName() const {
        switch (codec) {
            case VideoCodec::H264:
                return QStringLiteral("H.264");
            case VideoCodec::H265:
                return QStringLiteral("H.265");
            case VideoCodec::Mpeg4Part2:
                return QStringLiteral("MPEG-4 Part 2");
            case VideoCodec::Unknown:
            default:
                return QStringLiteral("Unknown");
        }
    }
};

struct EncodedVideoPacket {
    quint64 generation = 0;
    quint64 packetSequence = 0;
    QByteArray data;
    qint64 pts = 0;
    qint64 dts = 0;
    qint64 duration = 0;
    int timeBaseNumerator = 0;
    int timeBaseDenominator = 0;
    qint64 playbackTimestampMs = 0;
    bool hasPts = false;
    bool hasDts = false;
    bool keyFrame = false;

    bool isValid() const noexcept {
        return generation != 0 && !data.isEmpty() && timeBaseNumerator > 0 && timeBaseDenominator > 0 && playbackTimestampMs > 0;
    }
};

}  // namespace recording
}  // namespace guard

Q_DECLARE_METATYPE(guard::recording::EncodedStreamInfo)
Q_DECLARE_METATYPE(guard::recording::EncodedVideoPacket)
