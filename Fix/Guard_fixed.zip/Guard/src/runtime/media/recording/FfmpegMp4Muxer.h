#pragma once

#include <QString>

#include <memory>

#include "media/recording/EncodedVideoTypes.h"

namespace guard {
namespace recording {

class FfmpegMp4Muxer final {
public:
    FfmpegMp4Muxer();
    ~FfmpegMp4Muxer();

    FfmpegMp4Muxer(const FfmpegMp4Muxer&) = delete;
    FfmpegMp4Muxer& operator=(const FfmpegMp4Muxer&) = delete;

    bool open(const QString& path, const EncodedStreamInfo& streamInfo);
    bool writePacket(const EncodedVideoPacket& packet);
    bool finalize();
    void abort();

    bool isOpen() const noexcept;
    QString errorString() const;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace recording
}  // namespace guard
