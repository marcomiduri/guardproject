#include "media/recording/RecordingStorageManager.h"

#include "media/recording/EncodedVideoTypes.h"

#include <QCoreApplication>
#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutexLocker>
#include <QRegularExpression>
#include <QSaveFile>
#include <QSettings>
#include <QStandardPaths>
#include <QStorageInfo>
#include <QTemporaryFile>
#include <QUuid>

#include <algorithm>
#include <thread>
#include <vector>

namespace guard {
namespace recording {
namespace {

constexpr const char* kRecordingRootEnv = "GUARD_RECORDING_ROOT";
constexpr const char* kPortableModeEnv = "GUARD_RECORDING_PORTABLE";
constexpr int kMaintenanceIntervalMs = 45 * 60 * 1000;

QString envString(const char* name) {
    return QString::fromLocal8Bit(qgetenv(name)).trimmed();
}

bool envFlag(const char* name) {
    const QString value = envString(name).toLower();
    return value == QStringLiteral("1") || value == QStringLiteral("true") || value == QStringLiteral("yes") || value == QStringLiteral("on");
}

QString settingsRecordingRoot() {
    QSettings settings;
    return settings.value(QStringLiteral("recording/rootPath")).toString().trimmed();
}

QString cleanAbsolutePath(const QString& path) {
    return QDir::cleanPath(QFileInfo(path.trimmed()).absoluteFilePath());
}

QString removeBraces(QString value) {
    value.remove(QLatin1Char('{'));
    value.remove(QLatin1Char('}'));
    return value;
}

QStringList windowsReservedNames() {
    return QStringList() << QStringLiteral("CON") << QStringLiteral("PRN") << QStringLiteral("AUX") << QStringLiteral("NUL") << QStringLiteral("COM1")
                         << QStringLiteral("COM2") << QStringLiteral("COM3") << QStringLiteral("COM4") << QStringLiteral("COM5")
                         << QStringLiteral("COM6") << QStringLiteral("COM7") << QStringLiteral("COM8") << QStringLiteral("COM9")
                         << QStringLiteral("LPT1") << QStringLiteral("LPT2") << QStringLiteral("LPT3") << QStringLiteral("LPT4")
                         << QStringLiteral("LPT5") << QStringLiteral("LPT6") << QStringLiteral("LPT7") << QStringLiteral("LPT8")
                         << QStringLiteral("LPT9");
}

bool isInsideRoot(const QString& root, const QString& candidate) {
    const QString rootPath = QDir(root).canonicalPath();
    const QString candidatePath = QFileInfo(candidate).canonicalFilePath();
    return !rootPath.isEmpty() && !candidatePath.isEmpty() && (candidatePath == rootPath || candidatePath.startsWith(rootPath + QLatin1Char('/')));
}

QJsonObject incompletePartialMetadata(const QString& partVideoPath, const QString& reason) {
    const QFileInfo info(partVideoPath);
    QJsonObject object;
    object.insert(QStringLiteral("schemaVersion"), 1);
    object.insert(QStringLiteral("eventType"), QStringLiteral("motion"));
    object.insert(QStringLiteral("complete"), false);
    object.insert(QStringLiteral("incompleteReason"), reason);
    object.insert(QStringLiteral("videoFile"), info.fileName());
    object.insert(QStringLiteral("fileSizeBytes"), static_cast<double>(info.exists() ? info.size() : 0));
    object.insert(QStringLiteral("detectedAtUtc"), RecordingStorageManager::metadataTimestampUtc(QDateTime::currentDateTimeUtc()));
    return object;
}

bool writeJsonFile(const QString& path, const QJsonObject& object) {
    QString error;
    return RecordingStorageManager::writeMetadataAtomically(path, QJsonDocument(object).toJson(QJsonDocument::Indented), &error);
}

struct FinalizedRecording {
    QString videoPath;
    QString metadataPath;
    QDateTime lastModifiedUtc;
    qint64 totalBytes = 0;
};

std::vector<FinalizedRecording> scanFinalizedRecordings(const QString& rootPath) {
    std::vector<FinalizedRecording> recordings;
    QDirIterator iterator(rootPath, QStringList() << QStringLiteral("*.mp4"), QDir::Files, QDirIterator::Subdirectories);
    while (iterator.hasNext()) {
        const QString videoPath = iterator.next();
        if (videoPath.endsWith(QStringLiteral(".part.mp4"), Qt::CaseInsensitive) || !isInsideRoot(rootPath, videoPath)) {
            continue;
        }
        QFileInfo videoInfo(videoPath);
        const QString metadataPath = QFileInfo(videoPath).absolutePath() + QLatin1Char('/') + videoInfo.completeBaseName() + QStringLiteral(".json");
        QFileInfo metadataInfo(metadataPath);
        FinalizedRecording recording;
        recording.videoPath = videoPath;
        recording.metadataPath = metadataInfo.exists() ? metadataPath : QString();
        recording.lastModifiedUtc = videoInfo.lastModified().toUTC();
        recording.totalBytes = videoInfo.size() + (metadataInfo.exists() ? metadataInfo.size() : 0);
        recordings.push_back(recording);
    }
    std::sort(recordings.begin(), recordings.end(),
              [](const FinalizedRecording& left, const FinalizedRecording& right) { return left.lastModifiedUtc < right.lastModifiedUtc; });
    return recordings;
}

void removeEmptyDirectories(const QString& rootPath) {
    QList<QString> directories;
    QDirIterator iterator(rootPath, QDir::Dirs | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
    while (iterator.hasNext()) {
        directories.push_back(iterator.next());
    }
    std::sort(directories.begin(), directories.end(), [](const QString& left, const QString& right) { return left.length() > right.length(); });
    for (const QString& directoryPath : directories) {
        QDir directory(directoryPath);
        if (directory.entryList(QDir::AllEntries | QDir::NoDotAndDotDot).isEmpty()) {
            QDir parent(QFileInfo(directoryPath).absolutePath());
            parent.rmdir(QFileInfo(directoryPath).fileName());
        }
    }
}

QString metadataPathForPartialVideo(const QString& partVideoPath) {
    QFileInfo info(partVideoPath);
    QString base = info.completeBaseName();
    base.replace(QStringLiteral(".part"), QString());
    return info.absolutePath() + QLatin1Char('/') + base + QStringLiteral(".json");
}

}  // namespace

RecordingStorageManager::RecordingStorageManager(QObject* parent) : QObject(parent) {
    config_ = defaultConfig();
    QString error;
    reloadRecordingRoot(&error);
    maintenanceTimer_.setInterval(kMaintenanceIntervalMs);
    connect(&maintenanceTimer_, &QTimer::timeout, this, [this]() { requestCleanup(RecordingCleanupReason::Periodic); });
}

RecordingStorageManager* RecordingStorageManager::instance() {
    static RecordingStorageManager* storage = new RecordingStorageManager();
    return storage;
}

RecordingStorageConfig RecordingStorageManager::defaultConfig() {
    RecordingStorageConfig config;
    config.recordingRoot = settingsRecordingRoot();
    config.portableMode = envFlag(kPortableModeEnv);
    return config;
}

bool RecordingStorageManager::isValidConfig(const RecordingStorageConfig& config, QString* errorMessage) {
    if (config.retentionDays < 1) {
        if (errorMessage)
            *errorMessage = QStringLiteral("retentionDays must be at least 1.");
        return false;
    }
    if (config.minimumFreeDiskBytes < 0) {
        if (errorMessage)
            *errorMessage = QStringLiteral("minimumFreeDiskBytes must not be negative.");
        return false;
    }
    if (config.maximumTotalRecordingBytes < 0) {
        if (errorMessage)
            *errorMessage = QStringLiteral("maximumTotalRecordingBytes must not be negative.");
        return false;
    }
    if (config.stalePartialFileAgeHours < 1) {
        if (errorMessage)
            *errorMessage = QStringLiteral("stalePartialFileAgeHours must be at least 1.");
        return false;
    }
    return true;
}

QString RecordingStorageManager::configuredRecordingRoot() const {
    QMutexLocker locker(&mutex_);
    return configuredRoot_;
}

QString RecordingStorageManager::effectiveRecordingRoot() const {
    QMutexLocker locker(&mutex_);
    return effectiveRoot_;
}

QString RecordingStorageManager::rootPath() const {
    return effectiveRecordingRoot();
}

RecordingRootSource RecordingStorageManager::recordingRootSource() const {
    QMutexLocker locker(&mutex_);
    return rootSource_;
}

const RecordingStorageConfig& RecordingStorageManager::config() const {
    return config_;
}

RecordingRootResolution RecordingStorageManager::previewRecordingRoot(const QString& configuredRoot) const {
    RecordingStorageConfig previewConfig;
    {
        QMutexLocker locker(&mutex_);
        previewConfig = config_;
    }
    previewConfig.recordingRoot = configuredRoot.trimmed();
    previewConfig.portableMode = envFlag(kPortableModeEnv);

    const ResolvedRoot resolved = resolveRecordingRoot(previewConfig);
    RecordingRootResolution resolution;
    resolution.configuredRoot = resolved.configuredRoot;
    resolution.effectiveRoot = resolved.effectiveRoot;
    resolution.source = resolved.source;
    return resolution;
}

RecordingStorageManager::ResolvedRoot RecordingStorageManager::resolveRecordingRoot(const RecordingStorageConfig& config, QString* errorMessage) {
    Q_UNUSED(errorMessage);
    ResolvedRoot resolved;
    resolved.configuredRoot = config.recordingRoot.trimmed();

    const QString envRoot = envString(kRecordingRootEnv);
    if (!envRoot.isEmpty()) {
        resolved.effectiveRoot = cleanAbsolutePath(envRoot);
        resolved.source = RecordingRootSource::EnvironmentOverride;
        return resolved;
    }

    if (!resolved.configuredRoot.isEmpty()) {
        resolved.effectiveRoot = cleanAbsolutePath(resolved.configuredRoot);
        resolved.source = RecordingRootSource::UserSetting;
        return resolved;
    }

    if (config.portableMode) {
        resolved.effectiveRoot = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("recordings"));
        resolved.source = RecordingRootSource::PortableMode;
        return resolved;
    }

    const QString appLocal = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (!appLocal.isEmpty()) {
        resolved.effectiveRoot = QDir(appLocal).filePath(QStringLiteral("recordings"));
        resolved.source = RecordingRootSource::AppLocalData;
        return resolved;
    }

    const QString movies = QStandardPaths::writableLocation(QStandardPaths::MoviesLocation);
    if (!movies.isEmpty()) {
        resolved.effectiveRoot = QDir(movies).filePath(QStringLiteral("Guard/recordings"));
        resolved.source = RecordingRootSource::MoviesFallback;
        return resolved;
    }

    resolved.effectiveRoot = QDir(QCoreApplication::applicationDirPath()).filePath(QStringLiteral("recordings"));
    resolved.source = RecordingRootSource::ExecutableFallback;
    return resolved;
}

bool RecordingStorageManager::applyResolvedRoot(const ResolvedRoot& resolved, QString* errorMessage) {
    if (resolved.effectiveRoot.trimmed().isEmpty()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Recording root could not be resolved.");
        return false;
    }
    const bool changed = resolved.effectiveRoot != effectiveRoot_ || resolved.configuredRoot != configuredRoot_ || resolved.source != rootSource_;
    configuredRoot_ = resolved.configuredRoot;
    effectiveRoot_ = resolved.effectiveRoot;
    rootSource_ = resolved.source;
    config_.recordingRoot = resolved.configuredRoot;
    config_.portableMode = envFlag(kPortableModeEnv);
    if (changed) {
        qInfo("Guard recording root updated. Configured root: %s Effective root: %s Source: %s", qPrintable(configuredRoot_),
              qPrintable(effectiveRoot_), qPrintable(rootSourceName(rootSource_)));
    }
    return true;
}

bool RecordingStorageManager::reloadRecordingRoot(QString* errorMessage) {
    RecordingStorageConfig nextConfig = config_;
    nextConfig.recordingRoot = settingsRecordingRoot();
    nextConfig.portableMode = envFlag(kPortableModeEnv);
    if (!isValidConfig(nextConfig, errorMessage)) {
        return false;
    }
    const ResolvedRoot resolved = resolveRecordingRoot(nextConfig, errorMessage);
    QString effective;
    bool changed = false;
    {
        QMutexLocker locker(&mutex_);
        config_ = nextConfig;
        changed = resolved.effectiveRoot != effectiveRoot_ || resolved.configuredRoot != configuredRoot_ || resolved.source != rootSource_;
        if (!applyResolvedRoot(resolved, errorMessage)) {
            return false;
        }
        effective = effectiveRoot_;
    }
    if (changed) {
        emit recordingRootChanged(effective);
    }
    return true;
}

bool RecordingStorageManager::setConfiguredRecordingRoot(const QString& path, QString* errorMessage) {
    QString normalized;
    if (!validateRecordingRoot(path, &normalized, errorMessage)) {
        return false;
    }
    QSettings settings;
    settings.setValue(QStringLiteral("recording/rootPath"), normalized);
    settings.sync();
    if (settings.status() != QSettings::NoError) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to save recording root setting.");
        return false;
    }
    if (!reloadRecordingRoot(errorMessage)) {
        return false;
    }
    requestCleanup(RecordingCleanupReason::RootChanged);
    return true;
}

bool RecordingStorageManager::clearConfiguredRecordingRoot(QString* errorMessage) {
    QSettings settings;
    settings.remove(QStringLiteral("recording/rootPath"));
    settings.sync();
    if (settings.status() != QSettings::NoError) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to clear recording root setting.");
        return false;
    }
    if (!reloadRecordingRoot(errorMessage)) {
        return false;
    }
    requestCleanup(RecordingCleanupReason::RootChanged);
    return true;
}

bool RecordingStorageManager::validateRecordingRoot(const QString& path, QString* normalizedPath, QString* errorMessage) const {
    const QString trimmed = path.trimmed();
    if (trimmed.isEmpty()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Recording root path is empty.");
        return false;
    }
    const QString normalized = cleanAbsolutePath(trimmed);
    QDir directory(normalized);
    if (!directory.exists() && !QDir().mkpath(normalized)) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to create recording root: %1").arg(normalized);
        return false;
    }
    QFileInfo info(normalized);
    if (!info.exists() || !info.isDir()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Recording root is not a directory: %1").arg(normalized);
        return false;
    }

    QTemporaryFile testFile(QDir(normalized).filePath(QStringLiteral(".guard-write-test-XXXXXX")));
    testFile.setAutoRemove(true);
    if (!testFile.open()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Recording root is not writable: %1").arg(normalized);
        return false;
    }
    testFile.close();

    QStorageInfo storage(normalized);
    const qint64 available = storage.isValid() ? storage.bytesAvailable() : -1;
    if (available >= 0 && available < config_.minimumFreeDiskBytes) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Insufficient free disk space at %1. Available=%2 bytes, required=%3 bytes.")
                              .arg(normalized)
                              .arg(available)
                              .arg(config_.minimumFreeDiskBytes);
        }
        return false;
    }

    if (normalizedPath) {
        *normalizedPath = normalized;
    }
    return true;
}

bool RecordingStorageManager::ensureRoot(QString* errorMessage) const {
    return ensureWritableDirectory(effectiveRecordingRoot(), errorMessage);
}

bool RecordingStorageManager::ensureWritableDirectory(const QString& directoryPath, QString* errorMessage) const {
    QString normalized;
    return validateRecordingRoot(directoryPath, &normalized, errorMessage);
}

bool RecordingStorageManager::hasMinimumFreeSpace(QString* errorMessage) const {
    const QString root = effectiveRecordingRoot();
    QStorageInfo storage(root);
    if (!storage.isValid() || storage.bytesAvailable() >= config_.minimumFreeDiskBytes) {
        return true;
    }
    if (errorMessage) {
        *errorMessage = QStringLiteral("Low recording disk space. Root=%1 Available=%2 Required=%3")
                          .arg(root)
                          .arg(storage.bytesAvailable())
                          .arg(config_.minimumFreeDiskBytes);
    }
    return false;
}

QString RecordingStorageManager::cameraDirectory(const QString& cameraId) const {
    return QDir(effectiveRecordingRoot()).filePath(sanitizePathComponent(cameraId));
}

QString RecordingStorageManager::dateDirectory(const QString& cameraId, const QDateTime& utcStartTime) const {
    const QDateTime utc = utcStartTime.toUTC();
    return QDir(cameraDirectory(cameraId)).filePath(utc.date().toString(QStringLiteral("yyyy-MM-dd")));
}

RecordingPaths RecordingStorageManager::createPaths(const QString& cameraId, const QString& eventType, const QDateTime& utcStartTime) const {
    const QDateTime utc = utcStartTime.toUTC();
    const QString eventId = removeBraces(QUuid::createUuid().toString()).toLower();
    const QString shortEventId = eventId.left(12);
    const QString safeType = sanitizePathComponent(eventType, QStringLiteral("motion"));
    RecordingPaths paths;
    paths.directoryPath = dateDirectory(cameraId, utc);
    paths.eventId = eventId;
    paths.baseName = QStringLiteral("%1_%2_%3").arg(fileTimestampUtc(utc), safeType, shortEventId);
    const QDir directory(paths.directoryPath);
    paths.temporaryVideoPath = directory.filePath(paths.baseName + QStringLiteral(".part.mp4"));
    paths.finalVideoPath = directory.filePath(paths.baseName + QStringLiteral(".mp4"));
    paths.temporaryMetadataPath = directory.filePath(paths.baseName + QStringLiteral(".part.json"));
    paths.finalMetadataPath = directory.filePath(paths.baseName + QStringLiteral(".json"));
    return paths;
}

QString RecordingStorageManager::sanitizePathComponent(const QString& value, const QString& fallback) {
    QString sanitized = removeBraces(value.trimmed());
    sanitized.replace(QRegularExpression(QStringLiteral("[\\\\/:*?\"<>|]")), QStringLiteral("_"));
    sanitized.replace(QRegularExpression(QStringLiteral("[^A-Za-z0-9_-]")), QStringLiteral("_"));
    sanitized.replace(QRegularExpression(QStringLiteral("_+")), QStringLiteral("_"));
    while (sanitized.endsWith(QLatin1Char('.')) || sanitized.endsWith(QLatin1Char('_'))) {
        sanitized.chop(1);
    }
    while (sanitized.startsWith(QLatin1Char('.')) || sanitized.startsWith(QLatin1Char('_'))) {
        sanitized.remove(0, 1);
    }
    if (sanitized == QStringLiteral("..") || sanitized == QStringLiteral(".")) {
        sanitized.clear();
    }
    if (sanitized.isEmpty()) {
        sanitized = fallback;
    }
    if (windowsReservedNames().contains(sanitized.toUpper())) {
        sanitized.append(QStringLiteral("_camera"));
    }
    return sanitized;
}

QString RecordingStorageManager::rootSourceName(RecordingRootSource source) {
    switch (source) {
        case RecordingRootSource::EnvironmentOverride:
            return QStringLiteral("environment");
        case RecordingRootSource::UserSetting:
            return QStringLiteral("user-setting");
        case RecordingRootSource::PortableMode:
            return QStringLiteral("portable");
        case RecordingRootSource::AppLocalData:
            return QStringLiteral("app-local-data");
        case RecordingRootSource::MoviesFallback:
            return QStringLiteral("movies-fallback");
        case RecordingRootSource::ExecutableFallback:
        default:
            return QStringLiteral("executable-fallback");
    }
}

QString RecordingStorageManager::cleanupReasonName(RecordingCleanupReason reason) {
    switch (reason) {
        case RecordingCleanupReason::Startup:
            return QStringLiteral("startup");
        case RecordingCleanupReason::Periodic:
            return QStringLiteral("periodic");
        case RecordingCleanupReason::RecordingCompleted:
            return QStringLiteral("recording-completed");
        case RecordingCleanupReason::LowDiskSpace:
            return QStringLiteral("low-disk-space");
        case RecordingCleanupReason::RootChanged:
            return QStringLiteral("root-changed");
        case RecordingCleanupReason::Manual:
        default:
            return QStringLiteral("manual");
    }
}

QString RecordingStorageManager::metadataTimestampUtc(const QDateTime& utcTime) {
    return utcTime.toUTC().toString(QStringLiteral("yyyy-MM-dd'T'HH:mm:ss.zzz'Z'"));
}

QString RecordingStorageManager::fileTimestampUtc(const QDateTime& utcTime) {
    return utcTime.toUTC().toString(QStringLiteral("yyyyMMdd'T'HHmmss.zzz'Z'"));
}

QString RecordingStorageManager::backendName(int backend) {
    switch (backend) {
        case 1:
            return QStringLiteral("encoded-packets");
        case 2:
            return QStringLiteral("decoded-frames");
        default:
            return QStringLiteral("unknown");
    }
}

QString RecordingStorageManager::codecName(int codec) {
    switch (static_cast<VideoCodec>(codec)) {
        case VideoCodec::H264:
            return QStringLiteral("h264");
        case VideoCodec::H265:
            return QStringLiteral("h265");
        case VideoCodec::Mpeg4Part2:
            return QStringLiteral("mpeg4-part2");
        case VideoCodec::Unknown:
        default:
            return QStringLiteral("unknown");
    }
}

bool RecordingStorageManager::writeMetadataAtomically(const QString& path, const QByteArray& json, QString* errorMessage) {
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to open metadata file: %1").arg(path);
        return false;
    }
    if (file.write(json) != json.size()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to write metadata file: %1").arg(path);
        return false;
    }
    if (!file.commit()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to commit metadata file: %1").arg(path);
        return false;
    }
    return true;
}

bool RecordingStorageManager::finalizeMetadataFile(const QString& temporaryPath, const QString& finalPath, QString* errorMessage) {
    QFile::remove(finalPath);
    if (!QFile::rename(temporaryPath, finalPath)) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Unable to finalize metadata file: %1").arg(temporaryPath);
        return false;
    }
    return true;
}

void RecordingStorageManager::startMaintenance() {
    QString error;
    if (!ensureRoot(&error)) {
        qWarning("Guard recording root unavailable: %s", qPrintable(error));
        return;
    }
    qInfo("Guard recording root: %s", qPrintable(effectiveRecordingRoot()));
    qInfo("Guard recording root source: %s", qPrintable(rootSourceName(recordingRootSource())));
    if (!maintenanceTimer_.isActive()) {
        maintenanceTimer_.start();
    }
    requestCleanup(RecordingCleanupReason::Startup);
}

void RecordingStorageManager::stopMaintenance() {
    maintenanceTimer_.stop();
}

void RecordingStorageManager::requestCleanup(RecordingCleanupReason reason) {
    {
        QMutexLocker locker(&mutex_);
        if (cleanupRunning_) {
            cleanupPending_ = true;
            return;
        }
        cleanupRunning_ = true;
    }
    runMaintenanceAsync(reason);
}

void RecordingStorageManager::runMaintenanceAsync(RecordingCleanupReason reason) {
    RecordingStorageConfig configSnapshot;
    QString rootSnapshot;
    {
        QMutexLocker locker(&mutex_);
        configSnapshot = config_;
        rootSnapshot = effectiveRoot_;
    }

    std::thread([this, configSnapshot, rootSnapshot, reason]() {
        qInfo("Guard recording maintenance started: reason=%s root=%s", qPrintable(cleanupReasonName(reason)), qPrintable(rootSnapshot));
        recoverStalePartials(configSnapshot, rootSnapshot);
        cleanupRetention(configSnapshot, rootSnapshot);
        bool shouldRunAgain = false;
        {
            QMutexLocker locker(&mutex_);
            shouldRunAgain = cleanupPending_;
            cleanupPending_ = false;
            cleanupRunning_ = false;
        }
        if (shouldRunAgain) {
            requestCleanup(RecordingCleanupReason::Manual);
        }
    }).detach();
}

void RecordingStorageManager::recoverStalePartials(const RecordingStorageConfig& config, const QString& rootPath) {
    if (rootPath.trimmed().isEmpty() || !QDir(rootPath).exists()) {
        return;
    }
    const QDateTime cutoff = QDateTime::currentDateTimeUtc().addSecs(-config.stalePartialFileAgeHours * 3600);
    QDirIterator iterator(rootPath, QStringList() << QStringLiteral("*.part.mp4") << QStringLiteral("*.part.json"), QDir::Files,
                          QDirIterator::Subdirectories);
    while (iterator.hasNext()) {
        const QString path = iterator.next();
        QFileInfo info(path);
        if (!isInsideRoot(rootPath, path) || info.lastModified().toUTC() > cutoff) {
            continue;
        }

        if (path.endsWith(QStringLiteral(".part.mp4"), Qt::CaseInsensitive)) {
            const QString metadataPath = metadataPathForPartialVideo(path);
            if (info.size() <= 0) {
                QFile::remove(path);
                if (QFileInfo::exists(metadataPath)) {
                    writeJsonFile(metadataPath, incompletePartialMetadata(path, QStringLiteral("missing-partial-video")));
                }
                qInfo("Guard stale recovery removed empty partial video: %s", qPrintable(path));
                continue;
            }
            const QString reason =
              QFileInfo::exists(metadataPath) ? QStringLiteral("application-shutdown") : QStringLiteral("missing-partial-metadata");
            writeJsonFile(metadataPath, incompletePartialMetadata(path, reason));
            qInfo("Guard stale recovery preserved partial video: %s", qPrintable(path));
            continue;
        }

        if (path.endsWith(QStringLiteral(".part.json"), Qt::CaseInsensitive)) {
            QString videoPath = path;
            videoPath.chop(QStringLiteral(".part.json").length());
            videoPath += QStringLiteral(".part.mp4");
            if (!QFileInfo::exists(videoPath)) {
                writeJsonFile(path, incompletePartialMetadata(videoPath, QStringLiteral("missing-partial-video")));
                qInfo("Guard stale recovery marked orphan partial metadata incomplete: %s", qPrintable(path));
            }
        }
    }
}

void RecordingStorageManager::cleanupRetention(const RecordingStorageConfig& config, const QString& rootPath) {
    if (rootPath.trimmed().isEmpty() || !QDir(rootPath).exists()) {
        return;
    }
    std::vector<FinalizedRecording> recordings = scanFinalizedRecordings(rootPath);
    const QDateTime expiration = QDateTime::currentDateTimeUtc().addDays(-config.retentionDays);
    for (const FinalizedRecording& recording : recordings) {
        if (recording.lastModifiedUtc >= expiration) {
            continue;
        }
        QFile::remove(recording.videoPath);
        if (!recording.metadataPath.isEmpty()) {
            QFile::remove(recording.metadataPath);
        }
        qInfo("Guard retention deleted expired recording: %s", qPrintable(recording.videoPath));
    }

    recordings = scanFinalizedRecordings(rootPath);
    auto totalBytes = [&recordings]() {
        qint64 bytes = 0;
        for (const FinalizedRecording& recording : recordings) {
            bytes += recording.totalBytes;
        }
        return bytes;
    };

    auto deleteOldest = [&recordings](const QString& reason) {
        if (recordings.empty()) {
            return false;
        }
        const FinalizedRecording recording = recordings.front();
        recordings.erase(recordings.begin());
        QFile::remove(recording.videoPath);
        if (!recording.metadataPath.isEmpty()) {
            QFile::remove(recording.metadataPath);
        }
        qInfo("Guard retention deleted recording (%s): %s", qPrintable(reason), qPrintable(recording.videoPath));
        return true;
    };

    QStorageInfo storage(rootPath);
    while (config.minimumFreeDiskBytes > 0 && storage.isValid() && storage.bytesAvailable() < config.minimumFreeDiskBytes &&
           deleteOldest(QStringLiteral("low-disk-space"))) {
        storage.refresh();
    }

    while (config.maximumTotalRecordingBytes > 0 && totalBytes() > config.maximumTotalRecordingBytes &&
           deleteOldest(QStringLiteral("maximum-total-size"))) {
    }

    removeEmptyDirectories(rootPath);
}

}  // namespace recording
}  // namespace guard
