#pragma once

#include <QDateTime>
#include <QMutex>
#include <QObject>
#include <QString>
#include <QTimer>

namespace guard {
namespace recording {

struct RecordingStorageConfig {
    QString recordingRoot;
    bool portableMode = false;
    int retentionDays = 15;
    qint64 minimumFreeDiskBytes = 2LL * 1024LL * 1024LL * 1024LL;
    qint64 maximumTotalRecordingBytes = 0;
    int stalePartialFileAgeHours = 24;
};

struct RecordingPaths {
    QString directoryPath;
    QString baseName;
    QString eventId;
    QString temporaryVideoPath;
    QString finalVideoPath;
    QString temporaryMetadataPath;
    QString finalMetadataPath;
};

enum class RecordingRootSource { EnvironmentOverride, UserSetting, PortableMode, AppLocalData, MoviesFallback, ExecutableFallback };

struct RecordingRootResolution {
    QString configuredRoot;
    QString effectiveRoot;
    RecordingRootSource source = RecordingRootSource::ExecutableFallback;
};

enum class RecordingCleanupReason { Startup, Periodic, RecordingCompleted, LowDiskSpace, RootChanged, Manual };

class RecordingStorageManager final : public QObject {
    Q_OBJECT

public:
    explicit RecordingStorageManager(QObject* parent = nullptr);

    static RecordingStorageManager* instance();

    QString configuredRecordingRoot() const;
    QString effectiveRecordingRoot() const;
    QString rootPath() const;
    RecordingRootSource recordingRootSource() const;
    const RecordingStorageConfig& config() const;
    RecordingRootResolution previewRecordingRoot(const QString& configuredRoot) const;

    bool setConfiguredRecordingRoot(const QString& path, QString* errorMessage = nullptr);
    bool clearConfiguredRecordingRoot(QString* errorMessage = nullptr);
    bool reloadRecordingRoot(QString* errorMessage = nullptr);
    bool validateRecordingRoot(const QString& path, QString* normalizedPath, QString* errorMessage) const;
    bool ensureRoot(QString* errorMessage = nullptr) const;
    bool ensureWritableDirectory(const QString& directoryPath, QString* errorMessage = nullptr) const;
    bool hasMinimumFreeSpace(QString* errorMessage = nullptr) const;

    QString cameraDirectory(const QString& cameraId) const;
    QString dateDirectory(const QString& cameraId, const QDateTime& utcStartTime) const;
    RecordingPaths createPaths(const QString& cameraId, const QString& eventType, const QDateTime& utcStartTime) const;

    static RecordingStorageConfig defaultConfig();
    static bool isValidConfig(const RecordingStorageConfig& config, QString* errorMessage = nullptr);
    static QString sanitizePathComponent(const QString& value, const QString& fallback = QStringLiteral("camera"));
    static QString rootSourceName(RecordingRootSource source);
    static QString cleanupReasonName(RecordingCleanupReason reason);
    static QString metadataTimestampUtc(const QDateTime& utcTime);
    static QString fileTimestampUtc(const QDateTime& utcTime);
    static QString backendName(int backend);
    static QString codecName(int codec);
    static bool writeMetadataAtomically(const QString& path, const QByteArray& json, QString* errorMessage = nullptr);
    static bool finalizeMetadataFile(const QString& temporaryPath, const QString& finalPath, QString* errorMessage = nullptr);

public slots:
    void startMaintenance();
    void stopMaintenance();
    void requestCleanup(RecordingCleanupReason reason);

signals:
    void recordingRootChanged(QString effectiveRoot);

private:
    struct ResolvedRoot {
        QString configuredRoot;
        QString effectiveRoot;
        RecordingRootSource source = RecordingRootSource::ExecutableFallback;
    };

    static ResolvedRoot resolveRecordingRoot(const RecordingStorageConfig& config, QString* errorMessage = nullptr);
    static void recoverStalePartials(const RecordingStorageConfig& config, const QString& rootPath);
    static void cleanupRetention(const RecordingStorageConfig& config, const QString& rootPath);

    void runMaintenanceAsync(RecordingCleanupReason reason);
    bool applyResolvedRoot(const ResolvedRoot& resolved, QString* errorMessage);

    RecordingStorageConfig config_;
    QString configuredRoot_;
    QString effectiveRoot_;
    RecordingRootSource rootSource_ = RecordingRootSource::ExecutableFallback;
    QTimer maintenanceTimer_;
    mutable QMutex mutex_;
    bool cleanupRunning_ = false;
    bool cleanupPending_ = false;
};

}  // namespace recording
}  // namespace guard
