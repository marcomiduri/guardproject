#include "media/recording/MotionVideoRecorder.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>

#include <algorithm>
#include <chrono>
#include <cstring>
#include <iterator>
#include <utility>

#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>

namespace guard {
namespace recording {
namespace {

bool sameEncodedStreamInfo(const EncodedStreamInfo& left, const EncodedStreamInfo& right) {
    return left.codec == right.codec && left.width == right.width && left.height == right.height &&
           left.timeBaseNumerator == right.timeBaseNumerator && left.timeBaseDenominator == right.timeBaseDenominator &&
           left.codecExtraData == right.codecExtraData && left.mp4RemuxCompatible == right.mp4RemuxCompatible;
}

}  // namespace

struct MotionVideoRecorder::DecodedWriterState {
    cv::VideoWriter writer;
    cv::Mat bgrScratch;
    cv::Mat resizedScratch;
    int width = 0;
    int height = 0;
};

MotionVideoRecorder::MotionVideoRecorder(RecordingStorageManager* storageManager, QObject* parent)
: QObject(parent), decodedWriter_(new DecodedWriterState()), storage_(storageManager ? storageManager : RecordingStorageManager::instance()) {
    outputRoot_ = storage_->effectiveRecordingRoot();
    worker_ = std::thread(&MotionVideoRecorder::workerLoop, this);
}

MotionVideoRecorder::~MotionVideoRecorder() {
    shutdown();
}

void MotionVideoRecorder::setEnabled(bool enabled) {
    enabledRequested_.store(enabled);
    if (!enabled) {
        decodedFallbackRequested_.store(false);
    }
    Command command;
    command.type = CommandType::SetEnabled;
    command.enabled = enabled;
    enqueue(std::move(command));
}

bool MotionVideoRecorder::isEnabled() const noexcept {
    return enabledRequested_.load();
}

void MotionVideoRecorder::startSource(const QString& cameraId, const QString& cameraName, const QString& streamId, quint64 generation,
                                      const EncodedStreamInfo& streamInfo, const QString& detectionMode) {
    Command command;
    command.type = CommandType::StartSource;
    command.cameraId = cameraId;
    command.cameraName = cameraName;
    command.streamId = streamId;
    command.detectionMode = detectionMode;
    command.generation = generation;
    command.streamInfo = streamInfo;
    enqueue(std::move(command));
}

void MotionVideoRecorder::updateStreamInfo(quint64 generation, const EncodedStreamInfo& streamInfo) {
    Command command;
    command.type = CommandType::UpdateStreamInfo;
    command.generation = generation;
    command.streamInfo = streamInfo;
    enqueue(std::move(command));
}

QString MotionVideoRecorder::outputDirectory() const {
    return storage_ ? storage_->effectiveRecordingRoot() : outputRoot_;
}

void MotionVideoRecorder::stopSource(quint64 generation) {
    Command command;
    command.type = CommandType::StopSource;
    command.generation = generation;
    enqueue(std::move(command));
}

void MotionVideoRecorder::submitPacket(const EncodedVideoPacket& packet) {
    if (!enabledRequested_.load() || !packet.isValid()) {
        return;
    }
    Command command;
    command.type = CommandType::Packet;
    command.packet.packet = packet;
    command.packet.byteSize = static_cast<std::size_t>(packet.data.size());
    enqueue(std::move(command));
}

void MotionVideoRecorder::submitDecodedFrame(const QImage& frame, qint64 timestampMs, quint64 generation) {
    if (!enabledRequested_.load() || !decodedFallbackRequested_.load() || frame.isNull() || generation == 0 || timestampMs <= 0) {
        return;
    }

    Command command;
    command.type = CommandType::DecodedFrame;
    command.frame.frame = frame;
    command.frame.timestampMs = timestampMs;
    command.frame.generation = generation;
    command.frame.byteSize = imageByteSize(frame);
    enqueue(std::move(command));
}

void MotionVideoRecorder::notifyMotionStarted(qint64 timestampMs, quint64 generation) {
    if (!enabledRequested_.load()) {
        return;
    }
    Command command;
    command.type = CommandType::MotionStarted;
    command.timestampMs = timestampMs;
    command.generation = generation;
    enqueue(std::move(command));
}

void MotionVideoRecorder::notifyMotionUpdated(qint64 timestampMs, quint64 generation) {
    if (!enabledRequested_.load()) {
        return;
    }
    Command command;
    command.type = CommandType::MotionUpdated;
    command.timestampMs = timestampMs;
    command.generation = generation;
    enqueue(std::move(command));
}

void MotionVideoRecorder::notifyMotionEnded(qint64 timestampMs, quint64 generation) {
    if (!enabledRequested_.load()) {
        return;
    }
    Command command;
    command.type = CommandType::MotionEnded;
    command.timestampMs = timestampMs;
    command.generation = generation;
    enqueue(std::move(command));
}

void MotionVideoRecorder::shutdown() {
    bool expected = false;
    if (!shutdownRequested_.compare_exchange_strong(expected, true)) {
        if (worker_.joinable() && worker_.get_id() != std::this_thread::get_id()) {
            worker_.join();
        }
        return;
    }

    decodedFallbackRequested_.store(false);
    Command command;
    command.type = CommandType::Shutdown;
    {
        std::lock_guard<std::mutex> lock(queueMutex_);
        commands_.push_back(std::move(command));
    }
    queueCondition_.notify_one();
    if (worker_.joinable() && worker_.get_id() != std::this_thread::get_id()) {
        worker_.join();
    }
}

void MotionVideoRecorder::enqueue(Command command) {
    if (shutdownRequested_.load()) {
        return;
    }

    bool droppedPacket = false;
    bool droppedFrame = false;
    {
        std::lock_guard<std::mutex> lock(queueMutex_);
        if (shutdownRequested_.load()) {
            return;
        }

        if (command.type == CommandType::Packet) {
            while ((pendingPacketCommands_ >= kMaximumPendingPackets || pendingPacketBytes_ + command.packet.byteSize > kMaximumPendingPacketBytes) &&
                   !commands_.empty()) {
                auto oldestPacket =
                  std::find_if(commands_.begin(), commands_.end(), [](const Command& queued) { return queued.type == CommandType::Packet; });
                if (oldestPacket == commands_.end()) {
                    return;
                }
                pendingPacketBytes_ -= std::min(pendingPacketBytes_, oldestPacket->packet.byteSize);
                if (pendingPacketCommands_ > 0) {
                    --pendingPacketCommands_;
                }
                commands_.erase(oldestPacket);
                droppedPacket = true;
            }
            ++pendingPacketCommands_;
            pendingPacketBytes_ += command.packet.byteSize;
        } else if (command.type == CommandType::DecodedFrame) {
            while ((pendingDecodedFrameCommands_ >= kMaximumPendingDecodedFrames ||
                    pendingDecodedFrameBytes_ + command.frame.byteSize > kMaximumPendingDecodedBytes) &&
                   !commands_.empty()) {
                auto oldestFrame =
                  std::find_if(commands_.begin(), commands_.end(), [](const Command& queued) { return queued.type == CommandType::DecodedFrame; });
                if (oldestFrame == commands_.end()) {
                    return;
                }
                pendingDecodedFrameBytes_ -= std::min(pendingDecodedFrameBytes_, oldestFrame->frame.byteSize);
                if (pendingDecodedFrameCommands_ > 0) {
                    --pendingDecodedFrameCommands_;
                }
                commands_.erase(oldestFrame);
                droppedFrame = true;
            }
            ++pendingDecodedFrameCommands_;
            pendingDecodedFrameBytes_ += command.frame.byteSize;
        }
        commands_.push_back(std::move(command));
    }

    if (droppedPacket) {
        emit recordingWarning(QStringLiteral("Recording packet queue pressure: an older encoded packet was dropped."));
    }
    if (droppedFrame) {
        emit recordingWarning(QStringLiteral("Decoded fallback queue pressure: an older fallback frame was replaced."));
    }
    queueCondition_.notify_one();
}

void MotionVideoRecorder::workerLoop() {
    for (;;) {
        Command command;
        bool hasCommand = false;
        {
            std::unique_lock<std::mutex> lock(queueMutex_);
            queueCondition_.wait_for(lock, std::chrono::milliseconds(100), [this]() { return !commands_.empty(); });
            if (!commands_.empty()) {
                command = std::move(commands_.front());
                commands_.pop_front();
                hasCommand = true;
                if (command.type == CommandType::Packet && pendingPacketCommands_ > 0) {
                    --pendingPacketCommands_;
                    pendingPacketBytes_ -= std::min(pendingPacketBytes_, command.packet.byteSize);
                } else if (command.type == CommandType::DecodedFrame && pendingDecodedFrameCommands_ > 0) {
                    --pendingDecodedFrameCommands_;
                    pendingDecodedFrameBytes_ -= std::min(pendingDecodedFrameBytes_, command.frame.byteSize);
                }
            }
        }

        if (!hasCommand) {
            processTimerTick();
            continue;
        }
        if (command.type == CommandType::Shutdown) {
            finalizeRecording(QStringLiteral("application-shutdown"));
            resetSourceState();
            return;
        }
        processCommand(command);
        processTimerTick();
    }
}

void MotionVideoRecorder::processTimerTick() {
    if (!recording_ || motionActive_ || postRecordDeadlineMs_ <= 0) {
        return;
    }

    // Camera packet delivery can stop during a network interruption. Finalize
    // the normal post-roll clip from wall time as well as packet/frame
    // timestamps so a valid recording is not left indefinitely as a
    // .part.mp4 file.
    if (QDateTime::currentMSecsSinceEpoch() >= postRecordDeadlineMs_) {
        finalizeRecording();
        postRecordDeadlineMs_ = 0;
    }
}

void MotionVideoRecorder::processCommand(Command& command) {
    switch (command.type) {
        case CommandType::SetEnabled:
            processSetEnabled(command.enabled);
            break;
        case CommandType::StartSource:
            processStartSource(command);
            break;
        case CommandType::UpdateStreamInfo:
            processUpdateStreamInfo(command);
            break;
        case CommandType::StopSource:
            processStopSource(command.generation);
            break;
        case CommandType::Packet:
            processPacket(std::move(command.packet));
            break;
        case CommandType::DecodedFrame:
            processDecodedFrame(std::move(command.frame));
            break;
        case CommandType::MotionStarted:
            processMotionStarted(command.timestampMs, command.generation);
            break;
        case CommandType::MotionUpdated:
            if (enabled_ && command.generation == generation_) {
                motionActive_ = true;
                postRecordDeadlineMs_ = 0;
                pendingTriggerTimestampMs_ = command.timestampMs;

                // Keep decoded fallback frames flowing until an encoded
                // recording has actually opened. Merely seeing encoded stream
                // metadata or non-key packets is not enough to guarantee that
                // an MP4 can start immediately.
                if (!recording_) {
                    decodedFallbackRequested_.store(true);
                    if (!startEncodedRecordingFromBuffer(command.timestampMs)) {
                        startDecodedRecordingFromBuffer(command.timestampMs);
                    }
                }
            }
            break;
        case CommandType::MotionEnded:
            processMotionEnded(command.timestampMs, command.generation);
            break;
        case CommandType::Shutdown:
            break;
    }
}

void MotionVideoRecorder::processSetEnabled(bool enabled) {
    enabled_ = enabled;
    if (enabled_) {
        ensureOutputDirectory();

        // Always maintain a throttled decoded pre-roll buffer while the
        // recorder is idle. It is the guaranteed fallback when encoded
        // packets arrive without a usable keyframe or when remuxing cannot be
        // opened. The flag is disabled only after an encoded recording has
        // successfully started.
        decodedFallbackRequested_.store(true);
    } else {
        decodedFallbackRequested_.store(false);
        motionActive_ = false;
        pendingTriggerTimestampMs_ = 0;
        postRecordDeadlineMs_ = 0;
        finalizeRecording(QStringLiteral("recording-disabled"));
        preBuffer_.clear();
        preBufferBytes_ = 0;
        decodedPreBuffer_.clear();
        decodedPreBufferBytes_ = 0;
    }
}

void MotionVideoRecorder::processStartSource(const Command& command) {
    finalizeRecording(QStringLiteral("source-generation-changed"));
    resetSourceState();
    cameraId_ = command.cameraId;
    cameraName_ = command.cameraName;
    streamId_ = command.streamId;
    detectionMode_ = command.detectionMode;
    generation_ = command.generation;
    streamInfo_ = command.streamInfo;
    if (enabled_) {
        ensureOutputDirectory();
        decodedFallbackRequested_.store(true);
        if (!streamInfo_.isValid()) {
            emit recordingWarning(
              QStringLiteral("Encoded packet recording is not ready; Guard will use the decoded-frame fallback unless compatible packets arrive."));
        }
    }
}

void MotionVideoRecorder::processUpdateStreamInfo(const Command& command) {
    if (command.generation == 0 || command.generation != generation_) {
        return;
    }

    const bool streamChanged = streamInfo_.isValid() && command.streamInfo.isValid() && !sameEncodedStreamInfo(streamInfo_, command.streamInfo);
    if (streamChanged) {
        // A reconnect can change codec parameters, resolution, or extradata.
        // Never append incompatible packets to an already-open MP4 stream.
        finalizeRecording();
        preBuffer_.clear();
        preBufferBytes_ = 0;
        lastPacketTimestampMs_ = 0;
        lastPacketSequence_ = 0;
        hasLastPacketSequence_ = false;
        encodedPacketObserved_ = false;
        emit recordingWarning(QStringLiteral("Encoded stream parameters changed; the active clip was finalized and a new keyframe is required."));
    }

    streamInfo_ = command.streamInfo;
    encodedBackendFailed_ = false;
    if (!enabled_) {
        return;
    }
    if (!streamInfo_.isValid()) {
        decodedFallbackRequested_.store(true);
        emit recordingWarning(
          QStringLiteral("The active source is not directly remuxable to MP4; decoded-frame fallback recording remains enabled."));
        return;
    }

    // Valid encoded metadata does not guarantee that a keyframe is already in
    // the pre-roll buffer. Keep decoded fallback active until
    // startEncodedRecordingFromBuffer() succeeds.
    if (!recording_) {
        decodedFallbackRequested_.store(true);
    }

    emit recordingWarning(QStringLiteral("Encoded recording metadata ready: %1 %2x%3. Waiting for encoded packets/keyframe.")
                            .arg(streamInfo_.codecName())
                            .arg(streamInfo_.width)
                            .arg(streamInfo_.height));
    if (motionActive_ && !recording_ && !preBuffer_.empty()) {
        startEncodedRecordingFromBuffer(pendingTriggerTimestampMs_ > 0 ? pendingTriggerTimestampMs_ : lastPacketTimestampMs_);
    }
}

void MotionVideoRecorder::processStopSource(quint64 generation) {
    if (generation_ == 0 || (generation != 0 && generation != generation_)) {
        return;
    }
    finalizeRecording(QStringLiteral("camera-disconnected"));
    resetSourceState();
}

void MotionVideoRecorder::processPacket(PacketItem item) {
    const EncodedVideoPacket& packet = item.packet;
    if (!enabled_ || generation_ == 0 || packet.generation != generation_ || !packet.isValid()) {
        return;
    }

    encodedPacketObserved_ = true;

    // Do not disable or clear the decoded fallback merely because encoded
    // packets are arriving. A camera can begin motion before the first usable
    // keyframe reaches the recorder. In that case, clearing the decoded
    // pre-roll buffer makes the motion trigger silently produce no file.
    // Decoded fallback is disabled only after the encoded muxer has
    // successfully opened and accepted its buffered packets.

    if (hasLastPacketSequence_ && packet.packetSequence != lastPacketSequence_ + 1) {
        const bool continueMotionAfterReset = motionActive_;
        preBuffer_.clear();
        preBufferBytes_ = 0;
        if (recording_ && backend_ == RecordingBackend::EncodedPackets) {
            // Preserve the playable portion already written. A reconnect or a
            // bounded-queue drop starts a new MP4 segment at the next keyframe.
            finalizeRecording(QStringLiteral("encoded-packet-drop"));
            motionActive_ = continueMotionAfterReset;
            pendingTriggerTimestampMs_ = continueMotionAfterReset ? packet.playbackTimestampMs : 0;
        }
        emit recordingWarning(
          QStringLiteral("Encoded packet discontinuity detected; the current clip was finalized and recording will resume at a new keyframe."));
    }
    lastPacketSequence_ = packet.packetSequence;
    hasLastPacketSequence_ = true;

    if (lastPacketTimestampMs_ > 0 && packet.playbackTimestampMs < lastPacketTimestampMs_) {
        preBuffer_.clear();
        preBufferBytes_ = 0;
        if (recording_ && backend_ == RecordingBackend::EncodedPackets) {
            finalizeRecording(QStringLiteral("timestamp-discontinuity"));
        }
        emit recordingWarning(QStringLiteral("Encoded packet time moved backwards; encoded pre-record state was reset."));
    }
    lastPacketTimestampMs_ = packet.playbackTimestampMs;

    if (recording_ && backend_ == RecordingBackend::EncodedPackets) {
        if (!writeEncodedPacket(item)) {
            encodedBackendFailed_ = true;
            decodedFallbackRequested_.store(true);
            return;
        }
        if (!motionActive_ && postRecordDeadlineMs_ > 0 && packet.playbackTimestampMs >= postRecordDeadlineMs_) {
            finalizeRecording();
            postRecordDeadlineMs_ = 0;
            cachePrePacket(std::move(item));
        }
        return;
    }

    cachePrePacket(std::move(item));
    if (motionActive_ && !recording_ && !encodedBackendFailed_ && streamInfo_.isValid()) {
        startEncodedRecordingFromBuffer(pendingTriggerTimestampMs_ > 0 ? pendingTriggerTimestampMs_ : lastPacketTimestampMs_);
    }
}

void MotionVideoRecorder::processDecodedFrame(FrameItem frame) {
    if (!enabled_ || generation_ == 0 || frame.generation != generation_ || frame.frame.isNull() || frame.timestampMs <= 0) {
        return;
    }

    if (recording_ && backend_ == RecordingBackend::EncodedPackets) {
        return;
    }
    if (!decodedFallbackRequested_.load() && backend_ != RecordingBackend::DecodedFrames) {
        return;
    }

    if (lastAcceptedDecodedFrameTimestampMs_ > 0 && frame.timestampMs - lastAcceptedDecodedFrameTimestampMs_ < kDecodedFallbackFrameIntervalMs) {
        return;
    }
    lastAcceptedDecodedFrameTimestampMs_ = frame.timestampMs;
    lastDecodedFrameTimestampMs_ = frame.timestampMs;

    if (recording_ && backend_ == RecordingBackend::DecodedFrames) {
        if (!writeDecodedFrame(frame)) {
            return;
        }
        if (!motionActive_ && postRecordDeadlineMs_ > 0 && frame.timestampMs >= postRecordDeadlineMs_) {
            finalizeRecording();
            postRecordDeadlineMs_ = 0;
            cachePreFrame(std::move(frame));
        }
        return;
    }

    cachePreFrame(std::move(frame));
    if (motionActive_ && !recording_) {
        startDecodedRecordingFromBuffer(pendingTriggerTimestampMs_ > 0 ? pendingTriggerTimestampMs_ : lastDecodedFrameTimestampMs_);
    }
}

void MotionVideoRecorder::processMotionStarted(qint64 timestampMs, quint64 generation) {
    if (!enabled_ || generation == 0 || generation != generation_) {
        return;
    }
    motionActive_ = true;
    postRecordDeadlineMs_ = 0;
    pendingTriggerTimestampMs_ = timestampMs;
    if (!recording_) {
        // A motion event may arrive before an encoded keyframe or before the
        // first decoded pre-roll frame has been queued. Keep fallback intake
        // active so the next decoded frame can start this camera's recording.
        decodedFallbackRequested_.store(true);
        const bool encodedStarted = startEncodedRecordingFromBuffer(timestampMs);
        const bool decodedStarted = encodedStarted ? false : startDecodedRecordingFromBuffer(timestampMs);
        if (!encodedStarted && !decodedStarted) {
            emit recordingWarning(
              QStringLiteral("Motion was detected before a usable encoded keyframe or decoded pre-roll frame was ready. "
                             "This camera will start recording from the next available decoded frame or encoded keyframe."));
        }
    }
}

void MotionVideoRecorder::processMotionEnded(qint64 timestampMs, quint64 generation) {
    if (!enabled_ || generation == 0 || generation != generation_) {
        return;
    }
    motionActive_ = false;
    pendingTriggerTimestampMs_ = 0;
    if (!recording_) {
        return;
    }
    postRecordDeadlineMs_ = timestampMs + kPostRecordMs;
    const qint64 latestTimestamp = backend_ == RecordingBackend::EncodedPackets ? lastPacketTimestampMs_ : lastDecodedFrameTimestampMs_;
    if (latestTimestamp >= postRecordDeadlineMs_) {
        finalizeRecording();
        postRecordDeadlineMs_ = 0;
    }
}

void MotionVideoRecorder::cachePrePacket(PacketItem item) {
    preBufferBytes_ += item.byteSize;
    const qint64 newestTimestampMs = item.packet.playbackTimestampMs;
    preBuffer_.push_back(std::move(item));
    trimPreBuffer(newestTimestampMs);
}

void MotionVideoRecorder::trimPreBuffer(qint64 newestTimestampMs) {
    const qint64 cutoff = newestTimestampMs - kPreRecordMs;
    std::size_t lastKeyframeBeforeCutoff = 0;
    bool foundKeyframe = false;
    for (std::size_t index = 0; index < preBuffer_.size(); ++index) {
        if (preBuffer_[index].packet.playbackTimestampMs > cutoff) {
            break;
        }
        if (preBuffer_[index].packet.keyFrame) {
            lastKeyframeBeforeCutoff = index;
            foundKeyframe = true;
        }
    }
    if (foundKeyframe) {
        for (std::size_t index = 0; index < lastKeyframeBeforeCutoff; ++index) {
            preBufferBytes_ -= std::min(preBufferBytes_, preBuffer_.front().byteSize);
            preBuffer_.pop_front();
        }
    }

    while (!preBuffer_.empty() && (preBufferBytes_ > kMaximumPreBufferBytes || preBuffer_.size() > kMaximumPreBufferPackets)) {
        preBufferBytes_ -= std::min(preBufferBytes_, preBuffer_.front().byteSize);
        preBuffer_.pop_front();
    }
}

bool MotionVideoRecorder::startEncodedRecordingFromBuffer(qint64 triggerTimestampMs) {
    if (recording_ || encodedBackendFailed_ || preBuffer_.empty() || !streamInfo_.isValid()) {
        return false;
    }

    const qint64 requestedStart = triggerTimestampMs - kPreRecordMs;
    std::size_t startIndex = preBuffer_.size();
    for (std::size_t index = 0; index < preBuffer_.size(); ++index) {
        if (preBuffer_[index].packet.keyFrame && preBuffer_[index].packet.playbackTimestampMs <= requestedStart) {
            startIndex = index;
        }
    }
    if (startIndex == preBuffer_.size()) {
        for (std::size_t index = 0; index < preBuffer_.size(); ++index) {
            if (preBuffer_[index].packet.keyFrame) {
                startIndex = index;
                break;
            }
        }
    }
    if (startIndex == preBuffer_.size()) {
        return false;
    }

    if (!openEncodedMuxer()) {
        encodedBackendFailed_ = true;
        decodedFallbackRequested_.store(true);
        emit recordingWarning(QStringLiteral("Encoded MP4 muxing could not start; switching this source to decoded-frame fallback recording."));
        return false;
    }

    for (std::size_t index = startIndex; index < preBuffer_.size(); ++index) {
        if (!writeEncodedPacket(preBuffer_[index])) {
            encodedBackendFailed_ = true;
            decodedFallbackRequested_.store(true);
            return false;
        }
    }
    preBuffer_.clear();
    preBufferBytes_ = 0;
    decodedPreBuffer_.clear();
    decodedPreBufferBytes_ = 0;
    decodedFallbackRequested_.store(false);
    pendingTriggerTimestampMs_ = 0;
    return true;
}

void MotionVideoRecorder::cachePreFrame(FrameItem frame) {
    decodedPreBufferBytes_ += frame.byteSize;
    const qint64 newestTimestampMs = frame.timestampMs;
    decodedPreBuffer_.push_back(std::move(frame));
    trimDecodedPreBuffer(newestTimestampMs);
}

void MotionVideoRecorder::trimDecodedPreBuffer(qint64 newestTimestampMs) {
    const qint64 cutoff = newestTimestampMs - kPreRecordMs;
    while (!decodedPreBuffer_.empty() && decodedPreBuffer_.front().timestampMs < cutoff) {
        decodedPreBufferBytes_ -= std::min(decodedPreBufferBytes_, decodedPreBuffer_.front().byteSize);
        decodedPreBuffer_.pop_front();
    }
    while (!decodedPreBuffer_.empty() &&
           (decodedPreBufferBytes_ > kMaximumDecodedPreBufferBytes || decodedPreBuffer_.size() > kMaximumDecodedPreBufferFrames)) {
        decodedPreBufferBytes_ -= std::min(decodedPreBufferBytes_, decodedPreBuffer_.front().byteSize);
        decodedPreBuffer_.pop_front();
    }
}

bool MotionVideoRecorder::startDecodedRecordingFromBuffer(qint64 triggerTimestampMs) {
    if (recording_ || decodedPreBuffer_.empty()) {
        return false;
    }

    const qint64 requestedStart = triggerTimestampMs - kPreRecordMs;
    std::size_t startIndex = 0;
    while (startIndex + 1 < decodedPreBuffer_.size() && decodedPreBuffer_[startIndex].timestampMs < requestedStart) {
        ++startIndex;
    }

    if (!openDecodedWriter(decodedPreBuffer_[startIndex].frame)) {
        return false;
    }

    emit recordingWarning(QStringLiteral(
      "Recording uses the decoded-frame fallback (approximately 15 FPS). Configure native FFmpeg packet recording for lower CPU usage."));
    for (std::size_t index = startIndex; index < decodedPreBuffer_.size(); ++index) {
        if (!writeDecodedFrame(decodedPreBuffer_[index])) {
            return false;
        }
    }
    decodedPreBuffer_.clear();
    decodedPreBufferBytes_ = 0;
    pendingTriggerTimestampMs_ = 0;
    return true;
}

bool MotionVideoRecorder::ensureOutputDirectory() {
    QString errorMessage;
    if (storage_ && storage_->ensureRoot(&errorMessage)) {
        outputRoot_ = storage_->effectiveRecordingRoot();
        return true;
    }
    emit recordingError(errorMessage.isEmpty() ? QStringLiteral("Unable to create recording directory: %1").arg(outputRoot_) : errorMessage);
    return false;
}

bool MotionVideoRecorder::openEncodedMuxer() {
    if (!ensureOutputDirectory()) {
        return false;
    }
    QString diskError;
    if (storage_ && !storage_->hasMinimumFreeSpace(&diskError)) {
        storage_->requestCleanup(RecordingCleanupReason::LowDiskSpace);
        if (!storage_->hasMinimumFreeSpace(&diskError)) {
            emit recordingError(diskError);
            return false;
        }
    }

    recordingStartedAtUtc_ = QDateTime::currentDateTimeUtc();
    recordingPaths_ = storage_->createPaths(cameraId_.isEmpty() ? streamId_ : cameraId_, QStringLiteral("motion"), recordingStartedAtUtc_);
    QString pathError;
    if (!storage_->ensureWritableDirectory(recordingPaths_.directoryPath, &pathError)) {
        emit recordingError(pathError);
        return false;
    }
    finalPath_ = recordingPaths_.finalVideoPath;
    temporaryPath_ = recordingPaths_.temporaryVideoPath;
    if (!muxer_.open(temporaryPath_, streamInfo_)) {
        emit recordingError(muxer_.errorString());
        temporaryPath_.clear();
        finalPath_.clear();
        return false;
    }
    backend_ = RecordingBackend::EncodedPackets;
    recording_ = true;
    writtenPackets_ = 0;
    writeRecordingMetadata(false, QStringLiteral("recording-active"), recordingPaths_.temporaryMetadataPath, QFileInfo(temporaryPath_).fileName(), 0);
    emit recordingStarted(finalPath_);
    return true;
}

bool MotionVideoRecorder::openDecodedWriter(const QImage& firstFrame) {
    if (!ensureOutputDirectory() || firstFrame.isNull()) {
        return false;
    }
    QString diskError;
    if (storage_ && !storage_->hasMinimumFreeSpace(&diskError)) {
        storage_->requestCleanup(RecordingCleanupReason::LowDiskSpace);
        if (!storage_->hasMinimumFreeSpace(&diskError)) {
            emit recordingError(diskError);
            return false;
        }
    }

    recordingStartedAtUtc_ = QDateTime::currentDateTimeUtc();
    recordingPaths_ = storage_->createPaths(cameraId_.isEmpty() ? streamId_ : cameraId_, QStringLiteral("motion"), recordingStartedAtUtc_);
    QString pathError;
    if (!storage_->ensureWritableDirectory(recordingPaths_.directoryPath, &pathError)) {
        emit recordingError(pathError);
        return false;
    }
    finalPath_ = recordingPaths_.finalVideoPath;
    temporaryPath_ = recordingPaths_.temporaryVideoPath;

    decodedWriter_->width = firstFrame.width();
    decodedWriter_->height = firstFrame.height();
    const QByteArray nativePath = QDir::toNativeSeparators(temporaryPath_).toLocal8Bit();
    const int fourcc = cv::VideoWriter::fourcc('m', 'p', '4', 'v');
    bool opened = false;
    try {
        opened = decodedWriter_->writer.open(nativePath.constData(), fourcc, kDecodedFallbackFps,
                                             cv::Size(decodedWriter_->width, decodedWriter_->height), true);
    } catch (const cv::Exception& exception) {
        emit recordingError(QStringLiteral("OpenCV fallback writer failed: %1").arg(QString::fromLocal8Bit(exception.what())));
    }
    if (!opened) {
        emit recordingError(
          QStringLiteral("OpenCV could not create the fallback MP4 writer. Verify opencv_videoio_ffmpeg is deployed beside Guard.exe."));
        temporaryPath_.clear();
        finalPath_.clear();
        decodedWriter_->width = 0;
        decodedWriter_->height = 0;
        return false;
    }

    backend_ = RecordingBackend::DecodedFrames;
    recording_ = true;
    writtenPackets_ = 0;
    decodedFallbackRequested_.store(true);
    writeRecordingMetadata(false, QStringLiteral("recording-active"), recordingPaths_.temporaryMetadataPath, QFileInfo(temporaryPath_).fileName(), 0);
    emit recordingStarted(finalPath_);
    return true;
}

bool MotionVideoRecorder::writeEncodedPacket(const PacketItem& item) {
    if (!recording_ || backend_ != RecordingBackend::EncodedPackets || !muxer_.isOpen()) {
        return false;
    }
    if (!muxer_.writePacket(item.packet)) {
        abortRecording(muxer_.errorString(), true);
        return false;
    }
    ++writtenPackets_;
    return true;
}

bool MotionVideoRecorder::writeDecodedFrame(const FrameItem& item) {
    if (!recording_ || backend_ != RecordingBackend::DecodedFrames || !decodedWriter_ || !decodedWriter_->writer.isOpened() || item.frame.isNull()) {
        return false;
    }

    const QImage rgb = item.frame.format() == QImage::Format_RGB888 ? item.frame : item.frame.convertToFormat(QImage::Format_RGB888);
    if (rgb.isNull()) {
        abortRecording(QStringLiteral("Unable to convert a fallback recording frame to RGB."), true);
        return false;
    }

    try {
        cv::Mat rgbView(rgb.height(), rgb.width(), CV_8UC3, const_cast<uchar*>(rgb.constBits()), rgb.bytesPerLine());
        cv::cvtColor(rgbView, decodedWriter_->bgrScratch, cv::COLOR_RGB2BGR);

        const cv::Mat* output = &decodedWriter_->bgrScratch;
        if (decodedWriter_->bgrScratch.cols != decodedWriter_->width || decodedWriter_->bgrScratch.rows != decodedWriter_->height) {
            cv::resize(decodedWriter_->bgrScratch, decodedWriter_->resizedScratch, cv::Size(decodedWriter_->width, decodedWriter_->height), 0.0, 0.0,
                       cv::INTER_LINEAR);
            output = &decodedWriter_->resizedScratch;
        }

        decodedWriter_->writer.write(*output);
    } catch (const cv::Exception& exception) {
        abortRecording(QStringLiteral("OpenCV fallback frame write failed: %1").arg(QString::fromLocal8Bit(exception.what())), true);
        return false;
    }
    ++writtenPackets_;
    return true;
}

void MotionVideoRecorder::finalizeRecording(const QString& incompleteReason) {
    if (!recording_) {
        return;
    }

    bool finalized = true;
    QString finalizationError;
    if (backend_ == RecordingBackend::EncodedPackets) {
        finalized = muxer_.finalize();
        finalizationError = muxer_.errorString();
    } else if (backend_ == RecordingBackend::DecodedFrames) {
        if (decodedWriter_ && decodedWriter_->writer.isOpened()) {
            decodedWriter_->writer.release();
        }
    }

    const QString temporaryPath = temporaryPath_;
    const QString finalPath = finalPath_;
    const QString finalMetadataPath = recordingPaths_.finalMetadataPath;
    const quint64 writtenCount = writtenPackets_;
    recording_ = false;
    temporaryPath_.clear();
    finalPath_.clear();
    writtenPackets_ = 0;

    // Rebuild the decoded fallback pre-roll after any clip completes. This
    // keeps the next motion event independent from encoded-keyframe timing.
    decodedFallbackRequested_.store(enabled_ && generation_ != 0);

    const bool interrupted = !incompleteReason.trimmed().isEmpty();
    if (!finalized) {
        finalizeMetadata(false, QStringLiteral("muxer-finalization-failed"), QFileInfo(temporaryPath).fileName(),
                         QFileInfo::exists(temporaryPath) ? QFileInfo(temporaryPath).size() : 0);
        backend_ = RecordingBackend::None;
        emit recordingError(finalizationError.isEmpty() ? QStringLiteral("Recording finalization failed.") : finalizationError);
        return;
    }
    if (writtenCount == 0 || temporaryPath.isEmpty() || !QFileInfo::exists(temporaryPath) || QFileInfo(temporaryPath).size() <= 0) {
        QFile::remove(temporaryPath);
        finalizeMetadata(false, QStringLiteral("writer-error"), QString(), 0);
        backend_ = RecordingBackend::None;
        emit recordingError(QStringLiteral("Recording produced no usable video packets or frames."));
        return;
    }

    QFile::remove(finalPath);
    if (!QFile::rename(temporaryPath, finalPath)) {
        finalizeMetadata(false, QStringLiteral("file-rename-failed"), QFileInfo(temporaryPath).fileName(),
                         QFileInfo::exists(temporaryPath) ? QFileInfo(temporaryPath).size() : 0);
        backend_ = RecordingBackend::None;
        emit recordingError(QStringLiteral("Recording was written but could not be finalized. Temporary file: %1").arg(temporaryPath));
        return;
    }
    if (!finalizeMetadata(!interrupted, interrupted ? incompleteReason : QString(), QFileInfo(finalPath).fileName(), QFileInfo(finalPath).size())) {
        emit recordingWarning(QStringLiteral("Recording video finalized but metadata could not be finalized: %1").arg(finalMetadataPath));
    }
    backend_ = RecordingBackend::None;
    emit recordingFinished(finalPath, writtenCount);
    if (storage_) {
        storage_->requestCleanup(RecordingCleanupReason::RecordingCompleted);
    }
}

void MotionVideoRecorder::abortRecording(const QString& message, bool preserveMotionState, const QString& incompleteReason) {
    const bool wasMotionActive = motionActive_;
    if (backend_ == RecordingBackend::EncodedPackets) {
        muxer_.abort();
    } else if (backend_ == RecordingBackend::DecodedFrames && decodedWriter_ && decodedWriter_->writer.isOpened()) {
        decodedWriter_->writer.release();
    }

    recording_ = false;
    writtenPackets_ = 0;
    const QString temporaryPath = temporaryPath_;
    if (!temporaryPath_.isEmpty()) {
        QFile::remove(temporaryPath_);
    }
    temporaryPath_.clear();
    finalPath_.clear();
    finalizeMetadata(false, incompleteReason.isEmpty() ? QStringLiteral("unknown") : incompleteReason, QFileInfo(temporaryPath).fileName(), 0);
    backend_ = RecordingBackend::None;
    decodedFallbackRequested_.store(enabled_ && generation_ != 0);
    motionActive_ = preserveMotionState ? wasMotionActive : false;
    if (!preserveMotionState) {
        pendingTriggerTimestampMs_ = 0;
        postRecordDeadlineMs_ = 0;
    }
    emit recordingError(message);
}

void MotionVideoRecorder::resetSourceState() {
    decodedFallbackRequested_.store(false);
    streamId_.clear();
    generation_ = 0;
    cameraId_.clear();
    cameraName_.clear();
    detectionMode_.clear();
    streamInfo_ = EncodedStreamInfo{};
    preBuffer_.clear();
    preBufferBytes_ = 0;
    decodedPreBuffer_.clear();
    decodedPreBufferBytes_ = 0;
    motionActive_ = false;
    recording_ = false;
    backend_ = RecordingBackend::None;
    encodedPacketObserved_ = false;
    encodedBackendFailed_ = false;
    pendingTriggerTimestampMs_ = 0;
    postRecordDeadlineMs_ = 0;
    lastPacketTimestampMs_ = 0;
    lastDecodedFrameTimestampMs_ = 0;
    lastAcceptedDecodedFrameTimestampMs_ = 0;
    lastPacketSequence_ = 0;
    hasLastPacketSequence_ = false;
    recordingPaths_ = RecordingPaths{};
    recordingStartedAtUtc_ = QDateTime();
}

void MotionVideoRecorder::writeRecordingMetadata(bool complete, const QString& incompleteReason, const QString& metadataPath,
                                                 const QString& videoFileName, qint64 fileSizeBytes) {
    if (metadataPath.isEmpty() || recordingPaths_.eventId.isEmpty()) {
        return;
    }

    const QDateTime endedAtUtc = complete || !incompleteReason.isEmpty() ? QDateTime::currentDateTimeUtc() : QDateTime();
    QJsonObject metadata;
    metadata.insert(QStringLiteral("schemaVersion"), 1);
    metadata.insert(QStringLiteral("eventId"), recordingPaths_.eventId);
    metadata.insert(QStringLiteral("cameraId"), cameraId_);
    metadata.insert(QStringLiteral("cameraName"), cameraName_);
    metadata.insert(QStringLiteral("eventType"), QStringLiteral("motion"));
    metadata.insert(QStringLiteral("startedAtUtc"), RecordingStorageManager::metadataTimestampUtc(recordingStartedAtUtc_));
    if (endedAtUtc.isValid()) {
        metadata.insert(QStringLiteral("endedAtUtc"), RecordingStorageManager::metadataTimestampUtc(endedAtUtc));
        metadata.insert(QStringLiteral("durationMs"), recordingStartedAtUtc_.msecsTo(endedAtUtc));
    }
    metadata.insert(QStringLiteral("complete"), complete);
    metadata.insert(QStringLiteral("incompleteReason"), incompleteReason);
    metadata.insert(QStringLiteral("recordingBackend"), RecordingStorageManager::backendName(static_cast<int>(backend_)));
    metadata.insert(QStringLiteral("sourceGeneration"), static_cast<double>(generation_));
    metadata.insert(QStringLiteral("detectionMode"), detectionMode_);
    metadata.insert(QStringLiteral("preRollMs"), kPreRecordMs);
    metadata.insert(QStringLiteral("postRollMs"), kPostRecordMs);
    if (streamInfo_.isValid()) {
        metadata.insert(QStringLiteral("codec"), RecordingStorageManager::codecName(static_cast<int>(streamInfo_.codec)));
        metadata.insert(QStringLiteral("width"), streamInfo_.width);
        metadata.insert(QStringLiteral("height"), streamInfo_.height);
    } else if (decodedWriter_ && decodedWriter_->width > 0 && decodedWriter_->height > 0) {
        metadata.insert(QStringLiteral("width"), decodedWriter_->width);
        metadata.insert(QStringLiteral("height"), decodedWriter_->height);
    }
    if (!videoFileName.isEmpty()) {
        metadata.insert(QStringLiteral("videoFile"), videoFileName);
    }
    if (fileSizeBytes >= 0) {
        metadata.insert(QStringLiteral("fileSizeBytes"), static_cast<double>(fileSizeBytes));
    }

    QString error;
    if (!RecordingStorageManager::writeMetadataAtomically(metadataPath, QJsonDocument(metadata).toJson(QJsonDocument::Indented), &error)) {
        emit recordingWarning(error);
    }
}

bool MotionVideoRecorder::finalizeMetadata(bool complete, const QString& incompleteReason, const QString& videoFileName, qint64 fileSizeBytes) {
    if (recordingPaths_.temporaryMetadataPath.isEmpty() || recordingPaths_.finalMetadataPath.isEmpty()) {
        return true;
    }
    writeRecordingMetadata(complete, incompleteReason, recordingPaths_.temporaryMetadataPath, videoFileName, fileSizeBytes);
    QString error;
    if (!RecordingStorageManager::finalizeMetadataFile(recordingPaths_.temporaryMetadataPath, recordingPaths_.finalMetadataPath, &error)) {
        emit recordingWarning(error);
        return false;
    }
    return true;
}

std::size_t MotionVideoRecorder::imageByteSize(const QImage& image) noexcept {
    if (image.isNull() || image.bytesPerLine() <= 0 || image.height() <= 0) {
        return 0;
    }
    return static_cast<std::size_t>(image.bytesPerLine()) * static_cast<std::size_t>(image.height());
}

}  // namespace recording
}  // namespace guard
