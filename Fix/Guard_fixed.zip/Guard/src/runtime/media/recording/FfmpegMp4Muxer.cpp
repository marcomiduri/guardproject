#include "media/recording/FfmpegMp4Muxer.h"

#include <QDir>

#include <algorithm>
#include <cstring>
#include <limits>

#ifdef GUARD_ENABLE_FFMPEG
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/error.h>
#include <libavutil/mem.h>
}
#endif

namespace guard {
namespace recording {

class FfmpegMp4Muxer::Impl {
public:
#ifdef GUARD_ENABLE_FFMPEG
    AVFormatContext* formatContext = nullptr;
    AVStream* outputStream = nullptr;
    AVRational inputTimeBase{0, 1};
    qint64 baseTimestamp = 0;
    bool baseTimestampSet = false;
    qint64 lastOutputDts = std::numeric_limits<qint64>::min();
#endif
    QString error;
    bool open = false;

#ifdef GUARD_ENABLE_FFMPEG
    static QString ffmpegError(int code) {
        char buffer[AV_ERROR_MAX_STRING_SIZE] = {};
        av_strerror(code, buffer, sizeof(buffer));
        return QString::fromLocal8Bit(buffer);
    }

    void closeContext(bool writeTrailer) {
        if (!formatContext) {
            open = false;
            return;
        }

        if (writeTrailer && open) {
            const int result = av_write_trailer(formatContext);
            if (result < 0 && error.isEmpty()) {
                error = QStringLiteral("FFmpeg failed to finalize MP4: %1").arg(ffmpegError(result));
            }
        }
        if (!(formatContext->oformat->flags & AVFMT_NOFILE) && formatContext->pb) {
            avio_closep(&formatContext->pb);
        }
        avformat_free_context(formatContext);
        formatContext = nullptr;
        outputStream = nullptr;
        open = false;
        baseTimestampSet = false;
        lastOutputDts = std::numeric_limits<qint64>::min();
    }
#endif
};

FfmpegMp4Muxer::FfmpegMp4Muxer() : impl_(new Impl()) {}

FfmpegMp4Muxer::~FfmpegMp4Muxer() {
    abort();
}

bool FfmpegMp4Muxer::open(const QString& path, const EncodedStreamInfo& streamInfo) {
    abort();
    impl_->error.clear();

#ifndef GUARD_ENABLE_FFMPEG
    Q_UNUSED(path);
    Q_UNUSED(streamInfo);
    impl_->error = QStringLiteral("FFmpeg development libraries are not enabled. Set FFMPEG_ROOT and rebuild Guard.");
    return false;
#else
    if (!streamInfo.isValid()) {
        impl_->error = QStringLiteral("The selected source does not provide MP4-compatible H.264, H.265, or MPEG-4 Part 2 packets.");
        return false;
    }

    const QByteArray nativePath = QDir::toNativeSeparators(path).toLocal8Bit();
    int result = avformat_alloc_output_context2(&impl_->formatContext, nullptr, "mp4", nativePath.constData());
    if (result < 0 || !impl_->formatContext) {
        impl_->error = QStringLiteral("FFmpeg could not create MP4 output: %1").arg(Impl::ffmpegError(result));
        impl_->closeContext(false);
        return false;
    }

    impl_->outputStream = avformat_new_stream(impl_->formatContext, nullptr);
    if (!impl_->outputStream) {
        impl_->error = QStringLiteral("FFmpeg could not create the MP4 video stream.");
        impl_->closeContext(false);
        return false;
    }

    AVCodecParameters* parameters = impl_->outputStream->codecpar;
    parameters->codec_type = AVMEDIA_TYPE_VIDEO;
    switch (streamInfo.codec) {
        case VideoCodec::H265:
            parameters->codec_id = AV_CODEC_ID_HEVC;
            break;
        case VideoCodec::Mpeg4Part2:
            parameters->codec_id = AV_CODEC_ID_MPEG4;
            break;
        case VideoCodec::H264:
        default:
            parameters->codec_id = AV_CODEC_ID_H264;
            break;
    }
    parameters->codec_tag = 0;
    parameters->width = streamInfo.width;
    parameters->height = streamInfo.height;

    if (!streamInfo.codecExtraData.isEmpty()) {
        parameters->extradata_size = streamInfo.codecExtraData.size();
        parameters->extradata =
          static_cast<uint8_t*>(av_mallocz(static_cast<std::size_t>(parameters->extradata_size) + AV_INPUT_BUFFER_PADDING_SIZE));
        if (!parameters->extradata) {
            impl_->error = QStringLiteral("Unable to allocate codec configuration for MP4 recording.");
            impl_->closeContext(false);
            return false;
        }
        std::memcpy(parameters->extradata, streamInfo.codecExtraData.constData(), static_cast<std::size_t>(parameters->extradata_size));
    }

    impl_->inputTimeBase = AVRational{streamInfo.timeBaseNumerator, streamInfo.timeBaseDenominator};
    impl_->outputStream->time_base = impl_->inputTimeBase;

    if (!(impl_->formatContext->oformat->flags & AVFMT_NOFILE)) {
        result = avio_open(&impl_->formatContext->pb, nativePath.constData(), AVIO_FLAG_WRITE);
        if (result < 0) {
            impl_->error = QStringLiteral("Unable to open MP4 output file: %1").arg(Impl::ffmpegError(result));
            impl_->closeContext(false);
            return false;
        }
    }

    AVDictionary* options = nullptr;
    av_dict_set(&options, "movflags", "+faststart", 0);
    result = avformat_write_header(impl_->formatContext, &options);
    av_dict_free(&options);
    if (result < 0) {
        impl_->error = QStringLiteral("FFmpeg could not write the MP4 header: %1").arg(Impl::ffmpegError(result));
        impl_->closeContext(false);
        return false;
    }

    impl_->open = true;
    return true;
#endif
}

bool FfmpegMp4Muxer::writePacket(const EncodedVideoPacket& packet) {
#ifndef GUARD_ENABLE_FFMPEG
    Q_UNUSED(packet);
    return false;
#else
    if (!impl_->open || !impl_->formatContext || !impl_->outputStream || !packet.isValid()) {
        impl_->error = QStringLiteral("Cannot write an invalid packet or use a closed MP4 muxer.");
        return false;
    }

    AVPacket* outputPacket = av_packet_alloc();
    if (!outputPacket) {
        impl_->error = QStringLiteral("Unable to allocate an FFmpeg packet for recording.");
        return false;
    }

    const int allocationResult = av_new_packet(outputPacket, packet.data.size());
    if (allocationResult < 0) {
        impl_->error = QStringLiteral("Unable to allocate encoded packet storage: %1").arg(Impl::ffmpegError(allocationResult));
        av_packet_free(&outputPacket);
        return false;
    }
    std::memcpy(outputPacket->data, packet.data.constData(), static_cast<std::size_t>(packet.data.size()));

    const qint64 fallbackTimestamp = packet.hasDts ? packet.dts : packet.pts;
    if (!impl_->baseTimestampSet) {
        impl_->baseTimestamp = fallbackTimestamp;
        impl_->baseTimestampSet = true;
    }

    outputPacket->pts = packet.hasPts ? packet.pts - impl_->baseTimestamp : AV_NOPTS_VALUE;
    outputPacket->dts = packet.hasDts ? packet.dts - impl_->baseTimestamp : outputPacket->pts;
    outputPacket->duration = std::max<qint64>(0, packet.duration);
    outputPacket->flags = packet.keyFrame ? AV_PKT_FLAG_KEY : 0;
    outputPacket->stream_index = impl_->outputStream->index;

    const AVRational packetTimeBase{packet.timeBaseNumerator, packet.timeBaseDenominator};
    av_packet_rescale_ts(outputPacket, packetTimeBase, impl_->outputStream->time_base);

    if (outputPacket->dts == AV_NOPTS_VALUE) {
        outputPacket->dts = impl_->lastOutputDts == std::numeric_limits<qint64>::min() ? 0 : impl_->lastOutputDts + 1;
    }
    if (outputPacket->dts < 0) {
        outputPacket->dts = 0;
    }
    if (impl_->lastOutputDts != std::numeric_limits<qint64>::min() && outputPacket->dts <= impl_->lastOutputDts) {
        outputPacket->dts = impl_->lastOutputDts + 1;
    }
    if (outputPacket->pts == AV_NOPTS_VALUE || outputPacket->pts < outputPacket->dts) {
        outputPacket->pts = outputPacket->dts;
    }
    impl_->lastOutputDts = outputPacket->dts;

    const int result = av_interleaved_write_frame(impl_->formatContext, outputPacket);
    av_packet_free(&outputPacket);
    if (result < 0) {
        impl_->error = QStringLiteral("FFmpeg failed while writing an encoded packet: %1").arg(Impl::ffmpegError(result));
        return false;
    }
    return true;
#endif
}

bool FfmpegMp4Muxer::finalize() {
#ifndef GUARD_ENABLE_FFMPEG
    return false;
#else
    if (!impl_->open) {
        return true;
    }
    impl_->error.clear();
    impl_->closeContext(true);
    return impl_->error.isEmpty();
#endif
}

void FfmpegMp4Muxer::abort() {
#ifdef GUARD_ENABLE_FFMPEG
    impl_->closeContext(false);
#else
    impl_->open = false;
#endif
}

bool FfmpegMp4Muxer::isOpen() const noexcept {
    return impl_->open;
}

QString FfmpegMp4Muxer::errorString() const {
    return impl_->error;
}

}  // namespace recording
}  // namespace guard
