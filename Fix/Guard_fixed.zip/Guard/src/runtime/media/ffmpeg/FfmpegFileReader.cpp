#include "media/ffmpeg/FfmpegFileReader.h"

#include <QDir>
#include <QElapsedTimer>
#include <QThread>

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstring>
#include <limits>
#include <memory>
#include <utility>

#ifdef GUARD_ENABLE_FFMPEG
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/error.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}
#endif

namespace guard {
namespace media {
namespace {

constexpr double kFallbackFps = 25.0;

#ifdef GUARD_ENABLE_FFMPEG

QString ffmpegError(int code) {
    char buffer[AV_ERROR_MAX_STRING_SIZE] = {};
    av_strerror(code, buffer, sizeof(buffer));
    return QString::fromLocal8Bit(buffer);
}

struct InputSession {
    AVFormatContext* format = nullptr;
    AVCodecContext* decoder = nullptr;
    SwsContext* scaler = nullptr;
    int videoStreamIndex = -1;
    AVStream* videoStream = nullptr;

    ~InputSession() {
        if (scaler) {
            sws_freeContext(scaler);
        }
        if (decoder) {
            avcodec_free_context(&decoder);
        }
        if (format) {
            avformat_close_input(&format);
        }
    }
};

bool isValidFps(double fps) {
    return std::isfinite(fps) && fps > 1.0 && fps <= 240.0;
}

double streamFps(const AVStream* stream) {
    if (!stream) {
        return kFallbackFps;
    }
    AVRational rate = stream->avg_frame_rate;
    if (rate.num <= 0 || rate.den <= 0) {
        rate = stream->r_frame_rate;
    }
    const double fps = rate.num > 0 && rate.den > 0 ? av_q2d(rate) : kFallbackFps;
    return isValidFps(fps) ? fps : kFallbackFps;
}

qint64 timestampToMs(qint64 timestamp, AVRational timeBase) {
    if (timestamp == AV_NOPTS_VALUE || timeBase.num <= 0 || timeBase.den <= 0) {
        return 0;
    }
    return static_cast<qint64>(av_rescale_q(timestamp, timeBase, AVRational{1, 1000}));
}

qint64 streamStartMs(const AVStream* stream) {
    if (!stream || stream->start_time == AV_NOPTS_VALUE) {
        return 0;
    }
    return timestampToMs(stream->start_time, stream->time_base);
}

qint64 estimatedDurationMs(const InputSession& session) {
    if (session.videoStream && session.videoStream->duration != AV_NOPTS_VALUE) {
        const qint64 value = timestampToMs(session.videoStream->duration, session.videoStream->time_base);
        if (value > 0) {
            return value;
        }
    }
    if (session.format && session.format->duration != AV_NOPTS_VALUE) {
        const qint64 value = static_cast<qint64>(session.format->duration / (AV_TIME_BASE / 1000));
        if (value > 0) {
            return value;
        }
    }
    return 0;
}

recording::VideoCodec toVideoCodec(AVCodecID codecId) {
    switch (codecId) {
        case AV_CODEC_ID_H264:
            return recording::VideoCodec::H264;
        case AV_CODEC_ID_HEVC:
            return recording::VideoCodec::H265;
        case AV_CODEC_ID_MPEG4:
            return recording::VideoCodec::Mpeg4Part2;
        default:
            return recording::VideoCodec::Unknown;
    }
}

bool isMp4PacketLayout(const AVFormatContext* format) {
    if (!format || !format->iformat || !format->iformat->name) {
        return false;
    }
    const QByteArray name(format->iformat->name);
    return name.contains("mov") || name.contains("mp4") || name.contains("3gp") || name.contains("mj2");
}

recording::EncodedStreamInfo makeStreamInfo(const InputSession& session) {
    recording::EncodedStreamInfo info;
    if (!session.videoStream || !session.videoStream->codecpar) {
        return info;
    }

    const AVCodecParameters* parameters = session.videoStream->codecpar;
    info.codec = toVideoCodec(parameters->codec_id);
    info.width = parameters->width;
    info.height = parameters->height;
    info.timeBaseNumerator = session.videoStream->time_base.num;
    info.timeBaseDenominator = session.videoStream->time_base.den;
    info.mp4RemuxCompatible =
      isMp4PacketLayout(session.format) &&
      (info.codec == recording::VideoCodec::H264 || info.codec == recording::VideoCodec::H265 || info.codec == recording::VideoCodec::Mpeg4Part2);
    if (parameters->extradata && parameters->extradata_size > 0) {
        info.codecExtraData = QByteArray(reinterpret_cast<const char*>(parameters->extradata), parameters->extradata_size);
    }
    return info;
}

bool openSession(const QString& path, InputSession* session, QString* errorMessage) {
    if (!session) {
        return false;
    }

    const QByteArray nativePath = QDir::toNativeSeparators(path).toUtf8();
    int result = avformat_open_input(&session->format, nativePath.constData(), nullptr, nullptr);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("FFmpeg could not open the movie: %1").arg(ffmpegError(result));
        }
        return false;
    }

    result = avformat_find_stream_info(session->format, nullptr);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("FFmpeg could not read stream information: %1").arg(ffmpegError(result));
        }
        return false;
    }

    result = av_find_best_stream(session->format, AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("The movie does not contain a decodable video stream.");
        }
        return false;
    }

    session->videoStreamIndex = result;
    session->videoStream = session->format->streams[session->videoStreamIndex];
    const AVCodec* codec = avcodec_find_decoder(session->videoStream->codecpar->codec_id);
    if (!codec) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("No FFmpeg decoder is available for the selected video codec.");
        }
        return false;
    }

    session->decoder = avcodec_alloc_context3(codec);
    if (!session->decoder) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to allocate the FFmpeg video decoder.");
        }
        return false;
    }

    result = avcodec_parameters_to_context(session->decoder, session->videoStream->codecpar);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to configure the FFmpeg video decoder: %1").arg(ffmpegError(result));
        }
        return false;
    }

    session->decoder->pkt_timebase = session->videoStream->time_base;
    result = avcodec_open2(session->decoder, codec, nullptr);
    if (result < 0) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to start the FFmpeg video decoder: %1").arg(ffmpegError(result));
        }
        return false;
    }
    return true;
}

QImage convertFrame(InputSession& session, const AVFrame* frame, QString* errorMessage) {
    if (!frame || frame->width <= 0 || frame->height <= 0) {
        return QImage();
    }

    QImage image(frame->width, frame->height, QImage::Format_RGB888);
    if (image.isNull()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to allocate an RGB preview frame.");
        }
        return QImage();
    }

    session.scaler = sws_getCachedContext(session.scaler, frame->width, frame->height, static_cast<AVPixelFormat>(frame->format), frame->width,
                                          frame->height, AV_PIX_FMT_RGB24, SWS_BILINEAR, nullptr, nullptr, nullptr);
    if (!session.scaler) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to create the FFmpeg RGB conversion context.");
        }
        return QImage();
    }

    uint8_t* destinationData[4] = {image.bits(), nullptr, nullptr, nullptr};
    int destinationLinesize[4] = {image.bytesPerLine(), 0, 0, 0};
    const int scaledRows = sws_scale(session.scaler, frame->data, frame->linesize, 0, frame->height, destinationData, destinationLinesize);
    if (scaledRows != frame->height) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("FFmpeg did not convert the complete preview frame.");
        }
        return QImage();
    }
    return image;
}

bool decodeFirstFrame(InputSession& session, QImage* firstFrame, QString* errorMessage) {
    AVPacket* packet = av_packet_alloc();
    AVFrame* frame = av_frame_alloc();
    if (!packet || !frame) {
        av_packet_free(&packet);
        av_frame_free(&frame);
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to allocate FFmpeg probe buffers.");
        }
        return false;
    }

    bool decoded = false;
    while (!decoded && av_read_frame(session.format, packet) >= 0) {
        if (packet->stream_index == session.videoStreamIndex) {
            const int sendResult = avcodec_send_packet(session.decoder, packet);
            if (sendResult >= 0) {
                while (avcodec_receive_frame(session.decoder, frame) >= 0) {
                    QImage image = convertFrame(session, frame, errorMessage);
                    if (!image.isNull()) {
                        if (firstFrame) {
                            *firstFrame = std::move(image);
                        }
                        decoded = true;
                        break;
                    }
                }
            }
        }
        av_packet_unref(packet);
    }

    av_packet_free(&packet);
    av_frame_free(&frame);
    if (!decoded && errorMessage && errorMessage->isEmpty()) {
        *errorMessage = QStringLiteral("The movie contains no decodable video frames.");
    }
    return decoded;
}

void sleepUntil(QElapsedTimer& clock, qint64 targetMs, std::atomic<bool>& stopRequested) {
    while (!stopRequested.load()) {
        const qint64 remaining = targetMs - clock.elapsed();
        if (remaining <= 0) {
            return;
        }
        QThread::msleep(static_cast<unsigned long>(std::min<qint64>(remaining, 10)));
    }
}

#endif

}  // namespace

bool FfmpegFileReader::isAvailable() noexcept {
#ifdef GUARD_ENABLE_FFMPEG
    return true;
#else
    return false;
#endif
}

FfmpegFileProbeResult FfmpegFileReader::probe(const QString& path) {
    FfmpegFileProbeResult result;
#ifndef GUARD_ENABLE_FFMPEG
    Q_UNUSED(path);
    result.errorMessage = QStringLiteral("FFmpeg development libraries are not enabled.");
    return result;
#else
    InputSession session;
    if (!openSession(path, &session, &result.errorMessage)) {
        return result;
    }

    result.width = session.videoStream->codecpar->width;
    result.height = session.videoStream->codecpar->height;
    result.fps = streamFps(session.videoStream);
    result.frameCount = session.videoStream->nb_frames > 0 ? static_cast<qint64>(session.videoStream->nb_frames) : -1;
    result.durationMs = estimatedDurationMs(session);
    if (result.frameCount <= 0 && result.durationMs > 0 && result.fps > 0.0) {
        result.frameCount = static_cast<qint64>(std::llround(static_cast<double>(result.durationMs) * result.fps / 1000.0));
    }
    result.encodedStreamInfo = makeStreamInfo(session);
    if (!decodeFirstFrame(session, &result.firstFrame, &result.errorMessage)) {
        return result;
    }
    result.ok = true;
    return result;
#endif
}

bool FfmpegFileReader::playLoop(const QString& path, quint64 startSequence, qint64 startTimestampMs, quint64 generation,
                                std::atomic<bool>& stopRequested, const FrameCallback& frameCallback, const PacketCallback& packetCallback,
                                const StreamInfoCallback& streamInfoCallback, const ErrorCallback& errorCallback) {
#ifndef GUARD_ENABLE_FFMPEG
    Q_UNUSED(path);
    Q_UNUSED(startSequence);
    Q_UNUSED(startTimestampMs);
    Q_UNUSED(generation);
    Q_UNUSED(stopRequested);
    Q_UNUSED(frameCallback);
    Q_UNUSED(packetCallback);
    Q_UNUSED(streamInfoCallback);
    if (errorCallback) {
        errorCallback(QStringLiteral("FFmpeg development libraries are not enabled."));
    }
    return false;
#else
    quint64 sequence = startSequence;
    quint64 packetSequence = 0;
    qint64 loopOffsetMs = 0;
    QElapsedTimer playbackClock;
    playbackClock.start();

    while (!stopRequested.load()) {
        InputSession session;
        QString errorMessage;
        if (!openSession(path, &session, &errorMessage)) {
            if (errorCallback) {
                errorCallback(errorMessage);
            }
            return false;
        }

        if (streamInfoCallback) {
            streamInfoCallback(makeStreamInfo(session));
        }

        const qint64 sourceStartMs = streamStartMs(session.videoStream);
        const qint64 declaredDurationMs = estimatedDurationMs(session);
        qint64 latestPacketTimeMs = 0;
        qint64 latestFrameTimeMs = 0;

        AVPacket* packet = av_packet_alloc();
        AVFrame* frame = av_frame_alloc();
        if (!packet || !frame) {
            av_packet_free(&packet);
            av_frame_free(&frame);
            if (errorCallback) {
                errorCallback(QStringLiteral("Unable to allocate FFmpeg playback buffers."));
            }
            return false;
        }

        while (!stopRequested.load() && av_read_frame(session.format, packet) >= 0) {
            if (packet->stream_index != session.videoStreamIndex) {
                av_packet_unref(packet);
                continue;
            }

            const qint64 packetClockTs = packet->dts != AV_NOPTS_VALUE ? packet->dts : packet->pts;
            qint64 packetTimeMs = timestampToMs(packetClockTs, session.videoStream->time_base) - sourceStartMs;
            packetTimeMs = std::max<qint64>(0, packetTimeMs);
            latestPacketTimeMs = std::max(latestPacketTimeMs, packetTimeMs);
            sleepUntil(playbackClock, loopOffsetMs + packetTimeMs, stopRequested);
            if (stopRequested.load()) {
                av_packet_unref(packet);
                break;
            }

            if (packetCallback && packet->data && packet->size > 0) {
                recording::EncodedVideoPacket encoded;
                encoded.generation = generation;
                encoded.packetSequence = packetSequence++;
                encoded.data = QByteArray(reinterpret_cast<const char*>(packet->data), packet->size);
                encoded.timeBaseNumerator = session.videoStream->time_base.num;
                encoded.timeBaseDenominator = session.videoStream->time_base.den;
                const qint64 loopOffsetTs = av_rescale_q(loopOffsetMs, AVRational{1, 1000}, session.videoStream->time_base);
                encoded.hasPts = packet->pts != AV_NOPTS_VALUE;
                encoded.hasDts = packet->dts != AV_NOPTS_VALUE;
                encoded.pts = encoded.hasPts ? packet->pts + loopOffsetTs : 0;
                encoded.dts = encoded.hasDts ? packet->dts + loopOffsetTs : 0;
                encoded.duration = std::max<qint64>(0, packet->duration);
                encoded.playbackTimestampMs = startTimestampMs + loopOffsetMs + packetTimeMs;
                encoded.keyFrame = (packet->flags & AV_PKT_FLAG_KEY) != 0;
                packetCallback(std::move(encoded));
            }

            const int sendResult = avcodec_send_packet(session.decoder, packet);
            av_packet_unref(packet);
            if (sendResult < 0 && sendResult != AVERROR(EAGAIN)) {
                if (errorCallback) {
                    errorCallback(QStringLiteral("FFmpeg rejected a video packet: %1").arg(ffmpegError(sendResult)));
                }
                av_packet_free(&packet);
                av_frame_free(&frame);
                return false;
            }

            for (;;) {
                const int receiveResult = avcodec_receive_frame(session.decoder, frame);
                if (receiveResult == AVERROR(EAGAIN) || receiveResult == AVERROR_EOF) {
                    break;
                }
                if (receiveResult < 0) {
                    if (errorCallback) {
                        errorCallback(QStringLiteral("FFmpeg frame decoding failed: %1").arg(ffmpegError(receiveResult)));
                    }
                    av_packet_free(&packet);
                    av_frame_free(&frame);
                    return false;
                }

                const qint64 frameTs = frame->best_effort_timestamp;
                qint64 frameTimeMs = timestampToMs(frameTs, session.videoStream->time_base) - sourceStartMs;
                frameTimeMs = std::max<qint64>(0, frameTimeMs);
                latestFrameTimeMs = std::max(latestFrameTimeMs, frameTimeMs);
                sleepUntil(playbackClock, loopOffsetMs + frameTimeMs, stopRequested);
                if (stopRequested.load()) {
                    break;
                }

                QString conversionError;
                QImage image = convertFrame(session, frame, &conversionError);
                if (image.isNull()) {
                    if (errorCallback) {
                        errorCallback(conversionError);
                    }
                    av_packet_free(&packet);
                    av_frame_free(&frame);
                    return false;
                }
                if (frameCallback) {
                    frameCallback(std::move(image), sequence++, startTimestampMs + loopOffsetMs + frameTimeMs);
                }
                av_frame_unref(frame);
            }
        }

        if (!stopRequested.load()) {
            avcodec_send_packet(session.decoder, nullptr);
            while (!stopRequested.load()) {
                const int receiveResult = avcodec_receive_frame(session.decoder, frame);
                if (receiveResult == AVERROR_EOF || receiveResult == AVERROR(EAGAIN)) {
                    break;
                }
                if (receiveResult < 0) {
                    break;
                }
                const qint64 frameTs = frame->best_effort_timestamp;
                qint64 frameTimeMs = timestampToMs(frameTs, session.videoStream->time_base) - sourceStartMs;
                frameTimeMs = std::max<qint64>(0, frameTimeMs);
                latestFrameTimeMs = std::max(latestFrameTimeMs, frameTimeMs);
                sleepUntil(playbackClock, loopOffsetMs + frameTimeMs, stopRequested);
                QString conversionError;
                QImage image = convertFrame(session, frame, &conversionError);
                if (!image.isNull() && frameCallback) {
                    frameCallback(std::move(image), sequence++, startTimestampMs + loopOffsetMs + frameTimeMs);
                }
                av_frame_unref(frame);
            }
        }

        av_packet_free(&packet);
        av_frame_free(&frame);

        if (stopRequested.load()) {
            break;
        }

        const qint64 observedDurationMs =
          std::max(latestPacketTimeMs, latestFrameTimeMs) + static_cast<qint64>(1000.0 / std::max(1.0, streamFps(session.videoStream)));
        const qint64 loopDurationMs = std::max<qint64>(1, std::max(declaredDurationMs, observedDurationMs));
        loopOffsetMs += loopDurationMs;
    }
    return true;
#endif
}

}  // namespace media
}  // namespace guard
