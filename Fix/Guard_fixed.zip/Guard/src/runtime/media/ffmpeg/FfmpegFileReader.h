#pragma once

#include <QImage>
#include <QString>
#include <QtGlobal>

#include <atomic>
#include <functional>

#include "media/recording/EncodedVideoTypes.h"

namespace guard {
namespace media {

struct FfmpegFileProbeResult {
    bool ok = false;
    QString errorMessage;
    int width = 0;
    int height = 0;
    double fps = 0.0;
    qint64 frameCount = -1;
    qint64 durationMs = 0;
    QImage firstFrame;
    recording::EncodedStreamInfo encodedStreamInfo;
};

class FfmpegFileReader final {
public:
    using FrameCallback = std::function<void(QImage, quint64, qint64)>;
    using PacketCallback = std::function<void(recording::EncodedVideoPacket)>;
    using StreamInfoCallback = std::function<void(recording::EncodedStreamInfo)>;
    using ErrorCallback = std::function<void(const QString&)>;

    static bool isAvailable() noexcept;
    static FfmpegFileProbeResult probe(const QString& path);

    static bool playLoop(const QString& path, quint64 startSequence, qint64 startTimestampMs, quint64 generation, std::atomic<bool>& stopRequested,
                         const FrameCallback& frameCallback, const PacketCallback& packetCallback, const StreamInfoCallback& streamInfoCallback,
                         const ErrorCallback& errorCallback);
};

}  // namespace media
}  // namespace guard
