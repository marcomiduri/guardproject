#pragma once

#include <QImage>
#include <QObject>
#include <QString>

#include <atomic>

#include "media/recording/EncodedVideoTypes.h"

class FileDecoderWorker : public QObject {
    Q_OBJECT

public:
    explicit FileDecoderWorker(QObject* parent = nullptr);

    void requestStop();
    void cancelGeneration(quint64 generation);
    bool isDecoding() const;

public slots:
    void openSource(const QString& path, quint64 generation);
    void startDecoding(quint64 startSequence, qint64 startTimestampMs, quint64 generation);
    void stopDecoding();

signals:
    void sourceOpened(bool isMovie, int width, int height, double fps, qint64 frameCount, QImage firstFrame, quint64 generation);
    void encodedStreamInfoReady(guard::recording::EncodedStreamInfo streamInfo, quint64 generation);
    void encodedPacketDecoded(guard::recording::EncodedVideoPacket packet);
    void frameDecoded(QImage frame, quint64 sequence, qint64 timestampMs, quint64 generation);
    void playbackFinished();
    void decoderError(QString message, quint64 generation);
    void decodingStopped();

private:
    void sleepInterruptible(int ms);

    QString path_;
    std::atomic<bool> stopRequested_{false};
    std::atomic<bool> decoding_{false};
    std::atomic<quint64> cancelledThroughGeneration_{0};
    bool isMovie_ = false;
    bool useFfmpegForMovie_ = false;
    int width_ = 0;
    int height_ = 0;
    double fps_ = 0.0;
    qint64 frameCount_ = -1;
    guard::recording::EncodedStreamInfo encodedStreamInfo_;
    QImage stillImage_;
};
