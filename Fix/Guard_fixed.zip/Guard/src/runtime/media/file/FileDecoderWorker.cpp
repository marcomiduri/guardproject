#include "media/file/FileDecoderWorker.h"

#include "media/common/OpenCvFrameConverter.h"
#include "media/ffmpeg/FfmpegFileReader.h"

#include <QCoreApplication>
#include <QDir>
#include <QFileInfo>
#include <QImageReader>
#include <QThread>

#include <algorithm>
#include <utility>

#include <opencv2/videoio.hpp>

namespace {

constexpr double kFallbackFps = 25.0;
// Still images repeat for software detection, but native Identify/HazardDetect stacks are
// not safe at live-camera frame rates on large RGB buffers.
constexpr double kStillImageFps = 4.0;
constexpr int kMaxStillImageDimension = 1920;

QImage prepareStillImage(QImage image) {
    if (image.isNull()) {
        return image;
    }
    if (image.width() > kMaxStillImageDimension || image.height() > kMaxStillImageDimension) {
        image = image.scaled(kMaxStillImageDimension, kMaxStillImageDimension, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    }
    return image.convertToFormat(QImage::Format_RGB888);
}

int frameDelayMsForFps(double fps) {
    if (fps <= 1.0 || fps > 240.0) {
        fps = kFallbackFps;
    }
    return std::max(1, static_cast<int>(1000.0 / fps));
}

bool isMovieExtension(const QString& path) {
    const QString suffix = QFileInfo(path).suffix().toLower();
    return suffix == QStringLiteral("mp4") || suffix == QStringLiteral("avi") || suffix == QStringLiteral("mov") || suffix == QStringLiteral("mkv");
}

bool openVideoCapture(cv::VideoCapture& capture, const QString& path) {
    const QByteArray nativePath = QDir::toNativeSeparators(path).toLocal8Bit();
    return capture.open(nativePath.constData());
}

bool hasOpenCvVideoioPlugin() {
    const QDir appDir(QCoreApplication::applicationDirPath());
    return !appDir.entryList(QStringList() << QStringLiteral("opencv_videoio_ffmpeg*_64.dll"), QDir::Files).isEmpty();
}

QString videoOpenFailureMessage(const QString& path, const QString& ffmpegStatus, const QString& opencvStatus) {
    const QFileInfo fileInfo(path);
    QStringList lines;
    lines << QStringLiteral("Unable to open test video.") << QString() << QStringLiteral("File:") << fileInfo.absoluteFilePath() << QString()
          << QStringLiteral("Direct FFmpeg:") << ffmpegStatus << QString() << QStringLiteral("OpenCV fallback:") << opencvStatus;

    if (!hasOpenCvVideoioPlugin()) {
        lines << QStringLiteral("The OpenCV FFmpeg videoio plugin was not found beside Guard.exe.");
    }

    lines << QString() << QStringLiteral("Possible causes:") << QStringLiteral("- unsupported codec")
          << QStringLiteral("- missing FFmpeg runtime DLL") << QStringLiteral("- missing OpenCV videoio plugin")
          << QStringLiteral("- file is unreadable or corrupt");
    return lines.join(QLatin1Char('\n'));
}

}  // namespace

FileDecoderWorker::FileDecoderWorker(QObject* parent) : QObject(parent) {}

void FileDecoderWorker::requestStop() {
    stopRequested_ = true;
}

void FileDecoderWorker::cancelGeneration(quint64 generation) {
    quint64 current = cancelledThroughGeneration_.load(std::memory_order_acquire);
    while (current < generation &&
           !cancelledThroughGeneration_.compare_exchange_weak(current, generation, std::memory_order_release, std::memory_order_acquire)) {
    }
    stopRequested_ = true;
}

bool FileDecoderWorker::isDecoding() const {
    return decoding_.load();
}

void FileDecoderWorker::sleepInterruptible(int ms) {
    int remaining = ms;
    while (remaining > 0 && !stopRequested_.load()) {
        const int chunk = std::min(remaining, 10);
        QThread::msleep(static_cast<unsigned long>(chunk));
        remaining -= chunk;
    }
}

void FileDecoderWorker::openSource(const QString& path, quint64 generation) {
    path_ = path;
    stopRequested_ = false;
    isMovie_ = false;
    useFfmpegForMovie_ = false;
    width_ = 0;
    height_ = 0;
    fps_ = 0.0;
    frameCount_ = -1;
    encodedStreamInfo_ = guard::recording::EncodedStreamInfo{};
    stillImage_ = QImage();
    emit encodedStreamInfoReady(encodedStreamInfo_, generation);

    if (path.isEmpty()) {
        emit decoderError(QStringLiteral("No source path provided."), generation);
        return;
    }

    const QFileInfo fileInfo(path);
    if (!fileInfo.exists() || !fileInfo.isFile() || !fileInfo.isReadable()) {
        emit decoderError(
          QStringLiteral("Unable to open test media.\n\nFile:\n%1\n\nThe file does not exist, is not a regular file, or is not readable.")
            .arg(fileInfo.absoluteFilePath()),
          generation);
        return;
    }

    if (isMovieExtension(path)) {
        QString ffmpegStatus;
        if (guard::media::FfmpegFileReader::isAvailable()) {
            const guard::media::FfmpegFileProbeResult probe = guard::media::FfmpegFileReader::probe(path);
            if (probe.ok) {
                isMovie_ = true;
                useFfmpegForMovie_ = true;
                width_ = probe.width;
                height_ = probe.height;
                fps_ = probe.fps;
                frameCount_ = probe.frameCount;
                encodedStreamInfo_ = probe.encodedStreamInfo;
                emit encodedStreamInfoReady(encodedStreamInfo_, generation);
                emit sourceOpened(true, width_, height_, fps_, frameCount_, probe.firstFrame, generation);
                return;
            }
            ffmpegStatus = probe.errorMessage.isEmpty() ? QStringLiteral("failed without details") : probe.errorMessage;
        } else {
            ffmpegStatus = QStringLiteral("disabled at qmake time; GUARD_ENABLE_FFMPEG is not defined.");
        }

        cv::VideoCapture capture;
        if (!openVideoCapture(capture, path)) {
            emit decoderError(
              videoOpenFailureMessage(fileInfo.absoluteFilePath(), ffmpegStatus, QStringLiteral("OpenCV VideoCapture could not open the file.")),
              generation);
            return;
        }

        isMovie_ = true;
        width_ = static_cast<int>(capture.get(cv::CAP_PROP_FRAME_WIDTH));
        height_ = static_cast<int>(capture.get(cv::CAP_PROP_FRAME_HEIGHT));
        fps_ = capture.get(cv::CAP_PROP_FPS);
        if (fps_ <= 1.0 || fps_ > 240.0) {
            fps_ = kFallbackFps;
        }
        frameCount_ = static_cast<qint64>(capture.get(cv::CAP_PROP_FRAME_COUNT));

        cv::Mat frame;
        if (!capture.read(frame) || frame.empty()) {
            emit decoderError(videoOpenFailureMessage(fileInfo.absoluteFilePath(), ffmpegStatus,
                                                      QStringLiteral("OpenCV VideoCapture opened the file, but it produced no decodable frames.")),
                              generation);
            return;
        }

        emit sourceOpened(true, width_, height_, fps_, frameCount_, guard::media::bgrMatToRgbImage(frame), generation);
        return;
    }

    QImageReader reader(path);
    reader.setAutoTransform(true);
    if (!reader.canRead()) {
        emit decoderError(QStringLiteral("Unsupported or unreadable image: %1").arg(path), generation);
        return;
    }

    const QImage image = prepareStillImage(reader.read());
    if (image.isNull()) {
        emit decoderError(QStringLiteral("Failed to decode image: %1").arg(reader.errorString()), generation);
        return;
    }

    isMovie_ = false;
    stillImage_ = image;
    width_ = image.width();
    height_ = image.height();
    fps_ = kStillImageFps;
    frameCount_ = 1;
    emit sourceOpened(false, width_, height_, fps_, frameCount_, stillImage_, generation);
}

void FileDecoderWorker::startDecoding(quint64 startSequence, qint64 startTimestampMs, quint64 generation) {
    // Clear a previous generation's stop flag before checking this generation.
    // cancelGeneration() advances cancelledThroughGeneration_, so a stop that
    // races this queued start can never be lost by resetting stopRequested_.
    stopRequested_.store(false, std::memory_order_release);
    if (generation <= cancelledThroughGeneration_.load(std::memory_order_acquire)) {
        stopRequested_.store(true, std::memory_order_release);
        emit decodingStopped();
        return;
    }

    decoding_.store(true, std::memory_order_release);
    struct DecodingScope {
        std::atomic<bool>* decoding;
        FileDecoderWorker* worker;
        ~DecodingScope() {
            decoding->store(false, std::memory_order_release);
            emit worker->decodingStopped();
        }
    } decodingScope{&decoding_, this};

    // A disconnect may arrive after the first cancellation check but before
    // decoding_ becomes visible to the controller. Recheck before producing
    // any frame so stopAndWaitForQuiescence() may safely complete early.
    if (generation <= cancelledThroughGeneration_.load(std::memory_order_acquire) || stopRequested_.load(std::memory_order_acquire)) {
        return;
    }

    if (path_.isEmpty()) {
        emit decoderError(QStringLiteral("No source loaded."), generation);
        return;
    }

    if (!isMovie_) {
        if (stillImage_.isNull()) {
            QImageReader reader(path_);
            reader.setAutoTransform(true);
            stillImage_ = prepareStillImage(reader.read());
            if (stillImage_.isNull()) {
                emit decoderError(QStringLiteral("Failed to decode image: %1").arg(reader.errorString()), generation);
                return;
            }
        }

        const int frameDelayMs = frameDelayMsForFps(kStillImageFps);
        quint64 sequence = startSequence;
        qint64 timestampMs = startTimestampMs;
        while (!stopRequested_.load(std::memory_order_acquire) && generation > cancelledThroughGeneration_.load(std::memory_order_acquire)) {
            emit frameDecoded(stillImage_, sequence, timestampMs, generation);
            ++sequence;
            timestampMs += frameDelayMs;
            sleepInterruptible(frameDelayMs);
        }
        return;
    }

    if (useFfmpegForMovie_) {
        guard::media::FfmpegFileReader::playLoop(
          path_, startSequence, startTimestampMs, generation, stopRequested_,
          [this, generation](QImage image, quint64 sequence, qint64 timestampMs) {
              if (generation > cancelledThroughGeneration_.load(std::memory_order_acquire) && !stopRequested_.load(std::memory_order_acquire)) {
                  emit frameDecoded(std::move(image), sequence, timestampMs, generation);
              }
          },
          [this](guard::recording::EncodedVideoPacket packet) { emit encodedPacketDecoded(std::move(packet)); },
          [this, generation](guard::recording::EncodedStreamInfo streamInfo) {
              encodedStreamInfo_ = streamInfo;
              emit encodedStreamInfoReady(std::move(streamInfo), generation);
          },
          [this, generation](const QString& message) { emit decoderError(message, generation); });
        return;
    }

    const double fps = (fps_ > 1.0 && fps_ <= 240.0) ? fps_ : kFallbackFps;
    const int frameDelayMs = frameDelayMsForFps(fps);
    quint64 sequence = startSequence;
    qint64 timestampMs = startTimestampMs;

    while (!stopRequested_.load()) {
        cv::VideoCapture capture;
        if (!openVideoCapture(capture, path_) || !capture.isOpened()) {
            emit decoderError(QStringLiteral("Unable to reopen movie: %1").arg(path_), generation);
            return;
        }

        cv::Mat frame;
        while (!stopRequested_.load(std::memory_order_acquire) && generation > cancelledThroughGeneration_.load(std::memory_order_acquire) &&
               capture.read(frame)) {
            if (frame.empty()) {
                break;
            }
            emit frameDecoded(guard::media::bgrMatToRgbImage(frame), sequence, timestampMs, generation);
            ++sequence;
            timestampMs += frameDelayMs;
            sleepInterruptible(frameDelayMs);
        }
    }
}

void FileDecoderWorker::stopDecoding() {
    stopRequested_ = true;
}
