#ifndef CAMERARUNTIMECONTROLLER_H
#define CAMERARUNTIMECONTROLLER_H

#include "CameraDetectionSettings.h"
#include "CameraTestSourceSettings.h"
#include "CameraUiModel.h"
#include "CameraView.h"
#include "model/GuardEventModels.h"
#include "FrameSubmissionPipeline.h"
#include "media/MediaSourceController.h"
#include "media/hikvision/CameraOnboardTypes.h"
#include "media/recording/MotionVideoRecorder.h"
#include "platform/diagnostics/CameraFileLogger.h"

#include <QHash>
#include <QElapsedTimer>
#include <QObject>
#include <QPointer>
#include <QStringList>
#include <QTimer>
#include <QVector>

namespace guardvision {
class GuardVision;
}

namespace guard {
namespace recording {
class RecordingStorageManager;
}
}  // namespace guard

class GuardVisionEventListenerAdapter;

class CameraRuntimeController : public QObject {
    Q_OBJECT

public:
    enum class State { Disconnected, Connecting, Connected, Reconnecting, Error };
    Q_ENUM(State)

    CameraRuntimeController(const CameraUiModel& camera, guardvision::GuardVision* guardVision, GuardVisionEventListenerAdapter* eventAdapter,
                            CameraView* view, bool testMode, guard::recording::RecordingStorageManager* storageManager = nullptr,
                            const QString& retainedStreamId = QString(), bool retainedNativeFaceIdentificationPrepared = false,
                            quint64 retainedNextSubmissionSequence = 0, qint64 retainedNextSubmissionTimestampMs = 0, QObject* parent = nullptr);
    ~CameraRuntimeController() override;

    QString cameraId() const;
    QString streamId() const;
    CameraUiModel camera() const;
    CameraDetectionSettings detectionSettings() const;
    CameraTestSourceSettings testSourceSettings() const;
    guard::CameraOnboardCapabilities capabilities() const;
    QStringList logMessages() const;
    QString logFilePath() const;
    QString logDirectoryPath() const;
    bool fileLoggingEnabled() const;
    State state() const;
    bool isConnected() const;
    bool isStreamRegistered() const;
    bool ownsReusableGuardVisionStreamSlot() const;
    bool isGuardVisionStreamActive() const;
    bool isNativeFaceIdentificationPrepared() const;
    quint64 nextSubmissionSequence() const;
    qint64 nextSubmissionTimestampMs() const;

    void updateCamera(const CameraUiModel& camera);
    void setFileLoggingEnabled(bool enabled);
    void reloadFileLoggingSettings();
    bool start(QString* errorMessage = nullptr);
    void stop();
    void requestStop();
    void prepareForApplicationShutdown();
    bool applyDetectionSettings(const CameraDetectionSettings& settings, QString* errorMessage = nullptr);
    bool applyCameraSettings(const CameraDetectionSettings& settings, const CameraTestSourceSettings& testSourceSettings,
                             QString* errorMessage = nullptr);
    bool prepareFaceIdentification(float threshold, QString* errorMessage = nullptr);
    void suspendFaceIdentification();
    void syncFaceIdentificationFromRegistry(float threshold, const QHash<quint64, QString>& displayNamesById);

signals:
    void stateChanged(QString cameraId, int state, QString message);
    void settingsChanged(QString cameraId);
    void capabilitiesChanged(QString cameraId);
    void logAppended(QString cameraId, QString message);
    void logFileChanged(QString cameraId, QString filePath);
    void fatalRuntimeError(QString cameraId, QString message);
    void faceOccurrenceReady(GuardFaceOccurrence occurrence);
    void faceTrackLost(QString cameraId, quint64 trackId);
    void hazardOccurrenceReady(GuardHazardOccurrence occurrence);
    void hazardSessionStopped(QString localCameraKey);
    void guardVisionStreamRegistered(QString cameraId);
    void faceIdentificationUnavailable(QString cameraId, QString message);

private:
    bool configureSource(QString* errorMessage);
    bool validateTestSourceSettings(const CameraTestSourceSettings& settings, QString* errorMessage) const;
    bool registerStream(QString* errorMessage);
    void beginStop();
    void continueAsynchronousStop();
    void finalizeStop();
    void stopSynchronouslyForDestruction();
    QString buildRtspUrl() const;
    void handleDecodedFrame(const QImage& frame, quint64 sequence, qint64 timestampMs, quint64 generation);
    QImage frameForEvent(quint64 sequence, qint64 timestampMs) const;
    void setState(State state, const QString& message = QString());
    void appendLog(const QString& message);
    void resetRuntimeState();
    bool shouldUseFreshStreamForStillImageFaceSession() const;
    void retireRetainedStreamForFreshStillImageFaceSession();
    void clearDisabledOverlays();
    void refreshMotionOverlay();
    void refreshHazardOverlays();
    bool applyConfigsToRegisteredStream(const CameraDetectionSettings& settings, QString* errorMessage);
    bool waitForGuardVisionStreamIdle(int timeoutMs, int quietPeriodMs = 150) const;
    guardvision::FaceConfig effectiveFaceConfig(const guardvision::FaceConfig& configured) const;

    void onMotionEvent(QString streamId, int eventType, int motionState, quint64 generation, quint64 sequence, qint64 timestampMs, double score,
                       double changedAreaRatio, int regionCount, int analysisX, int analysisY, int analysisWidth, int analysisHeight,
                       QVector<QRect> regions, QVector<double> regionScores, QVector<double> regionAreaRatios);
    void onFaceEvent(QString streamId, int eventType, quint64 generation, quint64 sequence, qint64 timestampMs, QVector<QRect> bounds,
                     QVector<quint64> trackIds, QVector<quint64> identityIds, QVector<QString> displayNames, QVector<double> identityConfidences,
                     QVector<bool> identifiedFlags);
    void onHazardEvent(QString streamId, int eventType, quint64 generation, quint64 sequence, qint64 timestampMs, QVector<QRect> bounds,
                       QVector<int> hazardTypes, QVector<double> confidences);
    void onAlarmEvent(QString streamId, quint64 generation, int alarmType, int alarmState, int alarmSource, qint64 timestampMs, double confidence,
                      QVector<QRect> regions, QString onboardTargetId, quint64 softwareTrackId);

    CameraUiModel camera_;
    CameraDetectionSettings settings_;
    CameraTestSourceSettings testSourceSettings_;
    bool testMode_ = false;
    guardvision::GuardVision* guardVision_ = nullptr;
    GuardVisionEventListenerAdapter* eventAdapter_ = nullptr;
    QPointer<CameraView> view_;

    MediaSourceController mediaController_;
    guard::recording::MotionVideoRecorder recorder_;
    QTimer stopPollTimer_;
    QElapsedTimer stopElapsed_;
    guard::CameraOnboardCapabilities capabilities_;
    SubmissionState submissionState_;

    QString streamId_;
    State state_ = State::Disconnected;
    bool streamRegistered_ = false;
    // True as soon as this controller is assigned a process-lifetime native
    // stream slot, including before the controller has ever been started.
    // Room switches may create and remove controllers without playing them;
    // the slot must still be returned to MainWindow instead of being lost.
    bool ownsReusableGuardVisionStreamSlot_ = false;
    // GuardVision per-stream unregister currently tears down vendor face sessions.
    // On Windows this has proven unsafe while another camera stream remains active.
    // A disconnected camera therefore retains its registered GuardVision stream
    // and reuses it on the next Connect. The shared GuardVision shutdown releases
    // all retained streams after every media producer has stopped.
    bool streamRetainedForReuse_ = false;
    bool retainedStreamNativeFaceIdentificationPrepared_ = false;
    quint64 registeredGuardVisionGeneration_ = 0;
    bool stopping_ = false;
    bool preparedForApplicationShutdown_ = false;
    bool stopTimeoutLogged_ = false;
    bool sourceReplacementInProgress_ = false;
    quint64 stoppingSourceGeneration_ = 0;
    QHash<quint64, QString> faceDisplayNamesById_;
    // Identity results are trusted only while a room-scoped registry is active.
    // The native IdentifyEngine, once prepared, remains configured for the
    // process lifetime to avoid unsafe vendor-session teardown during room
    // transitions; stale identities are masked at the Guard boundary.
    bool faceIdentificationEnabled_ = false;
    // Registry intent is separate from actual native session state. A camera
    // controller may receive a room registry before its retained stream is
    // activated, but that must never mark the vendor Identify session prepared.
    bool faceIdentificationRequested_ = false;
    bool nativeFaceIdentificationPrepared_ = false;
    qint64 lastStillImagePipelineMs_ = 0;
    int stillImageGuardVisionSubmissions_ = 0;
    bool stillImageSubmissionPausedLogged_ = false;

    static constexpr int kStillImagePipelineIntervalMs = 250;
    static constexpr int kStillImageHazardPipelineIntervalMs = 750;
    static constexpr int kMaxStillImageGuardVisionSubmissions = 4;

    // GuardVision owns a lifecycle generation for each registered stream.
    // The media source owns a separate generation for decoded/encoded data.
    // They are intentionally independent and must never be compared or
    // forwarded interchangeably.
    quint64 activeGuardVisionGeneration_ = 0;
    quint64 activeSourceGeneration_ = 0;

    struct RecentFrame {
        quint64 sequence = 0;
        qint64 timestampMs = 0;
    };
    QVector<RecentFrame> recentFrames_;
    QImage latestFrame_;
    QVector<CameraFaceOverlay> faceOverlays_;
    QVector<CameraMotionOverlay> motionOverlays_;
    QVector<CameraHazardOverlay> fireOverlays_;
    QVector<CameraHazardOverlay> smokeOverlays_;
    QStringList logs_;
    guard::diagnostics::CameraFileLogger fileLogger_;
    bool fileLoggingEnabled_ = true;
    QString lastFileLogError_;
};

#endif  // CAMERARUNTIMECONTROLLER_H
