#pragma once

#include "CameraUiModel.h"

#include <QString>
#include <QtGlobal>

namespace guard {
namespace events {

QString faceTrackKey(const QString& cameraId, quint64 trackId);
QString faceOverlayLabel(bool identified, const QString& displayName, double identityConfidence);
bool canUploadFaceEvent(const CameraUiModel& camera);
bool shouldSendRecognizedFaceEvent(bool recognizedSent, bool identified, quint64 faceRegistryId);
bool shouldSendUnknownFaceOnTrackLost(bool unknownSent, bool recognizedSent, bool frameIsNull);
bool shouldSendUnknownFaceAfterDelay(bool unknownSent, bool recognizedSent, bool identified, qint64 elapsedMs, int delayMs, bool faceRegistryLoaded);
bool shouldPlayUnknownIncomingVoice(bool incoming, bool notifyUnknownIncoming);
bool shouldPlayUnapprovedIncomingVoice(bool incoming, bool approved, bool notifyUnapprovedIncoming);

}  // namespace events
}  // namespace guard
