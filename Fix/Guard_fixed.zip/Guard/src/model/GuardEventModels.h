#pragma once

#include "CameraUiModel.h"

#include <QImage>
#include <QMetaType>
#include <QRect>
#include <QString>
#include <QVector>

struct GuardFaceOccurrence {
    CameraUiModel camera;
    quint64 trackId = 0;
    quint64 faceRegistryId = 0;
    bool identified = false;
    QString displayName;
    double similarity = 0.0;
    QRect bounds;
    qint64 timestampMs = 0;
    QImage frame;
};

struct GuardHazardDetection {
    QRect bounds;
    int hazardType = 0;
    double confidence = 0.0;
};

struct GuardHazardOccurrence {
    CameraUiModel camera;
    int eventType = 0;
    qint64 timestampMs = 0;
    QVector<GuardHazardDetection> detections;
    QImage frame;
};

Q_DECLARE_METATYPE(GuardFaceOccurrence)
Q_DECLARE_METATYPE(GuardHazardOccurrence)
