#include "GuardFaceEventHelpers.h"

#include <QtMath>

namespace guard {
namespace events {

QString faceTrackKey(const QString& cameraId, quint64 trackId) {
    return QStringLiteral("%1:%2").arg(cameraId).arg(trackId);
}

QString faceOverlayLabel(bool identified, const QString& displayName, double identityConfidence) {
    const QString name = displayName.trimmed();
    if (identified && !name.isEmpty()) {
        return QStringLiteral("%1 %2%").arg(name).arg(qRound(identityConfidence * 100.0));
    }
    return QStringLiteral("UNKNOWN");
}

bool canUploadFaceEvent(const CameraUiModel& camera) {
    // Every backend face/hazard endpoint requires the canonical backend camera
    // identity. A local/client camera ID is never a valid upload identity.
    // This also prevents local monitoring in an intentionally disconnected
    // room state from issuing unauthenticated event requests.
    return !camera.backendCameraId.trimmed().isEmpty();
}

bool shouldSendRecognizedFaceEvent(bool recognizedSent, bool identified, quint64 faceRegistryId) {
    return !recognizedSent && identified && faceRegistryId > 0;
}

bool shouldSendUnknownFaceOnTrackLost(bool unknownSent, bool recognizedSent, bool frameIsNull) {
    return !unknownSent && !recognizedSent && !frameIsNull;
}

bool shouldSendUnknownFaceAfterDelay(bool unknownSent, bool recognizedSent, bool identified, qint64 elapsedMs, int delayMs, bool faceRegistryLoaded) {
    return faceRegistryLoaded && !unknownSent && !recognizedSent && !identified && elapsedMs >= delayMs;
}

bool shouldPlayUnknownIncomingVoice(bool incoming, bool notifyUnknownIncoming) {
    return incoming && notifyUnknownIncoming;
}

bool shouldPlayUnapprovedIncomingVoice(bool incoming, bool approved, bool notifyUnapprovedIncoming) {
    return incoming && !approved && notifyUnapprovedIncoming;
}

}  // namespace events
}  // namespace guard
