#include "GuardBackendModels.h"

#include <QCoreApplication>
#include <QJsonArray>
#include <QJsonValue>
#include <QtGlobal>

namespace guard {
namespace backend {

QJsonObject cameraToApiJson(const CameraUiModel& camera, const QString& roomId) {
    QJsonObject object;
    if (!camera.backendCameraId.trimmed().isEmpty())
        object.insert(QStringLiteral("id"), camera.backendCameraId.trimmed());
    object.insert(QStringLiteral("clientCameraId"), camera.effectiveClientCameraId());
    object.insert(QStringLiteral("roomId"), roomId.isEmpty() ? camera.roomId : roomId);
    object.insert(QStringLiteral("name"), camera.displayName());
    object.insert(QStringLiteral("type"), camera.type.contains(QStringLiteral("Hikvision"), Qt::CaseInsensitive) ? QStringLiteral("hikvision")
                                                                                                                 : QStringLiteral("generic_rtsp"));
    object.insert(QStringLiteral("direction"), cameraDirectionApiValue(camera.direction));
    object.insert(QStringLiteral("deviceAddress"), camera.address);
    object.insert(QStringLiteral("sdkPort"), camera.sdkPort);
    object.insert(QStringLiteral("rtspPort"), camera.rtspPort);
    if (!camera.rtspUrl.trimmed().isEmpty())
        object.insert(QStringLiteral("rtspUrl"), camera.rtspUrl.trimmed());
    object.insert(QStringLiteral("username"), camera.username);
    object.insert(QStringLiteral("password"), camera.password);
    object.insert(QStringLiteral("channel"), camera.channel);
    object.insert(QStringLiteral("streamType"), camera.stream.contains(QStringLiteral("Sub"), Qt::CaseInsensitive) ? 1 : 0);
    object.insert(QStringLiteral("sortOrder"), camera.sortOrder);
    return object;
}

QJsonObject roomConnectionRequestToApiJson(const RoomConnectionRequest& request) {
    QJsonObject object;
    object.insert(QStringLiteral("roomId"), request.roomId.trimmed());
    if (!request.hardwareId.trimmed().isEmpty())
        object.insert(QStringLiteral("hardwareId"), request.hardwareId.trimmed());
    if (!request.installationId.trimmed().isEmpty())
        object.insert(QStringLiteral("installationId"), request.installationId.trimmed());
    if (!request.deviceCredential.trimmed().isEmpty())
        object.insert(QStringLiteral("deviceCredential"), request.deviceCredential.trimmed());
    object.insert(QStringLiteral("deviceName"), request.deviceName.trimmed());
    object.insert(QStringLiteral("guardVersion"), request.applicationVersion.trimmed());
    QJsonArray cameras;
    for (const CameraUiModel& camera : request.cameras) {
        // Backend camera IDs are scoped to a room. Room connection is
        // idempotent by clientCameraId, so never send a mapping from the
        // previously connected room when selecting another room.
        QJsonObject cameraObject = cameraToApiJson(camera, request.roomId);
        cameraObject.remove(QStringLiteral("id"));
        cameras.append(cameraObject);
    }
    object.insert(QStringLiteral("cameras"), cameras);
    return object;
}

QString backendCameraIdFromApiJson(const QJsonObject& object) {
    const QString explicitId = object.value(QStringLiteral("backendCameraId")).toString().trimmed();
    if (!explicitId.isEmpty())
        return explicitId;
    return object.value(QStringLiteral("id")).toString().trimmed();
}

bool cameraFromApiJson(const QJsonObject& object, CameraUiModel* camera, QString* errorMessage) {
    if (!camera)
        return false;
    const QString backendId = backendCameraIdFromApiJson(object);
    if (backendId.isEmpty()) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Backend camera is missing id.");
        return false;
    }

    CameraUiModel parsed = *camera;
    parsed.backendCameraId = backendId;
    if (object.contains(QStringLiteral("clientCameraId"))) {
        parsed.clientCameraId = object.value(QStringLiteral("clientCameraId")).toString().trimmed();
    }
    if (parsed.id.isEmpty()) {
        parsed.id = parsed.clientCameraId.trimmed().isEmpty() ? backendId : parsed.clientCameraId;
    }
    if (object.contains(QStringLiteral("roomId"))) {
        parsed.roomId = object.value(QStringLiteral("roomId")).toString();
    }
    if (object.contains(QStringLiteral("name"))) {
        parsed.name = object.value(QStringLiteral("name")).toString();
    }
    if (object.contains(QStringLiteral("type"))) {
        const QString type = object.value(QStringLiteral("type")).toString();
        parsed.type = type == QStringLiteral("hikvision") ? QStringLiteral("Hikvision") : QStringLiteral("Generic (RTSP)");
    }
    if (object.contains(QStringLiteral("direction"))) {
        parsed.direction = cameraDirectionFromApiValue(object.value(QStringLiteral("direction")).toString());
        parsed.directionConfigured = true;
    }
    if (object.contains(QStringLiteral("deviceAddress"))) {
        parsed.address = object.value(QStringLiteral("deviceAddress")).toString();
    }
    if (object.contains(QStringLiteral("sdkPort"))) {
        parsed.sdkPort = object.value(QStringLiteral("sdkPort")).toInt(parsed.sdkPort);
    }
    if (object.contains(QStringLiteral("rtspPort"))) {
        parsed.rtspPort = object.value(QStringLiteral("rtspPort")).toInt(parsed.rtspPort);
    }
    if (object.contains(QStringLiteral("rtspUrl"))) {
        parsed.rtspUrl = object.value(QStringLiteral("rtspUrl")).toString();
    }
    if (object.contains(QStringLiteral("username"))) {
        parsed.username = object.value(QStringLiteral("username")).toString();
    }
    // Password may be intentionally omitted by the backend. Preserve the local value in that case.
    if (object.contains(QStringLiteral("password"))) {
        parsed.password = object.value(QStringLiteral("password")).toString();
    }
    if (object.contains(QStringLiteral("channel"))) {
        parsed.channel = object.value(QStringLiteral("channel")).toInt(parsed.channel);
    }
    if (object.contains(QStringLiteral("streamType"))) {
        parsed.stream = object.value(QStringLiteral("streamType")).toInt(0) == 1 ? QStringLiteral("Sub Stream") : QStringLiteral("Main Stream");
    }
    if (object.contains(QStringLiteral("sortOrder"))) {
        parsed.sortOrder = object.value(QStringLiteral("sortOrder")).toInt(parsed.sortOrder);
    }
    *camera = parsed;
    return true;
}

QDateTime parseUtcIso8601(const QJsonValue& value) {
    const QDateTime parsed = QDateTime::fromString(value.toString(), Qt::ISODate);
    return parsed.isValid() ? parsed.toUTC() : QDateTime();
}

QString deviceCredentialFromSessionJson(const QJsonObject& object) {
    return object.value(QStringLiteral("deviceCredential")).toString(object.value(QStringLiteral("deviceToken")).toString()).trimmed();
}

QString accessTokenFromSessionJson(const QJsonObject& object) {
    return object.value(QStringLiteral("accessToken")).toString().trimmed();
}

bool parseActivationCameraMappings(const QJsonArray& cameras, const QString& roomId, QVector<CameraUiModel>* mappedCameras) {
    if (!mappedCameras)
        return false;
    mappedCameras->clear();
    for (const QJsonValue& value : cameras) {
        const QJsonObject item = value.toObject();
        CameraUiModel camera;
        camera.id = item.value(QStringLiteral("clientCameraId")).toString();
        camera.clientCameraId = camera.id;
        camera.backendCameraId = item.value(QStringLiteral("backendCameraId"))
                                   .toString(item.value(QStringLiteral("cameraId")).toString(item.value(QStringLiteral("id")).toString()))
                                   .trimmed();
        camera.roomId = roomId;
        if (!camera.clientCameraId.isEmpty() || !camera.backendCameraId.isEmpty())
            mappedCameras->append(camera);
    }
    return true;
}

bool parseConnectResponse(const QJsonObject& object, InstallationState* state, QVector<CameraUiModel>* mappedCameras, QString* deviceCredential,
                          QString* errorMessage) {
    if (!state) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Installation state is unavailable.");
        return false;
    }

    InstallationState parsed = *state;
    const QString installationId = object.value(QStringLiteral("installationId")).toString().trimmed();
    if (installationId.isEmpty()) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("GuardBackendModels", "Backend response is missing installation information.");
        return false;
    }
    parsed.installationId = installationId;

    const QJsonObject room = object.value(QStringLiteral("room")).toObject();
    parsed.roomId = room.value(QStringLiteral("id")).toString().trimmed();
    parsed.roomName = room.value(QStringLiteral("name")).toString().trimmed();
    if (parsed.roomId.isEmpty()) {
        if (errorMessage)
            *errorMessage = QCoreApplication::translate("GuardBackendModels", "Backend response is missing room information.");
        return false;
    }

    parsed.userDisconnected = false;
    parsed.lastConnectedAtUtc = parseUtcIso8601(object.value(QStringLiteral("serverTime")));
    if (!parsed.lastConnectedAtUtc.isValid())
        parsed.lastConnectedAtUtc = QDateTime::currentDateTimeUtc();

    if (deviceCredential)
        *deviceCredential = deviceCredentialFromSessionJson(object);

    if (mappedCameras)
        parseActivationCameraMappings(object.value(QStringLiteral("cameras")).toArray(), parsed.roomId, mappedCameras);

    *state = parsed;
    return true;
}

bool parseAvailableRooms(const QJsonObject& object, QVector<AvailableRoom>* rooms, QString* errorMessage) {
    if (!rooms) {
        if (errorMessage)
            *errorMessage = QStringLiteral("Room list is unavailable.");
        return false;
    }
    rooms->clear();
    const QJsonArray values = object.value(QStringLiteral("rooms")).toArray();
    for (const QJsonValue& value : values) {
        const QJsonObject item = value.toObject();
        AvailableRoom room;
        room.id = item.value(QStringLiteral("id")).toString().trimmed();
        room.name = item.value(QStringLiteral("name")).toString().trimmed();
        if (!room.id.isEmpty())
            rooms->append(room);
    }
    return true;
}

int tokenRefreshDelaySeconds(const QJsonObject& object, const QDateTime& nowUtc) {
    const QDateTime reference = nowUtc.isValid() ? nowUtc : QDateTime::currentDateTimeUtc();
    const QDateTime expiresAt = parseUtcIso8601(object.value(QStringLiteral("expiresAt")));
    if (expiresAt.isValid()) {
        const qint64 seconds = reference.secsTo(expiresAt) - 60;
        return seconds > 0 ? static_cast<int>(seconds) : 0;
    }
    const int expiresInSeconds = object.value(QStringLiteral("expiresIn")).toInt(0);
    if (expiresInSeconds <= 0)
        return 0;
    return qMax(30, expiresInSeconds - 60);
}

bool parseNotificationSettingsFromJson(const QJsonObject& root, NotificationSettings* settings) {
    if (!settings)
        return false;
    QJsonObject object = root;
    if (root.contains(QStringLiteral("settings")) && root.value(QStringLiteral("settings")).isObject()) {
        object = root.value(QStringLiteral("settings")).toObject();
    }
    settings->notifyUnknownIncoming = object.value(QStringLiteral("notifyUnknownIncoming")).toBool(true);
    settings->notifyUnapprovedIncoming = object.value(QStringLiteral("notifyUnapprovedIncoming")).toBool(true);
    return true;
}

bool shouldReloadFaceRegistry(const QString& loadedVersion, bool loaded, const QString& remoteVersion) {
    return !loaded || loadedVersion != remoteVersion;
}

}  // namespace backend
}  // namespace guard
