#include "GuardHazardEventHelpers.h"

#include <hazard/HazardTypes.h>

namespace guard {
namespace events {

namespace {

int normalizedHazardType(int hazardType) {
    return hazardType == static_cast<int>(guardvision::HazardType::Smoke) ? static_cast<int>(guardvision::HazardType::Smoke)
                                                                          : static_cast<int>(guardvision::HazardType::Fire);
}

}  // namespace

QString hazardOccurrenceKey(const QString& cameraId, int hazardType) {
    return QStringLiteral("%1:%2").arg(cameraId).arg(normalizedHazardType(hazardType));
}

QString hazardTypeName(int hazardType) {
    return hazardType == static_cast<int>(guardvision::HazardType::Smoke) ? QStringLiteral("smoke") : QStringLiteral("fire");
}

QString hazardSnapshotLabel(int hazardType, double confidence) {
    return QStringLiteral("%1 %2%").arg(hazardTypeName(hazardType).toUpper()).arg(qRound(confidence * 100.0));
}

bool shouldHandleHazardStarted(int eventType) {
    return eventType == static_cast<int>(guardvision::HazardEventType::Started);
}

bool shouldMaintainHazardAlarm(int eventType) {
    const auto type = static_cast<guardvision::HazardEventType>(eventType);
    return type == guardvision::HazardEventType::Started || type == guardvision::HazardEventType::Updated;
}

bool shouldHandleHazardEnded(int eventType) {
    return eventType == static_cast<int>(guardvision::HazardEventType::Ended);
}

bool shouldUploadHazardOnStarted(const QSet<QString>& uploadedKeys, const QString& cameraId, const QVector<GuardHazardDetection>& detections) {
    if (cameraId.trimmed().isEmpty() || detections.isEmpty())
        return false;
    for (const GuardHazardDetection& detection : detections) {
        if (!uploadedKeys.contains(hazardOccurrenceKey(cameraId, detection.hazardType)))
            return true;
    }
    return false;
}

QStringList hazardUploadKeysForOccurrence(const QString& cameraId, const QVector<GuardHazardDetection>& detections) {
    QStringList keys;
    for (const GuardHazardDetection& detection : detections) {
        const QString key = hazardOccurrenceKey(cameraId, detection.hazardType);
        if (!keys.contains(key))
            keys.append(key);
    }
    return keys;
}

QStringList hazardUploadKeysToClearOnEnded(const QString& cameraId, const QVector<GuardHazardDetection>& detections, bool endedAllTypes) {
    if (cameraId.trimmed().isEmpty())
        return QStringList();
    if (endedAllTypes || detections.isEmpty()) {
        return QStringList{hazardOccurrenceKey(cameraId, static_cast<int>(guardvision::HazardType::Fire)),
                           hazardOccurrenceKey(cameraId, static_cast<int>(guardvision::HazardType::Smoke))};
    }
    return hazardUploadKeysForOccurrence(cameraId, detections);
}

bool shouldSoundPcHazardAlarm(bool enabled, int activeHazardCount, bool acknowledged, bool repeatUntilAcknowledged) {
    return enabled && activeHazardCount > 0 && (!repeatUntilAcknowledged || !acknowledged);
}

bool shouldExtendHazardIndicatorPresence(int eventType) {
    const auto type = static_cast<guardvision::HazardEventType>(eventType);
    return type == guardvision::HazardEventType::Started || type == guardvision::HazardEventType::Ended;
}

}  // namespace events
}  // namespace guard
