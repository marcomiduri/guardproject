#pragma once

#include <QString>

struct AppSettings {
    QString backendBaseUrl;
    QString recordingRoot;
    bool pcHazardAlarmEnabled = true;
    int pcHazardAlarmVolume = 80;
    bool repeatHazardAlarmUntilAcknowledged = true;
    bool cameraFileLoggingEnabled = true;
    QString cameraLogDirectory;
};
