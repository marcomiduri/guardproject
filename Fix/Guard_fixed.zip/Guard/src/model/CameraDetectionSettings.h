#ifndef CAMERADETECTIONSETTINGS_H
#define CAMERADETECTIONSETTINGS_H

#include <face/FaceConfig.h>
#include <hazard/HazardConfig.h>
#include <motion/MotionConfig.h>

struct CameraDetectionSettings {
    guardvision::MotionConfig motion;
    guardvision::FaceConfig face;
    guardvision::HazardConfig hazard;
    bool recordVideoForMotion = true;

    CameraDetectionSettings() {
        motion.detectionMode = guardvision::DetectionMode::Software;
        motion.enabled = true;
        motion.analysisIntervalMs = 100;
        motion.activationFrameCount = 1;

        face.detectionMode = guardvision::DetectionMode::Software;
        face.processingLevel = guardvision::FaceProcessingLevel::DetectTrackAndIdentify;
        face.useRoi = false;
        face.roi = guardvision::NormalizedRect{0.0, 0.0, 1.0, 1.0};

        hazard.detectionMode = guardvision::DetectionMode::Software;
        hazard.processingLevel = guardvision::HazardProcessingLevel::Detect;
        hazard.analysisIntervalMs = 100;
        hazard.minimumConfidence = 0.35;
        hazard.minimumRegionWidth = 8;
        hazard.minimumRegionHeight = 8;
        hazard.activationFrameCount = 1;
        hazard.clearFrameCount = 2;
        hazard.updateEventIntervalMs = 250;
    }
};

inline void normalizeEnabledFaceProcessing(guardvision::FaceConfig& face) {
    if (face.detectionMode == guardvision::DetectionMode::Disabled) {
        face.processingLevel = guardvision::FaceProcessingLevel::Disabled;
        return;
    }

    if (face.processingLevel == guardvision::FaceProcessingLevel::Disabled ||
        face.processingLevel == guardvision::FaceProcessingLevel::DetectAndTrack) {
        face.processingLevel = guardvision::FaceProcessingLevel::DetectTrackAndIdentify;
    }
}

#endif  // CAMERADETECTIONSETTINGS_H
