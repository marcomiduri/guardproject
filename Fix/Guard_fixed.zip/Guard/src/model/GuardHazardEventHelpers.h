#pragma once

#include "CameraUiModel.h"
#include "GuardEventModels.h"

#include <QString>
#include <QStringList>
#include <QSet>
#include <QtGlobal>

namespace guard {
namespace events {

QString hazardOccurrenceKey(const QString& cameraId, int hazardType);
QString hazardTypeName(int hazardType);
QString hazardSnapshotLabel(int hazardType, double confidence);
bool shouldHandleHazardStarted(int eventType);
bool shouldMaintainHazardAlarm(int eventType);
bool shouldHandleHazardEnded(int eventType);
bool shouldUploadHazardOnStarted(const QSet<QString>& uploadedKeys, const QString& cameraId, const QVector<GuardHazardDetection>& detections);
QStringList hazardUploadKeysForOccurrence(const QString& cameraId, const QVector<GuardHazardDetection>& detections);
QStringList hazardUploadKeysToClearOnEnded(const QString& cameraId, const QVector<GuardHazardDetection>& detections, bool endedAllTypes);
bool shouldSoundPcHazardAlarm(bool enabled, int activeHazardCount, bool acknowledged, bool repeatUntilAcknowledged);
bool shouldExtendHazardIndicatorPresence(int eventType);

}  // namespace events
}  // namespace guard
