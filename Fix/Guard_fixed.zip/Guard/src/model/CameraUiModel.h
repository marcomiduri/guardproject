#ifndef CAMERAUIMODEL_H
#define CAMERAUIMODEL_H

#include <QCoreApplication>
#include <QJsonObject>
#include <QString>

enum class CameraDirection { Incoming, Outgoing };

inline QString cameraDirectionApiValue(CameraDirection direction) {
    return direction == CameraDirection::Outgoing ? QStringLiteral("out") : QStringLiteral("in");
}

inline CameraDirection cameraDirectionFromApiValue(const QString& value) {
    return value.trimmed().compare(QStringLiteral("out"), Qt::CaseInsensitive) == 0 ? CameraDirection::Outgoing : CameraDirection::Incoming;
}

inline QString cameraDirectionDisplayName(CameraDirection direction) {
    return direction == CameraDirection::Outgoing ? QCoreApplication::translate("CameraUiModel", "Outgoing — leaves the room")
                                                  : QCoreApplication::translate("CameraUiModel", "Incoming — enters the room");
}

inline QString cameraDirectionBadgeLabel(CameraDirection direction) {
    return direction == CameraDirection::Outgoing ? QCoreApplication::translate("CameraUiModel", "OUT")
                                                  : QCoreApplication::translate("CameraUiModel", "IN");
}

inline bool cameraDirectionConfiguredFromStoredJson(const QJsonObject& object) {
    return object.contains(QStringLiteral("direction"));
}

struct CameraUiModel {
    // Local stable id. This is also used as the GuardVision stream id source.
    QString id;
    QString clientCameraId;
    QString backendCameraId;
    QString roomId;

    QString name;
    QString type;
    CameraDirection direction = CameraDirection::Incoming;
    bool directionConfigured = true;
    QString address;
    int sdkPort = 8000;
    int rtspPort = 554;
    QString username = QStringLiteral("admin");
    QString password;
    int channel = 1;
    QString stream;
    QString rtspUrl;
    int sortOrder = 0;

    QString displayName() const {
        return name.trimmed().isEmpty() ? QStringLiteral("Camera") : name.trimmed();
    }

    QString effectiveClientCameraId() const {
        return clientCameraId.trimmed().isEmpty() ? id : clientCameraId;
    }

    QString eventCameraId() const {
        if (!backendCameraId.trimmed().isEmpty())
            return backendCameraId;
        if (requiresBackendCameraId())
            return QString();
        return effectiveClientCameraId();
    }

    QString localFaceTrackCameraKey() const {
        if (!backendCameraId.trimmed().isEmpty())
            return backendCameraId;
        return effectiveClientCameraId();
    }

    bool requiresBackendCameraId() const {
        return !roomId.trimmed().isEmpty();
    }
};

inline QString cameraCardTitleText(const CameraUiModel& camera) {
    if (!camera.directionConfigured)
        return camera.displayName();
    return QStringLiteral("%1 [%2]").arg(camera.displayName(), cameraDirectionBadgeLabel(camera.direction));
}

inline bool cameraTypeUsesHcNetSdk(const QString& type) {
    return type.contains(QStringLiteral("Hikvision"), Qt::CaseInsensitive);
}

inline bool cameraStreamUsesSubStream(const QString& stream) {
    return stream.contains(QStringLiteral("Sub"), Qt::CaseInsensitive);
}

inline bool cameraConnectionFieldsEqual(const CameraUiModel& left, const CameraUiModel& right) {
    // Backend round-trips normalize labels such as "generic_rtsp" to
    // "Generic (RTSP)" and may trim text fields. Compare the effective source
    // configuration rather than presentation strings so a room connection does
    // not tear down and restart an already-running camera unnecessarily.
    return cameraTypeUsesHcNetSdk(left.type) == cameraTypeUsesHcNetSdk(right.type) &&
           left.address.trimmed().compare(right.address.trimmed(), Qt::CaseInsensitive) == 0 && left.sdkPort == right.sdkPort &&
           left.rtspPort == right.rtspPort && left.username.trimmed() == right.username.trimmed() && left.password == right.password &&
           left.channel == right.channel && cameraStreamUsesSubStream(left.stream) == cameraStreamUsesSubStream(right.stream) &&
           left.rtspUrl.trimmed() == right.rtspUrl.trimmed();
}

#endif  // CAMERAUIMODEL_H
