#ifndef CAMERATESTSOURCESETTINGS_H
#define CAMERATESTSOURCESETTINGS_H

#include <QString>

enum class CameraTestSourceType { ConfiguredCamera = 0, ImageFile = 1, VideoFile = 2 };

struct CameraTestSourceSettings {
    CameraTestSourceType type = CameraTestSourceType::ConfiguredCamera;
    QString filePath;

    bool usesFile() const {
        return type == CameraTestSourceType::ImageFile || type == CameraTestSourceType::VideoFile;
    }
};

inline bool operator==(const CameraTestSourceSettings& left, const CameraTestSourceSettings& right) {
    return left.type == right.type && left.filePath == right.filePath;
}

inline bool operator!=(const CameraTestSourceSettings& left, const CameraTestSourceSettings& right) {
    return !(left == right);
}

#endif  // CAMERATESTSOURCESETTINGS_H
