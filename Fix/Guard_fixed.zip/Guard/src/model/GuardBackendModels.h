#pragma once

#include "CameraUiModel.h"

#include <QDateTime>
#include <QJsonArray>
#include <QJsonObject>
#include <QString>
#include <QVector>

namespace guard {
namespace backend {

struct InstallationState {
    QString installationId;
    QString roomId;
    QString roomName;
    QString deviceName;
    QDateTime lastConnectedAtUtc;
    bool userDisconnected = false;

    bool hasInstallationIdentity() const {
        return !installationId.trimmed().isEmpty();
    }

    bool isRegistered() const {
        return hasInstallationIdentity() && !roomId.trimmed().isEmpty() && !userDisconnected;
    }
};

struct NotificationSettings {
    bool notifyUnapprovedIncoming = true;
    bool notifyUnknownIncoming = true;
};

struct AvailableRoom {
    QString id;
    QString name;
};

struct RoomConnectionRequest {
    QString roomId;
    QString hardwareId;
    QString installationId;
    QString deviceCredential;
    QString deviceName;
    QString applicationVersion;
    QVector<CameraUiModel> cameras;
};

struct RoomActivationRequest {
    QString roomIdentifier;
    QString activationCode;
    QString deviceName;
    QString hardwareId;
    QString applicationVersion;
    QVector<CameraUiModel> cameras;
};

QJsonObject cameraToApiJson(const CameraUiModel& camera, const QString& roomId);
QJsonObject roomConnectionRequestToApiJson(const RoomConnectionRequest& request);
QString backendCameraIdFromApiJson(const QJsonObject& object);
bool cameraFromApiJson(const QJsonObject& object, CameraUiModel* camera, QString* errorMessage = nullptr);

QDateTime parseUtcIso8601(const QJsonValue& value);
QString deviceCredentialFromSessionJson(const QJsonObject& object);
QString accessTokenFromSessionJson(const QJsonObject& object);
bool parseActivationCameraMappings(const QJsonArray& cameras, const QString& roomId, QVector<CameraUiModel>* mappedCameras);
bool parseConnectResponse(const QJsonObject& object, InstallationState* state, QVector<CameraUiModel>* mappedCameras, QString* deviceCredential,
                          QString* errorMessage = nullptr);
bool parseAvailableRooms(const QJsonObject& object, QVector<AvailableRoom>* rooms, QString* errorMessage = nullptr);
int tokenRefreshDelaySeconds(const QJsonObject& object, const QDateTime& nowUtc = QDateTime());
bool parseNotificationSettingsFromJson(const QJsonObject& root, NotificationSettings* settings);
bool shouldReloadFaceRegistry(const QString& loadedVersion, bool loaded, const QString& remoteVersion);

}  // namespace backend
}  // namespace guard