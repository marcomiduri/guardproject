#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "CameraUiModel.h"
#include "FaceRegistryLoader.h"
#include "model/GuardBackendModels.h"

#include <QHash>
#include <QCloseEvent>
#include <QEvent>
#include <QMainWindow>
#include <QPointer>
#include <QVector>

#include <functional>
#include <memory>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

namespace guardvision {
class GuardVision;
}
namespace guard {
namespace recording {
class RecordingStorageManager;
}
namespace backend {
class GuardBackendClient;
class GuardSessionManager;
class GuardRealtimeClient;
}  // namespace backend
namespace alerts {
class LocalAlertService;
class CameraAlarmService;
}  // namespace alerts
namespace events {
class GuardEventCoordinator;
}
}  // namespace guard

class CameraGridWidget;
class CameraRuntimeController;
class CameraWidget;
class GuardVisionEventListenerAdapter;
class HazardAlarmIndicator;
class GuardSplash;
class QAction;
class QDialog;
class QMenu;
class QSystemTrayIcon;
class QTimer;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr, bool testMode = false, GuardSplash* splash = nullptr);
    ~MainWindow() override;

    void runColdStartBootstrap(GuardSplash* splash, const std::function<void(bool)>& completion);

public slots:
    void bringToForeground();

protected:
    void closeEvent(QCloseEvent* event) override;
    void changeEvent(QEvent* event) override;

private:
    void setupUiChrome();
    void setupHeaderLayout();
    void connectUiSignals();
    void initializeGuardVision();
    void shutdownGuardVision();
    void detachNativeRuntimeForProcessExit();
    void performApplicationShutdown();
    void initializeBackendIntegration();
    void startBackendOperationalSession();
    void syncEventCoordinatorRoomAssignment();
    bool hasAuthenticatedBackendSession() const;
    bool hasActiveGuardVisionStream() const;
    void restorePersistedCameras();
    void persistCameras();

    void loadFaceRegistryFromBackend();
    void refreshFaceRegistryVersion();
    bool applyFaceRegistry(const guard::api::FaceRegistryData& registry, const guard::api::FaceRegistryVersionInfo& versionInfo);
    bool tryApplyPendingFaceRegistry();
    void clearPendingFaceRegistry();
    void markFaceIdentificationUnavailable(const QString& reason);
    void suspendFaceIdentificationForAllCameras();
    bool reactivateCachedFaceRegistryForCurrentRoom();
    void refreshNotificationSettings();
    void syncCamerasFromBackend(const std::function<void(bool)>& completion = std::function<void(bool)>(),
                                const std::shared_ptr<bool>& cancelled = std::shared_ptr<bool>());
    void bootstrapCheckBackend(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion);
    void bootstrapRestoreSession(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion);
    void bootstrapFaceRegistry(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion);
    void bootstrapSyncCameras(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion);
    void sendAllCameraHeartbeats();
    void sendInstallationHeartbeat();
    void sendCameraHeartbeat(const QString& cameraId, int stateValue);
    void refreshBackendOperationalData();

    void addOrRegisterCamera(const CameraUiModel& camera);
    void addCameraTile(const CameraUiModel& camera, bool animatedLayout = true);
    void removeCameraTile(const QString& cameraId);
    void removeCameraTileLocally(const QString& cameraId, bool animatedLayout = true);
    bool removeAllCameraTilesLocally(QString* errorMessage = nullptr);
    bool ensureCameraWorkspaceRoom(const QString& roomId, QString* errorMessage = nullptr);
    void editCamera(const QString& cameraId);
    void applyCameraEdit(const QString& cameraId, const CameraUiModel& updated);
    void openCameraSettings(const QString& cameraId);
    void openAppSettingsDialog();
    void checkLicenseState();
    bool promptForPermanentLicenseIfRequired();
    void showCameraLogs(const QString& cameraId);
    void connectCamera(const QString& cameraId);
    void disconnectCamera(const QString& cameraId);
    void startCameraNow(const QString& cameraId);
    void showRoomLoginDialog();
    void updateRoomUi();
    void applyActivationCameraMappings(const QVector<CameraUiModel>& mappings);
    void clearBackendCameraMappings();

    void retranslateDynamicUi();
    void updateFooterStatus(const QString& text, const QString& color);
    void setupSystemTray();
    void ensureSystemTray();
    void showTrayIcon(bool showHint = true);
    void minimizeToTray();
    void hideToTrayFromClose();
    void showFromTray();
    void quitApplication();
    CameraUiModel* findCamera(const QString& cameraId);
    const CameraUiModel* findCamera(const QString& cameraId) const;
    QString cameraCardTitle(const CameraUiModel& camera) const;
    QString nextDefaultCameraName() const;
    bool hasCameraIpConflict(const CameraUiModel& candidate, const QString& excludedCameraId, QString* conflictingCameraName = nullptr) const;
    void updateCameraTilePresentation(CameraWidget* tile, const CameraUiModel& camera);

    struct ReusableGuardVisionStreamSlot {
        QString streamId;
        bool nativeFaceIdentificationPrepared = false;
        quint64 nextSubmissionSequence = 0;
        qint64 nextSubmissionTimestampMs = 0;
    };

    Ui::MainWindow* ui;
    CameraGridWidget* m_cameraGrid = nullptr;
    QVector<CameraUiModel> m_cameras;
    QHash<QString, CameraRuntimeController*> m_controllersByCameraId;
    QHash<QString, QPointer<QDialog>> m_logDialogsByCameraId;
    QVector<ReusableGuardVisionStreamSlot> m_reusableGuardVisionStreamSlots;
    QString m_cameraWorkspaceRoomId;

    std::unique_ptr<guardvision::GuardVision> m_guardVision;
    GuardVisionEventListenerAdapter* m_eventAdapter = nullptr;
    guard::recording::RecordingStorageManager* m_recordingStorageManager = nullptr;

    guard::backend::GuardBackendClient* m_backendClient = nullptr;
    guard::backend::GuardSessionManager* m_sessionManager = nullptr;
    guard::backend::GuardRealtimeClient* m_realtimeClient = nullptr;
    guard::alerts::LocalAlertService* m_localAlerts = nullptr;
    guard::alerts::CameraAlarmService* m_cameraAlarms = nullptr;
    guard::events::GuardEventCoordinator* m_eventCoordinator = nullptr;
    QTimer* m_heartbeatTimer = nullptr;
    QTimer* m_faceRegistryTimer = nullptr;
    QTimer* m_notificationSettingsTimer = nullptr;
    QTimer* m_licenseCheckTimer = nullptr;
    HazardAlarmIndicator* m_hazardAlarmIndicator = nullptr;
    QSystemTrayIcon* m_trayIcon = nullptr;
    QMenu* m_trayMenu = nullptr;
    QAction* m_trayShowAction = nullptr;
    QAction* m_trayExitAction = nullptr;
    bool m_restoreFullScreen = false;
    bool m_restoreMaximized = false;
    bool m_hidingToTray = false;
    bool m_quitting = false;
    bool m_shutdownInProgress = false;
    bool m_shutdownComplete = false;
    bool m_trayHintShown = false;

    enum class FaceRegistryState { NotLoaded, Downloading, PendingIdentifyEngine, Applying, Ready, TemporarilyUnavailable, Rejected };

    guard::api::FaceRegistryData m_faceRegistry;
    guard::api::FaceRegistryVersionInfo m_faceRegistryVersion;
    guard::api::FaceRegistryData m_pendingFaceRegistry;
    guard::api::FaceRegistryVersionInfo m_pendingFaceRegistryInfo;
    guard::backend::NotificationSettings m_notificationSettings;
    bool m_guardVisionReady = false;
    FaceRegistryState m_faceRegistryState = FaceRegistryState::NotLoaded;
    bool m_faceRegistryLoaded = false;
    bool m_hasPendingFaceRegistry = false;
    bool m_faceIdentificationPermanentlyUnavailable = false;
    QString m_faceIdentificationUnavailableReason;
    QString m_pendingFaceRegistryRoomId;
    bool m_faceRegistryRequestInFlight = false;
    bool m_faceRegistryVersionRequestInFlight = false;
    quint64 m_faceRegistryRequestSerial = 0;
    quint64 m_faceRegistryVersionRequestSerial = 0;
    QString m_pendingFaceRegistryVersion;
    QString m_requestedFaceRegistryVersion;
    QString m_faceRegistryRoomId;
    bool m_bootstrapInProgress = false;
    bool m_licensePromptActive = false;
    bool m_testMode = false;
};

#endif  // MAINWINDOW_H
