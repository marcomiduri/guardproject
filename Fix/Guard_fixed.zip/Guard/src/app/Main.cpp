#include "MainWindow.h"
#include "GuardIcon.h"
#include "GuardSplash.h"
#include "guardlocale.h"
#include "runtime/app/ApplicationSingleInstance.h"
#include "runtime/app/VideoSmokeTest.h"
#include "media/recording/RecordingStorageManager.h"
#include <QApplication>
#include <QDebug>
#include <QSettings>

namespace {

void clearLegacyLicenseState() {
    // Keep the current protected Guard license credential.
    // Previous builds accidentally removed it on every launch, which made
    // Guard accept a key during one session and ask for it again after restart.
    // Only remove obsolete plaintext legacy keys.
    QSettings currentSettings;
    currentSettings.remove(QStringLiteral("license/key"));
    currentSettings.sync();

    QSettings legacySettings(QStringLiteral("Guard"), QStringLiteral("ApexImage"));
    legacySettings.remove(QStringLiteral("license/key"));
    legacySettings.sync();
}

}  // namespace

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("Guard"));
    QApplication::setApplicationVersion(QStringLiteral("2.0.0"));
    QApplication::setOrganizationName(QStringLiteral("Apex Image"));
    QApplication::setWindowIcon(GuardIcon::applicationIcon());
    clearLegacyLicenseState();
    guard::recording::RecordingStorageManager::instance()->startMaintenance();

    QApplication::setQuitOnLastWindowClosed(false);

    GuardLocale::install(&app);

    const bool testMode = app.arguments().contains(QStringLiteral("--test"));
    const int smokeIndex = app.arguments().indexOf(QStringLiteral("--video-smoke"));
    if (smokeIndex >= 0) {
        if (smokeIndex + 1 >= app.arguments().size()) {
            qCritical("Guard video smoke test requires a file path after --video-smoke.");
            return 2;
        }
        return guard::runtime::runVideoSmokeTest(app.arguments().at(smokeIndex + 1));
    }

    guard::runtime::ApplicationSingleInstance singleInstance;
    if (!singleInstance.tryBecomePrimary())
        return 0;

    GuardSplash splash;
    splash.showWithFadeIn();
    splash.setStatusMessage(QCoreApplication::translate("MainWindow", "Starting..."));

    MainWindow window(nullptr, testMode, &splash);
    QObject::connect(&singleInstance, &guard::runtime::ApplicationSingleInstance::activationRequested, &window, &MainWindow::bringToForeground,
                     Qt::QueuedConnection);

    window.runColdStartBootstrap(&splash, [&splash, &window, testMode](bool) { splash.finishSplash(&window, testMode); });

    return app.exec();
}
