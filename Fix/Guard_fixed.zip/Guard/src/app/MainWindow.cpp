#include "MainWindow.h"
#include "ui_MainWindow.h"

#include "AppSettingsDialog.h"
#include "CameraDialog.h"
#include "CameraGridWidget.h"
#include "CameraRuntimeController.h"
#include "CameraSettingsDialog.h"
#include "CameraView.h"
#include "CameraWidget.h"
#include "GuardIcon.h"
#include "GuardMessageDialog.h"
#include "GuardTheme.h"
#include "GuardLicenseManager.h"
#include "LicenseActivationDialog.h"
#include "GuardVisionEventListenerAdapter.h"
#include "HazardAlarmIndicator.h"
#include "RoomConnectionDialog.h"
#include "WindowTitleBar.h"
#include "GuardSplash.h"
#include "media/recording/RecordingStorageManager.h"
#include "model/GuardBackendModels.h"
#include "services/alerts/CameraAlarmService.h"
#include "services/alerts/LocalAlertService.h"
#include "services/api/FaceRegistryLoader.h"
#include "services/backend/CameraStore.h"
#include "services/backend/GuardBackendClient.h"
#include "services/backend/GuardSessionManager.h"
#include "services/backend/GuardRealtimeClient.h"
#include "services/events/GuardEventCoordinator.h"
#include "runtime/app/RuntimeResourcePaths.h"

#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <core/StreamStatus.h>
#include <face/FaceRegistry.h>

#include <QAction>
#include <QApplication>
#include <QCloseEvent>
#include <QCoreApplication>
#include <QDateTime>
#include <QDebug>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDesktopServices>
#include <QDir>
#include <QEvent>
#include <QFileInfo>
#include <QFrame>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QHostAddress>
#include <QLabel>
#include <QList>
#include <QMenu>
#include <QPointer>
#include <QPushButton>
#include <QSet>
#include <QSize>
#include <QSystemTrayIcon>
#include <QTextEdit>
#include <QUrl>
#include <QThread>
#include <QTimer>
#include <QVBoxLayout>

#include <algorithm>
#include <cstdint>
#include <utility>

namespace {

constexpr int kSessionRestoreTimeoutMs = 12000;
constexpr int kBackendHealthTimeoutMs = 8000;
constexpr int kFaceRegistryTimeoutMs = 12000;
constexpr int kCameraSyncTimeoutMs = 10000;

std::function<void(bool)> timedCompletion(QObject* context, int timeoutMs, const std::function<void(bool)>& completion,
                                          std::shared_ptr<bool>* finishedState = nullptr) {
    const std::shared_ptr<bool> finished = std::make_shared<bool>(false);
    if (finishedState)
        *finishedState = finished;
    QTimer* timer = new QTimer(context);
    timer->setSingleShot(true);
    const QPointer<QTimer> timerGuard(timer);

    const std::function<void(bool)> finish = [finished, timerGuard, completion](bool ok) {
        if (*finished)
            return;
        *finished = true;
        if (timerGuard) {
            timerGuard->stop();
            timerGuard->deleteLater();
        }
        if (completion)
            completion(ok);
    };

    QObject::connect(timer, &QTimer::timeout, context, [finish]() { finish(false); });
    timer->start(qMax(1, timeoutMs));
    return finish;
}

void setSplashStatus(GuardSplash* splash, const QString& message) {
    if (splash) {
        splash->setStatusMessage(message);
    }
}

QString cameraStatusApiValue(CameraRuntimeController::State state) {
    switch (state) {
        case CameraRuntimeController::State::Connected:
            return QStringLiteral("online");
        case CameraRuntimeController::State::Disconnected:
        case CameraRuntimeController::State::Error:
            return QStringLiteral("offline");
        case CameraRuntimeController::State::Connecting:
        case CameraRuntimeController::State::Reconnecting:
        default:
            return QStringLiteral("unknown");
    }
}

bool sameCameraModel(const CameraUiModel& left, const CameraUiModel& right) {
    return left.id == right.id && left.clientCameraId == right.clientCameraId && left.backendCameraId == right.backendCameraId &&
           left.roomId == right.roomId && left.name == right.name && left.type == right.type && left.direction == right.direction &&
           left.directionConfigured == right.directionConfigured && left.address == right.address && left.sdkPort == right.sdkPort &&
           left.rtspPort == right.rtspPort && left.username == right.username && left.password == right.password && left.channel == right.channel &&
           left.stream == right.stream && left.rtspUrl == right.rtspUrl && left.sortOrder == right.sortOrder;
}

QString normalizedCameraIp(const CameraUiModel& camera) {
    QString host = camera.address.trimmed();
    if (host.isEmpty() && !camera.rtspUrl.trimmed().isEmpty()) {
        const QUrl url(camera.rtspUrl.trimmed());
        host = url.host().trimmed();
    }
    if (host.startsWith(QLatin1Char('[')) && host.endsWith(QLatin1Char(']')))
        host = host.mid(1, host.size() - 2);
    QHostAddress address;
    if (address.setAddress(host))
        return address.toString().toLower();
    return host.toLower();
}

CameraUiModel* findCameraForBackendRecord(QVector<CameraUiModel>& cameras, const QJsonObject& object, const QString& backendId) {
    if (!backendId.isEmpty()) {
        for (CameraUiModel& camera : cameras) {
            if (camera.backendCameraId == backendId)
                return &camera;
        }
    }
    const QString clientCameraId = object.value(QStringLiteral("clientCameraId")).toString().trimmed();
    if (!clientCameraId.isEmpty()) {
        for (CameraUiModel& camera : cameras) {
            if (camera.effectiveClientCameraId() == clientCameraId || camera.clientCameraId == clientCameraId) {
                return &camera;
            }
        }
    }
    if (!backendId.isEmpty()) {
        for (CameraUiModel& camera : cameras) {
            if (camera.id == backendId)
                return &camera;
        }
    }
    return nullptr;
}

bool cameraWasStreaming(const CameraRuntimeController* controller) {
    if (!controller)
        return false;
    switch (controller->state()) {
        case CameraRuntimeController::State::Connected:
        case CameraRuntimeController::State::Connecting:
        case CameraRuntimeController::State::Reconnecting:
            return true;
        case CameraRuntimeController::State::Disconnected:
        case CameraRuntimeController::State::Error:
        default:
            return false;
    }
}

QHash<quint64, QString> faceDisplayNamesById(const guard::api::FaceRegistryData& registry) {
    QHash<quint64, QString> result;
    for (const guard::api::FaceRegistryFace& face : registry.faces) {
        const QString name = face.name.trimmed();
        if (face.id > 0 && !name.isEmpty())
            result.insert(static_cast<quint64>(face.id), name);
    }
    return result;
}

bool hasUsableFaceRegistryEntries(const guard::api::FaceRegistryData& registry) {
    for (const guard::api::FaceRegistryFace& face : registry.faces) {
        if (face.id > 0 && !face.name.trimmed().isEmpty() && !face.feature.empty())
            return true;
    }
    return false;
}

}  // namespace

MainWindow::MainWindow(QWidget* parent, bool testMode, GuardSplash* splash)
: QMainWindow(parent),
  ui(new Ui::MainWindow),
  m_recordingStorageManager(guard::recording::RecordingStorageManager::instance()),
  m_testMode(testMode) {
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setSplashStatus(splash, tr("Loading interface..."));
    ui->setupUi(this);

    setupUiChrome();
    setupSystemTray();
    setSplashStatus(splash, tr("Initializing GuardVision..."));
    initializeGuardVision();
    initializeBackendIntegration();
    connectUiSignals();
    restorePersistedCameras();
    updateRoomUi();

    // Register the tray icon from the first event-loop turn. Do not show the
    // "running in the background" balloon at ordinary application startup.
    showTrayIcon(false);

    m_licenseCheckTimer = new QTimer(this);
    m_licenseCheckTimer->setInterval(60 * 1000);
    connect(m_licenseCheckTimer, &QTimer::timeout, this, &MainWindow::checkLicenseState);
    m_licenseCheckTimer->start();
    // Do not block the boot/splash path with license UI. The first enforcement
    // check runs after the main event loop is already alive, and the repeating
    // timer keeps long-running tray sessions covered after temporary expiry.
    QTimer::singleShot(7000, this, &MainWindow::checkLicenseState);

    const QString readyText = m_testMode ? tr("GuardVision ready - test mode") : tr("GuardVision ready");
    const QString unavailableText = m_testMode ? tr("GuardVision unavailable - test mode") : tr("GuardVision unavailable");
    updateFooterStatus(m_guardVisionReady ? readyText : unavailableText, m_guardVisionReady ? QStringLiteral("#3DA35D") : QStringLiteral("#fb7185"));
}

MainWindow::~MainWindow() {
    performApplicationShutdown();
    delete ui;
}

void MainWindow::setupUiChrome() {
    setWindowTitle(m_testMode ? QStringLiteral("Guard - Test Mode") : QStringLiteral("Guard"));
    setWindowIcon(GuardIcon::applicationIcon());
    setStyleSheet(GuardTheme::applicationStyleSheet());

    ui->centralWidget->setObjectName(QStringLiteral("centralWidget"));
    ui->headerWidget->setAttribute(Qt::WA_StyledBackground, true);
    ui->footerWidget->setAttribute(Qt::WA_StyledBackground, true);
    ui->cameraGridPlaceholder->setFrameShape(QFrame::NoFrame);

    ui->titleBar->setTitle(windowTitle());
    connect(ui->titleBar, &WindowTitleBar::minimizeRequested, this, &MainWindow::minimizeToTray);
    connect(ui->titleBar, &WindowTitleBar::closeRequested, this, [this]() { close(); });

    ui->footerSettingsButton->setText(QString());
    ui->footerSettingsButton->setFixedSize(28, 28);
    ui->footerSettingsButton->setIcon(GuardIcon::themedSvgIcon(":/icons/settings.svg", 12, GuardTheme::colorFromHex(GuardTheme::kTextPrimary)));
    ui->footerSettingsButton->setIconSize(QSize(12, 12));

    setupHeaderLayout();

    m_cameraGrid = new CameraGridWidget(ui->cameraGridPlaceholder);
    m_cameraGrid->setObjectName(QStringLiteral("cameraGridWidget"));
    ui->cameraGridPlaceholderLayout->addWidget(m_cameraGrid);
}

void MainWindow::setupHeaderLayout() {
    QHBoxLayout* headerLayout = ui->headerLayout;

    for (int i = headerLayout->count() - 1; i >= 0; --i) {
        QLayoutItem* item = headerLayout->itemAt(i);
        if (item && item->spacerItem() && item->spacerItem() == ui->headerHorizontalSpacer) {
            delete headerLayout->takeAt(i);
            break;
        }
    }

    headerLayout->removeWidget(ui->loginToRoomButton);
    headerLayout->removeWidget(ui->addCameraButton);

    QWidget* leftHeaderHost = new QWidget(ui->headerWidget);
    leftHeaderHost->setObjectName(QStringLiteral("headerLeftHost"));
    leftHeaderHost->setAttribute(Qt::WA_StyledBackground, true);
    leftHeaderHost->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    QHBoxLayout* leftHeaderLayout = new QHBoxLayout(leftHeaderHost);
    leftHeaderLayout->setContentsMargins(0, 0, 0, 0);
    leftHeaderLayout->setSpacing(headerLayout->spacing());
    leftHeaderLayout->addStretch(1);

    QWidget* rightHeaderHost = new QWidget(ui->headerWidget);
    rightHeaderHost->setObjectName(QStringLiteral("headerRightHost"));
    rightHeaderHost->setAttribute(Qt::WA_StyledBackground, true);
    rightHeaderHost->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    QHBoxLayout* rightHeaderLayout = new QHBoxLayout(rightHeaderHost);
    rightHeaderLayout->setContentsMargins(0, 0, 0, 0);
    rightHeaderLayout->setSpacing(headerLayout->spacing());
    rightHeaderLayout->addStretch(1);
    rightHeaderLayout->addWidget(ui->loginToRoomButton, 0, Qt::AlignVCenter);
    rightHeaderLayout->addWidget(ui->addCameraButton, 0, Qt::AlignVCenter);

    m_hazardAlarmIndicator = new HazardAlarmIndicator(ui->headerWidget);

    headerLayout->addWidget(leftHeaderHost, 1);
    headerLayout->addWidget(m_hazardAlarmIndicator, 0, Qt::AlignHCenter | Qt::AlignVCenter);
    headerLayout->addWidget(rightHeaderHost, 1);
}

void MainWindow::initializeGuardVision() {
    m_eventAdapter = new GuardVisionEventListenerAdapter(this);
    m_guardVision.reset(new guardvision::GuardVision());

    guardvision::GuardVisionConfig config;
    // The UI still limits the active camera count to four. The native
    // GuardVision stream registrations, however, are now treated as
    // process-lifetime slots and are not recycled across different camera IDs
    // during room switches because recycled slots can emit stale hazard/face
    // state and corrupt the vendor/debug heap. Keep headroom for several room
    // changes in one long-running tray session.
    config.maxStreams = 64;
    config.frameWorkerCount = 2;
    config.faceWorkerCount = 1;
    config.hazardWorkerCount = 1;

    const QString identifyPath = guard::runtime::resolveIdentifyResourcePath();
    const QString hazardPath = guard::runtime::resolveHazardModelPath();
    if (!identifyPath.isEmpty())
        config.identifyResourcePath = identifyPath.toStdString();
    if (!hazardPath.isEmpty())
        config.hazardResourcePath = hazardPath.toStdString();

    const guardvision::Result result = m_guardVision->initialize(config);
    if (!result.ok) {
        m_guardVisionReady = false;
        GuardMessageDialog::warning(this, tr("Guard"), tr("GuardVision initialization failed: %1").arg(QString::fromStdString(result.error.message)));
        return;
    }

    m_guardVision->setEventListener(m_eventAdapter);
    m_guardVisionReady = true;
}

void MainWindow::shutdownGuardVision() {
    if (!m_guardVision)
        return;
    m_guardVision->setEventListener(nullptr);
    m_guardVision->shutdown();
    m_guardVision.reset();
    m_guardVisionReady = false;
}

void MainWindow::detachNativeRuntimeForProcessExit() {
    // GuardVision process-exit shutdown is terminal: it blocks new submissions,
    // detaches callbacks, joins every GuardVision worker/dispatcher thread, and
    // deliberately skips the unstable vendor session/engine release calls.
    // Unlike the previous workaround, this does not leak live GuardVision
    // threads into Windows DLL/process teardown.
    if (m_eventAdapter) {
        m_eventAdapter->disable();
        QObject::disconnect(m_eventAdapter, nullptr, nullptr, nullptr);
    }

    if (m_guardVision) {
        m_guardVision->shutdown(guardvision::ShutdownMode::ProcessExit);

        // Do not destroy the GuardVision C++ wrapper on final process exit.
        // The guarded ProcessExit shutdown has already stopped worker threads
        // and detached callbacks. Deleting the wrapper can still re-enter
        // vendor/destructor cleanup for retained native stream/session memory,
        // which is exactly where the MSVC debug CRT reports heap corruption.
        // Releasing the unique_ptr intentionally leaves this terminal native
        // runtime process-owned until Windows tears the process down.
        (void)m_guardVision.release();
    }

    m_guardVisionReady = false;
}

void MainWindow::performApplicationShutdown() {
    if (m_shutdownComplete || m_shutdownInProgress) {
        return;
    }
    m_shutdownInProgress = true;

    // Prevent timers, WebSocket callbacks, registry replies, and event uploads
    // from starting new work while media and analytics are shutting down.
    ++m_faceRegistryRequestSerial;
    ++m_faceRegistryVersionRequestSerial;
    m_faceRegistryRequestInFlight = false;
    m_faceRegistryVersionRequestInFlight = false;
    if (m_heartbeatTimer)
        m_heartbeatTimer->stop();
    if (m_faceRegistryTimer)
        m_faceRegistryTimer->stop();
    if (m_notificationSettingsTimer)
        m_notificationSettingsTimer->stop();
    if (m_realtimeClient)
        m_realtimeClient->stop();
    if (m_eventCoordinator)
        m_eventCoordinator->beginApplicationShutdown();
    if (m_recordingStorageManager)
        m_recordingStorageManager->stopMaintenance();
    if (m_trayIcon)
        m_trayIcon->hide();
    if (m_eventAdapter)
        m_eventAdapter->disable();

    // Phase 1: synchronously stop and join every Guard-owned producer and
    // recorder while the UI, OpenCV, FFmpeg, and GuardVision objects are alive.
    const QList<CameraRuntimeController*> controllers = m_controllersByCameraId.values();
    for (CameraRuntimeController* controller : controllers) {
        if (controller)
            controller->prepareForApplicationShutdown();
    }

    if (m_eventCoordinator)
        QCoreApplication::removePostedEvents(m_eventCoordinator, QEvent::MetaCall);

    // Phase 2: stop and join GuardVision's routing, motion, face, hazard,
    // onboard, and event-dispatch threads. ProcessExit intentionally avoids
    // HFReleaseIdentifySession/HFTerminateIdentify/HazardDetect_Shutdown, the
    // vendor teardown calls implicated by the active-stream Exit crash.
    detachNativeRuntimeForProcessExit();

    // With both Guard and GuardVision workers joined, controllers can now be
    // destroyed normally instead of being leaked into Qt/Windows teardown.
    m_controllersByCameraId.clear();
    for (CameraRuntimeController* controller : controllers) {
        if (!controller)
            continue;
        QObject::disconnect(controller, nullptr, nullptr, nullptr);
        QCoreApplication::removePostedEvents(controller, QEvent::MetaCall);
        delete controller;
    }

    m_shutdownComplete = true;
    m_shutdownInProgress = false;
}

void MainWindow::initializeBackendIntegration() {
    m_backendClient = new guard::backend::GuardBackendClient(this);
    m_sessionManager = new guard::backend::GuardSessionManager(m_backendClient, this);
    m_realtimeClient = new guard::backend::GuardRealtimeClient(m_backendClient, this);
    m_localAlerts = new guard::alerts::LocalAlertService(this);
    m_cameraAlarms = new guard::alerts::CameraAlarmService(this);
    m_eventCoordinator = new guard::events::GuardEventCoordinator(m_backendClient, m_localAlerts, m_cameraAlarms, this);
    m_eventCoordinator->setEventUploadEnabled(true);
    syncEventCoordinatorRoomAssignment();

    connect(m_sessionManager, &guard::backend::GuardSessionManager::accessTokenAvailable, this, [this]() { syncEventCoordinatorRoomAssignment(); });
    connect(m_sessionManager, &guard::backend::GuardSessionManager::authenticated, this, [this]() {
        syncEventCoordinatorRoomAssignment();
        updateFooterStatus(tr("Backend session authenticated"), QStringLiteral("#3DA35D"));
        if (!m_bootstrapInProgress)
            startBackendOperationalSession();
    });
    connect(m_sessionManager, &guard::backend::GuardSessionManager::sessionChanged, this, [this](const guard::backend::InstallationState& state) {
        const QString roomId = state.roomId.trimmed();
        // Room identity, not only connected/disconnected state,
        // defines event ownership. A direct A -> B switch keeps the
        // assigned flag true, so explicitly change the active room
        // to clear A's alarm state and reject its queued callbacks.
        syncEventCoordinatorRoomAssignment();

        // Invalidate outstanding callbacks whenever the room assignment
        // changes. A response for the old room must never replace the
        // registry used by a newly selected room.
        ++m_faceRegistryRequestSerial;
        ++m_faceRegistryVersionRequestSerial;
        m_faceRegistryRequestInFlight = false;
        m_faceRegistryVersionRequestInFlight = false;

        if (!state.isRegistered()) {
            // A normal room disconnect is only a logical authorization
            // boundary. Keep the already-enrolled native registry alive
            // and mask identity results in Guard. Replacing or clearing
            // the vendor registry while active cameras are processing is
            // the reconnect crash path.
            m_pendingFaceRegistryVersion.clear();
            m_requestedFaceRegistryVersion.clear();
            clearPendingFaceRegistry();
            if (m_eventCoordinator)
                m_eventCoordinator->setFaceRegistryLoaded(false);
            suspendFaceIdentificationForAllCameras();
        } else if (m_faceRegistryLoaded && roomId == m_faceRegistryRoomId) {
            // Reconnecting to the same room must reuse the cached native
            // enrollment. Do not call GuardVision::setFaceRegistry() or
            // reconfigure the native face session while frames are live.
            m_pendingFaceRegistryVersion = m_faceRegistryVersion.version;
            m_requestedFaceRegistryVersion.clear();
            clearPendingFaceRegistry();
            const QString expectedRoomId = roomId;
            QTimer::singleShot(0, this, [this, expectedRoomId]() {
                if (!m_sessionManager || !m_sessionManager->isRegistered() || m_sessionManager->state().roomId.trimmed() != expectedRoomId) {
                    return;
                }
                reactivateCachedFaceRegistryForCurrentRoom();
            });
        } else {
            const bool activeRegistryChanged = !m_faceRegistryRoomId.isEmpty() && roomId != m_faceRegistryRoomId;
            const bool pendingRegistryChanged = !m_pendingFaceRegistryRoomId.isEmpty() && roomId != m_pendingFaceRegistryRoomId;
            if (activeRegistryChanged || pendingRegistryChanged) {
                m_faceRegistryLoaded = false;
                m_faceRegistryState = FaceRegistryState::NotLoaded;
                m_pendingFaceRegistryVersion.clear();
                m_requestedFaceRegistryVersion.clear();
                clearPendingFaceRegistry();
                if (m_eventCoordinator)
                    m_eventCoordinator->setFaceRegistryLoaded(false);
                suspendFaceIdentificationForAllCameras();
            }
        }

        updateRoomUi();
        if (m_realtimeClient && (state.userDisconnected || !m_sessionManager->hasLiveAccessToken()))
            m_realtimeClient->stop();
    });
    connect(m_sessionManager, &guard::backend::GuardSessionManager::sessionError, this,
            [this](const QString& message) { updateFooterStatus(tr("Backend session: %1").arg(message), QStringLiteral("#fb7185")); });
    connect(m_sessionManager, &guard::backend::GuardSessionManager::connectionSucceeded, this, [this](const QVector<CameraUiModel>& mappings) {
        // Complete the modal RoomConnectionDialog signal stack before
        // camera mappings, WebSocket startup, camera synchronization,
        // and GuardVision registry work can mutate application state.
        // Running these operations re-entrantly from the Connect button
        // completion could tear down an active source while the dialog's
        // nested event loop was still unwinding.
        const QVector<CameraUiModel> mappingsCopy = mappings;
        QTimer::singleShot(0, this, [this, mappingsCopy]() {
            if (!hasAuthenticatedBackendSession())
                return;
            syncEventCoordinatorRoomAssignment();
            QString workspaceError;
            if (!ensureCameraWorkspaceRoom(m_sessionManager->state().roomId.trimmed(), &workspaceError)) {
                GuardMessageDialog::warning(this, tr("Room Connection"), workspaceError);
                return;
            }
            applyActivationCameraMappings(mappingsCopy);
            startBackendOperationalSession();
        });
    });

    connect(m_realtimeClient, &guard::backend::GuardRealtimeClient::faceRegistryInvalidated, this,
            [this](const QString&, const QString&, const QString&) { refreshFaceRegistryVersion(); });
    connect(m_realtimeClient, &guard::backend::GuardRealtimeClient::notificationSettingsInvalidated, this,
            [this](const QString&) { refreshNotificationSettings(); });

    connect(m_eventCoordinator, &guard::events::GuardEventCoordinator::eventUploaded, this, [this](const QString&, const QString& category) {
        updateFooterStatus(tr("%1 event delivered to backend").arg(category), QStringLiteral("#3DA35D"));
    });
    connect(m_eventCoordinator, &guard::events::GuardEventCoordinator::eventQueued, this,
            [this](const QString&, const QString& category, const QString& reason) {
                updateFooterStatus(tr("%1 event queued: %2").arg(category, reason), QStringLiteral("#f59e0b"));
            });
    connect(m_eventCoordinator, &guard::events::GuardEventCoordinator::eventRejected, this,
            [this](const QString&, const QString& category, const QString& reason) {
                updateFooterStatus(tr("%1 event rejected: %2").arg(category, reason), QStringLiteral("#fb7185"));
            });
    connect(m_localAlerts, &guard::alerts::LocalAlertService::hazardPresenceChanged, this, [this](bool present) {
        if (m_hazardAlarmIndicator)
            m_hazardAlarmIndicator->setActive(present);
    });
    connect(m_hazardAlarmIndicator, &HazardAlarmIndicator::acknowledgeRequested, m_eventCoordinator,
            &guard::events::GuardEventCoordinator::acknowledgeHazardAlarm);
    connect(m_hazardAlarmIndicator, &HazardAlarmIndicator::dismissRequested, m_eventCoordinator,
            &guard::events::GuardEventCoordinator::dismissHazardAlarm);

    m_heartbeatTimer = new QTimer(this);
    m_heartbeatTimer->setInterval(30000);
    connect(m_heartbeatTimer, &QTimer::timeout, this, [this]() {
        sendInstallationHeartbeat();
        sendAllCameraHeartbeats();
    });
    m_heartbeatTimer->start();

    m_faceRegistryTimer = new QTimer(this);
    m_faceRegistryTimer->setInterval(60000);
    connect(m_faceRegistryTimer, &QTimer::timeout, this, &MainWindow::refreshFaceRegistryVersion);
    m_faceRegistryTimer->start();

    m_notificationSettingsTimer = new QTimer(this);
    m_notificationSettingsTimer->setInterval(60000);
    connect(m_notificationSettingsTimer, &QTimer::timeout, this, &MainWindow::refreshNotificationSettings);
    m_notificationSettingsTimer->start();
}

void MainWindow::startBackendOperationalSession() {
    updateRoomUi();
    syncEventCoordinatorRoomAssignment();
    if (m_realtimeClient)
        m_realtimeClient->start();
    syncCamerasFromBackend();
    refreshBackendOperationalData();
}

void MainWindow::syncEventCoordinatorRoomAssignment() {
    if (!m_eventCoordinator)
        return;

    const bool registered = m_sessionManager && m_sessionManager->isRegistered();
    const QString roomId = registered ? m_sessionManager->state().roomId.trimmed() : QString();

    // GuardSessionManager loads the saved room before the backend token is
    // restored during cold start.  No sessionChanged signal is emitted for that
    // already-saved state, so the event coordinator must be synchronized
    // explicitly.  Otherwise it keeps an empty active room, accepts only
    // local-only cameras, and silently ignores face/hazard events until the
    // operator changes rooms.
    m_eventCoordinator->setActiveRoomId(roomId);
    m_eventCoordinator->setBackendRoomAssigned(registered && m_sessionManager->hasLiveAccessToken());
}

bool MainWindow::hasAuthenticatedBackendSession() const {
    return m_backendClient && m_sessionManager && m_sessionManager->isRegistered() && m_sessionManager->hasLiveAccessToken();
}

bool MainWindow::hasActiveGuardVisionStream() const {
    for (CameraRuntimeController* controller : m_controllersByCameraId) {
        if (controller && controller->isGuardVisionStreamActive())
            return true;
    }
    return false;
}

void MainWindow::refreshBackendOperationalData() {
    if (!hasAuthenticatedBackendSession())
        return;
    refreshNotificationSettings();
    refreshFaceRegistryVersion();
}

void MainWindow::bootstrapCheckBackend(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion) {
    if (!m_backendClient) {
        if (completion)
            completion(false);
        return;
    }

    setSplashStatus(splash, tr("Checking backend connection..."));
    std::shared_ptr<bool> operationFinished;
    const std::function<void(bool)> finish = timedCompletion(this, timeoutMs, completion, &operationFinished);
    const QPointer<MainWindow> self(this);
    m_backendClient->testConnection([self, finish, operationFinished](const guard::backend::GuardApiResponse& response) {
        if (!self || *operationFinished)
            return;
        if (!response.ok()) {
            self->updateFooterStatus(self->tr("Backend unavailable: %1").arg(response.errorMessage), QStringLiteral("#fb7185"));
            finish(false);
            return;
        }
        self->updateFooterStatus(self->tr("Backend connection available"), QStringLiteral("#3DA35D"));
        finish(true);
    });
}

void MainWindow::bootstrapRestoreSession(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion) {
    if (!m_sessionManager || !m_sessionManager->isRegistered() || m_sessionManager->isUserDisconnected()) {
        if (completion)
            completion(false);
        return;
    }

    setSplashStatus(splash, tr("Restoring room connection..."));
    std::shared_ptr<bool> operationFinished;
    const std::function<void(bool)> finish = timedCompletion(this, timeoutMs, completion, &operationFinished);
    const QPointer<MainWindow> self(this);
    m_sessionManager->refreshAccessToken([self, finish, operationFinished](bool ok, const QString& errorMessage) {
        if (!self || *operationFinished)
            return;
        if (!ok && !errorMessage.trimmed().isEmpty()) {
            self->updateFooterStatus(self->tr("Backend session: %1").arg(errorMessage), QStringLiteral("#fb7185"));
        }
        finish(ok && self->hasAuthenticatedBackendSession());
    });
}

void MainWindow::bootstrapFaceRegistry(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion) {
    if (!hasAuthenticatedBackendSession() || !m_backendClient) {
        if (completion)
            completion(false);
        return;
    }

    setSplashStatus(splash, tr("Checking face registry..."));
    const QString requestedRoomId = m_sessionManager->state().roomId.trimmed();
    std::shared_ptr<bool> operationFinished;
    const std::function<void(bool)> finish = timedCompletion(this, timeoutMs, completion, &operationFinished);
    const QPointer<MainWindow> self(this);

    m_backendClient->get(QStringLiteral("/api/guard/faces/version"), [self, splash, finish, operationFinished,
                                                                      requestedRoomId](const guard::backend::GuardApiResponse& response) {
        if (!self || *operationFinished)
            return;
        if (!self->hasAuthenticatedBackendSession() || !self->m_sessionManager ||
            self->m_sessionManager->state().roomId.trimmed() != requestedRoomId) {
            finish(false);
            return;
        }
        if (!response.ok()) {
            self->updateFooterStatus(self->tr("Face registry version unavailable: %1").arg(response.errorMessage), QStringLiteral("#fb7185"));
            finish(false);
            return;
        }

        guard::api::FaceRegistryVersionInfo remoteVersion;
        QString error;
        if (!guard::api::FaceRegistryLoader::parseVersionPayload(response.body, remoteVersion, &error)) {
            self->updateFooterStatus(error, QStringLiteral("#fb7185"));
            finish(false);
            return;
        }

        const bool scopeChanged =
          self->m_faceRegistryLoaded && !remoteVersion.scope.trimmed().isEmpty() && self->m_faceRegistryVersion.scope != remoteVersion.scope;
        const bool needsReload = scopeChanged || guard::backend::shouldReloadFaceRegistry(self->m_faceRegistryVersion.version,
                                                                                          self->m_faceRegistryLoaded, remoteVersion.version);
        if (!needsReload && self->m_faceRegistryLoaded) {
            self->m_faceRegistryState = FaceRegistryState::Ready;
            setSplashStatus(splash, self->tr("Face registry is up to date."));
            if (self->m_eventCoordinator)
                self->m_eventCoordinator->setFaceRegistryLoaded(true);
            finish(true);
            return;
        }

        setSplashStatus(splash, self->tr("Loading face registry..."));
        self->m_backendClient->get(QStringLiteral("/api/guard/faces"), [self, splash, finish, operationFinished, remoteVersion,
                                                                        requestedRoomId](const guard::backend::GuardApiResponse& registryResponse) {
            if (!self || *operationFinished)
                return;
            if (!self->hasAuthenticatedBackendSession() || !self->m_sessionManager ||
                self->m_sessionManager->state().roomId.trimmed() != requestedRoomId) {
                finish(false);
                return;
            }
            if (!registryResponse.ok()) {
                self->updateFooterStatus(self->tr("Backend face registry unavailable: %1").arg(registryResponse.errorMessage),
                                         QStringLiteral("#fb7185"));
                finish(false);
                return;
            }

            guard::api::FaceRegistryData registry;
            QString parseError;
            if (!guard::api::FaceRegistryLoader::parseRegistryPayload(registryResponse.body, registry, &parseError)) {
                self->updateFooterStatus(parseError, QStringLiteral("#fb7185"));
                finish(false);
                return;
            }

            guard::api::FaceRegistryVersionInfo versionInfo = remoteVersion;
            const QString responseVersion = registry.version.trimmed().isEmpty() ? remoteVersion.version.trimmed() : registry.version.trimmed();
            versionInfo.version = responseVersion;
            if (!registry.scope.trimmed().isEmpty())
                versionInfo.scope = registry.scope.trimmed();
            if (registry.updatedAtUtc.isValid())
                versionInfo.updatedAtUtc = registry.updatedAtUtc;
            versionInfo.count = registry.faces.size();
            versionInfo.model = registry.model;
            versionInfo.threshold = registry.threshold;

            registry.sourceDescription = self->tr("backend %1").arg(self->m_backendClient->urlForPath(QStringLiteral("/api/guard/faces")).toString());
            const bool applied = self->applyFaceRegistry(registry, versionInfo);
            if (applied) {
                setSplashStatus(splash, self->tr("Loaded face registry: %1 face(s)").arg(registry.faces.size()));
                finish(true);
                return;
            }

            if (self->m_hasPendingFaceRegistry) {
                setSplashStatus(splash, self->tr("Face registry downloaded. Waiting for face identification initialization..."));
                // The registry payload is safely retained. Camera startup is
                // allowed to initialize IdentifyEngine and apply it before the
                // first media frame is submitted.
                finish(true);
                return;
            }
            finish(false);
        });
    });
}

void MainWindow::bootstrapSyncCameras(GuardSplash* splash, int timeoutMs, const std::function<void(bool)>& completion) {
    if (!hasAuthenticatedBackendSession()) {
        if (completion)
            completion(false);
        return;
    }

    setSplashStatus(splash, tr("Synchronizing cameras..."));
    std::shared_ptr<bool> operationFinished;
    const std::function<void(bool)> finish = timedCompletion(this, timeoutMs, completion, &operationFinished);
    syncCamerasFromBackend(
      [finish, operationFinished](bool ok) {
          if (!*operationFinished)
              finish(ok);
      },
      operationFinished);
}

void MainWindow::runColdStartBootstrap(GuardSplash* splash, const std::function<void(bool)>& completion) {
    if (m_bootstrapInProgress) {
        if (completion)
            completion(false);
        return;
    }
    m_bootstrapInProgress = true;

    const QPointer<MainWindow> self(this);
    const std::function<void(bool)> finish = [self, completion](bool ok) {
        if (!self)
            return;
        self->m_bootstrapInProgress = false;
        if (completion)
            completion(ok);
    };

    if (!m_guardVisionReady) {
        setSplashStatus(splash, tr("GuardVision is unavailable. Opening in degraded mode."));
        updateFooterStatus(tr("GuardVision unavailable"), QStringLiteral("#fb7185"));
        finish(false);
        return;
    }

    // Always perform the public health check while the splash is visible. A
    // registry download still requires a saved installation session, but the
    // operator should see the correct backend state even on a first launch or
    // after a deliberate room disconnect.
    bootstrapCheckBackend(splash, kBackendHealthTimeoutMs, [self, splash, finish](bool backendOk) {
        if (!self)
            return;

        const bool hasSavedRoomSession =
          self->m_sessionManager && self->m_sessionManager->isRegistered() && !self->m_sessionManager->isUserDisconnected();
        if (!backendOk) {
            setSplashStatus(splash, self->tr("Backend unavailable. Opening in offline mode."));
            self->updateFooterStatus(self->tr("Backend connection unavailable"), QStringLiteral("#fb7185"));
            finish(false);
            return;
        }

        if (!hasSavedRoomSession) {
            if (self->m_sessionManager && self->m_sessionManager->isUserDisconnected()) {
                setSplashStatus(splash, self->tr("Room disconnected. Backend is available."));
                self->updateFooterStatus(self->tr("Room disconnected"), QStringLiteral("#f59e0b"));
            } else {
                setSplashStatus(splash, self->tr("Backend available. No saved room session."));
                self->updateFooterStatus(self->m_testMode ? self->tr("GuardVision ready - test mode") : self->tr("GuardVision ready"),
                                         QStringLiteral("#3DA35D"));
            }
            finish(true);
            return;
        }

        self->bootstrapRestoreSession(splash, kSessionRestoreTimeoutMs, [self, splash, finish](bool sessionOk) {
            if (!self)
                return;
            if (!sessionOk) {
                setSplashStatus(splash, self->tr("Room connection unavailable. Opening in offline mode."));
                self->updateFooterStatus(self->tr("Backend session unavailable"), QStringLiteral("#fb7185"));
                finish(false);
                return;
            }

            self->updateRoomUi();
            setSplashStatus(splash, self->tr("Room session restored."));

            self->bootstrapFaceRegistry(splash, kFaceRegistryTimeoutMs, [self, splash, finish](bool registryOk) {
                if (!self)
                    return;
                if (!registryOk) {
                    setSplashStatus(splash, self->tr("Face registry unavailable. Camera face identification will wait for a successful refresh."));
                    self->updateFooterStatus(self->tr("Face registry not loaded"), QStringLiteral("#f59e0b"));
                }

                self->bootstrapSyncCameras(splash, kCameraSyncTimeoutMs, [self, splash, finish](bool cameraSyncOk) {
                    if (!self)
                        return;
                    if (!cameraSyncOk)
                        setSplashStatus(splash, self->tr("Camera sync incomplete. Local cameras kept."));

                    if (self->m_realtimeClient)
                        self->m_realtimeClient->start();
                    self->refreshNotificationSettings();

                    setSplashStatus(splash, self->tr("Ready."));
                    self->updateFooterStatus(self->m_faceRegistryLoaded ? self->tr("Guard ready") : self->tr("Guard ready - face registry pending"),
                                             self->m_faceRegistryLoaded ? QStringLiteral("#3DA35D") : QStringLiteral("#f59e0b"));
                    finish(true);
                });
            });
        });
    });
}

void MainWindow::restorePersistedCameras() {
    const QVector<CameraUiModel> stored = guard::backend::CameraStore::load();
    for (const CameraUiModel& camera : stored) {
        if (m_cameraGrid->cameraCount() >= m_cameraGrid->maximumCameraCount())
            break;
        addCameraTile(camera, false);
        if (m_cameraWorkspaceRoomId.isEmpty() && !camera.roomId.trimmed().isEmpty())
            m_cameraWorkspaceRoomId = camera.roomId.trimmed();
    }
}

void MainWindow::persistCameras() {
    guard::backend::CameraStore::save(m_cameras);
}

void MainWindow::loadFaceRegistryFromBackend() {
    if (!hasAuthenticatedBackendSession() || m_faceRegistryRequestInFlight)
        return;

    const QString requestedVersion = m_pendingFaceRegistryVersion.trimmed();
    if (requestedVersion.isEmpty()) {
        refreshFaceRegistryVersion();
        return;
    }

    const QString requestedRoomId = m_sessionManager->state().roomId.trimmed();
    const quint64 requestSerial = ++m_faceRegistryRequestSerial;
    m_faceRegistryRequestInFlight = true;
    m_faceRegistryState = FaceRegistryState::Downloading;
    m_requestedFaceRegistryVersion = requestedVersion;
    m_backendClient->get(
      QStringLiteral("/api/guard/faces"), [this, requestedVersion, requestedRoomId, requestSerial](const guard::backend::GuardApiResponse& response) {
          if (requestSerial != m_faceRegistryRequestSerial)
              return;
          m_faceRegistryRequestInFlight = false;
          if (!hasAuthenticatedBackendSession() || !m_sessionManager || m_sessionManager->state().roomId.trimmed() != requestedRoomId) {
              return;
          }
          if (!response.ok()) {
              m_faceRegistryState = FaceRegistryState::TemporarilyUnavailable;
              updateFooterStatus(tr("Backend face registry unavailable: %1. Camera monitoring will continue.").arg(response.errorMessage),
                                 QStringLiteral("#f59e0b"));
              return;
          }

          guard::api::FaceRegistryData registry;
          QString error;
          if (!guard::api::FaceRegistryLoader::parseRegistryPayload(response.body, registry, &error)) {
              m_faceRegistryState = FaceRegistryState::Rejected;
              updateFooterStatus(tr("%1 Camera monitoring will continue.").arg(error), QStringLiteral("#f59e0b"));
              return;
          }

          const QString responseVersion = registry.version.trimmed().isEmpty() ? requestedVersion : registry.version.trimmed();
          if (responseVersion != requestedVersion && m_pendingFaceRegistryVersion != responseVersion) {
              // The registry changed while this request was in flight. Re-check the
              // authoritative version instead of applying a potentially stale payload.
              refreshFaceRegistryVersion();
              return;
          }
          if (m_pendingFaceRegistryVersion != requestedVersion && responseVersion != m_pendingFaceRegistryVersion) {
              loadFaceRegistryFromBackend();
              return;
          }

          guard::api::FaceRegistryVersionInfo versionInfo = m_faceRegistryVersion;
          versionInfo.version = responseVersion;
          if (!registry.scope.trimmed().isEmpty())
              versionInfo.scope = registry.scope.trimmed();
          if (registry.updatedAtUtc.isValid())
              versionInfo.updatedAtUtc = registry.updatedAtUtc;
          versionInfo.count = registry.faces.size();
          versionInfo.model = registry.model;
          versionInfo.threshold = registry.threshold;

          registry.sourceDescription = tr("backend %1").arg(m_backendClient->urlForPath(QStringLiteral("/api/guard/faces")).toString());
          applyFaceRegistry(registry, versionInfo);

          if (m_pendingFaceRegistryVersion != responseVersion)
              loadFaceRegistryFromBackend();
      });
}

void MainWindow::refreshFaceRegistryVersion() {
    if (!hasAuthenticatedBackendSession() || m_faceRegistryVersionRequestInFlight)
        return;

    const QString requestedRoomId = m_sessionManager->state().roomId.trimmed();
    const quint64 requestSerial = ++m_faceRegistryVersionRequestSerial;
    m_faceRegistryVersionRequestInFlight = true;
    m_backendClient->get(
      QStringLiteral("/api/guard/faces/version"), [this, requestedRoomId, requestSerial](const guard::backend::GuardApiResponse& response) {
          if (requestSerial != m_faceRegistryVersionRequestSerial)
              return;
          m_faceRegistryVersionRequestInFlight = false;
          if (!hasAuthenticatedBackendSession() || !m_sessionManager || m_sessionManager->state().roomId.trimmed() != requestedRoomId) {
              return;
          }
          if (!response.ok()) {
              m_faceRegistryState = FaceRegistryState::TemporarilyUnavailable;
              updateFooterStatus(tr("Face registry version could not be checked. Camera monitoring will continue."), QStringLiteral("#f59e0b"));
              return;
          }

          guard::api::FaceRegistryVersionInfo version;
          QString error;
          if (!guard::api::FaceRegistryLoader::parseVersionPayload(response.body, version, &error)) {
              m_faceRegistryState = FaceRegistryState::Rejected;
              updateFooterStatus(tr("%1 Camera monitoring will continue.").arg(error), QStringLiteral("#f59e0b"));
              return;
          }

          if (m_hasPendingFaceRegistry && m_pendingFaceRegistryInfo.version.trimmed() == version.version.trimmed() &&
              (version.scope.trimmed().isEmpty() || m_pendingFaceRegistryInfo.scope.trimmed() == version.scope.trimmed())) {
              tryApplyPendingFaceRegistry();
              return;
          }

          const bool scopeChanged = m_faceRegistryLoaded && !version.scope.trimmed().isEmpty() && m_faceRegistryVersion.scope != version.scope;
          if (scopeChanged || guard::backend::shouldReloadFaceRegistry(m_faceRegistryVersion.version, m_faceRegistryLoaded, version.version)) {
              m_pendingFaceRegistryVersion = version.version;
              if (!m_faceRegistryRequestInFlight)
                  loadFaceRegistryFromBackend();
          } else if (m_faceRegistryLoaded) {
            m_faceRegistryState = FaceRegistryState::Ready;
            reactivateCachedFaceRegistryForCurrentRoom();
          }
      });
}

bool MainWindow::applyFaceRegistry(const guard::api::FaceRegistryData& registry, const guard::api::FaceRegistryVersionInfo& versionInfo) {
    m_pendingFaceRegistry = registry;
    m_pendingFaceRegistryInfo = versionInfo;
    m_pendingFaceRegistryRoomId = m_sessionManager ? m_sessionManager->state().roomId.trimmed() : QString();
    m_hasPendingFaceRegistry = true;
    m_faceRegistryState = FaceRegistryState::PendingIdentifyEngine;
    return tryApplyPendingFaceRegistry();
}

bool MainWindow::tryApplyPendingFaceRegistry() {
    if (!m_hasPendingFaceRegistry)
        return m_faceRegistryLoaded;

    const QString currentRoomId = m_sessionManager ? m_sessionManager->state().roomId.trimmed() : QString();
    if (!m_pendingFaceRegistryRoomId.isEmpty() && currentRoomId != m_pendingFaceRegistryRoomId) {
        clearPendingFaceRegistry();
        return false;
    }

    if (m_faceIdentificationPermanentlyUnavailable) {
        m_faceRegistryState = FaceRegistryState::TemporarilyUnavailable;
        return false;
    }

    if (!m_guardVisionReady || !m_guardVision || !m_guardVision->isInitialized()) {
        m_faceRegistryState = FaceRegistryState::PendingIdentifyEngine;
        updateFooterStatus(tr("Face registry is ready and waiting for GuardVision initialization."), QStringLiteral("#f59e0b"));
        return false;
    }

    // Applying a native registry requires at least one active stream. During a
    // room switch all old streams are released before new controllers are built,
    // so keep the newest registry pending and apply it from the next
    // guardVisionStreamRegistered signal before source playback begins.
    const bool hasActiveStream = hasActiveGuardVisionStream();
    if (!hasActiveStream && !m_faceRegistryLoaded) {
        m_faceRegistryState = FaceRegistryState::PendingIdentifyEngine;
        updateFooterStatus(tr("Face registry downloaded. Waiting for a camera stream to become active..."), QStringLiteral("#f59e0b"));
        return false;
    }

    // Replacing InspireFace FeatureHub data while live Identify sessions are
    // processing can enter an unsafe vendor-global teardown/re-enable path.
    // Initial enrollment is still performed before media starts. Later backend
    // registry revisions remain pending while any camera stream is active and
    // are applied by the periodic refresh once all streams are inactive.
    if (hasActiveStream && m_faceRegistryLoaded &&
        m_pendingFaceRegistryInfo.version.trimmed() != m_faceRegistryVersion.version.trimmed()) {
        m_faceRegistryState = FaceRegistryState::PendingIdentifyEngine;
        updateFooterStatus(tr("Face registry update is pending until active camera face sessions are safely quiesced."), QStringLiteral("#f59e0b"));
        return false;
    }

    guardvision::FaceRegistry guardVisionRegistry;
    guardVisionRegistry.threshold = m_pendingFaceRegistry.threshold;
    guardVisionRegistry.model = m_pendingFaceRegistry.model.toStdString();
    guardVisionRegistry.entries.reserve(static_cast<std::size_t>(m_pendingFaceRegistry.faces.size()));
    for (const guard::api::FaceRegistryFace& face : m_pendingFaceRegistry.faces) {
        if (face.id <= 0 || face.name.trimmed().isEmpty() || face.feature.empty())
            continue;
        guardvision::FaceRegistryEntry entry;
        entry.identityId = static_cast<std::uint64_t>(face.id);
        entry.displayName = face.name.trimmed().toStdString();
        entry.feature = face.feature;
        guardVisionRegistry.entries.push_back(std::move(entry));
    }

    if (guardVisionRegistry.entries.empty()) {
        // There is no identity to resolve. Do not initialize IdentifyEngine with
        // an empty registry; retain local detect-and-track behavior instead.
        // A previously loaded native registry, if any, remains masked by Guard.
        m_faceRegistry = m_pendingFaceRegistry;
        m_faceRegistryVersion = m_pendingFaceRegistryInfo;
        m_faceRegistryLoaded = true;
        m_faceRegistryState = FaceRegistryState::Ready;
        m_faceRegistryRoomId = currentRoomId;
        m_pendingFaceRegistryVersion = m_faceRegistryVersion.version;
        m_requestedFaceRegistryVersion.clear();
        m_faceIdentificationPermanentlyUnavailable = false;
        m_faceIdentificationUnavailableReason.clear();
        clearPendingFaceRegistry();
        suspendFaceIdentificationForAllCameras();
        if (m_eventCoordinator)
            m_eventCoordinator->setFaceRegistryLoaded(true);
        updateFooterStatus(
          tr("Loaded face registry: 0 face(s), %1").arg(m_faceRegistry.model.trimmed().isEmpty() ? tr("unknown model") : m_faceRegistry.model),
          QStringLiteral("#3DA35D"));
        return true;
    }

    // Streams start in detect-and-track mode when no registry is available.
    // Prepare IdentifyEngine only now, while a concrete room-scoped payload is
    // ready. The direct stream-registered connection performs this before the
    // first media frame is submitted on initial camera startup.
    bool identificationPrepared = false;
    QString identificationPreparationError;
    for (CameraRuntimeController* controller : m_controllersByCameraId) {
        if (!controller || !controller->isGuardVisionStreamActive())
            continue;
        if (controller->prepareFaceIdentification(m_pendingFaceRegistry.threshold, &identificationPreparationError)) {
            identificationPrepared = true;
            break;
        }
    }
    if (!identificationPrepared) {
        m_faceRegistryState = FaceRegistryState::PendingIdentifyEngine;
        if (!identificationPreparationError.isEmpty()) {
            updateFooterStatus(tr("Face identification preparation failed: %1. Detect-and-track remains active.").arg(identificationPreparationError),
                               QStringLiteral("#f59e0b"));
        }
        return false;
    }

    m_faceRegistryState = FaceRegistryState::Applying;
    const guardvision::Result result = m_guardVision->setFaceRegistry(guardVisionRegistry);
    if (!result.ok) {
        suspendFaceIdentificationForAllCameras();
        if (result.error.code == guardvision::GuardVisionErrorCode::NotInitialized) {
            // IdentifyEngine is still unavailable. Keep the newest payload and
            // retry from guardVisionStreamRegistered before source playback.
            m_faceRegistryState = FaceRegistryState::PendingIdentifyEngine;
            updateFooterStatus(tr("Face registry downloaded. Waiting for face identification initialization..."), QStringLiteral("#f59e0b"));
            return false;
        }

        if (result.error.code == guardvision::GuardVisionErrorCode::FaceModelMissing ||
            (result.error.code == guardvision::GuardVisionErrorCode::FaceEngineInitializationFailed && !result.error.recoverable)) {
            markFaceIdentificationUnavailable(QString::fromStdString(result.error.message));
            return false;
        }

        m_faceRegistryState = FaceRegistryState::Rejected;
        clearPendingFaceRegistry();
        updateFooterStatus(
          tr("Face registry enrollment failed: %1. Camera monitoring will continue.").arg(QString::fromStdString(result.error.message)),
          QStringLiteral("#f59e0b"));
        return false;
    }

    // Commit the registry only after GuardVision accepts the complete
    // replacement. A failed refresh leaves the previous valid registry active.
    m_faceRegistry = m_pendingFaceRegistry;
    m_faceRegistryVersion = m_pendingFaceRegistryInfo;
    m_faceRegistryLoaded = true;
    m_faceRegistryState = FaceRegistryState::Ready;
    m_faceRegistryRoomId = currentRoomId;
    m_pendingFaceRegistryVersion = m_faceRegistryVersion.version;
    m_requestedFaceRegistryVersion.clear();
    m_faceIdentificationPermanentlyUnavailable = false;
    m_faceIdentificationUnavailableReason.clear();
    clearPendingFaceRegistry();

    const QHash<quint64, QString> namesById = faceDisplayNamesById(m_faceRegistry);
    for (CameraRuntimeController* controller : m_controllersByCameraId) {
        if (controller)
            controller->syncFaceIdentificationFromRegistry(m_faceRegistry.threshold, namesById);
    }
    if (m_eventCoordinator)
        m_eventCoordinator->setFaceRegistryLoaded(true);

    updateFooterStatus(tr("Loaded face registry: %1 face(s), %2")
                         .arg(static_cast<int>(guardVisionRegistry.entries.size()))
                         .arg(m_faceRegistry.model.trimmed().isEmpty() ? tr("unknown model") : m_faceRegistry.model),
                       QStringLiteral("#3DA35D"));
    return true;
}

void MainWindow::clearPendingFaceRegistry() {
    m_pendingFaceRegistry = guard::api::FaceRegistryData{};
    m_pendingFaceRegistryInfo = guard::api::FaceRegistryVersionInfo{};
    m_pendingFaceRegistryRoomId.clear();
    m_hasPendingFaceRegistry = false;
}

void MainWindow::markFaceIdentificationUnavailable(const QString& reason) {
    m_faceIdentificationPermanentlyUnavailable = true;
    m_faceIdentificationUnavailableReason = reason.trimmed();
    m_faceRegistryState = FaceRegistryState::TemporarilyUnavailable;
    if (m_eventCoordinator)
        m_eventCoordinator->setFaceRegistryLoaded(false);
    suspendFaceIdentificationForAllCameras();

    const QString detail =
      m_faceIdentificationUnavailableReason.isEmpty()
        ? tr("Face identification is unavailable. Camera monitoring will continue.")
        : tr("Face identification is unavailable: %1. Camera monitoring will continue.").arg(m_faceIdentificationUnavailableReason);
    updateFooterStatus(detail, QStringLiteral("#f59e0b"));
}

void MainWindow::suspendFaceIdentificationForAllCameras() {
    for (CameraRuntimeController* controller : m_controllersByCameraId) {
        if (controller)
            controller->suspendFaceIdentification();
    }
}

bool MainWindow::reactivateCachedFaceRegistryForCurrentRoom() {
    if (!m_sessionManager || !m_sessionManager->isRegistered() || !m_faceRegistryLoaded)
        return false;

    const QString currentRoomId = m_sessionManager->state().roomId.trimmed();
    if (currentRoomId.isEmpty() || currentRoomId != m_faceRegistryRoomId)
        return false;

    if (hasUsableFaceRegistryEntries(m_faceRegistry)) {
        const QHash<quint64, QString> namesById = faceDisplayNamesById(m_faceRegistry);
        for (CameraRuntimeController* controller : m_controllersByCameraId) {
            if (controller)
                controller->syncFaceIdentificationFromRegistry(m_faceRegistry.threshold, namesById);
        }
    } else {
        // An empty room registry still authorizes unknown-face event decisions,
        // but there is no identity payload to expose locally.
        suspendFaceIdentificationForAllCameras();
    }

    m_faceRegistryState = FaceRegistryState::Ready;
    if (m_eventCoordinator)
        m_eventCoordinator->setFaceRegistryLoaded(true);
    updateFooterStatus(tr("Reused the cached face registry for the restored room connection."), QStringLiteral("#3DA35D"));
    return true;
}

void MainWindow::refreshNotificationSettings() {
    if (!hasAuthenticatedBackendSession())
        return;
    m_backendClient->get(QStringLiteral("/api/guard/notification-settings"), [this](const guard::backend::GuardApiResponse& response) {
        if (!response.ok())
            return;
        QString error;
        const QJsonObject root = response.jsonObject(&error);
        if (!error.isEmpty())
            return;
        guard::backend::NotificationSettings parsed;
        if (!guard::backend::parseNotificationSettingsFromJson(root, &parsed))
            return;
        m_notificationSettings = parsed;
        if (m_eventCoordinator)
            m_eventCoordinator->setNotificationSettings(m_notificationSettings);
    });
}

void MainWindow::syncCamerasFromBackend(const std::function<void(bool)>& completion, const std::shared_ptr<bool>& cancelled) {
    if (!m_backendClient || !m_sessionManager || !m_sessionManager->isRegistered() || !m_sessionManager->hasLiveAccessToken()) {
        if (completion)
            completion(false);
        return;
    }

    const QString roomId = m_sessionManager->state().roomId.trimmed();
    m_backendClient->get(
      QStringLiteral("/api/guard/cameras"), [this, roomId, completion, cancelled](const guard::backend::GuardApiResponse& response) {
          if ((cancelled && *cancelled) || !m_sessionManager || !m_sessionManager->isRegistered() ||
              m_sessionManager->state().roomId.trimmed() != roomId) {
              if (completion && !(cancelled && *cancelled))
                  completion(false);
              return;
          }
          if (!response.ok()) {
              updateFooterStatus(tr("Camera synchronization failed: %1").arg(response.errorMessage), QStringLiteral("#fb7185"));
              if (completion)
                  completion(false);
              return;
          }

          QString error;
          const QJsonObject root = response.jsonObject(&error);
          if (!error.isEmpty()) {
              if (completion)
                  completion(false);
              return;
          }

          QString workspaceError;
          if (!ensureCameraWorkspaceRoom(roomId, &workspaceError)) {
              updateFooterStatus(workspaceError, QStringLiteral("#fb7185"));
              if (completion)
                  completion(false);
              return;
          }

          QVector<CameraUiModel> roomCameras;
          const QJsonArray cameras = root.value(QStringLiteral("cameras")).toArray();
          roomCameras.reserve(cameras.size());
          for (const QJsonValue& value : cameras) {
              const QJsonObject object = value.toObject();
              const QString backendId = guard::backend::backendCameraIdFromApiJson(object);
              if (backendId.isEmpty())
                  continue;

              CameraUiModel camera;
              const QString clientCameraId = object.value(QStringLiteral("clientCameraId")).toString().trimmed();
              camera.backendCameraId = backendId;
              camera.clientCameraId = clientCameraId.isEmpty() ? backendId : clientCameraId;
              camera.id = camera.clientCameraId;
              camera.roomId = roomId;
              if (guard::backend::cameraFromApiJson(object, &camera, nullptr))
                  roomCameras.append(camera);
          }

          // The visible camera workspace belongs to exactly one room. Remove
          // every tile that is not present in the selected room before adding or
          // updating that room's authoritative backend camera list.
          QStringList staleCameraIds;
          for (const CameraUiModel& current : m_cameras) {
              bool found = false;
              for (const CameraUiModel& target : roomCameras) {
                  if ((!current.backendCameraId.isEmpty() && current.backendCameraId == target.backendCameraId) ||
                      current.effectiveClientCameraId() == target.effectiveClientCameraId() || current.id == target.id) {
                      found = true;
                      break;
                  }
              }
              if (!found)
                  staleCameraIds.append(current.id);
          }
          for (const QString& cameraId : staleCameraIds)
              removeCameraTileLocally(cameraId, false);

          for (CameraUiModel target : roomCameras) {
              CameraUiModel* existing = nullptr;
              for (CameraUiModel& current : m_cameras) {
                  if ((!target.backendCameraId.isEmpty() && current.backendCameraId == target.backendCameraId) ||
                      current.effectiveClientCameraId() == target.effectiveClientCameraId() || current.id == target.id) {
                      existing = &current;
                      break;
                  }
              }

              if (existing) {
                  target.id = existing->id;
                  if (!sameCameraModel(*existing, target))
                      applyCameraEdit(existing->id, target);
                  continue;
              }

              if (m_cameraGrid->cameraCount() >= m_cameraGrid->maximumCameraCount())
                  break;
              addCameraTile(target, false);
          }

          persistCameras();
          updateFooterStatus(tr("Loaded %1 camera(s) for the selected room.").arg(m_cameraGrid->cameraCount()), QStringLiteral("#3DA35D"));
          if (completion)
              completion(true);
      });
}

void MainWindow::sendAllCameraHeartbeats() {
    if (!m_sessionManager || !m_sessionManager->hasLiveAccessToken())
        return;
    for (auto it = m_controllersByCameraId.constBegin(); it != m_controllersByCameraId.constEnd(); ++it) {
        if (it.value())
            sendCameraHeartbeat(it.key(), static_cast<int>(it.value()->state()));
    }
}

void MainWindow::sendInstallationHeartbeat() {
    if (!m_backendClient || !m_sessionManager || !m_sessionManager->isRegistered() || !m_sessionManager->hasLiveAccessToken())
        return;
    QJsonObject body;
    body.insert(QStringLiteral("occurredAt"), QDateTime::currentDateTimeUtc().toString(Qt::ISODate));
    body.insert(QStringLiteral("guardVersion"), QCoreApplication::applicationVersion());
    m_backendClient->postJson(QStringLiteral("/api/guard/installations/heartbeat"), body, [](const guard::backend::GuardApiResponse&) {});
}

void MainWindow::sendCameraHeartbeat(const QString& cameraId, int stateValue) {
    if (!m_backendClient || !m_sessionManager || !m_sessionManager->hasLiveAccessToken())
        return;
    const CameraUiModel* camera = findCamera(cameraId);
    if (!camera || camera->backendCameraId.trimmed().isEmpty())
        return;
    QJsonObject body;
    body.insert(QStringLiteral("status"), cameraStatusApiValue(static_cast<CameraRuntimeController::State>(stateValue)));
    body.insert(QStringLiteral("occurredAt"), QDateTime::currentDateTimeUtc().toString(Qt::ISODate));
    m_backendClient->postJson(QStringLiteral("/api/guard/cameras/%1/heartbeat").arg(camera->backendCameraId), body,
                              [](const guard::backend::GuardApiResponse&) {});
}

void MainWindow::connectUiSignals() {
    connect(ui->addCameraButton, &QPushButton::clicked, this, [this]() {
        if (m_cameraGrid->cameraCount() >= m_cameraGrid->maximumCameraCount()) {
            GuardMessageDialog::information(this, tr("Guard"), tr("You can add up to %1 cameras.").arg(m_cameraGrid->maximumCameraCount()));
            return;
        }
        CameraDialog dialog(this);
        dialog.setDefaultCameraName(nextDefaultCameraName());
        if (dialog.exec() != QDialog::Accepted)
            return;

        const CameraUiModel camera = dialog.camera();
        QString conflictingCameraName;
        if (hasCameraIpConflict(camera, QString(), &conflictingCameraName)) {
            GuardMessageDialog::warning(
              this, tr("Camera IP Conflict"),
              tr("The IP address is already used by '%1'. Enter a different camera IP address.").arg(conflictingCameraName));
            return;
        }
        addOrRegisterCamera(camera);
    });

    connect(ui->loginToRoomButton, &QPushButton::clicked, this, &MainWindow::showRoomLoginDialog);
    connect(ui->footerSettingsButton, &QPushButton::clicked, this, &MainWindow::openAppSettingsDialog);
    connect(m_recordingStorageManager, &guard::recording::RecordingStorageManager::recordingRootChanged, this, [this](const QString& effectiveRoot) {
        updateFooterStatus(tr("Recording root updated: %1").arg(effectiveRoot), QStringLiteral("#3DA35D"));
    });
    connect(m_cameraGrid, &CameraGridWidget::cameraRemovalRequested, this, &MainWindow::removeCameraTile);
}

void MainWindow::openAppSettingsDialog() {
    AppSettingsDialog dialog(m_recordingStorageManager, m_backendClient, this);
    dialog.setNotificationPolicies(m_notificationSettings.notifyUnknownIncoming, m_notificationSettings.notifyUnapprovedIncoming);
    connect(&dialog, &AppSettingsDialog::testHazardAlarmRequested, m_localAlerts, &guard::alerts::LocalAlertService::testHazardAlarm);
    if (dialog.exec() != QDialog::Accepted)
        return;
    const QList<CameraRuntimeController*> controllers = m_controllersByCameraId.values();
    for (CameraRuntimeController* controller : controllers) {
        if (controller)
            controller->reloadFileLoggingSettings();
    }
    if (m_localAlerts)
        m_localAlerts->reloadSettings();
    if (dialog.backendUrlChanged() && m_sessionManager) {
        // Device credentials and installation IDs belong to one backend. Do
        // not send credentials issued by the previous server to a new URL.
        m_sessionManager->clearLocalSession();
        updateRoomUi();
    } else if (m_backendClient) {
        m_backendClient->clearAccessToken();
    }
    if (m_sessionManager && m_sessionManager->isRegistered())
        m_sessionManager->restoreSession();
    if (m_sessionManager && m_sessionManager->isRegistered())
        refreshBackendOperationalData();
    updateFooterStatus(tr("Application settings saved"), QStringLiteral("#3DA35D"));
}

void MainWindow::checkLicenseState() {
    if (m_shutdownInProgress || m_quitting || m_licensePromptActive)
        return;
    const guard::license::GuardLicenseManager::Status status = guard::license::GuardLicenseManager::status();
    if (!guard::license::GuardLicenseManager::requiresPermanentLicense(status)) {
        if (status.state == guard::license::GuardLicenseManager::State::TemporaryValid) {
            updateFooterStatus(tr("Temporary Guard license: %1 day(s) remaining").arg(status.daysRemaining), QStringLiteral("#f59e0b"));
        }
        return;
    }
    promptForPermanentLicenseIfRequired();
}

bool MainWindow::promptForPermanentLicenseIfRequired() {
    const guard::license::GuardLicenseManager::Status status = guard::license::GuardLicenseManager::status();
    if (!guard::license::GuardLicenseManager::requiresPermanentLicense(status))
        return true;

    const bool permanentOnly = status.state == guard::license::GuardLicenseManager::State::TemporaryExpired;
    m_licensePromptActive = true;
    bringToForeground();
    LicenseActivationDialog dialog(permanentOnly, this);
    const bool accepted = dialog.exec() == QDialog::Accepted;
    m_licensePromptActive = false;

    if (!accepted) {
        m_quitting = true;
        performApplicationShutdown();
        QTimer::singleShot(0, qApp, []() { QCoreApplication::quit(); });
        return false;
    }

    const guard::license::GuardLicenseManager::Status updatedStatus = guard::license::GuardLicenseManager::status();
    if (updatedStatus.state == guard::license::GuardLicenseManager::State::PermanentValid)
        updateFooterStatus(tr("Permanent Guard license activated"), QStringLiteral("#3DA35D"));
    else if (updatedStatus.state == guard::license::GuardLicenseManager::State::TemporaryValid)
        updateFooterStatus(tr("Temporary Guard license activated: %1 day(s) remaining").arg(updatedStatus.daysRemaining), QStringLiteral("#f59e0b"));
    return true;
}

CameraUiModel* MainWindow::findCamera(const QString& cameraId) {
    auto it = std::find_if(m_cameras.begin(), m_cameras.end(), [&cameraId](const CameraUiModel& camera) { return camera.id == cameraId; });
    return it == m_cameras.end() ? nullptr : &(*it);
}

const CameraUiModel* MainWindow::findCamera(const QString& cameraId) const {
    auto it = std::find_if(m_cameras.constBegin(), m_cameras.constEnd(), [&cameraId](const CameraUiModel& camera) { return camera.id == cameraId; });
    return it == m_cameras.constEnd() ? nullptr : &(*it);
}

QString MainWindow::nextDefaultCameraName() const {
    const int nextNumber = (m_cameraGrid ? m_cameraGrid->cameraCount() : m_cameras.size()) + 1;
    return tr("Camera %1").arg(nextNumber);
}

bool MainWindow::hasCameraIpConflict(const CameraUiModel& candidate, const QString& excludedCameraId, QString* conflictingCameraName) const {
    const QString candidateIp = normalizedCameraIp(candidate);
    if (candidateIp.isEmpty())
        return false;

    for (const CameraUiModel& camera : m_cameras) {
        if (!excludedCameraId.isEmpty() && camera.id == excludedCameraId)
            continue;
        if (normalizedCameraIp(camera) != candidateIp)
            continue;
        if (conflictingCameraName)
            *conflictingCameraName = camera.displayName();
        return true;
    }
    return false;
}

QString MainWindow::cameraCardTitle(const CameraUiModel& camera) const {
    return cameraCardTitleText(camera);
}

void MainWindow::updateCameraTilePresentation(CameraWidget* tile, const CameraUiModel& camera) {
    if (!tile)
        return;
    tile->setCameraDisplayName(cameraCardTitle(camera));
    tile->setCameraDirection(camera.direction, camera.directionConfigured);
}

void MainWindow::addOrRegisterCamera(const CameraUiModel& input) {
    CameraUiModel camera = input;
    if (camera.clientCameraId.trimmed().isEmpty())
        camera.clientCameraId = camera.id;
    if (!m_sessionManager || !m_sessionManager->isRegistered()) {
        addCameraTile(camera);
        persistCameras();
        return;
    }

    camera.roomId = m_sessionManager->state().roomId;
    const QJsonObject body = guard::backend::cameraToApiJson(camera, camera.roomId);
    m_backendClient->postJson(QStringLiteral("/api/guard/cameras"), body, [this, camera](const guard::backend::GuardApiResponse& response) mutable {
        if (!response.ok()) {
            GuardMessageDialog::warning(this, tr("Add Camera"), response.errorMessage);
            return;
        }
        QString error;
        const QJsonObject root = response.jsonObject(&error);
        const QJsonObject object = root.value(QStringLiteral("camera")).toObject();
        CameraUiModel mapped = camera;
        if (!object.isEmpty())
            guard::backend::cameraFromApiJson(object, &mapped, &error);
        if (!error.isEmpty()) {
            GuardMessageDialog::warning(this, tr("Add Camera"), error);
            return;
        }
        if (mapped.backendCameraId.trimmed().isEmpty()) {
            GuardMessageDialog::warning(this, tr("Add Camera"), tr("The backend did not return a camera ID."));
            return;
        }
        addCameraTile(mapped);
        persistCameras();
    });
}

void MainWindow::addCameraTile(const CameraUiModel& camera, bool animatedLayout) {
    if (m_controllersByCameraId.contains(camera.id))
        return;
    CameraWidget* cameraWidget = new CameraWidget;
    cameraWidget->setCameraId(camera.id);
    updateCameraTilePresentation(cameraWidget, camera);
    cameraWidget->setCameraStatus(CameraWidget::CameraStatus::Disconnected);
    if (!m_cameraGrid->addCameraWidget(cameraWidget, animatedLayout)) {
        delete cameraWidget;
        return;
    }

    m_cameras.append(camera);
    if (m_cameraWorkspaceRoomId.isEmpty() && !camera.roomId.trimmed().isEmpty())
        m_cameraWorkspaceRoomId = camera.roomId.trimmed();

    // Use a fresh GuardVision stream ID for every new camera controller.
    // Normal Connect/Disconnect reuses the same controller-owned stream, but
    // a removed-room camera must not donate its native stream slot to a
    // different camera ID. Field logs showed stale hazard/face events from the
    // previous owner immediately after such adoption.
    CameraRuntimeController* controller = new CameraRuntimeController(camera, m_guardVision.get(), m_eventAdapter, cameraWidget->renderView(),
                                                                      m_testMode, m_recordingStorageManager, QString(), false, 0, 0, this);
    m_controllersByCameraId.insert(camera.id, controller);

    connect(cameraWidget, &CameraWidget::editRequested, this, &MainWindow::editCamera);
    connect(cameraWidget, &CameraWidget::settingsRequested, this, &MainWindow::openCameraSettings);
    connect(cameraWidget, &CameraWidget::logsRequested, this, &MainWindow::showCameraLogs);
    connect(cameraWidget, &CameraWidget::connectRequested, this, &MainWindow::connectCamera);
    connect(cameraWidget, &CameraWidget::disconnectRequested, this, &MainWindow::disconnectCamera);

    connect(controller, &CameraRuntimeController::faceOccurrenceReady, m_eventCoordinator,
            &guard::events::GuardEventCoordinator::handleFaceOccurrence);
    connect(controller, &CameraRuntimeController::faceTrackLost, m_eventCoordinator, &guard::events::GuardEventCoordinator::handleFaceTrackLost);
    connect(controller, &CameraRuntimeController::hazardOccurrenceReady, m_eventCoordinator,
            &guard::events::GuardEventCoordinator::handleHazardOccurrence);
    connect(controller, &CameraRuntimeController::hazardSessionStopped, m_eventCoordinator,
            &guard::events::GuardEventCoordinator::handleCameraHazardSessionStopped);

    // registerStream initializes GuardVision's IdentifyEngine lazily. Use a
    // direct connection so a registry downloaded during splash startup is
    // applied after stream registration but before the media producer starts.
    connect(
      controller, &CameraRuntimeController::guardVisionStreamRegistered, this,
      [this, controller](const QString&) {
          if (m_hasPendingFaceRegistry) {
              tryApplyPendingFaceRegistry();
              return;
          }
          if (m_faceRegistryLoaded && hasUsableFaceRegistryEntries(m_faceRegistry)) {
              controller->syncFaceIdentificationFromRegistry(m_faceRegistry.threshold, faceDisplayNamesById(m_faceRegistry));
          }
      },
      Qt::DirectConnection);
    connect(controller, &CameraRuntimeController::faceIdentificationUnavailable, this,
            [this](const QString&, const QString& message) { markFaceIdentificationUnavailable(message); });

    connect(controller, &CameraRuntimeController::stateChanged, this, [this](const QString& cameraId, int stateValue, const QString& message) {
        CameraWidget* tile = m_cameraGrid->cameraWidget(cameraId);
        if (!tile)
            return;
        const CameraRuntimeController::State state = static_cast<CameraRuntimeController::State>(stateValue);
        switch (state) {
            case CameraRuntimeController::State::Disconnected:
                tile->setCameraStatus(CameraWidget::CameraStatus::Disconnected);
                tile->setCameraViewPlaceholderVisible(true);
                break;
            case CameraRuntimeController::State::Connecting:
                tile->setCameraStatus(CameraWidget::CameraStatus::Connecting);
                tile->setCameraViewPlaceholderVisible(false);
                break;
            case CameraRuntimeController::State::Connected:
                tile->setCameraStatus(CameraWidget::CameraStatus::Connected);
                tile->setCameraViewPlaceholderVisible(false);
                break;
            case CameraRuntimeController::State::Reconnecting:
                tile->setCameraStatus(CameraWidget::CameraStatus::Reconnecting);
                tile->setCameraViewPlaceholderVisible(false);
                break;
            case CameraRuntimeController::State::Error:
                tile->setCameraStatus(CameraWidget::CameraStatus::Error);
                break;
        }
        sendCameraHeartbeat(cameraId, stateValue);
        if (!message.isEmpty()) {
            updateFooterStatus(message, state == CameraRuntimeController::State::Error ? QStringLiteral("#fb7185") : QStringLiteral("#3DA35D"));
        }
    });
    connect(controller, &CameraRuntimeController::fatalRuntimeError, this,
            [this](const QString&, const QString& message) { GuardMessageDialog::warning(this, tr("Guard"), message); });

    persistCameras();
    updateFooterStatus(tr("%1 camera(s) configured").arg(m_cameraGrid->cameraCount()), QStringLiteral("#3DA35D"));
}

void MainWindow::editCamera(const QString& cameraId) {
    CameraUiModel* camera = findCamera(cameraId);
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    if (!camera || !controller)
        return;

    CameraDialog dialog(this);
    dialog.setDialogTitle(tr("Edit Camera"));
    dialog.setCamera(*camera);
    if (dialog.exec() != QDialog::Accepted)
        return;

    CameraUiModel updated = dialog.camera();
    QString conflictingCameraName;
    if (hasCameraIpConflict(updated, cameraId, &conflictingCameraName)) {
        GuardMessageDialog::warning(this, tr("Camera IP Conflict"),
                                    tr("The IP address is already used by '%1'. Enter a different camera IP address.").arg(conflictingCameraName));
        return;
    }
    if (!camera->backendCameraId.isEmpty() && m_sessionManager && m_sessionManager->isRegistered()) {
        updated.roomId = m_sessionManager->state().roomId;
        m_backendClient->patchJson(QStringLiteral("/api/guard/cameras/%1").arg(camera->backendCameraId),
                                   guard::backend::cameraToApiJson(updated, updated.roomId),
                                   [this, cameraId, updated](const guard::backend::GuardApiResponse& response) mutable {
                                       if (!response.ok()) {
                                           GuardMessageDialog::warning(this, tr("Edit Camera"), response.errorMessage);
                                           return;
                                       }
                                       QString error;
                                       const QJsonObject root = response.jsonObject(&error);
                                       CameraUiModel mapped = updated;
                                       const QJsonObject object = root.value(QStringLiteral("camera")).toObject();
                                       if (!object.isEmpty())
                                           guard::backend::cameraFromApiJson(object, &mapped, &error);
                                       if (!error.isEmpty()) {
                                           GuardMessageDialog::warning(this, tr("Edit Camera"), error);
                                           return;
                                       }
                                       if (mapped.backendCameraId.trimmed().isEmpty()) {
                                           GuardMessageDialog::warning(this, tr("Edit Camera"), tr("The backend did not return a camera ID."));
                                           return;
                                       }
                                       applyCameraEdit(cameraId, mapped);
                                   });
        return;
    }
    applyCameraEdit(cameraId, updated);
}

void MainWindow::applyCameraEdit(const QString& cameraId, const CameraUiModel& updated) {
    CameraUiModel* camera = findCamera(cameraId);
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    if (!camera || !controller)
        return;

    const bool connectionChanged = !cameraConnectionFieldsEqual(*camera, updated);
    const bool wasStreaming = cameraWasStreaming(controller);

    controller->updateCamera(updated);
    *camera = updated;

    if (CameraWidget* tile = m_cameraGrid->cameraWidget(cameraId)) {
        updateCameraTilePresentation(tile, updated);
        if (connectionChanged) {
            tile->setCameraStatus(CameraWidget::CameraStatus::Disconnected);
            tile->setCameraViewPlaceholderVisible(true);
            tile->renderView()->clearFrame();
        }
    }

    if (connectionChanged && wasStreaming) {
        QString error;
        if (!controller->start(&error)) {
            updateFooterStatus(tr("Camera reconnect failed: %1").arg(error), QStringLiteral("#fb7185"));
        }
    }

    persistCameras();
}

void MainWindow::openCameraSettings(const QString& cameraId) {
    const CameraUiModel* camera = findCamera(cameraId);
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    if (!camera || !controller)
        return;

    CameraSettingsDialog dialog(this);
    dialog.setCameraName(camera->displayName());
    dialog.setSettings(controller->detectionSettings());
    dialog.setTestMode(m_testMode);
    dialog.setTestSourceSettings(controller->testSourceSettings());

    const bool hcNetSdkSource = camera->type.contains(QStringLiteral("Hikvision"), Qt::CaseInsensitive);
    const auto refreshAvailability = [&dialog, controller, hcNetSdkSource]() {
        dialog.setDetectionAvailability(controller->isConnected(), hcNetSdkSource, controller->capabilities(),
                                        !guard::runtime::resolveHazardModelPath().isEmpty());
    };
    refreshAvailability();
    connect(controller, &CameraRuntimeController::capabilitiesChanged, &dialog, [refreshAvailability](const QString&) { refreshAvailability(); });
    connect(controller, &CameraRuntimeController::stateChanged, &dialog,
            [refreshAvailability](const QString&, int, const QString&) { refreshAvailability(); });

    if (dialog.exec() != QDialog::Accepted)
        return;
    QString errorMessage;
    if (!controller->applyCameraSettings(dialog.settings(), dialog.testSourceSettings(), &errorMessage)) {
        GuardMessageDialog::warning(this, tr("Guard"), tr("Camera settings could not be applied: %1").arg(errorMessage));
    }
}

void MainWindow::showCameraLogs(const QString& cameraId) {
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    const CameraUiModel* camera = findCamera(cameraId);
    if (!controller || !camera)
        return;
    if (QPointer<QDialog> existing = m_logDialogsByCameraId.value(cameraId)) {
        existing->show();
        existing->raise();
        existing->activateWindow();
        return;
    }

    QDialog* dialog = new QDialog(this);
    dialog->setAttribute(Qt::WA_DeleteOnClose);
    dialog->setWindowTitle(tr("%1 Logs").arg(camera->displayName()));
    dialog->resize(760, 460);

    QVBoxLayout* layout = new QVBoxLayout(dialog);
    QLabel* pathLabel = new QLabel(dialog);
    pathLabel->setWordWrap(true);
    pathLabel->setTextInteractionFlags(Qt::TextSelectableByMouse | Qt::TextSelectableByKeyboard);
    QTextEdit* editor = new QTextEdit(dialog);
    editor->setReadOnly(true);
    editor->setPlainText(controller->logMessages().join(QLatin1Char('\n')));
    QDialogButtonBox* buttons = new QDialogButtonBox(QDialogButtonBox::Close, dialog);
    QPushButton* openFileButton = buttons->addButton(tr("Open Log File"), QDialogButtonBox::ActionRole);
    QPushButton* openFolderButton = buttons->addButton(tr("Open Log Folder"), QDialogButtonBox::ActionRole);
    const auto updatePathLabel = [this, pathLabel, openFileButton](const QString& path) {
        const bool available = !path.trimmed().isEmpty();
        pathLabel->setText(available ? tr("Log file: %1").arg(QDir::toNativeSeparators(path))
                                     : tr("File logging is disabled or the log file is unavailable."));
        pathLabel->setToolTip(QDir::toNativeSeparators(path));
        openFileButton->setEnabled(available);
    };
    updatePathLabel(controller->logFilePath());
    layout->addWidget(pathLabel);
    layout->addWidget(editor, 1);
    layout->addWidget(buttons);

    const QPointer<CameraRuntimeController> controllerGuard(controller);
    connect(openFileButton, &QPushButton::clicked, dialog, [this, controllerGuard]() {
        if (!controllerGuard)
            return;
        const QString path = controllerGuard->logFilePath();
        if (path.isEmpty() || !QFileInfo::exists(path)) {
            GuardMessageDialog::warning(this, tr("Camera Logs"), tr("The camera log file is not available."));
            return;
        }
        if (!QDesktopServices::openUrl(QUrl::fromLocalFile(path))) {
            GuardMessageDialog::warning(this, tr("Camera Logs"), tr("The camera log file could not be opened."));
        }
    });
    connect(openFolderButton, &QPushButton::clicked, dialog, [this, controllerGuard]() {
        if (!controllerGuard)
            return;
        const QString directory = controllerGuard->logDirectoryPath();
        if (directory.isEmpty() || !QFileInfo(directory).isDir()) {
            GuardMessageDialog::warning(this, tr("Camera Logs"), tr("The camera log folder is not available."));
            return;
        }
        if (!QDesktopServices::openUrl(QUrl::fromLocalFile(directory))) {
            GuardMessageDialog::warning(this, tr("Camera Logs"), tr("The camera log folder could not be opened."));
        }
    });
    connect(buttons, &QDialogButtonBox::rejected, dialog, &QDialog::close);
    connect(controller, &CameraRuntimeController::logAppended, dialog, [editor, cameraId](const QString& id, const QString& message) {
        if (id == cameraId)
            editor->append(message.toHtmlEscaped());
    });
    connect(controller, &CameraRuntimeController::logFileChanged, dialog, [cameraId, updatePathLabel](const QString& id, const QString& path) {
        if (id == cameraId)
            updatePathLabel(path);
    });
    connect(dialog, &QObject::destroyed, this, [this, cameraId]() { m_logDialogsByCameraId.remove(cameraId); });
    m_logDialogsByCameraId.insert(cameraId, dialog);
    dialog->show();
}

void MainWindow::removeCameraTile(const QString& cameraId) {
    const CameraUiModel* camera = findCamera(cameraId);
    if (!camera)
        return;
    if (!camera->backendCameraId.isEmpty() && m_sessionManager && m_sessionManager->isRegistered()) {
        const QString backendId = camera->backendCameraId;
        m_backendClient->deleteResource(QStringLiteral("/api/guard/cameras/%1").arg(backendId),
                                        [this, cameraId](const guard::backend::GuardApiResponse& response) {
                                            if (!response.ok()) {
                                                GuardMessageDialog::warning(this, tr("Remove Camera"), response.errorMessage);
                                                return;
                                            }
                                            removeCameraTileLocally(cameraId);
                                        });
        return;
    }
    removeCameraTileLocally(cameraId);
}

void MainWindow::removeCameraTileLocally(const QString& cameraId, bool animatedLayout) {
    if (!m_controllersByCameraId.contains(cameraId))
        return;

    if (QPointer<QDialog> logs = m_logDialogsByCameraId.take(cameraId))
        logs->close();

    CameraRuntimeController* controller = m_controllersByCameraId.take(cameraId);
    if (controller) {
        controller->stop();
        // A timed stop failure must not leave a producer targeting a controller
        // that is about to be deleted. Join workers and detach queued callbacks.
        // The native GuardVision stream is intentionally left process-owned; it
        // is not returned to another camera because cross-camera slot adoption
        // leaked stale hazard/face state from the previous owner.
        controller->prepareForApplicationShutdown();
        delete controller;
    }

    m_cameraGrid->removeCameraWidget(cameraId, animatedLayout);
    m_cameras.erase(std::remove_if(m_cameras.begin(), m_cameras.end(), [&cameraId](const CameraUiModel& camera) { return camera.id == cameraId; }),
                    m_cameras.end());
    persistCameras();
    updateFooterStatus(tr("%1 camera(s) configured").arg(m_cameraGrid->cameraCount()), QStringLiteral("#3DA35D"));
}

bool MainWindow::removeAllCameraTilesLocally(QString* errorMessage) {
    Q_UNUSED(errorMessage);
    const QList<CameraRuntimeController*> controllers = m_controllersByCameraId.values();

    // Stop every old-room producer first. The native GuardVision streams stay
    // registered until final process exit, but they are no longer recycled into
    // controllers for a different camera ID. Reusing those slots carried stale
    // GuardVision hazard/face state into the new room and was still triggering
    // the MSVC debug heap assertion after repeated room switches.
    for (CameraRuntimeController* controller : controllers) {
        if (!controller)
            continue;
        controller->stop();
        controller->prepareForApplicationShutdown();
    }

    m_reusableGuardVisionStreamSlots.clear();

    for (QPointer<QDialog> logs : m_logDialogsByCameraId) {
        if (logs)
            logs->close();
    }
    m_logDialogsByCameraId.clear();
    m_controllersByCameraId.clear();
    for (CameraRuntimeController* controller : controllers)
        delete controller;

    // Bulk room teardown must not start one removal animation per camera.
    // The animation groups retain QPropertyAnimation targets until their
    // DeferredDelete event is processed; deleting several camera hosts in the
    // same UI turn can leave stale animation targets and corrupt the debug CRT
    // heap.  Clear the whole grid synchronously after all camera runtimes are
    // already quiescent.
    if (m_cameraGrid)
        m_cameraGrid->clearCameraWidgets();

    m_cameras.clear();
    m_cameraWorkspaceRoomId.clear();
    persistCameras();
    updateFooterStatus(tr("Room cameras, streams, and alarms were cleared."), QStringLiteral("#3DA35D"));
    return true;
}

bool MainWindow::ensureCameraWorkspaceRoom(const QString& roomId, QString* errorMessage) {
    const QString normalizedRoomId = roomId.trimmed();
    if (normalizedRoomId.isEmpty())
        return true;

    bool workspaceMatches = m_cameraWorkspaceRoomId == normalizedRoomId;
    if (m_cameraWorkspaceRoomId.isEmpty() && !m_cameras.isEmpty()) {
        // Cameras created before the first room connection have no roomId and
        // must remain available for backend enrollment. A non-empty different
        // roomId is the signal that this is an actual old-room workspace.
        const bool containsDifferentRoom = std::any_of(m_cameras.cbegin(), m_cameras.cend(), [&normalizedRoomId](const CameraUiModel& camera) {
            const QString cameraRoomId = camera.roomId.trimmed();
            return !cameraRoomId.isEmpty() && cameraRoomId != normalizedRoomId;
        });
        workspaceMatches = !containsDifferentRoom;
    }

    if (!workspaceMatches && !m_cameras.isEmpty() && !removeAllCameraTilesLocally(errorMessage))
        return false;
    m_cameraWorkspaceRoomId = normalizedRoomId;
    return true;
}

void MainWindow::connectCamera(const QString& cameraId) {
    if (!m_guardVisionReady) {
        GuardMessageDialog::warning(this, tr("Guard"), tr("GuardVision is not initialized."));
        return;
    }
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    if (!controller)
        return;

    if (controller->state() == CameraRuntimeController::State::Connecting || controller->state() == CameraRuntimeController::State::Connected ||
        controller->state() == CameraRuntimeController::State::Reconnecting) {
        return;
    }

    // Registry synchronization is optional for source startup. When the
    // backend registry is still loading, the camera starts with face
    // detect-and-track only; motion, hazard, playback, and recording remain
    // available. Identification is enabled only after the room registry is ready.
    if (hasAuthenticatedBackendSession() && !m_faceRegistryLoaded) {
        if (!m_hasPendingFaceRegistry && !m_faceRegistryRequestInFlight && !m_faceRegistryVersionRequestInFlight)
            refreshFaceRegistryVersion();
        updateFooterStatus(tr("Camera is starting while face identification is pending."), QStringLiteral("#f59e0b"));
    }

    startCameraNow(cameraId);
}

void MainWindow::startCameraNow(const QString& cameraId) {
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    if (!controller)
        return;
    if (controller->state() == CameraRuntimeController::State::Connecting || controller->state() == CameraRuntimeController::State::Connected ||
        controller->state() == CameraRuntimeController::State::Reconnecting) {
        return;
    }

    QString errorMessage;
    if (!controller->start(&errorMessage)) {
        GuardMessageDialog::warning(this, tr("Guard"), errorMessage.isEmpty() ? tr("The camera could not be started.") : errorMessage);
        return;
    }

    // The direct stream-registered signal normally applies the pending
    // registry before source playback. This fallback also covers custom
    // controller implementations that emit asynchronously.
    if (m_hasPendingFaceRegistry)
        tryApplyPendingFaceRegistry();
}

void MainWindow::disconnectCamera(const QString& cameraId) {
    CameraRuntimeController* controller = m_controllersByCameraId.value(cameraId, nullptr);
    if (controller)
        controller->requestStop();
}

void MainWindow::showRoomLoginDialog() {
    for (const CameraUiModel& camera : m_cameras) {
        if (!camera.directionConfigured) {
            GuardMessageDialog::warning(
              this, tr("Camera Direction Required"),
              tr("The camera '%1' was created by an older Guard version. Edit it and select Incoming or Outgoing before connecting to a room.")
                .arg(camera.displayName()));
            return;
        }
    }

    RoomConnectionDialog dialog(m_backendClient, m_sessionManager, m_cameras, this);
    QPointer<RoomConnectionDialog> dialogGuard(&dialog);

    // Use the dialog itself as the connection context. Together with QPointer
    // checks in asynchronous completions, this prevents callbacks from using a
    // stack dialog after its modal event loop has ended.
    connect(&dialog, &RoomConnectionDialog::connectionRequested, &dialog, [this, dialogGuard](const guard::backend::RoomConnectionRequest& request) {
        if (!dialogGuard || !m_sessionManager)
            return;
        dialogGuard->setStatusMessage(tr("Connecting"));
        dialogGuard->setBusy(true);
        m_sessionManager->connectToRoom(request);
    });
    connect(&dialog, &RoomConnectionDialog::disconnectRequested, &dialog, [this, dialogGuard]() {
        if (!dialogGuard || !m_sessionManager)
            return;
        m_sessionManager->disconnectRoom([this, dialogGuard](bool success, const QString& errorMessage) {
            if (!dialogGuard)
                return;
            dialogGuard->setBusy(false);
            if (!success) {
                dialogGuard->setStatusMessage(errorMessage, true);
                return;
            }
            QString teardownError;
            if (!removeAllCameraTilesLocally(&teardownError)) {
                dialogGuard->setStatusMessage(teardownError, true);
                return;
            }
            dialogGuard->onDisconnected();
            updateRoomUi();
        });
    });
    connect(m_sessionManager, &guard::backend::GuardSessionManager::connectionSucceeded, &dialog, [dialogGuard](const QVector<CameraUiModel>&) {
        if (dialogGuard)
            dialogGuard->onConnectionSucceeded();
    });
    connect(m_sessionManager, &guard::backend::GuardSessionManager::sessionError, &dialog, [dialogGuard](const QString& message) {
        if (!dialogGuard)
            return;
        dialogGuard->setBusy(false);
        dialogGuard->setStatusMessage(message, true);
    });
    dialog.exec();
}

void MainWindow::updateRoomUi() {
    if (!m_sessionManager || !m_sessionManager->isRegistered()) {
        ui->loginToRoomButton->setText(tr("Room Connection"));
        ui->loginToRoomButton->setToolTip(m_sessionManager && m_sessionManager->hasInstallationIdentity()
                                            ? tr("Select any available room for this Guard computer")
                                            : tr("Connect this computer to a backend room"));
        return;
    }
    const guard::backend::InstallationState state = m_sessionManager->state();
    const QString room = state.roomName.trimmed().isEmpty() ? state.roomId : state.roomName;
    if (m_sessionManager->hasLiveAccessToken()) {
        ui->loginToRoomButton->setText(tr("%1 — Connected").arg(room));
        ui->loginToRoomButton->setToolTip(tr("View room connection status or disconnect"));
    } else {
        ui->loginToRoomButton->setText(tr("%1 — Disconnected").arg(room));
        ui->loginToRoomButton->setToolTip(tr("Backend room connection is unavailable"));
    }
}

void MainWindow::applyActivationCameraMappings(const QVector<CameraUiModel>& mappings) {
    for (const CameraUiModel& mapping : mappings) {
        for (CameraUiModel& camera : m_cameras) {
            if (camera.effectiveClientCameraId() == mapping.clientCameraId || camera.id == mapping.clientCameraId) {
                camera.backendCameraId = mapping.backendCameraId;
                camera.roomId = m_sessionManager->state().roomId;
                if (CameraRuntimeController* controller = m_controllersByCameraId.value(camera.id, nullptr))
                    controller->updateCamera(camera);
                break;
            }
        }
    }
    persistCameras();
}

void MainWindow::clearBackendCameraMappings() {
    bool changed = false;
    for (CameraUiModel& camera : m_cameras) {
        if (!camera.backendCameraId.isEmpty() || !camera.roomId.isEmpty()) {
            camera.backendCameraId.clear();
            camera.roomId.clear();
            changed = true;
        }
        if (CameraRuntimeController* controller = m_controllersByCameraId.value(camera.id, nullptr))
            controller->updateCamera(camera);
    }
    if (changed)
        persistCameras();
}

void MainWindow::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange) {
        ui->retranslateUi(this);
        retranslateDynamicUi();
    } else if (event->type() == QEvent::WindowStateChange && isMinimized() && !m_hidingToTray && !m_quitting) {
        // Keep a tray entry for every minimize path while leaving the minimized
        // window visible in the Windows taskbar.
        ensureSystemTray();
        showTrayIcon();
    }
    QMainWindow::changeEvent(event);
}

void MainWindow::retranslateDynamicUi() {
    setWindowTitle(m_testMode ? tr("Guard - Test Mode") : tr("Guard"));
    ui->titleBar->setTitle(windowTitle());
    updateRoomUi();
    if (m_cameraGrid)
        m_cameraGrid->refreshTranslations();

    if (m_trayIcon)
        m_trayIcon->setToolTip(windowTitle());
    if (m_trayShowAction)
        m_trayShowAction->setText(tr("Show Guard"));
    if (m_trayExitAction)
        m_trayExitAction->setText(tr("Exit"));
}

void MainWindow::updateFooterStatus(const QString& text, const QString& color) {
    ui->connectionStatusLabel->setText(text);
    ui->connectionStateLamp->setFixedSize(12, 12);
    ui->connectionStateLamp->setStyleSheet(QStringLiteral("QFrame#connectionStateLamp {"
                                                          " background-color: %1;"
                                                          " border: 0px;"
                                                          " border-radius: 6px;"
                                                          "}")
                                             .arg(color));
}

void MainWindow::closeEvent(QCloseEvent* event) {
    if (m_quitting) {
        QMainWindow::closeEvent(event);
        return;
    }
    event->ignore();
    hideToTrayFromClose();
}

void MainWindow::ensureSystemTray() {
    if (m_trayIcon)
        return;
    setupSystemTray();
}

void MainWindow::showTrayIcon(bool showHint) {
    ensureSystemTray();
    if (!m_trayIcon)
        return;

    const QIcon icon = GuardIcon::trayIcon();
    m_trayIcon->setIcon(icon);
    m_trayIcon->setToolTip(windowTitle());
    m_trayIcon->setVisible(true);

    // On Windows the Explorer notification area may not yet be ready when the
    // first visibility request is sent (especially during application startup
    // or an Explorer restart). Re-issuing the harmless show request after the
    // event loop turns makes the tray registration reliable on Qt 5.x.
    const QList<int> retryDelays = QList<int>() << 0 << 250 << 1000;
    for (int delay : retryDelays) {
        QPointer<QSystemTrayIcon> trayIcon(m_trayIcon);
        QTimer::singleShot(delay, this, [this, trayIcon, icon]() {
            if (!trayIcon || m_quitting)
                return;
            trayIcon->setIcon(icon);
            trayIcon->setToolTip(windowTitle());
            trayIcon->setVisible(true);
        });
    }

    if (showHint && !m_trayHintShown && QSystemTrayIcon::supportsMessages()) {
        m_trayHintShown = true;
        QPointer<QSystemTrayIcon> trayIcon(m_trayIcon);
        QTimer::singleShot(300, this, [this, trayIcon]() {
            if (!trayIcon || m_quitting)
                return;
            trayIcon->showMessage(tr("Guard"), tr("Guard is still running in the background. Use the tray icon to restore the window."),
                                  QSystemTrayIcon::Information, 4000);
        });
    }
}

void MainWindow::setupSystemTray() {
    QApplication::setQuitOnLastWindowClosed(false);

    if (m_trayIcon)
        return;

    // Construct the icon even when isSystemTrayAvailable() momentarily reports
    // false. QSystemTrayIcon will register it when the Windows shell becomes
    // available; returning early here made the previous implementation silently
    // skip tray creation on some machines.
    m_trayIcon = new QSystemTrayIcon(GuardIcon::trayIcon(), this);
    m_trayIcon->setToolTip(windowTitle());

    m_trayMenu = new QMenu(this);
    m_trayShowAction = m_trayMenu->addAction(tr("Show Guard"));
    m_trayMenu->addSeparator();
    m_trayExitAction = m_trayMenu->addAction(tr("Exit"));
    connect(m_trayShowAction, &QAction::triggered, this, &MainWindow::showFromTray, Qt::QueuedConnection);
    connect(m_trayExitAction, &QAction::triggered, this, &MainWindow::quitApplication, Qt::QueuedConnection);

    m_trayIcon->setContextMenu(m_trayMenu);
    connect(m_trayIcon, &QSystemTrayIcon::activated, this, [this](QSystemTrayIcon::ActivationReason reason) {
        if (reason == QSystemTrayIcon::Trigger || reason == QSystemTrayIcon::DoubleClick)
            showFromTray();
    });
}

void MainWindow::minimizeToTray() {
    ensureSystemTray();
    showTrayIcon();

    if (isFullScreen()) {
        m_restoreFullScreen = true;
        m_restoreMaximized = false;
        showNormal();
    } else {
        m_restoreFullScreen = false;
        m_restoreMaximized = isMaximized();
    }

    showMinimized();
    // Keep the taskbar entry for minimize, and register the tray icon after the
    // minimized window-state transition has completed.
    QTimer::singleShot(0, this, [this]() { showTrayIcon(); });
}

void MainWindow::hideToTrayFromClose() {
    if (m_hidingToTray || m_quitting)
        return;

    ensureSystemTray();

    if (!m_trayIcon) {
        // A platform without a system tray cannot hide the only application
        // window safely, so fall back to an ordinary taskbar minimize.
        showMinimized();
        return;
    }

    if (!isVisible() && !isMinimized()) {
        showTrayIcon();
        return;
    }

    m_hidingToTray = true;
    if (!isMinimized()) {
        m_restoreFullScreen = isFullScreen();
        m_restoreMaximized = isMaximized();
    }

    showTrayIcon();
    hide();  // Closing hides the taskbar entry; the tray icon remains available.
    m_hidingToTray = false;
    QTimer::singleShot(0, this, [this]() { showTrayIcon(); });
}

void MainWindow::showFromTray() {
    if (!isVisible() || isMinimized()) {
        if (m_restoreFullScreen) {
            showFullScreen();
        } else if (m_restoreMaximized) {
            showMaximized();
        } else {
            showNormal();
        }
    }

    raise();
    activateWindow();
}

void MainWindow::bringToForeground() {
    ensureSystemTray();
    showFromTray();
}

void MainWindow::quitApplication() {
    if (m_quitting || m_shutdownInProgress || m_shutdownComplete) {
        return;
    }
    m_quitting = true;
    performApplicationShutdown();

    // Let the QAction/QMenu triggered stack unwind before QApplication starts
    // destroying the tray menu and top-level widgets. All producer and recorder
    // threads are already joined, so this next-turn quit cannot admit new work.
    QTimer::singleShot(0, qApp, []() { QCoreApplication::quit(); });
}
