#include "AppSettingsDialog.h"

#include "CameraFileLogger.h"
#include "GuardHardwareId.h"
#include "GuardLicenseManager.h"
#include "SecureCredentialStore.h"
#include "GuardTheme.h"
#include "platform/compat/GuardPalette.h"
#include "GuardMessageDialog.h"
#include "WindowTitleBar.h"
#include "services/backend/GuardBackendClient.h"

#include <QCheckBox>
#include <QApplication>
#include <QClipboard>
#include <QColor>
#include <QRegularExpression>
#include <QDesktopServices>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGroupBox>
#include <QJsonObject>
#include <QGraphicsDropShadowEffect>
#include <QHBoxLayout>
#include <QLabel>
#include <QList>
#include <QLineEdit>
#include <QPainterPath>
#include <QPointer>
#include <QPushButton>
#include <QRegion>
#include <QResizeEvent>
#include <QSettings>
#include <QShowEvent>
#include <QSlider>
#include <QStorageInfo>
#include <QPalette>
#include <QTabBar>
#include <QTabWidget>
#include <QUrl>
#include <QCoreApplication>
#include <QEvent>
#include <QVBoxLayout>

namespace {
constexpr int kDialogCornerRadius = 4;
const char kHazardAlarmEnabledKey[] = "alerts/pcHazardAlarmEnabled";
const char kHazardAlarmVolumeKey[] = "alerts/pcHazardAlarmVolume";
const char kHazardRepeatKey[] = "alerts/repeatUntilAcknowledged";
const char kLicenseCredentialName[] = "guard-license-key";
constexpr int kServerTabIndex = 0;
constexpr int kAlertsTabIndex = 1;
constexpr int kRecordingTabIndex = 2;
constexpr int kDiagnosticsTabIndex = 3;
constexpr int kLicenseTabIndex = 4;

QString sourceDescription(guard::recording::RecordingRootSource source) {
    if (source == guard::recording::RecordingRootSource::EnvironmentOverride) {
        return QCoreApplication::translate("AppSettingsDialog", "Environment override active: GUARD_RECORDING_ROOT");
    }
    return QCoreApplication::translate("AppSettingsDialog", "Source: %1").arg(guard::recording::RecordingStorageManager::rootSourceName(source));
}

void styleButton(QPushButton* button) {
    if (!button)
        return;
    button->setAutoDefault(false);
    button->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
}

void markSettingsValueLabel(QLabel* label) {
    if (!label)
        return;
    label->setObjectName(QStringLiteral("settingsValueLabel"));
    QPalette palette = label->palette();
    palette.setColor(QPalette::WindowText, GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
    label->setPalette(palette);
}

void markSettingsHelpLabel(QLabel* label) {
    if (!label)
        return;
    label->setObjectName(QStringLiteral("settingsHelpLabel"));
    QPalette palette = label->palette();
    palette.setColor(QPalette::WindowText, GuardTheme::colorFromHex(GuardTheme::kTextMuted));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextMuted));
    label->setPalette(palette);
}

void styleSettingsForm(QFormLayout* form) {
    if (!form)
        return;
    form->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
}

QLabel* createFieldLabel(QWidget* parent, const QString& text) {
    auto* label = new QLabel(text, parent);
    label->setObjectName(QStringLiteral("settingsFieldLabel"));
    QPalette palette = label->palette();
    palette.setColor(QPalette::WindowText, GuardTheme::colorFromHex(GuardTheme::kTextSubtle));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextSubtle));
    label->setPalette(palette);
    return label;
}

void addFormRow(QFormLayout* form, QWidget* parent, const QString& labelText, QWidget* field) {
    form->addRow(createFieldLabel(parent, labelText), field);
}

void applySettingsPanelPalette(QWidget* widget) {
    if (!widget)
        return;
    widget->setAttribute(Qt::WA_StyledBackground, true);
    QPalette palette = widget->palette();
    palette.setColor(QPalette::Window, GuardTheme::colorFromHex(GuardTheme::kSurfacePanel));
    palette.setColor(QPalette::Base, GuardTheme::colorFromHex(GuardTheme::kSurfaceMuted));
    palette.setColor(QPalette::WindowText, GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
    guardSetPlaceholderTextColor(palette, GuardTheme::colorFromHex(GuardTheme::kTextPlaceholder));
    widget->setPalette(palette);
}

void styleSettingsLineEdit(QLineEdit* edit) {
    if (!edit)
        return;
    edit->setObjectName(QStringLiteral("settingsLineEdit"));
    edit->setProperty("settingsField", true);
    // Apply the field style directly as well as through the dialog stylesheet.
    // This avoids native Windows style leakage on older Qt versions and keeps
    // all Application Settings fields visually consistent.
    edit->setStyleSheet(GuardTheme::settingsLineEditStyleSheet());
    QPalette palette = edit->palette();
    palette.setColor(QPalette::Base, GuardTheme::colorFromHex(GuardTheme::kSurfaceMuted));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
    guardSetPlaceholderTextColor(palette, GuardTheme::colorFromHex(GuardTheme::kTextPlaceholder));
    edit->setPalette(palette);
}

QWidget* createSettingsTabPage() {
    auto* tab = new QWidget;
    tab->setObjectName(QStringLiteral("settingsTabPage"));
    applySettingsPanelPalette(tab);
    return tab;
}

QGroupBox* createSettingsGroup(const QString& title, QWidget* parent) {
    auto* group = new QGroupBox(title, parent);
    group->setObjectName(QStringLiteral("settingsFormGroup"));
    group->setProperty("settingsPanel", true);
    // Apply one shared explicit style to every settings group. Relying only on
    // a dynamic-property selector allowed the Windows native frame to leak
    // through on the Server tab with some Qt 5.x style engines.
    group->setStyleSheet(GuardTheme::settingsGroupBoxStyleSheet());
    applySettingsPanelPalette(group);
    return group;
}

QFormLayout* createSettingsForm(QGroupBox* group, int verticalSpacing = 11) {
    auto* form = new QFormLayout(group);
    form->setContentsMargins(16, 18, 16, 16);
    form->setHorizontalSpacing(16);
    form->setVerticalSpacing(verticalSpacing);
    styleSettingsForm(form);
    return form;
}

struct SettingsTabShell {
    QWidget* tab = nullptr;
    QVBoxLayout* layout = nullptr;
    QGroupBox* group = nullptr;
    QFormLayout* form = nullptr;
};

SettingsTabShell createSettingsTabShell(const QString& groupTitle) {
    SettingsTabShell shell;
    shell.tab = createSettingsTabPage();
    shell.layout = new QVBoxLayout(shell.tab);
    shell.layout->setContentsMargins(14, 14, 14, 14);
    shell.group = createSettingsGroup(groupTitle, shell.tab);
    shell.form = createSettingsForm(shell.group);
    shell.layout->addWidget(shell.group);
    shell.layout->addStretch(1);
    return shell;
}

QWidget* horizontalActions(QWidget* parent, const QList<QPushButton*>& buttons) {
    QWidget* host = new QWidget(parent);
    QHBoxLayout* layout = new QHBoxLayout(host);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(8);
    for (QPushButton* button : buttons)
        layout->addWidget(button);
    layout->addStretch(1);
    return host;
}

}  // namespace

AppSettingsDialog::AppSettingsDialog(guard::recording::RecordingStorageManager* storageManager, guard::backend::GuardBackendClient* backendClient,
                                     QWidget* parent)
: QDialog(parent),
  storageManager_(storageManager ? storageManager : guard::recording::RecordingStorageManager::instance()),
  backendClient_(backendClient) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setWindowModality(Qt::WindowModal);
    setAttribute(Qt::WA_TranslucentBackground);
    setObjectName(QStringLiteral("AppSettingsDialog"));
    buildUi();
    loadSettings();
    refreshRecordingPreview();
}

AppSettings AppSettingsDialog::settings() const {
    return settings_;
}
bool AppSettingsDialog::backendUrlChanged() const {
    return backendUrlChanged_;
}

void AppSettingsDialog::setNotificationPolicies(bool notifyUnknownIncoming, bool notifyUnapprovedIncoming) {
    notificationPoliciesSet_ = true;
    notifyUnknownIncoming_ = notifyUnknownIncoming;
    notifyUnapprovedIncoming_ = notifyUnapprovedIncoming;
    if (unknownIncomingPolicyLabel_)
        unknownIncomingPolicyLabel_->setText(notifyUnknownIncoming ? tr("Enabled") : tr("Disabled"));
    if (unapprovedIncomingPolicyLabel_)
        unapprovedIncomingPolicyLabel_->setText(notifyUnapprovedIncoming ? tr("Enabled") : tr("Disabled"));
}

void AppSettingsDialog::buildUi() {
    QVBoxLayout* outerLayout = new QVBoxLayout(this);
    outerLayout->setContentsMargins(20, 20, 20, 20);
    outerLayout->setSpacing(0);

    QWidget* shadowHost = new QWidget(this);
    shadowHost->setAttribute(Qt::WA_TranslucentBackground);
    QVBoxLayout* shadowLayout = new QVBoxLayout(shadowHost);
    shadowLayout->setContentsMargins(0, 0, 0, 0);
    shadowLayout->setSpacing(0);

    dialogFrame_ = new QWidget(shadowHost);
    dialogFrame_->setObjectName(QStringLiteral("dialogFrame"));
    dialogFrame_->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* frameLayout = new QVBoxLayout(dialogFrame_);
    frameLayout->setContentsMargins(0, 0, 0, 0);
    frameLayout->setSpacing(0);

    titleBar_ = new WindowTitleBar(dialogFrame_, WindowTitleBar::Style::Dialog);
    titleBar_->setObjectName(QStringLiteral("titleBar"));
    titleBar_->setTitle(tr("Application Settings"));
    frameLayout->addWidget(titleBar_, 0, Qt::AlignTop);

    QWidget* content = new QWidget(dialogFrame_);
    content->setObjectName(QStringLiteral("dialogContent"));
    content->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(24, 20, 24, 16);
    contentLayout->setSpacing(12);

    tabs_ = new QTabWidget(content);
    tabs_->setObjectName(QStringLiteral("applicationSettingsTabs"));
    tabs_->setDocumentMode(false);
    tabs_->setAttribute(Qt::WA_StyledBackground, true);
    tabs_->addTab(buildServerTab(), tr("Server"));
    tabs_->addTab(buildAlertsTab(), tr("Alerts"));
    tabs_->addTab(buildRecordingTab(), tr("Recording"));
    tabs_->addTab(buildDiagnosticsTab(), tr("Diagnostics"));
    tabs_->addTab(buildLicenseTab(), tr("License"));
    if (QTabBar* tabBar = tabs_->tabBar()) {
        tabBar->setExpanding(true);
        tabBar->setElideMode(Qt::ElideNone);
        tabBar->setUsesScrollButtons(false);
        tabBar->setDrawBase(false);
    }
    contentLayout->addWidget(tabs_, 1);
    frameLayout->addWidget(content, 1);

    QWidget* footer = new QWidget(dialogFrame_);
    footer->setObjectName(QStringLiteral("dialogFooter"));
    footer->setAttribute(Qt::WA_StyledBackground, true);
    QHBoxLayout* footerLayout = new QHBoxLayout(footer);
    footerLayout->setContentsMargins(16, 14, 16, 20);
    footerLayout->addStretch(1);
    cancelButton_ = new QPushButton(tr("Cancel"), footer);
    saveButton_ = new QPushButton(tr("Save"), footer);
    saveButton_->setDefault(true);
    styleButton(cancelButton_);
    styleButton(saveButton_);
    footerLayout->addWidget(cancelButton_);
    footerLayout->addWidget(saveButton_);
    frameLayout->addWidget(footer);

    shadowLayout->addWidget(dialogFrame_);
    outerLayout->addWidget(shadowHost);

    auto* shadow = new QGraphicsDropShadowEffect(shadowHost);
    shadow->setBlurRadius(48);
    shadow->setOffset(0, 16);
    shadow->setColor(QColor(2, 6, 23, 140));
    shadowHost->setGraphicsEffect(shadow);

    connect(cancelButton_, &QPushButton::clicked, this, &QDialog::reject);
    connect(saveButton_, &QPushButton::clicked, this, [this]() {
        if (validateAndSave())
            accept();
    });

    setStyleSheet(GuardTheme::cameraDialogStyleSheet());
    setMinimumWidth(900);
    resize(920, 540);
}

QWidget* AppSettingsDialog::buildServerTab() {
    const SettingsTabShell shell = createSettingsTabShell(tr("Backend Server"));
    serverGroup_ = shell.group;
    serverForm_ = shell.form;
    QGroupBox* group = shell.group;
    QFormLayout* form = shell.form;

    backendUrlEdit_ = new QLineEdit(group);
    styleSettingsLineEdit(backendUrlEdit_);
    backendUrlEdit_->setPlaceholderText(QStringLiteral("https://guard.example.com"));
    addFormRow(form, group, tr("Base URL"), backendUrlEdit_);
    backendUrlSourceLabel_ = new QLabel(group);
    backendUrlSourceLabel_->setWordWrap(true);
    markSettingsValueLabel(backendUrlSourceLabel_);
    addFormRow(form, group, tr("Source"), backendUrlSourceLabel_);
    backendConnectionLabel_ = new QLabel(tr("Not tested"), group);
    markSettingsValueLabel(backendConnectionLabel_);
    addFormRow(form, group, tr("Connection"), backendConnectionLabel_);
    backendVersionLabel_ = new QLabel(tr("Unknown"), group);
    markSettingsValueLabel(backendVersionLabel_);
    addFormRow(form, group, tr("Backend version"), backendVersionLabel_);
    testConnectionButton_ = new QPushButton(tr("Test Connection"), group);
    styleButton(testConnectionButton_);
    form->addRow(QString(), horizontalActions(group, QList<QPushButton*>() << testConnectionButton_));
    connect(testConnectionButton_, &QPushButton::clicked, this, &AppSettingsDialog::testBackendConnection);
    return shell.tab;
}

QWidget* AppSettingsDialog::buildLicenseTab() {
    const SettingsTabShell shell = createSettingsTabShell(tr("License Information"));
    licenseGroup_ = shell.group;
    licenseForm_ = shell.form;
    QGroupBox* group = shell.group;
    QFormLayout* form = shell.form;

    licenseStatusLabel_ = new QLabel(group);
    licenseStatusLabel_->setWordWrap(true);
    markSettingsValueLabel(licenseStatusLabel_);
    addFormRow(form, group, tr("Status"), licenseStatusLabel_);

    QWidget* hardwareHost = new QWidget(group);
    QHBoxLayout* hardwareLayout = new QHBoxLayout(hardwareHost);
    hardwareLayout->setContentsMargins(0, 0, 0, 0);
    hardwareLayout->setSpacing(8);
    hardwareIdEdit_ = new QLineEdit(hardwareHost);
    styleSettingsLineEdit(hardwareIdEdit_);
    hardwareIdEdit_->setReadOnly(true);
    hardwareIdEdit_->setMaxLength(19);
    hardwareIdEdit_->setPlaceholderText(tr("Hardware ID unavailable"));
    copyHardwareIdButton_ = new QPushButton(tr("Copy"), hardwareHost);
    styleButton(copyHardwareIdButton_);
    hardwareLayout->addWidget(hardwareIdEdit_, 1);
    hardwareLayout->addWidget(copyHardwareIdButton_);
    addFormRow(form, group, tr("Hardware ID"), hardwareHost);
    connect(copyHardwareIdButton_, &QPushButton::clicked, this, &AppSettingsDialog::copyHardwareIdToClipboard);

    licenseKeyEdit_ = new QLineEdit(group);
    styleSettingsLineEdit(licenseKeyEdit_);
    licenseKeyEdit_->setInputMask(QStringLiteral(">NNNN-NNNN-NNNN-NNNN;_"));
    licenseKeyEdit_->setMaxLength(19);
    addFormRow(form, group, tr("License key"), licenseKeyEdit_);

    activateLicenseButton_ = new QPushButton(tr("Activate License"), group);
    styleButton(activateLicenseButton_);
    form->addRow(QString(), horizontalActions(group, QList<QPushButton*>() << activateLicenseButton_));
    connect(activateLicenseButton_, &QPushButton::clicked, this, &AppSettingsDialog::activateLicenseFromSettings);

    licenseNoteLabel_ = new QLabel(tr("Copy the Guard hardware ID into LicenseGenerator. Non-activated LicenseGenerator output creates a 7-day Guard "
                                      "license. Activated LicenseGenerator output creates a permanent Guard license."),
                                   group);
    licenseNoteLabel_->setWordWrap(true);
    markSettingsHelpLabel(licenseNoteLabel_);
    form->addRow(QString(), licenseNoteLabel_);

    return shell.tab;
}

QWidget* AppSettingsDialog::buildAlertsTab() {
    QWidget* tab = createSettingsTabPage();
    QVBoxLayout* layout = new QVBoxLayout(tab);
    layout->setContentsMargins(14, 14, 14, 14);
    layout->setSpacing(12);
    localHazardGroup_ = createSettingsGroup(tr("Local Hazard Alarm"), tab);
    alertsForm_ = createSettingsForm(localHazardGroup_);
    QGroupBox* local = localHazardGroup_;
    QFormLayout* form = alertsForm_;
    pcHazardAlarmCheckBox_ = new QCheckBox(tr("Play an alarm on this computer"), local);
    form->addRow(QString(), pcHazardAlarmCheckBox_);
    QWidget* volumeHost = new QWidget(local);
    QHBoxLayout* volumeLayout = new QHBoxLayout(volumeHost);
    volumeLayout->setContentsMargins(0, 0, 0, 0);
    pcHazardVolumeSlider_ = new QSlider(Qt::Horizontal, volumeHost);
    pcHazardVolumeSlider_->setRange(0, 100);
    pcHazardVolumeLabel_ = new QLabel(volumeHost);
    markSettingsValueLabel(pcHazardVolumeLabel_);
    volumeLayout->addWidget(pcHazardVolumeSlider_, 1);
    volumeLayout->addWidget(pcHazardVolumeLabel_);
    addFormRow(form, local, tr("Volume"), volumeHost);
    repeatUntilAcknowledgedCheckBox_ = new QCheckBox(tr("Repeat until acknowledged"), local);
    form->addRow(QString(), repeatUntilAcknowledgedCheckBox_);
    testAlarmButton_ = new QPushButton(tr("Test Alarm"), local);
    styleButton(testAlarmButton_);
    form->addRow(QString(), horizontalActions(local, QList<QPushButton*>() << testAlarmButton_));
    connect(pcHazardVolumeSlider_, &QSlider::valueChanged, this,
            [this](int value) { pcHazardVolumeLabel_->setText(QStringLiteral("%1%").arg(value)); });
    connect(testAlarmButton_, &QPushButton::clicked, this, &AppSettingsDialog::testHazardAlarmRequested);
    layout->addWidget(local);

    accessWarningsGroup_ = createSettingsGroup(tr("Backend-Controlled Access Warnings"), tab);
    accessWarningsForm_ = createSettingsForm(accessWarningsGroup_);
    QGroupBox* policy = accessWarningsGroup_;
    QFormLayout* policyForm = accessWarningsForm_;
    unknownIncomingPolicyLabel_ = new QLabel(tr("Loaded after backend authentication"), policy);
    markSettingsValueLabel(unknownIncomingPolicyLabel_);
    unapprovedIncomingPolicyLabel_ = new QLabel(tr("Loaded after backend authentication"), policy);
    markSettingsValueLabel(unapprovedIncomingPolicyLabel_);
    addFormRow(policyForm, policy, tr("Unknown incoming"), unknownIncomingPolicyLabel_);
    addFormRow(policyForm, policy, tr("Unapproved incoming"), unapprovedIncomingPolicyLabel_);
    accessWarningsNoteLabel_ =
      new QLabel(tr("These policies are configured by an administrator. Disabling a warning never disables event upload."), policy);
    accessWarningsNoteLabel_->setWordWrap(true);
    markSettingsHelpLabel(accessWarningsNoteLabel_);
    policyForm->addRow(QString(), accessWarningsNoteLabel_);
    layout->addWidget(policy);
    layout->addStretch(1);
    return tab;
}

QWidget* AppSettingsDialog::buildRecordingTab() {
    QWidget* tab = createSettingsTabPage();
    QVBoxLayout* layout = new QVBoxLayout(tab);
    layout->setContentsMargins(14, 14, 14, 14);
    recordingGroup_ = createSettingsGroup(tr("Recording Storage"), tab);
    recordingForm_ = createSettingsForm(recordingGroup_, 10);
    QGroupBox* group = recordingGroup_;
    QFormLayout* form = recordingForm_;
    QWidget* rootHost = new QWidget(group);
    QHBoxLayout* rootLayout = new QHBoxLayout(rootHost);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(8);
    recordingRootEdit_ = new QLineEdit(rootHost);
    styleSettingsLineEdit(recordingRootEdit_);
    recordingRootEdit_->setPlaceholderText(tr("Leave empty to use the default recording location"));
    browseRecordingRootButton_ = new QPushButton(tr("Browse..."), rootHost);
    styleButton(browseRecordingRootButton_);
    rootLayout->addWidget(recordingRootEdit_, 1);
    rootLayout->addWidget(browseRecordingRootButton_);
    addFormRow(form, group, tr("Recording root"), rootHost);
    recordingRootSourceLabel_ = new QLabel(group);
    recordingRootSourceLabel_->setWordWrap(true);
    markSettingsValueLabel(recordingRootSourceLabel_);
    addFormRow(form, group, tr("Source"), recordingRootSourceLabel_);
    recordingStorageStatusLabel_ = new QLabel(group);
    recordingStorageStatusLabel_->setWordWrap(true);
    markSettingsHelpLabel(recordingStorageStatusLabel_);
    form->addRow(QString(), recordingStorageStatusLabel_);
    openRecordingRootButton_ = new QPushButton(tr("Open Folder"), group);
    restoreDefaultRootButton_ = new QPushButton(tr("Restore Default"), group);
    styleButton(openRecordingRootButton_);
    styleButton(restoreDefaultRootButton_);
    form->addRow(QString(), horizontalActions(group, QList<QPushButton*>() << openRecordingRootButton_ << restoreDefaultRootButton_));
    connect(recordingRootEdit_, &QLineEdit::textChanged, this, [this]() {
        restoreDefaultRequested_ = false;
        refreshRecordingPreview();
    });
    connect(browseRecordingRootButton_, &QPushButton::clicked, this, &AppSettingsDialog::browseRecordingRoot);
    connect(openRecordingRootButton_, &QPushButton::clicked, this, &AppSettingsDialog::openEffectiveRoot);
    connect(restoreDefaultRootButton_, &QPushButton::clicked, this, &AppSettingsDialog::restoreDefaultRoot);
    layout->addWidget(group);
    layout->addStretch(1);
    return tab;
}

QWidget* AppSettingsDialog::buildDiagnosticsTab() {
    const SettingsTabShell shell = createSettingsTabShell(tr("Camera Logging"));
    diagnosticsGroup_ = shell.group;
    diagnosticsForm_ = shell.form;
    QGroupBox* group = diagnosticsGroup_;
    QFormLayout* form = diagnosticsForm_;

    cameraFileLoggingCheckBox_ = new QCheckBox(tr("Write each camera's Logs dialog messages to a file"), group);
    form->addRow(QString(), cameraFileLoggingCheckBox_);

    QWidget* directoryHost = new QWidget(group);
    QHBoxLayout* directoryLayout = new QHBoxLayout(directoryHost);
    directoryLayout->setContentsMargins(0, 0, 0, 0);
    directoryLayout->setSpacing(8);
    cameraLogDirectoryEdit_ = new QLineEdit(directoryHost);
    styleSettingsLineEdit(cameraLogDirectoryEdit_);
    cameraLogDirectoryEdit_->setPlaceholderText(tr("Camera log folder"));
    browseCameraLogDirectoryButton_ = new QPushButton(tr("Browse..."), directoryHost);
    styleButton(browseCameraLogDirectoryButton_);
    directoryLayout->addWidget(cameraLogDirectoryEdit_, 1);
    directoryLayout->addWidget(browseCameraLogDirectoryButton_);
    addFormRow(form, group, tr("Log folder"), directoryHost);

    cameraLogDirectorySourceLabel_ = new QLabel(group);
    cameraLogDirectorySourceLabel_->setWordWrap(true);
    markSettingsValueLabel(cameraLogDirectorySourceLabel_);
    addFormRow(form, group, tr("Source"), cameraLogDirectorySourceLabel_);

    openCameraLogDirectoryButton_ = new QPushButton(tr("Open Folder"), group);
    restoreDefaultCameraLogDirectoryButton_ = new QPushButton(tr("Restore Default"), group);
    styleButton(openCameraLogDirectoryButton_);
    styleButton(restoreDefaultCameraLogDirectoryButton_);
    form->addRow(QString(),
                 horizontalActions(group, QList<QPushButton*>() << openCameraLogDirectoryButton_ << restoreDefaultCameraLogDirectoryButton_));

    connect(cameraLogDirectoryEdit_, &QLineEdit::textChanged, this, [this]() {
        restoreDefaultCameraLogDirectoryRequested_ = false;
        refreshDiagnosticsPreview();
    });
    connect(browseCameraLogDirectoryButton_, &QPushButton::clicked, this, &AppSettingsDialog::browseCameraLogDirectory);
    connect(openCameraLogDirectoryButton_, &QPushButton::clicked, this, &AppSettingsDialog::openCameraLogDirectory);
    connect(restoreDefaultCameraLogDirectoryButton_, &QPushButton::clicked, this, &AppSettingsDialog::restoreDefaultCameraLogDirectory);

    cameraFileLoggingNoteLabel_ = new QLabel(tr("When disabled, camera messages remain available in each Logs dialog for the current session, but no "
                                                "new log files are written. Existing log files are preserved."),
                                             group);
    cameraFileLoggingNoteLabel_->setWordWrap(true);
    markSettingsHelpLabel(cameraFileLoggingNoteLabel_);
    form->addRow(QString(), cameraFileLoggingNoteLabel_);

    return shell.tab;
}

void AppSettingsDialog::loadSettings() {
    QSettings qsettings;
    settings_.backendBaseUrl = guard::backend::GuardBackendClient::effectiveBaseUrl();
    initialBackendBaseUrl_ = guard::backend::GuardBackendClient::normalizeBaseUrl(settings_.backendBaseUrl);
    settings_.recordingRoot = storageManager_->configuredRecordingRoot();
    settings_.pcHazardAlarmEnabled = qsettings.value(QString::fromLatin1(kHazardAlarmEnabledKey), true).toBool();
    settings_.pcHazardAlarmVolume = qsettings.value(QString::fromLatin1(kHazardAlarmVolumeKey), 80).toInt();
    settings_.repeatHazardAlarmUntilAcknowledged = qsettings.value(QString::fromLatin1(kHazardRepeatKey), true).toBool();
    settings_.cameraFileLoggingEnabled = guard::diagnostics::CameraFileLogger::persistentLoggingEnabled();
    settings_.cameraLogDirectory = guard::diagnostics::CameraFileLogger::configuredDirectoryPath();

    backendUrlEdit_->setText(settings_.backendBaseUrl);
    backendUrlEdit_->setReadOnly(guard::backend::GuardBackendClient::isBaseUrlLockedByEnvironment());
    backendUrlSourceLabel_->setText(guard::backend::GuardBackendClient::baseUrlSourceDescription());
    const bool useDefaultRecordingRoot = settings_.recordingRoot.trimmed().isEmpty();
    const guard::recording::RecordingRootResolution recordingResolution = storageManager_->previewRecordingRoot(settings_.recordingRoot);
    recordingRootEdit_->setText(QDir::toNativeSeparators(recordingResolution.effectiveRoot));
    restoreDefaultRequested_ = useDefaultRecordingRoot;
    pcHazardAlarmCheckBox_->setChecked(settings_.pcHazardAlarmEnabled);
    pcHazardVolumeSlider_->setValue(qBound(0, settings_.pcHazardAlarmVolume, 100));
    repeatUntilAcknowledgedCheckBox_->setChecked(settings_.repeatHazardAlarmUntilAcknowledged);
    cameraFileLoggingCheckBox_->setChecked(settings_.cameraFileLoggingEnabled);

    const QString hardwareId = GuardHardwareId::displayText();
    hardwareIdEdit_->setText(hardwareId);
    const guard::license::GuardLicenseManager::Status licenseStatus = guard::license::GuardLicenseManager::status();
    licenseKeyEdit_->setText(licenseStatus.savedLicenseKey);
    refreshLicenseStatus();

    const bool logDirectoryLocked = guard::diagnostics::CameraFileLogger::isDirectoryLockedByEnvironment();
    const bool useDefaultLogDirectory = settings_.cameraLogDirectory.trimmed().isEmpty();
    const QString displayedLogDirectory =
      logDirectoryLocked ? guard::diagnostics::CameraFileLogger::effectiveDirectoryPath()
                         : (useDefaultLogDirectory ? guard::diagnostics::CameraFileLogger::defaultDirectoryPath() : settings_.cameraLogDirectory);
    cameraLogDirectoryEdit_->setText(QDir::toNativeSeparators(displayedLogDirectory));
    restoreDefaultCameraLogDirectoryRequested_ = useDefaultLogDirectory;
    cameraLogDirectoryEdit_->setReadOnly(logDirectoryLocked);
    browseCameraLogDirectoryButton_->setEnabled(!logDirectoryLocked);
    restoreDefaultCameraLogDirectoryButton_->setEnabled(!logDirectoryLocked);
    refreshDiagnosticsPreview();
}

void AppSettingsDialog::testBackendConnection() {
    if (!backendClient_) {
        backendConnectionLabel_->setText(tr("Backend client unavailable"));
        return;
    }
    const QString candidateUrl = guard::backend::GuardBackendClient::isBaseUrlLockedByEnvironment()
                                   ? guard::backend::GuardBackendClient::environmentBaseUrl()
                                   : backendUrlEdit_->text();
    const QString normalized = guard::backend::GuardBackendClient::normalizeBaseUrl(candidateUrl);
    if (normalized.isEmpty()) {
        backendConnectionLabel_->setText(tr("Enter a valid HTTP or HTTPS backend URL."));
        return;
    }
    testConnectionButton_->setEnabled(false);
    backendConnectionLabel_->setText(tr("Testing..."));
    QPointer<AppSettingsDialog> self(this);
    backendClient_->testConnectionAt(normalized, [self](const guard::backend::GuardApiResponse& response) {
        if (!self)
            return;
        self->testConnectionButton_->setEnabled(true);
        if (!response.ok()) {
            self->backendConnectionLabel_->setText(response.errorMessage);
            return;
        }
        self->backendConnectionLabel_->setText(self->tr("Connected"));
        QString parseError;
        const QJsonObject object = response.jsonObject(&parseError);
        const QString version = object.value(QStringLiteral("version")).toString().trimmed();
        const QString status = object.value(QStringLiteral("status")).toString().trimmed();
        if (!version.isEmpty()) {
            self->backendVersionLabel_->setText(version);
        } else if (object.value(QStringLiteral("ok")).toBool() || status.compare(QStringLiteral("ok"), Qt::CaseInsensitive) == 0) {
            self->backendVersionLabel_->setText(self->tr("Connected; version not reported"));
        } else if (!parseError.isEmpty()) {
            self->backendVersionLabel_->setText(parseError);
        } else {
            self->backendVersionLabel_->setText(self->tr("Connected; version not reported"));
        }
    });
}

void AppSettingsDialog::refreshRecordingPreview() {
    const QString configured = restoreDefaultRequested_ ? QString() : recordingRootEdit_->text().trimmed();
    const guard::recording::RecordingRootResolution resolution = storageManager_->previewRecordingRoot(configured);
    recordingRootSourceLabel_->setText(sourceDescription(resolution.source));
    QStorageInfo storage(resolution.effectiveRoot);
    recordingStorageStatusLabel_->setText(storage.isValid() && storage.isReady()
                                            ? tr("Available space: %1 GB").arg(storage.bytesAvailable() / (1024.0 * 1024.0 * 1024.0), 0, 'f', 1)
                                            : tr("The folder will be validated when settings are saved."));
}

void AppSettingsDialog::browseRecordingRoot() {
    const QString startPath =
      recordingRootEdit_->text().trimmed().isEmpty() ? storageManager_->effectiveRecordingRoot() : recordingRootEdit_->text().trimmed();
    const QString selected = QFileDialog::getExistingDirectory(this, tr("Select Recording Root"), startPath);
    if (!selected.isEmpty())
        recordingRootEdit_->setText(QDir::toNativeSeparators(selected));
}

void AppSettingsDialog::openEffectiveRoot() {
    const guard::recording::RecordingRootResolution resolution =
      storageManager_->previewRecordingRoot(restoreDefaultRequested_ ? QString() : recordingRootEdit_->text().trimmed());
    QDir().mkpath(resolution.effectiveRoot);
    QDesktopServices::openUrl(QUrl::fromLocalFile(resolution.effectiveRoot));
}

void AppSettingsDialog::restoreDefaultRoot() {
    const guard::recording::RecordingRootResolution resolution = storageManager_->previewRecordingRoot(QString());
    recordingRootEdit_->setText(QDir::toNativeSeparators(resolution.effectiveRoot));
    restoreDefaultRequested_ = true;
    refreshRecordingPreview();
}

void AppSettingsDialog::refreshDiagnosticsPreview() {
    if (!cameraLogDirectorySourceLabel_)
        return;

    QString sourceText;
    if (guard::diagnostics::CameraFileLogger::isDirectoryLockedByEnvironment()) {
        sourceText = tr("Environment override active: GUARD_LOG_ROOT");
    } else if (restoreDefaultCameraLogDirectoryRequested_) {
        sourceText = tr("Default application log folder");
    } else {
        sourceText = tr("Application Settings");
    }
    cameraLogDirectorySourceLabel_->setText(sourceText);
}

void AppSettingsDialog::browseCameraLogDirectory() {
    const QString startPath = cameraLogDirectoryEdit_->text().trimmed().isEmpty() ? guard::diagnostics::CameraFileLogger::effectiveDirectoryPath()
                                                                                  : cameraLogDirectoryEdit_->text().trimmed();
    const QString selected = QFileDialog::getExistingDirectory(this, tr("Select Camera Log Folder"), startPath);
    if (!selected.isEmpty()) {
        cameraLogDirectoryEdit_->setText(QDir::toNativeSeparators(selected));
    }
}

void AppSettingsDialog::openCameraLogDirectory() {
    QString directory;
    if (guard::diagnostics::CameraFileLogger::isDirectoryLockedByEnvironment()) {
        directory = guard::diagnostics::CameraFileLogger::effectiveDirectoryPath();
    } else {
        const QString configured = restoreDefaultCameraLogDirectoryRequested_ ? QString() : cameraLogDirectoryEdit_->text().trimmed();
        directory = configured.isEmpty() ? guard::diagnostics::CameraFileLogger::defaultDirectoryPath()
                                         : QDir::cleanPath(QFileInfo(configured).absoluteFilePath());
    }
    if (directory.isEmpty() || !QDir().mkpath(directory) || !QDesktopServices::openUrl(QUrl::fromLocalFile(directory))) {
        GuardMessageDialog::warning(this, tr("Application Settings"), tr("The camera log folder could not be opened."));
    }
}

void AppSettingsDialog::restoreDefaultCameraLogDirectory() {
    cameraLogDirectoryEdit_->setText(QDir::toNativeSeparators(guard::diagnostics::CameraFileLogger::defaultDirectoryPath()));
    restoreDefaultCameraLogDirectoryRequested_ = true;
    refreshDiagnosticsPreview();
}

bool AppSettingsDialog::validateAndSave() {
    if (!guard::backend::GuardBackendClient::isBaseUrlLockedByEnvironment()) {
        QString error;
        const QString normalized = guard::backend::GuardBackendClient::normalizeBaseUrl(backendUrlEdit_->text());
        if (normalized.isEmpty() || !guard::backend::GuardBackendClient::saveBaseUrl(normalized, &error)) {
            GuardMessageDialog::warning(this, tr("Application Settings"), error.isEmpty() ? tr("Enter a valid HTTP or HTTPS backend URL.") : error);
            tabs_->setCurrentIndex(kServerTabIndex);
            return false;
        }
        backendUrlChanged_ = normalized != initialBackendBaseUrl_;
    }

    const QString licenseKey = licenseKeyEdit_->text().trimmed();
    if (!licenseKey.isEmpty()) {
        QString licenseError;
        if (!guard::license::GuardLicenseManager::activateLicenseKey(licenseKey, false, &licenseError)) {
            GuardMessageDialog::warning(this, tr("Application Settings"), licenseError);
            tabs_->setCurrentIndex(kLicenseTabIndex);
            return false;
        }
        licenseKeyEdit_->setText(guard::license::GuardLicenseManager::status().savedLicenseKey);
    } else {
        QString licenseError;
        if (!guard::license::GuardLicenseManager::clearSavedLicense(&licenseError)) {
            GuardMessageDialog::warning(this, tr("Application Settings"), licenseError);
            tabs_->setCurrentIndex(kLicenseTabIndex);
            return false;
        }
    }
    refreshLicenseStatus();

    const QString configuredRoot = restoreDefaultRequested_ ? QString() : recordingRootEdit_->text().trimmed();
    QString storageError;
    if (!storageManager_->setConfiguredRecordingRoot(configuredRoot, &storageError)) {
        GuardMessageDialog::warning(this, tr("Application Settings"), storageError);
        tabs_->setCurrentIndex(kRecordingTabIndex);
        return false;
    }

    if (!guard::diagnostics::CameraFileLogger::isDirectoryLockedByEnvironment()) {
        const QString configuredLogDirectory = restoreDefaultCameraLogDirectoryRequested_ ? QString() : cameraLogDirectoryEdit_->text().trimmed();
        QString logDirectoryError;
        if (!guard::diagnostics::CameraFileLogger::setConfiguredDirectoryPath(configuredLogDirectory, &logDirectoryError)) {
            GuardMessageDialog::warning(this, tr("Application Settings"), logDirectoryError);
            tabs_->setCurrentIndex(kDiagnosticsTabIndex);
            return false;
        }
    }

    settings_.backendBaseUrl = guard::backend::GuardBackendClient::effectiveBaseUrl();
    settings_.recordingRoot = storageManager_->configuredRecordingRoot();
    settings_.cameraLogDirectory = guard::diagnostics::CameraFileLogger::configuredDirectoryPath();
    settings_.pcHazardAlarmEnabled = pcHazardAlarmCheckBox_->isChecked();
    settings_.pcHazardAlarmVolume = pcHazardVolumeSlider_->value();
    settings_.repeatHazardAlarmUntilAcknowledged = repeatUntilAcknowledgedCheckBox_->isChecked();
    settings_.cameraFileLoggingEnabled = cameraFileLoggingCheckBox_->isChecked();
    QSettings target;
    target.setValue(QString::fromLatin1(kHazardAlarmEnabledKey), settings_.pcHazardAlarmEnabled);
    target.setValue(QString::fromLatin1(kHazardAlarmVolumeKey), settings_.pcHazardAlarmVolume);
    target.setValue(QString::fromLatin1(kHazardRepeatKey), settings_.repeatHazardAlarmUntilAcknowledged);
    guard::diagnostics::CameraFileLogger::setPersistentLoggingEnabled(settings_.cameraFileLoggingEnabled);
    return true;
}

void AppSettingsDialog::copyHardwareIdToClipboard() {
    QApplication::clipboard()->setText(hardwareIdEdit_ ? hardwareIdEdit_->text() : QString());
}

void AppSettingsDialog::activateLicenseFromSettings() {
    QString licenseError;
    if (!guard::license::GuardLicenseManager::activateLicenseKey(licenseKeyEdit_->text(), false, &licenseError)) {
        GuardMessageDialog::warning(this, tr("Application Settings"), licenseError);
        tabs_->setCurrentIndex(kLicenseTabIndex);
        return;
    }
    const guard::license::GuardLicenseManager::Status licenseStatus = guard::license::GuardLicenseManager::status();
    licenseKeyEdit_->setText(licenseStatus.savedLicenseKey);
    refreshLicenseStatus();
    GuardMessageDialog::information(this, tr("Application Settings"), tr("The Guard license key was activated."));
}

void AppSettingsDialog::refreshLicenseStatus() {
    if (!licenseStatusLabel_)
        return;
    const guard::license::GuardLicenseManager::Status status = guard::license::GuardLicenseManager::status();
    QString text = guard::license::GuardLicenseManager::stateDisplayText(status.state);
    if (status.state == guard::license::GuardLicenseManager::State::TemporaryValid) {
        text += tr(" — %1 day(s) remaining").arg(status.daysRemaining);
        if (status.expiresAtUtc.isValid())
            text += tr("; expires %1 UTC").arg(status.expiresAtUtc.toUTC().toString(Qt::ISODate));
    }
    if (!status.message.isEmpty())
        text += QStringLiteral("\n") + status.message;
    licenseStatusLabel_->setText(text);
}

void AppSettingsDialog::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        retranslateUi();
    QDialog::changeEvent(event);
}

void AppSettingsDialog::updateFormFieldLabel(QFormLayout* form, QWidget* field, const QString& text) {
    if (!form || !field)
        return;
    if (QLabel* label = qobject_cast<QLabel*>(form->labelForField(field)))
        label->setText(text);
}

void AppSettingsDialog::retranslateUi() {
    if (titleBar_)
        titleBar_->setTitle(tr("Application Settings"));
    if (tabs_) {
        if (serverGroup_)
            tabs_->setTabText(tabs_->indexOf(serverGroup_->parentWidget()), tr("Server"));
        if (kLicenseTabIndex < tabs_->count())
            tabs_->setTabText(kLicenseTabIndex, tr("License"));
        if (kAlertsTabIndex < tabs_->count())
            tabs_->setTabText(kAlertsTabIndex, tr("Alerts"));
        if (kRecordingTabIndex < tabs_->count())
            tabs_->setTabText(kRecordingTabIndex, tr("Recording"));
        if (kDiagnosticsTabIndex < tabs_->count())
            tabs_->setTabText(kDiagnosticsTabIndex, tr("Diagnostics"));
    }
    if (serverGroup_)
        serverGroup_->setTitle(tr("Backend Server"));
    if (licenseGroup_)
        licenseGroup_->setTitle(tr("License Information"));
    if (diagnosticsGroup_)
        diagnosticsGroup_->setTitle(tr("Camera Logging"));
    if (serverForm_) {
        updateFormFieldLabel(serverForm_, backendUrlEdit_, tr("Base URL"));
        updateFormFieldLabel(serverForm_, backendUrlSourceLabel_, tr("Source"));
        updateFormFieldLabel(serverForm_, backendConnectionLabel_, tr("Connection"));
        updateFormFieldLabel(serverForm_, backendVersionLabel_, tr("Backend version"));
    }
    if (testConnectionButton_)
        testConnectionButton_->setText(tr("Test Connection"));
    if (licenseForm_) {
        updateFormFieldLabel(licenseForm_, licenseStatusLabel_, tr("Status"));
        updateFormFieldLabel(licenseForm_, hardwareIdEdit_ ? hardwareIdEdit_->parentWidget() : nullptr, tr("Hardware ID"));
        updateFormFieldLabel(licenseForm_, licenseKeyEdit_, tr("License key"));
    }
    if (hardwareIdEdit_)
        hardwareIdEdit_->setPlaceholderText(tr("Hardware ID unavailable"));
    if (copyHardwareIdButton_)
        copyHardwareIdButton_->setText(tr("Copy"));
    if (activateLicenseButton_)
        activateLicenseButton_->setText(tr("Activate License"));
    if (licenseNoteLabel_)
        licenseNoteLabel_->setText(
          tr("Copy the Guard hardware ID into LicenseGenerator. Non-activated LicenseGenerator output creates a 7-day Guard license. Activated "
             "LicenseGenerator output creates a permanent Guard license."));
    refreshLicenseStatus();
    if (localHazardGroup_)
        localHazardGroup_->setTitle(tr("Local Hazard Alarm"));
    if (pcHazardAlarmCheckBox_)
        pcHazardAlarmCheckBox_->setText(tr("Play an alarm on this computer"));
    if (alertsForm_ && pcHazardVolumeSlider_)
        updateFormFieldLabel(alertsForm_, pcHazardVolumeSlider_->parentWidget(), tr("Volume"));
    if (repeatUntilAcknowledgedCheckBox_)
        repeatUntilAcknowledgedCheckBox_->setText(tr("Repeat until acknowledged"));
    if (testAlarmButton_)
        testAlarmButton_->setText(tr("Test Alarm"));
    if (accessWarningsGroup_)
        accessWarningsGroup_->setTitle(tr("Backend-Controlled Access Warnings"));
    if (accessWarningsForm_) {
        updateFormFieldLabel(accessWarningsForm_, unknownIncomingPolicyLabel_, tr("Unknown incoming"));
        updateFormFieldLabel(accessWarningsForm_, unapprovedIncomingPolicyLabel_, tr("Unapproved incoming"));
    }
    if (accessWarningsNoteLabel_) {
        accessWarningsNoteLabel_->setText(tr("These policies are configured by an administrator. Disabling a warning never disables event upload."));
    }
    if (notificationPoliciesSet_) {
        setNotificationPolicies(notifyUnknownIncoming_, notifyUnapprovedIncoming_);
    } else {
        if (unknownIncomingPolicyLabel_)
            unknownIncomingPolicyLabel_->setText(tr("Loaded after backend authentication"));
        if (unapprovedIncomingPolicyLabel_)
            unapprovedIncomingPolicyLabel_->setText(tr("Loaded after backend authentication"));
    }
    if (recordingGroup_)
        recordingGroup_->setTitle(tr("Recording Storage"));
    if (recordingForm_) {
        updateFormFieldLabel(recordingForm_, recordingRootEdit_ ? recordingRootEdit_->parentWidget() : nullptr, tr("Recording root"));
        updateFormFieldLabel(recordingForm_, recordingRootSourceLabel_, tr("Source"));
    }
    if (recordingRootEdit_)
        recordingRootEdit_->setPlaceholderText(tr("Leave empty to use the default recording location"));
    if (browseRecordingRootButton_)
        browseRecordingRootButton_->setText(tr("Browse..."));
    if (openRecordingRootButton_)
        openRecordingRootButton_->setText(tr("Open Folder"));
    if (restoreDefaultRootButton_)
        restoreDefaultRootButton_->setText(tr("Restore Default"));
    if (cameraFileLoggingCheckBox_)
        cameraFileLoggingCheckBox_->setText(tr("Write each camera's Logs dialog messages to a file"));
    if (diagnosticsForm_) {
        updateFormFieldLabel(diagnosticsForm_, cameraLogDirectoryEdit_->parentWidget(), tr("Log folder"));
        updateFormFieldLabel(diagnosticsForm_, cameraLogDirectorySourceLabel_, tr("Source"));
    }
    if (cameraLogDirectoryEdit_)
        cameraLogDirectoryEdit_->setPlaceholderText(tr("Camera log folder"));
    if (browseCameraLogDirectoryButton_)
        browseCameraLogDirectoryButton_->setText(tr("Browse..."));
    if (openCameraLogDirectoryButton_)
        openCameraLogDirectoryButton_->setText(tr("Open Folder"));
    if (restoreDefaultCameraLogDirectoryButton_)
        restoreDefaultCameraLogDirectoryButton_->setText(tr("Restore Default"));
    if (cameraFileLoggingNoteLabel_) {
        cameraFileLoggingNoteLabel_->setText(
          tr("When disabled, camera messages remain available in each Logs dialog for the current session, but no new log files are written. "
             "Existing log files are preserved."));
    }
    if (cancelButton_)
        cancelButton_->setText(tr("Cancel"));
    if (saveButton_)
        saveButton_->setText(tr("Save"));
    refreshRecordingPreview();
    refreshDiagnosticsPreview();
}

void AppSettingsDialog::showEvent(QShowEvent* event) {
    QDialog::showEvent(event);
    backendUrlSourceLabel_->setText(guard::backend::GuardBackendClient::baseUrlSourceDescription());
    refreshRecordingPreview();
    refreshDiagnosticsPreview();
    updateDialogFrameMask();
}

void AppSettingsDialog::resizeEvent(QResizeEvent* event) {
    QDialog::resizeEvent(event);
    updateDialogFrameMask();
}

void AppSettingsDialog::updateDialogFrameMask() {
    if (!dialogFrame_)
        return;
    QPainterPath path;
    path.addRoundedRect(QRectF(dialogFrame_->rect()).adjusted(0.5, 0.5, -0.5, -0.5), kDialogCornerRadius, kDialogCornerRadius);
    dialogFrame_->setMask(QRegion(path.toFillPolygon().toPolygon()));
}
