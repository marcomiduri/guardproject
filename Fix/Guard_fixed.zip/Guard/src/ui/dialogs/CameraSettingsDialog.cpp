#include "CameraSettingsDialog.h"

#include "DetectionModeCombo.h"
#include "GuardComboBox.h"
#include "GuardTheme.h"
#include "GuardMessageDialog.h"
#include "WindowTitleBar.h"

#include <QAbstractItemView>
#include <QCheckBox>
#include <QColor>
#include <QDialogButtonBox>
#include <QEvent>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGraphicsDropShadowEffect>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPainterPath>
#include <QPushButton>
#include <QResizeEvent>
#include <QShowEvent>
#include <QStringList>
#include <QRegion>
#include <QVBoxLayout>

namespace {
constexpr int kDialogCornerRadius = 4;

bool hasImageExtension(const QString& path) {
    const QString suffix = QFileInfo(path).suffix().toLower();
    return suffix == QStringLiteral("jpg") || suffix == QStringLiteral("jpeg") || suffix == QStringLiteral("png") || suffix == QStringLiteral("bmp");
}

bool hasVideoExtension(const QString& path) {
    const QString suffix = QFileInfo(path).suffix().toLower();
    return suffix == QStringLiteral("mp4") || suffix == QStringLiteral("avi") || suffix == QStringLiteral("mov") || suffix == QStringLiteral("mkv");
}

CameraTestSourceType testSourceTypeForPath(const QString& path) {
    if (path.trimmed().isEmpty()) {
        return CameraTestSourceType::ConfiguredCamera;
    }
    if (hasImageExtension(path)) {
        return CameraTestSourceType::ImageFile;
    }
    if (hasVideoExtension(path)) {
        return CameraTestSourceType::VideoFile;
    }
    return CameraTestSourceType::ConfiguredCamera;
}

}  // namespace

CameraSettingsDialog::CameraSettingsDialog(QWidget* parent) : QDialog(parent) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setWindowModality(Qt::WindowModal);
    setAttribute(Qt::WA_TranslucentBackground);
    setObjectName(QStringLiteral("CameraSettingsDialog"));
    buildUi();
}

void CameraSettingsDialog::buildUi() {
    auto* outerLayout = new QVBoxLayout(this);
    outerLayout->setContentsMargins(20, 20, 20, 20);
    outerLayout->setSpacing(0);

    auto* shadowHost = new QWidget(this);
    shadowHost->setAttribute(Qt::WA_TranslucentBackground);
    auto* shadowLayout = new QVBoxLayout(shadowHost);
    shadowLayout->setContentsMargins(0, 0, 0, 0);
    shadowLayout->setSpacing(0);

    dialogFrame_ = new QWidget(shadowHost);
    dialogFrame_->setObjectName(QStringLiteral("dialogFrame"));
    dialogFrame_->setAttribute(Qt::WA_StyledBackground, true);
    auto* frameLayout = new QVBoxLayout(dialogFrame_);
    frameLayout->setContentsMargins(0, 0, 0, 0);
    frameLayout->setSpacing(0);

    titleBar_ = new WindowTitleBar(dialogFrame_, WindowTitleBar::Style::Dialog);
    titleBar_->setObjectName(QStringLiteral("titleBar"));
    titleBar_->setTitle(tr("Camera Settings"));
    frameLayout->addWidget(titleBar_, 0, Qt::AlignTop);

    auto* content = new QWidget(dialogFrame_);
    content->setObjectName(QStringLiteral("dialogContent"));
    auto* contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(24, 20, 24, 16);
    contentLayout->setSpacing(14);

    cameraNameLabel_ = new QLabel(content);
    cameraNameLabel_->setObjectName(QStringLiteral("settingsCameraName"));
    cameraNameLabel_->setWordWrap(true);
    contentLayout->addWidget(cameraNameLabel_);

    detectionGroup_ = new QGroupBox(content);
    detectionGroup_->setObjectName(QStringLiteral("detectionGroup"));
    detectionForm_ = new QFormLayout(detectionGroup_);
    detectionForm_->setContentsMargins(16, 18, 16, 16);
    detectionForm_->setHorizontalSpacing(18);
    detectionForm_->setVerticalSpacing(12);
    detectionForm_->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    motionCombo_ = new GuardComboBox(detectionGroup_);
    faceCombo_ = new GuardComboBox(detectionGroup_);
    hazardCombo_ = new GuardComboBox(detectionGroup_);
    DetectionModeCombo::populate(motionCombo_);
    DetectionModeCombo::populate(faceCombo_);
    DetectionModeCombo::populate(hazardCombo_);
    styleComboBox(motionCombo_);
    styleComboBox(faceCombo_);
    styleComboBox(hazardCombo_);

    detectionForm_->addRow(tr("Motion detection"), motionCombo_);
    detectionForm_->addRow(tr("Face detection"), faceCombo_);
    detectionForm_->addRow(tr("Hazard detection"), hazardCombo_);

    recordCheckBox_ = new QCheckBox(detectionGroup_);
    recordCheckBox_->setObjectName(QStringLiteral("recordVideoForMotionCheckBox"));
    detectionForm_->addRow(QString(), recordCheckBox_);

    contentLayout->addWidget(detectionGroup_);

    testSourceGroup_ = new QGroupBox(content);
    testSourceGroup_->setObjectName(QStringLiteral("testSourceGroup"));
    testSourceForm_ = new QFormLayout(testSourceGroup_);
    testSourceForm_->setContentsMargins(16, 18, 16, 16);
    testSourceForm_->setHorizontalSpacing(18);
    testSourceForm_->setVerticalSpacing(12);
    testSourceForm_->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    auto* pathHost = new QWidget(testSourceGroup_);
    auto* pathLayout = new QHBoxLayout(pathHost);
    pathLayout->setContentsMargins(0, 0, 0, 0);
    pathLayout->setSpacing(8);

    testFilePathEdit_ = new QLineEdit(pathHost);
    testFilePathEdit_->setObjectName(QStringLiteral("testFilePathEdit"));
    pathLayout->addWidget(testFilePathEdit_, 1);

    testBrowseButton_ = new QPushButton(pathHost);
    testBrowseButton_->setObjectName(QStringLiteral("testBrowseButton"));
    testBrowseButton_->setAutoDefault(false);
    testBrowseButton_->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
    pathLayout->addWidget(testBrowseButton_);

    testSourceForm_->addRow(tr("Media file"), pathHost);

    testSourceHelpLabel_ = new QLabel(testSourceGroup_);
    testSourceHelpLabel_->setObjectName(QStringLiteral("testSourceHelpLabel"));
    testSourceHelpLabel_->setWordWrap(true);
    testSourceForm_->addRow(QString(), testSourceHelpLabel_);

    testSourceGroup_->setVisible(false);
    contentLayout->addWidget(testSourceGroup_);

    availabilityLabel_ = new QLabel(content);
    availabilityLabel_->setObjectName(QStringLiteral("detectionAvailabilityLabel"));
    availabilityLabel_->setWordWrap(true);
    contentLayout->addWidget(availabilityLabel_);
    contentLayout->addStretch(1);

    frameLayout->addWidget(content, 1);

    auto* footer = new QWidget(dialogFrame_);
    footer->setObjectName(QStringLiteral("dialogFooter"));
    footer->setAttribute(Qt::WA_StyledBackground, true);
    auto* footerLayout = new QVBoxLayout(footer);
    footerLayout->setContentsMargins(16, 14, 16, 20);

    buttonBox_ = new QDialogButtonBox(QDialogButtonBox::Cancel | QDialogButtonBox::Ok, footer);
    buttonBox_->setCenterButtons(false);
    if (QPushButton* cancelButton = buttonBox_->button(QDialogButtonBox::Cancel)) {
        cancelButton->setAutoDefault(false);
        cancelButton->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
    }
    if (QPushButton* okButton = buttonBox_->button(QDialogButtonBox::Ok)) {
        okButton->setDefault(true);
        okButton->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
    }
    footerLayout->addWidget(buttonBox_);
    frameLayout->addWidget(footer);

    shadowLayout->addWidget(dialogFrame_);
    outerLayout->addWidget(shadowHost);

    auto* shadow = new QGraphicsDropShadowEffect(shadowHost);
    shadow->setBlurRadius(48);
    shadow->setOffset(0, 16);
    shadow->setColor(QColor(2, 6, 23, 140));
    shadowHost->setGraphicsEffect(shadow);

    setStyleSheet(GuardTheme::cameraDialogStyleSheet() +
                  QStringLiteral("QGroupBox#detectionGroup, QGroupBox#testSourceGroup { border: 1px solid #243552; border-radius: 6px; margin-top: "
                                 "9px; padding-top: 8px; color: #f1f5f9; }"
                                 "QGroupBox#detectionGroup::title, QGroupBox#testSourceGroup::title { subcontrol-origin: margin; left: 12px; "
                                 "padding: 0 6px; color: #d5dce6; font-weight: 600; }"
                                 "QLabel#settingsCameraName { color: #d5dce6; font-size: 13px; font-weight: 600; }"
                                 "QLabel#detectionAvailabilityLabel, QLabel#testSourceHelpLabel { color: #94a3b8; font-size: 12px; }"
                                 "QCheckBox { color: #f1f5f9; spacing: 8px; }"));
    setMinimumSize(520, 390);

    connect(testFilePathEdit_, &QLineEdit::textChanged, this, [this](const QString&) { updateTestSourceUi(); });
    connect(testBrowseButton_, &QPushButton::clicked, this, &CameraSettingsDialog::browseForTestMedia);
    connect(buttonBox_, &QDialogButtonBox::rejected, this, &QDialog::reject);
    connect(buttonBox_, &QDialogButtonBox::accepted, this, [this]() {
        if (validateAndStore()) {
            accept();
        }
    });

    retranslateUi();
    updateTestSourceUi();
}

void CameraSettingsDialog::styleComboBox(GuardComboBox* comboBox) {
    if (!comboBox) {
        return;
    }
    comboBox->setMinimumWidth(240);
    comboBox->setStyleSheet(GuardTheme::cameraDialogComboBoxStyleSheet());
    if (QAbstractItemView* view = comboBox->view()) {
        view->setStyleSheet(GuardTheme::cameraDialogComboBoxPopupStyleSheet());
        if (QWidget* popupFrame = view->window()) {
            popupFrame->setStyleSheet(GuardTheme::cameraDialogComboBoxPopupFrameStyleSheet());
        }
    }
}

void CameraSettingsDialog::setCameraName(const QString& cameraName) {
    cameraName_ = cameraName;
    if (cameraNameLabel_)
        cameraNameLabel_->setText(tr("Camera: %1").arg(cameraName_));
}

void CameraSettingsDialog::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        retranslateUi();
    QDialog::changeEvent(event);
}

void CameraSettingsDialog::retranslateUi() {
    if (titleBar_)
        titleBar_->setTitle(tr("Camera Settings"));
    if (cameraNameLabel_ && !cameraName_.isEmpty())
        cameraNameLabel_->setText(tr("Camera: %1").arg(cameraName_));
    if (detectionGroup_)
        detectionGroup_->setTitle(tr("Detection"));
    if (detectionForm_) {
        if (QLabel* label = qobject_cast<QLabel*>(detectionForm_->labelForField(motionCombo_)))
            label->setText(tr("Motion detection"));
        if (QLabel* label = qobject_cast<QLabel*>(detectionForm_->labelForField(faceCombo_)))
            label->setText(tr("Face detection"));
        if (QLabel* label = qobject_cast<QLabel*>(detectionForm_->labelForField(hazardCombo_)))
            label->setText(tr("Hazard detection"));
    }
    if (recordCheckBox_)
        recordCheckBox_->setText(tr("Record Video for Motion"));
    if (testSourceGroup_)
        testSourceGroup_->setTitle(tr("Test Source"));
    if (testSourceForm_ && testFilePathEdit_) {
        if (QLabel* label = qobject_cast<QLabel*>(testSourceForm_->labelForField(testFilePathEdit_->parentWidget())))
            label->setText(tr("Media file"));
    }
    if (testFilePathEdit_)
        testFilePathEdit_->setPlaceholderText(tr("Leave empty for configured camera, or select an image/video file"));
    if (testBrowseButton_)
        testBrowseButton_->setText(tr("Browse..."));
    if (buttonBox_) {
        if (QPushButton* cancelButton = buttonBox_->button(QDialogButtonBox::Cancel))
            cancelButton->setText(tr("Cancel"));
        if (QPushButton* okButton = buttonBox_->button(QDialogButtonBox::Ok))
            okButton->setText(tr("OK"));
    }

    const auto motionMode = DetectionModeCombo::currentMode(motionCombo_);
    const auto faceMode = DetectionModeCombo::currentMode(faceCombo_);
    const auto hazardMode = DetectionModeCombo::currentMode(hazardCombo_);
    DetectionModeCombo::populate(motionCombo_);
    DetectionModeCombo::populate(faceCombo_);
    DetectionModeCombo::populate(hazardCombo_);
    DetectionModeCombo::setMode(motionCombo_, motionMode);
    DetectionModeCombo::setMode(faceCombo_, faceMode);
    DetectionModeCombo::setMode(hazardCombo_, hazardMode);
    updateTestSourceUi();
    refreshDetectionAvailability();
}

void CameraSettingsDialog::setSettings(const CameraDetectionSettings& settings) {
    settings_ = settings;
    DetectionModeCombo::setMode(motionCombo_, settings.motion.detectionMode);
    DetectionModeCombo::setMode(faceCombo_, settings.face.detectionMode);
    DetectionModeCombo::setMode(hazardCombo_, settings.hazard.detectionMode);
    recordCheckBox_->setChecked(settings.recordVideoForMotion);
}

CameraDetectionSettings CameraSettingsDialog::settings() const {
    return settings_;
}

void CameraSettingsDialog::setTestMode(bool enabled) {
    testMode_ = enabled;
    if (testSourceGroup_) {
        testSourceGroup_->setVisible(testMode_);
    }
    setMinimumSize(520, testMode_ ? 560 : 390);
    updateTestSourceUi();
}

bool CameraSettingsDialog::testMode() const {
    return testMode_;
}

void CameraSettingsDialog::setTestSourceSettings(const CameraTestSourceSettings& settings) {
    testSourceSettings_ = settings;
    testFilePathEdit_->setText(settings.filePath);
    updateTestSourceUi();
}

CameraTestSourceSettings CameraSettingsDialog::testSourceSettings() const {
    return testSourceSettings_;
}

void CameraSettingsDialog::setDetectionAvailability(bool cameraConnected, bool hcNetSdkSource, const guard::CameraOnboardCapabilities& capabilities,
                                                    bool hazardModelAvailable) {
    cameraConnected_ = cameraConnected;
    hcNetSdkSource_ = hcNetSdkSource;
    capabilities_ = capabilities;
    hazardModelAvailable_ = hazardModelAvailable;
    refreshDetectionAvailability();
}

void CameraSettingsDialog::updateTestSourceUi() {
    if (!testFilePathEdit_ || !testBrowseButton_) {
        return;
    }

    testFilePathEdit_->setEnabled(testMode_);
    testBrowseButton_->setEnabled(testMode_);

    const QString path = testFilePathEdit_->text().trimmed();
    const CameraTestSourceType type = testSourceTypeForPath(path);
    testFilePathEdit_->setPlaceholderText(tr("Leave empty for configured camera, or select an image/video file"));
    testBrowseButton_->setText(tr("Browse..."));
    if (testSourceHelpLabel_) {
        if (path.isEmpty()) {
            testSourceHelpLabel_->setText(tr("No test file selected. This camera will use its configured camera source."));
        } else if (type == CameraTestSourceType::ImageFile) {
            testSourceHelpLabel_->setText(tr("Image mode selected. The image will repeat continuously for this camera."));
        } else if (type == CameraTestSourceType::VideoFile) {
            testSourceHelpLabel_->setText(tr("Video mode selected. The video will loop through the TestLib-style decoder pipeline."));
        } else {
            testSourceHelpLabel_->setText(tr("Unsupported test file type. Select JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV."));
        }
    }

    refreshDetectionAvailability();
}

void CameraSettingsDialog::refreshDetectionAvailability() {
    const bool fileTestSource = testMode_ && testFilePathEdit_ && !testFilePathEdit_->text().trimmed().isEmpty();

    const bool subscribed = !fileTestSource && cameraConnected_ && hcNetSdkSource_ && capabilities_.alarmSubscriptionActive;
    const bool motionOnboard = subscribed && capabilities_.motion.state != guard::CameraCapabilityState::Unsupported;
    const bool faceOnboard = subscribed && capabilities_.face.state != guard::CameraCapabilityState::Unsupported;
    const bool hazardOnboard = subscribed && (capabilities_.fire.state != guard::CameraCapabilityState::Unsupported ||
                                              capabilities_.smoke.state != guard::CameraCapabilityState::Unsupported);

    const QString normalReason = tr("Onboard detection becomes available after an HCNetSDK camera connects and its alarm channel is subscribed.");
    const QString testReason =
      tr("Image and video test files support software detection only. Onboard and hybrid modes are unavailable for file sources.");
    const QString reason = fileTestSource ? testReason : normalReason;

    DetectionModeCombo::setOnboardAvailability(motionCombo_, motionOnboard, motionOnboard ? QString() : reason);
    DetectionModeCombo::setOnboardAvailability(faceCombo_, faceOnboard, faceOnboard ? QString() : reason);
    DetectionModeCombo::setOnboardAvailability(hazardCombo_, hazardOnboard, hazardOnboard ? QString() : reason);

    QStringList messages;
    if (fileTestSource) {
        messages << testReason;
    } else {
        messages << (subscribed ? tr("Onboard alarm route is active.") : normalReason);
    }
    if (!hazardModelAvailable_) {
        messages << tr("Software and hybrid hazard detection require models/fire_smoke.onnx beside Guard.exe.");
    }
    availabilityLabel_->setText(messages.join(QStringLiteral(" ")));
}

void CameraSettingsDialog::browseForTestMedia() {
    const QString initialDirectory = testFilePathEdit_->text().trimmed();
    const QString path = QFileDialog::getOpenFileName(this, tr("Select Test Media"), initialDirectory,
                                                      tr("Supported Media (*.jpg *.jpeg *.png *.bmp *.mp4 *.avi *.mov *.mkv);;Images (*.jpg *.jpeg "
                                                         "*.png *.bmp);;Videos (*.mp4 *.avi *.mov *.mkv);;All Files (*.*)"));
    if (!path.isEmpty()) {
        testFilePathEdit_->setText(path);
    }
}

bool CameraSettingsDialog::validateAndStore() {
    CameraDetectionSettings candidate = settings_;

    candidate.motion.detectionMode = DetectionModeCombo::currentMode(motionCombo_);
    candidate.motion.enabled = candidate.motion.detectionMode != guardvision::DetectionMode::Disabled;

    candidate.face.detectionMode = DetectionModeCombo::currentMode(faceCombo_);
    if (candidate.face.detectionMode == guardvision::DetectionMode::Disabled) {
        candidate.face.processingLevel = guardvision::FaceProcessingLevel::Disabled;
    } else {
        normalizeEnabledFaceProcessing(candidate.face);
    }

    candidate.hazard.detectionMode = DetectionModeCombo::currentMode(hazardCombo_);
    if (candidate.hazard.detectionMode == guardvision::DetectionMode::Disabled) {
        candidate.hazard.processingLevel = guardvision::HazardProcessingLevel::Disabled;
    } else {
        if (!hazardModelAvailable_) {
            GuardMessageDialog::warning(this, tr("Guard"),
                                        tr("Hazard model not found. Copy models/fire_smoke.onnx beside Guard.exe before enabling hazard detection."));
            DetectionModeCombo::setMode(hazardCombo_, guardvision::DetectionMode::Disabled);
            return false;
        }
        candidate.hazard.processingLevel = guardvision::HazardProcessingLevel::Detect;
    }

    candidate.recordVideoForMotion = recordCheckBox_->isChecked();

    CameraTestSourceSettings testCandidate = testSourceSettings_;
    if (testMode_) {
        testCandidate.filePath = testFilePathEdit_->text().trimmed();
        if (testCandidate.filePath.isEmpty()) {
            testCandidate.type = CameraTestSourceType::ConfiguredCamera;
            testCandidate.filePath.clear();
        } else {
            const QFileInfo fileInfo(testCandidate.filePath);
            if (!fileInfo.exists() || !fileInfo.isFile()) {
                GuardMessageDialog::warning(this, tr("Guard"), tr("Select an existing test media file for this camera."));
                testFilePathEdit_->setFocus();
                return false;
            }

            testCandidate.type = testSourceTypeForPath(testCandidate.filePath);
            if (testCandidate.type == CameraTestSourceType::ConfiguredCamera) {
                GuardMessageDialog::warning(this, tr("Guard"),
                                            tr("The selected test source must be a JPG, JPEG, PNG, BMP, MP4, AVI, MOV, or MKV file."));
                testFilePathEdit_->setFocus();
                return false;
            }
        }
    } else {
        testCandidate = CameraTestSourceSettings{};
    }

    settings_ = candidate;
    testSourceSettings_ = testCandidate;
    return true;
}

void CameraSettingsDialog::showEvent(QShowEvent* event) {
    QDialog::showEvent(event);
    updateDialogFrameMask();
}

void CameraSettingsDialog::resizeEvent(QResizeEvent* event) {
    QDialog::resizeEvent(event);
    updateDialogFrameMask();
}

void CameraSettingsDialog::updateDialogFrameMask() {
    if (!dialogFrame_) {
        return;
    }
    QPainterPath path;
    path.addRoundedRect(QRectF(dialogFrame_->rect()).adjusted(0.5, 0.5, -0.5, -0.5), kDialogCornerRadius, kDialogCornerRadius);
    dialogFrame_->setMask(QRegion(path.toFillPolygon().toPolygon()));
}
