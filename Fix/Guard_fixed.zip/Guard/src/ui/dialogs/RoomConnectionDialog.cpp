#include "RoomConnectionDialog.h"

#include "GuardTheme.h"
#include "GuardMessageDialog.h"
#include "WindowTitleBar.h"

#include <QColor>
#include <QCoreApplication>
#include <QEvent>
#include <QGraphicsDropShadowEffect>
#include <QHBoxLayout>
#include <QItemSelectionModel>
#include <QJsonObject>
#include <QKeyEvent>
#include <QLabel>
#include <QLineEdit>
#include <QListView>
#include <QPainterPath>
#include <QPushButton>
#include <QRegion>
#include <QResizeEvent>
#include <QShowEvent>
#include <QSortFilterProxyModel>
#include <QStandardItemModel>
#include <QSysInfo>
#include <QVBoxLayout>

namespace {
constexpr int kCornerRadius = 4;
constexpr int kRoomIdRole = Qt::UserRole + 1;
}  // namespace

RoomConnectionDialog::RoomConnectionDialog(guard::backend::GuardBackendClient* client, guard::backend::GuardSessionManager* sessionManager,
                                           const QVector<CameraUiModel>& cameras, QWidget* parent)
: QDialog(parent), client_(client), sessionManager_(sessionManager), cameras_(cameras) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setWindowModality(Qt::WindowModal);
    setAttribute(Qt::WA_TranslucentBackground);
    setObjectName(QStringLiteral("RoomConnectionDialog"));
    buildUi();
    if (sessionManager_ && sessionManager_->isRegistered())
        setViewMode(ViewMode::Connected);
}

void RoomConnectionDialog::buildUi() {
    QVBoxLayout* outer = new QVBoxLayout(this);
    outer->setContentsMargins(20, 20, 20, 20);
    outer->setSpacing(0);

    QWidget* shadowHost = new QWidget(this);
    shadowHost->setAttribute(Qt::WA_TranslucentBackground);
    QVBoxLayout* shadowLayout = new QVBoxLayout(shadowHost);
    shadowLayout->setContentsMargins(0, 0, 0, 0);
    shadowLayout->setSpacing(0);

    dialogFrame_ = new QWidget(shadowHost);
    dialogFrame_->setObjectName(QStringLiteral("dialogFrame"));
    dialogFrame_->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* layout = new QVBoxLayout(dialogFrame_);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    titleBar_ = new WindowTitleBar(dialogFrame_, WindowTitleBar::Style::Dialog);
    titleBar_->setObjectName(QStringLiteral("titleBar"));
    titleBar_->setTitle(tr("Room Connection"));
    layout->addWidget(titleBar_, 0, Qt::AlignTop);

    QWidget* content = new QWidget(dialogFrame_);
    content->setObjectName(QStringLiteral("dialogContent"));
    content->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(24, 20, 24, 16);
    contentLayout->setSpacing(14);

    searchEdit_ = new QLineEdit(content);
    searchEdit_->setPlaceholderText(tr("Search rooms..."));
    searchEdit_->setClearButtonEnabled(true);
    contentLayout->addWidget(searchEdit_);

    roomModel_ = new QStandardItemModel(this);
    roomProxyModel_ = new QSortFilterProxyModel(this);
    roomProxyModel_->setSourceModel(roomModel_);
    roomProxyModel_->setFilterCaseSensitivity(Qt::CaseInsensitive);
    roomProxyModel_->setFilterRole(Qt::DisplayRole);

    roomListView_ = new QListView(content);
    roomListView_->setObjectName(QStringLiteral("roomListView"));
    roomListView_->setModel(roomProxyModel_);
    roomListView_->setSelectionMode(QAbstractItemView::SingleSelection);
    roomListView_->setEditTriggers(QAbstractItemView::NoEditTriggers);
    roomListView_->setMinimumHeight(220);
    contentLayout->addWidget(roomListView_, 1);

    connectedInfoLabel_ = new QLabel(content);
    connectedInfoLabel_->setWordWrap(true);
    connectedInfoLabel_->hide();
    contentLayout->addWidget(connectedInfoLabel_);

    statusLabel_ = new QLabel(content);
    statusLabel_->setObjectName(QStringLiteral("roomConnectionStatusLabel"));
    statusLabel_->setWordWrap(true);
    contentLayout->addWidget(statusLabel_);

    layout->addWidget(content, 1);

    QWidget* footer = new QWidget(dialogFrame_);
    footer->setObjectName(QStringLiteral("dialogFooter"));
    footer->setAttribute(Qt::WA_StyledBackground, true);
    QHBoxLayout* footerLayout = new QHBoxLayout(footer);
    footerLayout->setContentsMargins(16, 14, 16, 20);
    refreshButton_ = new QPushButton(tr("Refresh"), footer);
    footerLayout->addWidget(refreshButton_);
    footerLayout->addStretch(1);
    cancelButton_ = new QPushButton(tr("Cancel"), footer);
    connectButton_ = new QPushButton(tr("Connect"), footer);
    disconnectButton_ = new QPushButton(tr("Disconnect Room"), footer);
    reconnectButton_ = new QPushButton(tr("Reconnect"), footer);
    closeButton_ = new QPushButton(tr("Close"), footer);
    connectButton_->setDefault(true);
    footerLayout->addWidget(cancelButton_);
    footerLayout->addWidget(connectButton_);
    footerLayout->addWidget(disconnectButton_);
    footerLayout->addWidget(reconnectButton_);
    footerLayout->addWidget(closeButton_);
    layout->addWidget(footer);

    shadowLayout->addWidget(dialogFrame_);
    outer->addWidget(shadowHost);

    auto* shadow = new QGraphicsDropShadowEffect(shadowHost);
    shadow->setBlurRadius(48);
    shadow->setOffset(0, 16);
    shadow->setColor(QColor(2, 6, 23, 140));
    shadowHost->setGraphicsEffect(shadow);

    setStyleSheet(GuardTheme::cameraDialogStyleSheet());
    resize(560, 460);

    connect(searchEdit_, &QLineEdit::textChanged, this, &RoomConnectionDialog::onSearchTextChanged);
    connect(roomListView_->selectionModel(), &QItemSelectionModel::selectionChanged, this, &RoomConnectionDialog::onRoomSelectionChanged);
    connect(refreshButton_, &QPushButton::clicked, this, &RoomConnectionDialog::onRefreshClicked);
    connect(cancelButton_, &QPushButton::clicked, this, &QDialog::reject);
    connect(connectButton_, &QPushButton::clicked, this, &RoomConnectionDialog::onConnectClicked);
    connect(disconnectButton_, &QPushButton::clicked, this, &RoomConnectionDialog::onDisconnectClicked);
    connect(reconnectButton_, &QPushButton::clicked, this, &RoomConnectionDialog::onReconnectClicked);
    connect(closeButton_, &QPushButton::clicked, this, &QDialog::accept);
    roomListView_->installEventFilter(this);

    setViewMode(viewMode_);
    updateConnectEnabled();
}

void RoomConnectionDialog::setViewMode(ViewMode mode) {
    viewMode_ = mode;
    const bool connected = mode == ViewMode::Connected;
    searchEdit_->setVisible(!connected);
    roomListView_->setVisible(!connected);
    connectButton_->setVisible(!connected);
    cancelButton_->setVisible(!connected);
    const bool live = connected && sessionManager_ && sessionManager_->hasLiveAccessToken();
    disconnectButton_->setVisible(live);
    reconnectButton_->setVisible(false);
    closeButton_->setVisible(connected);
    refreshButton_->setText(connected ? tr("Refresh Status") : tr("Refresh"));
    if (connected && sessionManager_) {
        const guard::backend::InstallationState state = sessionManager_->state();
        const QString backendUrl = guard::backend::GuardBackendClient::effectiveBaseUrl();
        const QString lastConnected =
          state.lastConnectedAtUtc.isValid() ? state.lastConnectedAtUtc.toLocalTime().toString(Qt::ISODate) : tr("Unknown");
        const QString statusText = live ? tr("Connected") : tr("Disconnected");
        connectedInfoLabel_->setText(
          tr("Current room: %1\nRoom ID: %2\nBackend URL: %3\nStatus: %4\nLast successful connection: %5")
            .arg(state.roomName.isEmpty() ? state.roomId : state.roomName, state.roomId, backendUrl, statusText, lastConnected));
        connectedInfoLabel_->show();
        setStatusMessage(QString());
    } else {
        connectedInfoLabel_->hide();
    }
}

void RoomConnectionDialog::populateRoomModel(const QVector<guard::backend::AvailableRoom>& rooms) {
    roomModel_->clear();
    for (const guard::backend::AvailableRoom& room : rooms) {
        QStandardItem* item = new QStandardItem(room.name);
        item->setData(room.id, kRoomIdRole);
        roomModel_->appendRow(item);
    }
    onSearchTextChanged(searchEdit_->text());
}

void RoomConnectionDialog::beginRoomLoad() {
    if (!client_ || roomLoadInFlight_)
        return;
    roomLoadInFlight_ = true;
    refreshButton_->setEnabled(false);
    connectButton_->setEnabled(false);
    setStatusMessage(tr("Loading rooms..."));

    // The backend client owns requests beyond the dialog's lifetime. Capture a
    // guarded dialog pointer and a request generation instead of a raw QObject
    // sentinel: a deleted sentinel still leaves a non-null dangling pointer.
    // This prevents late health/room-list completions from dereferencing a
    // RoomConnectionDialog that has already closed.
    const quint64 generation = ++roomLoadGeneration_;
    QPointer<RoomConnectionDialog> self(this);
    client_->testConnection([self, generation](const guard::backend::GuardApiResponse& healthResponse) {
        if (!self || self->roomLoadGeneration_ != generation)
            return;
        if (!healthResponse.ok()) {
            self->handleRoomLoadFailure(self->tr("Backend unavailable"));
            return;
        }
        self->client_->get(QStringLiteral("/api/guard/available-rooms"), [self, generation](const guard::backend::GuardApiResponse& roomsResponse) {
            if (!self || self->roomLoadGeneration_ != generation)
                return;
            self->roomLoadInFlight_ = false;
            self->refreshButton_->setEnabled(true);
            if (!roomsResponse.ok()) {
                self->handleRoomLoadFailure(roomsResponse.errorMessage.isEmpty() ? self->tr("Backend unavailable") : roomsResponse.errorMessage);
                return;
            }
            QString parseError;
            QVector<guard::backend::AvailableRoom> rooms;
            const QJsonObject object = roomsResponse.jsonObject(&parseError);
            if (!parseError.isEmpty() || !guard::backend::parseAvailableRooms(object, &rooms, &parseError)) {
                self->handleRoomLoadFailure(parseError);
                return;
            }
            self->populateRoomModel(rooms);
            if (rooms.isEmpty())
                self->setStatusMessage(self->tr("No rooms configured"));
            else if (self->roomProxyModel_->rowCount() == 0)
                self->setStatusMessage(self->tr("No rooms found"));
            else
                self->setStatusMessage(QString());
            self->updateConnectEnabled();
        });
    });
}

void RoomConnectionDialog::handleRoomLoadFailure(const QString& message) {
    roomLoadInFlight_ = false;
    refreshButton_->setEnabled(true);
    roomModel_->clear();
    setStatusMessage(message, true);
    updateConnectEnabled();
}

void RoomConnectionDialog::reloadRooms() {
    if (viewMode_ == ViewMode::Connected) {
        if (sessionManager_ && sessionManager_->isRegistered() && !sessionManager_->isUserDisconnected()) {
            QPointer<RoomConnectionDialog> self(this);
            sessionManager_->refreshAccessToken([self](bool success, const QString& errorMessage) {
                if (!self)
                    return;
                self->setViewMode(ViewMode::Connected);
                if (!success)
                    self->setStatusMessage(errorMessage, true);
            });
        } else {
            setViewMode(ViewMode::Connected);
        }
        return;
    }
    searchEdit_->clear();
    beginRoomLoad();
}

QString RoomConnectionDialog::selectedRoomId() const {
    const QModelIndexList selected = roomListView_->selectionModel()->selectedIndexes();
    if (selected.isEmpty())
        return QString();
    return selected.first().data(kRoomIdRole).toString();
}

guard::backend::RoomConnectionRequest RoomConnectionDialog::buildConnectionRequest() const {
    guard::backend::RoomConnectionRequest request;
    request.roomId = selectedRoomId();
    request.applicationVersion = QCoreApplication::applicationVersion();
    request.cameras = cameras_;
    const QString host = QSysInfo::machineHostName().trimmed();
    request.deviceName = host.isEmpty() ? tr("Guard Computer") : tr("%1 Guard").arg(host);
    return request;
}

void RoomConnectionDialog::updateConnectEnabled() {
    const bool canConnect = viewMode_ == ViewMode::RoomSelection && !roomLoadInFlight_ && !selectedRoomId().isEmpty() &&
                            roomProxyModel_->rowCount() > 0 && statusLabel_->text() != tr("No rooms configured");
    connectButton_->setEnabled(canConnect);
}

void RoomConnectionDialog::setBusy(bool busy) {
    busy_ = busy;
    searchEdit_->setEnabled(!busy);
    roomListView_->setEnabled(!busy);
    refreshButton_->setEnabled(!busy);
    connectButton_->setEnabled(!busy && !selectedRoomId().isEmpty());
    cancelButton_->setEnabled(!busy);
    disconnectButton_->setEnabled(!busy);
    reconnectButton_->setEnabled(!busy);
    closeButton_->setEnabled(!busy);
    connectButton_->setText(busy ? tr("Connecting") : tr("Connect"));
}

void RoomConnectionDialog::setStatusMessage(const QString& message, bool isError) {
    statusLabel_->setText(message);
    statusLabel_->setProperty("error", isError);
    statusLabel_->style()->unpolish(statusLabel_);
    statusLabel_->style()->polish(statusLabel_);
}

void RoomConnectionDialog::onConnectionSucceeded() {
    setBusy(false);
    accept();
}

void RoomConnectionDialog::onDisconnected() {
    // CameraWidgets are room-owned. MainWindow has stopped and removed the
    // previous room workspace, so a new room connection must not submit any of
    // those cameras. The selected room's cameras are loaded from the backend
    // after authentication succeeds.
    cameras_.clear();

    setBusy(false);
    setStatusMessage(tr("Room disconnected. Select any available room to connect this computer again."));
    showRoomSelectionMode();
}

void RoomConnectionDialog::showRoomSelectionMode() {
    setViewMode(ViewMode::RoomSelection);
    reloadRooms();
}

void RoomConnectionDialog::onSearchTextChanged(const QString& text) {
    roomProxyModel_->setFilterFixedString(text.trimmed());
    if (viewMode_ != ViewMode::RoomSelection)
        return;
    if (roomModel_->rowCount() == 0)
        return;
    if (roomProxyModel_->rowCount() == 0)
        setStatusMessage(tr("No rooms found"), false);
    else if (statusLabel_->text() == tr("No rooms found"))
        setStatusMessage(QString());
    updateConnectEnabled();
}

void RoomConnectionDialog::onRoomSelectionChanged() {
    updateConnectEnabled();
}

void RoomConnectionDialog::onConnectClicked() {
    if (busy_ || viewMode_ != ViewMode::RoomSelection)
        return;
    const guard::backend::RoomConnectionRequest request = buildConnectionRequest();
    if (request.roomId.trimmed().isEmpty())
        return;
    setBusy(true);
    setStatusMessage(tr("Connecting"));
    emit connectionRequested(request);
}

void RoomConnectionDialog::onDisconnectClicked() {
    const guard::backend::InstallationState state = sessionManager_ ? sessionManager_->state() : guard::backend::InstallationState{};
    if (!GuardMessageDialog::question(this, tr("Room Connection"),
                                      tr("Disconnect this computer from %1?").arg(state.roomName.isEmpty() ? state.roomId : state.roomName))) {
        return;
    }
    setBusy(true);
    emit disconnectRequested();
}

void RoomConnectionDialog::onReconnectClicked() {
    setBusy(true);
    setStatusMessage(tr("Reconnecting"));
    emit reconnectRequested();
}

void RoomConnectionDialog::onRefreshClicked() {
    reloadRooms();
}

void RoomConnectionDialog::showEvent(QShowEvent* event) {
    QDialog::showEvent(event);
    updateDialogFrameMask();
    if (viewMode_ == ViewMode::RoomSelection)
        reloadRooms();
    else
        setViewMode(ViewMode::Connected);
}

void RoomConnectionDialog::resizeEvent(QResizeEvent* event) {
    QDialog::resizeEvent(event);
    updateDialogFrameMask();
}

void RoomConnectionDialog::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        retranslateUi();
    QDialog::changeEvent(event);
}

bool RoomConnectionDialog::eventFilter(QObject* watched, QEvent* event) {
    if (watched == roomListView_ && event->type() == QEvent::KeyPress) {
        QKeyEvent* keyEvent = static_cast<QKeyEvent*>(event);
        if (keyEvent->key() == Qt::Key_Return || keyEvent->key() == Qt::Key_Enter) {
            onConnectClicked();
            return true;
        }
        if (keyEvent->key() == Qt::Key_Escape) {
            reject();
            return true;
        }
    }
    return QDialog::eventFilter(watched, event);
}

void RoomConnectionDialog::retranslateUi() {
    if (titleBar_)
        titleBar_->setTitle(tr("Room Connection"));
    if (searchEdit_)
        searchEdit_->setPlaceholderText(tr("Search rooms..."));
    if (refreshButton_)
        refreshButton_->setText(viewMode_ == ViewMode::Connected ? tr("Refresh Status") : tr("Refresh"));
    if (cancelButton_)
        cancelButton_->setText(tr("Cancel"));
    if (connectButton_)
        connectButton_->setText(busy_ ? tr("Connecting") : tr("Connect"));
    if (disconnectButton_)
        disconnectButton_->setText(tr("Disconnect Room"));
    if (reconnectButton_)
        reconnectButton_->setText(tr("Reconnect"));
    if (closeButton_)
        closeButton_->setText(tr("Close"));
    if (viewMode_ == ViewMode::Connected)
        setViewMode(ViewMode::Connected);
}

void RoomConnectionDialog::updateDialogFrameMask() {
    if (!dialogFrame_)
        return;
    QPainterPath path;
    path.addRoundedRect(QRectF(dialogFrame_->rect()).adjusted(0.5, 0.5, -0.5, -0.5), kCornerRadius, kCornerRadius);
    dialogFrame_->setMask(QRegion(path.toFillPolygon().toPolygon()));
}
