#ifndef APPSETTINGSDIALOG_H
#define APPSETTINGSDIALOG_H

#include "AppSettings.h"
#include "media/recording/RecordingStorageManager.h"

#include <QDialog>

class QCheckBox;
class QEvent;
class QFormLayout;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QResizeEvent;
class QShowEvent;
class QSlider;
class QTabWidget;
class QWidget;
class WindowTitleBar;

namespace guard {
namespace backend {
class GuardBackendClient;
}  // namespace backend
}  // namespace guard

class AppSettingsDialog : public QDialog {
    Q_OBJECT

public:
    explicit AppSettingsDialog(guard::recording::RecordingStorageManager* storageManager, guard::backend::GuardBackendClient* backendClient = nullptr,
                               QWidget* parent = nullptr);

    AppSettings settings() const;
    bool backendUrlChanged() const;
    void setNotificationPolicies(bool notifyUnknownIncoming, bool notifyUnapprovedIncoming);

signals:
    void testHazardAlarmRequested();

protected:
    void changeEvent(QEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private:
    void buildUi();
    void retranslateUi();
    void updateFormFieldLabel(QFormLayout* form, QWidget* field, const QString& text);
    QWidget* buildServerTab();
    QWidget* buildLicenseTab();
    QWidget* buildAlertsTab();
    QWidget* buildRecordingTab();
    QWidget* buildDiagnosticsTab();
    void updateDialogFrameMask();
    void loadSettings();
    void refreshRecordingPreview();
    void testBackendConnection();
    void browseRecordingRoot();
    void openEffectiveRoot();
    void restoreDefaultRoot();
    void refreshDiagnosticsPreview();
    void browseCameraLogDirectory();
    void openCameraLogDirectory();
    void restoreDefaultCameraLogDirectory();
    bool validateAndSave();
    void copyHardwareIdToClipboard();
    void activateLicenseFromSettings();
    void refreshLicenseStatus();

    guard::recording::RecordingStorageManager* storageManager_ = nullptr;
    guard::backend::GuardBackendClient* backendClient_ = nullptr;
    AppSettings settings_;
    bool restoreDefaultRequested_ = false;
    bool backendUrlChanged_ = false;
    bool restoreDefaultCameraLogDirectoryRequested_ = false;
    QString initialBackendBaseUrl_;

    QWidget* dialogFrame_ = nullptr;
    WindowTitleBar* titleBar_ = nullptr;
    QTabWidget* tabs_ = nullptr;

    QGroupBox* serverGroup_ = nullptr;
    QFormLayout* serverForm_ = nullptr;
    QGroupBox* licenseGroup_ = nullptr;
    QFormLayout* licenseForm_ = nullptr;

    QLineEdit* backendUrlEdit_ = nullptr;
    QLabel* backendUrlSourceLabel_ = nullptr;
    QLabel* backendConnectionLabel_ = nullptr;
    QLabel* backendVersionLabel_ = nullptr;
    QPushButton* testConnectionButton_ = nullptr;

    QLineEdit* hardwareIdEdit_ = nullptr;
    QPushButton* copyHardwareIdButton_ = nullptr;
    QLabel* licenseStatusLabel_ = nullptr;
    QLineEdit* licenseKeyEdit_ = nullptr;
    QPushButton* activateLicenseButton_ = nullptr;
    QLabel* licenseNoteLabel_ = nullptr;

    QGroupBox* localHazardGroup_ = nullptr;
    QFormLayout* alertsForm_ = nullptr;
    QCheckBox* pcHazardAlarmCheckBox_ = nullptr;
    QSlider* pcHazardVolumeSlider_ = nullptr;
    QLabel* pcHazardVolumeLabel_ = nullptr;
    QCheckBox* repeatUntilAcknowledgedCheckBox_ = nullptr;
    QGroupBox* accessWarningsGroup_ = nullptr;
    QFormLayout* accessWarningsForm_ = nullptr;
    QLabel* unknownIncomingPolicyLabel_ = nullptr;
    QLabel* unapprovedIncomingPolicyLabel_ = nullptr;
    QLabel* accessWarningsNoteLabel_ = nullptr;
    QPushButton* testAlarmButton_ = nullptr;
    bool notificationPoliciesSet_ = false;
    bool notifyUnknownIncoming_ = false;
    bool notifyUnapprovedIncoming_ = false;

    QGroupBox* recordingGroup_ = nullptr;
    QFormLayout* recordingForm_ = nullptr;
    QLineEdit* recordingRootEdit_ = nullptr;
    QPushButton* browseRecordingRootButton_ = nullptr;
    QPushButton* openRecordingRootButton_ = nullptr;
    QPushButton* restoreDefaultRootButton_ = nullptr;
    QLabel* recordingRootSourceLabel_ = nullptr;
    QLabel* recordingStorageStatusLabel_ = nullptr;

    QGroupBox* diagnosticsGroup_ = nullptr;
    QFormLayout* diagnosticsForm_ = nullptr;
    QCheckBox* cameraFileLoggingCheckBox_ = nullptr;
    QLineEdit* cameraLogDirectoryEdit_ = nullptr;
    QPushButton* browseCameraLogDirectoryButton_ = nullptr;
    QPushButton* openCameraLogDirectoryButton_ = nullptr;
    QPushButton* restoreDefaultCameraLogDirectoryButton_ = nullptr;
    QLabel* cameraLogDirectorySourceLabel_ = nullptr;
    QLabel* cameraFileLoggingNoteLabel_ = nullptr;

    QPushButton* saveButton_ = nullptr;
    QPushButton* cancelButton_ = nullptr;
};

#endif  // APPSETTINGSDIALOG_H
