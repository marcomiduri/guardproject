#include "LicenseActivationDialog.h"

#include "GuardHardwareId.h"
#include "GuardLicenseManager.h"
#include "GuardMessageDialog.h"
#include "GuardTheme.h"
#include "platform/compat/GuardPalette.h"
#include "WindowTitleBar.h"

#include <QApplication>
#include <QClipboard>
#include <QColor>
#include <QEvent>
#include <QFont>
#include <QFormLayout>
#include <QGraphicsDropShadowEffect>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPainterPath>
#include <QPalette>
#include <QPushButton>
#include <QRegion>
#include <QResizeEvent>
#include <QShowEvent>
#include <QSizePolicy>
#include <QVBoxLayout>

namespace {
constexpr int kDialogCornerRadius = 4;

void styleLineEdit(QLineEdit* edit) {
    if (!edit)
        return;
    edit->setObjectName(QStringLiteral("licenseField"));
    edit->setProperty("settingsField", true);
    edit->setStyleSheet(GuardTheme::settingsLineEditStyleSheet());
    QPalette palette = edit->palette();
    palette.setColor(QPalette::Base, GuardTheme::colorFromHex(GuardTheme::kSurfaceMuted));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
    guardSetPlaceholderTextColor(palette, GuardTheme::colorFromHex(GuardTheme::kTextPlaceholder));
    edit->setPalette(palette);
}

void styleButton(QPushButton* button, const QString& objectName = QString()) {
    if (!button)
        return;
    if (!objectName.isEmpty())
        button->setObjectName(objectName);
    button->setAutoDefault(false);
    button->setFlat(false);
    button->setCursor(Qt::PointingHandCursor);
    button->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
}

QLabel* createFieldLabel(QWidget* parent, const QString& text) {
    QLabel* label = new QLabel(text, parent);
    label->setObjectName(QStringLiteral("settingsFieldLabel"));
    QPalette palette = label->palette();
    palette.setColor(QPalette::WindowText, GuardTheme::colorFromHex(GuardTheme::kTextSubtle));
    palette.setColor(QPalette::Text, GuardTheme::colorFromHex(GuardTheme::kTextSubtle));
    label->setPalette(palette);
    return label;
}

void addFormRow(QFormLayout* form, QWidget* parent, const QString& labelText, QWidget* field) {
    form->addRow(createFieldLabel(parent, labelText), field);
}

void updateFormFieldLabel(QFormLayout* form, QWidget* field, const QString& text) {
    if (!form || !field)
        return;
    if (QLabel* label = qobject_cast<QLabel*>(form->labelForField(field)))
        label->setText(text);
}
}  // namespace

LicenseActivationDialog::LicenseActivationDialog(bool permanentOnly, QWidget* parent) : QDialog(parent), permanentOnly_(permanentOnly) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setWindowModality(Qt::WindowModal);
    setAttribute(Qt::WA_TranslucentBackground);
    setObjectName(QStringLiteral("LicenseActivationDialog"));
    buildUi();
}

void LicenseActivationDialog::buildUi() {
    QVBoxLayout* outerLayout = new QVBoxLayout(this);
    outerLayout->setContentsMargins(20, 20, 20, 20);
    outerLayout->setSpacing(0);

    QWidget* shadowHost = new QWidget(this);
    shadowHost->setAttribute(Qt::WA_TranslucentBackground);
    QVBoxLayout* shadowLayout = new QVBoxLayout(shadowHost);
    shadowLayout->setContentsMargins(0, 0, 0, 0);
    shadowLayout->setSpacing(0);

    dialogFrame_ = new QWidget(shadowHost);
    dialogFrame_->setObjectName(QStringLiteral("dialogFrame"));
    dialogFrame_->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* frameLayout = new QVBoxLayout(dialogFrame_);
    frameLayout->setContentsMargins(0, 0, 0, 0);
    frameLayout->setSpacing(0);

    titleBar_ = new WindowTitleBar(dialogFrame_, WindowTitleBar::Style::Dialog);
    titleBar_->setObjectName(QStringLiteral("titleBar"));
    frameLayout->addWidget(titleBar_, 0, Qt::AlignTop);
    connect(titleBar_, &WindowTitleBar::closeRequested, this, &QDialog::reject);

    QWidget* content = new QWidget(dialogFrame_);
    content->setObjectName(QStringLiteral("dialogContent"));
    content->setAttribute(Qt::WA_StyledBackground, true);
    QVBoxLayout* contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(24, 22, 24, 18);
    contentLayout->setSpacing(14);

    headingLabel_ = new QLabel(content);
    headingLabel_->setObjectName(QStringLiteral("licenseTitleLabel"));
    QFont titleFont = headingLabel_->font();
    titleFont.setPointSize(titleFont.pointSize() + 2);
    titleFont.setBold(true);
    headingLabel_->setFont(titleFont);
    headingLabel_->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    contentLayout->addWidget(headingLabel_);

    statusLabel_ = new QLabel(content);
    statusLabel_->setObjectName(QStringLiteral("licenseHelpLabel"));
    statusLabel_->setWordWrap(true);
    statusLabel_->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    contentLayout->addWidget(statusLabel_);

    form_ = new QFormLayout;
    form_->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    form_->setHorizontalSpacing(16);
    form_->setVerticalSpacing(11);
    contentLayout->addLayout(form_);

    QWidget* hardwareHost = new QWidget(content);
    QHBoxLayout* hardwareLayout = new QHBoxLayout(hardwareHost);
    hardwareLayout->setContentsMargins(0, 0, 0, 0);
    hardwareLayout->setSpacing(8);
    hardwareIdEdit_ = new QLineEdit(hardwareHost);
    hardwareIdEdit_->setReadOnly(true);
    hardwareIdEdit_->setText(GuardHardwareId::displayText());
    hardwareIdEdit_->setMaxLength(19);
    styleLineEdit(hardwareIdEdit_);
    copyHardwareButton_ = new QPushButton(hardwareHost);
    styleButton(copyHardwareButton_, QStringLiteral("copyButton"));
    hardwareLayout->addWidget(hardwareIdEdit_, 1);
    hardwareLayout->addWidget(copyHardwareButton_);
    addFormRow(form_, content, QString(), hardwareHost);
    connect(copyHardwareButton_, &QPushButton::clicked, this, &LicenseActivationDialog::copyHardwareId);

    licenseKeyEdit_ = new QLineEdit(content);
    licenseKeyEdit_->setInputMask(QStringLiteral(">NNNN-NNNN-NNNN-NNNN;_"));
    licenseKeyEdit_->setMaxLength(19);
    styleLineEdit(licenseKeyEdit_);
    addFormRow(form_, content, QString(), licenseKeyEdit_);

    frameLayout->addWidget(content, 1);

    QWidget* footer = new QWidget(dialogFrame_);
    footer->setObjectName(QStringLiteral("dialogFooter"));
    footer->setAttribute(Qt::WA_StyledBackground, true);
    QHBoxLayout* footerLayout = new QHBoxLayout(footer);
    footerLayout->setContentsMargins(16, 14, 16, 20);
    footerLayout->setSpacing(0);
    footerLayout->addStretch(1);

    closeButton_ = new QPushButton(footer);
    activateButton_ = new QPushButton(footer);
    styleButton(closeButton_, QStringLiteral("cancelButton"));
    styleButton(activateButton_, QStringLiteral("okButton"));
    activateButton_->setAutoDefault(true);
    activateButton_->setDefault(true);
    footerLayout->addWidget(closeButton_);
    footerLayout->addWidget(activateButton_);
    frameLayout->addWidget(footer);

    shadowLayout->addWidget(dialogFrame_);
    outerLayout->addWidget(shadowHost);

    QGraphicsDropShadowEffect* shadow = new QGraphicsDropShadowEffect(shadowHost);
    shadow->setBlurRadius(48);
    shadow->setOffset(0, 16);
    shadow->setColor(QColor(2, 6, 23, 140));
    shadowHost->setGraphicsEffect(shadow);

    connect(closeButton_, &QPushButton::clicked, this, &LicenseActivationDialog::reject);
    connect(activateButton_, &QPushButton::clicked, this, &LicenseActivationDialog::activateLicense);

    setStyleSheet(GuardTheme::cameraDialogStyleSheet());
    setMinimumWidth(560);
    retranslateUi();
    resize(620, sizeHint().height());
}

void LicenseActivationDialog::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        retranslateUi();
    QDialog::changeEvent(event);
}

void LicenseActivationDialog::retranslateUi() {
    const QString dialogTitle = tr("Guard License");
    setWindowTitle(dialogTitle);
    if (titleBar_)
        titleBar_->setTitle(dialogTitle);
    if (headingLabel_)
        headingLabel_->setText(permanentOnly_ ? tr("Permanent license required") : tr("Enter Guard license"));
    if (statusLabel_) {
        statusLabel_->setText(permanentOnly_
                                ? tr("The temporary 7-day license is missing, invalid, or expired. Enter a permanent license key to continue.")
                                : tr("Copy this hardware ID to LicenseGenerator, then paste the generated Guard license key below."));
    }
    if (form_) {
        updateFormFieldLabel(form_, hardwareIdEdit_ ? hardwareIdEdit_->parentWidget() : nullptr, tr("Hardware ID"));
        updateFormFieldLabel(form_, licenseKeyEdit_, tr("License key"));
    }
    if (copyHardwareButton_)
        copyHardwareButton_->setText(tr("Copy"));
    if (closeButton_)
        closeButton_->setText(permanentOnly_ ? tr("Exit") : tr("Close"));
    if (activateButton_)
        activateButton_->setText(tr("Activate"));
}

void LicenseActivationDialog::showEvent(QShowEvent* event) {
    QDialog::showEvent(event);
    updateDialogFrameMask();
}

void LicenseActivationDialog::resizeEvent(QResizeEvent* event) {
    QDialog::resizeEvent(event);
    updateDialogFrameMask();
}

void LicenseActivationDialog::updateDialogFrameMask() {
    if (!dialogFrame_)
        return;
    QPainterPath clipPath;
    clipPath.addRoundedRect(QRectF(dialogFrame_->rect()).adjusted(0.5, 0.5, -0.5, -0.5), kDialogCornerRadius, kDialogCornerRadius);
    dialogFrame_->setMask(QRegion(clipPath.toFillPolygon().toPolygon()));
}

void LicenseActivationDialog::copyHardwareId() {
    QApplication::clipboard()->setText(hardwareIdEdit_ ? hardwareIdEdit_->text() : QString());
}

void LicenseActivationDialog::activateLicense() {
    QString error;
    if (!guard::license::GuardLicenseManager::activateLicenseKey(licenseKeyEdit_->text(), permanentOnly_, &error)) {
        GuardMessageDialog::warning(this, tr("Guard License"), error);
        return;
    }
    accept();
}
