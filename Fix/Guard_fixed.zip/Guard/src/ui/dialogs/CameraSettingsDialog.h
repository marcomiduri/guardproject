#ifndef CAMERASETTINGSDIALOG_H
#define CAMERASETTINGSDIALOG_H

#include "CameraDetectionSettings.h"
#include "CameraTestSourceSettings.h"
#include "media/hikvision/CameraOnboardTypes.h"

#include <QDialog>
#include <QString>

class GuardComboBox;
class QCheckBox;
class QDialogButtonBox;
class QEvent;
class QFormLayout;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QResizeEvent;
class QShowEvent;
class QWidget;
class WindowTitleBar;

class CameraSettingsDialog : public QDialog {
    Q_OBJECT

public:
    explicit CameraSettingsDialog(QWidget* parent = nullptr);

    void setCameraName(const QString& cameraName);
    void setSettings(const CameraDetectionSettings& settings);
    CameraDetectionSettings settings() const;

    void setTestMode(bool enabled);
    bool testMode() const;
    void setTestSourceSettings(const CameraTestSourceSettings& settings);
    CameraTestSourceSettings testSourceSettings() const;

    void setDetectionAvailability(bool cameraConnected, bool hcNetSdkSource, const guard::CameraOnboardCapabilities& capabilities,
                                  bool hazardModelAvailable);

protected:
    void changeEvent(QEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private:
    void buildUi();
    void retranslateUi();
    void updateDialogFrameMask();
    void styleComboBox(GuardComboBox* comboBox);
    void updateTestSourceUi();
    void refreshDetectionAvailability();
    void browseForTestMedia();
    bool validateAndStore();

    CameraDetectionSettings settings_;
    CameraTestSourceSettings testSourceSettings_;
    QString cameraName_;
    bool testMode_ = false;
    bool hazardModelAvailable_ = false;
    bool cameraConnected_ = false;
    bool hcNetSdkSource_ = false;
    guard::CameraOnboardCapabilities capabilities_;

    QWidget* dialogFrame_ = nullptr;
    WindowTitleBar* titleBar_ = nullptr;
    QLabel* cameraNameLabel_ = nullptr;
    QGroupBox* detectionGroup_ = nullptr;
    QFormLayout* detectionForm_ = nullptr;
    GuardComboBox* motionCombo_ = nullptr;
    GuardComboBox* faceCombo_ = nullptr;
    GuardComboBox* hazardCombo_ = nullptr;
    QCheckBox* recordCheckBox_ = nullptr;

    QGroupBox* testSourceGroup_ = nullptr;
    QFormLayout* testSourceForm_ = nullptr;
    QLineEdit* testFilePathEdit_ = nullptr;
    QPushButton* testBrowseButton_ = nullptr;
    QLabel* testSourceHelpLabel_ = nullptr;

    QLabel* availabilityLabel_ = nullptr;
    QDialogButtonBox* buttonBox_ = nullptr;
};

#endif  // CAMERASETTINGSDIALOG_H
