#pragma once

#include "model/GuardBackendModels.h"
#include "services/backend/GuardBackendClient.h"
#include "services/backend/GuardSessionManager.h"

#include <QDialog>
#include <QPointer>
#include <QVector>

class QLabel;
class QLineEdit;
class QListView;
class QPushButton;
class QSortFilterProxyModel;
class QStandardItemModel;
class WindowTitleBar;

class RoomConnectionDialog : public QDialog {
    Q_OBJECT

public:
    explicit RoomConnectionDialog(guard::backend::GuardBackendClient* client, guard::backend::GuardSessionManager* sessionManager,
                                  const QVector<CameraUiModel>& cameras, QWidget* parent = nullptr);

    void reloadRooms();

signals:
    void connectionRequested(const guard::backend::RoomConnectionRequest& request);
    void disconnectRequested();
    void reconnectRequested();

public slots:
    void setBusy(bool busy);
    void setStatusMessage(const QString& message, bool isError = false);
    void onConnectionSucceeded();
    void onDisconnected();
    void showRoomSelectionMode();

private slots:
    void onSearchTextChanged(const QString& text);
    void onRoomSelectionChanged();
    void onConnectClicked();
    void onDisconnectClicked();
    void onReconnectClicked();
    void onRefreshClicked();

protected:
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    void changeEvent(QEvent* event) override;
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    enum class ViewMode { RoomSelection, Connected };

    void buildUi();
    void retranslateUi();
    void updateDialogFrameMask();
    void setViewMode(ViewMode mode);
    void populateRoomModel(const QVector<guard::backend::AvailableRoom>& rooms);
    void beginRoomLoad();
    void handleRoomLoadFailure(const QString& message);
    void updateConnectEnabled();
    guard::backend::RoomConnectionRequest buildConnectionRequest() const;
    QString selectedRoomId() const;

    guard::backend::GuardBackendClient* client_ = nullptr;
    guard::backend::GuardSessionManager* sessionManager_ = nullptr;
    QVector<CameraUiModel> cameras_;
    ViewMode viewMode_ = ViewMode::RoomSelection;
    bool roomLoadInFlight_ = false;
    bool busy_ = false;

    QWidget* dialogFrame_ = nullptr;
    WindowTitleBar* titleBar_ = nullptr;
    QLineEdit* searchEdit_ = nullptr;
    QListView* roomListView_ = nullptr;
    QStandardItemModel* roomModel_ = nullptr;
    QSortFilterProxyModel* roomProxyModel_ = nullptr;
    QLabel* statusLabel_ = nullptr;
    QLabel* connectedInfoLabel_ = nullptr;
    QPushButton* refreshButton_ = nullptr;
    QPushButton* cancelButton_ = nullptr;
    QPushButton* connectButton_ = nullptr;
    QPushButton* disconnectButton_ = nullptr;
    QPushButton* reconnectButton_ = nullptr;
    QPushButton* closeButton_ = nullptr;
    quint64 roomLoadGeneration_ = 0;
};
