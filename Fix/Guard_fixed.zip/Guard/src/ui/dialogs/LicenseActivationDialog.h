#ifndef LICENSEACTIVATIONDIALOG_H
#define LICENSEACTIVATIONDIALOG_H

#include <QDialog>

class QEvent;
class QFormLayout;
class QLabel;
class QLineEdit;
class QPushButton;
class QResizeEvent;
class QShowEvent;
class QWidget;
class WindowTitleBar;

class LicenseActivationDialog : public QDialog {
    Q_OBJECT
public:
    explicit LicenseActivationDialog(bool permanentOnly, QWidget* parent = nullptr);

protected:
    void changeEvent(QEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private slots:
    void copyHardwareId();
    void activateLicense();

private:
    void buildUi();
    void retranslateUi();
    void updateDialogFrameMask();

    bool permanentOnly_ = false;
    QWidget* dialogFrame_ = nullptr;
    WindowTitleBar* titleBar_ = nullptr;
    QLabel* headingLabel_ = nullptr;
    QFormLayout* form_ = nullptr;
    QLineEdit* hardwareIdEdit_ = nullptr;
    QPushButton* copyHardwareButton_ = nullptr;
    QLineEdit* licenseKeyEdit_ = nullptr;
    QLabel* statusLabel_ = nullptr;
    QPushButton* activateButton_ = nullptr;
    QPushButton* closeButton_ = nullptr;
};

#endif  // LICENSEACTIVATIONDIALOG_H
