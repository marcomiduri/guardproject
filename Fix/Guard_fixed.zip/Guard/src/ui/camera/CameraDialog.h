#ifndef CAMERADIALOG_H
#define CAMERADIALOG_H

#include "CameraUiModel.h"

#include <QDialog>

class QResizeEvent;
class QShowEvent;
class QWidget;
class WindowTitleBar;

QT_BEGIN_NAMESPACE
namespace Ui {
class CameraDialog;
}
QT_END_NAMESPACE

class CameraDialog : public QDialog {
    Q_OBJECT

public:
    explicit CameraDialog(QWidget *parent = nullptr);
    ~CameraDialog() override;

    void setCamera(const CameraUiModel &camera);
    void setDefaultCameraName(const QString &name);
    CameraUiModel camera() const;
    void setDialogTitle(const QString &title);

protected:
    void showEvent(QShowEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void changeEvent(QEvent *event) override;

private:
    void connectSignals();
    void updateDialogFrameMask();
    void styleDialogButtons();
    void styleFormComboBoxes();
    bool validate();

    Ui::CameraDialog *ui;
    WindowTitleBar *m_titleBar = nullptr;
    QWidget *m_dialogFrame = nullptr;
    CameraUiModel m_originalCamera;
};

#endif  // CAMERADIALOG_H
