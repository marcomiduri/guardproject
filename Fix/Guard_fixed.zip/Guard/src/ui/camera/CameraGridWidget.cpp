#include "CameraGridWidget.h"
#include "CameraWidget.h"
#include "ui_CameraGridWidget.h"

#include <QAbstractAnimation>
#include <QEasingCurve>
#include <QEvent>
#include <QFrame>
#include <QGraphicsOpacityEffect>
#include <QLabel>
#include <QParallelAnimationGroup>
#include <QPropertyAnimation>
#include <QResizeEvent>
#include <QTimer>
#include <QVBoxLayout>

namespace {
const int kMaximumCameraCount = 4;
const int kDefaultAnimationDurationMs = 300;
const int kDefaultGridSpacing = 8;
const int kCollapsedExtent = 1;
const int kTileFadeInDurationMs = 200;

void setTileGeometry(QFrame* host, CameraWidget* camera, const QRect& geometry) {
    if (!host) {
        return;
    }

    host->setGeometry(geometry);

    if (camera) {
        camera->resize(geometry.size());
    }
}

void connectTileGeometryAnimation(QPropertyAnimation* animation, CameraWidget* camera) {
    if (!animation || !camera) {
        return;
    }

    QObject::connect(animation, &QPropertyAnimation::valueChanged, camera,
                     [camera](const QVariant& value) { camera->resize(value.toRect().size()); });
}

QRect cameraCardRectInBounds(const QRect& bounds, const CameraWidget* cameraWidget) {
    if (!cameraWidget || bounds.width() <= 0 || bounds.height() <= 0) {
        return bounds;
    }

    int width = bounds.width();
    int height = cameraWidget->cardHeightForWidth(width);

    if (height > bounds.height()) {
        // Find the widest card whose fixed header/footer plus a 16:9
        // camera viewport still fit inside the available slot.
        int low = 0;
        int high = bounds.width();

        while (low < high) {
            const int middle = low + ((high - low + 1) / 2);

            if (cameraWidget->cardHeightForWidth(middle) <= bounds.height()) {
                low = middle;
            } else {
                high = middle - 1;
            }
        }

        width = low;
        height = cameraWidget->cardHeightForWidth(width);
    }

    // If the slot is shorter than the fixed card chrome, preserve a valid
    // non-negative rectangle and let Qt clip it during very small transitions.
    if (width <= 0 || height <= 0 || height > bounds.height()) {
        return bounds;
    }

    QRect rect(0, 0, width, height);
    rect.moveCenter(bounds.center());
    return rect;
}

QVector<QRect> slotBoundsForCount(const QRect& area, int count, int gridSpacing) {
    QVector<QRect> gridSlotBounds;
    gridSlotBounds.reserve(count);

    if (count <= 0) {
        return gridSlotBounds;
    }

    if (count == 1) {
        gridSlotBounds.append(area);
        return gridSlotBounds;
    }

    if (count == 2) {
        const int firstWidth = qMax(0, (area.width() - gridSpacing) / 2);
        const int secondWidth = qMax(0, area.width() - firstWidth - gridSpacing);

        gridSlotBounds.append(QRect(area.left(), area.top(), firstWidth, area.height()));
        gridSlotBounds.append(QRect(area.left() + firstWidth + gridSpacing, area.top(), secondWidth, area.height()));
        return gridSlotBounds;
    }

    const int firstWidth = qMax(0, (area.width() - gridSpacing) / 2);
    const int secondWidth = qMax(0, area.width() - firstWidth - gridSpacing);
    const int firstHeight = qMax(0, (area.height() - gridSpacing) / 2);
    const int secondHeight = qMax(0, area.height() - firstHeight - gridSpacing);

    const QRect cells[4] = {QRect(area.left(), area.top(), firstWidth, firstHeight),
                            QRect(area.left() + firstWidth + gridSpacing, area.top(), secondWidth, firstHeight),
                            QRect(area.left(), area.top() + firstHeight + gridSpacing, firstWidth, secondHeight),
                            QRect(area.left() + firstWidth + gridSpacing, area.top() + firstHeight + gridSpacing, secondWidth, secondHeight)};

    for (int index = 0; index < count && index < kMaximumCameraCount; ++index) {
        gridSlotBounds.append(cells[index]);
    }

    return gridSlotBounds;
}

}  // namespace

CameraGridWidget::CameraGridWidget(QWidget* parent)
: QWidget(parent),
  ui(new Ui::CameraGridWidget),
  m_animationDurationMs(kDefaultAnimationDurationMs),
  m_gridSpacing(kDefaultGridSpacing),
  m_outerMargin(0) {
    ui->setupUi(this);
    ui->emptyStateLabel->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    updateEmptyState();
}

CameraGridWidget::~CameraGridWidget() {
    stopCurrentAnimation();
    clearCameraWidgets();
    delete ui;
}

bool CameraGridWidget::addCameraWidget(CameraWidget* cameraWidget, bool animated) {
    if (!cameraWidget)
        return false;

    if (m_tiles.size() >= kMaximumCameraCount) {
        emit maximumCameraCountReached();
        return false;
    }

    if (indexOfCamera(cameraWidget) >= 0)
        return false;

    const QString newCameraId = cameraWidget->cameraId();

    if (!newCameraId.isEmpty() && m_cameraById.contains(newCameraId))
        return false;

    stopCurrentAnimation();

    // Adding a camera always restores the normal grid arrangement.
    m_expandedHost.clear();

    for (const Tile& tile : m_tiles)
        tile.host->show();

    QFrame* host = createTileHost(cameraWidget);

    if (!host)
        return false;

    Tile tile;
    tile.host = host;
    tile.camera = cameraWidget;
    m_tiles.append(tile);
    if (!newCameraId.isEmpty())
        m_cameraById.insert(newCameraId, cameraWidget);

    connect(cameraWidget, &CameraWidget::expandToggleRequested, this, &CameraGridWidget::toggleExpanded, Qt::UniqueConnection);

    connect(cameraWidget, &CameraWidget::removeRequested, this, &CameraGridWidget::cameraRemovalRequested, Qt::UniqueConnection);

    setTileGeometry(host, cameraWidget, collapsedRect());
    host->show();
    cameraWidget->show();

    updateEmptyState();
    applyCurrentLayout(animated);
    if (animated)
        fadeInTileHost(host);
    emit cameraCountChanged(m_tiles.size());

    return true;
}

bool CameraGridWidget::removeCameraWidget(const QString& cameraId, bool animated) {
    const int index = indexOfCamera(cameraId);

    if (index < 0)
        return false;

    stopCurrentAnimation();

    Tile retiringTile = m_tiles.at(index);
    if (retiringTile.camera)
        m_cameraById.remove(retiringTile.camera->cameraId());
    m_tiles.removeAt(index);

    if (m_expandedHost == retiringTile.host)
        m_expandedHost.clear();

    if (retiringTile.camera)
        retiringTile.camera->disconnect(this);

    m_retiringHosts.append(retiringTile.host);
    retiringTile.host->raise();

    for (const Tile& tile : m_tiles)
        tile.host->show();

    const QVector<QRect> targets = calculateTargetRects();

    updateEmptyState();
    emit cameraCountChanged(m_tiles.size());

    if (!animated || m_animationDurationMs <= 0) {
        cleanupRetiringHosts();
        applyCurrentLayout(false);
        return true;
    }

    startRemovalAnimation(retiringTile.host, targets);
    return true;
}

CameraWidget* CameraGridWidget::cameraWidget(const QString& cameraId) const {
    const QHash<QString, CameraWidget*>::const_iterator it = m_cameraById.constFind(cameraId);

    if (it == m_cameraById.constEnd())
        return nullptr;

    return it.value();
}

QList<CameraWidget*> CameraGridWidget::cameraWidgets() const {
    QList<CameraWidget*> result;

    for (const Tile& tile : m_tiles)
        result.append(tile.camera);

    return result;
}

int CameraGridWidget::cameraCount() const {
    return m_tiles.size();
}

int CameraGridWidget::maximumCameraCount() const {
    return kMaximumCameraCount;
}

void CameraGridWidget::clearCameraWidgets() {
    stopCurrentAnimation();

    const bool hadCameras = !m_tiles.isEmpty() || !m_retiringHosts.isEmpty();

    m_expandedHost.clear();

    for (const Tile& tile : m_tiles)
        delete tile.host;

    m_tiles.clear();
    m_cameraById.clear();
    cleanupRetiringHosts();

    updateEmptyState();

    if (hadCameras)
        emit cameraCountChanged(0);
}

void CameraGridWidget::refreshTranslations() {
    ui->retranslateUi(this);
    for (CameraWidget* camera : cameraWidgets()) {
        if (camera)
            camera->refreshTranslations();
    }
}

void CameraGridWidget::setAnimationDuration(int durationMs) {
    m_animationDurationMs = qMax(0, durationMs);
}

int CameraGridWidget::animationDuration() const {
    return m_animationDurationMs;
}

void CameraGridWidget::setGridSpacing(int spacing) {
    const int boundedSpacing = qMax(0, spacing);

    if (m_gridSpacing == boundedSpacing)
        return;

    m_gridSpacing = boundedSpacing;
    applyCurrentLayout(false);
}

int CameraGridWidget::gridSpacing() const {
    return m_gridSpacing;
}

bool CameraGridWidget::isExpanded() const {
    return !m_expandedHost.isNull();
}

QString CameraGridWidget::expandedCameraId() const {
    if (!m_expandedHost)
        return QString();

    for (const Tile& tile : m_tiles) {
        if (tile.host == m_expandedHost && tile.camera)
            return tile.camera->cameraId();
    }

    return QString();
}

void CameraGridWidget::toggleExpanded(const QString& cameraId) {
    const int index = indexOfCamera(cameraId);

    if (index < 0)
        return;

    if (m_expandedHost == m_tiles.at(index).host) {
        restoreGrid();
        return;
    }

    expandCamera(cameraId);
}

void CameraGridWidget::expandCamera(const QString& cameraId) {
    const int index = indexOfCamera(cameraId);

    if (index < 0)
        return;

    stopCurrentAnimation();

    const QString previousExpandedId = expandedCameraId();

    for (const Tile& tile : m_tiles)
        tile.host->show();

    m_expandedHost = m_tiles.at(index).host;
    m_expandedHost->raise();

    applyCurrentLayout(true);

    if (!previousExpandedId.isEmpty() && previousExpandedId != cameraId)
        emit cameraExpansionChanged(previousExpandedId, false);

    emit cameraExpansionChanged(cameraId, true);
}

void CameraGridWidget::restoreGrid() {
    if (!m_expandedHost)
        return;

    const QString previousExpandedId = expandedCameraId();

    stopCurrentAnimation();

    m_expandedHost.clear();

    for (const Tile& tile : m_tiles)
        tile.host->show();

    applyCurrentLayout(true);
    emit cameraExpansionChanged(previousExpandedId, false);
}

void CameraGridWidget::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        refreshTranslations();
    QWidget::changeEvent(event);
}

void CameraGridWidget::resizeEvent(QResizeEvent* event) {
    QWidget::resizeEvent(event);

    ui->emptyStateLabel->setGeometry(ui->cameraArea->contentsRect());

    // Window resizing should track the cursor immediately rather than
    // starting a layout transition on every resize event.
    applyCurrentLayout(false);
}

int CameraGridWidget::indexOfCamera(const QString& cameraId) const {
    CameraWidget* mappedCamera = m_cameraById.value(cameraId, nullptr);

    if (mappedCamera)
        return indexOfCamera(mappedCamera);

    for (int index = 0; index < m_tiles.size(); ++index) {
        CameraWidget* camera = m_tiles.at(index).camera;

        if (camera && camera->cameraId() == cameraId)
            return index;
    }

    return -1;
}

int CameraGridWidget::indexOfCamera(const CameraWidget* cameraWidget) const {
    for (int index = 0; index < m_tiles.size(); ++index) {
        if (m_tiles.at(index).camera == cameraWidget)
            return index;
    }

    return -1;
}

QFrame* CameraGridWidget::createTileHost(CameraWidget* cameraWidget) {
    QFrame* host = new QFrame(ui->cameraArea);
    host->setObjectName(QStringLiteral("cameraTileHost"));
    host->setFrameShape(QFrame::NoFrame);
    host->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    host->setAttribute(Qt::WA_StyledBackground, true);
    host->setAutoFillBackground(true);

    QVBoxLayout* layout = new QVBoxLayout(host);
    layout->setObjectName(QStringLiteral("cameraTileLayout"));
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    cameraWidget->setParent(host);
    layout->addWidget(cameraWidget, 1);

    return host;
}

QRect CameraGridWidget::usableAreaRect() const {
    QRect area = ui->cameraArea->contentsRect();

    area.adjust(m_outerMargin, m_outerMargin, -m_outerMargin, -m_outerMargin);

    if (area.width() < 0)
        area.setWidth(0);

    if (area.height() < 0)
        area.setHeight(0);

    return area;
}

QRect CameraGridWidget::collapsedRect() const {
    const QRect area = usableAreaRect();
    const QPoint center = area.center();

    return QRect(center.x(), center.y(), kCollapsedExtent, kCollapsedExtent);
}

QVector<QRect> CameraGridWidget::calculateTargetRects() const {
    QVector<QRect> targets;
    const int count = m_tiles.size();

    if (count <= 0)
        return targets;

    const QRect area = usableAreaRect();
    targets.reserve(count);

    if (m_expandedHost) {
        const QRect collapsed = collapsedRect();

        for (const Tile& tile : m_tiles) {
            const QRect slotBounds = tile.host == m_expandedHost ? area : collapsed;
            targets.append(tile.host == m_expandedHost ? cameraCardRectInBounds(slotBounds, tile.camera) : slotBounds);
        }

        return targets;
    }

    const QVector<QRect> gridSlotBounds = slotBoundsForCount(area, count, m_gridSpacing);

    for (int index = 0; index < gridSlotBounds.size() && index < m_tiles.size(); ++index) {
        targets.append(cameraCardRectInBounds(gridSlotBounds.at(index), m_tiles.at(index).camera));
    }

    return targets;
}

void CameraGridWidget::applyCurrentLayout(bool animated) {
    stopCurrentAnimation();

    const QVector<QRect> targets = calculateTargetRects();

    for (const Tile& tile : m_tiles)
        tile.host->show();

    if (!animated || m_animationDurationMs <= 0) {
        for (int index = 0; index < m_tiles.size() && index < targets.size(); ++index) {
            const Tile& tile = m_tiles.at(index);
            setTileGeometry(tile.host, tile.camera, targets.at(index));
        }

        updateVisibilityAfterLayout();
        return;
    }

    startLayoutAnimation(targets);
}

void CameraGridWidget::startLayoutAnimation(const QVector<QRect>& targets) {
    QParallelAnimationGroup* group = new QParallelAnimationGroup(this);

    m_animationGroup = group;

    for (int index = 0; index < m_tiles.size() && index < targets.size(); ++index) {
        QFrame* host = m_tiles.at(index).host;
        host->show();

        QPropertyAnimation* animation = new QPropertyAnimation(host, "geometry", group);

        animation->setDuration(m_animationDurationMs);
        animation->setStartValue(host->geometry());
        animation->setEndValue(targets.at(index));
        animation->setEasingCurve(QEasingCurve::InOutCubic);
        connectTileGeometryAnimation(animation, m_tiles.at(index).camera);
        group->addAnimation(animation);
    }

    connect(group, &QParallelAnimationGroup::finished, this, [this, group, targets]() {
        for (int index = 0; index < m_tiles.size() && index < targets.size(); ++index) {
            const Tile& tile = m_tiles.at(index);
            setTileGeometry(tile.host, tile.camera, targets.at(index));
        }

        updateVisibilityAfterLayout();
        m_animationGroup.clear();
        group->deleteLater();
        QTimer::singleShot(0, this, [this]() { cleanupRetiringHosts(); });
    });

    group->start(QAbstractAnimation::KeepWhenStopped);
}

void CameraGridWidget::startRemovalAnimation(QFrame* retiringHost, const QVector<QRect>& remainingTargets) {
    QParallelAnimationGroup* group = new QParallelAnimationGroup(this);

    m_animationGroup = group;

    if (retiringHost) {
        QPropertyAnimation* retiringAnimation = new QPropertyAnimation(retiringHost, "geometry", group);

        retiringAnimation->setDuration(m_animationDurationMs);
        retiringAnimation->setStartValue(retiringHost->geometry());
        retiringAnimation->setEndValue(collapsedRect());
        retiringAnimation->setEasingCurve(QEasingCurve::InOutCubic);
        group->addAnimation(retiringAnimation);
    }

    for (int index = 0; index < m_tiles.size() && index < remainingTargets.size(); ++index) {
        QFrame* host = m_tiles.at(index).host;
        host->show();

        QPropertyAnimation* animation = new QPropertyAnimation(host, "geometry", group);

        animation->setDuration(m_animationDurationMs);
        animation->setStartValue(host->geometry());
        animation->setEndValue(remainingTargets.at(index));
        animation->setEasingCurve(QEasingCurve::InOutCubic);
        connectTileGeometryAnimation(animation, m_tiles.at(index).camera);
        group->addAnimation(animation);
    }

    connect(group, &QParallelAnimationGroup::finished, this, [this, group, remainingTargets]() {
        for (int index = 0; index < m_tiles.size() && index < remainingTargets.size(); ++index) {
            const Tile& tile = m_tiles.at(index);
            setTileGeometry(tile.host, tile.camera, remainingTargets.at(index));
        }

        updateVisibilityAfterLayout();
        updateEmptyState();
        m_animationGroup.clear();
        group->deleteLater();
        QTimer::singleShot(0, this, [this]() {
            cleanupRetiringHosts();
            updateEmptyState();
        });
    });

    group->start(QAbstractAnimation::KeepWhenStopped);
}

void CameraGridWidget::stopCurrentAnimation() {
    if (m_animationGroup) {
        QParallelAnimationGroup* group = m_animationGroup;
        m_animationGroup.clear();
        disconnect(group, nullptr, this, nullptr);
        group->stop();
        delete group;
    }

    // A removal transition may have been interrupted by another operation.
    // Finalize those removals immediately to avoid orphaned tile hosts.
    cleanupRetiringHosts();
}

void CameraGridWidget::cleanupRetiringHosts() {
    const QList<QFrame*> retiringHosts = m_retiringHosts;
    m_retiringHosts.clear();

    for (QFrame* host : retiringHosts)
        delete host;
}

void CameraGridWidget::updateVisibilityAfterLayout() {
    if (!m_expandedHost) {
        for (const Tile& tile : m_tiles)
            tile.host->show();

        return;
    }

    for (const Tile& tile : m_tiles) {
        if (tile.host == m_expandedHost) {
            tile.host->show();
            tile.host->raise();
        } else {
            tile.host->hide();
        }
    }
}

void CameraGridWidget::updateEmptyState() {
    const bool empty = m_tiles.isEmpty();

    ui->emptyStateLabel->setVisible(empty);
    ui->emptyStateLabel->setGeometry(ui->cameraArea->contentsRect());

    if (empty)
        ui->emptyStateLabel->raise();
    else
        ui->emptyStateLabel->lower();
}

void CameraGridWidget::fadeInTileHost(QFrame* host) {
    if (!host || kTileFadeInDurationMs <= 0)
        return;

    auto* effect = new QGraphicsOpacityEffect(host);
    effect->setOpacity(0.0);
    host->setGraphicsEffect(effect);

    auto* animation = new QPropertyAnimation(effect, "opacity", host);
    animation->setDuration(kTileFadeInDurationMs);
    animation->setStartValue(0.0);
    animation->setEndValue(1.0);
    animation->setEasingCurve(QEasingCurve::OutCubic);

    connect(animation, &QPropertyAnimation::finished, host, [host]() {
        // Qt owns the effect once installed; clearing deletes it.
        if (host)
            host->setGraphicsEffect(nullptr);
    });

    animation->start(QAbstractAnimation::DeleteWhenStopped);
}
