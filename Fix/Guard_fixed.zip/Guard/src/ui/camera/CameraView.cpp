#include "CameraView.h"
#include "GuardTheme.h"
#include "GuardFontMetrics.h"
#include "model/GuardFaceEventHelpers.h"

#include <hazard/HazardTypes.h>

#include <QMouseEvent>
#include <QMutexLocker>
#include <QPainter>
#include <QPaintEvent>
#include <QPalette>
#include <QPen>
#include <QEvent>

namespace {

void drawStyledLabel(QPainter& painter, const QRect& label, const QString& text, const QColor& color) {
    painter.fillRect(label, QColor(0, 0, 0, 190));
    painter.setPen(color);
    painter.drawText(label, Qt::AlignCenter, text);
}

QFontMetrics boldLabelMetrics(QPainter& painter) {
    QFont font = painter.font();
    font.setBold(true);
    painter.setFont(font);
    return QFontMetrics(font);
}

void drawLabel(QPainter& painter, const QRect& box, const QString& text, const QColor& color) {
    if (box.isEmpty() || text.isEmpty())
        return;

    const QFontMetrics metrics = boldLabelMetrics(painter);
    QRect label(box.x() + 2, box.y() + 2, guardTextWidth(metrics, text) + 10, metrics.height() + 6);
    label.setWidth(qMin(label.width(), qMax(1, box.width() - 4)));
    drawStyledLabel(painter, label, text, color);
}

void drawLabelBelow(QPainter& painter, const QRect& box, const QRect& bounds, const QString& text, const QColor& color) {
    if (box.isEmpty() || text.isEmpty() || bounds.isEmpty())
        return;

    const QFontMetrics metrics = boldLabelMetrics(painter);
    const int labelHeight = metrics.height() + 6;
    const int labelWidth = qMin(guardTextWidth(metrics, text) + 10, qMax(1, bounds.width()));
    int x = box.left();
    if (x + labelWidth > bounds.right() + 1)
        x = bounds.right() - labelWidth + 1;
    x = qMax(bounds.left(), x);

    // Keep the face name outside the detection rectangle. Prefer directly below;
    // when the rectangle touches the image bottom, clamp the label to the lowest
    // available line in the camera widget without drawing it inside the face box.
    int y = box.bottom() + 3;
    if (y + labelHeight > bounds.bottom() + 1)
        y = qMax(box.bottom() + 1, bounds.bottom() - labelHeight + 1);

    drawStyledLabel(painter, QRect(x, y, labelWidth, labelHeight), text, color);
}

QRect normalizedRoiRect(const QRectF& roi, const QRect& target) {
    return QRect(target.x() + static_cast<int>(roi.x() * target.width()), target.y() + static_cast<int>(roi.y() * target.height()),
                 qMax(1, static_cast<int>(roi.width() * target.width())), qMax(1, static_cast<int>(roi.height() * target.height())));
}

}  // namespace

CameraView::CameraView(QWidget* parent) : QWidget(parent) {
    setMinimumSize(160, 90);
    setAttribute(Qt::WA_StyledBackground, true);
    setAutoFillBackground(true);
    QPalette viewPalette = palette();
    viewPalette.setColor(QPalette::Window, GuardTheme::surfaceCanvasColor());
    setPalette(viewPalette);
}

void CameraView::setFrame(const QImage& frame) {
    {
        QMutexLocker locker(&m_frameMutex);
        m_frame = frame;
    }
    update();
}

void CameraView::clearFrame() {
    {
        QMutexLocker locker(&m_frameMutex);
        m_frame = QImage();
        m_faceOverlays.clear();
        m_hazardOverlays.clear();
        m_motionOverlays.clear();
        m_showFaceRoi = false;
        m_showHazardRoi = false;
        m_showMotionRoi = false;
    }
    update();
}

void CameraView::setFaceOverlays(const QVector<CameraFaceOverlay>& overlays, const QRectF& roiNormalized, bool showRoi) {
    {
        QMutexLocker locker(&m_frameMutex);
        m_faceOverlays = overlays;
        m_faceRoi = roiNormalized;
        m_showFaceRoi = showRoi;
    }
    update();
}

void CameraView::setHazardOverlays(const QVector<CameraHazardOverlay>& overlays, const QRectF& roiNormalized, bool showRoi) {
    {
        QMutexLocker locker(&m_frameMutex);
        m_hazardOverlays = overlays;
        m_hazardRoi = roiNormalized;
        m_showHazardRoi = showRoi;
    }
    update();
}

void CameraView::clearHazardOverlays() {
    {
        QMutexLocker locker(&m_frameMutex);
        m_hazardOverlays.clear();
        m_showHazardRoi = false;
    }
    update();
}

void CameraView::setMotionOverlays(const QVector<CameraMotionOverlay>& overlays, const QRectF& roiNormalized, bool showRoi) {
    {
        QMutexLocker locker(&m_frameMutex);
        m_motionOverlays = overlays;
        m_motionRoi = roiNormalized;
        m_showMotionRoi = showRoi;
    }
    update();
}

void CameraView::clearMotionOverlays() {
    {
        QMutexLocker locker(&m_frameMutex);
        m_motionOverlays.clear();
        m_showMotionRoi = false;
    }
    update();
}

void CameraView::clearAllOverlays() {
    {
        QMutexLocker locker(&m_frameMutex);
        m_faceOverlays.clear();
        m_hazardOverlays.clear();
        m_motionOverlays.clear();
        m_showFaceRoi = false;
        m_showHazardRoi = false;
        m_showMotionRoi = false;
    }
    update();
}

void CameraView::setDirectionBadge(CameraDirection direction, bool configured) {
    m_direction = direction;
    m_directionConfigured = configured;
    update();
}

void CameraView::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        update();
    QWidget::changeEvent(event);
}

void CameraView::mouseDoubleClickEvent(QMouseEvent* event) {
    if (event->button() == Qt::LeftButton) {
        emit expandToggleRequested();
        event->accept();
        return;
    }
    QWidget::mouseDoubleClickEvent(event);
}

QRect CameraView::mapOverlayRect(const QRect& bounds, const QRect& targetRect, const QSize& frameSize) {
    if (bounds.isEmpty() || frameSize.width() <= 0 || frameSize.height() <= 0) {
        return QRect();
    }
    const double scaleX = static_cast<double>(targetRect.width()) / frameSize.width();
    const double scaleY = static_cast<double>(targetRect.height()) / frameSize.height();
    return QRect(targetRect.x() + static_cast<int>(bounds.x() * scaleX), targetRect.y() + static_cast<int>(bounds.y() * scaleY),
                 qMax(1, static_cast<int>(bounds.width() * scaleX)), qMax(1, static_cast<int>(bounds.height() * scaleY)));
}

void CameraView::paintEvent(QPaintEvent* event) {
    Q_UNUSED(event);

    QImage frame;
    QVector<CameraFaceOverlay> faceOverlays;
    QVector<CameraHazardOverlay> hazardOverlays;
    QVector<CameraMotionOverlay> motionOverlays;
    QRectF faceRoi;
    QRectF hazardRoi;
    QRectF motionRoi;
    bool showFaceRoi = false;
    bool showHazardRoi = false;
    bool showMotionRoi = false;
    {
        QMutexLocker locker(&m_frameMutex);
        frame = m_frame;
        faceOverlays = m_faceOverlays;
        hazardOverlays = m_hazardOverlays;
        motionOverlays = m_motionOverlays;
        faceRoi = m_faceRoi;
        hazardRoi = m_hazardRoi;
        motionRoi = m_motionRoi;
        showFaceRoi = m_showFaceRoi;
        showHazardRoi = m_showHazardRoi;
        showMotionRoi = m_showMotionRoi;
    }

    QPainter painter(this);
    painter.fillRect(rect(), GuardTheme::surfaceCanvasColor());
    if (frame.isNull()) {
        painter.setPen(GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
        painter.drawText(rect(), Qt::AlignCenter, tr("No camera"));
        return;
    }

    const QSize scaledSize = frame.size().scaled(size(), Qt::KeepAspectRatio);
    QRect targetRect(QPoint(0, 0), scaledSize);
    targetRect.moveCenter(rect().center());
    painter.drawImage(targetRect, frame);
    painter.setRenderHint(QPainter::Antialiasing, true);

    if (showFaceRoi) {
        QPen pen(QColor(255, 196, 0));
        pen.setStyle(Qt::DashLine);
        painter.setPen(pen);
        painter.drawRect(normalizedRoiRect(faceRoi, targetRect));
    }
    if (showHazardRoi) {
        QPen pen(QColor(255, 0, 0));
        pen.setStyle(Qt::DashLine);
        painter.setPen(pen);
        painter.drawRect(normalizedRoiRect(hazardRoi, targetRect));
    }
    if (showMotionRoi) {
        QPen pen(QColor(255, 220, 0));
        pen.setStyle(Qt::DotLine);
        pen.setWidth(2);
        painter.setPen(pen);
        const QRect roiRect = normalizedRoiRect(motionRoi, targetRect);
        painter.drawRect(roiRect);
        drawLabel(painter, roiRect, tr("Motion detection"), QColor(255, 220, 0));
    }

    for (const CameraMotionOverlay& overlay : motionOverlays) {
        const QRect mapped = mapOverlayRect(overlay.bounds, targetRect, frame.size());
        QPen pen(QColor(255, 215, 0));
        pen.setStyle(Qt::DotLine);
        pen.setWidth(2);
        painter.setPen(pen);
        painter.drawRect(mapped);
        drawLabel(painter, mapped, overlay.score > 0.0 ? tr("Motion %1").arg(overlay.score, 0, 'f', 2) : tr("Motion"), Qt::white);
    }

    for (const CameraHazardOverlay& overlay : hazardOverlays) {
        const QRect mapped = mapOverlayRect(overlay.bounds, targetRect, frame.size());
        const bool isFire = overlay.hazardType == static_cast<int>(guardvision::HazardType::Fire);
        QPen pen(QColor(255, 0, 0));
        pen.setWidth(2);
        painter.setPen(pen);
        painter.drawRect(mapped);
        drawLabel(painter, mapped, tr("%1 %2").arg(isFire ? tr("Fire") : tr("Smoke")).arg(overlay.confidence, 0, 'f', 2), Qt::white);
    }

    for (const CameraFaceOverlay& overlay : faceOverlays) {
        const QRect mapped = mapOverlayRect(overlay.bounds, targetRect, frame.size());
        const bool recognized = overlay.identified && overlay.faceRegistryId > 0 && !overlay.displayName.trimmed().isEmpty();
        QPen pen(recognized ? QColor(0, 220, 120) : QColor(245, 158, 11));
        pen.setWidth(2);
        painter.setPen(pen);
        painter.drawRect(mapped);
        const QString label = recognized ? guard::events::faceOverlayLabel(true, overlay.displayName, overlay.identityConfidence) : tr("UNKNOWN");
        drawLabelBelow(painter, mapped, rect(), label, Qt::white);
    }

    if (m_directionConfigured) {
        const QString badgeText = m_direction == CameraDirection::Outgoing ? tr("OUT") : tr("IN");
        QFont badgeFont = painter.font();
        badgeFont.setBold(true);
        badgeFont.setPointSize(qMax(8, badgeFont.pointSize() - 1));
        painter.setFont(badgeFont);
        const QFontMetrics badgeMetrics(badgeFont);
        const int badgeWidth = guardTextWidth(badgeMetrics, badgeText) + 12;
        const int badgeHeight = badgeMetrics.height() + 6;
        const QRect badgeRect(rect().right() - badgeWidth - 8, 8, badgeWidth, badgeHeight);
        painter.fillRect(badgeRect, QColor(15, 23, 42, 210));
        painter.setPen(QColor(148, 163, 184));
        painter.drawRect(badgeRect);
        painter.setPen(GuardTheme::colorFromHex(GuardTheme::kTextPrimary));
        painter.drawText(badgeRect, Qt::AlignCenter, badgeText);
    }
}
