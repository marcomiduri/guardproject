#include "CameraDialog.h"
#include "ui_CameraDialog.h"

#include "GuardComboBox.h"
#include "GuardTheme.h"
#include "GuardMessageDialog.h"
#include "GuardUuid.h"
#include "WindowTitleBar.h"

#include <QAbstractItemView>
#include <QComboBox>
#include <QColor>
#include <QDialogButtonBox>
#include <QEvent>
#include <QGraphicsDropShadowEffect>
#include <QLayout>
#include <QLineEdit>
#include <QPainterPath>
#include <QPushButton>
#include <QRegion>
#include <QResizeEvent>
#include <QShowEvent>
#include <QSpinBox>
#include <QVBoxLayout>

namespace {
constexpr int kDialogCornerRadius = 4;
constexpr const char *kDefaultCameraName = "Camera 1";
constexpr const char *kDefaultCameraAddress = "192.168.1.64";
}  // namespace

CameraDialog::CameraDialog(QWidget *parent) : QDialog(parent), ui(new Ui::CameraDialog) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);
    ui->setupUi(this);
    setObjectName(QStringLiteral("CameraDialog"));

    ui->verticalLayout->setContentsMargins(20, 20, 20, 20);

    auto *shadowHost = new QWidget(this);
    shadowHost->setAttribute(Qt::WA_TranslucentBackground);
    auto *shadowHostLayout = new QVBoxLayout(shadowHost);
    shadowHostLayout->setContentsMargins(0, 0, 0, 0);
    shadowHostLayout->setSpacing(0);

    m_dialogFrame = new QWidget(shadowHost);
    m_dialogFrame->setObjectName(QStringLiteral("dialogFrame"));
    m_dialogFrame->setAttribute(Qt::WA_StyledBackground, true);
    auto *frameLayout = new QVBoxLayout(m_dialogFrame);
    frameLayout->setContentsMargins(0, 0, 0, 0);
    frameLayout->setSpacing(0);

    m_titleBar = new WindowTitleBar(m_dialogFrame, WindowTitleBar::Style::Dialog);
    m_titleBar->setObjectName(QStringLiteral("titleBar"));
    frameLayout->addWidget(m_titleBar, 0, Qt::AlignTop);

    ui->verticalLayout->takeAt(0);
    frameLayout->addWidget(ui->dialogContent);
    shadowHostLayout->addWidget(m_dialogFrame);
    ui->verticalLayout->addWidget(shadowHost);

    auto *shadow = new QGraphicsDropShadowEffect(shadowHost);
    shadow->setBlurRadius(48);
    shadow->setOffset(0, 16);
    shadow->setColor(QColor(2, 6, 23, 140));
    shadowHost->setGraphicsEffect(shadow);

    setDialogTitle(tr("Add Camera"));

    ui->dialogContent->setObjectName(QStringLiteral("dialogContent"));
    ui->contentLayout->setContentsMargins(0, 0, 0, 0);
    ui->contentLayout->setSpacing(0);

    ui->contentLayout->removeItem(ui->contentLayout->itemAt(0));
    auto *formHost = new QWidget(ui->dialogContent);
    auto *formHostLayout = new QVBoxLayout(formHost);
    formHostLayout->setContentsMargins(24, 20, 24, 0);
    formHostLayout->setSpacing(0);
    formHostLayout->addLayout(ui->formLayout);
    formHostLayout->addStretch(1);
    formHost->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
    ui->contentLayout->insertWidget(0, formHost, 1, Qt::AlignTop);

    ui->formLayout->setHorizontalSpacing(16);
    ui->formLayout->setVerticalSpacing(10);
    ui->formLayout->setLabelAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    const int footerIndex = ui->contentLayout->indexOf(ui->buttonBox);
    ui->contentLayout->takeAt(footerIndex);

    auto *footerHost = new QWidget(ui->dialogContent);
    footerHost->setObjectName(QStringLiteral("dialogFooter"));
    footerHost->setAttribute(Qt::WA_StyledBackground, true);
    auto *footerHostLayout = new QVBoxLayout(footerHost);
    footerHostLayout->setContentsMargins(16, 20, 16, 24);
    footerHostLayout->setSpacing(0);

    ui->buttonBox->setObjectName(QStringLiteral("dialogButtonBox"));
    if (QLayout *buttonBoxLayout = ui->buttonBox->layout()) {
        buttonBoxLayout->setContentsMargins(0, 0, 0, 0);
    }
    footerHostLayout->addWidget(ui->buttonBox);
    ui->contentLayout->insertWidget(footerIndex, footerHost);

    ui->nameEdit->setText(tr(kDefaultCameraName));
    ui->addressEdit->setText(QString::fromLatin1(kDefaultCameraAddress));

    styleDialogButtons();
    setStyleSheet(GuardTheme::cameraDialogStyleSheet());
    styleFormComboBoxes();
    setMinimumWidth(500);

    connectSignals();
}

CameraDialog::~CameraDialog() {
    delete ui;
}

void CameraDialog::changeEvent(QEvent *event) {
    if (event->type() == QEvent::LanguageChange)
        ui->retranslateUi(this);
    QDialog::changeEvent(event);
}

void CameraDialog::showEvent(QShowEvent *event) {
    QDialog::showEvent(event);
    updateDialogFrameMask();
}

void CameraDialog::resizeEvent(QResizeEvent *event) {
    QDialog::resizeEvent(event);
    updateDialogFrameMask();
}

void CameraDialog::updateDialogFrameMask() {
    if (!m_dialogFrame) {
        return;
    }

    QPainterPath clipPath;
    clipPath.addRoundedRect(QRectF(m_dialogFrame->rect()).adjusted(0.5, 0.5, -0.5, -0.5), kDialogCornerRadius, kDialogCornerRadius);
    m_dialogFrame->setMask(QRegion(clipPath.toFillPolygon().toPolygon()));
}

void CameraDialog::setDefaultCameraName(const QString &name) {
    if (m_originalCamera.id.trimmed().isEmpty() && !name.trimmed().isEmpty())
        ui->nameEdit->setText(name.trimmed());
}

void CameraDialog::setCamera(const CameraUiModel &camera) {
    m_originalCamera = camera;
    ui->nameEdit->setText(camera.name);
    ui->addressEdit->setText(camera.address);
    ui->portSpinBox->setValue(camera.sdkPort);
    ui->rtspPortSpinBox->setValue(camera.rtspPort);
    ui->usernameEdit->setText(camera.username);
    ui->passwordEdit->setText(camera.password);
    ui->channelSpinBox->setValue(camera.channel);
    ui->rtspUrlEdit->setText(camera.rtspUrl);

    const int typeIndex = ui->typeComboBox->findText(camera.type);
    if (typeIndex >= 0) {
        ui->typeComboBox->setCurrentIndex(typeIndex);
    }

    const int directionIndex = camera.direction == CameraDirection::Outgoing ? 1 : 0;
    ui->directionComboBox->setCurrentIndex(directionIndex);

    const int streamIndex = ui->streamComboBox->findText(camera.stream);
    if (streamIndex >= 0) {
        ui->streamComboBox->setCurrentIndex(streamIndex);
    }
}

CameraUiModel CameraDialog::camera() const {
    CameraUiModel camera = m_originalCamera;
    camera.id = camera.id.isEmpty() ? guardCreateUuidString() : camera.id;
    if (camera.clientCameraId.trimmed().isEmpty()) {
        camera.clientCameraId = camera.id;
    }
    camera.name = ui->nameEdit->text().trimmed();
    camera.type = ui->typeComboBox->currentText();
    camera.direction = ui->directionComboBox->currentIndex() == 1 ? CameraDirection::Outgoing : CameraDirection::Incoming;
    camera.directionConfigured = true;
    camera.address = ui->addressEdit->text().trimmed();
    camera.sdkPort = ui->portSpinBox->value();
    camera.rtspPort = ui->rtspPortSpinBox->value();
    camera.username = ui->usernameEdit->text().trimmed();
    camera.password = ui->passwordEdit->text();
    camera.channel = ui->channelSpinBox->value();
    camera.stream = ui->streamComboBox->currentText();
    camera.rtspUrl = ui->rtspUrlEdit->text().trimmed();
    return camera;
}

void CameraDialog::setDialogTitle(const QString &title) {
    setWindowTitle(title);
    if (m_titleBar) {
        m_titleBar->setTitle(title);
    }
}

void CameraDialog::connectSignals() {
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, [this]() {
        if (validate()) {
            accept();
        }
    });
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
}

void CameraDialog::styleDialogButtons() {
    ui->buttonBox->setCenterButtons(false);

    if (QPushButton *cancelButton = ui->buttonBox->button(QDialogButtonBox::Cancel)) {
        cancelButton->setObjectName(QStringLiteral("cancelButton"));
        cancelButton->setText(tr("Cancel"));
        cancelButton->setAutoDefault(false);
        cancelButton->setDefault(false);
        cancelButton->setFlat(false);
        cancelButton->setFocusPolicy(Qt::NoFocus);
        cancelButton->setCursor(Qt::PointingHandCursor);
        cancelButton->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
    }

    if (QPushButton *okButton = ui->buttonBox->button(QDialogButtonBox::Ok)) {
        okButton->setObjectName(QStringLiteral("okButton"));
        okButton->setText(tr("OK"));
        okButton->setAutoDefault(true);
        okButton->setDefault(true);
        okButton->setFlat(false);
        okButton->setFocusPolicy(Qt::StrongFocus);
        okButton->setCursor(Qt::PointingHandCursor);
        okButton->setStyleSheet(GuardTheme::dialogButtonStyleSheet());
    }
}

void CameraDialog::styleFormComboBoxes() {
    const auto applyComboStyle = [](QComboBox *comboBox) {
        if (!comboBox) {
            return;
        }

        comboBox->setStyleSheet(GuardTheme::cameraDialogComboBoxStyleSheet());
        if (QAbstractItemView *view = comboBox->view()) {
            view->setStyleSheet(GuardTheme::cameraDialogComboBoxPopupStyleSheet());
            if (QWidget *popupFrame = view->window()) {
                popupFrame->setStyleSheet(GuardTheme::cameraDialogComboBoxPopupFrameStyleSheet());
            }
        }
    };

    applyComboStyle(static_cast<GuardComboBox *>(ui->typeComboBox));
    applyComboStyle(static_cast<GuardComboBox *>(ui->directionComboBox));
    applyComboStyle(static_cast<GuardComboBox *>(ui->streamComboBox));
}

bool CameraDialog::validate() {
    if (ui->nameEdit->text().trimmed().isEmpty()) {
        GuardMessageDialog::warning(this, tr("Guard"), tr("Please enter a camera name."));
        ui->nameEdit->setFocus();
        return false;
    }

    if (ui->addressEdit->text().trimmed().isEmpty() && ui->rtspUrlEdit->text().trimmed().isEmpty()) {
        GuardMessageDialog::warning(this, tr("Guard"), tr("Please enter an IP address or RTSP URL."));
        ui->addressEdit->setFocus();
        return false;
    }

    return true;
}
