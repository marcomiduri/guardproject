#ifndef CAMERAVIEW_H
#define CAMERAVIEW_H

#include "CameraUiModel.h"

#include <QImage>
#include <QMutex>
#include <QRectF>
#include <QVector>
#include <QWidget>

class QEvent;

struct CameraFaceOverlay {
    QRect bounds;
    quint64 trackId = 0;
    quint64 faceRegistryId = 0;
    QString displayName;
    double identityConfidence = 0.0;
    bool identified = false;
};

struct CameraHazardOverlay {
    QRect bounds;
    int hazardType = 0;
    double confidence = 0.0;
};

struct CameraMotionOverlay {
    QRect bounds;
    double score = 0.0;
    double changedAreaRatio = 0.0;
};

class CameraView : public QWidget {
    Q_OBJECT

public:
    explicit CameraView(QWidget* parent = nullptr);

public slots:
    void setFrame(const QImage& frame);
    void clearFrame();
    void setFaceOverlays(const QVector<CameraFaceOverlay>& overlays, const QRectF& roiNormalized, bool showRoi);
    void setHazardOverlays(const QVector<CameraHazardOverlay>& overlays, const QRectF& roiNormalized, bool showRoi);
    void clearHazardOverlays();
    void setMotionOverlays(const QVector<CameraMotionOverlay>& overlays, const QRectF& roiNormalized, bool showRoi);
    void clearMotionOverlays();
    void clearAllOverlays();
    void setDirectionBadge(CameraDirection direction, bool configured);

signals:
    void expandToggleRequested();

protected:
    void paintEvent(QPaintEvent* event) override;
    void changeEvent(QEvent* event) override;
    void mouseDoubleClickEvent(QMouseEvent* event) override;

private:
    static QRect mapOverlayRect(const QRect& bounds, const QRect& targetRect, const QSize& frameSize);

    QImage m_frame;
    QVector<CameraFaceOverlay> m_faceOverlays;
    QVector<CameraHazardOverlay> m_hazardOverlays;
    QVector<CameraMotionOverlay> m_motionOverlays;
    QRectF m_faceRoi;
    QRectF m_hazardRoi;
    QRectF m_motionRoi;
    bool m_showFaceRoi = false;
    bool m_showHazardRoi = false;
    bool m_showMotionRoi = false;
    bool m_directionConfigured = false;
    CameraDirection m_direction = CameraDirection::Incoming;
    mutable QMutex m_frameMutex;
};

#endif  // CAMERAVIEW_H
