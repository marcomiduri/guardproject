#ifndef CAMERAWIDGET_H
#define CAMERAWIDGET_H

#include "CameraUiModel.h"

#include <QString>
#include <QTimer>
#include <QWidget>

QT_BEGIN_NAMESPACE
class QEvent;
class QResizeEvent;
class QShowEvent;

namespace Ui {
class CameraWidget;
}
QT_END_NAMESPACE

class CameraView;

class CameraWidget : public QWidget {
    Q_OBJECT

public:
    enum class CameraStatus { Disconnected, Connecting, Connected, Reconnecting, Error };
    Q_ENUM(CameraStatus)

    explicit CameraWidget(QWidget* parent = nullptr);
    ~CameraWidget() override;

    void setCameraId(const QString& cameraId);
    QString cameraId() const;

    void setCameraDisplayName(const QString& displayName);
    QString cameraDisplayName() const;

    void setCameraDirection(CameraDirection direction, bool configured);

    void setCameraStatus(CameraStatus status);
    CameraStatus cameraStatus() const;

    // Convenience method for simple connected/disconnected callers.
    void setConnected(bool connected);

    // Provides access to the central rendering container.
    QWidget* cameraView() const;
    CameraView* renderView() const;

    // The placeholder can be hidden when a real renderer is installed.
    void setCameraViewPlaceholderVisible(bool visible);

    // Re-applies generated and dynamic text after a runtime language change.
    void refreshTranslations();

    // The video viewport is always 16:9. The complete camera card also
    // includes the fixed header and footer heights.
    int cameraViewHeightForWidth(int width) const;
    int cardHeightForWidth(int width) const;

signals:
    void editRequested(const QString& cameraId);
    void removeRequested(const QString& cameraId);

    void settingsRequested(const QString& cameraId);
    void logsRequested(const QString& cameraId);

    void connectRequested(const QString& cameraId);
    void disconnectRequested(const QString& cameraId);

    void expandToggleRequested(const QString& cameraId);

protected:
    bool eventFilter(QObject* watched, QEvent* event) override;
    void changeEvent(QEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private:
    void connectUiSignals();
    void retranslateDynamicUi();
    QString statusLabelText() const;
    void updateDisplayedTitle();
    void updateStatusUi();
    void updateConnectionButtons();
    void updateStatusIndicator();
    void updateStatusBarSize();
    void updateStatusLamp();
    void updateConnectionLampBlink();
    void updateCameraViewAspectRatio();
    int cameraChromeHeight() const;
    void releaseCameraViewLayout();
    void layoutCameraViewContents();
    void scheduleCameraViewLayout();
    void scheduleDisplayedTitleUpdate();

    Ui::CameraWidget* ui;
    CameraView* m_renderView = nullptr;

    QString m_cameraId;
    QString m_cameraDisplayName;
    CameraStatus m_cameraStatus;
    QTimer m_connectionLampBlinkTimer;
    bool m_connectionLampLit = true;
    bool m_cameraViewLayoutPending;
    bool m_titleUpdatePending;
};

#endif  // CAMERAWIDGET_H
