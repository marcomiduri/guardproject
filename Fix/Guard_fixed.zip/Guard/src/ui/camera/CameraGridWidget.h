#ifndef CAMERAGRIDWIDGET_H
#define CAMERAGRIDWIDGET_H

#include <QHash>
#include <QList>
#include <QPointer>
#include <QString>
#include <QVector>
#include <QWidget>

QT_BEGIN_NAMESPACE
class QFrame;
class QParallelAnimationGroup;
class QResizeEvent;

namespace Ui {
class CameraGridWidget;
}
QT_END_NAMESPACE

class CameraWidget;

class CameraGridWidget : public QWidget {
    Q_OBJECT

public:
    explicit CameraGridWidget(QWidget* parent = nullptr);
    ~CameraGridWidget() override;

    // CameraGridWidget takes Qt parent ownership of an accepted widget.
    // The grid supports at most four active camera widgets.
    bool addCameraWidget(CameraWidget* cameraWidget, bool animated = true);

    // Removes and deletes the matching camera widget after the transition.
    // The backend camera should already have been removed successfully.
    bool removeCameraWidget(const QString& cameraId, bool animated = true);

    CameraWidget* cameraWidget(const QString& cameraId) const;
    QList<CameraWidget*> cameraWidgets() const;

    int cameraCount() const;
    int maximumCameraCount() const;

    void clearCameraWidgets();

    // Re-applies translations to the grid and every hosted camera card.
    void refreshTranslations();

    void setAnimationDuration(int durationMs);
    int animationDuration() const;

    void setGridSpacing(int spacing);
    int gridSpacing() const;

    bool isExpanded() const;
    QString expandedCameraId() const;

public slots:
    void toggleExpanded(const QString& cameraId);
    void expandCamera(const QString& cameraId);
    void restoreGrid();

signals:
    // Forwarded when a CameraWidget Remove button is clicked.
    // The controller should remove the backend camera and then call
    // removeCameraWidget(cameraId) after success.
    void cameraRemovalRequested(const QString& cameraId);

    void cameraCountChanged(int count);
    void cameraExpansionChanged(const QString& cameraId, bool expanded);
    void maximumCameraCountReached();

protected:
    void resizeEvent(QResizeEvent* event) override;
    void changeEvent(QEvent* event) override;

private:
    struct Tile {
        QFrame* host = nullptr;
        CameraWidget* camera = nullptr;
    };

    int indexOfCamera(const QString& cameraId) const;
    int indexOfCamera(const CameraWidget* cameraWidget) const;

    QFrame* createTileHost(CameraWidget* cameraWidget);
    QRect usableAreaRect() const;
    QRect collapsedRect() const;
    QVector<QRect> calculateTargetRects() const;

    void applyCurrentLayout(bool animated);
    void startLayoutAnimation(const QVector<QRect>& targets);
    void startRemovalAnimation(QFrame* retiringHost, const QVector<QRect>& remainingTargets);

    void stopCurrentAnimation();
    void cleanupRetiringHosts();
    void updateVisibilityAfterLayout();
    void updateEmptyState();
    void fadeInTileHost(QFrame* host);

    Ui::CameraGridWidget* ui;

    QList<Tile> m_tiles;
    QList<QFrame*> m_retiringHosts;
    QHash<QString, CameraWidget*> m_cameraById;

    QPointer<QFrame> m_expandedHost;
    QPointer<QParallelAnimationGroup> m_animationGroup;

    int m_animationDurationMs;
    int m_gridSpacing;
    int m_outerMargin;
};

#endif  // CAMERAGRIDWIDGET_H
