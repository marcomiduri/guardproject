#include "CameraWidget.h"
#include "ui_CameraWidget.h"

#include "CameraView.h"
#include "GuardFontMetrics.h"
#include "GuardTheme.h"

#include <QEvent>
#include <QFontMetrics>
#include <QLabel>
#include <QLayout>
#include <QMargins>
#include <QMouseEvent>
#include <QPalette>
#include <QPushButton>
#include <QResizeEvent>
#include <QShowEvent>
#include <QTimer>

namespace {
constexpr int kAspectWidth = 16;
constexpr int kAspectHeight = 9;
constexpr int kCameraViewStatusLeftMargin = 8;
constexpr int kCameraViewStatusBottomMargin = 8;
constexpr int kCameraViewStatusHeight = 20;
constexpr int kCameraViewStatusHorizontalMargin = 6;
constexpr int kCameraViewStatusSpacing = 4;
constexpr int kCameraViewStatusBorderWidth = 1;
constexpr int kCameraStatusLampSize = 8;
constexpr int kConnectionLampBlinkMs = 600;
}  // namespace

CameraWidget::CameraWidget(QWidget* parent)
: QWidget(parent),
  ui(new Ui::CameraWidget),
  m_cameraDisplayName(QStringLiteral("Camera 1")),
  m_cameraStatus(CameraStatus::Disconnected),
  m_cameraViewLayoutPending(false),
  m_titleUpdatePending(false) {
    ui->setupUi(this);

    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setAttribute(Qt::WA_StyledBackground, true);
    setAutoFillBackground(true);
    QPalette widgetPalette = palette();
    widgetPalette.setColor(QPalette::Window, GuardTheme::surfaceCanvasColor());
    setPalette(widgetPalette);

    ui->headerWidget->setAttribute(Qt::WA_StyledBackground, true);
    ui->footerWidget->setAttribute(Qt::WA_StyledBackground, true);
    ui->cameraView->setAttribute(Qt::WA_StyledBackground, true);
    ui->cameraView->setAutoFillBackground(true);
    ui->cameraView->setPalette(widgetPalette);
    ui->cameraViewPlaceholderLabel->setAttribute(Qt::WA_TranslucentBackground, false);
    ui->cameraViewPlaceholderLabel->setAutoFillBackground(true);
    ui->cameraViewPlaceholderLabel->setPalette(widgetPalette);
    ui->cameraViewPlaceholderLabel->setStyleSheet(QStringLiteral("background-color: #0b1220; color: #94a3b8;"));

    m_renderView = new CameraView(ui->cameraView);
    m_renderView->setObjectName(QStringLiteral("cameraRenderView"));
    m_renderView->show();

    ui->cameraViewStatusBar->setAttribute(Qt::WA_StyledBackground, true);
    ui->cameraViewStatusBar->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->cameraViewStatusBar->setFixedHeight(kCameraViewStatusHeight);
    ui->cameraViewStatusBar->show();
    ui->cameraViewStatusLayout->setContentsMargins(kCameraViewStatusHorizontalMargin, 0, kCameraViewStatusHorizontalMargin, 0);
    ui->cameraViewStatusLayout->setSpacing(kCameraViewStatusSpacing);
    ui->cameraViewStatusLayout->setAlignment(Qt::AlignCenter);
    ui->statusIndicator->setFixedSize(kCameraStatusLampSize, kCameraStatusLampSize);
    ui->cameraStatusLabel->setTextFormat(Qt::PlainText);
    ui->cameraStatusLabel->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
    ui->cameraStatusLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    m_connectionLampBlinkTimer.setInterval(kConnectionLampBlinkMs);
    connect(&m_connectionLampBlinkTimer, &QTimer::timeout, this, &CameraWidget::updateConnectionLampBlink);

    releaseCameraViewLayout();

    // The placeholder label occupies the camera-view area in the supplied .ui,
    // so both objects receive the double-click event filter.
    ui->cameraView->installEventFilter(this);
    ui->cameraViewPlaceholderLabel->installEventFilter(this);
    m_renderView->installEventFilter(this);

    connect(m_renderView, &CameraView::expandToggleRequested, this, [this]() { emit expandToggleRequested(m_cameraId); });

    connectUiSignals();
    updateDisplayedTitle();
    updateStatusUi();
    updateCameraViewAspectRatio();
    scheduleCameraViewLayout();
}

CameraWidget::~CameraWidget() {
    delete ui;
}

void CameraWidget::setCameraId(const QString& cameraId) {
    m_cameraId = cameraId;
}

QString CameraWidget::cameraId() const {
    return m_cameraId;
}

void CameraWidget::setCameraDisplayName(const QString& displayName) {
    if (m_cameraDisplayName == displayName)
        return;

    m_cameraDisplayName = displayName;
    ui->cameraTitleLabel->setToolTip(m_cameraDisplayName);
    updateDisplayedTitle();
}

void CameraWidget::setCameraDirection(CameraDirection direction, bool configured) {
    if (m_renderView)
        m_renderView->setDirectionBadge(direction, configured);
}

QString CameraWidget::cameraDisplayName() const {
    return m_cameraDisplayName;
}

void CameraWidget::setCameraStatus(CameraStatus status) {
    if (m_cameraStatus == status)
        return;

    m_cameraStatus = status;
    updateStatusUi();
}

CameraWidget::CameraStatus CameraWidget::cameraStatus() const {
    return m_cameraStatus;
}

void CameraWidget::setConnected(bool connected) {
    setCameraStatus(connected ? CameraStatus::Connected : CameraStatus::Disconnected);
}

QWidget* CameraWidget::cameraView() const {
    return ui->cameraView;
}

CameraView* CameraWidget::renderView() const {
    return m_renderView;
}

void CameraWidget::setCameraViewPlaceholderVisible(bool visible) {
    ui->cameraViewPlaceholderLabel->setVisible(visible);
}

void CameraWidget::refreshTranslations() {
    ui->retranslateUi(this);
    retranslateDynamicUi();
}

int CameraWidget::cameraViewHeightForWidth(int width) const {
    if (width <= 0) {
        return 0;
    }

    // Rounded integer form of width * 9 / 16.
    return (width * kAspectHeight + (kAspectWidth / 2)) / kAspectWidth;
}

int CameraWidget::cardHeightForWidth(int width) const {
    return cameraChromeHeight() + cameraViewHeightForWidth(width);
}

bool CameraWidget::eventFilter(QObject* watched, QEvent* event) {
    if (watched == ui->cameraView && event->type() == QEvent::Resize) {
        scheduleCameraViewLayout();
    }

    const bool isCameraViewObject = watched == ui->cameraView || watched == ui->cameraViewPlaceholderLabel || watched == m_renderView;

    if (isCameraViewObject && event->type() == QEvent::MouseButtonDblClick) {
        QMouseEvent* mouseEvent = static_cast<QMouseEvent*>(event);

        if (mouseEvent->button() == Qt::LeftButton) {
            emit expandToggleRequested(m_cameraId);
            return true;
        }
    }

    return QWidget::eventFilter(watched, event);
}

void CameraWidget::showEvent(QShowEvent* event) {
    QWidget::showEvent(event);
    scheduleCameraViewLayout();
}

void CameraWidget::resizeEvent(QResizeEvent* event) {
    QWidget::resizeEvent(event);
    updateCameraViewAspectRatio();
    scheduleDisplayedTitleUpdate();
}

void CameraWidget::updateCameraViewAspectRatio() {
    const int viewHeight = cameraViewHeightForWidth(width());

    if (viewHeight <= 0) {
        return;
    }

    // The vertical card layout controls the viewport width. Constrain only
    // its height so the viewport itself remains 16:9 and spans the card.
    if (ui->cameraView->height() != viewHeight || ui->cameraView->minimumHeight() != viewHeight || ui->cameraView->maximumHeight() != viewHeight) {
        ui->cameraView->setFixedHeight(viewHeight);
    }

    scheduleCameraViewLayout();
}

int CameraWidget::cameraChromeHeight() const {
    if (!ui) {
        return 0;
    }

    const int headerHeight = qMax(ui->headerWidget->minimumHeight(), ui->headerWidget->sizeHint().height());
    const int footerHeight = qMax(ui->footerWidget->minimumHeight(), ui->footerWidget->sizeHint().height());

    const QMargins margins = ui->mainVerticalLayout->contentsMargins();
    const int spacing = qMax(0, ui->mainVerticalLayout->spacing());

    // Three widgets (header, camera view, footer) create two layout gaps.
    return headerHeight + footerHeight + margins.top() + margins.bottom() + (2 * spacing);
}

void CameraWidget::releaseCameraViewLayout() {
    QLayout* layout = ui->cameraView->layout();

    if (!layout) {
        return;
    }

    while (QLayoutItem* item = layout->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            widget->setParent(ui->cameraView);
        }

        delete item;
    }

    delete layout;
}

void CameraWidget::scheduleCameraViewLayout() {
    if (m_cameraViewLayoutPending)
        return;

    m_cameraViewLayoutPending = true;
    QTimer::singleShot(0, this, [this]() {
        m_cameraViewLayoutPending = false;
        layoutCameraViewContents();
    });
}

void CameraWidget::scheduleDisplayedTitleUpdate() {
    if (m_titleUpdatePending)
        return;

    m_titleUpdatePending = true;
    QTimer::singleShot(0, this, [this]() {
        m_titleUpdatePending = false;
        updateDisplayedTitle();
    });
}

void CameraWidget::layoutCameraViewContents() {
    QFrame* cameraView = ui->cameraView;

    if (!cameraView) {
        return;
    }

    const QRect viewRect = cameraView->rect();

    if (viewRect.width() <= 0 || viewRect.height() <= 0) {
        return;
    }

    ui->cameraViewPlaceholderLabel->setGeometry(viewRect);
    ui->cameraViewPlaceholderLabel->lower();

    if (m_renderView) {
        m_renderView->setGeometry(viewRect);
        m_renderView->raise();
    }

    if (ui->cameraViewStatusBar) {
        const int x = kCameraViewStatusLeftMargin;
        const int y = qMax(0, viewRect.height() - kCameraViewStatusHeight - kCameraViewStatusBottomMargin);

        ui->cameraViewStatusBar->setGeometry(x, y, ui->cameraViewStatusBar->width(), kCameraViewStatusHeight);
        ui->cameraViewStatusBar->show();
        ui->cameraViewStatusBar->raise();
    }
}

void CameraWidget::connectUiSignals() {
    connect(ui->editButton, &QPushButton::clicked, this, [this]() { emit editRequested(m_cameraId); });

    connect(ui->removeButton, &QPushButton::clicked, this, [this]() { emit removeRequested(m_cameraId); });

    connect(ui->settingsButton, &QPushButton::clicked, this, [this]() { emit settingsRequested(m_cameraId); });

    connect(ui->logsButton, &QPushButton::clicked, this, [this]() { emit logsRequested(m_cameraId); });

    connect(ui->connectButton, &QPushButton::clicked, this, [this]() { emit connectRequested(m_cameraId); });

    connect(ui->disconnectButton, &QPushButton::clicked, this, [this]() { emit disconnectRequested(m_cameraId); });
}

void CameraWidget::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        refreshTranslations();
    QWidget::changeEvent(event);
}

void CameraWidget::retranslateDynamicUi() {
    updateStatusIndicator();
    updateDisplayedTitle();
}

QString CameraWidget::statusLabelText() const {
    switch (m_cameraStatus) {
        case CameraStatus::Connecting:
            return tr("CONNECTING");
        case CameraStatus::Connected:
            return tr("CONNECTED");
        case CameraStatus::Reconnecting:
            return tr("RECONNECTING");
        case CameraStatus::Error:
            return tr("ERROR");
        case CameraStatus::Disconnected:
        default:
            return tr("DISCONNECTED");
    }
}

void CameraWidget::updateDisplayedTitle() {
    if (m_cameraDisplayName.isEmpty()) {
        ui->cameraTitleLabel->clear();
        ui->cameraTitleLabel->setToolTip(QString());
        return;
    }

    const int availableWidth = ui->cameraTitleLabel->contentsRect().width();

    if (availableWidth <= 0)
        return;

    const QFontMetrics metrics(ui->cameraTitleLabel->font());
    const QString visibleTitle = metrics.elidedText(m_cameraDisplayName, Qt::ElideRight, availableWidth);

    ui->cameraTitleLabel->setText(visibleTitle);
    ui->cameraTitleLabel->setToolTip(m_cameraDisplayName);
}

void CameraWidget::updateStatusUi() {
    updateStatusIndicator();
    updateConnectionButtons();
    scheduleCameraViewLayout();
    scheduleDisplayedTitleUpdate();
}

void CameraWidget::updateConnectionButtons() {
    bool connectEnabled = false;
    bool disconnectEnabled = false;
    bool settingsEnabled = true;

    switch (m_cameraStatus) {
        case CameraStatus::Disconnected:
            connectEnabled = true;
            disconnectEnabled = false;
            break;

        case CameraStatus::Connecting:
            connectEnabled = false;
            disconnectEnabled = true;
            settingsEnabled = false;
            break;

        case CameraStatus::Connected:
            connectEnabled = false;
            disconnectEnabled = true;
            break;

        case CameraStatus::Reconnecting:
            connectEnabled = false;
            disconnectEnabled = true;
            settingsEnabled = false;
            break;

        case CameraStatus::Error:
            connectEnabled = true;
            disconnectEnabled = false;
            break;
    }

    ui->connectButton->setEnabled(connectEnabled);
    ui->disconnectButton->setEnabled(disconnectEnabled);
    ui->settingsButton->setEnabled(settingsEnabled);
}

void CameraWidget::updateStatusIndicator() {
    const bool connected = m_cameraStatus == CameraStatus::Connected;

    if (connected) {
        if (!m_connectionLampBlinkTimer.isActive()) {
            m_connectionLampLit = true;
            m_connectionLampBlinkTimer.start();
        }
    } else {
        m_connectionLampBlinkTimer.stop();
        m_connectionLampLit = true;
    }

    ui->cameraViewStatusBar->setVisible(true);
    ui->cameraStatusLabel->setText(statusLabelText());
    updateStatusBarSize();

    updateStatusLamp();
    ui->cameraViewStatusBar->raise();
    scheduleCameraViewLayout();
}

void CameraWidget::updateStatusBarSize() {
    const QFontMetrics metrics(ui->cameraStatusLabel->font());
    const int textWidth = qMax(1, guardTextWidth(metrics, ui->cameraStatusLabel->text()));
    ui->cameraStatusLabel->setFixedWidth(textWidth);

    const QMargins margins = ui->cameraViewStatusLayout->contentsMargins();
    const int width = margins.left() + kCameraStatusLampSize + ui->cameraViewStatusLayout->spacing() + textWidth + margins.right() +
                      (2 * kCameraViewStatusBorderWidth);
    ui->cameraViewStatusBar->setFixedSize(width, kCameraViewStatusHeight);
}

void CameraWidget::updateStatusLamp() {
    const bool connected = m_cameraStatus == CameraStatus::Connected;
    const QColor lampColor =
      connected ? (m_connectionLampLit ? GuardTheme::successColor() : GuardTheme::successColor().darker(180)) : GuardTheme::dangerColor();

    ui->statusIndicator->setStyleSheet(QStringLiteral("QFrame#statusIndicator {"
                                                      "background-color: %1;"
                                                      "border: 0px;"
                                                      "border-radius: 4px;"
                                                      "}")
                                         .arg(lampColor.name()));
}

void CameraWidget::updateConnectionLampBlink() {
    m_connectionLampLit = !m_connectionLampLit;
    updateStatusLamp();
}
