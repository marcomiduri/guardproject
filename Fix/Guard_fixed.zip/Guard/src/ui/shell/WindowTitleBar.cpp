#include "WindowTitleBar.h"

#include <QDialog>
#include <QEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QMainWindow>
#include <QMouseEvent>
#include <QPushButton>

namespace {

constexpr int kChromeButtonWidth = 40;
constexpr int kChromeButtonHeight = 28;
constexpr int kMainTitleBarHeight = 29;
constexpr int kMainChromeInset = 1;
constexpr int kDialogTitleBarHeight = 32;

QPushButton *createChromeButton(const QString &text, const QString &objectName, QWidget *parent) {
    auto *button = new QPushButton(text, parent);
    button->setObjectName(objectName);
    button->setFixedSize(kChromeButtonWidth, kChromeButtonHeight);
    button->setFlat(false);
    button->setFocusPolicy(Qt::NoFocus);
    return button;
}

QPushButton *createCloseButton(QWidget *parent) {
    auto *closeButton = new QPushButton(QString(QChar(0x00D7)), parent);
    closeButton->setObjectName(QStringLiteral("titleBarCloseButton"));
    closeButton->setFixedSize(kChromeButtonWidth, kChromeButtonHeight);
    closeButton->setFlat(false);
    closeButton->setFocusPolicy(Qt::NoFocus);
    return closeButton;
}

QPushButton *createDialogCloseButton(QWidget *parent) {
    auto *closeButton = new QPushButton(QString(QChar(0x00D7)), parent);
    closeButton->setObjectName(QStringLiteral("dialogTitleBarCloseButton"));
    closeButton->setFixedSize(kChromeButtonWidth, kChromeButtonHeight);
    closeButton->setFlat(false);
    closeButton->setFocusPolicy(Qt::NoFocus);
    return closeButton;
}

}  // namespace

WindowTitleBar::WindowTitleBar(QWidget *parent, Style style) : QWidget(parent), m_style(style) {
    const int barHeight = m_style == Style::Dialog ? kDialogTitleBarHeight : kMainTitleBarHeight;
    const int verticalPadding = m_style == Style::Dialog ? 3 : 0;
    setFixedHeight(barHeight);
    setAttribute(Qt::WA_StyledBackground, true);

    auto *layout = new QHBoxLayout(this);
    const int rightMargin = m_style == Style::Dialog ? 0 : kMainChromeInset;
    const int topMargin = m_style == Style::Dialog ? 0 : 0;
    const int bottomMargin = m_style == Style::Dialog ? verticalPadding : kMainChromeInset;
    layout->setContentsMargins(12, topMargin, rightMargin, bottomMargin);
    layout->setSpacing(0);

    auto *titleLabel = new QLabel(m_style == Style::MainWindow ? tr("Guard") : tr("Dialog"), this);
    titleLabel->setObjectName(QStringLiteral("appTitleLabel"));
    titleLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    layout->addWidget(titleLabel, 1, m_style == Style::Dialog ? Qt::AlignVCenter : Qt::Alignment());

    if (m_style == Style::MainWindow) {
        auto *minimizeButton = createChromeButton(QString(QChar(0x2212)), QStringLiteral("titleBarMinimizeButton"), this);
        m_maximizeButton = createChromeButton(QString(QChar(0x25A1)), QStringLiteral("titleBarMaximizeButton"), this);
        auto *closeButton = createCloseButton(this);

        layout->addWidget(minimizeButton);
        layout->addWidget(m_maximizeButton);
        layout->addWidget(closeButton);

        connect(minimizeButton, &QPushButton::clicked, this, &WindowTitleBar::onMinimizeClicked);
        connect(m_maximizeButton, &QPushButton::clicked, this, &WindowTitleBar::onMaximizeClicked);
        connect(closeButton, &QPushButton::clicked, this, &WindowTitleBar::onCloseClicked);

        if (QMainWindow *window = mainWindow()) {
            window->installEventFilter(this);
        }

        syncMaximizeButton();
        return;
    }

    auto *closeButton = createDialogCloseButton(this);
    layout->addWidget(closeButton, 0, Qt::AlignTop);
    connect(closeButton, &QPushButton::clicked, this, &WindowTitleBar::onCloseClicked);
}

void WindowTitleBar::setTitle(const QString &title) {
    if (auto *titleLabel = findChild<QLabel *>(QStringLiteral("appTitleLabel"))) {
        titleLabel->setText(title);
    }
}

void WindowTitleBar::changeEvent(QEvent *event) {
    if (event->type() == QEvent::LanguageChange)
        syncMaximizeButton();
    QWidget::changeEvent(event);
}

bool WindowTitleBar::eventFilter(QObject *watched, QEvent *event) {
    if (watched == mainWindow() && event->type() == QEvent::WindowStateChange) {
        syncMaximizeButton();
    }

    return QWidget::eventFilter(watched, event);
}

void WindowTitleBar::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        if (QWidget *window = hostWindow()) {
            m_dragPosition = event->globalPos() - window->frameGeometry().topLeft();
        }
        event->accept();
        return;
    }

    QWidget::mousePressEvent(event);
}

void WindowTitleBar::mouseMoveEvent(QMouseEvent *event) {
    if ((event->buttons() & Qt::LeftButton) == 0) {
        QWidget::mouseMoveEvent(event);
        return;
    }

    if (QWidget *window = hostWindow()) {
        if (window->isMaximized() || window->isFullScreen()) {
            event->accept();
            return;
        }
        window->move(event->globalPos() - m_dragPosition);
    }

    event->accept();
}

void WindowTitleBar::mouseDoubleClickEvent(QMouseEvent *event) {
    if (m_style != Style::MainWindow) {
        QWidget::mouseDoubleClickEvent(event);
        return;
    }

    if (event->button() == Qt::LeftButton) {
        toggleMaximize();
        event->accept();
        return;
    }

    QWidget::mouseDoubleClickEvent(event);
}

void WindowTitleBar::onMinimizeClicked() {
    if (m_style == Style::MainWindow) {
        emit minimizeRequested();
        return;
    }

    if (QMainWindow *window = mainWindow()) {
        window->showMinimized();
    }
}

void WindowTitleBar::onMaximizeClicked() {
    toggleMaximize();
}

void WindowTitleBar::onCloseClicked() {
    if (QWidget *window = hostWindow()) {
        if (auto *dialog = qobject_cast<QDialog *>(window)) {
            dialog->reject();
            return;
        }
        if (m_style == Style::MainWindow) {
            emit closeRequested();
            return;
        }
        window->close();
    }
}

void WindowTitleBar::syncMaximizeButton() {
    if (!m_maximizeButton) {
        return;
    }

    if (QMainWindow *window = mainWindow()) {
        const bool expanded = window->isFullScreen() || window->isMaximized();
        m_maximizeButton->setText(expanded ? QString(QChar(0x29C9)) : QString(QChar(0x25A1)));
        m_maximizeButton->setToolTip(expanded ? tr("Restore") : tr("Maximize"));
    }
}

QWidget *WindowTitleBar::hostWindow() const {
    return window();
}

QMainWindow *WindowTitleBar::mainWindow() const {
    return qobject_cast<QMainWindow *>(hostWindow());
}

void WindowTitleBar::toggleMaximize() {
    QMainWindow *window = mainWindow();
    if (!window) {
        return;
    }

    if (window->isFullScreen() || window->isMaximized()) {
        window->showNormal();
    } else {
        window->showFullScreen();
    }

    syncMaximizeButton();
}
