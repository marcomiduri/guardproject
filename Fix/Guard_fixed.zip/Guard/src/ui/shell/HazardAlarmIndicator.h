#ifndef HAZARDALARMINDICATOR_H
#define HAZARDALARMINDICATOR_H

#include <QWidget>

class QPaintEvent;
class QPushButton;
class QTimer;

class HazardAlarmIndicator : public QWidget {
    Q_OBJECT

public:
    explicit HazardAlarmIndicator(QWidget* parent = nullptr);

    void setActive(bool active);

signals:
    void acknowledgeRequested();
    void dismissRequested();

protected:
    void changeEvent(QEvent* event) override;
    void paintEvent(QPaintEvent* event) override;

private slots:
    void onBlinkTick();

private:
    void retranslateUi();
    void applyBlinkPhase();
    void updateContentWidth();

    QWidget* lampWidget_ = nullptr;
    QPushButton* silenceButton_ = nullptr;
    QPushButton* closeButton_ = nullptr;
    QTimer* blinkTimer_ = nullptr;
    bool active_ = false;
    bool redBackgroundPhase_ = true;
};

#endif  // HAZARDALARMINDICATOR_H
