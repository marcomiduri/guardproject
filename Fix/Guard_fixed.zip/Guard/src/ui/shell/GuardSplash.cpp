#include "GuardSplash.h"

#include "GuardTheme.h"

#include <QApplication>
#include <QCoreApplication>
#include <QEasingCurve>
#include <QEventLoop>
#include <QPixmap>
#include <QPointer>
#include <QPropertyAnimation>
#include <QScreen>
#include <QTimer>

namespace {

QPixmap buildSplashPixmap() {
    QPixmap source(QStringLiteral(":/splash.png"));
    if (source.isNull()) {
        QPixmap fallback(480, 300);
        fallback.fill(GuardTheme::surfaceCanvasColor());
        return fallback;
    }

    constexpr int kMaxWidth = 720;
    if (source.width() > kMaxWidth) {
        source = source.scaledToWidth(kMaxWidth, Qt::SmoothTransformation);
    }
    return source;
}

}  // namespace

GuardSplash::GuardSplash() : QSplashScreen(buildSplashPixmap(), Qt::WindowStaysOnTopHint) {
    if (QScreen* screen = QApplication::primaryScreen()) {
        const QRect available = screen->availableGeometry();
        move(available.x() + (available.width() - width()) / 2, available.y() + (available.height() - height()) / 2);
    }
}

void GuardSplash::showWithFadeIn(int fadeDurationMs) {
    visibleSince_.start();
    setWindowOpacity(0.0);
    QSplashScreen::show();
    QApplication::processEvents(QEventLoop::ExcludeUserInputEvents);

    auto* animation = new QPropertyAnimation(this, "windowOpacity", this);
    animation->setDuration(fadeDurationMs);
    animation->setStartValue(0.0);
    animation->setEndValue(1.0);
    animation->setEasingCurve(QEasingCurve::OutCubic);
    animation->start(QAbstractAnimation::DeleteWhenStopped);
}

void GuardSplash::setStatusMessage(const QString& message) {
    showMessage(message, Qt::AlignBottom | Qt::AlignHCenter, GuardTheme::colorFromHex(GuardTheme::kPrimary));
}

void GuardSplash::finishSplash(QWidget* mainWindow, bool testMode, int fadeOutMs) {
    if (!mainWindow) {
        return;
    }

    const int minimumVisibleMs = testMode ? kTestModeMinimumVisibleMs : kDefaultMinimumVisibleMs;
    const int remainingMs = qMax(0, minimumVisibleMs - static_cast<int>(visibleSince_.elapsed()));
    const QPointer<QWidget> windowGuard(mainWindow);

    const auto beginFinish = [this, windowGuard, fadeOutMs]() {
        if (!windowGuard)
            return;

        windowGuard->show();
        windowGuard->raise();
        windowGuard->activateWindow();

        if (fadeOutMs <= 0) {
            finish(windowGuard);
            return;
        }

        auto* animation = new QPropertyAnimation(this, "windowOpacity", this);
        animation->setDuration(fadeOutMs);
        animation->setStartValue(windowOpacity());
        animation->setEndValue(0.0);
        animation->setEasingCurve(QEasingCurve::InCubic);
        QObject::connect(animation, &QPropertyAnimation::finished, this, [this, windowGuard]() {
            if (windowGuard)
                finish(windowGuard);
        });
        animation->start(QAbstractAnimation::DeleteWhenStopped);
    };

    if (remainingMs > 0)
        QTimer::singleShot(remainingMs, this, beginFinish);
    else
        beginFinish();
}
