#ifndef WINDOWTITLEBAR_H
#define WINDOWTITLEBAR_H

#include <QPoint>
#include <QString>
#include <QWidget>

class QEvent;
class QMainWindow;
class QMouseEvent;
class QPushButton;

class WindowTitleBar : public QWidget {
    Q_OBJECT

public:
    enum class Style {
        MainWindow,
        Dialog,
    };

    explicit WindowTitleBar(QWidget *parent = nullptr, Style style = Style::MainWindow);

    void setTitle(const QString &title);

signals:
    void minimizeRequested();
    void closeRequested();

protected:
    void changeEvent(QEvent *event) override;
    bool eventFilter(QObject *watched, QEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseDoubleClickEvent(QMouseEvent *event) override;

private slots:
    void onMinimizeClicked();
    void onMaximizeClicked();
    void onCloseClicked();
    void syncMaximizeButton();

private:
    QWidget *hostWindow() const;
    QMainWindow *mainWindow() const;
    void toggleMaximize();

    Style m_style = Style::MainWindow;
    QPoint m_dragPosition;
    QPushButton *m_maximizeButton = nullptr;
};

#endif  // WINDOWTITLEBAR_H
