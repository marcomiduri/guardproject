#include "HazardAlarmIndicator.h"

#include "platform/compat/GuardFontMetrics.h"

#include <QEvent>
#include <QFontMetrics>
#include <QHBoxLayout>
#include <QPainter>
#include <QPaintEvent>
#include <QPushButton>
#include <QSizePolicy>
#include <QTimer>

namespace {

constexpr int kLampDiameter = 8;
constexpr int kCloseButtonWidth = 16;
constexpr int kBlinkIntervalMs = 500;
constexpr int kIndicatorHeight = 24;
constexpr int kHorizontalPadding = 8;
constexpr int kVerticalPadding = 2;
constexpr int kContentSpacing = 6;
constexpr int kLabelFontPixelSize = 10;
constexpr int kButtonHorizontalPadding = 8;
constexpr int kWidthSafetyMargin = 4;
constexpr qreal kCornerRadius = 5.0;

class HazardAlarmLamp : public QWidget {
public:
    explicit HazardAlarmLamp(QWidget* parent = nullptr) : QWidget(parent) {
        setFixedSize(kLampDiameter, kLampDiameter);
        setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    }

    void setLampColor(const QColor& color) {
        if (lampColor_ == color)
            return;
        lampColor_ = color;
        update();
    }

protected:
    void paintEvent(QPaintEvent* event) override {
        QWidget::paintEvent(event);

        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);
        const QRectF lampRect = QRectF(rect()).adjusted(0.75, 0.75, -0.75, -0.75);
        painter.setPen(QPen(QColor(255, 255, 255, 210), 1.0));
        painter.setBrush(lampColor_);
        painter.drawEllipse(lampRect);
    }

private:
    QColor lampColor_ = QColor(QStringLiteral("#fde047"));
};

HazardAlarmLamp* asLamp(QWidget* widget) {
    return static_cast<HazardAlarmLamp*>(widget);
}

}  // namespace

HazardAlarmIndicator::HazardAlarmIndicator(QWidget* parent) : QWidget(parent) {
    setObjectName(QStringLiteral("hazardAlarmIndicator"));
    setAttribute(Qt::WA_TranslucentBackground, true);
    setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Fixed);
    setFixedHeight(kIndicatorHeight);
    hide();

    auto* layout = new QHBoxLayout(this);
    layout->setContentsMargins(kHorizontalPadding, kVerticalPadding, kHorizontalPadding, kVerticalPadding);
    layout->setSpacing(kContentSpacing);

    lampWidget_ = new HazardAlarmLamp(this);
    lampWidget_->setObjectName(QStringLiteral("hazardAlarmLamp"));
    lampWidget_->setToolTip(tr("Hazard alarm active"));
    layout->addWidget(lampWidget_, 0, Qt::AlignVCenter);

    silenceButton_ = new QPushButton(this);
    silenceButton_->setObjectName(QStringLiteral("silenceAlarmButton"));
    silenceButton_->setCursor(Qt::PointingHandCursor);
    silenceButton_->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    connect(silenceButton_, &QPushButton::clicked, this, &HazardAlarmIndicator::acknowledgeRequested);
    layout->addWidget(silenceButton_, 0, Qt::AlignVCenter);

    closeButton_ = new QPushButton(QString(QChar(0x00D7)), this);
    closeButton_->setObjectName(QStringLiteral("dismissAlarmButton"));
    closeButton_->setFixedSize(kCloseButtonWidth, kIndicatorHeight - kVerticalPadding * 2);
    closeButton_->setCursor(Qt::PointingHandCursor);
    closeButton_->setFocusPolicy(Qt::NoFocus);
    closeButton_->setFlat(true);
    connect(closeButton_, &QPushButton::clicked, this, &HazardAlarmIndicator::dismissRequested);
    layout->addWidget(closeButton_, 0, Qt::AlignVCenter);

    blinkTimer_ = new QTimer(this);
    blinkTimer_->setInterval(kBlinkIntervalMs);
    connect(blinkTimer_, &QTimer::timeout, this, &HazardAlarmIndicator::onBlinkTick);

    retranslateUi();
    applyBlinkPhase();
}

void HazardAlarmIndicator::setActive(bool active) {
    if (active_ == active) {
        if (active) {
            applyBlinkPhase();
            if (blinkTimer_ && !blinkTimer_->isActive())
                blinkTimer_->start();
        }
        return;
    }

    active_ = active;
    setVisible(active);
    if (active) {
        redBackgroundPhase_ = true;
        applyBlinkPhase();
        if (blinkTimer_)
            blinkTimer_->start();
    } else if (blinkTimer_) {
        blinkTimer_->stop();
    }
}

void HazardAlarmIndicator::onBlinkTick() {
    if (!active_)
        return;
    redBackgroundPhase_ = !redBackgroundPhase_;
    applyBlinkPhase();
}

void HazardAlarmIndicator::applyBlinkPhase() {
    const QColor lampColor = redBackgroundPhase_ ? QColor(QStringLiteral("#fde047")) : QColor(QStringLiteral("#ef4444"));
    if (lampWidget_)
        asLamp(lampWidget_)->setLampColor(lampColor);

    if (silenceButton_) {
        const QString textColor = redBackgroundPhase_ ? QStringLiteral("#ffffff") : QStringLiteral("#3f2d00");
        silenceButton_->setStyleSheet(QStringLiteral("QPushButton#silenceAlarmButton {"
                                                     " background: transparent;"
                                                     " color: %1;"
                                                     " border: none;"
                                                     " border-radius: 3px;"
                                                     " padding: 0px 4px;"
                                                     " font-weight: 700;"
                                                     "}"
                                                     "QPushButton#silenceAlarmButton:hover { background: rgba(255,255,255,42); }"
                                                     "QPushButton#silenceAlarmButton:pressed { background: rgba(0,0,0,42); }")
                                        .arg(textColor));
    }

    if (closeButton_) {
        const QString textColor = redBackgroundPhase_ ? QStringLiteral("#ffffff") : QStringLiteral("#3f2d00");
        closeButton_->setStyleSheet(QStringLiteral("QPushButton#dismissAlarmButton {"
                                                   " background: transparent;"
                                                   " color: %1;"
                                                   " border: none;"
                                                   " border-radius: 3px;"
                                                   " font-size: 14px;"
                                                   " font-weight: 700;"
                                                   " padding: 0px;"
                                                   " min-width: 0px;"
                                                   "}"
                                                   "QPushButton#dismissAlarmButton:hover { background: rgba(255,255,255,42); }"
                                                   "QPushButton#dismissAlarmButton:pressed { background: rgba(0,0,0,42); }")
                                      .arg(textColor));
    }
    update();
}

void HazardAlarmIndicator::paintEvent(QPaintEvent* event) {
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    const QRectF outer = QRectF(rect()).adjusted(1.5, 1.5, -1.5, -1.5);
    const QColor background = redBackgroundPhase_ ? QColor(QStringLiteral("#dc2626")) : QColor(QStringLiteral("#facc15"));
    const QColor border = redBackgroundPhase_ ? QColor(QStringLiteral("#f87171")) : QColor(QStringLiteral("#f59e0b"));

    QColor glow = background;
    glow.setAlpha(65);
    painter.setBrush(Qt::NoBrush);
    painter.setPen(QPen(glow, 3.0));
    painter.drawRoundedRect(outer, kCornerRadius, kCornerRadius);

    painter.setPen(QPen(border, 1.0));
    painter.setBrush(background);
    painter.drawRoundedRect(outer, kCornerRadius, kCornerRadius);
}

void HazardAlarmIndicator::changeEvent(QEvent* event) {
    if (event->type() == QEvent::LanguageChange)
        retranslateUi();
    QWidget::changeEvent(event);
}

void HazardAlarmIndicator::retranslateUi() {
    if (silenceButton_) {
        silenceButton_->setText(tr("Fire/smoke alarm"));
        QFont labelFont = silenceButton_->font();
        labelFont.setBold(true);
        labelFont.setPixelSize(kLabelFontPixelSize);
        silenceButton_->setFont(labelFont);
    }
    if (lampWidget_)
        lampWidget_->setToolTip(tr("Hazard alarm active"));
    if (closeButton_)
        closeButton_->setToolTip(tr("Dismiss hazard indicator and alarm"));
    applyBlinkPhase();
    updateContentWidth();
}

void HazardAlarmIndicator::updateContentWidth() {
    if (!silenceButton_)
        return;

    const QFontMetrics metrics(silenceButton_->font());
    const int textWidth = guardTextWidth(metrics, silenceButton_->text());
    const int labelWidth = textWidth + kButtonHorizontalPadding;
    silenceButton_->setFixedSize(labelWidth, kIndicatorHeight - kVerticalPadding * 2);

    const int indicatorWidth =
      kHorizontalPadding * 2 + kLampDiameter + kContentSpacing + labelWidth + kContentSpacing + kCloseButtonWidth + kWidthSafetyMargin;
    setFixedWidth(indicatorWidth);
}
