#pragma once

#include <QElapsedTimer>
#include <QSplashScreen>
#include <QString>

class QWidget;

class GuardSplash : public QSplashScreen {
public:
    static constexpr int kDefaultFadeInMs = 400;
    static constexpr int kDefaultFadeOutMs = 450;
    static constexpr int kDefaultMinimumVisibleMs = 1800;
    static constexpr int kTestModeMinimumVisibleMs = 700;

    GuardSplash();

    void showWithFadeIn(int fadeDurationMs = kDefaultFadeInMs);
    void setStatusMessage(const QString& message);
    void finishSplash(QWidget* mainWindow, bool testMode = false, int fadeOutMs = kDefaultFadeOutMs);

private:
    QElapsedTimer visibleSince_;
};
