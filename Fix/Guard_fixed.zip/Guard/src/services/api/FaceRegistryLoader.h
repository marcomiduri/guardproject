#ifndef FACEREGISTRYLOADER_H
#define FACEREGISTRYLOADER_H

#include <QByteArray>
#include <QString>
#include <QDateTime>
#include <QVector>

#include <vector>

namespace guard {
namespace api {

struct FaceRegistryFace {
    qint64 id = -1;
    QString name;
    std::vector<float> feature;
};

struct FaceRegistryData {
    QString version;
    QString scope;
    QDateTime updatedAtUtc;
    float threshold = 0.48f;
    QString model;
    QVector<FaceRegistryFace> faces;
    QString sourceDescription;
};

struct FaceRegistryVersionInfo {
    QString version;
    QString scope;
    QDateTime updatedAtUtc;
    int count = 0;
    QString model;
    float threshold = 0.48f;
};

class FaceRegistryLoader {
public:
    static bool parseRegistryPayload(const QByteArray& payload, FaceRegistryData& out, QString* errorMessage = nullptr);
    static bool parseVersionPayload(const QByteArray& payload, FaceRegistryVersionInfo& out, QString* errorMessage = nullptr);
};

}  // namespace api
}  // namespace guard

#endif  // FACEREGISTRYLOADER_H
