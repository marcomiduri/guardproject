#include "FaceRegistryLoader.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QObject>
#include <QVariant>
#include <QtMath>
#include <QSet>

namespace guard {
namespace api {

namespace {

const float kDefaultThreshold = 0.48f;

void assignError(QString* errorMessage, const QString& message) {
    if (errorMessage)
        *errorMessage = message;
}

bool parseRootObject(const QByteArray& payload, QJsonObject* root, QString* errorMessage, const QString& invalidJsonMessage) {
    const QJsonDocument document = QJsonDocument::fromJson(payload);
    if (!document.isObject()) {
        assignError(errorMessage, invalidJsonMessage);
        return false;
    }
    *root = document.object();
    return true;
}

QDateTime parseUtcTimestamp(const QJsonObject& object, const QString& key) {
    return QDateTime::fromString(object.value(key).toString(), Qt::ISODate).toUTC();
}

float parseThreshold(const QJsonObject& object) {
    const double value = object.contains(QStringLiteral("threshold")) ? object.value(QStringLiteral("threshold")).toDouble(kDefaultThreshold)
                                                                      : kDefaultThreshold;
    return qIsFinite(value) && value >= 0.0 && value <= 1.0 ? static_cast<float>(value) : kDefaultThreshold;
}

bool parseFeature(const QJsonArray& values, std::vector<float>* feature) {
    if (values.isEmpty())
        return false;

    feature->clear();
    feature->reserve(static_cast<std::size_t>(values.size()));
    for (const QJsonValue& value : values) {
        if (!value.isDouble())
            return false;
        const double component = value.toDouble();
        if (!qIsFinite(component))
            return false;
        feature->push_back(static_cast<float>(component));
    }
    return !feature->empty();
}

}  // namespace

bool FaceRegistryLoader::parseRegistryPayload(const QByteArray& payload, FaceRegistryData& out, QString* errorMessage) {
    QJsonObject root;
    if (!parseRootObject(payload, &root, errorMessage, QObject::tr("Face registry response is not valid JSON.")))
        return false;

    FaceRegistryData parsed;
    parsed.version = root.value(QStringLiteral("version")).toString().trimmed();
    parsed.scope = root.value(QStringLiteral("scope")).toString().trimmed();
    parsed.updatedAtUtc = parseUtcTimestamp(root, QStringLiteral("updatedAt"));
    parsed.threshold = parseThreshold(root);
    parsed.model = root.value(QStringLiteral("model")).toString();

    int expectedFeatureDimension = 0;
    QSet<qint64> seenIds;
    const QJsonArray faces = root.value(QStringLiteral("faces")).toArray();
    for (const QJsonValue& value : faces) {
        const QJsonObject face = value.toObject();
        FaceRegistryFace entry;
        entry.id = face.value(QStringLiteral("id")).toVariant().toLongLong();
        entry.name = face.value(QStringLiteral("name")).toString().trimmed();

        if (entry.id <= 0 || entry.name.isEmpty() || seenIds.contains(entry.id) ||
            !parseFeature(face.value(QStringLiteral("feature")).toArray(), &entry.feature)) {
            continue;
        }

        const int featureDimension = static_cast<int>(entry.feature.size());
        if (featureDimension <= 0 || featureDimension > 8192)
            continue;
        if (expectedFeatureDimension == 0)
            expectedFeatureDimension = featureDimension;
        else if (featureDimension != expectedFeatureDimension)
            continue;

        seenIds.insert(entry.id);
        parsed.faces.append(entry);
    }

    out = parsed;
    return true;
}

bool FaceRegistryLoader::parseVersionPayload(const QByteArray& payload, FaceRegistryVersionInfo& out, QString* errorMessage) {
    QJsonObject root;
    if (!parseRootObject(payload, &root, errorMessage, QObject::tr("Face registry version response is not valid JSON."))) {
        return false;
    }

    const QString version = root.value(QStringLiteral("version")).toString().trimmed();
    if (version.isEmpty()) {
        assignError(errorMessage, QObject::tr("Face registry version response is missing version."));
        return false;
    }

    FaceRegistryVersionInfo parsed;
    parsed.version = version;
    parsed.scope = root.value(QStringLiteral("scope")).toString().trimmed();
    parsed.updatedAtUtc = parseUtcTimestamp(root, QStringLiteral("updatedAt"));
    parsed.count = root.value(QStringLiteral("count")).toInt(0);
    parsed.model = root.value(QStringLiteral("model")).toString();
    parsed.threshold = parseThreshold(root);
    out = parsed;
    return true;
}

}  // namespace api
}  // namespace guard
