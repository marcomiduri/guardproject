#ifndef GUARDENVIRONMENT_H
#define GUARDENVIRONMENT_H

#include <QString>
#include <QtGlobal>

namespace guard {
namespace api {

inline QString environmentVariable(const char* name) {
#if QT_VERSION >= QT_VERSION_CHECK(5, 10, 0)
    return qEnvironmentVariable(name);
#else
    return QString::fromLocal8Bit(qgetenv(name));
#endif
}

inline int faceRegistryRefreshMs() {
    const QString value = environmentVariable("GUARD_FACE_REGISTRY_REFRESH_MS").trimmed();
    if (value.isEmpty()) {
        return 60000;
    }

    const int parsed = value.toInt();
    return parsed < 10000 ? 60000 : parsed;
}

}  // namespace api
}  // namespace guard

#endif  // GUARDENVIRONMENT_H
