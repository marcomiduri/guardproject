#pragma once

#include "GuardBackendClient.h"

namespace guard {
namespace backend {

class GuardBackendClientInterface {
public:
    virtual ~GuardBackendClientInterface() = default;

    virtual void get(const QString& path, GuardBackendClient::Completion completion) = 0;
    virtual void postJson(const QString& path, const QJsonObject& object, GuardBackendClient::Completion completion) = 0;
    virtual void patchJson(const QString& path, const QJsonObject& object, GuardBackendClient::Completion completion) = 0;
    virtual void deleteResource(const QString& path, GuardBackendClient::Completion completion) = 0;
    virtual void postMultipart(const QString& path, const QJsonObject& fields, const QVector<MultipartFile>& files,
                               GuardBackendClient::Completion completion) = 0;
};

class GuardBackendClientAdapter : public GuardBackendClient, public GuardBackendClientInterface {
public:
    explicit GuardBackendClientAdapter(QObject* parent = nullptr) : GuardBackendClient(parent) {}

    void get(const QString& path, GuardBackendClient::Completion completion) override {
        GuardBackendClient::get(path, std::move(completion));
    }
    void postJson(const QString& path, const QJsonObject& object, GuardBackendClient::Completion completion) override {
        GuardBackendClient::postJson(path, object, std::move(completion));
    }
    void patchJson(const QString& path, const QJsonObject& object, GuardBackendClient::Completion completion) override {
        GuardBackendClient::patchJson(path, object, std::move(completion));
    }
    void deleteResource(const QString& path, GuardBackendClient::Completion completion) override {
        GuardBackendClient::deleteResource(path, std::move(completion));
    }
    void postMultipart(const QString& path, const QJsonObject& fields, const QVector<MultipartFile>& files,
                       GuardBackendClient::Completion completion) override {
        GuardBackendClient::postMultipart(path, fields, files, std::move(completion));
    }
};

}  // namespace backend
}  // namespace guard
