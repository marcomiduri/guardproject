#pragma once

#include "model/GuardBackendModels.h"
#include "services/backend/GuardBackendClient.h"

#include <QObject>
#include <functional>

class QTimer;

namespace guard {
namespace backend {

class GuardSessionManager : public QObject {
    Q_OBJECT

public:
    explicit GuardSessionManager(GuardBackendClient* client, QObject* parent = nullptr);

    InstallationState state() const;
    bool isRegistered() const;
    bool hasInstallationIdentity() const;
    bool hasLiveAccessToken() const;
    bool isUserDisconnected() const;
    QString deviceCredential(QString* errorMessage = nullptr) const;

    void restoreSession();
    void refreshAccessToken(const std::function<void(bool success, const QString& errorMessage)>& done = {});
    void reconnectRoom(const std::function<void(bool success, const QString& errorMessage)>& done = {});
    void connectToRoom(const RoomConnectionRequest& request);
    void disconnectRoom(const std::function<void(bool success, const QString& errorMessage)>& done = {});
    void clearLocalSession();

signals:
    void sessionChanged(guard::backend::InstallationState state);
    // Emitted after every successful access-token response, including cold-start
    // restoration and callback-driven refreshes. This is intentionally separate
    // from authenticated(), whose existing meaning also starts the operational
    // backend session when no completion callback is supplied.
    void accessTokenAvailable();
    void authenticated();
    void connectionSucceeded(QVector<CameraUiModel> mappedCameras);
    void sessionError(QString message);

private:
    void loadLocalState();
    bool saveLocalState(QString* errorMessage = nullptr);
    bool saveDeviceCredential(const QString& token, QString* errorMessage = nullptr);
    bool applyConnectResponse(const QJsonObject& object, const RoomConnectionRequest& request, QVector<CameraUiModel>* mappedCameras,
                              QString* errorMessage);
    bool applyTokenResponse(const QJsonObject& object, QString* errorMessage);
    void scheduleTokenRefresh(const QJsonObject& object);
    void completeConnection(const QVector<CameraUiModel>& mappedCameras);
    void refreshAccessTokenInternal(const std::function<void(bool success, const QString& errorMessage)>& done);
    void stopTokenRefreshAndClearAccessToken();
    void reportResult(const std::function<void(bool success, const QString& errorMessage)>& done, bool success,
                      const QString& errorMessage = QString());

    GuardBackendClient* client_ = nullptr;
    InstallationState state_;
    QTimer* tokenRefreshTimer_ = nullptr;
    bool tokenRequestInFlight_ = false;
    bool connectRequestInFlight_ = false;
};

}  // namespace backend
}  // namespace guard

Q_DECLARE_METATYPE(guard::backend::InstallationState)
