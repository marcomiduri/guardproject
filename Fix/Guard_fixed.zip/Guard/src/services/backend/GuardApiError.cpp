#include "GuardApiError.h"

#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QObject>

namespace guard {
namespace backend {

namespace {

QString translate(const char* context, const char* text) {
    return QCoreApplication::translate(context, text);
}

bool isNonRetryableAuthCode(const QString& code) {
    const QString normalized = code.trimmed().toUpper();
    return normalized == QStringLiteral("INSTALLATION_REVOKED") || normalized == QStringLiteral("INSTALLATION_CREDENTIAL_RECOVERY_REQUIRED") ||
           normalized == QStringLiteral("DEVICE_CREDENTIAL_INVALID") || normalized == QStringLiteral("INVALID_DEVICE_CREDENTIAL") ||
           normalized == QStringLiteral("INVALID_CREDENTIAL") || normalized == QStringLiteral("CREDENTIAL_REVOKED") ||
           normalized == QStringLiteral("UNAUTHORIZED_INSTALLATION");
}

bool isExpiredTokenCode(const QString& code) {
    const QString normalized = code.trimmed().toUpper();
    return normalized == QStringLiteral("TOKEN_EXPIRED") || normalized == QStringLiteral("JWT_EXPIRED") ||
           normalized == QStringLiteral("ACCESS_TOKEN_EXPIRED");
}

QString networkFallbackMessage(int httpStatus, bool timedOut) {
    if (timedOut)
        return translate("GuardBackendClient", "Backend request timed out.");
    if (httpStatus > 0) {
        return translate("GuardBackendClient", "Backend request failed (%1).").arg(httpStatus);
    }
    return translate("GuardBackendClient", "Backend request failed.");
}

}  // namespace

bool GuardApiErrorParser::parseFromBody(const QByteArray& body, GuardApiError* error) {
    if (!error)
        return false;
    *error = GuardApiError{};

    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(body, &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject())
        return false;

    const QJsonObject object = document.object();
    const QJsonValue errorValue = object.value(QStringLiteral("error"));
    if (errorValue.isObject()) {
        const QJsonObject nested = errorValue.toObject();
        error->code = nested.value(QStringLiteral("code")).toString().trimmed();
        error->message = nested.value(QStringLiteral("message")).toString().trimmed();
        if (nested.contains(QStringLiteral("retryable"))) {
            error->retryable = nested.value(QStringLiteral("retryable")).toBool(false);
            error->retryableKnown = true;
        }
        return !error->code.isEmpty() || !error->message.isEmpty() || error->retryableKnown;
    }

    if (errorValue.isString()) {
        error->message = errorValue.toString().trimmed();
    }
    const QString topLevelMessage = object.value(QStringLiteral("message")).toString().trimmed();
    if (error->message.isEmpty())
        error->message = topLevelMessage;
    return !error->message.isEmpty();
}

void GuardApiErrorParser::applyToResponse(int httpStatus, bool timedOut, const QByteArray& body, GuardApiResponse* response) {
    if (!response)
        return;

    GuardApiError parsed;
    if (GuardApiErrorParser::parseFromBody(body, &parsed)) {
        if (!parsed.code.isEmpty())
            response->errorCode = parsed.code;
        if (!parsed.message.isEmpty())
            response->errorMessage = parsed.message;
        if (parsed.retryableKnown) {
            response->retryable = parsed.retryable;
            response->retryableKnown = true;
        }
    }

    if (response->errorMessage.isEmpty()) {
        response->errorMessage = networkFallbackMessage(httpStatus, timedOut);
    }
}

bool guardApiResponseIsRetryableFailure(const GuardApiResponse& response) {
    if (response.ok())
        return false;
    if (guardApiResponseIsNonRetryableAuthFailure(response))
        return false;
    if (response.retryableKnown)
        return response.retryable;
    if (response.httpStatus == 401 && guardApiResponseShouldAttemptAuthRetry(response))
        return true;
    return response.timedOut || response.httpStatus == 0 || response.httpStatus == 408 || response.httpStatus == 429 || response.httpStatus >= 500;
}

bool guardApiResponseIsNonRetryableAuthFailure(const GuardApiResponse& response) {
    if (response.httpStatus == 403)
        return true;
    if (!response.errorCode.isEmpty() && isNonRetryableAuthCode(response.errorCode))
        return true;
    if (response.retryableKnown && !response.retryable && (response.httpStatus == 401 || response.httpStatus == 403)) {
        return true;
    }
    return false;
}

bool guardApiResponseShouldAttemptAuthRetry(const GuardApiResponse& response) {
    if (response.httpStatus != 401)
        return false;
    if (guardApiResponseIsNonRetryableAuthFailure(response))
        return false;
    if (!response.errorCode.isEmpty()) {
        if (isNonRetryableAuthCode(response.errorCode))
            return false;
        if (isExpiredTokenCode(response.errorCode))
            return true;
    }
    if (response.retryableKnown)
        return response.retryable;
    return true;
}

bool guardApiResponseShouldClearGuardSession(const GuardApiResponse& response) {
    if (guardApiResponseIsNonRetryableAuthFailure(response))
        return true;
    if (response.httpStatus == 404)
        return true;
    return response.errorCode.trimmed().compare(QStringLiteral("NOT_FOUND"), Qt::CaseInsensitive) == 0;
}

}  // namespace backend
}  // namespace guard
