#pragma once

#include <QByteArray>
#include <QString>

class QJsonObject;

namespace guard {
namespace backend {

struct GuardApiError {
    QString code;
    QString message;
    bool retryable = false;
    bool retryableKnown = false;
};

struct GuardApiResponse {
    int httpStatus = 0;
    QByteArray body;
    QString errorMessage;
    QString errorCode;
    bool retryable = false;
    bool retryableKnown = false;
    bool timedOut = false;

    bool ok() const {
        return httpStatus >= 200 && httpStatus < 300 && errorMessage.isEmpty();
    }
    QJsonObject jsonObject(QString* errorMessageOut = nullptr) const;
    bool isRetryableFailure() const;
    bool isNonRetryableAuthFailure() const;
    bool shouldAttemptAuthRetry() const;
};

class GuardApiErrorParser {
public:
    static bool parseFromBody(const QByteArray& body, GuardApiError* error);
    static void applyToResponse(int httpStatus, bool timedOut, const QByteArray& body, GuardApiResponse* response);
};

bool guardApiResponseIsRetryableFailure(const GuardApiResponse& response);
bool guardApiResponseIsNonRetryableAuthFailure(const GuardApiResponse& response);
bool guardApiResponseShouldAttemptAuthRetry(const GuardApiResponse& response);
bool guardApiResponseShouldClearGuardSession(const GuardApiResponse& response);

}  // namespace backend
}  // namespace guard
