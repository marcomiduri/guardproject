#include "CameraStore.h"

#include "platform/security/SecureCredentialStore.h"

#include <QCryptographicHash>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSet>
#include <QSettings>

namespace guard {
namespace backend {

namespace {
const char kCameraSettingsKey[] = "cameras/configuration";

QString passwordCredentialName(const QString& cameraId) {
    const QByteArray digest = QCryptographicHash::hash(cameraId.toUtf8(), QCryptographicHash::Sha256).toHex().left(24);
    return QStringLiteral("guard-camera-password-%1").arg(QString::fromLatin1(digest));
}

QJsonArray storedCameraArray() {
    const QByteArray raw = QSettings().value(QString::fromLatin1(kCameraSettingsKey)).toByteArray();
    const QJsonDocument document = QJsonDocument::fromJson(raw);
    return document.isArray() ? document.array() : QJsonArray();
}
}  // namespace

QVector<CameraUiModel> CameraStore::load() {
    QVector<CameraUiModel> result;
    const QJsonArray stored = storedCameraArray();
    for (const QJsonValue& value : stored) {
        const QJsonObject object = value.toObject();
        CameraUiModel camera;
        camera.id = object.value(QStringLiteral("id")).toString();
        camera.clientCameraId = object.value(QStringLiteral("clientCameraId")).toString(camera.id);
        camera.backendCameraId = object.value(QStringLiteral("backendCameraId")).toString();
        camera.roomId = object.value(QStringLiteral("roomId")).toString();
        camera.name = object.value(QStringLiteral("name")).toString();
        camera.type = object.value(QStringLiteral("type")).toString(QStringLiteral("Hikvision"));
        camera.directionConfigured = cameraDirectionConfiguredFromStoredJson(object);
        camera.direction = cameraDirectionFromApiValue(object.value(QStringLiteral("direction")).toString(QStringLiteral("in")));
        camera.address = object.value(QStringLiteral("address")).toString();
        camera.sdkPort = object.value(QStringLiteral("sdkPort")).toInt(8000);
        camera.rtspPort = object.value(QStringLiteral("rtspPort")).toInt(554);
        camera.username = object.value(QStringLiteral("username")).toString(QStringLiteral("admin"));

        QByteArray protectedPassword;
        if (security::SecureCredentialStore::read(passwordCredentialName(camera.id), &protectedPassword, nullptr)) {
            camera.password = QString::fromUtf8(protectedPassword);
        } else {
            // One-time compatibility path for early Guard camera settings.
            // The next successful save migrates this plaintext value to DPAPI.
            camera.password = object.value(QStringLiteral("password")).toString();
        }

        camera.channel = object.value(QStringLiteral("channel")).toInt(1);
        camera.stream = object.value(QStringLiteral("stream")).toString(QStringLiteral("Main Stream"));
        camera.rtspUrl = object.value(QStringLiteral("rtspUrl")).toString();
        camera.sortOrder = object.value(QStringLiteral("sortOrder")).toInt(result.size());
        if (!camera.id.trimmed().isEmpty())
            result.append(camera);
    }
    return result;
}

bool CameraStore::save(const QVector<CameraUiModel>& cameras) {
    const QJsonArray previous = storedCameraArray();
    QSet<QString> retainedIds;
    QJsonArray array;
    bool credentialsSaved = true;

    for (const CameraUiModel& camera : cameras) {
        const QString cameraId = camera.id.trimmed();
        if (cameraId.isEmpty())
            continue;
        retainedIds.insert(cameraId);

        const QString credentialName = passwordCredentialName(cameraId);
        if (camera.password.isEmpty()) {
            credentialsSaved = security::SecureCredentialStore::remove(credentialName, nullptr) && credentialsSaved;
        } else {
            credentialsSaved = security::SecureCredentialStore::write(credentialName, camera.password.toUtf8(), nullptr) && credentialsSaved;
        }

        QJsonObject object;
        object.insert(QStringLiteral("id"), camera.id);
        object.insert(QStringLiteral("clientCameraId"), camera.effectiveClientCameraId());
        object.insert(QStringLiteral("backendCameraId"), camera.backendCameraId);
        object.insert(QStringLiteral("roomId"), camera.roomId);
        object.insert(QStringLiteral("name"), camera.name);
        object.insert(QStringLiteral("type"), camera.type);
        if (camera.directionConfigured) {
            object.insert(QStringLiteral("direction"), cameraDirectionApiValue(camera.direction));
        }
        object.insert(QStringLiteral("address"), camera.address);
        object.insert(QStringLiteral("sdkPort"), camera.sdkPort);
        object.insert(QStringLiteral("rtspPort"), camera.rtspPort);
        object.insert(QStringLiteral("username"), camera.username);
        object.insert(QStringLiteral("channel"), camera.channel);
        object.insert(QStringLiteral("stream"), camera.stream);
        object.insert(QStringLiteral("rtspUrl"), camera.rtspUrl);
        object.insert(QStringLiteral("sortOrder"), camera.sortOrder);
        array.append(object);
    }

    // Remove protected passwords for cameras that were deleted locally.
    for (const QJsonValue& value : previous) {
        const QString oldId = value.toObject().value(QStringLiteral("id")).toString().trimmed();
        if (!oldId.isEmpty() && !retainedIds.contains(oldId)) {
            security::SecureCredentialStore::remove(passwordCredentialName(oldId), nullptr);
        }
    }

    QSettings target;
    target.setValue(QString::fromLatin1(kCameraSettingsKey), QJsonDocument(array).toJson(QJsonDocument::Compact));
    target.sync();
    return credentialsSaved && target.status() == QSettings::NoError;
}

}  // namespace backend
}  // namespace guard
