#pragma once

#include <QObject>
#include <QString>

class QTimer;

#ifdef GUARD_HAS_QT_WEBSOCKETS
class QWebSocket;
#endif

namespace guard {
namespace backend {

class GuardBackendClient;

class GuardRealtimeClient : public QObject {
    Q_OBJECT

public:
    explicit GuardRealtimeClient(GuardBackendClient* backendClient, QObject* parent = nullptr);

    void start();
    void stop();
    bool isConnected() const;

signals:
    void faceRegistryInvalidated(QString version, QString scope, QString updatedAt);
    void notificationSettingsInvalidated(QString version);
    void connectionStateChanged(bool connected);

private:
    void scheduleReconnect();
    void handleTextMessage(const QString& message);

    GuardBackendClient* backendClient_ = nullptr;
    QTimer* reconnectTimer_ = nullptr;
    bool stopping_ = false;

#ifdef GUARD_HAS_QT_WEBSOCKETS
    QWebSocket* socket_ = nullptr;
#endif
};

}  // namespace backend
}  // namespace guard
