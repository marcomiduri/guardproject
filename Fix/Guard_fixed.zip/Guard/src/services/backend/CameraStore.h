#pragma once

#include "CameraUiModel.h"

#include <QVector>

namespace guard {
namespace backend {

class CameraStore {
public:
    static QVector<CameraUiModel> load();
    static bool save(const QVector<CameraUiModel>& cameras);
};

}  // namespace backend
}  // namespace guard
