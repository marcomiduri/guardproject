#include "GuardSessionManager.h"

#include "model/GuardBackendModels.h"
#include "platform/identity/GuardHardwareId.h"
#include "platform/security/SecureCredentialStore.h"

#include <QJsonDocument>
#include <QSettings>
#include <QTimer>

namespace guard {
namespace backend {

namespace {
const char kSessionSettingsKey[] = "backend/installation";
const char kDeviceCredentialName[] = "guard-backend-device-credential";
}  // namespace

GuardSessionManager::GuardSessionManager(GuardBackendClient* client, QObject* parent) : QObject(parent), client_(client) {
    qRegisterMetaType<guard::backend::InstallationState>("guard::backend::InstallationState");
    qRegisterMetaType<guard::backend::GuardApiResponse>("guard::backend::GuardApiResponse");
    tokenRefreshTimer_ = new QTimer(this);
    tokenRefreshTimer_->setSingleShot(true);
    connect(tokenRefreshTimer_, &QTimer::timeout, this, &GuardSessionManager::restoreSession);
    if (client_) {
        client_->setTokenRefreshHandler([this](const std::function<void(bool)>& done) {
            refreshAccessToken([done](bool success, const QString&) {
                if (done)
                    done(success);
            });
        });
        connect(client_, &GuardBackendClient::authorizationFailed, this, [this](const GuardApiResponse& response) {
            emit sessionError(response.errorMessage);
            if (response.isNonRetryableAuthFailure())
                clearLocalSession();
        });
    }
    loadLocalState();
}

InstallationState GuardSessionManager::state() const {
    return state_;
}

bool GuardSessionManager::isRegistered() const {
    return state_.isRegistered();
}

bool GuardSessionManager::hasInstallationIdentity() const {
    return state_.hasInstallationIdentity();
}

bool GuardSessionManager::hasLiveAccessToken() const {
    return client_ && !client_->accessToken().trimmed().isEmpty();
}

bool GuardSessionManager::isUserDisconnected() const {
    return state_.hasInstallationIdentity() && state_.userDisconnected;
}

QString GuardSessionManager::deviceCredential(QString* errorMessage) const {
    QByteArray bytes;
    if (!security::SecureCredentialStore::read(QString::fromLatin1(kDeviceCredentialName), &bytes, errorMessage))
        return QString();
    return QString::fromUtf8(bytes);
}

void GuardSessionManager::loadLocalState() {
    const QByteArray raw = QSettings().value(QString::fromLatin1(kSessionSettingsKey)).toByteArray();
    const QJsonDocument document = QJsonDocument::fromJson(raw);
    if (!document.isObject())
        return;
    const QJsonObject object = document.object();
    state_.installationId = object.value(QStringLiteral("installationId")).toString();
    state_.roomId = object.value(QStringLiteral("roomId")).toString();
    state_.roomName = object.value(QStringLiteral("roomName")).toString();
    state_.deviceName = object.value(QStringLiteral("deviceName")).toString();
    state_.userDisconnected = object.value(QStringLiteral("userDisconnected")).toBool(false);
    state_.lastConnectedAtUtc = parseUtcIso8601(object.value(QStringLiteral("lastConnectedAtUtc")));
    // Older builds retained the previous room locally after a deliberate disconnect.
    // Treat that state as an unassigned installation so the operator may choose any room.
    if (state_.userDisconnected) {
        state_.roomId.clear();
        state_.roomName.clear();
    }
}

bool GuardSessionManager::saveLocalState(QString* errorMessage) {
    QJsonObject object;
    object.insert(QStringLiteral("installationId"), state_.installationId);
    object.insert(QStringLiteral("roomId"), state_.roomId);
    object.insert(QStringLiteral("roomName"), state_.roomName);
    object.insert(QStringLiteral("deviceName"), state_.deviceName);
    object.insert(QStringLiteral("userDisconnected"), state_.userDisconnected);
    if (state_.lastConnectedAtUtc.isValid())
        object.insert(QStringLiteral("lastConnectedAtUtc"), state_.lastConnectedAtUtc.toString(Qt::ISODate));
    QSettings settings;
    settings.setValue(QString::fromLatin1(kSessionSettingsKey), QJsonDocument(object).toJson(QJsonDocument::Compact));
    settings.sync();
    if (settings.status() != QSettings::NoError) {
        if (errorMessage)
            *errorMessage = tr("Installation state could not be saved.");
        return false;
    }
    return true;
}

bool GuardSessionManager::saveDeviceCredential(const QString& token, QString* errorMessage) {
    if (token.trimmed().isEmpty()) {
        if (errorMessage)
            *errorMessage = tr("Backend did not return a device credential.");
        return false;
    }
    return security::SecureCredentialStore::write(QString::fromLatin1(kDeviceCredentialName), token.trimmed().toUtf8(), errorMessage);
}

bool GuardSessionManager::applyConnectResponse(const QJsonObject& object, const RoomConnectionRequest& request, QVector<CameraUiModel>* mappedCameras,
                                               QString* errorMessage) {
    InstallationState parsedState = state_;
    parsedState.deviceName = request.deviceName.trimmed();
    QString returnedCredential;
    if (!parseConnectResponse(object, &parsedState, mappedCameras, &returnedCredential, errorMessage))
        return false;

    QString credentialError;
    const QString existingCredential = deviceCredential(&credentialError);
    if (returnedCredential.isEmpty() && existingCredential.isEmpty()) {
        if (errorMessage)
            *errorMessage = tr("Recovery required. This installation already exists and requires credential recovery.");
        return false;
    }

    const InstallationState previousState = state_;
    if (!returnedCredential.isEmpty() && !saveDeviceCredential(returnedCredential, errorMessage))
        return false;

    state_ = parsedState;
    if (!saveLocalState(errorMessage)) {
        state_ = previousState;
        if (!returnedCredential.isEmpty())
            security::SecureCredentialStore::remove(QString::fromLatin1(kDeviceCredentialName), nullptr);
        return false;
    }
    emit sessionChanged(state_);
    return true;
}

bool GuardSessionManager::applyTokenResponse(const QJsonObject& object, QString* errorMessage) {
    const QString accessToken = accessTokenFromSessionJson(object);
    if (accessToken.isEmpty()) {
        if (errorMessage)
            *errorMessage = tr("Backend token response is missing an access token.");
        return false;
    }
    if (client_)
        client_->setAccessToken(accessToken);
    scheduleTokenRefresh(object);
    return true;
}

void GuardSessionManager::scheduleTokenRefresh(const QJsonObject& object) {
    if (!tokenRefreshTimer_)
        return;
    const int refreshSeconds = tokenRefreshDelaySeconds(object);
    if (refreshSeconds <= 0) {
        tokenRefreshTimer_->stop();
        return;
    }
    tokenRefreshTimer_->start(refreshSeconds * 1000);
}

void GuardSessionManager::restoreSession() {
    if (!state_.isRegistered()) {
        emit sessionChanged(state_);
        return;
    }
    refreshAccessToken();
}

void GuardSessionManager::refreshAccessToken(const std::function<void(bool success, const QString& errorMessage)>& done) {
    refreshAccessTokenInternal(done);
}

void GuardSessionManager::reconnectRoom(const std::function<void(bool success, const QString& errorMessage)>& done) {
    const QString message = tr("Select a room to reconnect this Guard computer.");
    reportResult(done, false, message);
}

void GuardSessionManager::refreshAccessTokenInternal(const std::function<void(bool success, const QString& errorMessage)>& done) {
    if (!client_ || !state_.isRegistered() || tokenRequestInFlight_) {
        if (done)
            done(false, tr("Backend session is unavailable."));
        return;
    }
    QString credentialError;
    const QString credential = deviceCredential(&credentialError);
    if (credential.isEmpty()) {
        const QString message = credentialError.isEmpty() ? tr("The saved device credential is unavailable.") : credentialError;
        reportResult(done, false, message);
        return;
    }

    QJsonObject request;
    request.insert(QStringLiteral("installationId"), state_.installationId);
    request.insert(QStringLiteral("deviceCredential"), credential);
    const QString hardwareId = GuardHardwareId::displayText().trimmed();
    if (!hardwareId.isEmpty())
        request.insert(QStringLiteral("hardwareId"), hardwareId);
    tokenRequestInFlight_ = true;
    client_->postJson(QStringLiteral("/api/guard/auth/token"), request, [this, done](const GuardApiResponse& response) {
        tokenRequestInFlight_ = false;
        if (!response.ok()) {
            if (guardApiResponseShouldClearGuardSession(response))
                clearLocalSession();
            reportResult(done, false, response.errorMessage);
            return;
        }
        QString parseError;
        const QJsonObject object = response.jsonObject(&parseError);
        if (!parseError.isEmpty() || !applyTokenResponse(object, &parseError)) {
            reportResult(done, false, parseError);
            return;
        }

        // A successful token response makes backend event delivery available
        // regardless of whether the caller supplied a completion callback.
        // Cold-start restoration always supplies a callback, so relying only on
        // authenticated() left GuardEventCoordinator in the no-room state until
        // the operator manually disconnected and reconnected.
        emit accessTokenAvailable();

        if (done)
            reportResult(done, true);
        else
            emit authenticated();
    });
}

void GuardSessionManager::completeConnection(const QVector<CameraUiModel>& mappedCameras) {
    stopTokenRefreshAndClearAccessToken();
    refreshAccessToken([this, mappedCameras](bool success, const QString& errorMessage) {
        if (!success) {
            emit sessionError(errorMessage);
            return;
        }
        emit connectionSucceeded(mappedCameras);
    });
}

void GuardSessionManager::connectToRoom(const RoomConnectionRequest& requestData) {
    if (!client_ || connectRequestInFlight_)
        return;

    RoomConnectionRequest authenticatedRequest = requestData;
    const QString hardwareId = GuardHardwareId::displayText().trimmed();
    if (hardwareId.isEmpty()) {
        emit sessionError(tr("Hardware ID is unavailable. Guard cannot resolve a stable backend installation."));
        return;
    }
    authenticatedRequest.hardwareId = hardwareId;

    if (state_.hasInstallationIdentity()) {
        QString credentialError;
        const QString credential = deviceCredential(&credentialError);
        authenticatedRequest.installationId = state_.installationId;
        // Hardware identity is the recovery key.  If a rebuild/reinstall removed
        // the protected credential, still let the backend resolve this machine by
        // hardwareId and return a fresh device credential.
        if (!credential.isEmpty())
            authenticatedRequest.deviceCredential = credential;
    }
    const QJsonObject request = roomConnectionRequestToApiJson(authenticatedRequest);

    connectRequestInFlight_ = true;
    client_->postJson(QStringLiteral("/api/guard/installations/connect"), request, [this, requestData](const GuardApiResponse& response) {
        connectRequestInFlight_ = false;
        if (!response.ok()) {
            emit sessionError(response.errorMessage);
            return;
        }
        QString parseError;
        QVector<CameraUiModel> mapped;
        const QJsonObject object = response.jsonObject(&parseError);
        if (!parseError.isEmpty() || !applyConnectResponse(object, requestData, &mapped, &parseError)) {
            emit sessionError(parseError);
            return;
        }
        completeConnection(mapped);
    });
}

void GuardSessionManager::disconnectRoom(const std::function<void(bool success, const QString& errorMessage)>& done) {
    if (!client_ || !state_.isRegistered()) {
        reportResult(done, true);
        return;
    }
    if (state_.userDisconnected) {
        reportResult(done, true);
        return;
    }
    if (!hasLiveAccessToken()) {
        refreshAccessTokenInternal([this, done](bool success, const QString& errorMessage) {
            if (!success) {
                reportResult(done, false, errorMessage);
                return;
            }
            disconnectRoom(done);
        });
        return;
    }
    client_->postJson(QStringLiteral("/api/guard/installations/disconnect"), QJsonObject{}, [this, done](const GuardApiResponse& response) {
        if (!response.ok() && response.httpStatus != 404) {
            reportResult(done, false, response.errorMessage);
            return;
        }
        state_.userDisconnected = true;
        state_.roomId.clear();
        state_.roomName.clear();
        stopTokenRefreshAndClearAccessToken();
        QString saveError;
        if (!saveLocalState(&saveError)) {
            reportResult(done, false, saveError);
            return;
        }
        emit sessionChanged(state_);
        reportResult(done, true);
    });
}

void GuardSessionManager::stopTokenRefreshAndClearAccessToken() {
    if (tokenRefreshTimer_)
        tokenRefreshTimer_->stop();
    if (client_)
        client_->clearAccessToken();
}

void GuardSessionManager::reportResult(const std::function<void(bool success, const QString& errorMessage)>& done, bool success,
                                       const QString& errorMessage) {
    if (done) {
        done(success, errorMessage);
    } else if (!success) {
        emit sessionError(errorMessage);
    }
}

void GuardSessionManager::clearLocalSession() {
    state_ = InstallationState{};
    tokenRequestInFlight_ = false;
    connectRequestInFlight_ = false;
    stopTokenRefreshAndClearAccessToken();
    security::SecureCredentialStore::remove(QString::fromLatin1(kDeviceCredentialName), nullptr);
    QSettings().remove(QString::fromLatin1(kSessionSettingsKey));
    emit sessionChanged(state_);
}

}  // namespace backend
}  // namespace guard
