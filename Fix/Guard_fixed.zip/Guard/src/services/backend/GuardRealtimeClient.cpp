#include "GuardRealtimeClient.h"

#include "GuardBackendClient.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkRequest>
#include <QTimer>
#include <QUrl>

#ifdef GUARD_HAS_QT_WEBSOCKETS
#include <QWebSocket>
#endif

namespace guard {
namespace backend {

GuardRealtimeClient::GuardRealtimeClient(GuardBackendClient* backendClient, QObject* parent) : QObject(parent), backendClient_(backendClient) {
    reconnectTimer_ = new QTimer(this);
    reconnectTimer_->setSingleShot(true);
    reconnectTimer_->setInterval(5000);
    connect(reconnectTimer_, &QTimer::timeout, this, &GuardRealtimeClient::start);

#ifdef GUARD_HAS_QT_WEBSOCKETS
    socket_ = new QWebSocket(QString(), QWebSocketProtocol::VersionLatest, this);
    connect(socket_, &QWebSocket::connected, this, [this]() { emit connectionStateChanged(true); });
    connect(socket_, &QWebSocket::disconnected, this, [this]() {
        emit connectionStateChanged(false);
        if (!stopping_)
            scheduleReconnect();
    });
    connect(socket_, &QWebSocket::textMessageReceived, this, &GuardRealtimeClient::handleTextMessage);
#endif
}

void GuardRealtimeClient::start() {
    stopping_ = false;
    if (reconnectTimer_)
        reconnectTimer_->stop();

#ifdef GUARD_HAS_QT_WEBSOCKETS
    if (!backendClient_ || !socket_)
        return;
    const QString token = backendClient_->accessToken().trimmed();
    if (token.isEmpty())
        return;

    if (socket_->state() == QAbstractSocket::ConnectedState || socket_->state() == QAbstractSocket::ConnectingState)
        socket_->abort();

    QUrl url = backendClient_->urlForPath(QStringLiteral("/api/guard/ws"));
    if (url.scheme().compare(QStringLiteral("https"), Qt::CaseInsensitive) == 0)
        url.setScheme(QStringLiteral("wss"));
    else
        url.setScheme(QStringLiteral("ws"));

    QNetworkRequest request(url);
    request.setRawHeader("Authorization", QByteArray("Bearer ") + token.toUtf8());
    socket_->open(request);
#else
    emit connectionStateChanged(false);
#endif
}

void GuardRealtimeClient::stop() {
    stopping_ = true;
    if (reconnectTimer_)
        reconnectTimer_->stop();
#ifdef GUARD_HAS_QT_WEBSOCKETS
    if (socket_)
        socket_->close();
#endif
    emit connectionStateChanged(false);
}

bool GuardRealtimeClient::isConnected() const {
#ifdef GUARD_HAS_QT_WEBSOCKETS
    return socket_ && socket_->state() == QAbstractSocket::ConnectedState;
#else
    return false;
#endif
}

void GuardRealtimeClient::scheduleReconnect() {
    if (stopping_ || !backendClient_ || backendClient_->accessToken().trimmed().isEmpty())
        return;
    if (reconnectTimer_ && !reconnectTimer_->isActive())
        reconnectTimer_->start();
}

void GuardRealtimeClient::handleTextMessage(const QString& message) {
    const QJsonDocument document = QJsonDocument::fromJson(message.toUtf8());
    if (!document.isObject())
        return;
    const QJsonObject object = document.object();
    const QString type = object.value(QStringLiteral("type")).toString().trimmed();
    if (type == QStringLiteral("face_registry.updated")) {
        const QString version = object.value(QStringLiteral("version")).toString().trimmed();
        if (!version.isEmpty()) {
            emit faceRegistryInvalidated(version, object.value(QStringLiteral("scope")).toString().trimmed(),
                                         object.value(QStringLiteral("updatedAt")).toString().trimmed());
        }
    } else if (type == QStringLiteral("notification_settings.updated")) {
        emit notificationSettingsInvalidated(object.value(QStringLiteral("version")).toString().trimmed());
    }
}

}  // namespace backend
}  // namespace guard
