#pragma once

#include "GuardApiError.h"

#include <QHash>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QObject>
#include <QUrl>
#include <QVector>
#include <functional>

class QHttpMultiPart;
class QNetworkReply;
class QTimer;

namespace guard {
namespace backend {

struct MultipartFile {
    QString fieldName;
    QString fileName;
    QByteArray mimeType;
    QByteArray data;
};

class GuardBackendClient : public QObject {
    Q_OBJECT

public:
    using Completion = std::function<void(const GuardApiResponse&)>;
    using TokenRefreshHandler = std::function<void(const std::function<void(bool success)>& completion)>;

    explicit GuardBackendClient(QObject* parent = nullptr);

    static QString defaultBaseUrl();
    static QString environmentBaseUrl();
    static bool isBaseUrlLockedByEnvironment();
    static QString savedBaseUrl();
    static QString effectiveBaseUrl();
    static QString baseUrlSourceDescription();
    static bool saveBaseUrl(const QString& value, QString* errorMessage = nullptr);
    static QString normalizeBaseUrl(const QString& value);

    void setTokenRefreshHandler(TokenRefreshHandler handler);
    void setAccessToken(const QString& token);
    QString accessToken() const;
    void clearAccessToken();
    void setRequestTimeoutMs(int timeoutMs);

    QUrl urlForPath(const QString& path) const;

    void get(const QString& path, const Completion& completion);
    void postJson(const QString& path, const QJsonObject& object, const Completion& completion);
    void patchJson(const QString& path, const QJsonObject& object, const Completion& completion);
    void deleteResource(const QString& path, const Completion& completion);
    void postMultipart(const QString& path, const QJsonObject& fields, const QVector<MultipartFile>& files, const Completion& completion);
    void testConnection(const Completion& completion);
    void testConnectionAt(const QString& baseUrl, const Completion& completion);

signals:
    void requestStarted(QString method, QUrl url);
    void requestCompleted(QString method, QUrl url, int httpStatus, bool ok);
    void authorizationFailed(guard::backend::GuardApiResponse response);

private:
    enum class RequestKind { Get, PostJson, PatchJson, Delete, PostMultipart };

    struct PendingRequest {
        QString method;
        QUrl url;
        Completion completion;
        QTimer* timeout = nullptr;
        RequestKind kind = RequestKind::Get;
        QByteArray body;
        QJsonObject multipartFields;
        QVector<MultipartFile> multipartFiles;
        bool authRetried = false;
        bool skipAuthRetry = false;
    };

    QNetworkRequest makeRequest(const QUrl& url, const QByteArray& contentType = QByteArray()) const;
    void sendRequest(PendingRequest pending);
    void deliverCompletion(PendingRequest pending, const GuardApiResponse& response);
    void watchReply(QNetworkReply* reply, PendingRequest pending);
    void finishReply(QNetworkReply* reply, bool timedOut);
    void attemptAuthRetry(PendingRequest pending, const GuardApiResponse& response);
    QString apiKey() const;

    QNetworkAccessManager manager_;
    QHash<QNetworkReply*, PendingRequest> pending_;
    TokenRefreshHandler tokenRefreshHandler_;
    QString accessToken_;
    int requestTimeoutMs_ = 8000;
};

}  // namespace backend
}  // namespace guard
