#include "GuardBackendClient.h"

#include "GuardApiError.h"
#include "services/api/GuardEnvironment.h"

#include <QBuffer>
#include <QCoreApplication>
#include <QHttpMultiPart>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QSettings>
#include <QTimer>

namespace guard {
namespace backend {

namespace {
const char kBaseUrlKey[] = "backend/baseUrl";
const char kLegacyBaseUrlKey[] = "guard-api-url";
const char kDefaultUrl[] = "http://127.0.0.1:3000";

bool hasEmbeddedCredentials(const QString& value) {
    QString trimmed = value.trimmed();
    if (trimmed.isEmpty())
        return false;
    QUrl url(trimmed);
    if (url.scheme().isEmpty())
        url.setScheme(QStringLiteral("http"));
    return !url.userInfo().isEmpty();
}

QString embeddedCredentialsError() {
    return QCoreApplication::translate("GuardBackendClient", "Backend URL must not contain embedded credentials.");
}

QString invalidBaseUrlError() {
    return QCoreApplication::translate("GuardBackendClient", "Enter a valid HTTP or HTTPS backend URL.");
}

bool shouldSkipAuthRetryForPath(const QString& path) {
    const QString normalized = path.trimmed();
    return normalized.contains(QStringLiteral("/api/guard/auth/token"));
}

}  // namespace

QJsonObject GuardApiResponse::jsonObject(QString* errorMessageOut) const {
    QJsonParseError error;
    const QJsonDocument document = QJsonDocument::fromJson(body, &error);
    if (error.error != QJsonParseError::NoError || !document.isObject()) {
        if (errorMessageOut)
            *errorMessageOut = QObject::tr("Backend response is not a JSON object.");
        return QJsonObject();
    }
    return document.object();
}

bool GuardApiResponse::isRetryableFailure() const {
    return guardApiResponseIsRetryableFailure(*this);
}

bool GuardApiResponse::isNonRetryableAuthFailure() const {
    return guardApiResponseIsNonRetryableAuthFailure(*this);
}

bool GuardApiResponse::shouldAttemptAuthRetry() const {
    return guardApiResponseShouldAttemptAuthRetry(*this);
}

GuardBackendClient::GuardBackendClient(QObject* parent) : QObject(parent) {}

QString GuardBackendClient::defaultBaseUrl() {
    return QString::fromLatin1(kDefaultUrl);
}
QString GuardBackendClient::environmentBaseUrl() {
    return guard::api::environmentVariable("GUARD_API_URL").trimmed();
}
bool GuardBackendClient::isBaseUrlLockedByEnvironment() {
    return !environmentBaseUrl().isEmpty();
}

QString GuardBackendClient::normalizeBaseUrl(const QString& value) {
    QString trimmed = value.trimmed();
    if (trimmed.isEmpty())
        return QString();
    QUrl url(trimmed);
    if (url.scheme().isEmpty())
        url.setScheme(QStringLiteral("http"));
    if (!url.isValid() || url.host().trimmed().isEmpty())
        return QString();
    if (!url.userInfo().isEmpty())
        return QString();
    const QString scheme = url.scheme().toLower();
    if (scheme != QStringLiteral("http") && scheme != QStringLiteral("https"))
        return QString();
    url.setQuery(QString());
    url.setFragment(QString());
    QString path = url.path();
    while (path.endsWith(QLatin1Char('/')))
        path.chop(1);
    url.setPath(path);
    return url.toString(QUrl::FullyEncoded);
}

bool hasSavedBaseUrlSetting() {
    QSettings settings;
    QString value = settings.value(QString::fromLatin1(kBaseUrlKey)).toString().trimmed();
    if (value.isEmpty()) {
        const QSettings legacy(QStringLiteral("Guard"), QStringLiteral("ApexImage"));
        value = legacy.value(QString::fromLatin1(kLegacyBaseUrlKey)).toString().trimmed();
    }
    return !value.isEmpty() && !GuardBackendClient::normalizeBaseUrl(value).isEmpty();
}

QString GuardBackendClient::savedBaseUrl() {
    QSettings settings;
    QString value = settings.value(QString::fromLatin1(kBaseUrlKey)).toString();
    if (value.trimmed().isEmpty()) {
        const QSettings legacy(QStringLiteral("Guard"), QStringLiteral("ApexImage"));
        value = legacy.value(QString::fromLatin1(kLegacyBaseUrlKey)).toString();
    }
    const QString normalized = normalizeBaseUrl(value);
    return normalized.isEmpty() ? defaultBaseUrl() : normalized;
}

QString GuardBackendClient::effectiveBaseUrl() {
    const QString environment = normalizeBaseUrl(environmentBaseUrl());
    return environment.isEmpty() ? savedBaseUrl() : environment;
}

QString GuardBackendClient::baseUrlSourceDescription() {
    if (isBaseUrlLockedByEnvironment()) {
        return QCoreApplication::translate("GuardBackendClient", "Environment override: GUARD_API_URL");
    }
    if (hasSavedBaseUrlSetting()) {
        return QCoreApplication::translate("GuardBackendClient", "Saved application setting");
    }
    return QCoreApplication::translate("GuardBackendClient", "Development default");
}

bool GuardBackendClient::saveBaseUrl(const QString& value, QString* errorMessage) {
    if (isBaseUrlLockedByEnvironment()) {
        if (errorMessage)
            *errorMessage = QObject::tr("Backend URL is controlled by GUARD_API_URL.");
        return false;
    }
    if (hasEmbeddedCredentials(value)) {
        if (errorMessage)
            *errorMessage = embeddedCredentialsError();
        return false;
    }
    const QString normalized = normalizeBaseUrl(value);
    if (normalized.isEmpty()) {
        if (errorMessage)
            *errorMessage = invalidBaseUrlError();
        return false;
    }
    QSettings settings;
    settings.setValue(QString::fromLatin1(kBaseUrlKey), normalized);
    settings.sync();
    if (settings.status() != QSettings::NoError) {
        if (errorMessage)
            *errorMessage = QObject::tr("Backend URL could not be saved.");
        return false;
    }
    return true;
}

void GuardBackendClient::setTokenRefreshHandler(TokenRefreshHandler handler) {
    tokenRefreshHandler_ = std::move(handler);
}

void GuardBackendClient::setAccessToken(const QString& token) {
    accessToken_ = token.trimmed();
}
QString GuardBackendClient::accessToken() const {
    return accessToken_;
}
void GuardBackendClient::clearAccessToken() {
    accessToken_.clear();
}
void GuardBackendClient::setRequestTimeoutMs(int timeoutMs) {
    requestTimeoutMs_ = qMax(1000, timeoutMs);
}

QUrl GuardBackendClient::urlForPath(const QString& path) const {
    QUrl base(effectiveBaseUrl());
    if (!base.isValid())
        return QUrl();
    QString suffix = path.trimmed();
    if (!suffix.startsWith(QLatin1Char('/')))
        suffix.prepend(QLatin1Char('/'));
    QString basePath = base.path();
    while (basePath.endsWith(QLatin1Char('/')))
        basePath.chop(1);
    base.setPath(basePath + suffix);
    return base;
}

QString GuardBackendClient::apiKey() const {
    const QString value = guard::api::environmentVariable("GUARD_API_KEY").trimmed();
    return value.isEmpty() ? QStringLiteral("dev-guard-api-key-change-me") : value;
}

QNetworkRequest GuardBackendClient::makeRequest(const QUrl& url, const QByteArray& contentType) const {
    QNetworkRequest request(url);
    request.setRawHeader("Accept", "application/json");
    if (!contentType.isEmpty())
        request.setRawHeader("Content-Type", contentType);
    if (!accessToken_.isEmpty()) {
        request.setRawHeader("Authorization", QByteArrayLiteral("Bearer ") + accessToken_.toUtf8());
    } else {
        request.setRawHeader("X-Guard-Api-Key", apiKey().toUtf8());
    }
    request.setRawHeader("X-Guard-Client", "Guard");
    return request;
}

void GuardBackendClient::get(const QString& path, const Completion& completion) {
    PendingRequest pending;
    pending.method = QStringLiteral("GET");
    pending.url = urlForPath(path);
    pending.completion = completion;
    pending.kind = RequestKind::Get;
    pending.skipAuthRetry = shouldSkipAuthRetryForPath(path);
    sendRequest(std::move(pending));
}

void GuardBackendClient::postJson(const QString& path, const QJsonObject& object, const Completion& completion) {
    PendingRequest pending;
    pending.method = QStringLiteral("POST");
    pending.url = urlForPath(path);
    pending.completion = completion;
    pending.kind = RequestKind::PostJson;
    pending.body = QJsonDocument(object).toJson(QJsonDocument::Compact);
    pending.skipAuthRetry = shouldSkipAuthRetryForPath(path);
    sendRequest(std::move(pending));
}

void GuardBackendClient::patchJson(const QString& path, const QJsonObject& object, const Completion& completion) {
    PendingRequest pending;
    pending.method = QStringLiteral("PATCH");
    pending.url = urlForPath(path);
    pending.completion = completion;
    pending.kind = RequestKind::PatchJson;
    pending.body = QJsonDocument(object).toJson(QJsonDocument::Compact);
    pending.skipAuthRetry = shouldSkipAuthRetryForPath(path);
    sendRequest(std::move(pending));
}

void GuardBackendClient::deleteResource(const QString& path, const Completion& completion) {
    PendingRequest pending;
    pending.method = QStringLiteral("DELETE");
    pending.url = urlForPath(path);
    pending.completion = completion;
    pending.kind = RequestKind::Delete;
    pending.skipAuthRetry = shouldSkipAuthRetryForPath(path);
    sendRequest(std::move(pending));
}

void GuardBackendClient::postMultipart(const QString& path, const QJsonObject& fields, const QVector<MultipartFile>& files,
                                       const Completion& completion) {
    PendingRequest pending;
    pending.method = QStringLiteral("POST");
    pending.url = urlForPath(path);
    pending.completion = completion;
    pending.kind = RequestKind::PostMultipart;
    pending.multipartFields = fields;
    pending.multipartFiles = files;
    pending.skipAuthRetry = shouldSkipAuthRetryForPath(path);
    sendRequest(std::move(pending));
}

void GuardBackendClient::testConnection(const Completion& completion) {
    testConnectionAt(effectiveBaseUrl(), completion);
}

void GuardBackendClient::testConnectionAt(const QString& baseUrl, const Completion& completion) {
    if (hasEmbeddedCredentials(baseUrl)) {
        GuardApiResponse response;
        response.errorMessage = embeddedCredentialsError();
        if (completion)
            completion(response);
        return;
    }
    const QString normalized = normalizeBaseUrl(baseUrl);
    if (normalized.isEmpty()) {
        GuardApiResponse response;
        response.errorMessage = invalidBaseUrlError();
        if (completion)
            completion(response);
        return;
    }
    QUrl url(normalized);
    QString basePath = url.path();
    while (basePath.endsWith(QLatin1Char('/')))
        basePath.chop(1);
    url.setPath(basePath + QStringLiteral("/api/health"));
    PendingRequest pending;
    pending.method = QStringLiteral("GET");
    pending.url = url;
    pending.completion = completion;
    pending.kind = RequestKind::Get;
    pending.skipAuthRetry = true;

    QNetworkRequest request(url);
    request.setRawHeader("Accept", "application/json");
    request.setRawHeader("X-Guard-Client", "Guard");
    QNetworkReply* reply = manager_.get(request);
    watchReply(reply, std::move(pending));
}

void GuardBackendClient::sendRequest(PendingRequest pending) {
    if (!pending.url.isValid()) {
        GuardApiResponse response;
        response.errorMessage = tr("Backend request URL is invalid.");
        deliverCompletion(std::move(pending), response);
        return;
    }

    QNetworkReply* reply = nullptr;
    switch (pending.kind) {
        case RequestKind::Get:
            reply = manager_.get(makeRequest(pending.url));
            break;
        case RequestKind::PostJson:
            reply = manager_.post(makeRequest(pending.url, QByteArrayLiteral("application/json")), pending.body);
            break;
        case RequestKind::PatchJson: {
            QNetworkRequest request = makeRequest(pending.url, QByteArrayLiteral("application/json"));
            const QByteArray verb = QByteArrayLiteral("PATCH");
#if QT_VERSION >= QT_VERSION_CHECK(5, 9, 0)
            reply = manager_.sendCustomRequest(request, verb, pending.body);
#else
            QBuffer* buffer = new QBuffer;
            buffer->setData(pending.body);
            buffer->open(QIODevice::ReadOnly);
            reply = manager_.sendCustomRequest(request, verb, buffer);
            buffer->setParent(reply);
#endif
            break;
        }
        case RequestKind::Delete:
            reply = manager_.deleteResource(makeRequest(pending.url));
            break;
        case RequestKind::PostMultipart: {
            QHttpMultiPart* multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType);
            for (auto it = pending.multipartFields.constBegin(); it != pending.multipartFields.constEnd(); ++it) {
                QHttpPart part;
                part.setHeader(QNetworkRequest::ContentDispositionHeader, QStringLiteral("form-data; name=\"%1\"").arg(it.key()));
                if (it.value().isObject()) {
                    part.setBody(QJsonDocument(it.value().toObject()).toJson(QJsonDocument::Compact));
                } else if (it.value().isArray()) {
                    part.setBody(QJsonDocument(it.value().toArray()).toJson(QJsonDocument::Compact));
                } else {
                    part.setBody(it.value().toVariant().toString().toUtf8());
                }
                multiPart->append(part);
            }
            for (const MultipartFile& file : pending.multipartFiles) {
                QHttpPart part;
                const QByteArray mimeType = file.mimeType.isEmpty() ? QByteArrayLiteral("application/octet-stream") : file.mimeType;
                part.setHeader(QNetworkRequest::ContentTypeHeader, QString::fromLatin1(mimeType.constData()));
                part.setHeader(QNetworkRequest::ContentDispositionHeader,
                               QStringLiteral("form-data; name=\"%1\"; filename=\"%2\"").arg(file.fieldName, file.fileName));
                part.setBody(file.data);
                multiPart->append(part);
            }
            reply = manager_.post(makeRequest(pending.url), multiPart);
            multiPart->setParent(reply);
            break;
        }
    }
    watchReply(reply, std::move(pending));
}

void GuardBackendClient::deliverCompletion(PendingRequest pending, const GuardApiResponse& response) {
    emit requestCompleted(pending.method, pending.url, response.httpStatus, response.ok());
    if (pending.completion)
        pending.completion(response);
}

void GuardBackendClient::watchReply(QNetworkReply* reply, PendingRequest pending) {
    if (!reply) {
        GuardApiResponse response;
        response.errorMessage = tr("Backend request could not be created.");
        deliverCompletion(std::move(pending), response);
        return;
    }

    const QString method = pending.method;
    const QUrl url = pending.url;
    pending.timeout = new QTimer(reply);
    pending.timeout->setSingleShot(true);
    pending.timeout->setInterval(requestTimeoutMs_);
    connect(pending.timeout, &QTimer::timeout, this, [this, reply]() {
        if (!pending_.contains(reply))
            return;
        reply->setProperty("guardTimedOut", true);
        reply->abort();
    });
    connect(reply, &QNetworkReply::finished, this, [this, reply]() { finishReply(reply, reply->property("guardTimedOut").toBool()); });
    pending_.insert(reply, std::move(pending));
    pending_[reply].timeout->start();
    emit requestStarted(method, url);
}

void GuardBackendClient::attemptAuthRetry(PendingRequest pending, const GuardApiResponse& failedResponse) {
    if (!tokenRefreshHandler_) {
        if (failedResponse.isNonRetryableAuthFailure())
            emit authorizationFailed(failedResponse);
        deliverCompletion(std::move(pending), failedResponse);
        return;
    }

    tokenRefreshHandler_([this, pending = std::move(pending), failedResponse](bool success) mutable {
        if (success) {
            sendRequest(std::move(pending));
            return;
        }
        if (failedResponse.isNonRetryableAuthFailure())
            emit authorizationFailed(failedResponse);
        deliverCompletion(std::move(pending), failedResponse);
    });
}

void GuardBackendClient::finishReply(QNetworkReply* reply, bool timedOut) {
    if (!pending_.contains(reply)) {
        reply->deleteLater();
        return;
    }
    PendingRequest pending = pending_.take(reply);
    if (pending.timeout)
        pending.timeout->stop();

    GuardApiResponse response;
    response.httpStatus = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    response.body = reply->readAll();
    response.timedOut = timedOut;
    if (timedOut) {
        response.errorMessage = tr("Backend request timed out.");
    } else if (reply->error() != QNetworkReply::NoError || response.httpStatus < 200 || response.httpStatus >= 300) {
        GuardApiErrorParser::applyToResponse(response.httpStatus, timedOut, response.body, &response);
        if (response.errorMessage.isEmpty()) {
            const QString fallback = response.httpStatus > 0
                                       ? tr("Backend request failed (%1): %2").arg(response.httpStatus).arg(reply->errorString())
                                       : tr("Backend request failed: %1").arg(reply->errorString());
            response.errorMessage = fallback;
        }
    }

    const bool canRetryAuth = !pending.skipAuthRetry && !pending.authRetried && !accessToken_.isEmpty() && response.shouldAttemptAuthRetry();
    if (canRetryAuth) {
        pending.authRetried = true;
        attemptAuthRetry(std::move(pending), response);
        reply->deleteLater();
        return;
    }

    if (response.isNonRetryableAuthFailure())
        emit authorizationFailed(response);
    deliverCompletion(std::move(pending), response);
    reply->deleteLater();
}

}  // namespace backend
}  // namespace guard
