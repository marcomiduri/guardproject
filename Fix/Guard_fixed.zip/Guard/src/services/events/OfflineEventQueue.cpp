#include "OfflineEventQueue.h"

#include <algorithm>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QSaveFile>
#include <QStandardPaths>

namespace guard {
namespace events {

namespace {
const qint64 kMaximumQueueBytes = 250LL * 1024LL * 1024LL;
const qint64 kMaximumAgeMs = 30LL * 24LL * 60LL * 60LL * 1000LL;
}  // namespace

OfflineEventQueue::OfflineEventQueue(QObject* parent) : QObject(parent) {
    QDir().mkpath(rootPath());
    performMaintenance();
}

QString OfflineEventQueue::rootPath() const {
    QString base = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (base.isEmpty())
        base = QDir::homePath() + QStringLiteral("/.guard");
    return QDir(base).filePath(QStringLiteral("pending-events"));
}

QString OfflineEventQueue::safeEventId(const QString& value) {
    QString safe = value.trimmed();
    for (int i = 0; i < safe.size(); ++i) {
        const QChar ch = safe.at(i);
        if (!ch.isLetterOrNumber() && ch != QLatin1Char('-') && ch != QLatin1Char('_'))
            safe[i] = QLatin1Char('_');
    }
    return safe.left(96);
}

QString OfflineEventQueue::eventDirectory(const QString& eventId) const {
    return QDir(rootPath()).filePath(safeEventId(eventId));
}

bool OfflineEventQueue::enqueue(const QueuedMultipartEvent& event, QString* errorMessage) {
    if (event.eventId.trimmed().isEmpty() || event.endpoint.trimmed().isEmpty()) {
        if (errorMessage)
            *errorMessage = tr("Pending event is missing an event ID or endpoint.");
        return false;
    }
    const QString directoryPath = eventDirectory(event.eventId);
    QDir existing(directoryPath);
    if (existing.exists() && !existing.removeRecursively()) {
        if (errorMessage)
            *errorMessage = tr("Pending event folder could not be replaced.");
        return false;
    }
    if (!QDir().mkpath(directoryPath)) {
        if (errorMessage)
            *errorMessage = tr("Pending event folder could not be created.");
        return false;
    }

    QJsonArray files;
    for (int i = 0; i < event.files.size(); ++i) {
        const backend::MultipartFile& source = event.files.at(i);
        const QString diskName = QStringLiteral("file-%1.bin").arg(i);
        QSaveFile file(QDir(directoryPath).filePath(diskName));
        if (!file.open(QIODevice::WriteOnly) || file.write(source.data) != source.data.size() || !file.commit()) {
            QDir(directoryPath).removeRecursively();
            if (errorMessage)
                *errorMessage = tr("Pending event image could not be saved.");
            return false;
        }
        QJsonObject item;
        item.insert(QStringLiteral("fieldName"), source.fieldName);
        item.insert(QStringLiteral("fileName"), source.fileName);
        item.insert(QStringLiteral("mimeType"), QString::fromLatin1(source.mimeType));
        item.insert(QStringLiteral("diskName"), diskName);
        files.append(item);
    }

    const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
    const qint64 queuedAtMs = event.queuedAtMs > 0 ? event.queuedAtMs : nowMs;
    const qint64 nextAttemptAtMs = event.nextAttemptAtMs > 0 ? event.nextAttemptAtMs : nowMs + 15000;

    QJsonObject metadata;
    metadata.insert(QStringLiteral("eventId"), event.eventId);
    metadata.insert(QStringLiteral("category"), event.category);
    metadata.insert(QStringLiteral("endpoint"), event.endpoint);
    metadata.insert(QStringLiteral("fields"), event.fields);
    metadata.insert(QStringLiteral("files"), files);
    metadata.insert(QStringLiteral("retryCount"), event.retryCount);
    metadata.insert(QStringLiteral("queuedAtMs"), static_cast<double>(queuedAtMs));
    metadata.insert(QStringLiteral("nextAttemptAtMs"), static_cast<double>(nextAttemptAtMs));
    metadata.insert(QStringLiteral("queuedAtUtc"), QDateTime::fromMSecsSinceEpoch(queuedAtMs, Qt::UTC).toString(Qt::ISODate));
    QSaveFile metadataFile(QDir(directoryPath).filePath(QStringLiteral("event.json")));
    const QByteArray payload = QJsonDocument(metadata).toJson(QJsonDocument::Indented);
    if (!metadataFile.open(QIODevice::WriteOnly) || metadataFile.write(payload) != payload.size() || !metadataFile.commit()) {
        QDir(directoryPath).removeRecursively();
        if (errorMessage)
            *errorMessage = tr("Pending event metadata could not be saved.");
        return false;
    }
    performMaintenance();
    return true;
}

QVector<QueuedMultipartEvent> OfflineEventQueue::loadPending(int maximumCount) const {
    QVector<QueuedMultipartEvent> result;
    QDir root(rootPath());
    const QFileInfoList directories = root.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Time | QDir::Reversed);
    const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
    for (const QFileInfo& directoryInfo : directories) {
        if (result.size() >= maximumCount)
            break;
        QFile metadataFile(QDir(directoryInfo.absoluteFilePath()).filePath(QStringLiteral("event.json")));
        if (!metadataFile.open(QIODevice::ReadOnly))
            continue;
        const QJsonDocument document = QJsonDocument::fromJson(metadataFile.readAll());
        if (!document.isObject())
            continue;
        const QJsonObject metadata = document.object();
        QueuedMultipartEvent event;
        event.eventId = metadata.value(QStringLiteral("eventId")).toString();
        event.category = metadata.value(QStringLiteral("category")).toString(QStringLiteral("event"));
        event.endpoint = metadata.value(QStringLiteral("endpoint")).toString();
        event.fields = metadata.value(QStringLiteral("fields")).toObject();
        event.retryCount = metadata.value(QStringLiteral("retryCount")).toInt(0);
        event.queuedAtMs = static_cast<qint64>(metadata.value(QStringLiteral("queuedAtMs")).toDouble(0));
        event.nextAttemptAtMs = static_cast<qint64>(metadata.value(QStringLiteral("nextAttemptAtMs")).toDouble(0));
        if (event.queuedAtMs > 0 && nowMs - event.queuedAtMs > kMaximumAgeMs)
            continue;
        if (event.nextAttemptAtMs > nowMs)
            continue;
        const QJsonArray files = metadata.value(QStringLiteral("files")).toArray();
        bool complete = true;
        for (const QJsonValue& value : files) {
            const QJsonObject item = value.toObject();
            QFile file(QDir(directoryInfo.absoluteFilePath()).filePath(item.value(QStringLiteral("diskName")).toString()));
            if (!file.open(QIODevice::ReadOnly)) {
                complete = false;
                break;
            }
            backend::MultipartFile multipart;
            multipart.fieldName = item.value(QStringLiteral("fieldName")).toString();
            multipart.fileName = item.value(QStringLiteral("fileName")).toString();
            multipart.mimeType = item.value(QStringLiteral("mimeType")).toString().toLatin1();
            multipart.data = file.readAll();
            event.files.append(multipart);
        }
        if (complete && !event.eventId.isEmpty() && !event.endpoint.isEmpty())
            result.append(event);
    }
    return result;
}

bool OfflineEventQueue::remove(const QString& eventId) {
    return QDir(eventDirectory(eventId)).removeRecursively();
}

void OfflineEventQueue::performMaintenance() {
    QDir root(rootPath());
    QFileInfoList directories = root.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Time);
    qint64 totalBytes = 0;
    struct Item {
        QFileInfo info;
        qint64 bytes;
        qint64 queuedAtMs;
    };
    QVector<Item> items;
    const qint64 nowMs = QDateTime::currentMSecsSinceEpoch();

    for (const QFileInfo& info : directories) {
        qint64 bytes = 0;
        QDir dir(info.absoluteFilePath());
        const QFileInfoList files = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot);
        for (const QFileInfo& file : files)
            bytes += file.size();

        qint64 queuedAtMs = info.lastModified().toMSecsSinceEpoch();
        QFile metadataFile(dir.filePath(QStringLiteral("event.json")));
        if (metadataFile.open(QIODevice::ReadOnly)) {
            const QJsonDocument document = QJsonDocument::fromJson(metadataFile.readAll());
            if (document.isObject()) {
                const qint64 stored = static_cast<qint64>(document.object().value(QStringLiteral("queuedAtMs")).toDouble(0));
                if (stored > 0)
                    queuedAtMs = stored;
            }
        }
        if (queuedAtMs > 0 && nowMs - queuedAtMs > kMaximumAgeMs) {
            dir.removeRecursively();
            continue;
        }
        items.append(Item{info, bytes, queuedAtMs});
        totalBytes += bytes;
    }

    std::sort(items.begin(), items.end(), [](const Item& left, const Item& right) { return left.queuedAtMs < right.queuedAtMs; });
    while (totalBytes > kMaximumQueueBytes && !items.isEmpty()) {
        const Item item = items.takeFirst();
        QDir(item.info.absoluteFilePath()).removeRecursively();
        totalBytes -= item.bytes;
    }
}

}  // namespace events
}  // namespace guard
