#pragma once

#include "services/backend/GuardBackendClient.h"

#include <QJsonObject>
#include <QObject>
#include <QString>
#include <QVector>

namespace guard {
namespace events {

struct QueuedMultipartEvent {
    QString eventId;
    QString category;
    QString endpoint;
    QJsonObject fields;
    QVector<guard::backend::MultipartFile> files;
    int retryCount = 0;
    qint64 queuedAtMs = 0;
    qint64 nextAttemptAtMs = 0;
};

class OfflineEventQueue : public QObject {
    Q_OBJECT

public:
    explicit OfflineEventQueue(QObject* parent = nullptr);

    QString rootPath() const;
    bool enqueue(const QueuedMultipartEvent& event, QString* errorMessage = nullptr);
    QVector<QueuedMultipartEvent> loadPending(int maximumCount = 10) const;
    bool remove(const QString& eventId);
    void performMaintenance();

private:
    QString eventDirectory(const QString& eventId) const;
    static QString safeEventId(const QString& value);
};

}  // namespace events
}  // namespace guard
