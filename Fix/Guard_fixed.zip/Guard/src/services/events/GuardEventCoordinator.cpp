#include "GuardEventCoordinator.h"

#include "GuardUuid.h"
#include "model/GuardFaceEventHelpers.h"
#include "model/GuardHazardEventHelpers.h"
#include "services/alerts/CameraAlarmService.h"
#include "services/alerts/LocalAlertService.h"
#include "services/backend/GuardBackendClient.h"

#include <hazard/HazardTypes.h>

#include <QBuffer>
#include <QCoreApplication>
#include <QEvent>
#include <QDateTime>
#include <QFontMetrics>
#include <QJsonArray>
#include <QJsonDocument>
#include <QPainter>
#include <QPen>

#include <algorithm>

namespace guard {
namespace events {

namespace {

QRect clampedRect(const QRect& source, const QImage& image) {
    if (image.isNull() || image.width() <= 0 || image.height() <= 0 || source.width() == 0 || source.height() == 0)
        return QRect();

    const qint64 x1 = source.x();
    const qint64 y1 = source.y();
    const qint64 x2 = x1 + static_cast<qint64>(source.width()) - (source.width() > 0 ? 1 : -1);
    const qint64 y2 = y1 + static_cast<qint64>(source.height()) - (source.height() > 0 ? 1 : -1);
    const qint64 left = qMax<qint64>(0, qMin(x1, x2));
    const qint64 top = qMax<qint64>(0, qMin(y1, y2));
    const qint64 right = qMin<qint64>(image.width() - 1, qMax(x1, x2));
    const qint64 bottom = qMin<qint64>(image.height() - 1, qMax(y1, y2));
    if (left > right || top > bottom)
        return QRect();
    return QRect(QPoint(static_cast<int>(left), static_cast<int>(top)), QPoint(static_cast<int>(right), static_cast<int>(bottom)));
}

void drawLabel(QPainter& painter, const QRect& box, const QString& text, const QColor& color) {
    QFont font = painter.font();
    font.setBold(true);
    font.setPixelSize(qMax(14, painter.device()->height() / 45));
    painter.setFont(font);
    const QFontMetrics metrics(font);
    const int width = metrics.boundingRect(text).width() + 18;
    const int height = metrics.height() + 10;
    QRect label(box.left(), qMax(0, box.top() - height), width, height);
    if (label.right() >= painter.device()->width())
        label.moveRight(painter.device()->width() - 1);
    painter.fillRect(label, QColor(color.red(), color.green(), color.blue(), 220));
    painter.setPen(Qt::white);
    painter.drawText(label.adjusted(8, 3, -8, -3), Qt::AlignLeft | Qt::AlignVCenter, text);
}

QString utcIso(qint64 timestampMs) {
    const qint64 value = timestampMs > 0 ? timestampMs : QDateTime::currentMSecsSinceEpoch();
    return QDateTime::fromMSecsSinceEpoch(value, Qt::UTC).toString(QStringLiteral("yyyy-MM-dd'T'HH:mm:ss.zzz'Z'"));
}

}  // namespace

GuardEventCoordinator::GuardEventCoordinator(backend::GuardBackendClient* client, alerts::LocalAlertService* localAlerts,
                                             alerts::CameraAlarmService* cameraAlarms, QObject* parent)
: QObject(parent), client_(client), localAlerts_(localAlerts), cameraAlarms_(cameraAlarms), queue_(this) {
    unknownTrackTimer_.setInterval(250);
    connect(&unknownTrackTimer_, &QTimer::timeout, this, &GuardEventCoordinator::evaluateUnknownTracks);
    unknownTrackTimer_.start();
    retryTimer_.setInterval(15000);
    connect(&retryTimer_, &QTimer::timeout, this, &GuardEventCoordinator::retryOfflineEvents);
    retryTimer_.start();
    if (localAlerts_) {
        connect(localAlerts_, &alerts::LocalAlertService::hazardAlarmStateChanged, this, &GuardEventCoordinator::hazardAlarmStateChanged);
    }
}

void GuardEventCoordinator::beginApplicationShutdown() {
    if (shuttingDown_)
        return;
    shuttingDown_ = true;
    eventUploadEnabled_ = false;
    backendRoomAssigned_ = false;
    ++backendRoomGeneration_;
    unknownTrackTimer_.stop();
    retryTimer_.stop();
    faceTracks_.clear();
    hazardUploadSent_.clear();
    activeHazardIncidentKeys_.clear();
    retryInProgress_ = false;
    QCoreApplication::removePostedEvents(this, QEvent::MetaCall);
}

void GuardEventCoordinator::setNotificationSettings(const backend::NotificationSettings& settings) {
    notificationSettings_ = settings;
}

backend::NotificationSettings GuardEventCoordinator::notificationSettings() const {
    return notificationSettings_;
}
void GuardEventCoordinator::setEventUploadEnabled(bool enabled) {
    eventUploadEnabled_ = enabled;
}

void GuardEventCoordinator::setBackendRoomAssigned(bool assigned) {
    if (shuttingDown_)
        return;
    if (backendRoomAssigned_ == assigned)
        return;
    backendRoomAssigned_ = assigned;
    ++backendRoomGeneration_;
    if (!assigned)
        resetForRoomTransition();
}

void GuardEventCoordinator::setActiveRoomId(const QString& roomId) {
    if (shuttingDown_)
        return;
    const QString normalizedRoomId = roomId.trimmed();
    if (activeRoomId_ == normalizedRoomId)
        return;
    activeRoomId_ = normalizedRoomId;
    ++backendRoomGeneration_;
    resetForRoomTransition();
}

void GuardEventCoordinator::resetForRoomTransition() {
    faceTracks_.clear();
    hazardUploadSent_.clear();
    activeHazardIncidentKeys_.clear();
    retryInProgress_ = false;
    if (localAlerts_)
        localAlerts_->resetHazardState();
}

void GuardEventCoordinator::setFaceRegistryLoaded(bool loaded) {
    faceRegistryLoaded_ = loaded;
}

QString GuardEventCoordinator::faceTrackKey(const GuardFaceOccurrence& occurrence) const {
    return guard::events::faceTrackKey(occurrence.camera.localFaceTrackCameraKey(), occurrence.trackId);
}

QString GuardEventCoordinator::faceTrackKey(const QString& cameraId, quint64 trackId) const {
    return guard::events::faceTrackKey(cameraId, trackId);
}

QString GuardEventCoordinator::hazardKey(const CameraUiModel& camera, int hazardType) const {
    return guard::events::hazardOccurrenceKey(camera.localFaceTrackCameraKey(), hazardType);
}

bool GuardEventCoordinator::acceptsCameraRoom(const CameraUiModel& camera) const {
    const QString cameraRoomId = camera.roomId.trimmed();
    if (activeRoomId_.isEmpty())
        return cameraRoomId.isEmpty();
    return cameraRoomId == activeRoomId_;
}

void GuardEventCoordinator::handleFaceOccurrence(const GuardFaceOccurrence& occurrence) {
    if (shuttingDown_ || !acceptsCameraRoom(occurrence.camera) || occurrence.trackId == 0 || occurrence.frame.isNull())
        return;
    const QString key = faceTrackKey(occurrence);
    FaceTrackState state = faceTracks_.value(key);
    if (state.firstSeenMs == 0)
        state.firstSeenMs = QDateTime::currentMSecsSinceEpoch();

    GuardFaceOccurrence merged = occurrence;
    // Break implicit sharing with decoder/preview frames before storing this
    // occurrence for delayed unknown-face decisions or backend upload retries.
    if (!merged.frame.isNull())
        merged.frame = merged.frame.copy();
    if (!merged.identified && state.latest.identified && state.latest.faceRegistryId > 0 && !state.latest.displayName.trimmed().isEmpty()) {
        merged.identified = true;
        merged.faceRegistryId = state.latest.faceRegistryId;
        merged.displayName = state.latest.displayName;
        merged.similarity = state.latest.similarity;
    }
    state.latest = merged;

    if (guard::events::shouldSendRecognizedFaceEvent(state.recognizedSent, merged.identified, merged.faceRegistryId)) {
        state.recognizedSent = true;
        faceTracks_.insert(key, state);
        uploadFace(merged, true, state.unknownEventId);
        return;
    }
    faceTracks_.insert(key, state);
}

void GuardEventCoordinator::handleFaceTrackLost(const QString& cameraId, quint64 trackId) {
    if (shuttingDown_)
        return;
    const QString key = faceTrackKey(cameraId, trackId);
    FaceTrackState state = faceTracks_.take(key);
    const qint64 elapsedMs = state.firstSeenMs > 0 ? QDateTime::currentMSecsSinceEpoch() - state.firstSeenMs : 0;
    if (elapsedMs >= unknownDecisionDelayMs_ && faceRegistryLoaded_ &&
        guard::events::shouldSendUnknownFaceOnTrackLost(state.unknownSent, state.recognizedSent, state.latest.frame.isNull())) {
        uploadFace(state.latest, false);
    }
}

void GuardEventCoordinator::evaluateUnknownTracks() {
    if (shuttingDown_)
        return;
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    const QStringList keys = faceTracks_.keys();
    for (const QString& key : keys) {
        FaceTrackState state = faceTracks_.value(key);
        if (!guard::events::shouldSendUnknownFaceAfterDelay(state.unknownSent, state.recognizedSent, state.latest.identified, now - state.firstSeenMs,
                                                            unknownDecisionDelayMs_, faceRegistryLoaded_)) {
            continue;
        }
        state.unknownSent = true;
        state.unknownEventId = uploadFace(state.latest, false);
        faceTracks_.insert(key, state);
    }
}

QString GuardEventCoordinator::uploadFace(const GuardFaceOccurrence& occurrence, bool identified, const QString& supersedesEventId) {
    GuardFaceOccurrence stableOccurrence = occurrence;
    if (!stableOccurrence.frame.isNull())
        stableOccurrence.frame = stableOccurrence.frame.copy();

    // Unknown/approved access semantics exist only inside an assigned room. A
    // fresh local-only launch must not schedule an access-denied sound or event
    // several seconds after displaying a harmless Unknown tracking overlay.
    if (!backendRoomAssigned_ || !guard::events::canUploadFaceEvent(stableOccurrence.camera))
        return QString();

    const bool incoming = stableOccurrence.camera.direction == CameraDirection::Incoming;
    if (!identified && guard::events::shouldPlayUnknownIncomingVoice(incoming, notificationSettings_.notifyUnknownIncoming) && localAlerts_) {
        localAlerts_->speakUnknownIncoming();
    }

    const QString eventId = guardCreateUuidString();
    QJsonObject eventData;
    eventData.insert(QStringLiteral("eventId"), eventId);
    eventData.insert(QStringLiteral("cameraId"), stableOccurrence.camera.eventCameraId());
    eventData.insert(QStringLiteral("trackId"), static_cast<double>(stableOccurrence.trackId));
    eventData.insert(QStringLiteral("eventTime"), utcIso(stableOccurrence.timestampMs));
    eventData.insert(QStringLiteral("source"), QStringLiteral("GUARD2"));
    if (identified) {
        eventData.insert(QStringLiteral("faceRegistryId"), static_cast<double>(stableOccurrence.faceRegistryId));
        eventData.insert(QStringLiteral("similarity"), stableOccurrence.similarity);
        if (!supersedesEventId.isEmpty()) {
            eventData.insert(QStringLiteral("supersedesEventId"), supersedesEventId);
        }
    }
    QJsonObject rectangle;
    if (!stableOccurrence.frame.isNull() && stableOccurrence.frame.width() > 0 && stableOccurrence.frame.height() > 0) {
        rectangle.insert(QStringLiteral("x"), static_cast<double>(stableOccurrence.bounds.x()) / stableOccurrence.frame.width());
        rectangle.insert(QStringLiteral("y"), static_cast<double>(stableOccurrence.bounds.y()) / stableOccurrence.frame.height());
        rectangle.insert(QStringLiteral("width"), static_cast<double>(stableOccurrence.bounds.width()) / stableOccurrence.frame.width());
        rectangle.insert(QStringLiteral("height"), static_cast<double>(stableOccurrence.bounds.height()) / stableOccurrence.frame.height());
    }
    eventData.insert(QStringLiteral("rectangle"), rectangle);

    QJsonObject fields;
    fields.insert(QStringLiteral("eventData"), QString::fromUtf8(QJsonDocument(eventData).toJson(QJsonDocument::Compact)));
    QVector<backend::MultipartFile> files;
    const QByteArray frameJpeg = encodeJpeg(annotateFaceFrame(stableOccurrence));
    const QByteArray faceJpeg = encodeJpeg(cropFace(stableOccurrence), 90);
    if (!frameJpeg.isEmpty())
        files.append(backend::MultipartFile{QStringLiteral("frameImage"), QStringLiteral("frame.jpg"), QByteArrayLiteral("image/jpeg"), frameJpeg});
    if (!faceJpeg.isEmpty())
        files.append(backend::MultipartFile{QStringLiteral("faceImage"), QStringLiteral("face.jpg"), QByteArrayLiteral("image/jpeg"), faceJpeg});

    const QString endpoint = identified ? QStringLiteral("/api/guard/events/appeared") : QStringLiteral("/api/guard/events/unknown-appeared");

    submitMultipart(
      eventId, identified ? QStringLiteral("recognized-face") : QStringLiteral("unknown-face"), endpoint, fields, files,
      [this, stableOccurrence, identified, incoming](const backend::GuardApiResponse& response) {
          if (!identified || !incoming)
              return;
          QString parseError;
          const QJsonObject object = response.jsonObject(&parseError);
          if (!parseError.isEmpty())
              return;
          const bool approved = object.value(QStringLiteral("approved")).toBool(false);
          emit accessDecisionReceived(stableOccurrence.camera.eventCameraId(), stableOccurrence.trackId, approved);
          if (guard::events::shouldPlayUnapprovedIncomingVoice(incoming, approved, notificationSettings_.notifyUnapprovedIncoming) && localAlerts_) {
              localAlerts_->speakUnapprovedIncoming();
          }
      });
    return eventId;
}

void GuardEventCoordinator::clearHazardUploadState(const CameraUiModel& camera, const QVector<GuardHazardDetection>& detections, bool endedAllTypes) {
    for (const QString& key : guard::events::hazardUploadKeysToClearOnEnded(camera.localFaceTrackCameraKey(), detections, endedAllTypes)) {
        hazardUploadSent_.remove(key);
    }
}

void GuardEventCoordinator::handleHazardOccurrence(const GuardHazardOccurrence& occurrence) {
    if (shuttingDown_ || !acceptsCameraRoom(occurrence.camera))
        return;

    const bool maintainsAlarm = guard::events::shouldMaintainHazardAlarm(occurrence.eventType);
    bool beginsNewLocalIncident = false;

    if (maintainsAlarm) {
        for (const GuardHazardDetection& detection : occurrence.detections) {
            const QString key = hazardKey(occurrence.camera, detection.hazardType);
            if (!activeHazardIncidentKeys_.contains(key)) {
                activeHazardIncidentKeys_.insert(key);
                beginsNewLocalIncident = true;
            }
            if (localAlerts_)
                localAlerts_->startHazardAlarm(key);
            if (cameraAlarms_) {
                QString ignored;
                cameraAlarms_->startAlarm(occurrence.camera, guard::events::hazardTypeName(detection.hazardType), &ignored);
            }
        }

        // Backend delivery dedupe is independent from local indicator state.
        // A post-reconnect Updated event becomes a new incident because the
        // camera-session stop handler clears both sets.
        if (guard::events::shouldUploadHazardOnStarted(hazardUploadSent_, occurrence.camera.localFaceTrackCameraKey(), occurrence.detections) &&
            uploadHazard(occurrence)) {
            for (const QString& key :
                 guard::events::hazardUploadKeysForOccurrence(occurrence.camera.localFaceTrackCameraKey(), occurrence.detections)) {
                hazardUploadSent_.insert(key);
            }
        }
    } else if (guard::events::shouldHandleHazardEnded(occurrence.eventType)) {
        const bool endedAllTypes = occurrence.detections.isEmpty();
        const QStringList endedKeys =
          guard::events::hazardUploadKeysToClearOnEnded(occurrence.camera.localFaceTrackCameraKey(), occurrence.detections, endedAllTypes);

        for (const QString& key : endedKeys) {
            activeHazardIncidentKeys_.remove(key);
            if (localAlerts_)
                localAlerts_->endHazardAlarm(key);
        }
        if (cameraAlarms_) {
            QString ignored;
            cameraAlarms_->stopAlarm(occurrence.camera, &ignored);
        }
        clearHazardUploadState(occurrence.camera, occurrence.detections, endedAllTypes);
    }

    if (localAlerts_) {
        const int indicatorEventType = beginsNewLocalIncident ? static_cast<int>(guardvision::HazardEventType::Started) : occurrence.eventType;
        localAlerts_->noteHazardIndicatorEvent(indicatorEventType);
    }
}

void GuardEventCoordinator::handleCameraHazardSessionStopped(const QString& localCameraKey) {
    const QString normalizedKey = localCameraKey.trimmed();
    if (normalizedKey.isEmpty())
        return;

    const QString fireKey = guard::events::hazardOccurrenceKey(normalizedKey, static_cast<int>(guardvision::HazardType::Fire));
    const QString smokeKey = guard::events::hazardOccurrenceKey(normalizedKey, static_cast<int>(guardvision::HazardType::Smoke));

    // Disconnect/reconnect is an incident boundary even when the retained
    // GuardVision stream later reports Updated rather than Started. Clear both
    // local incident and backend upload dedupe state so the first event from the
    // next camera session reopens the indicator and creates a new backend row.
    activeHazardIncidentKeys_.remove(fireKey);
    activeHazardIncidentKeys_.remove(smokeKey);
    hazardUploadSent_.remove(fireKey);
    hazardUploadSent_.remove(smokeKey);

    if (localAlerts_) {
        localAlerts_->endHazardAlarm(fireKey);
        localAlerts_->endHazardAlarm(smokeKey);
        localAlerts_->syncHazardIndicatorIdleHideTimer();
    }
}

bool GuardEventCoordinator::uploadHazard(const GuardHazardOccurrence& occurrence) {
    GuardHazardOccurrence stableOccurrence = occurrence;
    if (!stableOccurrence.frame.isNull())
        stableOccurrence.frame = stableOccurrence.frame.copy();

    if (shuttingDown_ || stableOccurrence.detections.isEmpty())
        return false;
    if (!backendRoomAssigned_ || !guard::events::canUploadFaceEvent(stableOccurrence.camera))
        return false;
    const QString eventId = guardCreateUuidString();
    const GuardHazardDetection strongest =
      *std::max_element(stableOccurrence.detections.constBegin(), stableOccurrence.detections.constEnd(),
                        [](const GuardHazardDetection& left, const GuardHazardDetection& right) { return left.confidence < right.confidence; });

    QJsonArray detections;
    for (const GuardHazardDetection& detection : stableOccurrence.detections) {
        QJsonObject item;
        item.insert(QStringLiteral("type"), guard::events::hazardTypeName(detection.hazardType));
        item.insert(QStringLiteral("confidence"), detection.confidence);
        if (!stableOccurrence.frame.isNull() && stableOccurrence.frame.width() > 0 && stableOccurrence.frame.height() > 0) {
            QJsonObject rectangle;
            rectangle.insert(QStringLiteral("x"), static_cast<double>(detection.bounds.x()) / stableOccurrence.frame.width());
            rectangle.insert(QStringLiteral("y"), static_cast<double>(detection.bounds.y()) / stableOccurrence.frame.height());
            rectangle.insert(QStringLiteral("width"), static_cast<double>(detection.bounds.width()) / stableOccurrence.frame.width());
            rectangle.insert(QStringLiteral("height"), static_cast<double>(detection.bounds.height()) / stableOccurrence.frame.height());
            item.insert(QStringLiteral("rectangle"), rectangle);
        }
        detections.append(item);
    }

    QJsonObject fields;
    fields.insert(QStringLiteral("eventId"), eventId);
    fields.insert(QStringLiteral("cameraId"), stableOccurrence.camera.eventCameraId());
    fields.insert(QStringLiteral("hazardType"), guard::events::hazardTypeName(strongest.hazardType));
    fields.insert(QStringLiteral("confidence"), QString::number(strongest.confidence, 'f', 6));
    fields.insert(QStringLiteral("eventTime"), utcIso(stableOccurrence.timestampMs));
    fields.insert(QStringLiteral("source"), QStringLiteral("GUARD2"));
    fields.insert(QStringLiteral("detections"), QString::fromUtf8(QJsonDocument(detections).toJson(QJsonDocument::Compact)));
    QVector<backend::MultipartFile> files;
    const QByteArray snapshot = encodeJpeg(annotateHazardFrame(stableOccurrence));
    if (!snapshot.isEmpty())
        files.append(backend::MultipartFile{QStringLiteral("snapshot"), QStringLiteral("hazard.jpg"), QByteArrayLiteral("image/jpeg"), snapshot});
    return submitMultipart(eventId, QStringLiteral("hazard"), QStringLiteral("/api/guard/events/hazard-detected"), fields, files);
}

bool GuardEventCoordinator::submitMultipart(const QString& eventId, const QString& category, const QString& endpoint, const QJsonObject& fields,
                                            const QVector<backend::MultipartFile>& files,
                                            const std::function<void(const backend::GuardApiResponse&)>& successHandler) {
    if (shuttingDown_ || !backendRoomAssigned_)
        return false;

    if (!eventUploadEnabled_ || !client_) {
        QueuedMultipartEvent event;
        event.eventId = eventId;
        event.category = category;
        event.endpoint = endpoint;
        event.fields = fields;
        event.files = files;
        QString queueError;
        if (queue_.enqueue(event, &queueError)) {
            emit eventQueued(eventId, category, tr("Backend session is unavailable."));
            return true;
        }
        emit eventRejected(eventId, category, queueError);
        return false;
    }
    const quint64 requestRoomGeneration = backendRoomGeneration_;
    client_->postMultipart(
      endpoint, fields, files,
      [this, eventId, category, endpoint, fields, files, successHandler, requestRoomGeneration](const backend::GuardApiResponse& response) {
          if (requestRoomGeneration != backendRoomGeneration_ || !backendRoomAssigned_)
              return;
          if (response.ok()) {
              if (successHandler)
                  successHandler(response);
              emit eventUploaded(eventId, category);
              return;
          }
          if (shouldQueue(response)) {
              QueuedMultipartEvent event;
              event.eventId = eventId;
              event.category = category;
              event.endpoint = endpoint;
              event.fields = fields;
              event.files = files;
              QString queueError;
              if (queue_.enqueue(event, &queueError)) {
                  emit eventQueued(eventId, category, response.errorMessage);
              } else {
                  emit eventRejected(eventId, category, queueError);
              }
          } else {
              emit eventRejected(eventId, category, response.errorMessage);
          }
      });
    return true;
}

void GuardEventCoordinator::retryOfflineEvents() {
    if (shuttingDown_ || retryInProgress_ || !backendRoomAssigned_ || !eventUploadEnabled_ || !client_)
        return;
    const QVector<QueuedMultipartEvent> pending = queue_.loadPending(1);
    if (pending.isEmpty())
        return;
    retryInProgress_ = true;
    const QueuedMultipartEvent event = pending.first();
    const quint64 requestRoomGeneration = backendRoomGeneration_;
    client_->postMultipart(event.endpoint, event.fields, event.files,
                           [this, event, requestRoomGeneration](const backend::GuardApiResponse& response) {
                               retryInProgress_ = false;
                               if (requestRoomGeneration != backendRoomGeneration_ || !backendRoomAssigned_)
                                   return;
                               if (response.ok()) {
                                   queue_.remove(event.eventId);
                                   emit eventUploaded(event.eventId, event.category);
                               } else if (!shouldQueue(response)) {
                                   queue_.remove(event.eventId);
                                   emit eventRejected(event.eventId, event.category, response.errorMessage);
                               } else {
                                   QueuedMultipartEvent retryEvent = event;
                                   retryEvent.retryCount = qMin(event.retryCount + 1, 16);
                                   const int exponent = qMin(retryEvent.retryCount, 6);
                                   const qint64 delayMs = qMin<qint64>(15LL * 60LL * 1000LL, 15000LL * (1LL << exponent));
                                   retryEvent.nextAttemptAtMs = QDateTime::currentMSecsSinceEpoch() + delayMs;
                                   QString queueError;
                                   if (!queue_.enqueue(retryEvent, &queueError)) {
                                       emit eventRejected(event.eventId, event.category, queueError);
                                   }
                               }
                           });
}

void GuardEventCoordinator::acknowledgeHazardAlarm() {
    if (localAlerts_)
        localAlerts_->acknowledgeHazardAlarm();
}

void GuardEventCoordinator::dismissHazardAlarm() {
    if (localAlerts_)
        localAlerts_->dismissHazardAlarm();
}

QImage GuardEventCoordinator::annotateFaceFrame(const GuardFaceOccurrence& occurrence) {
    if (occurrence.frame.isNull())
        return QImage();
    QImage image = occurrence.frame.convertToFormat(QImage::Format_RGB32);
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);
    const QRect box = clampedRect(occurrence.bounds, image);
    if (!box.isEmpty()) {
        QPen pen(occurrence.identified ? QColor(0, 220, 120) : QColor(255, 190, 0));
        pen.setWidth(qMax(2, image.width() / 500));
        painter.setPen(pen);
        painter.drawRect(box);
        const QString label = occurrence.identified ? QStringLiteral("%1 %2%").arg(occurrence.displayName).arg(qRound(occurrence.similarity * 100.0))
                                                    : QStringLiteral("UNKNOWN");
        drawLabel(painter, box, label, pen.color());
    }
    const QString footer = QStringLiteral("%1 | %2 UTC").arg(occurrence.camera.displayName(), utcIso(occurrence.timestampMs));
    QRect footerRect(0, qMax(0, image.height() - qMax(32, image.height() / 18)), image.width(), qMax(32, image.height() / 18));
    painter.fillRect(footerRect, QColor(0, 0, 0, 170));
    painter.setPen(Qt::white);
    painter.drawText(footerRect.adjusted(12, 0, -12, 0), Qt::AlignLeft | Qt::AlignVCenter, footer);
    return image;
}

QImage GuardEventCoordinator::cropFace(const GuardFaceOccurrence& occurrence) {
    if (occurrence.frame.isNull())
        return QImage();
    QRect expanded = occurrence.bounds.adjusted(-occurrence.bounds.width() / 6, -occurrence.bounds.height() / 6, occurrence.bounds.width() / 6,
                                                occurrence.bounds.height() / 6);
    expanded = clampedRect(expanded, occurrence.frame);
    return expanded.isEmpty() ? QImage() : occurrence.frame.copy(expanded);
}

QImage GuardEventCoordinator::annotateHazardFrame(const GuardHazardOccurrence& occurrence) {
    if (occurrence.frame.isNull())
        return QImage();
    QImage image = occurrence.frame.convertToFormat(QImage::Format_RGB32);
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, true);
    for (const GuardHazardDetection& detection : occurrence.detections) {
        const QRect box = clampedRect(detection.bounds, image);
        if (box.isEmpty())
            continue;
        QPen pen(QColor(230, 40, 40));
        pen.setWidth(qMax(3, image.width() / 450));
        painter.setPen(pen);
        painter.drawRect(box);
        drawLabel(painter, box, guard::events::hazardSnapshotLabel(detection.hazardType, detection.confidence), pen.color());
    }
    const QString footer = QStringLiteral("%1 | %2 UTC").arg(occurrence.camera.displayName(), utcIso(occurrence.timestampMs));
    QRect footerRect(0, qMax(0, image.height() - qMax(32, image.height() / 18)), image.width(), qMax(32, image.height() / 18));
    painter.fillRect(footerRect, QColor(0, 0, 0, 170));
    painter.setPen(Qt::white);
    painter.drawText(footerRect.adjusted(12, 0, -12, 0), Qt::AlignLeft | Qt::AlignVCenter, footer);
    return image;
}

QByteArray GuardEventCoordinator::encodeJpeg(const QImage& image, int quality) {
    if (image.isNull())
        return QByteArray();
    QImage output = image;
    if (output.width() > 1920 || output.height() > 1920)
        output = output.scaled(QSize(1920, 1920), Qt::KeepAspectRatio, Qt::SmoothTransformation);
    QByteArray bytes;
    QBuffer buffer(&bytes);
    if (!buffer.open(QIODevice::WriteOnly) || !output.save(&buffer, "JPEG", quality))
        return QByteArray();
    return bytes;
}

bool GuardEventCoordinator::shouldQueue(const backend::GuardApiResponse& response) {
    return response.isRetryableFailure();
}

}  // namespace events
}  // namespace guard
