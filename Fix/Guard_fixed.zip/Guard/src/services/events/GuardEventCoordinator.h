#pragma once

#include "model/GuardBackendModels.h"
#include "model/GuardEventModels.h"
#include "services/events/OfflineEventQueue.h"

#include <QHash>
#include <QObject>
#include <QSet>
#include <QTimer>
#include <functional>

namespace guard {
namespace alerts {
class CameraAlarmService;
class LocalAlertService;
}  // namespace alerts
namespace backend {
class GuardBackendClient;
}
namespace events {

class GuardEventCoordinator : public QObject {
    Q_OBJECT

public:
    GuardEventCoordinator(backend::GuardBackendClient* client, alerts::LocalAlertService* localAlerts, alerts::CameraAlarmService* cameraAlarms,
                          QObject* parent = nullptr);

    void setNotificationSettings(const backend::NotificationSettings& settings);
    backend::NotificationSettings notificationSettings() const;
    void setEventUploadEnabled(bool enabled);
    void setBackendRoomAssigned(bool assigned);
    void setActiveRoomId(const QString& roomId);
    void resetForRoomTransition();
    void setFaceRegistryLoaded(bool loaded);
    void beginApplicationShutdown();

public slots:
    void handleFaceOccurrence(const GuardFaceOccurrence& occurrence);
    void handleFaceTrackLost(const QString& cameraId, quint64 trackId);
    void handleHazardOccurrence(const GuardHazardOccurrence& occurrence);
    void handleCameraHazardSessionStopped(const QString& localCameraKey);
    void retryOfflineEvents();
    void acknowledgeHazardAlarm();
    void dismissHazardAlarm();

signals:
    void eventUploaded(QString eventId, QString category);
    void eventQueued(QString eventId, QString category, QString reason);
    void eventRejected(QString eventId, QString category, QString reason);
    void accessDecisionReceived(QString cameraId, quint64 trackId, bool approved);
    void hazardAlarmStateChanged(bool sounding);

private:
    struct FaceTrackState {
        GuardFaceOccurrence latest;
        qint64 firstSeenMs = 0;
        bool unknownSent = false;
        bool recognizedSent = false;
        QString unknownEventId;
    };

    QString faceTrackKey(const GuardFaceOccurrence& occurrence) const;
    QString faceTrackKey(const QString& cameraId, quint64 trackId) const;
    QString hazardKey(const CameraUiModel& camera, int hazardType) const;
    bool acceptsCameraRoom(const CameraUiModel& camera) const;
    void evaluateUnknownTracks();
    QString uploadFace(const GuardFaceOccurrence& occurrence, bool identified, const QString& supersedesEventId = QString());
    bool uploadHazard(const GuardHazardOccurrence& occurrence);
    bool submitMultipart(const QString& eventId, const QString& category, const QString& endpoint, const QJsonObject& fields,
                         const QVector<backend::MultipartFile>& files,
                         const std::function<void(const backend::GuardApiResponse&)>& successHandler = {});
    static QImage annotateFaceFrame(const GuardFaceOccurrence& occurrence);
    static QImage cropFace(const GuardFaceOccurrence& occurrence);
    static QImage annotateHazardFrame(const GuardHazardOccurrence& occurrence);
    static QByteArray encodeJpeg(const QImage& image, int quality = 85);
    static bool shouldQueue(const backend::GuardApiResponse& response);
    void clearHazardUploadState(const CameraUiModel& camera, const QVector<GuardHazardDetection>& detections, bool endedAllTypes);

    backend::GuardBackendClient* client_ = nullptr;
    alerts::LocalAlertService* localAlerts_ = nullptr;
    alerts::CameraAlarmService* cameraAlarms_ = nullptr;
    OfflineEventQueue queue_;
    backend::NotificationSettings notificationSettings_;
    QHash<QString, FaceTrackState> faceTracks_;
    QSet<QString> hazardUploadSent_;
    QSet<QString> activeHazardIncidentKeys_;
    QTimer unknownTrackTimer_;
    QTimer retryTimer_;
    bool retryInProgress_ = false;
    bool eventUploadEnabled_ = true;
    bool backendRoomAssigned_ = false;
    QString activeRoomId_;
    quint64 backendRoomGeneration_ = 0;
    bool faceRegistryLoaded_ = false;
    bool shuttingDown_ = false;
    static constexpr int kUnknownDecisionDelayMs = 3500;
    int unknownDecisionDelayMs_ = kUnknownDecisionDelayMs;
};

}  // namespace events
}  // namespace guard
