#pragma once

#include <QByteArray>
#include <QHash>
#include <QObject>
#include <QString>
#include <QTimer>

class QProcess;

namespace guard {
namespace alerts {

class LocalAlertService : public QObject {
    Q_OBJECT

public:
    explicit LocalAlertService(QObject* parent = nullptr);
    ~LocalAlertService() override;

    void reloadSettings();
    bool hazardAlarmEnabled() const;
    int volume() const;

    void startHazardAlarm(const QString& occurrenceKey);
    void endHazardAlarm(const QString& occurrenceKey);
    void acknowledgeHazardAlarm();
    void dismissHazardAlarm();
    void resetHazardState();
    void noteHazardIndicatorEvent(int eventType);
    void syncHazardIndicatorIdleHideTimer();
    void testHazardAlarm();
    void speakUnknownIncoming();
    void speakUnapprovedIncoming();

signals:
    void hazardAlarmStateChanged(bool sounding);
    void hazardPresenceChanged(bool present);

private:
    void updateHazardTimer();
    void extendHazardIndicatorPresence();
    void clearHazardIndicatorPresence();
    void refreshHazardIndicatorPresence();
    void onHazardIndicatorPresenceExpired();
    void beepOnce();
    bool playSoundBuffer(const QByteArray& sound);
    void playAccessAlert(const QByteArray& sound, const QString& text);
    void speak(const QString& text);

    QHash<QString, bool> activeHazards_;
    QTimer hazardTimer_;
    QTimer indicatorPresenceTimer_;
    qint64 hazardIndicatorVisibleUntilMs_ = 0;
    qint64 lastHazardIndicatorActivityMs_ = 0;
    bool hazardAlarmEnabled_ = true;
    bool hazardPresent_ = false;
    bool repeatUntilAcknowledged_ = true;
    bool acknowledged_ = false;
    int volume_ = 80;
    QByteArray hazardSound_;
    QByteArray unknownAccessSound_;
    QByteArray unapprovedAccessSound_;
    QByteArray activeAsyncSound_;
    QString activeAsyncSoundFile_;
};

}  // namespace alerts
}  // namespace guard
