#include "LocalAlertService.h"

#include "model/GuardHazardEventHelpers.h"

#include <QApplication>
#include <QStandardPaths>
#include <QDir>
#include <QCryptographicHash>
#include <QDateTime>
#include <QFile>
#include <QProcess>
#include <QSettings>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#endif

namespace guard {
namespace alerts {

namespace {
const char kHazardAlarmEnabledKey[] = "alerts/pcHazardAlarmEnabled";
const char kHazardAlarmVolumeKey[] = "alerts/pcHazardAlarmVolume";
const char kHazardRepeatKey[] = "alerts/repeatUntilAcknowledged";
const char kAccessDeniedUnknownWav[] = ":/audio/access_denied_unknown.wav";
const char kAccessDeniedUnapprovedWav[] = ":/audio/access_denied_unapproved.wav";
constexpr int kHazardIndicatorDisplayMs = 60000;

QByteArray loadScaledWavFromResource(const QString& resourcePath, int volume) {
    QFile file(resourcePath);
    if (!file.open(QIODevice::ReadOnly))
        return QByteArray();
    QByteArray bytes = file.readAll();
    if (bytes.size() > 44) {
        const double scale = qBound(0, volume, 100) / 100.0;
        for (int offset = 44; offset + 1 < bytes.size(); offset += 2) {
            const quint16 raw = static_cast<quint8>(bytes.at(offset)) | (static_cast<quint16>(static_cast<quint8>(bytes.at(offset + 1))) << 8);
            const qint16 sample = static_cast<qint16>(raw);
            const qint16 scaled = static_cast<qint16>(sample * scale);
            bytes[offset] = static_cast<char>(scaled & 0xff);
            bytes[offset + 1] = static_cast<char>((static_cast<quint16>(scaled) >> 8) & 0xff);
        }
    }
    return bytes;
}

QByteArray loadScaledAlarmWav(int volume) {
    return loadScaledWavFromResource(QStringLiteral(":/audio/hazard_alarm.wav"), volume);
}

QString cachedSoundFilePath(const QByteArray& sound) {
    if (sound.isEmpty())
        return QString();

    QString root = QStandardPaths::writableLocation(QStandardPaths::TempLocation);
    if (root.trimmed().isEmpty())
        root = QDir::tempPath();
    QDir dir(root);
    if (!dir.exists(QStringLiteral("ApexImageGuardAudio")) && !dir.mkpath(QStringLiteral("ApexImageGuardAudio")))
        return QString();
    if (!dir.cd(QStringLiteral("ApexImageGuardAudio")))
        return QString();

    const QByteArray digest = QCryptographicHash::hash(sound, QCryptographicHash::Sha1).toHex();
    const QString filePath = dir.absoluteFilePath(QStringLiteral("guard-alert-%1.wav").arg(QString::fromLatin1(digest)));
    QFile existing(filePath);
    if (existing.exists() && existing.size() == sound.size())
        return filePath;

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return QString();
    if (file.write(sound) != sound.size()) {
        file.close();
        QFile::remove(filePath);
        return QString();
    }
    file.close();
    return filePath;
}
}  // namespace

LocalAlertService::LocalAlertService(QObject* parent) : QObject(parent) {
    hazardTimer_.setInterval(1100);
    hazardTimer_.setSingleShot(false);
    connect(&hazardTimer_, &QTimer::timeout, this, &LocalAlertService::beepOnce);

    indicatorPresenceTimer_.setSingleShot(true);
    connect(&indicatorPresenceTimer_, &QTimer::timeout, this, &LocalAlertService::onHazardIndicatorPresenceExpired);

    reloadSettings();
}

LocalAlertService::~LocalAlertService() {
#ifdef Q_OS_WIN
    // Stop any asynchronous alert playback before the service is destroyed.
    PlaySoundW(nullptr, nullptr, 0);
#endif
}

void LocalAlertService::reloadSettings() {
    QSettings settings;
    hazardAlarmEnabled_ = settings.value(QString::fromLatin1(kHazardAlarmEnabledKey), true).toBool();
    volume_ = qBound(0, settings.value(QString::fromLatin1(kHazardAlarmVolumeKey), 80).toInt(), 100);
    repeatUntilAcknowledged_ = settings.value(QString::fromLatin1(kHazardRepeatKey), true).toBool();
    hazardSound_ = loadScaledAlarmWav(volume_);
    unknownAccessSound_ = loadScaledWavFromResource(QString::fromUtf8(kAccessDeniedUnknownWav), volume_);
    unapprovedAccessSound_ = loadScaledWavFromResource(QString::fromUtf8(kAccessDeniedUnapprovedWav), volume_);
    updateHazardTimer();
}

bool LocalAlertService::hazardAlarmEnabled() const {
    return hazardAlarmEnabled_;
}
int LocalAlertService::volume() const {
    return volume_;
}

void LocalAlertService::startHazardAlarm(const QString& occurrenceKey) {
    if (occurrenceKey.trimmed().isEmpty())
        return;
    const bool isNewOccurrence = !activeHazards_.contains(occurrenceKey);
    activeHazards_.insert(occurrenceKey, true);
    if (isNewOccurrence)
        acknowledged_ = false;
    updateHazardTimer();
    if (hazardAlarmEnabled_ && isNewOccurrence)
        beepOnce();
}

void LocalAlertService::endHazardAlarm(const QString& occurrenceKey) {
    activeHazards_.remove(occurrenceKey);
    if (activeHazards_.isEmpty())
        acknowledged_ = false;
    updateHazardTimer();
}

void LocalAlertService::acknowledgeHazardAlarm() {
    acknowledged_ = true;
    updateHazardTimer();
}

void LocalAlertService::dismissHazardAlarm() {
    acknowledged_ = true;
    clearHazardIndicatorPresence();
    updateHazardTimer();
}

void LocalAlertService::resetHazardState() {
    // A room transition is a hard ownership boundary. No active occurrence,
    // repeating sound, or one-minute indicator presence from the previous room
    // may remain visible after the workspace changes.
    activeHazards_.clear();
    acknowledged_ = false;
    lastHazardIndicatorActivityMs_ = 0;
    indicatorPresenceTimer_.stop();
    hazardIndicatorVisibleUntilMs_ = 0;
    updateHazardTimer();
#ifdef Q_OS_WIN
    PlaySoundW(nullptr, nullptr, 0);
#endif
    activeAsyncSound_.clear();
    activeAsyncSoundFile_.clear();
    if (hazardPresent_) {
        hazardPresent_ = false;
        emit hazardPresenceChanged(false);
    }
}

void LocalAlertService::noteHazardIndicatorEvent(int eventType) {
    lastHazardIndicatorActivityMs_ = QDateTime::currentMSecsSinceEpoch();
    if (guard::events::shouldExtendHazardIndicatorPresence(eventType))
        extendHazardIndicatorPresence();
}

void LocalAlertService::syncHazardIndicatorIdleHideTimer() {
    if (lastHazardIndicatorActivityMs_ <= 0 || !hazardPresent_)
        return;

    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    hazardIndicatorVisibleUntilMs_ = lastHazardIndicatorActivityMs_ + kHazardIndicatorDisplayMs;
    if (now >= hazardIndicatorVisibleUntilMs_) {
        onHazardIndicatorPresenceExpired();
        return;
    }

    indicatorPresenceTimer_.stop();
    indicatorPresenceTimer_.start(static_cast<int>(hazardIndicatorVisibleUntilMs_ - now));
}

void LocalAlertService::testHazardAlarm() {
    beepOnce();
}

void LocalAlertService::speakUnknownIncoming() {
    playAccessAlert(unknownAccessSound_, tr("Access denied. You are not registered in the system."));
}

void LocalAlertService::speakUnapprovedIncoming() {
    playAccessAlert(unapprovedAccessSound_, tr("Access denied. You do not have permission to enter this room at this time."));
}

void LocalAlertService::extendHazardIndicatorPresence() {
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    hazardIndicatorVisibleUntilMs_ = now + kHazardIndicatorDisplayMs;
    refreshHazardIndicatorPresence();

    const int remainingMs = static_cast<int>(qMax<qint64>(0, hazardIndicatorVisibleUntilMs_ - now));
    indicatorPresenceTimer_.start(remainingMs);
}

void LocalAlertService::clearHazardIndicatorPresence() {
    hazardIndicatorVisibleUntilMs_ = QDateTime::currentMSecsSinceEpoch();
    indicatorPresenceTimer_.stop();
    refreshHazardIndicatorPresence();
}

void LocalAlertService::refreshHazardIndicatorPresence() {
    const bool present = QDateTime::currentMSecsSinceEpoch() < hazardIndicatorVisibleUntilMs_;
    if (present == hazardPresent_)
        return;
    hazardPresent_ = present;
    emit hazardPresenceChanged(present);
}

void LocalAlertService::onHazardIndicatorPresenceExpired() {
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    if (now < hazardIndicatorVisibleUntilMs_)
        return;

    hazardIndicatorVisibleUntilMs_ = now;
    indicatorPresenceTimer_.stop();
    if (!hazardPresent_)
        return;
    hazardPresent_ = false;
    emit hazardPresenceChanged(false);
}

void LocalAlertService::updateHazardTimer() {
    const bool shouldSound =
      guard::events::shouldSoundPcHazardAlarm(hazardAlarmEnabled_, activeHazards_.size(), acknowledged_, repeatUntilAcknowledged_);
    if (shouldSound && !hazardTimer_.isActive()) {
        hazardTimer_.start();
        emit hazardAlarmStateChanged(true);
    } else if (!shouldSound && hazardTimer_.isActive()) {
        hazardTimer_.stop();
        emit hazardAlarmStateChanged(false);
    }
}

void LocalAlertService::beepOnce() {
#ifdef Q_OS_WIN
    if (playSoundBuffer(hazardSound_)) {
        return;
    }
    MessageBeep(MB_ICONHAND);
#else
    QApplication::beep();
#endif
}

bool LocalAlertService::playSoundBuffer(const QByteArray& sound) {
#ifdef Q_OS_WIN
    if (sound.isEmpty())
        return false;

    // Avoid memory-backed asynchronous PlaySound. WinMM may continue reading a
    // caller-owned SND_MEMORY buffer after PlaySound returns, which is unsafe
    // when unknown-face connect/disconnect cycles replace camera/session state.
    // Cache the scaled WAV to a temp file and let WinMM own file playback.
    const QString filePath = cachedSoundFilePath(sound);
    if (filePath.isEmpty())
        return false;

    PlaySoundW(nullptr, nullptr, 0);
    activeAsyncSound_.clear();
    activeAsyncSoundFile_ = filePath;
    const QString nativePath = QDir::toNativeSeparators(activeAsyncSoundFile_);
    if (PlaySoundW(reinterpret_cast<LPCWSTR>(nativePath.utf16()), nullptr, SND_FILENAME | SND_ASYNC | SND_NODEFAULT)) {
        return true;
    }
    activeAsyncSoundFile_.clear();
#else
    Q_UNUSED(sound);
#endif
    return false;
}

void LocalAlertService::playAccessAlert(const QByteArray& sound, const QString& text) {
    if (playSoundBuffer(sound))
        return;
    speak(text);
}

void LocalAlertService::speak(const QString& text) {
#ifdef Q_OS_WIN
    QString escaped = text;
    escaped.replace(QLatin1Char('\''), QStringLiteral("''"));
    const QString command = QStringLiteral(
                              "Add-Type -AssemblyName System.Speech; "
                              "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                              "$s.Volume = %1; $s.Speak('%2')")
                              .arg(volume_)
                              .arg(escaped);
    const bool started =
      QProcess::startDetached(QStringLiteral("powershell.exe"), QStringList() << QStringLiteral("-NoProfile") << QStringLiteral("-NonInteractive")
                                                                              << QStringLiteral("-WindowStyle") << QStringLiteral("Hidden")
                                                                              << QStringLiteral("-Command") << command);
    if (!started)
        beepOnce();
#else
    Q_UNUSED(text);
    beepOnce();
#endif
}

}  // namespace alerts
}  // namespace guard
