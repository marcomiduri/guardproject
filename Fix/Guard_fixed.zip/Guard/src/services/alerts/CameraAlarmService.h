#pragma once

#include "CameraUiModel.h"

#include <QObject>
#include <QString>

namespace guard {
namespace alerts {

struct CameraAlarmCapabilities {
    bool audibleWarning = false;
    bool flashingLight = false;
    bool physicalOutput = false;
};

class CameraAlarmService : public QObject {
    Q_OBJECT

public:
    explicit CameraAlarmService(QObject* parent = nullptr);

    CameraAlarmCapabilities capabilities(const CameraUiModel& camera) const;
    bool startAlarm(const CameraUiModel& camera, const QString& hazardType, QString* errorMessage = nullptr);
    bool stopAlarm(const CameraUiModel& camera, QString* errorMessage = nullptr);
};

}  // namespace alerts
}  // namespace guard
