#include "CameraAlarmService.h"

namespace guard {
namespace alerts {

CameraAlarmService::CameraAlarmService(QObject* parent) : QObject(parent) {}

CameraAlarmCapabilities CameraAlarmService::capabilities(const CameraUiModel& camera) const {
    Q_UNUSED(camera);
    // Vendor alarm-output control is intentionally capability-gated. The
    // current Guard HCNetSDK integration receives onboard alarms but does not
    // yet expose a verified siren/light output command for all camera models.
    return CameraAlarmCapabilities{};
}

bool CameraAlarmService::startAlarm(const CameraUiModel& camera, const QString& hazardType, QString* errorMessage) {
    Q_UNUSED(camera);
    Q_UNUSED(hazardType);
    if (errorMessage)
        *errorMessage = tr("This camera does not expose a supported alarm output.");
    return false;
}

bool CameraAlarmService::stopAlarm(const CameraUiModel& camera, QString* errorMessage) {
    Q_UNUSED(camera);
    if (errorMessage)
        *errorMessage = tr("This camera does not expose a supported alarm output.");
    return false;
}

}  // namespace alerts
}  // namespace guard
