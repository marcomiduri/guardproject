#include <chrono>
#include <cstring>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <frame/FrameBuffer.h>
#include <geometry/Geometry.h>
#include <GuardVision.h>
#include <core/GuardVisionConfig.h>
#include <hazard/HazardConfig.h>
#include <hazard/HazardEvent.h>
#include <hazard/HazardMetrics.h>
#include <hazard/HazardTypes.h>
#include <motion/MotionConfig.h>
#include <frame/VideoFrame.h>

#include "hazard/HazardEngine.h"
#include "hazard/HazardFrameConverter.h"
#include "hazard/HazardStateRegistry.h"
#include "scheduling/LatestFrameSlot.h"

#if defined(_WIN32) && __has_include(<opencv2/opencv.hpp>)
#define GUARDVISION_TASK6_HAVE_OPENCV 1
#include <opencv2/opencv.hpp>
#endif

namespace {

using namespace guardvision;

int g_failures = 0;

void expectTrue(bool condition, const char* message) {
    if (!condition) {
        ++g_failures;
        std::cerr << "FAIL: " << message << '\n';
    }
}

void expectFalse(bool condition, const char* message) {
    expectTrue(!condition, message);
}

StreamConfig makeStreamConfig(const std::string& streamId, const std::string& displayName = {}) {
    StreamConfig config;
    config.streamId = streamId;
    config.displayName = displayName;
    return config;
}

std::string resolveAssetPath(const char* relativePath) {
    const std::string relative(relativePath);
    const std::string assetRelative = relative.rfind("assets/", 0) == 0 ? relative.substr(7) : relative;
    const std::vector<std::string> candidates = {
      relative,
      std::string("../") + relative,
      std::string("../../") + relative,
      std::string("../assets/") + assetRelative,
      std::string("../../assets/") + assetRelative,
      std::string("../../../assets/") + assetRelative,
    };
    for (const std::string& candidate : candidates) {
        std::ifstream file(candidate, std::ios::binary);
        if (file.good()) {
            return candidate;
        }
    }
    return {};
}

std::string resolveHazardModelPath() {
    const std::vector<std::string> candidates = {
      "models/fire_smoke.onnx",
      "sdk/HazardDetect/models/fire_smoke.onnx",
      "../sdk/HazardDetect/models/fire_smoke.onnx",
      "../../sdk/HazardDetect/models/fire_smoke.onnx",
    };
    for (const std::string& candidate : candidates) {
        std::ifstream file(candidate, std::ios::binary);
        if (file.good()) {
            return candidate;
        }
    }
    return discoverHazardModelPath("");
}

HazardConfig defaultHazardConfig() {
    HazardConfig config;
    config.processingLevel = HazardProcessingLevel::Detect;
    config.analysisIntervalMs = 0;
    config.fireEnabled = true;
    config.smokeEnabled = true;
    config.minimumConfidence = 0.35;
    config.minimumRegionWidth = 8;
    config.minimumRegionHeight = 8;
    config.maximumRegionCount = 8;
    config.activationFrameCount = 1;
    config.clearFrameCount = 2;
    config.updateEventIntervalMs = 0;
    return config;
}

VideoFrame makeBgrFrame(const std::string& streamId, int width, int height, std::uint64_t sequence, std::int64_t timestampMs,
                        const std::vector<std::uint8_t>& bytes) {
    VideoFrame frame;
    frame.streamId = streamId;
    frame.width = width;
    frame.height = height;
    frame.stride = width * 3;
    frame.sequence = sequence;
    frame.timestampMs = timestampMs;
    frame.pixelFormat = PixelFormat::BGR24;
    frame.buffer = FrameBuffer::copyFrom(bytes.data(), bytes.size());
    return frame;
}

void testHazardConfigValidation() {
    HazardConfig config = defaultHazardConfig();
    expectTrue(isValidHazardConfig(config), "default hazard config valid");

    config.minimumConfidence = 1.5;
    expectFalse(isValidHazardConfig(config), "reject out-of-range confidence");
    config = defaultHazardConfig();

    config.fireEnabled = false;
    config.smokeEnabled = false;
    expectFalse(isValidHazardConfig(config), "reject detect with both types disabled");
    config = defaultHazardConfig();

    config.processingLevel = HazardProcessingLevel::Disabled;
    config.fireEnabled = false;
    config.smokeEnabled = false;
    expectTrue(isValidHazardConfig(config), "disabled config allows both types off");
}

void testHazardStateTransitions() {
    HazardConfig config = defaultHazardConfig();
    config.activationFrameCount = 2;
    config.clearFrameCount = 2;
    config.updateEventIntervalMs = 1000;

    HazardStateRegistry registry;
    std::vector<HazardRegion> fireRegion;
    HazardRegion region;
    region.type = HazardType::Fire;
    region.bounds = Rect{10, 10, 40, 40};
    region.confidence = 0.9;
    fireRegion.push_back(region);

    auto first = registry.update(fireRegion, {}, config, "stream-a", 1, 1, 100, nullptr);
    expectTrue(first.empty(), "first detection frame is candidate only");

    auto started = registry.update(fireRegion, {}, config, "stream-a", 1, 2, 200, nullptr);
    expectTrue(started.size() == 1 && started.front().type == HazardEventType::Started, "fire started after activation");

    auto updated = registry.update(fireRegion, {}, config, "stream-a", 1, 3, 300, nullptr);
    expectTrue(updated.empty(), "updated event rate limited");

    auto ended = registry.update({}, {}, config, "stream-a", 1, 4, 400, nullptr);
    expectTrue(ended.empty(), "first clear frame enters clearing");

    ended = registry.update({}, {}, config, "stream-a", 1, 5, 500, nullptr);
    expectTrue(ended.size() == 1 && ended.front().type == HazardEventType::Ended, "fire ended after clear frames");

    expectFalse(registry.isFireActive(), "fire inactive after ended");
}

void testHazardLatestFrameReplacement() {
    LatestFrameSlot slot;
    StreamToken token{"stream-a", 1};
    VideoFrame frame = makeBgrFrame("stream-a", 8, 8, 1, 0, std::vector<std::uint8_t>(8 * 8 * 3, 1));
    FrameRoutingJob firstJob{token, frame, 0};
    expectTrue(slot.replace(std::move(firstJob)) == ReplaceResult::Inserted, "first hazard pending inserted");

    frame.sequence = 2;
    FrameRoutingJob secondJob{token, frame, 1};
    expectTrue(slot.replace(std::move(secondJob)) == ReplaceResult::ReplacedPending, "second hazard pending replaces first");
}

void testHazardRoiMapping() {
    HazardConfig config = defaultHazardConfig();
    config.useRoi = true;
    config.roi = NormalizedRect{0.25, 0.25, 0.5, 0.5};

    std::vector<std::uint8_t> pixels(static_cast<std::size_t>(100 * 100 * 3), 0);
    VideoFrame frame = makeBgrFrame("roi", 100, 100, 0, 0, pixels);

    HazardImageConversion conversion;
    expectTrue(convertFrameForHazardDetect(frame, config, conversion), "hazard roi conversion");
    expectTrue(conversion.width == 50 && conversion.height == 50, "roi crop size");
    expectTrue(conversion.roiFullFrame.x == 25 && conversion.roiFullFrame.y == 25, "roi offset");
}

class TestHazardListener : public IGuardVisionEventListener {
public:
    std::vector<HazardEvent> hazardEvents;
    std::mutex mutex;

    void onHazard(const HazardEvent& event) override {
        std::lock_guard<std::mutex> lock(mutex);
        hazardEvents.push_back(event);
    }
};

[[maybe_unused]] bool waitForHazardAnalyzed(GuardVision& guardVision, const std::string& streamId, std::uint64_t minAnalyzed, int timeoutMs) {
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    while (std::chrono::steady_clock::now() < deadline) {
        HazardMetrics metrics;
        if (guardVision.getHazardMetrics(streamId, metrics).ok && metrics.analyzedFrames >= minAnalyzed) {
            return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    return false;
}

void testInitWithoutHazardModels() {
    GuardVision guardVision;
    GuardVisionConfig config;
    expectTrue(guardVision.initialize(config).ok, "initialize without hazard models when disabled");
    guardVision.shutdown();
}

void testHazardRegisterRequiresModel() {
    const std::string modelPath = resolveHazardModelPath();
    if (!modelPath.empty()) {
        std::cout << "SKIPPED: hazard register requires model (model present)\n";
        return;
    }

    GuardVision guardVision;
    GuardVisionConfig config;
    expectTrue(guardVision.initialize(config).ok, "hazard register init");
    StreamConfig stream = makeStreamConfig("hazard-missing");
    stream.hazard = defaultHazardConfig();
    expectFalse(guardVision.registerStream(stream).ok, "hazard register fails without model");
    guardVision.shutdown();
}

void testNoHazardCallbackAfterShutdown() {
    const std::string modelPath = resolveHazardModelPath();
    if (modelPath.empty()) {
        std::cout << "SKIPPED: no hazard callback after shutdown (model missing)\n";
        return;
    }

    GuardVision guardVision;
    GuardVisionConfig config;
    config.hazardWorkerCount = 1;
    config.hazardResourcePath = modelPath;
    expectTrue(guardVision.initialize(config).ok, "hazard shutdown init");

    TestHazardListener listener;
    guardVision.setEventListener(&listener);
    StreamConfig streamConfig = makeStreamConfig("hazard-shutdown");
    streamConfig.hazard = defaultHazardConfig();
    expectTrue(guardVision.registerStream(streamConfig).ok, "hazard shutdown register");

    std::vector<std::uint8_t> pixels(64 * 64 * 3, 128);
    VideoFrame frame = makeBgrFrame("hazard-shutdown", 64, 64, 0, 0, pixels);
    expectTrue(guardVision.submitFrame(frame).accepted, "hazard shutdown submit");

    guardVision.setEventListener(nullptr);
    guardVision.shutdown();

    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    std::lock_guard<std::mutex> lock(listener.mutex);
    expectTrue(listener.hazardEvents.empty(), "no hazard callback after shutdown");
}

void testMotionRegressionWithHazardWorkers() {
    GuardVision guardVision;
    GuardVisionConfig config;
    config.hazardWorkerCount = 2;
    expectTrue(guardVision.initialize(config).ok, "motion regression hazard init");

    StreamConfig stream = makeStreamConfig("motion-hazard");
    stream.motion.enabled = true;
    stream.motion.analysisIntervalMs = 0;
    expectTrue(guardVision.registerStream(stream).ok, "motion regression register");

    std::vector<std::uint8_t> pixels(32 * 32 * 3, 4);
    VideoFrame frame = makeBgrFrame("motion-hazard", 32, 32, 0, 0, pixels);
    expectTrue(guardVision.submitFrame(frame).accepted, "motion regression submit");
    guardVision.shutdown();
}

void testHazardEngineLaunch() {
    const std::string modelPath = resolveHazardModelPath();
    if (modelPath.empty()) {
        std::cout << "SKIPPED: HazardDetect engine launch (model missing)\n";
        return;
    }

    HazardEngine::instance().shutdown();
    const Result result = HazardEngine::instance().initialize(modelPath, 0.4f);
    expectTrue(result.ok, "HazardDetect engine launch");
    expectTrue(HazardEngine::instance().isInitialized(), "hazard engine initialized flag");
    HazardEngine::instance().shutdown();
}

void testRoomFireIntegration() {
    const std::string modelPath = resolveHazardModelPath();
    const std::string videoPath = resolveAssetPath("assets/room-fire.mp4");
    if (modelPath.empty() || videoPath.empty()) {
        std::cout << "SKIPPED: room-fire.mp4 integration (model or asset missing)\n";
        return;
    }

#ifndef GUARDVISION_TASK6_HAVE_OPENCV
    std::cout << "SKIPPED: room-fire.mp4 integration (OpenCV unavailable for tests)\n";
    return;
#else
    cv::VideoCapture capture(videoPath);
    if (!capture.isOpened()) {
        std::cout << "SKIPPED: room-fire.mp4 integration (OpenCV could not open video)\n";
        return;
    }

    GuardVision guardVision;
    GuardVisionConfig config;
    config.hazardWorkerCount = 2;
    config.hazardResourcePath = modelPath;
    expectTrue(guardVision.initialize(config).ok, "room-fire init");

    TestHazardListener listener;
    guardVision.setEventListener(&listener);

    StreamConfig streamConfig = makeStreamConfig("room-fire");
    streamConfig.hazard = defaultHazardConfig();
    expectTrue(guardVision.registerStream(streamConfig).ok, "room-fire register");

    cv::Mat frameMat;
    std::uint64_t sequence = 0;
    int framesSubmitted = 0;
    while (framesSubmitted < 120 && capture.read(frameMat) && !frameMat.empty()) {
        cv::Mat bgr;
        if (frameMat.channels() == 4) {
            cv::cvtColor(frameMat, bgr, cv::COLOR_BGRA2BGR);
        } else if (frameMat.channels() == 3) {
            bgr = frameMat;
        } else {
            continue;
        }

        if (!bgr.isContinuous()) {
            bgr = bgr.clone();
        }

        VideoFrame frame;
        frame.streamId = "room-fire";
        frame.width = bgr.cols;
        frame.height = bgr.rows;
        frame.stride = static_cast<int>(bgr.step);
        frame.sequence = sequence++;
        frame.timestampMs = static_cast<std::int64_t>(sequence) * 33;
        frame.pixelFormat = PixelFormat::BGR24;
        frame.buffer = FrameBuffer::copyFrom(bgr.data, static_cast<std::size_t>(bgr.step * bgr.rows));
        expectTrue(guardVision.submitFrame(std::move(frame)).accepted, "room-fire frame submit");
        ++framesSubmitted;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    const bool analyzed = waitForHazardAnalyzed(guardVision, "room-fire", 1, 15000);
    expectTrue(analyzed, "room-fire hazard analyzed at least one frame");

    HazardMetrics metrics;
    expectTrue(guardVision.getHazardMetrics("room-fire", metrics).ok, "room-fire metrics");
    std::cout << "room-fire.mp4: analyzedFrames=" << metrics.analyzedFrames << " fireDetections=" << metrics.fireDetections
              << " smokeDetections=" << metrics.smokeDetections << " startedEvents=" << metrics.startedEvents << '\n';

    std::lock_guard<std::mutex> lock(listener.mutex);
    if (metrics.fireDetections == 0 && metrics.smokeDetections == 0) {
        std::cout << "NOT SUPPORTED: room-fire.mp4 produced no SDK hazard detections in test window\n";
    } else {
        expectTrue(!listener.hazardEvents.empty(), "room-fire produced hazard events when SDK reported detections");
    }

    guardVision.setEventListener(nullptr);
    guardVision.shutdown();
#endif
}

}  // namespace

int runTask6Tests() {
    testHazardConfigValidation();
    testHazardStateTransitions();
    testHazardLatestFrameReplacement();
    testHazardRoiMapping();
    testInitWithoutHazardModels();
    testHazardRegisterRequiresModel();
    testNoHazardCallbackAfterShutdown();
    testMotionRegressionWithHazardWorkers();
    testHazardEngineLaunch();
    testRoomFireIntegration();
    return g_failures;
}
