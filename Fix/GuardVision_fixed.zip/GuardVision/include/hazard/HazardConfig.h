#pragma once

#include <core/DetectionMode.h>
#include <geometry/Geometry.h>
#include <hazard/HazardTypes.h>

namespace guardvision {

struct HazardConfig {
    HazardProcessingLevel processingLevel = HazardProcessingLevel::Disabled;
    DetectionMode detectionMode = DetectionMode::Software;

    int analysisIntervalMs = 250;

    bool fireEnabled = true;
    bool smokeEnabled = true;

    double minimumConfidence = 0.4;
    int minimumRegionWidth = 16;
    int minimumRegionHeight = 16;
    int maximumRegionCount = 8;

    int activationFrameCount = 2;
    int clearFrameCount = 3;
    int updateEventIntervalMs = 500;

    bool useRoi = false;
    NormalizedRect roi;
};

bool isValidHazardConfig(const HazardConfig& config) noexcept;

}  // namespace guardvision
