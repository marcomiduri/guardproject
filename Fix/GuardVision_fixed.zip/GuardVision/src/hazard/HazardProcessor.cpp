#include "hazard/HazardProcessor.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <mutex>
#include <vector>

#ifdef GUARDVISION_HAVE_HAZARD
#include <hazard_detect.h>
#endif

#include "face/IdentifyEngine.h"
#include "hazard/HazardEngine.h"
#include "hazard/HazardFrameConverter.h"

#include "detail/AtomicUtil.h"
namespace guardvision {
namespace {

GuardVisionError makeVendorError(GuardVisionErrorCode code, const char* component, const char* message, int vendorCode, const std::string& streamId) {
    GuardVisionError error;
    error.code = code;
    error.component = component;
    error.message = message;
    error.streamId = streamId;
    error.recoverable = true;
    error.vendorErrorCode = vendorCode;
    return error;
}

bool normalizedBoxIsValid(const float x, const float y, const float width, const float height, const float confidence) {
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(width) || !std::isfinite(height) || !std::isfinite(confidence)) {
        return false;
    }
    if (width <= 0.f || height <= 0.f) {
        return false;
    }
    const float right = x + width;
    const float bottom = y + height;
    return right > 0.f && bottom > 0.f && x < 1.f && y < 1.f;
}

Rect normalizedDetectionToFullFrame(const float x, const float y, const float width, const float height, int imageWidth, int imageHeight,
                                    const Rect& roiOffset) {
    const int px = std::max(0, static_cast<int>(std::lround(x * static_cast<float>(imageWidth))));
    const int py = std::max(0, static_cast<int>(std::lround(y * static_cast<float>(imageHeight))));
    const int pw = std::max(1, static_cast<int>(std::lround(width * static_cast<float>(imageWidth))));
    const int ph = std::max(1, static_cast<int>(std::lround(height * static_cast<float>(imageHeight))));
    return Rect{px + roiOffset.x, py + roiOffset.y, pw, ph};
}

bool mapVendorType(int vendorType, HazardType& out) {
    switch (vendorType) {
        case HAZARD_TYPE_FIRE:
        case HAZARD_TYPE_FLAME:
            out = HazardType::Fire;
            return true;
        case HAZARD_TYPE_SMOKE:
            out = HazardType::Smoke;
            return true;
        default:
            return false;
    }
}

constexpr int kMaxHazardDetectDimension = 1280;
constexpr int kMinHazardDetectDimension = 8;

bool hazardDetectionDimensionsAreSafe(int width, int height) {
    if (width < kMinHazardDetectDimension || height < kMinHazardDetectDimension) {
        return false;
    }
    const std::int64_t pixels = static_cast<std::int64_t>(width) * static_cast<std::int64_t>(height);
    return pixels > 0 && pixels <= static_cast<std::int64_t>(3840) * 2160;
}

void downscaleConversionForDetection(HazardImageConversion& conversion) {
    if (!hazardDetectionDimensionsAreSafe(conversion.width, conversion.height)) {
        conversion.pixels.clear();
        conversion.width = 0;
        conversion.height = 0;
        conversion.stride = 0;
        return;
    }

    const int maxSide = std::max(conversion.width, conversion.height);
    if (maxSide <= kMaxHazardDetectDimension) {
        return;
    }

    const int newWidth = std::max(
      kMinHazardDetectDimension, static_cast<int>(std::lround(static_cast<double>(conversion.width) * static_cast<double>(kMaxHazardDetectDimension) /
                                                              static_cast<double>(maxSide))));
    const int newHeight = std::max(kMinHazardDetectDimension,
                                   static_cast<int>(std::lround(static_cast<double>(conversion.height) *
                                                                static_cast<double>(kMaxHazardDetectDimension) / static_cast<double>(maxSide))));

    std::vector<std::uint8_t> scaled(static_cast<std::size_t>(newWidth) * static_cast<std::size_t>(newHeight) * 3);
    for (int y = 0; y < newHeight; ++y) {
        const int srcY = (y * conversion.height) / newHeight;
        for (int x = 0; x < newWidth; ++x) {
            const int srcX = (x * conversion.width) / newWidth;
            const std::size_t srcOffset = static_cast<std::size_t>((srcY * conversion.width + srcX) * 3);
            const std::size_t dstOffset = static_cast<std::size_t>((y * newWidth + x) * 3);
            scaled[dstOffset] = conversion.pixels[srcOffset];
            scaled[dstOffset + 1] = conversion.pixels[srcOffset + 1];
            scaled[dstOffset + 2] = conversion.pixels[srcOffset + 2];
        }
    }

    conversion.pixels = std::move(scaled);
    conversion.width = newWidth;
    conversion.height = newHeight;
    conversion.stride = newWidth * 3;
}

}  // namespace

HazardProcessResult HazardProcessor::processFrame(const VideoFrame& frame, const StreamToken& token, const HazardConfig& config,
                                                  HazardStateRegistry& state, HazardMetricsState& metrics, std::int64_t& lastAnalyzedTimestampMs,
                                                  HazardProcessingScratch& scratch) {
    HazardProcessResult result;
    const auto start = std::chrono::steady_clock::now();

    if (lastAnalyzedTimestampMs >= 0 && config.analysisIntervalMs > 0 && frame.timestampMs - lastAnalyzedTimestampMs < config.analysisIntervalMs) {
        result.skippedByInterval = true;
        metrics.skippedByInterval.fetch_add(1);
        return result;
    }

#ifndef GUARDVISION_HAVE_HAZARD
    result.hadError = true;
    result.error = makeVendorError(GuardVisionErrorCode::HazardEngineInitializationFailed, "HazardProcessor", "Hazard support is not available.", -1,
                                   token.streamId);
    metrics.processingErrors.fetch_add(1);
    return result;
#else
    if (!HazardEngine::instance().isInitialized()) {
        result.hadError = true;
        result.error =
          makeVendorError(GuardVisionErrorCode::HazardModelMissing, "HazardProcessor", "HazardDetect engine is not initialized.", -1, token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    HazardImageConversion& conversion = scratch.conversion;
    if (!convertFrameForHazardDetect(frame, config, conversion, scratch.frameConversion)) {
        result.hadError = true;
        result.error = conversion.error;
        result.error.streamId = token.streamId;
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    downscaleConversionForDetection(conversion);
    if (conversion.width <= 0 || conversion.height <= 0 || conversion.pixels.empty()) {
        result.hadError = true;
        result.error = makeVendorError(GuardVisionErrorCode::InvalidFrame, "HazardProcessor", "Hazard conversion produced an unsafe frame size.", -1,
                                       token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    HazardDetection detections[HAZARD_DETECT_MAX_OUTPUT];
    int detectionCount = 0;
    {
        // Identify and HazardDetect are not safe concurrently in-process. Use the
        // same recursive vendor lock that guards HF* session and registry calls.
        std::lock_guard<std::recursive_mutex> vendorLock(IdentifyEngine::instance().apiMutex());
        detectionCount = HazardDetect_DetectBgr(conversion.pixels.data(), conversion.width, conversion.height, conversion.stride, detections,
                                                HAZARD_DETECT_MAX_OUTPUT);
    }
    if (detectionCount < 0) {
        const char* lastError = HazardDetect_LastError();
        result.hadError = true;
        result.error = makeVendorError(GuardVisionErrorCode::HazardProcessingFailed, "HazardProcessor",
                                       lastError != nullptr ? lastError : "HazardDetect_DetectBgr failed.", -1, token.streamId);
        metrics.processingErrors.fetch_add(1);
        return result;
    }

    std::vector<HazardRegion> fireRegions;
    std::vector<HazardRegion> smokeRegions;
    fireRegions.reserve(static_cast<std::size_t>(config.maximumRegionCount));
    smokeRegions.reserve(static_cast<std::size_t>(config.maximumRegionCount));

    for (int index = 0; index < detectionCount; ++index) {
        const HazardDetection& detection = detections[index];
        if (!normalizedBoxIsValid(detection.x, detection.y, detection.width, detection.height, detection.confidence)) {
            metrics.filteredRegions.fetch_add(1);
            continue;
        }

        HazardType hazardType = HazardType::Fire;
        if (!mapVendorType(static_cast<int>(detection.type), hazardType)) {
            metrics.filteredRegions.fetch_add(1);
            continue;
        }
        if (hazardType == HazardType::Fire) {
            metrics.fireDetections.fetch_add(1);
            if (!config.fireEnabled) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }
        } else {
            metrics.smokeDetections.fetch_add(1);
            if (!config.smokeEnabled) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }
        }

        if (static_cast<double>(detection.confidence) < config.minimumConfidence) {
            metrics.filteredRegions.fetch_add(1);
            continue;
        }

        HazardRegion region;
        region.type = hazardType;
        region.confidence = static_cast<double>(detection.confidence);
        region.bounds = normalizedDetectionToFullFrame(detection.x, detection.y, detection.width, detection.height, conversion.width,
                                                       conversion.height, conversion.roiFullFrame);
        if (region.bounds.width < config.minimumRegionWidth || region.bounds.height < config.minimumRegionHeight) {
            metrics.filteredRegions.fetch_add(1);
            continue;
        }

        if (hazardType == HazardType::Fire) {
            if (static_cast<int>(fireRegions.size()) >= config.maximumRegionCount) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }
            fireRegions.push_back(region);
        } else {
            if (static_cast<int>(smokeRegions.size()) >= config.maximumRegionCount) {
                metrics.filteredRegions.fetch_add(1);
                continue;
            }
            smokeRegions.push_back(region);
        }
    }

    result.events = state.update(fireRegions, smokeRegions, config, token.streamId, token.generation, frame.sequence, frame.timestampMs, &metrics);

    lastAnalyzedTimestampMs = frame.timestampMs;
    metrics.analyzedFrames.fetch_add(1);

    const auto end = std::chrono::steady_clock::now();
    result.processingTimeUs = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
    metrics.lastProcessingTimeUs = result.processingTimeUs;
    detail::updateAtomicMaximum(metrics.maximumProcessingTimeUs, result.processingTimeUs);
    return result;
#endif
}

std::vector<HazardEvent> HazardProcessor::endActiveStates(const StreamToken& token, const HazardConfig& config, HazardStateRegistry& state,
                                                          HazardMetricsState& metrics, std::uint64_t sequence, std::int64_t timestampMs) {
    (void)config;
    return state.endActiveStates(token.streamId, token.generation, sequence, timestampMs, &metrics);
}

}  // namespace guardvision
